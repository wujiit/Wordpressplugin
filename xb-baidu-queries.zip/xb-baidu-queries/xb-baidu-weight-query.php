<?php
/*
Plugin Name: 小半百度权重查询
Description: 一个用于查询网站百度权重的WordPress插件，支持自定义API接口和密钥，记录查询历史，允许游客查询（使用用户ID 0）。
Version: 1.0.3
Author: Summer
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xb_baidu_activate');
function xb_baidu_activate() {
    xb_baidu_create_database();
    xb_baidu_create_front_page();
}

// 创建数据库表
function xb_baidu_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 用户查询次数表
    $usage_table = $wpdb->prefix . 'xb_baidu_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        query_date date NOT NULL,
        query_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_date (user_id, query_date)
    ) $charset_collate;";

    // 查询记录表
    $queries_table = $wpdb->prefix . 'xb_baidu_queries';
    $queries_sql = "CREATE TABLE $queries_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        domain varchar(255) NOT NULL,
        query_status varchar(255) NOT NULL,
        query_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $result_usage = dbDelta($usage_sql);
    $result_queries = dbDelta($queries_sql);

    error_log('XB Baidu Query: Database tables created or updated. Usage table: ' . print_r($result_usage, true) . ', Queries table: ' . print_r($result_queries, true));
}

// 检查并创建前台页面
function xb_baidu_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_baidu_query_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => '网站百度权重查询',
            'post_content' => '[xb_baidu_query_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_baidu_enqueue_scripts');
function xb_baidu_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_baidu_query_form')) {
        wp_enqueue_style('xb_baidu_styles', plugins_url('xb-baidu-styles.css', __FILE__), array(), '1.0.3');
        wp_enqueue_script('xb_baidu_scripts', plugins_url('xb-baidu-scripts.js', __FILE__), array('jquery'), '1.0.3', true);
        
        wp_localize_script('xb_baidu_scripts', 'xb_baidu_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('xb_baidu_query_nonce'),
            'login_url' => wp_login_url(get_permalink())
        ));
    }
}

// 创建短代码，允许游客查询
add_shortcode('xb_baidu_query_form', 'xb_baidu_query_form_shortcode');
function xb_baidu_query_form_shortcode() {
    $ad_content = get_option('xb_baidu_ad_content', '');
    $default_limit = absint(get_option('xb_baidu_default_limit', 5)); // 默认5次

    ob_start();
    ?>
    <div class="xb_baidu_container">
        <div class="xb_baidu_title">网站百度权重查询助手</div>
        
        <?php
        $user_id = is_user_logged_in() ? get_current_user_id() : 0; // 游客使用用户ID 0
        $today = current_time('Y-m-d');
        global $wpdb;
        $table_name = $wpdb->prefix . 'xb_baidu_usage';
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT query_count, custom_limit FROM $table_name WHERE user_id = %d AND query_date = %s",
                $user_id,
                $today
            )
        );

        $query_count = $row ? absint($row->query_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;
        $remaining = max(0, $user_limit - $query_count);
        error_log("XB Baidu Query: User ID $user_id, Limit: $user_limit, Count: $query_count, Remaining: $remaining");
        ?>
        <div class="xb_baidu_query_section">
            <?php if ($query_count >= $user_limit): ?>
                <div class="xb_baidu_message">今日查询次数已用完，请明天再试！</div>
            <?php else: ?>
                <form id="xb_baidu_query_form" method="post">
                    <input type="text" name="xb_baidu_domain" id="xb_baidu_domain" placeholder="请输入域名（如：baidu.com）" required>
                    <button type="submit" class="xb_baidu_submit_button">查询</button>
                    <input type="hidden" name="xb_baidu_nonce" id="xb_baidu_nonce" value="<?php echo wp_create_nonce('xb_baidu_query_nonce'); ?>">
                </form>
            <?php endif; ?>
            <div class="xb_baidu_result_section">
                <div id="xb_baidu_result"></div>
                <div class="xb_baidu_usage_info">今日剩余查询次数：<?php echo esc_html($remaining); ?>/<?php echo esc_html($user_limit); ?></div>
            </div>
        </div>
        <div class="xb_baidu_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
    </div>
    <?php
    return ob_get_clean();
}

// 处理 AJAX 查询请求，允许游客查询
add_action('wp_ajax_xb_baidu_query', 'xb_baidu_handle_query');
add_action('wp_ajax_nopriv_xb_baidu_query', 'xb_baidu_handle_query'); // 添加对游客的支持
function xb_baidu_handle_query() {
    // 验证 nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'xb_baidu_query_nonce')) {
        $nonce_received = isset($_POST['nonce']) ? $_POST['nonce'] : 'none';
        error_log('XB Baidu Query: Nonce verification failed. Received nonce: ' . $nonce_received);
        wp_send_json_error(array('message' => '安全验证失败，请刷新页面重试！', 'debug' => 'Nonce verification failed.'));
        return;
    }

    $domain = sanitize_text_field($_POST['domain']);
    // 验证域名格式
    if (!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+$/', $domain)) {
        wp_send_json_error(array('message' => '请输入有效的域名格式（如：baidu.com）！'));
        return;
    }

    $user_id = is_user_logged_in() ? get_current_user_id() : 0; // 游客使用用户ID 0
    $today = current_time('Y-m-d');
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_baidu_usage';
    $queries_table = $wpdb->prefix . 'xb_baidu_queries';

    // 检查查询限制
    $default_limit = absint(get_option('xb_baidu_default_limit', 5));
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT query_count, custom_limit FROM $usage_table WHERE user_id = %d AND query_date = %s",
            $user_id,
            $today
        )
    );

    $query_count = $row ? absint($row->query_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;

    if ($query_count >= $user_limit) {
        wp_send_json_error(array('message' => '今日查询次数已用完，请明天再试！'));
        return;
    }

    // 调用 API
    $api_url = get_option('xb_baidu_api_url', 'https://apistore.aizhan.com/baidurank/siteinfos/');
    $api_key = get_option('xb_baidu_api_key');
    $request_url = trailingslashit($api_url) . $api_key . '?domains=' . urlencode($domain);

    $args = array(
        'timeout' => 10,
        'sslverify' => false
    );

    $response = wp_remote_get($request_url, $args);
    $query_status = 'failed';

    // 准备插入记录
    $insert_data = array(
        'user_id' => $user_id,
        'domain' => $domain,
        'query_status' => $query_status,
        'query_time' => current_time('mysql')
    );

    if (is_wp_error($response)) {
        $query_status = $response->get_error_message();
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s'));
        error_log('XB Baidu Query: Inserted error record. ID: ' . $wpdb->insert_id . ', Error: ' . $query_status);
        wp_send_json_error(array('message' => 'API 请求失败：' . esc_html($query_status), 'debug' => $query_status));
        return;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['code']) && $data['code'] == 200000 && !empty($data['data']['success'])) {
        $query_status = 'success';
        $insert_data['query_status'] = $query_status;

        // 更新查询次数
        if ($row) {
            $new_count = $query_count + 1;
            $wpdb->update(
                $usage_table,
                array('query_count' => $new_count),
                array('user_id' => $user_id, 'query_date' => $today),
                array('%d'),
                array('%d', '%s')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'query_date' => $today,
                    'query_count' => 1,
                    'custom_limit' => null
                ),
                array('%d', '%s', '%d', '%d')
            );
        }

        // 插入查询记录
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s'));
        error_log('XB Baidu Query: Inserted success record. ID: ' . $wpdb->insert_id . ', Domain: ' . $domain);

        // 格式化结果
        $result = $data['data']['success'][0];
        $output = '<table class="xb_baidu_result_table">';
        $output .= '<tr><th>域名</th><td>' . esc_html($result['domain']) . '</td></tr>';
        $output .= '<tr><th>PC权重</th><td>' . esc_html($result['pc_br']) . '</td></tr>';
        $output .= '<tr><th>移动权重</th><td>' . esc_html($result['m_br']) . '</td></tr>';
        $output .= '<tr><th>预计总来路</th><td>' . esc_html($result['ip']) . '</td></tr>';
        $output .= '<tr><th>PC预计来路</th><td>' . esc_html($result['pc_ip']) . '</td></tr>';
        $output .= '<tr><th>移动预计来路</th><td>' . esc_html($result['m_ip']) . '</td></tr>';
        $output .= '</table>';

        wp_send_json_success(array(
            'result' => $output,
            'remaining' => $user_limit - ($query_count + 1),
            'limit' => $user_limit
        ));
    } else {
        $query_status = isset($data['msg']) ? $data['msg'] : '未知错误';
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s'));
        error_log('XB Baidu Query: Inserted failed record. ID: ' . $wpdb->insert_id . ', Status: ' . $query_status);
        wp_send_json_error(array('message' => '查询失败：' . esc_html($query_status), 'debug' => $query_status));
    }
}

// 添加管理菜单
add_action('admin_menu', 'xb_baidu_admin_menu');
function xb_baidu_admin_menu() {
    add_menu_page(
        '百度权重查询设置',
        '百度权重设置',
        'manage_options',
        'xb_baidu_settings',
        'xb_baidu_settings_page',
        'dashicons-chart-line',
        80
    );
    add_submenu_page(
        'xb_baidu_settings',
        '查询记录',
        '查询记录',
        'manage_options',
        'xb_baidu_all_records',
        'xb_baidu_all_records_page'
    );
}

// 插件设置页面
function xb_baidu_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['xb_baidu_save_settings'])) {
        check_admin_referer('xb_baidu_settings_nonce');
        
        update_option('xb_baidu_api_url', sanitize_text_field($_POST['xb_baidu_api_url']));
        update_option('xb_baidu_api_key', sanitize_text_field($_POST['xb_baidu_api_key']));
        $new_limit = absint($_POST['xb_baidu_default_limit']);
        if ($new_limit > 0) {
            update_option('xb_baidu_default_limit', $new_limit);
        }
        $allowed_html = array(
            'a' => array('href' => array(), 'title' => array(), 'target' => array()),
            'img' => array('src' => array(), 'alt' => array(), 'width' => array(), 'height' => array()),
            'p' => array(),
            'div' => array('class' => array(), 'style' => array()),
            'span' => array('class' => array(), 'style' => array()),
            'strong' => array(),
            'em' => array(),
            'br' => array()
        );
        update_option('xb_baidu_ad_content', wp_kses($_POST['xb_baidu_ad_content'], $allowed_html));
        
        echo '<div id="xb_baidu_settings_notice" class="updated"><p>设置已保存！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_baidu_settings_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    global $wpdb;
    $queries_table = $wpdb->prefix . 'xb_baidu_queries';
    $stats = array();
    $stats['total_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table");
    $stats['success_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table WHERE query_status = 'success'");
    $stats['failed_queries'] = $stats['total_queries'] - $stats['success_queries'];
    $stats['today_queries'] = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $queries_table WHERE DATE(query_time) = %s", current_time('Y-m-d'))
    );

    ?>
    <div class="wrap">
        <div class="xb_baidu_admin_title">百度权重查询设置</div>
        <form method="post">
            <?php wp_nonce_field('xb_baidu_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_baidu_api_url">API 接口地址</label></th>
                    <td><input type="text" name="xb_baidu_api_url" id="xb_baidu_api_url" value="<?php echo esc_attr(get_option('xb_baidu_api_url', 'https://apistore.aizhan.com/baidurank/siteinfos/')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_baidu_api_key">API 密钥</label></th>
                    <td><input type="text" name="xb_baidu_api_key" id="xb_baidu_api_key" value="<?php echo esc_attr(get_option('xb_baidu_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_baidu_default_limit">默认每日查询次数</label></th>
                    <td><input type="number" name="xb_baidu_default_limit" id="xb_baidu_default_limit" value="<?php echo esc_attr(get_option('xb_baidu_default_limit', 5)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_baidu_ad_content">广告内容</label></th>
                    <td>
                        <textarea name="xb_baidu_ad_content" id="xb_baidu_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_baidu_ad_content')); ?></textarea>
                        <p class="description">支持 HTML 格式</p>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="xb_baidu_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        <div class="xb_baidu_stats">
            <p>总查询次数：<?php echo esc_html($stats['total_queries'] ?: 0); ?></p>
            <p>成功查询次数：<?php echo esc_html($stats['success_queries'] ?: 0); ?></p>
            <p>失败查询次数：<?php echo esc_html($stats['failed_queries'] ?: 0); ?></p>
            <p>今日查询次数：<?php echo esc_html($stats['today_queries'] ?: 0); ?></p>
        </div>
    </div>
    <?php
}

// 所有查询记录页面
function xb_baidu_all_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_baidu_usage';
    $queries_table = $wpdb->prefix . 'xb_baidu_queries';
    $user_id = isset($_POST['xb_baidu_user_id']) ? absint($_POST['xb_baidu_user_id']) : 0;
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    // 删除单条记录
    if (isset($_POST['xb_baidu_delete_record']) && isset($_POST['record_id'])) {
        check_admin_referer('xb_baidu_delete_record_nonce');
        $wpdb->delete($queries_table, array('id' => absint($_POST['record_id'])), array('%d'));
        echo '<div id="xb_baidu_delete_notice" class="updated"><p>记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_baidu_delete_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 删除用户全部记录（包括游客记录）
    if (isset($_POST['xb_baidu_delete_all_records']) && $user_id) {
        check_admin_referer('xb_baidu_delete_all_records_nonce');
        $wpdb->delete($queries_table, array('user_id' => $user_id), array('%d'));
        $wpdb->delete($usage_table, array('user_id' => $user_id), array('%d'));
        echo '<div id="xb_baidu_delete_all_notice" class="updated"><p>所有记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_baidu_delete_all_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 保存用户自定义限制（包括游客ID 0）
    if (isset($_POST['xb_baidu_save_user_limit']) && $user_id) {
        check_admin_referer('xb_baidu_user_limit_nonce');
        $custom_limit = isset($_POST['xb_baidu_custom_limit']) ? absint($_POST['xb_baidu_custom_limit']) : null;
        
        $wpdb->update(
            $usage_table,
            array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
            array('user_id' => $user_id, 'query_date' => current_time('Y-m-d')),
            array('%d'),
            array('%d', '%s')
        );
        
        echo '<div id="xb_baidu_limit_notice" class="updated"><p>用户查询限制已更新！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_baidu_limit_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 统计数据
    $stats = array();
    $where_clause = $user_id ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : '';
    $stats['total_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table $where_clause");
    $stats['success_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table WHERE query_status = 'success' " . ($user_id ? $wpdb->prepare('AND user_id = %d', $user_id) : ''));
    $stats['failed_queries'] = $stats['total_queries'] - $stats['success_queries'];
    $stats['today_queries'] = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $queries_table WHERE DATE(query_time) = %s " . ($user_id ? 'AND user_id = %d' : ''), current_time('Y-m-d'), $user_id)
    );

    // 获取记录
    $offset = ($paged - 1) * $per_page;
    $query = $user_id
        ? $wpdb->prepare("SELECT id, user_id, domain, query_status, query_time FROM $queries_table WHERE user_id = %d ORDER BY query_time DESC LIMIT %d, %d", $user_id, $offset, $per_page)
        : $wpdb->prepare("SELECT id, user_id, domain, query_status, query_time FROM $queries_table ORDER BY query_time DESC LIMIT %d, %d", $offset, $per_page);
    $records = $wpdb->get_results($query);
    $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table" . ($user_id ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : ''));
    $total_pages = ceil($total_records / $per_page);

    error_log('XB Baidu Query: Fetched records. User ID: ' . ($user_id ?: 'All') . ', Total records: ' . $total_records);

    $user_info = $user_id && $user_id != 0 ? get_userdata($user_id) : null;
    $user_display = $user_id == 0 ? '游客' : ($user_info ? $user_info->user_login : '未知用户');
    ?>
    <div class="wrap">
        <div class="xb_baidu_admin_title">所有查询记录</div>
        <form method="post">
            <p>
                <label for="xb_baidu_user_id">输入用户 ID（0 表示游客，留空显示所有记录）：</label>
                <input type="number" name="xb_baidu_user_id" id="xb_baidu_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <?php if ($user_id || $user_id === 0): ?>
            <h2>用户：<?php echo esc_html($user_display); ?> (ID: <?php echo $user_id; ?>)</h2>
            <form method="post">
                <?php wp_nonce_field('xb_baidu_user_limit_nonce'); ?>
                <p>
                    <label for="xb_baidu_custom_limit">设置自定义每日查询次数（0 表示使用默认值）：</label>
                    <input type="number" name="xb_baidu_custom_limit" id="xb_baidu_custom_limit" min="0">
                    <input type="hidden" name="xb_baidu_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_baidu_save_user_limit" class="button-primary" value="保存">
                </p>
            </form>
            <form method="post">
                <?php wp_nonce_field('xb_baidu_delete_all_records_nonce'); ?>
                <input type="hidden" name="xb_baidu_user_id" value="<?php echo esc_attr($user_id); ?>">
                <p><input type="submit" name="xb_baidu_delete_all_records" class="button-secondary" value="删除所有记录" onclick="return confirm('确定删除所有记录吗？');"></p>
            </form>
        <?php endif; ?>

        <div class="xb_baidu_stats">
            <p>总查询次数：<?php echo esc_html($stats['total_queries'] ?: 0); ?></p>
            <p>成功查询次数：<?php echo esc_html($stats['success_queries'] ?: 0); ?></p>
            <p>失败查询次数：<?php echo esc_html($stats['failed_queries'] ?: 0); ?></p>
            <p>今日查询次数：<?php echo esc_html($stats['today_queries'] ?: 0); ?></p>
        </div>

        <table class="widefat">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>查询时间</th>
                    <th>域名</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="5">暂无查询记录。</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td><?php echo esc_html($record->user_id == 0 ? '游客' : $record->user_id); ?></td>
                            <td><?php echo esc_html($record->query_time); ?></td>
                            <td><?php echo esc_html($record->domain); ?></td>
                            <td><?php echo esc_html($record->query_status); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_baidu_delete_record_nonce'); ?>
                                    <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>">
                                    <input type="submit" name="xb_baidu_delete_record" class="button-link" value="删除" onclick="return confirm('确定删除此记录？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}
?>