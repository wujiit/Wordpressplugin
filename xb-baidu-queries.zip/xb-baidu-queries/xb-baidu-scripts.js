jQuery(document).ready(function ($) {
    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('XB Baidu Query: jQuery 未加载！');
        $('#xb_baidu_result').html('<div class="xb_baidu_message">脚本加载失败，请刷新页面！</div>');
        return;
    }

    // 确保 xb_baidu_ajax 配置
    if (typeof xb_baidu_ajax === 'undefined') {
        console.error('XB Baidu Query: xb_baidu_ajax 未定义！');
        $('#xb_baidu_result').html('<div class="xb_baidu_message">脚本配置失败，请检查插件设置！</div>');
        return;
    }

    // 查询表单提交
    $('#xb_baidu_query_form').on('submit', function (e) {
        e.preventDefault();

        var $form = $(this);
        var domain = $('#xb_baidu_domain').val().trim();
        var nonce = $('#xb_baidu_nonce').val();

        if (!domain) {
            $('#xb_baidu_result').html('<div class="xb_baidu_message">请输入域名！</div>');
            return;
        }

        if (!nonce) {
            $('#xb_baidu_result').html('<div class="xb_baidu_message">安全验证参数丢失，请刷新页面！</div>');
            return;
        }

        $.ajax({
            url: xb_baidu_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_baidu_query',
                domain: domain,
                nonce: nonce
            },
            beforeSend: function () {
                $('.xb_baidu_submit_button').prop('disabled', true).text('查询中...');
            },
            success: function (response) {
                if (response.success) {
                    $('#xb_baidu_result').html(response.data.result);
                    $('.xb_baidu_usage_info').text('今日剩余查询次数：' + response.data.remaining + '/' + response.data.limit);

                    if (response.data.remaining <= 0) {
                        $form.hide();
                        $('#xb_baidu_result').append('<div class="xb_baidu_message">今日查询次数已用尽，请明天再试！</div>');
                    }
                } else {
                    $('#xb_baidu_result').html('<div class="xb_baidu_message">' + response.data.message + '</div>');
                }
            },
            error: function (xhr, status, error) {
                console.error('XB Baidu Query: AJAX 错误：' + error);
                $('#xb_baidu_result').html('<div class="xb_baidu_message">请求失败：' + error + '。请检查网络或刷新页面。</div>');
            },
            complete: function () {
                $('.xb_baidu_submit_button').prop('disabled', false).text('查询');
            }
        });
    });

    // “快速登录”按钮点击事件
    $('.xb_baidu_login_button').on('click', function (e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });
});