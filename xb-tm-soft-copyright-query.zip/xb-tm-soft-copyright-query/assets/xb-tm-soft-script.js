jQuery(document).ready(function($) {
    // 定义错误码到用户友好消息的映射
    var errorMessages = {
        400: '请求参数错误，请检查输入',
        404: '查询错误，请联系管理员检查',
        500: '服务维护中，请稍后再试',
        601: '查询错误，请联系管理员检查',
        602: '查询错误，请联系管理员检查',
        603: '查询错误，请联系管理员检查',
        604: '查询错误，请联系管理员检查',
        605: '查询错误，请联系管理员检查',
        606: '调用频率过高，请稍后再试',
        607: '查询错误，请联系管理员检查',
        609: '请求过于频繁，请稍后再试',
        610: '请求超时，请稍后再试',
        999: '未知错误，请稍后再试',
        1001: '今日查询次数已用完，请明天再来'
    };

    // 更新剩余查询次数
    function updateRemainingQueries() {
        $.ajax({
            url: xbTmSoft.ajaxurl + '/remaining-queries',
            method: 'GET',
            headers: {
                'X-WP-Nonce': xbTmSoft.nonce
            },
            success: function(response) {
                 // 调试日志console.log('Remaining Queries Response:', response);
                var remaining = response.remaining !== undefined ? response.remaining : 0;
                var dailyLimit = xbTmSoft.daily_limit;
                var $usage = $('.xb-tm-soft-usage');
                
                if (remaining > 0) {
                    $usage.html('今日剩余查询次数：<span id="xb-tm-soft-remaining">' + remaining + '</span>/' + dailyLimit);
                } else {
                    $usage.html('今日使用次数已经用完了，请明天再来');
                }
            },
            error: function(xhr) {
                //console.error('Failed to fetch remaining queries:', xhr.responseText);
                $('.xb-tm-soft-usage').html('无法获取剩余查询次数，请刷新页面');
            }
        });
    }

    // 查询按钮点击事件
    $('#xb-tm-soft-query-btn').on('click', function() {
        var keyword = $('#xb-tm-soft-keyword').val().trim();
        if (!keyword) {
            alert('请输入企业名称或社会统一信用代码');
            return;
        }

        $('#xb-tm-soft-loading').show();
        $('#xb-tm-soft-results').find('.xb-tm-soft-card-container, .xb-tm-soft-pagination, .xb-tm-soft-error, .xb-tm-soft-no-results, .xb-tm-soft-count').remove();

        $.ajax({
            url: xbTmSoft.ajaxurl + '/query',
            method: 'POST',
            headers: {
                'X-WP-Nonce': xbTmSoft.nonce
            },
            data: {
                keyword: keyword,
                frontend_page_no: 1
            },
            success: function(response) {
                $('#xb-tm-soft-loading').hide();
                renderResults(response);
                updateRemainingQueries(); // 查询成功后更新剩余次数
            },
            error: function(xhr) {
                $('#xb-tm-soft-loading').hide();
                var errorData = xhr.responseJSON || {};
                var errorCode = errorData.code || 999;
                var errorMsg = errorMessages[errorCode] || '查询失败，请稍后再试';
                $('#xb-tm-soft-results').append('<div class="xb-tm-soft-error">' + errorMsg + '</div>');
                //console.error('Query Error:', xhr.responseText);
            }
        });
    });

    // 分页点击事件
    $(document).on('click', '.xb-tm-soft-page-link', function(e) {
        e.preventDefault();
        var pageNo = $(this).data('page');
        var keyword = $('#xb-tm-soft-keyword').val().trim();

        $('#xb-tm-soft-loading').show();
        $('#xb-tm-soft-results').find('.xb-tm-soft-card-container, .xb-tm-soft-pagination, .xb-tm-soft-error, .xb-tm-soft-no-results, .xb-tm-soft-count').remove();

        $.ajax({
            url: xbTmSoft.ajaxurl + '/query',
            method: 'POST',
            headers: {
                'X-WP-Nonce': xbTmSoft.nonce
            },
            data: {
                keyword: keyword,
                frontend_page_no: pageNo
            },
            success: function(response) {
                $('#xb-tm-soft-loading').hide();
                renderResults(response);
                updateRemainingQueries(); // 分页查询后也更新剩余次数
            },
            error: function(xhr) {
                $('#xb-tm-soft-loading').hide();
                var errorData = xhr.responseJSON || {};
                var errorCode = errorData.code || 999;
                var errorMsg = errorMessages[errorCode] || '查询失败，请稍后再试';
                $('#xb-tm-soft-results').append('<div class="xb-tm-soft-error">' + errorMsg + '</div>');
                //console.error('Pagination Error:', xhr.responseText);
            }
        });
    });

    // 快速登录按钮点击事件
    $('.xb-tm-soft-login-btn').on('click', function(e) {
        e.preventDefault();
        // 找到主题的登录按钮并触发点击
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            // 如果找不到主题按钮，跳转到登录页面
            window.location.href = $(this).attr('data-href');
        }
    });

    // 渲染查询结果
    function renderResults(response) {
        //console.log('Query Response:', response);

        if (response.code !== 200) {
            var errorCode = response.code || 999;
            var errorMsg = errorMessages[errorCode] || response.msg || '查询失败，请稍后再试';
            $('#xb-tm-soft-results').append('<div class="xb-tm-soft-error">' + errorMsg + '</div>');
            return;
        }

        var data = response.data;
        var results = data.items || [];
        var page = data.page || {};
        var pageSize = page.pageSize || 10;
        var totalRecords = page.recordCount || 0;
        var currentPage = page.pageNo || 1;
        var totalPages = Math.ceil(totalRecords / pageSize);

        // 显示查询结果总数
        $('#xb-tm-soft-results').append('<div class="xb-tm-soft-count">共查询到 ' + totalRecords + ' 条结果</div>');

        if (!Array.isArray(results) || results.length === 0) {
            $('#xb-tm-soft-results').append('<div class="xb-tm-soft-no-results">无查询结果</div>');
            return;
        }

        // 渲染卡片式布局
        var cardContainer = $('<div class="xb-tm-soft-card-container"></div>');

        $.each(results, function(i, item) {
            var card = $('<div class="xb-tm-soft-card"></div>');
            card.append('<h3>' + (item.Name || '-') + '</h3>');
            card.append('<p><strong>软件简称：</strong>' + (item.ShortName || '-') + '</p>');
            card.append('<p><strong>著作权人：</strong>' + (item.Owner || '-') + '</p>');
            card.append('<p><strong>分类号：</strong>' + (item.Category || '-') + '</p>');
            card.append('<p><strong>登记号：</strong>' + (item.RegisterNo || '-') + '</p>');
            card.append('<p><strong>登记批准日期：</strong>' + (item.RegisterAperDate || '-') + '</p>');
            card.append('<p><strong>发布日期：</strong>' + (item.PublishDate || '-') + '</p>');
            card.append('<p><strong>版本号：</strong>' + (item.VersionNo || '-') + '</p>');
            cardContainer.append(card);
        });

        $('#xb-tm-soft-results').append(cardContainer);

        // 渲染分页
        if (totalPages > 1) {
            var pagination = $('<div class="xb-tm-soft-pagination"></div>');

            // 上一页
            if (currentPage > 1) {
                pagination.append('<a href="#" class="xb-tm-soft-page-link" data-page="' + (currentPage - 1) + '">上一页</a>');
            }

            // 页码
            var startPage = Math.max(1, currentPage - 2);
            var endPage = Math.min(totalPages, currentPage + 2);
            if (startPage > 1) {
                pagination.append('<a href="#" class="xb-tm-soft-page-link" data-page="1">1</a>');
                if (startPage > 2) pagination.append('<span>...</span>');
            }
            for (var i = startPage; i <= endPage; i++) {
                if (i === currentPage) {
                    pagination.append('<span class="xb-tm-soft-page-current">' + i + '</span>');
                } else {
                    pagination.append('<a href="#" class="xb-tm-soft-page-link" data-page="' + i + '">' + i + '</a>');
                }
            }
            if (endPage < totalPages) {
                if (endPage < totalPages - 1) pagination.append('<span>...</span>');
                pagination.append('<a href="#" class="xb-tm-soft-page-link" data-page="' + totalPages + '">' + totalPages + '</a>');
            }

            // 下一页
            if (currentPage < totalPages) {
                pagination.append('<a href="#" class="xb-tm-soft-page-link" data-page="' + (currentPage + 1) + '">下一页</a>');
            }

            $('#xb-tm-soft-results').append(pagination);
        }
    }

    // 页面加载时初始化剩余查询次数
    updateRemainingQueries();
});