/**
 * 生成唯一会话ID
 */
function generateSessionKey() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        const r = Math.random() * 16 | 0;
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
}

/**
 * 查询历史管理
 */
const xbExpressHistory = {
    get: () => JSON.parse(localStorage.getItem('xb_express_history') || '[]'),
    add: (company_code, company_name, number, phone) => {
        let history = xbExpressHistory.get();
        history = history.filter(item => item.number !== number || item.company_code !== company_code);
        history.unshift({ company_code, company_name, number, phone, timestamp: Date.now() });
        localStorage.setItem('xb_express_history', JSON.stringify(history.slice(0, 10)));
    },
    render: () => {
        const list = document.getElementById('xb_express_history_list');
        list.innerHTML = '';
        xbExpressHistory.get().forEach(item => {
            const div = document.createElement('div');
            div.className = 'xb_express_history_item';
            div.textContent = `${item.company_name} - ${item.number}${item.phone ? ` (${item.phone})` : ''} (${new Date(item.timestamp).toLocaleString()})`;
            div.onclick = () => {
                document.getElementById('xb_express_company').value = item.company_code;
                document.getElementById('xb_express_number').value = item.number;
                document.getElementById('xb_express_phone').value = item.phone || '';
                xbExpressQuery(item.company_code, item.company_name);
            };
            list.appendChild(div);
        });
    }
};

/**
 * 显示消息
 */
function showMessage(message, type = 'error') {
    const messageDiv = document.getElementById('xb_express_message');
    messageDiv.textContent = message;
    messageDiv.className = `xb_express_message ${type}`;
    messageDiv.style.display = 'block';
    setTimeout(() => {
        messageDiv.style.display = 'none';
    }, 5000);
}

/**
 * 查询函数
 */
function xbExpressQuery(company_code, company_name) {
    const company = company_code || document.getElementById('xb_express_company').value;
    const number = document.getElementById('xb_express_number').value.trim();
    const phone = document.getElementById('xb_express_phone').value.trim();
    const submitButton = document.getElementById('xb_express_submit');
    const sessionKey = generateSessionKey();

    // 验证快递单号
    if (!number) {
        showMessage('请输入快递单号');
        return;
    }

    if (!/^[A-Za-z0-9]+$/.test(number)) {
        showMessage('快递单号仅支持字母和数字');
        return;
    }

    if (number.length < 6 || number.length > 32) {
        showMessage('快递单号长度必须在6-32位之间');
        return;
    }

    // 验证手机号（如果填写）
    if (phone && !/^[0-9\-]{0,20}$/.test(phone)) {
        showMessage('手机号格式不正确，仅支持数字和连字符');
        return;
    }

    submitButton.disabled = true;

    const performQuery = (com, com_name) => {
        jQuery.ajax({
            url: xbExpress.ajaxUrl,
            method: 'POST',
            data: {
                action: 'xb_express_query',
                nonce: xbExpress.nonce,
                company: com,
                number: number,
                phone: phone,
                company_name: com_name,
                session_key: sessionKey
            },
            success: response => {
                const resultDiv = document.getElementById('xb_express_result');
                if (response.success) {
                    xbExpressHistory.add(com, com_name, number, phone);
                    xbExpressHistory.render();
                    
                    resultDiv.style.display = 'block';
                    resultDiv.innerHTML = `
                        <div class="xb_express_result_title">查询结果 - ${sanitizeHTML(response.data.nu)}</div>
                        <p>状态: ${sanitizeHTML(response.data.state)}</p>
                        ${response.data.data.map(item => `
                            <div class="xb_express_result_item">
                                <p><strong>${sanitizeHTML(item.ftime)}</strong>: ${sanitizeHTML(item.context)}</p>
                                <p>状态: ${sanitizeHTML(item.status)} (${sanitizeHTML(item.statusCode)})</p>
                                ${item.areaName ? `<p>地点: ${sanitizeHTML(item.areaName)}</p>` : ''}
                            </div>
                        `).join('')}
                    `;
                    showMessage('查询成功', 'success');
                } else {
                    resultDiv.style.display = 'block';
                    resultDiv.innerHTML = `<p style="color: red;">${sanitizeHTML(response.data.message)}</p>`;
                    showMessage(response.data.message);
                }
            },
            error: () => {
                document.getElementById('xb_express_result').style.display = 'block';
                document.getElementById('xb_express_result').innerHTML = '<p style="color: red;">查询失败，请稍后重试</p>';
                showMessage('查询失败，请稍后重试');
            },
            complete: () => {
                submitButton.disabled = false;
            }
        });
    };

    if (company === 'auto') {
        jQuery.ajax({
            url: xbExpress.ajaxUrl,
            method: 'POST',
            data: {
                action: 'xb_express_auto_detect',
                nonce: xbExpress.nonce,
                number: number
            },
            success: response => {
                if (response.success) {
                    performQuery(response.data.company_code, response.data.company_name);
                } else {
                    showMessage(response.data.message);
                    submitButton.disabled = false;
                }
            },
            error: () => {
                showMessage('快递公司识别失败');
                submitButton.disabled = false;
            }
        });
    } else {
        const selectedOption = document.querySelector(`#xb_express_company option[value="${company}"]`);
        performQuery(company, selectedOption ? selectedOption.textContent : '');
    }
}

/**
 * HTML安全过滤
 */
function sanitizeHTML(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

/**
 * 初始化
 */
jQuery(document).ready(() => {
    const numberInput = document.getElementById('xb_express_number');
    numberInput.addEventListener('input', () => {
        numberInput.value = numberInput.value.replace(/[^A-Za-z0-9]/g, '');
    });

    const phoneInput = document.getElementById('xb_express_phone');
    phoneInput.addEventListener('input', () => {
        phoneInput.value = phoneInput.value.replace(/[^0-9\-]/g, '');
    });
    
    document.getElementById('xb_express_submit').onclick = () => xbExpressQuery();
    xbExpressHistory.render();
});