<?php
/**
 * Plugin Name: 小半快递物流查询
 * Description: 基于快递100 API的快递物流查询插件
 * Version: 1.1.1
 * Author: Summer
 */

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 定义插件常量
 */
define('XB_EXPRESS_VERSION', '1.1.1');
define('XB_EXPRESS_PATH', plugin_dir_path(__FILE__));
define('XB_EXPRESS_URL', plugin_dir_url(__FILE__));

/**
 * 插件激活时执行
 */
register_activation_hook(__FILE__, 'xb_express_activate');
function xb_express_activate() {
    xb_express_create_table();
    xb_express_create_front_page();
}

/**
 * 插件加载时检查并更新数据库表结构
 */
add_action('plugins_loaded', 'xb_express_update_db_check');
function xb_express_update_db_check() {
    if (get_option('xb_express_db_version') !== XB_EXPRESS_VERSION) {
        xb_express_create_table();
        update_option('xb_express_db_version', XB_EXPRESS_VERSION);
    }
}

/**
 * 创建或更新数据表
 */
function xb_express_create_table() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 快递公司表
    $table_companies = $wpdb->prefix . 'xb_express_companies';
    $sql_companies = "CREATE TABLE $table_companies (
        id bigint(20) NOT NULL auto_increment,
        company_name varchar(100) NOT NULL,
        company_code varchar(50) NOT NULL,
        company_type varchar(50) NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // 查询记录表，新增 phone 字段存储手机号
    $table_queries = $wpdb->prefix . 'xb_express_queries';
    $sql_queries = "CREATE TABLE $table_queries (
        id bigint(20) NOT NULL auto_increment,
        user_ip varchar(45) NOT NULL,
        company_code varchar(50) NOT NULL,
        company_name varchar(100) NOT NULL,
        tracking_number varchar(32) NOT NULL,
        phone varchar(20) DEFAULT NULL,
        query_time datetime NOT NULL,
        response_code varchar(10) DEFAULT NULL,
        response_message varchar(255) DEFAULT NULL,
        PRIMARY KEY (id),
        KEY idx_user_ip (user_ip),
        KEY idx_tracking_number (tracking_number)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql_companies);
    dbDelta($sql_queries);

    // 手动检查并添加 phone 字段（如果 dbDelta 未成功添加）
    $phone_column_exists = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM `$table_queries` LIKE %s", 'phone'));
    if (empty($phone_column_exists)) {
        $wpdb->query("ALTER TABLE `$table_queries` ADD COLUMN phone varchar(20) DEFAULT NULL AFTER tracking_number");
    }

    // 插入默认快递公司数据（仅当表为空时）
    $existing_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_companies");
    if ($existing_count == 0) {
        $default_companies = [
            ['name' => '圆通速递', 'code' => 'yuantong', 'type' => '国内运输商'],
            ['name' => '中通快递', 'code' => 'zhongtong', 'type' => '国内运输商'],
            ['name' => '韵达快递', 'code' => 'yunda', 'type' => '国内运输商'],
            ['name' => '顺丰速运', 'code' => 'shunfeng', 'type' => '国际运输商'],
            ['name' => '申通快递', 'code' => 'shentong', 'type' => '国内运输商'],
            ['name' => '极兔速递', 'code' => 'jtexpress', 'type' => '国内运输商'],
            ['name' => '邮政快递包裹', 'code' => 'youzhengguonei', 'type' => '国际邮政'],
            ['name' => '京东物流', 'code' => 'jd', 'type' => '国内运输商'],
            ['name' => 'EMS', 'code' => 'ems', 'type' => '国际邮政'],
            ['name' => '德邦快递', 'code' => 'debangkuaidi', 'type' => '国内运输商'],
            ['name' => '邮政电商标快', 'code' => 'youzhengdsbk', 'type' => '国内运输商'],
            ['name' => '邮政标准快递', 'code' => 'youzhengbk', 'type' => '国内运输商'],
        ];

        foreach ($default_companies as $company) {
            $wpdb->insert(
                $table_companies,
                [
                    'company_name' => sanitize_text_field($company['name']),
                    'company_code' => sanitize_text_field($company['code']),
                    'company_type' => sanitize_text_field($company['type']),
                ],
                ['%s', '%s', '%s']
            );
        }
    }
}

/**
 * 创建前台查询页面
 */
function xb_express_create_front_page() {
    $query = new WP_Query([
        'post_type' => 'page',
        'post_status' => 'publish',
        's' => '[xb_express_query]',
        'posts_per_page' => 1
    ]);

    if (!$query->have_posts()) {
        wp_insert_post([
            'post_title' => '物流快递查询',
            'post_name' => 'express-query',
            'post_content' => '[xb_express_query]',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        ]);
    }
}

/**
 * 加载前端资源
 */
add_action('wp_enqueue_scripts', 'xb_express_enqueue_assets');
function xb_express_enqueue_assets() {
    global $post;
    
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_express_query')) {
        wp_enqueue_style('xb-express-style', XB_EXPRESS_URL . 'xb-express.css', [], XB_EXPRESS_VERSION);
        wp_enqueue_script('xb-express-script', XB_EXPRESS_URL . 'xb-express.js', ['jquery'], XB_EXPRESS_VERSION, true);
        wp_localize_script('xb-express-script', 'xbExpress', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('xb_express_nonce'),
        ]);
    }
}

/**
 * 注册短代码
 */
add_shortcode('xb_express_query', 'xb_express_query_shortcode');
function xb_express_query_shortcode() {
    ob_start();
    ?>
    <div class="xb_express_container">
        <div class="xb_express_title">快递物流查询</div>
        <div class="xb_express_form">
            <div class="xb_express_form_group">
                <label class="xb_express_label" for="xb_express_company">快递公司</label>
                <select id="xb_express_company" class="xb_express_select">
                    <option value="auto" selected>自动识别</option>
                    <?php
                    global $wpdb;
                    $table_name = $wpdb->prefix . 'xb_express_companies';
                    $companies = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name ORDER BY company_name"));
                    foreach ($companies as $company) {
                        printf('<option value="%s">%s</option>', 
                            esc_attr($company->company_code), 
                            esc_html($company->company_name)
                        );
                    }
                    ?>
                </select>
            </div>
            <div class="xb_express_form_group xb_express_form_group_input">
                <label class="xb_express_label" for="xb_express_number">快递单号</label>
                <input type="text" id="xb_express_number" class="xb_express_input" placeholder="请输入快递单号" maxlength="32" pattern="[A-Za-z0-9]+">
            </div>
            <div class="xb_express_form_group xb_express_form_group_input">
                <label class="xb_express_label" for="xb_express_phone">手机号(<span style="color: #ff0000">仅顺丰必填/其他可不用</span>)</label>
                <input type="text" id="xb_express_phone" class="xb_express_input" placeholder="顺丰请输入手机号后四位" maxlength="20" pattern="[0-9\-]+">
            </div>
            <button id="xb_express_submit" class="xb_express_button">查询</button>
        </div>
        <div id="xb_express_message" class="xb_express_message"></div>
        <div id="xb_express_result" class="xb_express_result"></div>
        <div id="xb_express_history" class="xb_express_history">
            <div class="xb_express_history_title">查询历史</div>
            <div id="xb_express_history_list" class="xb_express_history_list"></div>
        </div>
        <div id="xb_express_announcement" class="xb_express_announcement">
            <?php echo wp_kses_post(get_option('xb_express_announcement', '')); ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * 后台设置页面
 */
add_action('admin_menu', 'xb_express_admin_menu');
function xb_express_admin_menu() {
    add_menu_page(
        '物流查询设置',
        '物流查询',
        'manage_options',
        'xb-express-settings',
        'xb_express_settings_page',
        'dashicons-location',
        80
    );
    add_submenu_page(
        'xb-express-settings',
        '查询记录',
        '查询记录',
        'manage_options',
        'xb-express-queries',
        'xb_express_queries_page'
    );
}

function xb_express_settings_page() {
    global $wpdb;
    $message = '';
    $message_class = '';
    $edit_company = null;

    // 处理添加快递公司
    if (isset($_POST['xb_express_company_nonce']) && wp_verify_nonce($_POST['xb_express_company_nonce'], 'xb_express_add_company')) {
        $name = sanitize_text_field($_POST['company_name']);
        $code = sanitize_text_field($_POST['company_code']);
        $type = sanitize_text_field($_POST['company_type']);

        if (empty($name) || empty($code) || empty($type)) {
            $message = '所有字段均为必填';
            $message_class = 'error';
        } else {
            $table_name = $wpdb->prefix . 'xb_express_companies';
            $wpdb->insert(
                $table_name,
                [
                    'company_name' => $name,
                    'company_code' => $code,
                    'company_type' => $type,
                ],
                ['%s', '%s', '%s']
            );
            $message = '快递公司添加成功';
            $message_class = 'success';
        }
    }

    // 处理编辑快递公司
    if (isset($_POST['xb_express_edit_company_nonce']) && wp_verify_nonce($_POST['xb_express_edit_company_nonce'], 'xb_express_edit_company')) {
        $id = intval($_POST['company_id']);
        $name = sanitize_text_field($_POST['company_name']);
        $code = sanitize_text_field($_POST['company_code']);
        $type = sanitize_text_field($_POST['company_type']);

        if (empty($name) || empty($code) || empty($type)) {
            $message = '所有字段均为必填';
            $message_class = 'error';
        } else {
            $table_name = $wpdb->prefix . 'xb_express_companies';
            $wpdb->update(
                $table_name,
                [
                    'company_name' => $name,
                    'company_code' => $code,
                    'company_type' => $type,
                ],
                ['id' => $id],
                ['%s', '%s', '%s'],
                ['%d']
            );
            $message = '快递公司更新成功';
            $message_class = 'success';
        }
    }

    // 处理保存公告
    if (isset($_POST['xb_express_save_settings_nonce']) && wp_verify_nonce($_POST['xb_express_save_settings_nonce'], 'xb_express_save_settings')) {
        update_option('xb_express_api_url', esc_url_raw($_POST['xb_express_api_url']));
        update_option('xb_express_api_key', sanitize_text_field($_POST['xb_express_api_key']));
        update_option('xb_express_api_customer', sanitize_text_field($_POST['xb_express_api_customer']));
        update_option('xb_express_query_frequency', absint($_POST['xb_express_query_frequency']));
        update_option('xb_express_user_limit', absint($_POST['xb_express_user_limit']));
        update_option('xb_express_announcement', wp_kses_post($_POST['xb_express_announcement']));
        $message = '设置保存成功';
        $message_class = 'success';
    }

    // 处理删除快递公司
    if (isset($_GET['action']) && $_GET['action'] === 'delete_company' && isset($_GET['id']) && isset($_GET['nonce'])) {
        $id = intval($_GET['id']);
        if (wp_verify_nonce($_GET['nonce'], 'xb_express_delete_company_' . $id)) {
            $table_name = $wpdb->prefix . 'xb_express_companies';
            $wpdb->delete($table_name, ['id' => $id], ['%d']);
            $message = '快递公司删除成功';
            $message_class = 'success';
        } else {
            $message = '删除失败，无效的请求';
            $message_class = 'error';
        }
    }

    // 获取编辑的公司数据
    if (isset($_GET['action']) && $_GET['action'] === 'edit_company' && isset($_GET['id']) && isset($_GET['nonce'])) {
        $id = intval($_GET['id']);
        if (wp_verify_nonce($_GET['nonce'], 'xb_express_edit_company_' . $id)) {
            $table_name = $wpdb->prefix . 'xb_express_companies';
            $edit_company = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
            if (!$edit_company) {
                $message = '公司不存在';
                $message_class = 'error';
            }
        } else {
            $message = '无效的编辑请求';
            $message_class = 'error';
        }
    }

    ?>
    <div class="wrap">
        <h1>物流查询插件设置</h1>
        <?php if ($message) : ?>
            <div class="notice notice-<?php echo esc_attr($message_class); ?> is-dismissible" data-timeout="3000">
                <p><?php echo esc_html($message); ?></p>
            </div>
        <?php endif; ?>
        <form method="post" action="">
            <?php wp_nonce_field('xb_express_save_settings', 'xb_express_save_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_express_api_url">API 请求地址</label></th>
                    <td><input type="text" name="xb_express_api_url" id="xb_express_api_url" value="<?php echo esc_attr(get_option('xb_express_api_url', 'https://poll.kuaidi100.com/poll/query.do')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_express_api_key">API 密钥</label></th>
                    <td><input type="text" name="xb_express_api_key" id="xb_express_api_key" value="<?php echo esc_attr(get_option('xb_express_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_express_api_customer">客户授权码</label></th>
                    <td><input type="text" name="xb_express_api_customer" id="xb_express_api_customer" value="<?php echo esc_attr(get_option('xb_express_api_customer')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_express_query_frequency">单号查询间隔（秒）</label></th>
                    <td>
                        <input type="number" name="xb_express_query_frequency" id="xb_express_query_frequency" value="<?php echo esc_attr(get_option('xb_express_query_frequency', 1800)); ?>" class="regular-text" min="1800">
                        <p class="description">设置相同单号的最小查询间隔时间（秒），建议不低于1800秒（30分钟）</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_express_user_limit">每小时用户查询限制</label></th>
                    <td>
                        <input type="number" name="xb_express_user_limit" id="xb_express_user_limit" value="<?php echo esc_attr(get_option('xb_express_user_limit', 5)); ?>" class="regular-text" min="1">
                        <p class="description">设置每小时内每个用户的最大查询次数</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_express_announcement">公告内容</label></th>
                    <td>
                        <textarea name="xb_express_announcement" id="xb_express_announcement" class="large-text" rows="6"><?php echo esc_textarea(get_option('xb_express_announcement', '')); ?></textarea>
                        <p class="description">支持HTML格式的公告内容，将显示在查询页面底部</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('保存设置'); ?>
        </form>
        <p>基于快递100的接口: https://api.kuaidi100.com/document/5f0ffb5ebc8da837cbd8aefc</p>
        <h2>快递公司管理</h2>
        <form method="post" action="">
            <input type="hidden" name="company_id" value="<?php echo esc_attr($edit_company ? $edit_company->id : ''); ?>">
            <input type="text" id="xb_express_company_name" name="company_name" placeholder="快递公司名称" value="<?php echo esc_attr($edit_company ? $edit_company->company_name : ''); ?>" required>
            <input type="text" id="xb_express_company_code" name="company_code" placeholder="快递公司编码" value="<?php echo esc_attr($edit_company ? $edit_company->company_code : ''); ?>" required>
            <select id="xb_express_company_type" name="company_type" required>
                <option value="国内运输商" <?php selected($edit_company && $edit_company->company_type === '国内运输商'); ?>>国内运输商</option>
                <option value="国际运输商" <?php selected($edit_company && $edit_company->company_type === '国际运输商'); ?>>国际运输商</option>
                <option value="国际邮政" <?php selected($edit_company && $edit_company->company_type === '国际邮政'); ?>>国际邮政</option>
            </select>
            <button type="submit" class="button button-primary"><?php echo $edit_company ? '更新快递公司' : '添加快递公司'; ?></button>
            <?php if ($edit_company) : ?>
                <a href="<?php echo esc_url(admin_url('admin.php?page=xb-express-settings')); ?>" class="button">取消</a>
                <?php wp_nonce_field('xb_express_edit_company', 'xb_express_edit_company_nonce'); ?>
            <?php else : ?>
                <?php wp_nonce_field('xb_express_add_company', 'xb_express_company_nonce'); ?>
            <?php endif; ?>
        </form>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>公司名称</th>
                    <th>公司编码</th>
                    <th>公司类型</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $table_name = $wpdb->prefix . 'xb_express_companies';
                $companies = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name ORDER BY company_name"));
                foreach ($companies as $company) {
                    $delete_url = add_query_arg([
                        'action' => 'delete_company',
                        'id' => $company->id,
                        'nonce' => wp_create_nonce('xb_express_delete_company_' . $company->id)
                    ], admin_url('admin.php?page=xb-express-settings'));
                    $edit_url = add_query_arg([
                        'action' => 'edit_company',
                        'id' => $company->id,
                        'nonce' => wp_create_nonce('xb_express_edit_company_' . $company->id)
                    ], admin_url('admin.php?page=xb-express-settings'));
                    printf(
                        '<tr><td>%s</td><td>%s</td><td>%s</td><td><a href="%s">编辑</a> | <a href="%s" onclick="return confirm(\'确定要删除吗？\');">删除</a></td></tr>',
                        esc_html($company->company_name),
                        esc_html($company->company_code),
                        esc_html($company->company_type),
                        esc_url($edit_url),
                        esc_url($delete_url)
                    );
                }
                ?>
            </tbody>
        </table>
    </div>
    <script>
        jQuery(document).ready(function($) {
            $('.notice.is-dismissible').each(function() {
                const $this = $(this);
                const timeout = $this.data('timeout') || 3000;
                setTimeout(function() {
                    $this.fadeOut(400, function() {
                        $this.remove();
                    });
                }, timeout);
            });
        });
    </script>
    <?php
}

function xb_express_queries_page() {
    global $wpdb;
    $message = '';
    $message_class = '';

    // 处理删除单条查询记录
    if (isset($_GET['action']) && $_GET['action'] === 'delete_query' && isset($_GET['id']) && isset($_GET['nonce'])) {
        $id = intval($_GET['id']);
        if (wp_verify_nonce($_GET['nonce'], 'xb_express_delete_query_' . $id)) {
            $table_name = $wpdb->prefix . 'xb_express_queries';
            $wpdb->delete($table_name, ['id' => $id], ['%d']);
            $message = '查询记录删除成功';
            $message_class = 'success';
        } else {
            $message = '删除失败，无效的请求';
            $message_class = 'error';
        }
    }

    // 处理删除所有查询记录
    if (isset($_POST['xb_express_delete_all_nonce']) && wp_verify_nonce($_POST['xb_express_delete_all_nonce'], 'xb_express_delete_all_queries')) {
        $table_name = $wpdb->prefix . 'xb_express_queries';
        $wpdb->query("TRUNCATE TABLE $table_name");
        $message = '所有查询记录已删除';
        $message_class = 'success';
    }

    $table_name = $wpdb->prefix . 'xb_express_queries';
    $per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;

    $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $total_pages = ceil($total_items / $per_page);

    $queries = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name ORDER BY query_time DESC LIMIT %d OFFSET %d",
        $per_page,
        $offset
    ));

    // 定义信息代码描述
    $response_codes = [
        '200' => '查询成功',
        '400' => '找不到对应公司',
        '408' => '快递公司参数异常：验证码错误',
        '500' => '查询无结果，请隔段时间再查',
        '501' => '服务器错误',
        '502' => '服务器繁忙',
        '503' => '验证签名失败',
        '601' => 'key已过期'
    ];

    ?>
    <div class="wrap">
        <h1>查询记录</h1>
        <?php if ($message) : ?>
            <div class="notice notice-<?php echo esc_attr($message_class); ?> is-dismissible" data-timeout="3000">
                <p><?php echo esc_html($message); ?></p>
            </div>
        <?php endif; ?>
        <form method="post" action="">
            <button type="submit" class="button button-danger" onclick="return confirm('确定要删除所有查询记录吗？');">删除所有记录</button>
            <?php wp_nonce_field('xb_express_delete_all_queries', 'xb_express_delete_all_nonce'); ?>
        </form>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>IP地址</th>
                    <th>快递公司</th>
                    <th>快递单号</th>
                    <th>手机号</th>
                    <th>查询时间</th>
                    <th>信息代码</th>
                    <th>信息内容描述</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($queries) {
                    foreach ($queries as $query) {
                        $delete_url = add_query_arg([
                            'action' => 'delete_query',
                            'id' => $query->id,
                            'nonce' => wp_create_nonce('xb_express_delete_query_' . $query->id)
                        ], admin_url('admin.php?page=xb-express-queries'));
                        printf(
                            '<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td><a href="%s" onclick="return confirm(\'确定要删除吗？\');">删除</a></td></tr>',
                            esc_html($query->user_ip),
                            esc_html($query->company_name),
                            esc_html($query->tracking_number),
                            esc_html($query->phone ?? ''),
                            esc_html($query->query_time),
                            esc_html($query->response_code ?? ''),
                            esc_html($query->response_message ?? ''),
                            esc_url($delete_url)
                        );
                    }
                } else {
                    echo '<tr><td colspan="8">暂无查询记录</td></tr>';
                }
                ?>
            </tbody>
        </table>
        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links([
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $current_page,
            ]);
            echo '</div></div>';
        }
        ?>
        <h2>信息代码说明</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>信息代码</th>
                    <th>信息内容描述</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($response_codes as $code => $description) {
                    printf(
                        '<tr><td>%s</td><td>%s</td></tr>',
                        esc_html($code),
                        esc_html($description)
                    );
                }
                ?>
            </tbody>
        </table>
    </div>
    <script>
        jQuery(document).ready(function($) {
            $('.notice.is-dismissible').each(function() {
                const $this = $(this);
                const timeout = $this.data('timeout') || 3000;
                setTimeout(function() {
                    $this.fadeOut(400, function() {
                        $this.remove();
                    });
                }, timeout);
            });
        });
    </script>
    <?php
}

/**
 * 注册设置
 */
add_action('admin_init', 'xb_express_register_settings');
function xb_express_register_settings() {
    register_setting('xb_express_settings', 'xb_express_api_url', ['sanitize_callback' => 'esc_url_raw']);
    register_setting('xb_express_settings', 'xb_express_api_key', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('xb_express_settings', 'xb_express_api_customer', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('xb_express_settings', 'xb_express_query_frequency', [
        'sanitize_callback' => 'absint',
        'default' => 1800
    ]);
    register_setting('xb_express_settings', 'xb_express_user_limit', [
        'sanitize_callback' => 'absint',
        'default' => 5
    ]);
    register_setting('xb_express_settings', 'xb_express_announcement', [
        'sanitize_callback' => 'wp_kses_post'
    ]);

    add_settings_section('xb_express_main', 'API 设置', null, 'xb_express_settings');
    add_settings_field('xb_express_api_url', 'API 请求地址', 'xb_express_api_url_callback', 'xb_express_settings', 'xb_express_main');
    add_settings_field('xb_express_api_key', 'API 密钥', 'xb_express_api_key_callback', 'xb_express_settings', 'xb_express_main');
    add_settings_field('xb_express_api_customer', '客户授权码', 'xb_express_api_customer_callback', 'xb_express_settings', 'xb_express_main');
    add_settings_field('xb_express_query_frequency', '单号查询间隔（秒）', 'xb_express_query_frequency_callback', 'xb_express_settings', 'xb_express_main');
    add_settings_field('xb_express_user_limit', '每小时用户查询限制', 'xb_express_user_limit_callback', 'xb_express_settings', 'xb_express_main');
    add_settings_field('xb_express_announcement', '公告内容', 'xb_express_announcement_callback', 'xb_express_settings', 'xb_express_main');
}

function xb_express_api_url_callback() {
    $value = get_option('xb_express_api_url', 'https://poll.kuaidi100.com/poll/query.do');
    printf('<input type="text" name="xb_express_api_url" id="xb_express_api_url" value="%s" class="regular-text">', esc_attr($value));
}

function xb_express_api_key_callback() {
    $value = get_option('xb_express_api_key');
    printf('<input type="text" name="xb_express_api_key" id="xb_express_api_key" value="%s" class="regular-text">', esc_attr($value));
}

function xb_express_api_customer_callback() {
    $value = get_option('xb_express_api_customer');
    printf('<input type="text" name="xb_express_api_customer" id="xb_express_api_customer" value="%s" class="regular-text">', esc_attr($value));
}

function xb_express_query_frequency_callback() {
    $value = get_option('xb_express_query_frequency', 1800);
    printf('<input type="number" name="xb_express_query_frequency" id="xb_express_query_frequency" value="%s" class="regular-text" min="1800">', esc_attr($value));
    echo '<p class="description">设置相同单号的最小查询间隔时间（秒），建议不低于1800秒（30分钟）</p>';
}

function xb_express_user_limit_callback() {
    $value = get_option('xb_express_user_limit', 5);
    printf('<input type="number" name="xb_express_user_limit" id="xb_express_user_limit" value="%s" class="regular-text" min="1">', esc_attr($value));
    echo '<p class="description">设置每小时内每个用户的最大查询次数</p>';
}

function xb_express_announcement_callback() {
    $value = get_option('xb_express_announcement', '');
    printf('<textarea name="xb_express_announcement" id="xb_express_announcement" class="large-text" rows="6">%s</textarea>', esc_textarea($value));
    echo '<p class="description">支持HTML格式的公告内容，将显示在查询页面底部</p>';
}

/**
 * AJAX 处理快递公司识别
 */
add_action('wp_ajax_xb_express_auto_detect', 'xb_express_auto_detect_callback');
add_action('wp_ajax_nopriv_xb_express_auto_detect', 'xb_express_auto_detect_callback');
function xb_express_auto_detect_callback() {
    check_ajax_referer('xb_express_nonce', 'nonce');

    $num = sanitize_text_field($_POST['number']);
    $key = get_option('xb_express_api_key');
    
    if (strlen($num) < 6 || strlen($num) > 32) {
        wp_send_json_error(['message' => '快递单号长度必须在6-32位之间']);
    }

    if (!preg_match('/^[A-Za-z0-9]+$/', $num)) {
        wp_send_json_error(['message' => '快递单号仅支持字母和数字']);
    }

    $api_url = 'http://www.kuaidi100.com/autonumber/auto?num=' . urlencode($num) . '&key=' . urlencode($key);
    
    $response = wp_remote_get($api_url, [
        'timeout' => 10,
        'headers' => [
            'Content-Type' => 'application/x-www-form-urlencoded'
        ]
    ]);

    if (is_wp_error($response)) {
        wp_send_json_error(['message' => '快递公司识别失败']);
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);

    if (!empty($data) && isset($data[0]['comCode'])) {
        wp_send_json_success([
            'company_code' => $data[0]['comCode'],
            'company_name' => $data[0]['name']
        ]);
    } else {
        wp_send_json_error(['message' => $data['message'] ?? '无法识别快递公司']);
    }
}

/**
 * AJAX 处理快递查询
 */
add_action('wp_ajax_xb_express_query', 'xb_express_query_callback');
add_action('wp_ajax_nopriv_xb_express_query', 'xb_express_query_callback');
function xb_express_query_callback() {
    check_ajax_referer('xb_express_nonce', 'nonce');

    global $wpdb;
    $table_queries = $wpdb->prefix . 'xb_express_queries';
    
    $com = sanitize_text_field($_POST['company']);
    $num = sanitize_text_field($_POST['number']);
    $phone = sanitize_text_field($_POST['phone'] ?? '');
    $company_name = sanitize_text_field($_POST['company_name'] ?? '');
    $session_key = sanitize_text_field($_POST['session_key']);
    $user_ip = $_SERVER['REMOTE_ADDR'];

    // 验证快递单号
    if (strlen($num) < 6 || strlen($num) > 32) {
        wp_send_json_error(['message' => '快递单号长度必须在6-32位之间']);
    }

    if (!preg_match('/^[A-Za-z0-9]+$/', $num)) {
        wp_send_json_error(['message' => '快递单号仅支持字母和数字']);
    }

    // 验证手机号（如果填写）
    if ($phone && !preg_match('/^[0-9\-]{0,20}$/', $phone)) {
        wp_send_json_error(['message' => '手机号格式不正确，仅支持数字和连字符']);
    }

    $query_frequency = get_option('xb_express_query_frequency', 1800);
    $user_limit = get_option('xb_express_user_limit', 5);
    
    // 检查用户小时内查询次数
    $user_queries = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_queries 
        WHERE user_ip = %s AND query_time > %s",
        $user_ip,
        date('Y-m-d H:i:s', strtotime('-1 hour'))
    ));
    
    if ($user_queries >= $user_limit) {
        wp_send_json_error(['message' => '您的小时查询次数已达上限，请稍后再试']);
    }

    // 检查会话缓存
    $session_cache = get_transient('xb_express_session_' . $session_key);
    if ($session_cache) {
        wp_send_json_error(['message' => '请勿重复提交查询']);
    }

    // 检查相同单号的查询间隔
    $last_query = $wpdb->get_var($wpdb->prepare(
        "SELECT query_time FROM $table_queries 
        WHERE tracking_number = %s 
        ORDER BY query_time DESC LIMIT 1",
        $num
    ));
    
    if ($last_query && (strtotime('now') - strtotime($last_query)) < $query_frequency) {
        wp_send_json_error(['message' => sprintf('查询频率过高，请%d分钟后再试，同个订单号30分钟内只能查询一次', floor($query_frequency/60))]);
    }

    $key = get_option('xb_express_api_key');
    $customer = get_option('xb_express_api_customer');
    $api_url = get_option('xb_express_api_url', 'https://poll.kuaidi100.com/poll/query.do');

    $param = [
        'com' => $com,
        'num' => $num,
        'resultv2' => '4',
        'show' => '0',
        'order' => 'desc',
        'lang' => 'zh',
    ];

    // 如果填写了手机号，添加到请求参数
    if ($phone) {
        $param['phone'] = $phone;
    }

    $post_data = [
        'customer' => $customer,
        'param' => wp_json_encode($param),
    ];
    $post_data['sign'] = strtoupper(md5($post_data['param'] . $key . $customer));

    $response = wp_remote_post($api_url, [
        'body' => http_build_query($post_data),
        'timeout' => 10,
        'headers' => [
            'Content-Type' => 'application/x-www-form-urlencoded'
        ]
    ]);

    $insert_data = [
        'user_ip' => $user_ip,
        'company_code' => $com,
        'company_name' => $company_name,
        'tracking_number' => $num,
        'phone' => $phone ?: null,
        'query_time' => current_time('mysql'),
        'response_code' => null,
        'response_message' => null,
    ];

    // 检查插入是否成功
    if (is_wp_error($response)) {
        $insert_data['response_code'] = '501';
        $insert_data['response_message'] = 'API请求失败';
        $result = $wpdb->insert($table_queries, $insert_data, ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']);
        if ($result === false) {
            wp_send_json_error(['message' => '记录插入失败：' . $wpdb->last_error]);
        }
        wp_send_json_error(['message' => 'API请求失败']);
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);

    if (isset($data['status']) && $data['status'] === '200') {
        $insert_data['response_code'] = '200';
        $insert_data['response_message'] = '查询成功';
        $result = $wpdb->insert($table_queries, $insert_data, ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']);
        if ($result === false) {
            wp_send_json_error(['message' => '记录插入失败：' . $wpdb->last_error]);
        }
        set_transient('xb_express_session_' . $session_key, true, 60);
        wp_send_json_success($data);
    } else {
        $insert_data['response_code'] = $data['returnCode'] ?? '501';
        $insert_data['response_message'] = $data['message'] ?? '查询失败';
        $result = $wpdb->insert($table_queries, $insert_data, ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']);
        if ($result === false) {
            wp_send_json_error(['message' => '记录插入失败：' . $wpdb->last_error]);
        }
        set_transient('xb_express_session_' . $session_key, true, 60);
        wp_send_json_error(['message' => $data['message'] ?? '查询失败']);
    }
}
?>