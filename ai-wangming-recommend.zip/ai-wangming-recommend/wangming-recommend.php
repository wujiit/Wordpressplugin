<?php
/*
Plugin Name: AI网名推荐
Description: 基于通义千问API的WordPress网名推荐插件，支持联网搜索
Version: 1.0.0
Author: summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 创建数据库表
function wangming_create_database() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'wangming_records';
    $charset_collate = $wpdb->get_charset_collate();

    // 创建记录表，用于存储用户使用记录
    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        usage_date date NOT NULL,
        total_count int DEFAULT 0,
        success_count int DEFAULT 0,
        custom_limit int DEFAULT NULL,
        input_content text NOT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        INDEX user_date_index (user_id, usage_date)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// 创建前台页面
function wangming_create_frontend_page() {
    // 检查是否已存在包含短代码的页面
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[wangming_shortcode]',
        'numberposts' => 1,
    ));

    // 如果不存在，则创建新页面
    if (empty($pages)) {
        wp_insert_post(array(
            'post_title'    => 'AI网名推荐',
            'post_name'     => 'ai-wangming-recommend',
            'post_content'  => '[wangming_shortcode]',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        ));
    }
}

// 加载前台资源
function wangming_load_resources() {
    // 确保 jQuery 加载
    wp_enqueue_script('jquery');
    
    // 加载 CSS
    $css_path = plugin_dir_path(__FILE__) . 'wangming-recommend.css';
    if (file_exists($css_path)) {
        wp_enqueue_style(
            'wangming_styles',
            plugin_dir_url(__FILE__) . 'wangming-recommend.css',
            array(),
            '1.0.0'
        );
    }

    // 加载 JS
    $js_path = plugin_dir_path(__FILE__) . 'wangming-recommend.js';
    if (file_exists($js_path)) {
        wp_enqueue_script(
            'wangming_script',
            plugin_dir_url(__FILE__) . 'wangming-recommend.js',
            array('jquery'),
            '1.0.0',
            true
        );
    }

    // 传递数据给 JS
    $models = array_map('trim', explode(',', get_option('wangming_models', 'qwen-plus')));
    wp_localize_script('wangming_script', 'WangmingData', array(
        'rest_url' => esc_url_raw(rest_url('wangming/v1/recommend')),
        'nonce' => wp_create_nonce('wp_rest'),
        'ajax_url' => admin_url('admin-ajax.php'),
        'forbidden_words' => array_filter(array_map('trim', explode(',', get_option('wangming_forbidden_words', '')))),
        'default_model' => !empty($models) ? $models[0] : 'qwen-plus'
    ));
}

// 动态加载前端资源
add_action('wp_enqueue_scripts', function() {
    global $post;
    if (is_a($post, 'WP_Post') && (has_shortcode($post->post_content, 'wangming_shortcode') || is_page('ai-wangming-recommend'))) {
        wangming_load_resources();
    }
});

// 注册激活钩子
register_activation_hook(__FILE__, 'wangming_create_database');
register_activation_hook(__FILE__, 'wangming_create_frontend_page');

// 推荐处理函数
function wangming_recommend_handler(WP_REST_Request $request) {
    global $wpdb;
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = get_option('wangming_daily_limit', 10);
    
    // 获取使用数据
    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT total_count, success_count, custom_limit FROM {$wpdb->prefix}wangming_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));
    
    $total_count = $usage_data ? $usage_data->total_count : 0;
    $success_count = $usage_data ? $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? $usage_data->custom_limit : $default_limit;
    
    // 检查使用限制
    if ($success_count >= $user_limit) {
        echo "data: " . json_encode(array('error' => '今日使用次数已达上限')) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    // 检查违规词
    $forbidden_words = array_filter(array_map('trim', explode(',', get_option('wangming_forbidden_words', ''))));
    $input_data = $request->get_param('data') ?? '';
    
    if (!empty($forbidden_words)) {
        foreach ($forbidden_words as $word) {
            if (stripos($input_data, $word) !== false) {
                echo "data: " . json_encode(array('error' => '输入内容包含违规词“' . esc_html($word) . '”，请重新输入')) . "\n\n";
                ob_flush();
                flush();
                exit;
            }
        }
    }

    // 构造 AI 提示词
    $platform = $request->get_param('platform') ?? '';
    $enable_search = filter_var($request->get_param('enable_search'), FILTER_VALIDATE_BOOLEAN);

    $prompt = "你是一个专业的网名推荐助手，任务是根据用户的需求，推荐10个适合特定平台的网名，并说明每个网名的适用场景或特点。请严格遵循以下要求：\n";
    $prompt .= "1. 推荐的网名必须与用户输入的需求：'{$input_data}' 高度相关。\n";
    $prompt .= "2. 每个推荐的网名需列出网名和具体的适用场景或特点，格式为：\n";
    $prompt .= "- 网名：具体网名\n";
    $prompt .= "  特点：适用场景或特点描述\n\n";
    $prompt .= "3. 推荐的网名必须适合目标平台：{$platform}。\n";
    $prompt .= "4. 推荐10个网名，不多不少。\n";
    if ($enable_search) {
        $prompt .= "5. 在推荐前，请通过全网搜索收集与输入需求和平台相关的信息，确保推荐内容准确、新颖。\n";
    }
    $prompt .= "用户输入的需求：{$input_data}\n";
    $prompt .= "目标平台：{$platform}\n";
    $prompt .= "请按照指定格式提供推荐结果，仅返回网名和特点，其他内容不要输出。";

    // 获取模型参数
    $models = array_map('trim', explode(',', get_option('wangming_models', 'qwen-plus')));
    $enable_model_select = get_option('wangming_enable_model_select', '0');
    $model = $request->get_param('model') ?? '';

    if (!$enable_model_select || empty($model) || !in_array($model, $models)) {
        $model = !empty($models) ? $models[0] : 'qwen-plus';
    }

    // 发起 API 请求
    $api_url = get_option('wangming_api_url', '');
    $api_key = get_option('wangming_api_key', '');
    
    if (empty($api_url) || empty($api_key)) {
        echo "data: " . json_encode(array('error' => 'API地址或密钥未配置')) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    // 更新总尝试次数并保存输入内容
    if ($usage_data) {
        $wpdb->update(
            $wpdb->prefix . 'wangming_records',
            array(
                'total_count' => $total_count + 1,
                'input_content' => $input_data,
                'created_at' => current_time('mysql')
            ),
            array('user_id' => $user_id, 'usage_date' => $today)
        );
    } else {
        $wpdb->insert(
            $wpdb->prefix . 'wangming_records',
            array(
                'user_id' => $user_id,
                'usage_date' => $today,
                'total_count' => 1,
                'success_count' => 0,
                'input_content' => $input_data,
                'created_at' => current_time('mysql')
            )
        );
    }

    // 设置流式响应头
    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no');

    // 使用 cURL 发起请求
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Bearer ' . $api_key,
        'Content-Type: application/json',
        'Accept: text/event-stream'
    ));
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
        'model' => $model,
        'messages' => array(
            array('role' => 'system', 'content' => 'You are a helpful assistant.'),
            array('role' => 'user', 'content' => $prompt)
        ),
        'stream' => true,
        'enable_search' => $enable_search
    )));

    // 流式处理回调
    $has_content = false;
    curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $data) use ($user_id, $today, $success_count, &$has_content) {
        global $wpdb;

        $lines = explode("\n", $data);
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;

            if (strpos($line, 'data: ') === 0) {
                $json_data = trim(substr($line, 6));
                if ($json_data === '[DONE]') {
                    if ($has_content) {
                        $wpdb->update(
                            $wpdb->prefix . 'wangming_records',
                            array('success_count' => $success_count + 1),
                            array('user_id' => $user_id, 'usage_date' => $today)
                        );
                    }
                    echo "data: [DONE]\n\n";
                    ob_flush();
                    flush();
                    return strlen($data);
                }

                $parsed_data = json_decode($json_data, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    error_log('JSON 解析错误: ' . json_last_error_msg() . ' - 数据: ' . $json_data);
                    continue;
                }

                if (isset($parsed_data['choices'][0]['delta']['content'])) {
                    $has_content = true;
                    echo "data: " . json_encode(array('content' => $parsed_data['choices'][0]['delta']['content'])) . "\n\n";
                    ob_flush();
                    flush();
                } elseif (isset($parsed_data['error'])) {
                    echo "data: " . json_encode(array('error' => $parsed_data['error']['message'])) . "\n\n";
                    ob_flush();
                    flush();
                    return strlen($data);
                }
            }
        }
        return strlen($data);
    });

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        echo "data: " . json_encode(array('error' => 'API请求失败: ' . $error)) . "\n\n";
        ob_flush();
        flush();
    } elseif (!$has_content) {
        echo "data: " . json_encode(array('error' => '推荐失败，未收到有效内容')) . "\n\n";
        ob_flush();
        flush();
    }

    curl_close($ch);
    exit;
}

// 注册 REST API 端点
add_action('rest_api_init', function() {
    $namespace = 'wangming/v1';
    $endpoint = '/recommend';
    register_rest_route($namespace, $endpoint, array(
        'methods' => 'POST',
        'callback' => 'wangming_recommend_handler',
        'permission_callback' => function(WP_REST_Request $request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_not_logged_in', '请先登录', array('status' => 401));
            }
            $nonce = $request->get_header('X-WP-Nonce');
            if (!wp_verify_nonce($nonce, 'wp_rest')) {
                return new WP_Error('rest_forbidden', 'Nonce 验证失败', array('status' => 403));
            }
            return true;
        }
    ));

    register_rest_route($namespace, '/usage', array(
        'methods' => 'GET',
        'callback' => 'wangming_get_usage',
        'permission_callback' => function() {
            return is_user_logged_in();
        }
    ));
});

// 获取使用情况
function wangming_get_usage(WP_REST_Request $request) {
    global $wpdb;
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = get_option('wangming_daily_limit', 10);

    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT total_count, success_count, custom_limit FROM {$wpdb->prefix}wangming_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));

    $total_count = $usage_data ? $usage_data->total_count : 0;
    $success_count = $usage_data ? $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? $usage_data->custom_limit : $default_limit;

    return array(
        'remaining' => max(0, $user_limit - $success_count),
        'limit' => $user_limit,
        'total_count' => $total_count,
        'success_count' => $success_count
    );
}

// 后台菜单
function wangming_admin_menu() {
    add_menu_page(
        'AI网名推荐',
        'AI网名推荐',
        'manage_options',
        'wangming-recommend',
        'wangming_settings_page',
        'dashicons-id-alt'
    );
    add_submenu_page(
        'wangming-recommend',
        '用户记录',
        '用户记录',
        'manage_options',
        'wangming-user-records',
        'wangming_user_records_page'
    );
}
add_action('admin_menu', 'wangming_admin_menu');

// 注册设置
function wangming_register_settings() {
    register_setting('wangming_settings', 'wangming_api_url');
    register_setting('wangming_settings', 'wangming_models');
    register_setting('wangming_settings', 'wangming_api_key');
    register_setting('wangming_settings', 'wangming_daily_limit');
    register_setting('wangming_settings', 'wangming_forbidden_words');
    register_setting('wangming_settings', 'wangming_ad_content');
    register_setting('wangming_settings', 'wangming_platforms');
    register_setting('wangming_settings', 'wangming_enable_search');
    register_setting('wangming_settings', 'wangming_enable_model_select');
    register_setting('wangming_settings', 'wangming_enable_usage_display');

    add_settings_section(
        'wangming_main_section',
        'API设置',
        null,
        'wangming_settings'
    );

    add_settings_section(
        'wangming_content_section',
        '内容设置',
        null,
        'wangming_settings'
    );

    add_settings_field(
        'wangming_api_url',
        'API地址',
        'wangming_api_url_field',
        'wangming_settings',
        'wangming_main_section'
    );

    add_settings_field(
        'wangming_models',
        'AI模型',
        'wangming_models_field',
        'wangming_settings',
        'wangming_main_section'
    );

    add_settings_field(
        'wangming_api_key',
        'API密钥',
        'wangming_api_key_field',
        'wangming_settings',
        'wangming_main_section'
    );

    add_settings_field(
        'wangming_daily_limit',
        '每日使用限制',
        'wangming_daily_limit_field',
        'wangming_settings',
        'wangming_main_section'
    );

    add_settings_field(
        'wangming_enable_search',
        '启用联网搜索',
        'wangming_enable_search_field',
        'wangming_settings',
        'wangming_main_section'
    );

    add_settings_field(
        'wangming_enable_model_select',
        '启用前台模型选择',
        'wangming_enable_model_select_field',
        'wangming_settings',
        'wangming_main_section'
    );

    add_settings_field(
        'wangming_enable_usage_display',
        '启用前台使用次数显示',
        'wangming_enable_usage_display_field',
        'wangming_settings',
        'wangming_main_section'
    );

    add_settings_field(
        'wangming_forbidden_words',
        '违规词',
        'wangming_forbidden_words_field',
        'wangming_settings',
        'wangming_content_section'
    );

    add_settings_field(
        'wangming_ad_content',
        '广告内容 (HTML)',
        'wangming_ad_content_field',
        'wangming_settings',
        'wangming_content_section'
    );

    add_settings_field(
        'wangming_platforms',
        '支持平台',
        'wangming_platforms_field',
        'wangming_settings',
        'wangming_content_section'
    );
}
add_action('admin_init', 'wangming_register_settings');

// 设置字段回调函数
function wangming_api_url_field() {
    $value = get_option('wangming_api_url', '');
    echo '<input type="text" name="wangming_api_url" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入API地址 (如 https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions)</p>';
}

function wangming_models_field() {
    $value = get_option('wangming_models', 'qwen-plus');
    echo '<input type="text" name="wangming_models" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入AI模型，用逗号分隔 (如 qwen-plus,qwen-turbo)</p>';
}

function wangming_api_key_field() {
    $value = get_option('wangming_api_key', '');
    echo '<input type="text" name="wangming_api_key" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入您的API密钥</p>';
}

function wangming_daily_limit_field() {
    $value = get_option('wangming_daily_limit', '10');
    echo '<input type="number" name="wangming_daily_limit" value="' . esc_attr($value) . '" min="1" />';
    echo '<p class="description">设置用户默认每日使用限制</p>';
}

function wangming_enable_search_field() {
    $value = get_option('wangming_enable_search', '0');
    echo '<input type="checkbox" name="wangming_enable_search" value="1"' . checked(1, $value, false) . ' />';
    echo '<p class="description">启用后，前台将显示联网搜索开关，用户可选择是否联网搜索</p>';
}

function wangming_enable_model_select_field() {
    $value = get_option('wangming_enable_model_select', '0');
    echo '<input type="checkbox" name="wangming_enable_model_select" value="1"' . checked(1, $value, false) . ' />';
    echo '<p class="description">启用后，前台将显示模型选择下拉框</p>';
}

function wangming_enable_usage_display_field() {
    $value = get_option('wangming_enable_usage_display', '0');
    echo '<input type="checkbox" name="wangming_enable_usage_display" value="1"' . checked(1, $value, false) . ' />';
    echo '<p class="description">启用后，前台将显示实时使用次数</p>';
}

function wangming_forbidden_words_field() {
    $value = get_option('wangming_forbidden_words', '');
    echo '<textarea name="wangming_forbidden_words" rows="5" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">输入违规词，用逗号分隔</p>';
}

function wangming_ad_content_field() {
    $value = get_option('wangming_ad_content', '');
    echo '<textarea name="wangming_ad_content" rows="5" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">输入广告内容 (支持HTML，图片建议尺寸：宽度不超过600px，高度不超过400px)</p>';
}

function wangming_platforms_field() {
    $value = get_option('wangming_platforms', '微信,微博,小红书');
    echo '<input type="text" name="wangming_platforms" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入支持平台，用逗号分隔</p>';
}

// 设置页面
function wangming_settings_page() {
    ?>
    <div class="wrap">
        <h1>AI网名推荐设置</h1>
        <?php
        if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {
            echo '<div id="setting-saved-notice" class="notice notice-success is-dismissible"><p>设置保存成功！</p></div>';
            echo '<script>
                setTimeout(function() {
                    jQuery("#setting-saved-notice").fadeOut();
                }, 3000);
            </script>';
        }
        ?>
        <form method="post" action="options.php">
            <?php
            settings_fields('wangming_settings');
            do_settings_sections('wangming_settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// 用户记录页面
function wangming_user_records_page() {
    global $wpdb;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : (isset($_GET['user_id']) ? intval($_GET['user_id']) : 0);
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $per_page = 20;

    $total_usage = $wpdb->get_var("SELECT SUM(total_count) FROM {$wpdb->prefix}wangming_records");
    $total_success = $wpdb->get_var("SELECT SUM(success_count) FROM {$wpdb->prefix}wangming_records");

    $today = current_time('Y-m-d');
    $today_total_usage = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(total_count) FROM {$wpdb->prefix}wangming_records WHERE usage_date = %s",
        $today
    ));
    $today_total_success = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(success_count) FROM {$wpdb->prefix}wangming_records WHERE usage_date = %s",
        $today
    ));

    $total_all_records = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}wangming_records");
    $all_records = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}wangming_records 
        ORDER BY created_at DESC 
        LIMIT %d OFFSET %d",
        $per_page,
        ($paged - 1) * $per_page
    ));

    ?>
    <div class="wrap">
        <h1>用户记录</h1>
        <h2>使用统计</h2>
        <p>网站总共尝试次数：<?php echo esc_html($total_usage ?: 0); ?> 次，成功次数：<?php echo esc_html($total_success ?: 0); ?> 次</p>
        <p>今日总共尝试次数：<?php echo esc_html($today_total_usage ?: 0); ?> 次，成功次数：<?php echo esc_html($today_total_success ?: 0); ?> 次</p>

        <h2>所有用户记录</h2>
        <?php
        if ($all_records) {
            echo '<table class="wp-list-table widefat fixed striped" id="all-records-table">';
            echo '<thead><tr><th>用户ID</th><th>日期</th><th>尝试次数</th><th>成功次数</th><th>自定义限制</th><th>输入内容</th><th>创建时间</th><th>操作</th></tr></thead>';
            echo '<tbody>';
            foreach ($all_records as $record) {
                echo '<tr>';
                echo '<td>' . esc_html($record->user_id) . '</td>';
                echo '<td>' . esc_html($record->usage_date) . '</td>';
                echo '<td>' . esc_html($record->total_count) . '</td>';
                echo '<td>' . esc_html($record->success_count) . '</td>';
                echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
                echo '<td>' . esc_html($record->input_content ?: '无记录') . '</td>';
                echo '<td>' . esc_html($record->created_at) . '</td>';
                echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
            echo '<button id="delete-all-records">删除全部记录</button>';

            $total_pages = ceil($total_all_records / $per_page);
            if ($total_pages > 1) {
                echo '<div id="all-pagination">';
                for ($i = 1; $i <= $total_pages; $i++) {
                    printf('<a href="#" class="page-number%s" data-page="%d">%d</a>', $i === $paged ? ' active' : '', $i, $i);
                }
                echo '</div>';
            }
        } else {
            echo '<p>暂无用户记录。</p>';
        }
        ?>
        
        <h2>查询指定用户</h2>
        <form method="post">
            <input type="number" name="user_id" placeholder="输入用户ID" value="<?php echo esc_attr($user_id); ?>">
            <input type="submit" value="搜索" class="button">
        </form>
        <?php
        if ($user_id) {
            $user_total_usage = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(total_count) FROM {$wpdb->prefix}wangming_records WHERE user_id = %d",
                $user_id
            ));
            $user_total_success = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(success_count) FROM {$wpdb->prefix}wangming_records WHERE user_id = %d",
                $user_id
            ));

            $user_today_usage = $wpdb->get_var($wpdb->prepare(
                "SELECT total_count FROM {$wpdb->prefix}wangming_records WHERE user_id = %d AND usage_date = %s",
                $user_id,
                $today
            ));
            $user_today_success = $wpdb->get_var($wpdb->prepare(
                "SELECT success_count FROM {$wpdb->prefix}wangming_records WHERE user_id = %d AND usage_date = %s",
                $user_id,
                $today
            ));

            $total_records = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}wangming_records WHERE user_id = %d",
                $user_id
            ));

            $records = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}wangming_records 
                WHERE user_id = %d 
                ORDER BY created_at DESC 
                LIMIT %d OFFSET %d",
                $user_id,
                $per_page,
                ($paged - 1) * $per_page
            ));

            echo '<h2>用户记录 (ID: ' . esc_html($user_id) . ')</h2>';
            echo '<p>用户总共尝试次数：' . esc_html($user_total_usage ?: 0) . ' 次，成功次数：' . esc_html($user_total_success ?: 0) . ' 次</p>';
            echo '<p>用户今日尝试次数：' . esc_html($user_today_usage ?: 0) . ' 次，成功次数：' . esc_html($user_today_success ?: 0) . ' 次</p>';

            if ($records) {
                echo '<table class="wp-list-table widefat fixed striped" id="user-records-table">';
                echo '<thead><tr><th>日期</th><th>尝试次数</th><th>成功次数</th><th>自定义限制</th><th>输入内容</th><th>操作</th></tr></thead>';
                echo '<tbody>';
                foreach ($records as $record) {
                    echo '<tr>';
                    echo '<td>' . esc_html($record->usage_date) . '</td>';
                    echo '<td>' . esc_html($record->total_count) . '</td>';
                    echo '<td>' . esc_html($record->success_count) . '</td>';
                    echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
                    echo '<td>' . esc_html($record->input_content ?: '无记录') . '</td>';
                    echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
                echo '<button id="delete-all-user-records" data-user-id="' . esc_attr($user_id) . '">删除全部用户记录</button>';

                $total_pages = ceil($total_records / $per_page);
                if ($total_pages > 1) {
                    echo '<div id="pagination">';
                    for ($i = 1; $i <= $total_pages; $i++) {
                        printf('<a href="#" class="page-number%s" data-page="%d">%d</a>', $i === $paged ? ' active' : '', $i, $i);
                    }
                    echo '</div>';
                }
            } else {
                echo '<p>未找到该用户记录。</p>';
            }
            
            ?>
            <form method="post">
                <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="number" name="custom_limit" placeholder="自定义每日限制">
                <input type="submit" name="set_limit" value="设置自定义限制" class="button">
                <input type="submit" name="reset_limit" value="恢复默认" class="button">
            </form>
            <?php
        }
        ?>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $('#pagination .page-number').on('click', function(e) {
            e.preventDefault();
            if (!$(this).hasClass('active')) {
                var user_id = $('input[name="user_id"]').val();
                var page = $(this).data('page');
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'wangming_load_user_records',
                        user_id: user_id,
                        paged: page
                    },
                    success: function(response) {
                        $('#user-records-table tbody').html(response.data.records);
                        $('#pagination .page-number').removeClass('active');
                        $('#pagination .page-number[data-page="' + page + '"]').addClass('active');
                    }
                });
            }
        });

        $('#all-pagination .page-number').on('click', function(e) {
            e.preventDefault();
            if (!$(this).hasClass('active')) {
                var page = $(this).data('page');
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'wangming_load_all_records',
                        paged: page
                    },
                    success: function(response) {
                        $('#all-records-table tbody').html(response.data.records);
                        $('#all-pagination .page-number').removeClass('active');
                        $('#all-pagination .page-number[data-page="' + page + '"]').addClass('active');
                    }
                });
            }
        });

        $('.delete-record').on('click', function(e) {
            e.preventDefault();
            var record_id = $(this).data('id');
            if (confirm('确定删除此记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'wangming_delete_record',
                        record_id: record_id
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#all-records-table tr').each(function() {
                                if ($(this).find('.delete-record').data('id') === record_id) {
                                    $(this).remove();
                                }
                            });
                            $('#user-records-table tr').each(function() {
                                if ($(this).find('.delete-record').data('id') === record_id) {
                                    $(this).remove();
                                }
                            });
                        }
                    }
                });
            }
        });

        $('#delete-all-records').on('click', function(e) {
            e.preventDefault();
            if (confirm('确定删除所有记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'wangming_delete_all_records'
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#all-records-table tbody').empty();
                        }
                    }
                });
            }
        });

        $('#delete-all-user-records').on('click', function(e) {
            e.preventDefault();
            var user_id = $(this).data('user-id');
            if (confirm('确定删除该用户的所有记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'wangming_delete_user_records',
                        user_id: user_id
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#user-records-table tbody').empty();
                        }
                    }
                });
            }
        });
    });
    </script>
    <?php
}

// AJAX 获取用户记录
add_action('wp_ajax_wangming_load_user_records', function() {
    global $wpdb;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $paged = isset($_POST['paged']) ? max(1, intval($_POST['paged'])) : 1;
    $per_page = 20;

    if ($user_id) {
        $records = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}wangming_records 
            WHERE user_id = %d 
            ORDER BY created_at DESC 
            LIMIT %d OFFSET %d",
            $user_id,
            $per_page,
            ($paged - 1) * $per_page
        ));

        ob_start();
        foreach ($records as $record) {
            echo '<tr>';
            echo '<td>' . esc_html($record->usage_date) . '</td>';
            echo '<td>' . esc_html($record->total_count) . '</td>';
            echo '<td>' . esc_html($record->success_count) . '</td>';
            echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
            echo '<td>' . esc_html($record->input_content ?: '无记录') . '</td>';
            echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
            echo '</tr>';
        }
        $html = ob_get_clean();

        wp_send_json_success(array('records' => $html));
    }
    wp_die();
});

// AJAX 获取所有用户记录
add_action('wp_ajax_wangming_load_all_records', function() {
    global $wpdb;
    $paged = isset($_POST['paged']) ? max(1, intval($_POST['paged'])) : 1;
    $per_page = 20;

    $records = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}wangming_records 
        ORDER BY created_at DESC 
        LIMIT %d OFFSET %d",
        $per_page,
        ($paged - 1) * $per_page
    ));

    ob_start();
    foreach ($records as $record) {
        echo '<tr>';
        echo '<td>' . esc_html($record->user_id) . '</td>';
        echo '<td>' . esc_html($record->usage_date) . '</td>';
        echo '<td>' . esc_html($record->total_count) . '</td>';
        echo '<td>' . esc_html($record->success_count) . '</td>';
        echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
        echo '<td>' . esc_html($record->input_content ?: '无记录') . '</td>';
        echo '<td>' . esc_html($record->created_at) . '</td>';
        echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
        echo '</tr>';
    }
    $html = ob_get_clean();

    wp_send_json_success(array('records' => $html));
    exit;
});

// AJAX 删除单条记录
function wangming_delete_record() {
    global $wpdb;
    $record_id = isset($_POST['record_id']) ? intval($_POST['record_id']) : 0;

    if ($record_id) {
        $wpdb->delete($wpdb->prefix . 'wangming_records', array('id' => $record_id));
        wp_send_json_success();
    }

    wp_send_json_error();
}
add_action('wp_ajax_wangming_delete_record', 'wangming_delete_record');

// AJAX 删除所有记录
function wangming_delete_all_records() {
    global $wpdb;

    $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}wangming_records");
    wp_send_json_success();
}
add_action('wp_ajax_wangming_delete_all_records', 'wangming_delete_all_records');

// AJAX 删除用户所有记录
function wangming_delete_user_records() {
    global $wpdb;

    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;

    if ($user_id) {
        $wpdb->delete($wpdb->prefix . 'wangming_records', array('user_id' => $user_id));
        wp_send_json_success();
    }

    wp_send_json_error();
}
add_action('wp_ajax_wangming_delete_user_records', 'wangming_delete_user_records');

// 前台短代码
function wangming_shortcode() {
    global $wpdb;
    $ad_content = get_option('wangming_ad_content', '');
    $enable_search = get_option('wangming_enable_search', '0');
    $enable_model_select = get_option('wangming_enable_model_select', '0');
    $enable_usage_display = get_option('wangming_enable_usage_display', '0');

    if (!is_user_logged_in()) {
        ob_start();
        ?>
        <div class="wangming_container">
            <div class="wangming_page_title">AI网名推荐</div>
            <div class="wangming_login_notice">
                请先登录才能使用网名推荐助手。
                <button class="wangming_quick_login_button">快速登录</button>
            </div>
            <?php if ($ad_content): ?>
            <div class="wangming_ad">
                <?php echo wp_kses_post($ad_content); ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = get_option('wangming_daily_limit', 10);
    
    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT total_count, success_count, custom_limit FROM {$wpdb->prefix}wangming_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));
    
    $success_count = $usage_data ? $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? $usage_data->custom_limit : $default_limit;
    $remaining_usage = $user_limit - $success_count;
    
    if ($remaining_usage <= 0) {
        return '<div class="wangming_container"><div class="wangming_limit_notice">今日使用次数已达上限，请明天再来。</div></div>';
    }

    $models = array_map('trim', explode(',', get_option('wangming_models', 'qwen-plus')));
    $platforms = array_map('trim', explode(',', get_option('wangming_platforms', '微信,微博,小红书')));

    ob_start();
    ?>
    <div class="wangming_container">
        <div class="wangming_page_title">AI网名推荐</div>
        
        <div class="wangming_config">
            <div class="wangming_page_mintitle">推荐配置</div>
            
            <div class="wangming_input_wrapper">
                <label for="wangming_input">网名需求</label>
                <textarea id="wangming_input" name="wangming_input" placeholder="请输入网名需求，例如：搞笑风格的微信网名"></textarea>
            </div>
            
            <div class="wangming_model_wrapper">
                <?php if ($enable_model_select): ?>
                <div class="wangming_model_select">
                    <label for="wangming_model">AI模型选择</label>
                    <select id="wangming_model" name="wangming_model">
                        <?php foreach ($models as $model): ?>
                            <option value="<?php echo esc_attr($model); ?>"><?php echo esc_html($model); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                <?php if ($enable_search): ?>
                <div class="wangming_search_toggle">
                    <span class="wangming_search_label">启用联网搜索</span>
                    <label class="wangming_search_slider">
                        <input type="checkbox" id="wangming_enable_search" name="wangming_enable_search">
                        <span class="slider"></span>
                    </label>
                </div>
                <?php endif; ?>
            </div>
            
            <?php if ($platforms): ?>
            <div class="wangming_platforms">
                <label>平台类型</label>
                <div class="wangming_platform_buttons">
                    <?php foreach ($platforms as $platform): ?>
                        <button class="wangming_platform_button" data-platform="<?php echo esc_attr($platform); ?>">
                            <?php echo esc_html($platform); ?>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <button class="wangming_generate_button">获取推荐</button>
        </div>
        
        <div class="wangming_results">
            <div class="wangming_page_mintitle">推荐结果</div>
            <div class="wangming_result_content">AI推荐结果将显示在这里...</div>
            <div class="wangming_result_buttons">
                <button class="wangming_copy_button">一键复制</button>
                <button class="wangming_refresh_button">换一批</button>
                <button class="wangming_clear_button">清空</button>
            </div>
            <div class="wangming_copy_success"></div>
            <?php if ($enable_usage_display): ?>
            <div class="wangming_usage">今日可用次数：<?php echo esc_html($user_limit . '/' . $remaining_usage); ?></div>
            <?php endif; ?>
        </div>
        
        <?php if ($ad_content): ?>
        <div class="wangming_ad">
            <?php echo wp_kses_post($ad_content); ?>
        </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('wangming_shortcode', 'wangming_shortcode');

// 处理自定义限制更新
add_action('admin_post', function() {
    if (isset($_POST['user_id']) && (isset($_POST['set_limit']) || isset($_POST['reset_limit']))) {
        global $wpdb;
        $user_id = intval($_POST['user_id']);
        
        if (isset($_POST['set_limit']) && !empty($_POST['custom_limit'])) {
            $custom_limit = intval($_POST['custom_limit']);
            $wpdb->update(
                $wpdb->prefix . 'wangming_records',
                array('custom_limit' => $custom_limit),
                array('user_id' => $user_id)
            );
        } elseif (isset($_POST['reset_limit'])) {
            $wpdb->update(
                $wpdb->prefix . 'wangming_records',
                array('custom_limit' => null),
                array('user_id' => $user_id)
            );
        }
        
        wp_redirect(admin_url('admin.php?page=wangming-user-records&user_id=' . $user_id));
        exit;
    }
});

// 增强 REST API 权限检查
add_filter('rest_authentication_errors', function($result) {
    if (is_wp_error($result)) {
        return $result;
    }
    if (!is_user_logged_in()) {
        return new WP_Error(
            'rest_not_logged_in',
            '您必须登录才能访问此资源。',
            array('status' => 401)
        );
    }
    return $result;
});
?>