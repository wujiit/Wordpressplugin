<?php
/*
Plugin Name: 域名备案黑名单查询
Description: 一个用于查询域名备案黑名单情况的WordPress插件，支持游客查询并提供游客专属限制和登录提示。
Version: 1.0.2
Author: Summer
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xb_icphmd_activate');
function xb_icphmd_activate() {
    xb_icphmd_create_database();
    xb_icphmd_create_front_page();
}

// 创建数据库表，包含IP地址和设备信息
function xb_icphmd_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 查询次数表，增加ip_address和device_info字段
    $usage_table = $wpdb->prefix . 'xb_icphmd_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        ip_address varchar(45) NOT NULL,
        device_info varchar(255) NOT NULL,
        query_date date NOT NULL,
        query_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_ip_date (user_id, ip_address, device_info, query_date)
    ) $charset_collate;";

    // 查询记录表，增加ip_address和device_info字段
    $queries_table = $wpdb->prefix . 'xb_icphmd_queries';
    $queries_sql = "CREATE TABLE $queries_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        ip_address varchar(45) NOT NULL,
        device_info varchar(255) NOT NULL,
        domain varchar(255) NOT NULL,
        query_status varchar(255) NOT NULL,
        query_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($usage_sql);
    dbDelta($queries_sql);

    // 日志记录
    error_log('XB ICPHMD: Database tables created or updated.');
}

// 检查并创建前台页面
function xb_icphmd_create_front_page() {
    // 查询是否已有包含短代码 [xb_icphmd_query_form] 的页面
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_icphmd_query_form]',
        'numberposts' => 1,
    ));

    // 如果没有找到包含短代码的页面
    if (empty($pages)) {
        // 创建页面
        $page_data = array(
            'post_title'   => '域名备案黑名单查询',
            'post_content' => '[xb_icphmd_query_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 加载前端资源，仅在包含短代码的页面加载
add_action('wp_enqueue_scripts', 'xb_icphmd_enqueue_scripts');
function xb_icphmd_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_icphmd_query_form')) {
        wp_enqueue_style('xb_icphmd_styles', plugins_url('xb-icphmd.css', __FILE__), array(), '1.0.2');
        wp_enqueue_script('xb_icphmd_scripts', plugins_url('xb-icphmd.js', __FILE__), array('jquery'), '1.0.2', true);

        wp_localize_script('xb_icphmd_scripts', 'xb_icphmd_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => rest_url('xb_icphmd/v1/query'),
            'nonce'    => wp_create_nonce('wp_rest'),
            'login_url' => wp_login_url(get_permalink()),
            'is_logged_in' => is_user_logged_in() ? 1 : 0
        ));
    }
}

// 创建短代码，支持游客和登录用户查询
add_shortcode('xb_icphmd_query_form', 'xb_icphmd_query_form_shortcode');
function xb_icphmd_query_form_shortcode() {
    $ad_content = get_option('xb_icphmd_ad_content', '');
    $default_limit = absint(get_option('xb_icphmd_default_limit', 10));
    $guest_limit = absint(get_option('xb_icphmd_guest_limit', 5));
    $show_stats = get_option('xb_icphmd_show_stats', 1); // 默认显示统计

    $display_result = '';
    $display_message = '';
    $show_clear = false;

    if (!is_user_logged_in()) {
        // 检查通用消息 transient
        $guest_message = get_transient('xb_icphmd_guest_message');
        if ($guest_message) {
            $display_message = $guest_message;
            $show_clear = true;
            delete_transient('xb_icphmd_guest_message');
        }

        // 检查特定 domain 的 transient
        if (isset($_GET['qdomain'])) {
            $qdomain = urldecode(sanitize_text_field($_GET['qdomain']));
            $md5_key = md5($qdomain);
            $transient_result = get_transient('xb_icphmd_result_' . $md5_key);
            if ($transient_result) {
                if (isset($transient_result['message'])) {
                    $display_message = $transient_result['message'];
                } else {
                    $display_result = $transient_result['result'];
                }
                $show_clear = true;
                delete_transient('xb_icphmd_result_' . $md5_key);
            }
        }
    }

    ob_start();
    ?>
    <div class="xb_icphmd_container">
        <div class="xb_icphmd_title">域名备案黑名单查询</div>

        <?php
        $user_id = is_user_logged_in() ? get_current_user_id() : 0;
        $today = current_time('Y-m-d');
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $device_info = !empty($_SERVER['HTTP_USER_AGENT']) ? substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT']), 0, 255) : 'Unknown';

        global $wpdb;
        $table_name = $wpdb->prefix . 'xb_icphmd_usage';
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT query_count, custom_limit FROM $table_name WHERE user_id = %d AND ip_address = %s AND device_info = %s AND query_date = %s",
                $user_id,
                $ip_address,
                $device_info,
                $today
            )
        );

        $query_count = $row ? absint($row->query_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : ($user_id ? $default_limit : $guest_limit);
        $remaining = max(0, $user_limit - $query_count);
        $stats_text = "今日剩余查询次数：{$remaining}/{$user_limit}";
        $form_id = is_user_logged_in() ? 'xb_icphmd_query_form_logged' : 'xb_icphmd_query_form_guest';
        $action = is_user_logged_in() ? '' : get_permalink(); // 游客用普通表单提交
        $method = is_user_logged_in() ? 'post' : 'post'; // 两者都post，但登录用JS拦截
        ?>

        <div class="xb_icphmd_query_section">
            <?php if ($query_count >= $user_limit): ?>
                <div class="xb_icphmd_message">
                    <?php if (is_user_logged_in()): ?>
                        今日使用次数已经用完，请明天再来。
                    <?php else: ?>
                        游客的使用次数已经用完，请登录之后继续。
                        <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="wp-icphei-login-btn">快速登录</a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <form id="<?php echo $form_id; ?>" action="<?php echo $action; ?>" method="<?php echo $method; ?>">
                    <input type="text" name="xb_icphmd_domain" id="xb_icphmd_domain" placeholder="请输入域名（如：aizhan.com）" required>
                    <button type="submit" class="xb_icphmd_submit_button">开始查询</button>
                    <?php if (is_user_logged_in()): ?>
                        <input type="hidden" name="xb_icphmd_nonce" id="xb_icphmd_nonce" value="<?php echo wp_create_nonce('xb_icphmd_query_nonce'); ?>">
                    <?php endif; ?>
                </form>
            <?php endif; ?>
            <div class="xb_icphmd_result_section">
                <?php if ($query_count < $user_limit || $show_clear): ?>
                    <button id="xb_icphmd_clear_button" class="xb_icphmd_clear_button" style="<?php echo $show_clear ? 'display:block;' : 'display:none;'; ?>">清空结果</button>
                <?php endif; ?>
                <div id="xb_icphmd_result">
                    <?php 
                    if ($display_result) {
                        echo $display_result;
                    }
                    if ($display_message) {
                        echo '<div class="xb_icphmd_message">' . esc_html($display_message) . '</div>';
                    }
                    ?>
                </div>
                <?php if ($show_stats && $query_count < $user_limit): ?>
                    <div class="xb_icphmd_usage_info"><?php echo esc_html($stats_text); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <div class="xb_icphmd_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
    </div>
    <?php
    return ob_get_clean();
}

// 处理游客普通表单提交
add_action('template_redirect', 'xb_icphmd_handle_guest_query');
function xb_icphmd_handle_guest_query() {
    if (isset($_POST['xb_icphmd_domain']) && !is_user_logged_in()) {
        $domain = sanitize_text_field($_POST['xb_icphmd_domain']);
        if (empty($domain)) {
            set_transient('xb_icphmd_guest_message', '请输入域名！', 10);
            wp_redirect(get_permalink());
            exit;
        }

        // 验证域名格式
        if (!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+$/', $domain)) {
            set_transient('xb_icphmd_guest_message', '请输入有效的域名格式（如：aizhan.com）！', 10);
            wp_redirect(get_permalink());
            exit;
        }

        $user_id = 0;
        $today = current_time('Y-m-d');
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $device_info = !empty($_SERVER['HTTP_USER_AGENT']) ? substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT']), 0, 255) : 'Unknown';

        global $wpdb;
        $usage_table = $wpdb->prefix . 'xb_icphmd_usage';
        $queries_table = $wpdb->prefix . 'xb_icphmd_queries';

        $guest_limit = absint(get_option('xb_icphmd_guest_limit', 5));
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT query_count, custom_limit FROM $usage_table WHERE user_id = %d AND ip_address = %s AND device_info = %s AND query_date = %s",
                $user_id,
                $ip_address,
                $device_info,
                $today
            )
        );

        $query_count = $row ? absint($row->query_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $guest_limit;

        if ($query_count >= $user_limit) {
            set_transient('xb_icphmd_guest_message', '游客的使用次数已经用完，请登录之后继续。', 10);
            wp_redirect(get_permalink());
            exit;
        }

        // 调用 API
        $result = xb_icphmd_call_api($domain, $user_id, $ip_address, $device_info, $today, $query_count, $user_limit);

        // 使用 transient 存储结果以减少重定向后重新调用
        set_transient('xb_icphmd_result_' . md5($domain), $result, 60); // 缓存1分钟

        wp_redirect(add_query_arg('qdomain', urlencode($domain), get_permalink()));
        exit;
    }
}

// 注册 REST API 端点，用于登录用户
add_action('rest_api_init', 'xb_icphmd_register_rest_route');
function xb_icphmd_register_rest_route() {
    register_rest_route('xb_icphmd/v1', '/query', array(
        'methods' => 'POST',
        'callback' => 'xb_icphmd_handle_logged_query',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
        'args' => array(
            'domain' => array(
                'required' => true,
                'validate_callback' => function ($param) {
                    return preg_match('/^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+$/', $param);
                }
            ),
        )
    ));
}

// 处理登录用户 REST 查询，使用 transient 缓存使用次数检查以优化性能
function xb_icphmd_handle_logged_query(WP_REST_Request $request) {
    $domain = $request->get_param('domain');
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $device_info = !empty($_SERVER['HTTP_USER_AGENT']) ? substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT']), 0, 255) : 'Unknown';

    // 使用 transient 缓存使用次数检查，减少数据库查询
    $transient_key = 'xb_icphmd_usage_' . $user_id . '_' . md5($ip_address . $device_info . $today);
    $cached_usage = get_transient($transient_key);
    if ($cached_usage !== false) {
        list($query_count, $user_limit) = $cached_usage;
    } else {
        global $wpdb;
        $usage_table = $wpdb->prefix . 'xb_icphmd_usage';
        $default_limit = absint(get_option('xb_icphmd_default_limit', 10));
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT query_count, custom_limit FROM $usage_table WHERE user_id = %d AND ip_address = %s AND device_info = %s AND query_date = %s",
                $user_id,
                $ip_address,
                $device_info,
                $today
            )
        );
        $query_count = $row ? absint($row->query_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;
        set_transient($transient_key, array($query_count, $user_limit), 300); // 缓存5分钟
    }

    if ($query_count >= $user_limit) {
        return new WP_REST_Response(array('message' => '今日使用次数已经用完，请明天再来。'), 403);
    }

    // 调用 API
    $result = xb_icphmd_call_api($domain, $user_id, $ip_address, $device_info, $today, $query_count, $user_limit);

    return new WP_REST_Response($result, 200);
}

// 通用 API 调用函数
function xb_icphmd_call_api($domain, $user_id, $ip_address, $device_info, $today, $query_count, $user_limit) {
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_icphmd_usage';
    $queries_table = $wpdb->prefix . 'xb_icphmd_queries';

    $api_url = get_option('xb_icphmd_api_url', 'https://apistore.aizhan.com/icp/checkdomain/');
    $api_key = get_option('xb_icphmd_api_key');
    $request_url = trailingslashit($api_url) . $api_key . '?domain=' . urlencode($domain);

    $args = array(
        'timeout' => 10,
        'sslverify' => false,
        'headers' => array(
            'Accept' => 'application/json'
        )
    );

    $response = wp_remote_get($request_url, $args);
    $query_status = 'failed';

    $insert_data = array(
        'user_id' => $user_id,
        'ip_address' => $ip_address,
        'device_info' => $device_info,
        'domain' => $domain,
        'query_status' => $query_status,
        'query_time' => current_time('mysql')
    );

    if (is_wp_error($response)) {
        $query_status = $response->get_error_message();
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data);
        return array('message' => '暂时无法解析请联系客服');
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if ($status_code >= 400) {
        $query_status = isset($data['msg']) ? $data['msg'] : 'API 请求错误：HTTP ' . $status_code;
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data);
        return array('message' => '暂时无法解析请联系客服');
    }

    if (isset($data['code']) && $data['code'] == 200000 && isset($data['data'])) {
        $query_status = 'success';
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data);

        // 更新查询次数
        if ($query_count > 0) {
            $new_count = $query_count + 1;
            $wpdb->update(
                $usage_table,
                array('query_count' => $new_count),
                array('user_id' => $user_id, 'ip_address' => $ip_address, 'device_info' => $device_info, 'query_date' => $today)
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'ip_address' => $ip_address,
                    'device_info' => $device_info,
                    'query_date' => $today,
                    'query_count' => 1,
                    'custom_limit' => null
                )
            );
        }

        // 更新 transient 缓存
        $transient_key = 'xb_icphmd_usage_' . $user_id . '_' . md5($ip_address . $device_info . $today);
        set_transient($transient_key, array($query_count + 1, $user_limit), 300);

        // 格式化结果，仅显示文本状态
        $result = $data['data'];
        $level_class = '';
        $level_text = '';
        if ($result['blackListLevel'] == 2) {
            $level_class = 'xb_icphmd_normal';
            $level_text = '正常域名';
        } elseif ($result['blackListLevel'] == 0) {
            $level_class = 'xb_icphmd_blacklist';
            $level_text = '列入黑名单';
        } elseif ($result['blackListLevel'] == -1) {
            $level_class = 'xb_icphmd_unknown';
            $level_text = '未知';
        }

        $output = '<table class="xb_icphmd_result_table">';
        $output .= '<tr><th>域名</th><td>' . esc_html($result['domain']) . '</td></tr>';
        $output .= '<tr><th>备案黑名单状态</th><td class="' . $level_class . '">' . esc_html($level_text) . '</td></tr>';
        $output .= '</table>';

        return array(
            'result' => $output,
            'remaining' => $user_limit - ($query_count + 1),
            'limit' => $user_limit
        );
    } else {
        $query_status = isset($data['msg']) ? $data['msg'] : '未知错误';
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data);
        return array('message' => '暂时无法解析请联系客服');
    }
}

// 添加管理菜单
add_action('admin_menu', 'xb_icphmd_admin_menu');
function xb_icphmd_admin_menu() {
    add_menu_page(
        '域名备案黑名单查询设置',
        '备案黑名单设置',
        'manage_options',
        'xb_icphmd_settings',
        'xb_icphmd_settings_page',
        'dashicons-shield',
        80
    );
    add_submenu_page(
        'xb_icphmd_settings',
        '查询记录',
        '查询记录',
        'manage_options',
        'xb_icphmd_all_records',
        'xb_icphmd_all_records_page'
    );
}

// 插件设置页面，增加游客查询次数和显示统计开关
function xb_icphmd_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['xb_icphmd_save_settings'])) {
        check_admin_referer('xb_icphmd_settings_nonce');

        update_option('xb_icphmd_api_url', sanitize_text_field($_POST['xb_icphmd_api_url']));
        update_option('xb_icphmd_api_key', sanitize_text_field($_POST['xb_icphmd_api_key']));
        $new_limit = absint($_POST['xb_icphmd_default_limit']);
        $new_guest_limit = absint($_POST['xb_icphmd_guest_limit']);
        if ($new_limit > 0) {
            update_option('xb_icphmd_default_limit', $new_limit);
        }
        if ($new_guest_limit > 0) {
            update_option('xb_icphmd_guest_limit', $new_guest_limit);
        }
        update_option('xb_icphmd_show_stats', isset($_POST['xb_icphmd_show_stats']) ? 1 : 0);
        $allowed_html = array(
            'a' => array('href' => array(), 'title' => array(), 'target' => array()),
            'img' => array('src' => array(), 'alt' => array(), 'width' => array(), 'height' => array()),
            'p' => array(),
            'div' => array('class' => array(), 'style' => array()),
            'span' => array('class' => array(), 'style' => array()),
            'strong' => array(),
            'em' => array(),
            'br' => array()
        );
        update_option('xb_icphmd_ad_content', wp_kses($_POST['xb_icphmd_ad_content'], $allowed_html));

        echo '<div id="xb_icphmd_settings_notice" class="updated"><p>设置已保存！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_icphmd_settings_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    global $wpdb;
    $queries_table = $wpdb->prefix . 'xb_icphmd_queries';
    $stats = array();
    $stats['total_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table");
    $stats['success_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table WHERE query_status = 'success'");
    $stats['failed_queries'] = $stats['total_queries'] - $stats['success_queries'];
    $stats['today_queries'] = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $queries_table WHERE DATE(query_time) = %s", current_time('Y-m-d'))
    );

    ?>
    <div class="wrap">
        <div class="xb_icphmd_admin_title">域名备案黑名单查询设置</div>
        <form method="post">
            <?php wp_nonce_field('xb_icphmd_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_icphmd_api_url">API 接口地址</label></th>
                    <td><input type="text" name="xb_icphmd_api_url" id="xb_icphmd_api_url" value="<?php echo esc_attr(get_option('xb_icphmd_api_url', 'https://apistore.aizhan.com/icp/checkdomain/')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_icphmd_api_key">API 密钥</label></th>
                    <td><input type="text" name="xb_icphmd_api_key" id="xb_icphmd_api_key" value="<?php echo esc_attr(get_option('xb_icphmd_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_icphmd_default_limit">登录用户每日查询次数</label></th>
                    <td><input type="number" name="xb_icphmd_default_limit" id="xb_icphmd_default_limit" value="<?php echo esc_attr(get_option('xb_icphmd_default_limit', 10)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_icphmd_guest_limit">游客每日查询次数</label></th>
                    <td><input type="number" name="xb_icphmd_guest_limit" id="xb_icphmd_guest_limit" value="<?php echo esc_attr(get_option('xb_icphmd_guest_limit', 5)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_icphmd_show_stats">前台显示统计</label></th>
                    <td><input type="checkbox" name="xb_icphmd_show_stats" id="xb_icphmd_show_stats" <?php checked(get_option('xb_icphmd_show_stats', 1), 1); ?> value="1"> 显示今日剩余查询次数</td>
                </tr>
                <tr>
                    <th><label for="xb_icphmd_ad_content">公告内容</label></th>
                    <td>
                        <textarea name="xb_icphmd_ad_content" id="xb_icphmd_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_icphmd_ad_content')); ?></textarea>
                        <p class="description">支持 HTML 格式。</p>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="xb_icphmd_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        <div class="xb_icphmd_stats">
            <p>总查询次数：<?php echo esc_html($stats['total_queries'] ?: 0); ?></p>
            <p>成功查询次数：<?php echo esc_html($stats['success_queries'] ?: 0); ?></p>
            <p>失败查询次数：<?php echo esc_html($stats['failed_queries'] ?: 0); ?></p>
            <p>今日查询次数：<?php echo esc_html($stats['today_queries'] ?: 0); ?></p>
        </div>
    </div>
    <?php
}

// 查询记录页面，支持一键删除所有记录和指定用户记录
function xb_icphmd_all_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_icphmd_usage';
    $queries_table = $wpdb->prefix . 'xb_icphmd_queries';
    $user_id = isset($_POST['xb_icphmd_user_id']) ? absint($_POST['xb_icphmd_user_id']) : 0;
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    // 一键删除所有记录
    if (isset($_POST['xb_icphmd_delete_all_global'])) {
        check_admin_referer('xb_icphmd_delete_all_global_nonce');
        $wpdb->query("TRUNCATE TABLE $queries_table");
        $wpdb->query("TRUNCATE TABLE $usage_table");
        echo '<div id="xb_icphmd_delete_global_notice" class="updated"><p>所有记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_icphmd_delete_global_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 删除单条记录
    if (isset($_POST['xb_icphmd_delete_record']) && isset($_POST['record_id'])) {
        check_admin_referer('xb_icphmd_delete_record_nonce');
        $wpdb->delete($queries_table, array('id' => absint($_POST['record_id'])), array('%d'));
        echo '<div id="xb_icphmd_delete_notice" class="updated"><p>记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_icphmd_delete_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 删除用户全部记录
    if (isset($_POST['xb_icphmd_delete_all_records']) && $user_id) {
        check_admin_referer('xb_icphmd_delete_all_records_nonce');
        $wpdb->delete($queries_table, array('user_id' => $user_id), array('%d'));
        $wpdb->delete($usage_table, array('user_id' => $user_id), array('%d'));
        echo '<div id="xb_icphmd_delete_all_notice" class="updated"><p>用户记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_icphmd_delete_all_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 保存用户自定义限制
    if (isset($_POST['xb_icphmd_save_user_limit']) && $user_id) {
        check_admin_referer('xb_icphmd_user_limit_nonce');
        $custom_limit = isset($_POST['xb_icphmd_custom_limit']) ? absint($_POST['xb_icphmd_custom_limit']) : null;

        $wpdb->update(
            $usage_table,
            array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
            array('user_id' => $user_id, 'query_date' => current_time('Y-m-d')),
            array('%d'),
            array('%d', '%s')
        );

        echo '<div id="xb_icphmd_limit_notice" class="updated"><p>用户查询限制已更新！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_icphmd_limit_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 获取用户每日查询次数限制
    $default_limit = absint(get_option('xb_icphmd_default_limit', 10));
    $guest_limit = absint(get_option('xb_icphmd_guest_limit', 5));
    $user_limit = $user_id ? $default_limit : $guest_limit;
    if ($user_id || $user_id === 0) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT custom_limit FROM $usage_table WHERE user_id = %d AND query_date = %s LIMIT 1",
                $user_id,
                current_time('Y-m-d')
            )
        );
        if ($row && $row->custom_limit !== null) {
            $user_limit = absint($row->custom_limit);
        }
    }

    // 统计数据
    $stats = array();
    $where_clause = $user_id ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : '';
    $stats['total_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table $where_clause");
    $stats['success_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table WHERE query_status = 'success' $where_clause");
    $stats['failed_queries'] = $stats['total_queries'] - $stats['success_queries'];
    $stats['today_queries'] = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $queries_table WHERE DATE(query_time) = %s $where_clause", current_time('Y-m-d'))
    );

    // 获取记录
    $offset = ($paged - 1) * $per_page;
    $query = $user_id
        ? $wpdb->prepare("SELECT id, user_id, ip_address, device_info, domain, query_status, query_time FROM $queries_table WHERE user_id = %d ORDER BY query_time DESC LIMIT %d, %d", $user_id, $offset, $per_page)
        : $wpdb->prepare("SELECT id, user_id, ip_address, device_info, domain, query_status, query_time FROM $queries_table ORDER BY query_time DESC LIMIT %d, %d", $offset, $per_page);
    $records = $wpdb->get_results($query);
    $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table" . ($user_id ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : ''));
    $total_pages = ceil($total_records / $per_page);

    $user_info = $user_id && $user_id != 0 ? get_userdata($user_id) : null;
    $user_display = $user_id == 0 ? '游客' : ($user_info ? $user_info->user_login : '未知用户');
    ?>
    <div class="wrap">
        <div class="xb_icphmd_admin_title">所有查询记录</div>
        <form method="post" style="display:inline;">
            <?php wp_nonce_field('xb_icphmd_delete_all_global_nonce'); ?>
            <p><input type="submit" name="xb_icphmd_delete_all_global" class="button-secondary" value="一键删除所有记录" onclick="return confirm('确定删除所有记录吗？这将清空查询记录和使用次数表。');"></p>
        </form>
        <form method="post">
            <p>
                <label for="xb_icphmd_user_id">输入用户 ID（0 表示游客，留空显示所有记录）：</label>
                <input type="number" name="xb_icphmd_user_id" id="xb_icphmd_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <?php if ($user_id || $user_id === 0): ?>
            <h2>用户：<?php echo esc_html($user_display); ?> (ID: <?php echo $user_id; ?>)</h2>
            <p>当前用户每日查询次数：<?php echo esc_html($user_limit); ?> 次</p>
            <form method="post">
                <?php wp_nonce_field('xb_icphmd_user_limit_nonce'); ?>
                <p>
                    <label for="xb_icphmd_custom_limit">设置自定义每日查询次数（0 表示使用默认值）：</label>
                    <input type="number" name="xb_icphmd_custom_limit" id="xb_icphmd_custom_limit" min="0">
                    <input type="hidden" name="xb_icphmd_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_icphmd_save_user_limit" class="button-primary" value="保存">
                </p>
            </form>
            <form method="post">
                <?php wp_nonce_field('xb_icphmd_delete_all_records_nonce'); ?>
                <input type="hidden" name="xb_icphmd_user_id" value="<?php echo esc_attr($user_id); ?>">
                <p><input type="submit" name="xb_icphmd_delete_all_records" class="button-secondary" value="删除当前用户记录" onclick="return confirm('确定删除当前用户所有记录吗？');"></p>
            </form>
        <?php endif; ?>

        <div class="xb_icphmd_stats">
            <p>总查询次数：<?php echo esc_html($stats['total_queries'] ?: 0); ?></p>
            <p>成功查询次数：<?php echo esc_html($stats['success_queries'] ?: 0); ?></p>
            <p>失败查询次数：<?php echo esc_html($stats['failed_queries'] ?: 0); ?></p>
            <p>今日查询次数：<?php echo esc_html($stats['today_queries'] ?: 0); ?></p>
        </div>

        <table class="widefat">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>IP 地址</th>
                    <th>设备信息</th>
                    <th>查询时间</th>
                    <th>域名</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="7">暂无查询记录。</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td><?php echo esc_html($record->user_id == 0 ? '游客' : $record->user_id); ?></td>
                            <td><?php echo esc_html($record->ip_address); ?></td>
                            <td><?php echo esc_html($record->device_info); ?></td>
                            <td><?php echo esc_html($record->query_time); ?></td>
                            <td><?php echo esc_html($record->domain); ?></td>
                            <td><?php echo esc_html($record->query_status); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_icphmd_delete_record_nonce'); ?>
                                    <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>">
                                    <input type="submit" name="xb_icphmd_delete_record" class="button-link" value="删除" onclick="return confirm('确定删除此记录？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}
?>