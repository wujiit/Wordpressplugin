jQuery(document).ready(function ($) {
    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('XB ICPHMD: jQuery 未加载！');
        $('#xb_icphmd_result').html('<div class="xb_icphmd_message">脚本加载失败，请刷新页面！</div>');
        return;
    }

    // 确保 xb_icphmd_ajax 配置
    if (typeof xb_icphmd_ajax === 'undefined') {
        console.error('XB ICPHMD: xb_icphmd_ajax 未定义！');
        $('#xb_icphmd_result').html('<div class="xb_icphmd_message">脚本配置失败，请检查插件设置！</div>');
        return;
    }

    // “快速登录”按钮点击事件
    $(document).on('click', '.wp-icphei-login-btn', function (e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });

    // 清空按钮
    $('#xb_icphmd_clear_button').on('click', function (e) {
        e.preventDefault();
        $('#xb_icphmd_result').empty();
        $(this).hide();
    });

    // 处理登录用户表单提交，使用 REST API
    $('#xb_icphmd_query_form_logged').on('submit', function (e) {
        e.preventDefault();

        var $form = $(this);
        var domain = $('#xb_icphmd_domain').val().trim();
        var nonce = $('#xb_icphmd_nonce').val();

        if (!domain) {
            $('#xb_icphmd_result').html('<div class="xb_icphmd_message">请输入域名！</div>');
            $('#xb_icphmd_clear_button').show();
            return;
        }

        // 前端验证域名格式
        var domainPattern = /^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+$/;
        if (!domainPattern.test(domain)) {
            $('#xb_icphmd_result').html('<div class="xb_icphmd_message">请输入有效的域名格式（如：aizhan.com）！</div>');
            $('#xb_icphmd_clear_button').show();
            return;
        }

        if (!nonce) {
            $('#xb_icphmd_result').html('<div class="xb_icphmd_message">安全验证参数丢失，请刷新页面！</div>');
            $('#xb_icphmd_clear_button').show();
            return;
        }

        $.ajax({
            url: xb_icphmd_ajax.rest_url,
            type: 'POST',
            data: JSON.stringify({ domain: domain }),
            contentType: 'application/json',
            headers: { 'X-WP-Nonce': xb_icphmd_ajax.nonce },
            beforeSend: function () {
                $('.xb_icphmd_submit_button').prop('disabled', true).text('查询中...');
            },
            success: function (response) {
                if (response.message) {
                    $('#xb_icphmd_result').html('<div class="xb_icphmd_message">' + response.message + '</div>');
                } else {
                    $('#xb_icphmd_result').html(response.result);
                    $('.xb_icphmd_usage_info').text('今日剩余查询次数：' + response.remaining + '/' + response.limit);

                    if (response.remaining <= 0) {
                        $form.hide();
                        $('#xb_icphmd_result').append('<div class="xb_icphmd_message">今日使用次数已经用完，请明天再来。</div>');
                    }
                }
                $('#xb_icphmd_clear_button').show();
            },
            error: function (xhr, status, error) {
                console.error('XB ICPHMD: REST API 错误：' + error);
                var message = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : '暂时无法解析请联系客服';
                $('#xb_icphmd_result').html('<div class="xb_icphmd_message">' + message + '</div>');
                $('#xb_icphmd_clear_button').show();
            },
            complete: function () {
                $('.xb_icphmd_submit_button').prop('disabled', false).text('开始查询');
            }
        });
    });
});