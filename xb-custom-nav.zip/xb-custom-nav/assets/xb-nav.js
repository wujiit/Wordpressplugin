(function($, window, document) {
    'use strict';

    const XBNav = {
        /**
         * 初始化函数，绑定所有事件并初始化热榜
         */
        init: function() {
            console.log('XBNav 初始化开始'); // 调试信息
            this.bindEvents();
            this.initHotlist();
        },

        /**
         * 绑定所有点击、键盘和鼠标悬停事件，新增二维码模态框关闭事件
         */
        bindEvents: function() {
            $(document)
                .on('click', '#xb-search-btn', this.handleSearch.bind(this))
                .on('keypress', '#xb-search-input', this.handleSearchKeypress.bind(this))
                .on('click', '.xb-search-tab', this.handleSearchTab.bind(this))
                .on('click', '.xb-category-item', this.handleCategoryFilter.bind(this))
                .on('mouseenter mouseleave', '.xb-nav-item', this.handleNavDesc.bind(this))
                .on('mouseenter mouseleave', '.xb-contact-qr', this.handleContactQr.bind(this))
                .on('click', '.xb-hotlist-tab', this.handleHotlistTab.bind(this))
                .on('click', '.xb-nav-item, .xb-hotlist-link', this.handleNavClick.bind(this))
                .on('click', '.xb-nav-edit', this.handleNavEdit.bind(this))
                .on('click', '.xb-safety-modal-btn', this.handleSafetyModalBtn.bind(this))
                .on('click', '.xb-qr-modal-close', this.handleQrModalClose.bind(this))
                .on('click', '.xb-qr-modal', this.handleQrModalClick.bind(this));
        },

        /**
         * 初始化热榜，确保默认显示日榜并验证热榜数据
         */
        initHotlist: function() {
            const $hotlistWidget = $('.xb-hotlist-widget');
            if ($hotlistWidget.length) {
                console.log('热榜板块已加载'); // 调试信息
                const $dailyTab = $('.xb-hotlist-tab[data-type="daily"]');
                const $dailyContent = $('#hotlist-daily');
                if ($dailyTab.length && $dailyContent.length) {
                    $dailyTab.addClass('active');
                    $dailyContent.show();
                    if ($dailyContent.find('.xb-hotlist-items').children().length === 0) {
                        console.warn('日榜数据为空'); // 调试信息
                    } else {
                        console.log('日榜数据加载成功，项目数：' + $dailyContent.find('.xb-hotlist-items').children().length);
                    }
                } else {
                    console.error('热榜选项卡或内容未找到');
                }
            } else {
                console.error('热榜板块未找到，可能未启用或未渲染'); // 调试信息
            }
        },

        /**
         * 处理搜索按钮点击事件，根据选择的搜索引擎跳转
         */
        handleSearch: function() {
            const keyword = $('#xb-search-input').val().trim();
            if (!keyword) {
                this.showToast('请输入关键词！');
                return;
            }

            const engine = $('.xb-search-tab.active').data('engine');
            let url = '';
            switch (engine) {
                case 'baidu':
                    url = `https://www.baidu.com/s?wd=${encodeURIComponent(keyword)}`;
                    break;
                case 'google':
                    url = `https://www.google.com/search?q=${encodeURIComponent(keyword)}`;
                    break;
                case 'github':
                    url = `https://github.com/search?q=${encodeURIComponent(keyword)}`;
                    break;
                case 'bilibili':
                    url = `https://search.bilibili.com/all?keyword=${encodeURIComponent(keyword)}`;
                    break;
                case 'weibo':
                    url = `https://s.weibo.com/weibo?q=${encodeURIComponent(keyword)}`;
                    break;
                case 'zhihu':
                    url = `https://www.zhihu.com/search?q=${encodeURIComponent(keyword)}`;
                    break;
                case 'taobao':
                    url = `https://s.taobao.com/search?q=${encodeURIComponent(keyword)}`;
                    break;
                case 'site':
                    url = `${window.location.origin}/?s=${encodeURIComponent(keyword)}`;
                    break;
                default:
                    url = `https://www.baidu.com/s?wd=${encodeURIComponent(keyword)}`;
            }
            window.open(url, '_blank');
        },

        /**
         * 处理搜索框回车事件，触发搜索按钮
         */
        handleSearchKeypress: function(e) {
            if (e.which === 13) {
                $('#xb-search-btn').trigger('click');
            }
        },

        /**
         * 处理搜索选项卡切换，更新激活状态
         */
        handleSearchTab: function(e) {
            $('.xb-search-tab').removeClass('active');
            $(e.currentTarget).addClass('active');
        },

        /**
         * 处理分类导航点击，平滑滚动到对应分类板块，保持所有导航板块可见
         */
        handleCategoryFilter: function(e) {
            const categoryId = $(e.currentTarget).data('category-id');
            const $targetSection = $(`#category-${categoryId}`);
            
            // 确保所有导航板块都显示
            $('.xb-nav-section').show();
            $('.xb-recommended-section').show();

            // 如果目标分类存在，平滑滚动到该分类
            if ($targetSection.length) {
                $('html, body').animate({
                    scrollTop: $targetSection.offset().top - 50 // 偏移50px以留出顶部空间
                }, 500); // 动画持续时间500ms
                console.log(`滚动到分类：category-${categoryId}`); // 调试信息
            } else {
                console.warn(`分类未找到：category-${categoryId}`); // 调试信息
            }

            // 关闭手机端菜单
            $('.xb-mobile-menu-content').removeClass('active');
        },

        /**
         * 处理导航描述的显示和隐藏（鼠标悬停）
         */
        handleNavDesc: function(e) {
            if (xbNavAjax.show_desc !== '1') return;

            const $item = $(e.currentTarget);
            const $desc = $item.find('.xb-nav-desc-full');

            if (e.type === 'mouseenter') {
                $desc.show();
            } else {
                $desc.hide();
            }
        },

        /**
         * 处理联系方式二维码的显示和隐藏（鼠标悬停）
         */
        handleContactQr: function(e) {
            const $item = $(e.currentTarget);
            const $qrPopup = $item.find('.xb-qr-popup');

            if (e.type === 'mouseenter') {
                $qrPopup.show();
            } else {
                $qrPopup.hide();
            }
        },

        /**
         * 处理热榜选项卡切换，显示对应热榜内容
         */
        handleHotlistTab: function(e) {
            const $tab = $(e.currentTarget);
            const type = $tab.data('type');

            $('.xb-hotlist-tab').removeClass('active');
            $tab.addClass('active');

            $('.xb-hotlist-content').hide();
            $(`#hotlist-${type}`).show();
            console.log(`切换到${type}热榜`); // 调试信息
        },

        /**
         * 处理导航点击，记录点击并根据设置处理跳转或显示二维码
         */
        handleNavClick: function(e) {
            const $item = $(e.currentTarget);
            const navId = $item.data('nav-id');
            const isExternal = $item.data('is-external') === true;
            const isQrCode = $item.data('is-qr-code') === true;
            const siteName = $item.data('site-name');
            const navName = $item.data('nav-name') || '未知网站';
            const url = $item.attr('href');

            console.log('导航点击：', { navId, isExternal, isQrCode, url }); // 调试信息

            // 记录点击
            if (navId) {
                this.recordNavClick(navId);
            } else {
                console.warn('导航ID缺失，无法记录点击'); // 调试信息
            }

            // 处理二维码导航
            if (isQrCode && xbNavAjax.enable_safety_modal === '1') {
                e.preventDefault();
                this.showQrModal(url, siteName, navName);
                return;
            }

            // 处理外部链接和安全提示
            if (isExternal && xbNavAjax.enable_safety_modal === '1' && !isQrCode) {
                e.preventDefault();
                this.showSafetyModal(url, siteName, navId, navName);
                return;
            }

            // 允许默认跳转
        },

        /**
         * 显示二维码模态框
         */
        showQrModal: function(url, siteName, navName) {
            $('.xb-qr-modal').remove();
            const modalHtml = `
                <div class="xb-qr-modal">
                    <div class="xb-qr-modal-content">
                        <span class="xb-qr-modal-close">×</span>
                        <div class="xb-qr-modal-title">${navName} 二维码</div>
                        <img src="${url}" alt="${navName} 二维码" />
                    </div>
                </div>
            `;
            $('body').append(modalHtml);
            $('.xb-qr-modal').fadeIn(300);
        },

        /**
         * 处理二维码模态框关闭按钮点击
         */
        handleQrModalClose: function(e) {
            $('.xb-qr-modal').fadeOut(300, function() {
                $(this).remove();
            });
        },

        /**
         * 处理二维码模态框外部点击关闭
         */
        handleQrModalClick: function(e) {
            if ($(e.target).hasClass('xb-qr-modal')) {
                $('.xb-qr-modal').fadeOut(300, function() {
                    $(this).remove();
                });
            }
        },

        /**
         * 显示安全提示框
         */
        showSafetyModal: function(url, siteName, navId, navName) {
            $('.xb-safety-modal').remove();
            const modalHtml = `
                <div class="xb-safety-modal">
                    <div class="xb-safety-modal-content">
                        <div class="xb-safety-modal-icon">💡</div>
                        <div class="xb-safety-modal-title">请注意账号和财产安全</div>
                        <div class="xb-safety-modal-text">
                            您即将离开${siteName}，前往 ${navName}：<br>${url}
                        </div>
                        <div class="xb-safety-modal-buttons">
                            <button class="xb-safety-modal-btn cancel">取消</button>
                            <button class="xb-safety-modal-btn continue" data-url="${url}" data-nav-id="${navId}">继续</button>
                        </div>
                    </div>
                </div>
            `;
            $('body').append(modalHtml);
            $('.xb-safety-modal').fadeIn(300);
        },

        /**
         * 处理安全提示框按钮点击
         */
        handleSafetyModalBtn: function(e) {
            const $btn = $(e.currentTarget);
            const isContinue = $btn.hasClass('continue');
            const url = $btn.data('url');

            $('.xb-safety-modal').fadeOut(300, function() {
                $(this).remove(); // 移除非法字符 'طبق'，添加分号
            });

            if (isContinue && url) {
                window.open(url, '_blank');
            }
        },

        /**
         * 记录导航点击，添加错误处理
         */
        recordNavClick: function(navId) {
            console.log('记录点击：nav_id=' + navId); // 调试信息
            $.ajax({
                url: xbNavAjax.ajax_url,
                method: 'POST',
                data: {
                    action: 'xb_nav_record_click',
                    nav_id: navId
                },
                success: function(response) {
                    console.log('点击记录成功：', response); // 调试信息
                },
                error: function(xhr, status, error) {
                    console.error('点击记录失败：', { status, error }); // 调试信息
                    // 不显示错误提示，避免打断用户体验
                }
            });
        },

        /**
         * 处理编辑导航按钮点击
         */
        handleNavEdit: function(e) {
            const $button = $(e.currentTarget);
            const id = $button.data('id');
            $.ajax({
                url: xbNavAjax.ajax_url,
                method: 'POST',
                data: {
                    action: 'xb_nav_get_item',
                    id: id,
                    nonce: xbNavAjax.nonce
                },
                success: (response) => {
                    if (response.success) {
                        const item = response.data;
                        $('#edit-nav-id').val(item.id);
                        $('#edit-nav-name').val(item.name);
                        $('#edit-nav-url').val(item.url);
                        $('#edit-nav-icon').val(item.icon);
                        $('#edit-nav-description').val(item.description);
                        $('#edit-nav-intro-url').val(item.intro_url);
                        $('#edit-nav-category').val(item.category_id);
                        $('#edit-redirect-to-intro').prop('checked', item.redirect_to_intro == 1);
                        $('#edit-nav-order-num').val(item.order_num || 0);
                        $('#edit-is-recommended').prop('checked', item.is_recommended == 1);
                        $('#edit-is-qr-code').prop('checked', item.is_qr_code == 1);
                        $('#xb-nav-edit-modal').show();
                    } else {
                        this.showToast(response.data.message || '获取导航数据失败。');
                    }
                },
                error: () => {
                    this.showToast('请求失败，请检查网络。');
                }
            });
        },

        /**
         * 显示提示消息，3秒后自动隐藏
         */
        showToast: function(message) {
            $('#xb-toast-message').text(message);
            $('#xb-toast').fadeIn();
            setTimeout(() => {
                $('#xb-toast').fadeOut();
            }, 3000);
        }
    };

    /**
     * 页面加载完成后初始化 XBNav
     */
    $(document).ready(function() {
        XBNav.init();
    });

})(jQuery, window, document);