jQuery(document).ready(function($) {
    $('#xb-creative-poster-container').css('visibility', 'hidden');

    function checkCSSLoaded() {
        const cssLoaded = Array.from(document.styleSheets).some(sheet => {
            return sheet.href && sheet.href.includes('xb-creative-poster.css');
        });
        if (cssLoaded) {
            $('#xb-creative-poster-container').css('visibility', 'visible');
        } else {
            setTimeout(checkCSSLoaded, 100);
        }
    }
    checkCSSLoaded();
    
    // 海报生成表单提交
    $('#poster-form').on('submit', function(e) {
        e.preventDefault();
        const formData = $(this).serializeArray();
        const data = {};
        formData.forEach(item => data[item.name] = item.value);

        $.ajax({
            url: xbCreativePoster.ajax_url + '/generate',
            method: 'POST',
            headers: { 'X-WP-Nonce': xbCreativePoster.nonce },
            data: JSON.stringify(data),
            contentType: 'application/json',
            success: function(response) {
                if (response.task_id) {
                    $('#poster-result').html('<div class="xb-title">生成结果</div><p class="xb-loading">' + response.message + '</p>');
                    checkTaskStatus(response.task_id);
                } else {
                    $('#poster-result').html('<div class="xb-title">生成结果</div><p>意外响应: ' + JSON.stringify(response) + '</p>');
                }
            },
            error: function(xhr) {
                const errorMsg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : '未知错误';
                $('#poster-result').html('<div class="xb-title">生成结果</div><p>生成失败: ' + errorMsg + '</p>');
            }
        });
    });

    // 检查任务状态并更新剩余次数
    function checkTaskStatus(taskId) {
        const interval = setInterval(() => {
            $.ajax({
                url: xbCreativePoster.ajax_url + '/check-task/' + taskId,
                method: 'GET',
                headers: { 'X-WP-Nonce': xbCreativePoster.nonce },
                success: function(response) {
                    if (response.status === 'SUCCEEDED') {
                        clearInterval(interval);
                        $('#poster-result').html(
                            '<div class="xb-title">生成结果</div>' +
                            '<div class="xb-result-content">' +
                                '<img src="' + response.image_url + '" alt="Generated Poster" class="xb-result-img">' +
                                '<div class="xb-download-wrapper">' +
                                    '<a href="' + response.image_url + '" class="xb-btn xb-download-btn" data-download>下载海报</a>' +
                                '</div>' +
                            '</div>'
                        );
                        // 更新剩余次数
                        const $remainingCount = $('#xb-remaining-count');
                        let remaining = parseInt($remainingCount.data('remaining')) - 1;
                        if (remaining < 0) remaining = 0; // 防止负数
                        $remainingCount.data('remaining', remaining);
                        $('#remaining-value').text(remaining);
                        if (remaining === 0) {
                            $('#xb-creative-poster-form').html('<div class="xb-title">海报配置</div><p class="xb-limit-notice">今天已经使用完海报生成额度，请明天再来</p>');
                        }
                        bindDownloadEvents();
                    } else if (response.status === 'FAILED') {
                        clearInterval(interval);
                        $('#poster-result').html('<div class="xb-title">生成结果</div><p>海报生成失败: ' + (response.message || '未知错误') + '</p>');
                    }
                },
                error: function(xhr) {
                    clearInterval(interval);
                    $('#poster-result').html('<div class="xb-title">生成结果</div><p>检查任务失败: ' + (xhr.responseJSON.message || '未知错误') + '</p>');
                }
            });
        }, 5000);
    }

    // 登录按钮点击事件
    $('.wp-creative-login-btn').on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });

    // 下载按钮绑定事件
    function bindDownloadEvents() {
        $('.xb-download-btn').off('click').on('click', function(e) {
            e.preventDefault();
            const url = $(this).attr('href');
            const extension = url.split('.').pop().split(/\#|\?/)[0].toLowerCase();
            const validExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            const fileExt = validExtensions.includes(extension) ? extension : 'jpg';
            const fileName = 'poster-' + Date.now() + '.' + fileExt;

            fetch(url, { mode: 'cors' })
                .then(response => {
                    const contentType = response.headers.get('content-type');
                    return response.blob().then(blob => ({ blob, contentType }));
                })
                .then(({ blob, contentType }) => {
                    const link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = fileName;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                })
                .catch(error => console.error('下载失败:', error));
        });
    }

    bindDownloadEvents();

    // 海报展示页面按钮切换和推荐海报中的我的海报按钮
    $('.xb-my-posters-btn, .xb-all-posters-btn').on('click', function(e) {
        e.preventDefault();
        const url = $(this).data('url') || $(this).attr('href');
        
        $('.xb-my-posters-btn, .xb-all-posters-btn').removeClass('active');
        $(this).addClass('active');

        window.location.href = url;
    });
});