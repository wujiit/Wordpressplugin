<?php
/*
Plugin Name: 小半AI海报图片
Description: 基于通义千问AI模型的WordPress创意海报生成插件
Version: 1.2
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 创建数据表
function xb_creative_poster_create_table() {
    global $wpdb;
    
    // 海报记录表
    $poster_table = $wpdb->prefix . 'xb_creative_poster';
    $charset_collate = $wpdb->get_charset_collate();

    $sql_poster = "CREATE TABLE $poster_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        task_id varchar(255) NOT NULL,
        user_id bigint(20) NOT NULL,
        title varchar(30) NOT NULL,
        sub_title varchar(30) DEFAULT '',
        body_text varchar(50) DEFAULT '',
        prompt_text_zh varchar(50) DEFAULT '',
        prompt_text_en varchar(50) DEFAULT '',
        style varchar(50) DEFAULT '',
        layout varchar(50) DEFAULT '',
        mode varchar(50) DEFAULT 'generate',
        image_url text DEFAULT '',
        status varchar(50) DEFAULT 'PENDING',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";
    
    // 用户限额表
    $limit_table = $wpdb->prefix . 'xb_creative_poster_limits';
    $sql_limit = "CREATE TABLE $limit_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        daily_limit int NOT NULL DEFAULT 0,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_poster);
    dbDelta($sql_limit);
}
register_activation_hook(__FILE__, 'xb_creative_poster_create_table');

// 创建生成页面
function xb_creative_poster_create_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_creative_poster_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        wp_insert_post(array(
            'post_title'    => '创意海报生成',
            'post_content'  => '[xb_creative_poster_form]',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        ));
    }
}
register_activation_hook(__FILE__, 'xb_creative_poster_create_page');

// 创建展示页面
function xb_creative_poster_create_gallery_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_creative_poster_gallery]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        wp_insert_post(array(
            'post_title'    => '海报展示',
            'post_content'  => '[xb_creative_poster_gallery]',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        ));
    }
}
register_activation_hook(__FILE__, 'xb_creative_poster_create_gallery_page');

// 插件列表页面添加设置入口
function xb_creative_poster_add_settings_link($links) {
    $settings_link = '<a href="admin.php?page=xb-creative-poster">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'xb_creative_poster_add_settings_link');

// 添加菜单和子菜单
add_action('admin_menu', 'xb_creative_poster_menu');
function xb_creative_poster_menu() {
    add_menu_page(
        '创意海报设置',
        '创意海报',
        'manage_options',
        'xb-creative-poster',
        'xb_creative_poster_settings_page',
        'dashicons-format-gallery'
    );
    add_submenu_page(
        'xb-creative-poster',
        '海报生成记录',
        '生成记录',
        'manage_options',
        'xb-creative-poster-records',
        'xb_creative_poster_records_page'
    );
}

// 设置页面
function xb_creative_poster_settings_page() {
    if (isset($_POST['xb_creative_poster_save'])) {
        update_option('xb_creative_poster_api_url', sanitize_text_field($_POST['api_url']));
        update_option('xb_creative_poster_api_key', sanitize_text_field($_POST['api_key']));
        update_option('xb_creative_poster_model_params', sanitize_text_field($_POST['model_params']));
        update_option('xb_creative_poster_styles', sanitize_text_field($_POST['styles']));
        update_option('xb_creative_poster_layouts', sanitize_text_field($_POST['layouts']));
        update_option('xb_creative_poster_modes', sanitize_text_field($_POST['modes']));
        update_option('xb_creative_poster_notice', wp_kses_post($_POST['notice']));
        update_option('xb_creative_poster_daily_limit', intval($_POST['daily_limit']));
        update_option('xb_creative_poster_show_stats', isset($_POST['show_stats']) ? 1 : 0);
        echo '<div class="updated xb-notice"><p>设置已保存</p></div>';
    }
    ?>
    <div class="wrap">
        <div class="xb-title">创意海报设置</div>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>API 接口地址</th>
                    <td><input type="text" name="api_url" value="<?php echo esc_attr(get_option('xb_creative_poster_api_url', 'https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis')); ?>" size="50"></td>
                </tr>
                <tr>
                    <th>API Key</th>
                    <td><input type="text" name="api_key" value="<?php echo esc_attr(get_option('xb_creative_poster_api_key')); ?>" size="50"></td>
                </tr>
                <tr>
                    <th>模型参数</th>
                    <td><input type="text" name="model_params" value="<?php echo esc_attr(get_option('xb_creative_poster_model_params', 'wanx-poster-generation-v1')); ?>" size="50">（多个用逗号分隔，默认调用第一个）</td>
                </tr>
                <tr>
                    <th>海报风格</th>
                    <td><input type="text" name="styles" value="<?php echo esc_attr(get_option('xb_creative_poster_styles', '浩瀚星云,童话油画,真实场景')); ?>" size="50">（多个用逗号分隔，2D插画1, 2D插画2,浩瀚星云等）</td>
                </tr>
                <tr>
                    <th>海报版式</th>
                    <td><input type="text" name="layouts" value="<?php echo esc_attr(get_option('xb_creative_poster_layouts', '竖版,横版')); ?>" size="50">（多个用逗号分隔）</td>
                </tr>
                <tr>
                    <th>海报模式</th>
                    <td><input type="text" name="modes" value="<?php echo esc_attr(get_option('xb_creative_poster_modes', 'generate,sr,hrf')); ?>" size="50">（多个用逗号分隔）</td>
                </tr>
                <tr>
                    <th>每日生成限额</th>
                    <td><input type="number" name="daily_limit" value="<?php echo esc_attr(get_option('xb_creative_poster_daily_limit', 10)); ?>" min="1" size="10">（每位用户每天最多生成海报数量）</td>
                </tr>
                <tr>
                    <th>前台显示海报统计</th>
                    <td><input type="checkbox" name="show_stats" value="1" <?php checked(get_option('xb_creative_poster_show_stats', 0), 1); ?>> 是否在海报展示页面显示总生成数量</td>
                </tr>
                <tr>
                    <th>公告内容</th>
                    <td><textarea name="notice" rows="5" cols="50"><?php echo esc_textarea(get_option('xb_creative_poster_notice')); ?></textarea><p>支持 HTML 格式</p></td>
                </tr>
            </table>
            <p><input type="submit" name="xb_creative_poster_save" class="button-primary" value="保存设置"></p>
        </form>
        由阿里通义千问模型提供：https://help.aliyun.com/zh/model-studio/user-guide/creative-poster-generation<br>
        单价：暂时免费
    </div>
    <script>
        jQuery(document).ready(function($) {
            setTimeout(function() {
                $('.xb-notice').fadeOut(500);
            }, 3000);
        });
    </script>
    <?php
}

// 生成记录页面
function xb_creative_poster_records_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_creative_poster';
    $limit_table = $wpdb->prefix . 'xb_creative_poster_limits';

    // 处理删除操作
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $wpdb->delete($table_name, array('id' => $id));
        echo '<div class="updated xb-notice"><p>记录已删除</p></div>';
    }

    // 处理限额更新
    if (isset($_POST['update_user_limit']) && isset($_POST['user_id']) && isset($_POST['daily_limit'])) {
        $user_id = intval($_POST['user_id']);
        $daily_limit = max(0, intval($_POST['daily_limit'])); // 确保限额不小于0
        
        $wpdb->replace(
            $limit_table,
            array(
                'user_id' => $user_id,
                'daily_limit' => $daily_limit
            ),
            array('%d', '%d')
        );
        echo '<div class="updated xb-notice"><p>用户限额已更新</p></div>';
    }

    $where = '';
    $user_id = 0;
    $today_count = 0; // 当天生成次数
    if (isset($_GET['user_id']) && !empty($_GET['user_id'])) {
        $user_id = intval($_GET['user_id']);
        $where = $wpdb->prepare("WHERE user_id = %d", $user_id);
        
        // 查询当天生成次数
        $today = date('Y-m-d');
        $today_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(created_at) = %s",
            $user_id,
            $today
        ));
    }

    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
    $records = $wpdb->get_results("SELECT * FROM $table_name $where ORDER BY created_at DESC");
    
    // 获取用户自定义限额
    $user_limit = $user_id ? $wpdb->get_var($wpdb->prepare(
        "SELECT daily_limit FROM $limit_table WHERE user_id = %d", 
        $user_id
    )) : null;
    $default_limit = get_option('xb_creative_poster_daily_limit', 10);
    $current_limit = ($user_limit !== null && $user_limit > 0) ? $user_limit : $default_limit;
    ?>
    <div class="wrap">
        <div class="xb-title">海报生成记录</div>
        <div style="margin-bottom: 20px;">
            <p>总共生成海报数量：<?php echo esc_html($total); ?></p>
            <form method="get" action="" style="display: inline;">
                <input type="hidden" name="page" value="xb-creative-poster-records">
                <label>查询用户ID：<input type="number" name="user_id" value="<?php echo isset($_GET['user_id']) ? esc_attr($_GET['user_id']) : ''; ?>" min="1"></label>
                <input type="submit" value="查询" class="button">
            </form>
            <a href="<?php echo admin_url('admin.php?page=xb-creative-poster-records'); ?>" class="button" style="margin-left: 10px;">全部记录</a>
            
            <?php if ($user_id): ?>
                <div style="margin-top: 10px;">
                    <p>今日已生成：<?php echo esc_html($today_count); ?> 张 / 限额 <?php echo esc_html($current_limit); ?> 张</p>
                    <form method="post" action="" style="display: inline;">
                        <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">
                        <label>每日限额：
                            <input type="number" name="daily_limit" value="<?php echo esc_attr($current_limit); ?>" min="0" style="width: 80px;">
                        </label>
                        <input type="submit" name="update_user_limit" value="更新限额" class="button">
                        <small>(默认: <?php echo esc_html($default_limit); ?>，设为0使用默认值)</small>
                    </form>
                </div>
            <?php endif; ?>
        </div>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户ID</th>
                    <th>用户名称</th>
                    <th>海报标题</th>
                    <th>预览图</th>
                    <th>生成时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record) : ?>
                    <tr>
                        <td><?php echo esc_html($record->user_id); ?></td>
                        <td><?php echo esc_html(get_userdata($record->user_id)->user_login); ?></td>
                        <td><?php echo esc_html($record->title); ?></td>
                        <td><?php if ($record->image_url) : ?><img src="<?php echo esc_url($record->image_url); ?>" class="xb-preview-img" alt="Preview" style="width: 100px; height: 100px;"><?php endif; ?></td>
                        <td><?php echo esc_html($record->created_at); ?></td>
                        <td><a href="<?php echo admin_url('admin.php?page=xb-creative-poster-records&action=delete&id=' . $record->id . (isset($_GET['user_id']) ? '&user_id=' . esc_attr($_GET['user_id']) : '')); ?>" onclick="return confirm('确定删除此记录？');" class="button button-small">删除</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script>
        jQuery(document).ready(function($) {
            setTimeout(function() {
                $('.xb-notice').fadeOut(500);
            }, 3000);
        });
    </script>
    <?php
}

// 获取展示页面链接
function xb_get_gallery_page_url() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_creative_poster_gallery]',
        'numberposts' => 1,
    ));
    return !empty($pages) ? get_permalink($pages[0]->ID) : '#';
}

// 预加载 CSS
add_action('wp_head', 'xb_creative_poster_preload_assets');
function xb_creative_poster_preload_assets() {
    global $post;
    if (isset($post->post_content) && (has_shortcode($post->post_content, 'xb_creative_poster_form') || has_shortcode($post->post_content, 'xb_creative_poster_gallery'))) {
        echo '<link rel="preload" href="https://img.qiyucloud.com/cloud/xb-creative-poster/xb-creative-poster.css" as="style" onload="this.rel=\'stylesheet\'">' . "\n";
    }
}

// 加载 JS 和 CSS 的公共函数
function xb_creative_poster_load_assets() {
    wp_enqueue_style('xb_creative_poster-css', 'https://img.qiyucloud.com/cloud/xb-creative-poster/xb-creative-poster.css');
    wp_enqueue_script('xb-creative-poster-js', 'https://img.qiyucloud.com/cloud/xb-creative-poster/xb-creative-poster.js', ['jquery'], '1.2', true);

    //wp_enqueue_script('xb-creative-poster-js', plugin_dir_url(__FILE__) . 'xb-creative-poster.js', array('jquery'), '1.0', true);
    //wp_enqueue_style('xb_creative_poster-css', plugin_dir_url(__FILE__) . 'xb-creative-poster.css');

    wp_localize_script('xb-creative-poster-js', 'xbCreativePoster', array(
        'ajax_url' => rest_url('xb-creative-poster/v1'),
        'nonce' => wp_create_nonce('wp_rest'),
        'gallery_url' => xb_get_gallery_page_url()
    ));
}

// 检查用户每日生成限额
function xb_creative_poster_check_daily_limit($user_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_creative_poster';
    $limit_table = $wpdb->prefix . 'xb_creative_poster_limits';
    
    // 获取用户自定义限额
    $user_limit = $wpdb->get_var($wpdb->prepare(
        "SELECT daily_limit FROM $limit_table WHERE user_id = %d",
        $user_id
    ));
    
    // 如果没有自定义限额或限额为0，使用默认值
    $daily_limit = ($user_limit !== null && $user_limit > 0) ? 
        $user_limit : 
        get_option('xb_creative_poster_daily_limit', 10);
    
    $today = date('Y-m-d');
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(created_at) = %s",
        $user_id,
        $today
    ));
    
    return $count < $daily_limit;
}

// 计算今日剩余次数
function xb_creative_poster_get_remaining_count($user_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_creative_poster';
    $limit_table = $wpdb->prefix . 'xb_creative_poster_limits';

    // 获取用户自定义限额
    $user_limit = $wpdb->get_var($wpdb->prepare(
        "SELECT daily_limit FROM $limit_table WHERE user_id = %d",
        $user_id
    ));
    $daily_limit = ($user_limit !== null && $user_limit > 0) ? $user_limit : get_option('xb_creative_poster_daily_limit', 10);

    // 计算今日已使用次数
    $today = date('Y-m-d');
    $used_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(created_at) = %s",
        $user_id,
        $today
    ));

    return max(0, $daily_limit - $used_count); // 确保不会返回负数
}

// 生成页面短代码
add_shortcode('xb_creative_poster_form', 'xb_creative_poster_form_shortcode');
function xb_creative_poster_form_shortcode() {
    global $wpdb, $post;
    if (!isset($post->post_content) || !has_shortcode($post->post_content, 'xb_creative_poster_form')) {
        return '';
    }

    xb_creative_poster_load_assets();

    $recommended = $wpdb->get_results("SELECT image_url FROM {$wpdb->prefix}xb_creative_poster WHERE image_url != '' ORDER BY RAND() LIMIT 20");

    ob_start();

    if (!is_user_logged_in()) {
        // 游客模式：保持不变
        ?>
        <div id="xb-creative-poster-container">
            <div id="xb-creative-poster-login-notice">
                <div class="xb-title">请先登录</div>
                <p>请登录以使用AI创意海报生成功能。</p>
                <a href="<?php echo wp_login_url(get_permalink()); ?>" class="wp-creative-login-btn xb-btn">立即登录</a>
            </div>
            <div id="xb-recommended-posters">
                <div class="xb-recommended-header">
                    <div class="xb-title">推荐海报</div>
                </div>
                <div class="xb-recommended-grid">
                    <?php foreach ($recommended as $poster) : ?>
                        <div class="xb-poster-item">
                            <a href="<?php echo esc_url($poster->image_url); ?>" data-fancybox="recommended">
                                <img src="<?php echo esc_url($poster->image_url); ?>" alt="Recommended Poster" class="xb-recommended-img">
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    } else {
        // 登录用户模式
        $styles = explode(',', get_option('xb_creative_poster_styles', '浩瀚星云,童话油画,真实场景'));
        $layouts = explode(',', get_option('xb_creative_poster_layouts', '竖版,横版'));
        $modes = explode(',', get_option('xb_creative_poster_modes', 'generate,sr,hrf'));
        $notice = get_option('xb_creative_poster_notice');
        $user_id = get_current_user_id();
        $can_generate = xb_creative_poster_check_daily_limit($user_id);
        $remaining_count = xb_creative_poster_get_remaining_count($user_id);
        $daily_limit = ($wpdb->get_var($wpdb->prepare("SELECT daily_limit FROM {$wpdb->prefix}xb_creative_poster_limits WHERE user_id = %d", $user_id)) ?: get_option('xb_creative_poster_daily_limit', 10));
        ?>
        <div id="xb-creative-poster-container">
            <div id="xb-creative-poster-main">
                <div id="xb-creative-poster-form">
                    <div class="xb-title">海报配置</div>
                    <?php if (!$can_generate) : ?>
                        <p class="xb-limit-notice">今天已经使用完海报生成额度，请明天再来</p>
                    <?php else : ?>
                        <form id="poster-form">
                            <p><label>主标题（必填，最多30个字符）<input type="text" name="title" maxlength="30" required placeholder="例如：春节快乐"></label></p>
                            <p><label>副标题（可选，最多30个字符）<input type="text" name="sub_title" maxlength="30" placeholder="例如：家庭团聚，共享天伦之乐"></label></p>
                            <p><label>正文（可选，最多50个字符）<input type="text" name="body_text" maxlength="50" placeholder="例如：春节是中国最重要的传统节日之一"></label></p>
                            <p><label>海报背景元素中文提示词（可选）<input type="text" name="prompt_text_zh" maxlength="50" placeholder="例如：小朋友画的可爱的龙"></label></p>
                            <p><label>海报背景元素英文提示词（可选）<input type="text" name="prompt_text_en" maxlength="50" placeholder="例如：Cute dragon drawn by kids"></label></p>
                            <p class="prompt-note">* 中文或英文提示词至少填写一个，总字符数不超过50个字或单词</p>
                            <p class="xb-options-row">
                                <label>海报风格<select name="style"><?php foreach ($styles as $style) { echo '<option value="' . trim($style) . '">' . trim($style) . '</option>'; } ?></select></label>
                                <label>海报版式<select name="layout"><?php foreach ($layouts as $layout) { echo '<option value="' . trim($layout) . '">' . trim($layout) . '</option>'; } ?></select></label>
                                <label>海报模式<select name="mode">
                                    <?php 
                                    $mode_labels = ['generate' => '默认', 'sr' => '高分辨率', 'hrf' => '高清修复'];
                                    foreach ($modes as $mode) { 
                                        $mode = trim($mode);
                                        echo '<option value="' . $mode . '">' . ($mode_labels[$mode] ?? $mode) . '</option>'; 
                                    } 
                                    ?>
                                </select></label>
                            </p>
                            <p><button type="submit" class="xb-btn">生成海报</button></p>
                        </form>
                    <?php endif; ?>
                </div>
                <div id="poster-result">
                    <div class="xb-title">海报结果</div>
                    <p>请提交配置以生成海报</p>
                </div>
            </div>
            <!-- 将剩余次数和公告移到这里 -->
            <div id="xb-remaining-count" data-remaining="<?php echo esc_attr($remaining_count); ?>" data-limit="<?php echo esc_attr($daily_limit); ?>">
                今日剩余海报次数: <span id="remaining-value"><?php echo esc_html($remaining_count); ?></span>/<?php echo esc_html($daily_limit); ?>
            </div>
            <?php if (!empty($notice) || !$can_generate) : ?>
                <div id="xb-poster-notice">
                    <?php 
                    if (!$can_generate) {
                        echo '<p>今天已经使用完海报生成额度，请明天再来</p>';
                    }
                    echo wp_kses_post($notice); 
                    ?>
                </div>
            <?php endif; ?>
            <div id="xb-recommended-posters">
                <div class="xb-recommended-header">
                    <div class="xb-title">推荐海报</div>
                    <a href="<?php echo esc_url(xb_get_gallery_page_url()); ?>?my_posters=1" class="xb-btn xb-my-posters-btn">我的海报</a>
                </div>
                <div class="xb-recommended-grid">
                    <?php foreach ($recommended as $poster) : ?>
                        <div class="xb-poster-item">
                            <a href="<?php echo esc_url($poster->image_url); ?>" data-fancybox="recommended">
                                <img src="<?php echo esc_url($poster->image_url); ?>" alt="Recommended Poster" class="xb-recommended-img">
                            </a>
                            <a href="<?php echo esc_url($poster->image_url); ?>" class="xb-btn xb-download-btn" data-download>下载海报</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    }

    return ob_get_clean();
}

// 展示页面短代码
add_shortcode('xb_creative_poster_gallery', 'xb_creative_poster_gallery_shortcode');
function xb_creative_poster_gallery_shortcode() {
    global $wpdb, $post;
    if (!isset($post->post_content) || !has_shortcode($post->post_content, 'xb_creative_poster_gallery')) {
        return '';
    }

    xb_creative_poster_load_assets();

    $table_name = $wpdb->prefix . 'xb_creative_poster';
    $per_page = 20;
    $paged = max(1, get_query_var('paged') ? get_query_var('paged') : (isset($_GET['paged']) ? intval($_GET['paged']) : 1));
    $offset = ($paged - 1) * $per_page;

    $is_my_posters = isset($_GET['my_posters']) && $_GET['my_posters'] == 1 && is_user_logged_in();
    $where = $is_my_posters ? "WHERE user_id = " . get_current_user_id() . " AND image_url != ''" : "WHERE image_url != ''";
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
    $total_all = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE image_url != ''");
    $posters = $wpdb->get_results("SELECT image_url FROM $table_name $where ORDER BY created_at DESC LIMIT $offset, $per_page");
    $show_stats = get_option('xb_creative_poster_show_stats', 0);

    ob_start();
    ?>
    <div id="xb-creative-poster-container">
        <div class="xb-title"><?php echo $is_my_posters ? '我的海报' : '海报展示'; ?></div>
        <div class="xb-gallery-controls">
            <?php if (is_user_logged_in()) : ?>
                <button class="xb-btn xb-my-posters-btn <?php echo $is_my_posters ? 'active' : ''; ?>" data-url="<?php echo esc_url(xb_get_gallery_page_url() . '?my_posters=1'); ?>">我的海报</button>
                <button class="xb-btn xb-all-posters-btn <?php echo !$is_my_posters ? 'active' : ''; ?>" data-url="<?php echo esc_url(xb_get_gallery_page_url()); ?>">全部海报</button>
            <?php else : ?>
                <button class="xb-btn xb-all-posters-btn active" data-url="<?php echo esc_url(xb_get_gallery_page_url()); ?>">全部海报</button>
            <?php endif; ?>
        </div>
        <div class="xb-gallery-grid">
            <?php foreach ($posters as $poster) : ?>
                <div class="xb-poster-item">
                    <a href="<?php echo esc_url($poster->image_url); ?>" data-fancybox="gallery">
                        <img src="<?php echo esc_url($poster->image_url); ?>" alt="Poster" class="xb-gallery-img">
                    </a>
                    <?php if (is_user_logged_in()) : ?>
                        <a href="<?php echo esc_url($poster->image_url); ?>" class="xb-btn xb-download-btn" data-download>下载海报</a>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
        echo paginate_links(array(
            'base' => add_query_arg('paged', '%#%'),
            'format' => '?paged=%#%',
            'current' => $paged,
            'total' => ceil($total / $per_page),
            'prev_text' => '« 上一页',
            'next_text' => '下一页 »',
        ));
        ?>
        <?php if ($show_stats) : ?>
            <div class="xb-stats-footer">
                <p>总共生成海报数量：<?php echo esc_html($total_all); ?></p>
            </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

// 注册 REST API
add_action('rest_api_init', 'xb_creative_poster_register_api');
function xb_creative_poster_register_api() {
    register_rest_route('xb-creative-poster/v1', '/generate', array(
        'methods' => 'POST',
        'callback' => 'xb_creative_poster_generate',
        'permission_callback' => function() { return is_user_logged_in(); }
    ));

    register_rest_route('xb-creative-poster/v1', '/check-task/(?P<task_id>[a-zA-Z0-9-]+)', array(
        'methods' => 'GET',
        'callback' => 'xb_creative_poster_check_task',
        'permission_callback' => function() { return is_user_logged_in(); }
    ));
}

// 日志记录函数
function xb_creative_poster_log($message) {
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log("[xb_creative_poster] $message");
    }
}

// 保存图片到媒体库
function xb_save_image_to_media_library($image_url, $title) {
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    $tmp = download_url($image_url);
    if (is_wp_error($tmp)) {
        xb_creative_poster_log("下载图片失败: " . $tmp->get_error_message());
        return false;
    }

    // 获取原始文件扩展名
    $path_info = pathinfo($image_url);
    $extension = isset($path_info['extension']) ? strtolower($path_info['extension']) : 'jpg';
    // 验证有效的图片扩展名
    $valid_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $extension = in_array($extension, $valid_extensions) ? $extension : 'jpg';

    $file_array = array(
        'name' => sanitize_file_name($title) . '-' . time() . '.' . $extension,
        'tmp_name' => $tmp
    );

    $id = media_handle_sideload($file_array, 0, $title);
    if (is_wp_error($id)) {
        @unlink($tmp);
        xb_creative_poster_log("保存图片到媒体库失败: " . $id->get_error_message());
        return false;
    }

    return wp_get_attachment_url($id);
}

function xb_creative_poster_generate($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_creative_poster';
    $user_id = get_current_user_id();

    if (!xb_creative_poster_check_daily_limit($user_id)) {
        return new WP_Error('daily_limit_exceeded', '今天已达到海报生成限额，请明天再试', array('status' => 403));
    }

    $params = $request->get_params();
    $title = sanitize_text_field($params['title'] ?? '');
    $sub_title = sanitize_text_field($params['sub_title'] ?? '');
    $body_text = sanitize_text_field($params['body_text'] ?? '');
    $prompt_text_zh = sanitize_text_field($params['prompt_text_zh'] ?? '');
    $prompt_text_en = sanitize_text_field($params['prompt_text_en'] ?? '');
    $style = sanitize_text_field($params['style'] ?? '');
    $layout = sanitize_text_field($params['layout'] ?? '竖版');
    $mode = sanitize_text_field($params['mode'] ?? 'generate');

    // 定义通义千问支持的风格列表
    $valid_styles = [
        '2D插画1', '2D插画2', '浩瀚星云', '浓郁色彩', '光线粒子', '透明玻璃', 
        '剪纸工艺', '折纸工艺', '中国水墨', '中国刺绣', '真实场景', '2D卡通', 
        '儿童水彩', '赛博背景', '浅蓝抽象', '深蓝抽象', '抽象点线', '童话油画'
    ];

    // 校验输入参数
    if (empty($title) || mb_strlen($title, 'UTF-8') > 30) {
        $error = "Invalid title: '$title' (must be non-empty and <= 30 chars)";
        xb_creative_poster_log($error);
        return new WP_Error('invalid_title', $error, array('status' => 400));
    }
    if (!empty($sub_title) && mb_strlen($sub_title, 'UTF-8') > 30) {
        $error = "Invalid sub_title: '$sub_title' (<= 30 chars)";
        xb_creative_poster_log($error);
        return new WP_Error('invalid_sub_title', $error, array('status' => 400));
    }
    if (!empty($body_text) && mb_strlen($body_text, 'UTF-8') > 50) {
        $error = "Invalid body_text: '$body_text' (<= 50 chars)";
        xb_creative_poster_log($error);
        return new WP_Error('invalid_body_text', $error, array('status' => 400));
    }
    $prompt_total_length = mb_strlen($prompt_text_zh, 'UTF-8') + mb_strlen($prompt_text_en, 'UTF-8');
    if (empty($prompt_text_zh) && empty($prompt_text_en)) {
        $error = "Prompt missing: At least one of prompt_text_zh or prompt_text_en must be filled";
        xb_creative_poster_log($error);
        return new WP_Error('invalid_prompt', $error, array('status' => 400));
    }
    if ($prompt_total_length > 50) {
        $error = "Prompt too long: Total length of prompt_text_zh ('$prompt_text_zh') and prompt_text_en ('$prompt_text_en') exceeds 50 chars";
        xb_creative_poster_log($error);
        return new WP_Error('invalid_prompt_length', $error, array('status' => 400));
    }
    if (!in_array($mode, ['generate', 'sr', 'hrf'])) {
        $error = "Invalid mode: '$mode' (must be generate, sr, or hrf)";
        xb_creative_poster_log($error);
        return new WP_Error('invalid_mode', $error, array('status' => 400));
    }
    if (!in_array($style, $valid_styles)) {
        $error = "Invalid style: '$style' (must be one of " . implode(', ', $valid_styles) . ")";
        xb_creative_poster_log($error);
        return new WP_Error('invalid_style', $error, array('status' => 400));
    }

    $data = array(
        'user_id' => $user_id,
        'task_id' => '',
        'title' => $title,
        'sub_title' => $sub_title,
        'body_text' => $body_text,
        'prompt_text_zh' => $prompt_text_zh,
        'prompt_text_en' => $prompt_text_en,
        'style' => $style,
        'layout' => $layout,
        'mode' => $mode,
    );

    $api_url = get_option('xb_creative_poster_api_url', 'https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis');
    $api_key = get_option('xb_creative_poster_api_key');
    $model = explode(',', get_option('xb_creative_poster_model_params', 'wanx-poster-generation-v1'))[0];

    if (empty($api_key)) {
        $error = "API Key is missing";
        xb_creative_poster_log($error);
        return new WP_Error('api_config_error', $error, array('status' => 500));
    }

    $body = array(
        'model' => $model,
        'input' => array(
            'title' => $data['title'],
            'sub_title' => $data['sub_title'],
            'body_text' => $data['body_text'],
            'prompt_text_zh' => $data['prompt_text_zh'],
            'prompt_text_en' => $data['prompt_text_en'],
            'wh_ratios' => $data['layout'],
            'lora_name' => $data['style'], // 已经过验证，确保合法
            'lora_weight' => 0.8,
            'ctrl_ratio' => 0.7,
            'ctrl_step' => 0.7,
            'generate_mode' => $data['mode'],
            'generate_num' => 1
        ),
        'parameters' => new stdClass()
    );

    $headers = array(
        'X-DashScope-Async' => 'enable',
        'Content-Type' => 'application/json',
        'Authorization' => 'Bearer ' . $api_key
    );

    xb_creative_poster_log("API Request URL: $api_url");
    xb_creative_poster_log("API Request Headers: " . json_encode($headers));
    xb_creative_poster_log("API Request Body: " . json_encode($body, JSON_UNESCAPED_UNICODE));

    $response = wp_remote_post($api_url, array(
        'headers' => $headers,
        'body' => json_encode($body, JSON_UNESCAPED_UNICODE),
        'timeout' => 30,
        'sslverify' => true
    ));

    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        xb_creative_poster_log("API Request Failed: $error_message");
        return new WP_Error('api_error', "API 请求失败: $error_message", array('status' => 500));
    }

    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = json_decode(wp_remote_retrieve_body($response), true);

    xb_creative_poster_log("API Response Code: $response_code");
    xb_creative_poster_log("API Response Body: " . json_encode($response_body));

    if ($response_code !== 200) {
        $error_message = $response_body['output']['message'] ?? '未知错误';
        $error_code = $response_body['output']['code'] ?? 'Unknown';
        xb_creative_poster_log("API Error - Code: $error_code, Message: $error_message");
        return new WP_Error('api_error', "API 返回错误: $error_message (Code: $error_code)", array('status' => $response_code));
    }

    if (!isset($response_body['output']['task_id'])) {
        $error_message = "API 响应中缺少 task_id: " . json_encode($response_body);
        xb_creative_poster_log($error_message);
        return new WP_Error('api_error', "API 响应异常: 缺少 task_id", array('status' => 500));
    }

    $data['task_id'] = $response_body['output']['task_id'];
    $insert_result = $wpdb->insert($table_name, $data);
    if ($insert_result === false) {
        $db_error = $wpdb->last_error;
        xb_creative_poster_log("Database Insert Failed: $db_error");
        return new WP_Error('db_error', "数据库保存失败: $db_error", array('status' => 500));
    }

    xb_creative_poster_log("Task Created Successfully: " . $data['task_id']);
    return array(
        'task_id' => $data['task_id'], 
        'message' => '<div class="xb-loading"><span class="xb-loading-text">请耐心等待2-5分钟，正在生成中</span></div>'
    );
}

function xb_creative_poster_check_task($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_creative_poster';
    $task_id = $request['task_id'];

    $api_key = get_option('xb_creative_poster_api_key');
    $check_url = 'https://dashscope.aliyuncs.com/api/v1/tasks/' . $task_id;

    xb_creative_poster_log("Checking Task: $task_id");

    $response = wp_remote_get($check_url, array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key
        ),
        'timeout' => 30,
        'sslverify' => true
    ));

    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        xb_creative_poster_log("Task Check Failed (Task ID: $task_id): $error_message");
        return new WP_Error('api_error', "检查任务失败: $error_message", array('status' => 500));
    }

    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = json_decode(wp_remote_retrieve_body($response), true);

    xb_creative_poster_log("Task Check Response (Task ID: $task_id, Code: $response_code): " . json_encode($response_body));

    $status = $response_body['output']['task_status'] ?? 'UNKNOWN';

    if ($status === 'SUCCEEDED' && isset($response_body['output']['render_urls'][0])) {
        $remote_image_url = $response_body['output']['render_urls'][0];
        $title = $wpdb->get_var($wpdb->prepare("SELECT title FROM $table_name WHERE task_id = %s", $task_id));
        $local_image_url = xb_save_image_to_media_library($remote_image_url, $title);
        $image_url = $local_image_url ?: $remote_image_url;
        $wpdb->update($table_name, array('image_url' => $image_url, 'status' => 'SUCCEEDED'), array('task_id' => $task_id));
        xb_creative_poster_log("Task Succeeded (Task ID: $task_id): Image URL = $image_url");
        return array('status' => 'SUCCEEDED', 'image_url' => $image_url);
    } elseif ($status === 'FAILED') {
        $error_message = $response_body['output']['message'] ?? '未知错误';
        xb_creative_poster_log("Task Failed (Task ID: $task_id): $error_message");
        $wpdb->update($table_name, array('status' => 'FAILED'), array('task_id' => $task_id));
        return array('status' => 'FAILED', 'message' => $error_message);
    }

    return array('status' => $status);
}
?>