<?php
/*
Plugin Name: 自定义SEO设置
Plugin URI: https://www.jingxialai.com/4611.html
Description: 自定义SEO信息，支持WooCommerce产品页面，支持提交到百度站长平台。
Version: 1.2
Author: summer
Author URI: https://www.jingxialai.com
*/

if (!defined('ABSPATH')) {
    exit;
}

// 添加到设置菜单里面
add_action('admin_menu', 'wp_zdy_seo_menu');
function wp_zdy_seo_menu(){
    add_options_page( '自定义SEO设置', 'SEO 设置', 'manage_options', 'wp-zdy-seo-settings', 'wp_zdy_seo_settings_page' );
}

// 设置链接回调函数
function wp_zdy_seo_settings_link($links) {
    $settings_link = '<a href="options-general.php?page=wp-zdy-seo-settings">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}
// 设置入口
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wp_zdy_seo_settings_link');



add_action('admin_head', 'wp_zdy_custom_seo_styles');
function wp_zdy_custom_seo_styles() {
    if (isset($_GET['page']) && $_GET['page'] === 'wp-zdy-seo-settings') {
        ?>
        <style>
            body {
                color: #333;
                background-color: #f5f5f5;
                margin: 0;
                padding: 0;
            }
            .wp_zdy_seo {
                 max-width: 95%;
                margin: 20px auto;
                background-color: #fff;
                padding: 20px;
                border-radius: 5px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }
            .wp_zdy_seo_table {
                width: 50%;
                border-collapse: collapse;
                border-spacing: 0;
            }
            .wp_zdy_seo_table th,
            .wp_zdy_seo_table td {
                padding: 8px;
                border: 1px solid #ddd;
                text-align: left;
            }
            .wp_zdy_seo_table th {
                background-color: #f2f2f2;
                font-weight: bold;
            }
            .wp-list-table {
                    max-width: 700px;
            }
            .wp-list-table th:nth-child(1),
            .wp-list-table td:nth-child(1) {
                width: 500px;
            }
            .wp-list-table th:nth-child(2),
            .wp-list-table td:nth-child(2) {
                width: 100px;
            }
            .wp_zdy_seo_list {
                width: 700px;
                border-collapse: collapse;
            }

        </style>
        <?php
    }
}


// 设置页面
function wp_zdy_seo_settings_page(){
    if (!current_user_can('manage_options')) {
        wp_die('您无权限访问这个页面');
    }
    ?>
    <div class="wp_zdy_seo">
        <h2>自定义SEO设置</h2>
        <form method="post" action="options.php">
            <?php settings_fields( 'wp-zdy-seo-settings-group' ); ?>
            <?php do_settings_sections( 'wp-zdy-seo-settings-group' ); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">网站标题:</th>
                    <td><input type="text" name="website_title" value="<?php echo esc_attr( get_option('website_title') ); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">网站副标题:</th>
                    <td><input type="text" name="website_subtitle" value="<?php echo esc_attr( get_option('website_subtitle') ); ?>" style="width: 350px;" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">标题连接符:</th>
                    <td><input type="text" name="title_separator" value="<?php echo esc_attr( get_option('title_separator') ); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">网站描述:</th>
                    <td><textarea name="website_description" rows="4" cols="50"><?php echo esc_attr( get_option('website_description') ); ?></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row">网站关键词:</th>
                    <td><textarea name="website_keywords" rows="2" cols="50"><?php echo esc_attr( get_option('website_keywords') ); ?></textarea></td>
                </tr>

                <tr valign="top">
                    <th scope="row">启用自定义SEO:</th>
                    <td><input type="checkbox" name="enable_wp_zdy_seo" <?php if(get_option('enable_wp_zdy_seo')) echo "checked='checked'"; ?> /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>

        <div class="wp_zdy_seo">
        <form method="post" action="options.php">
            <?php settings_fields('wp_zdy_baidu_auto_submit_settings_group'); ?>
            <?php do_settings_sections('baidu-auto-submit-settings'); ?>
            <?php submit_button(); ?>
        </form>

        <h2>最新10个页面链接的提交反馈(新网站一般一天就1、2条链接权限)</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>链接URL</th>
                    <th>反馈</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // 查询
                $recent_posts = new WP_Query(array(
                    'post_type' => 'any',
                    'posts_per_page' => 10,
                    'orderby' => 'post_date',
                    'order' => 'DESC',
                ));

                // 获取反馈
                while ($recent_posts->have_posts()) {
                    $recent_posts->the_post();
                    $post_url = get_permalink();
                    $submission_result = get_post_meta(get_the_ID(), 'wp_zdy_baidu_auto_submit_result', true);
                    $feedback = '';
                    if ($submission_result && isset($submission_result['success']) && $submission_result['success'] > 0) {
                        $feedback = '成功';
                    } elseif ($submission_result && isset($submission_result['message']) && $submission_result['message'] == 'over quota') {
                        $feedback = '超过每日配额';
                    } elseif ($submission_result) {
                        $feedback = '错误：' . $submission_result['error'] . ', 信息：' . $submission_result['message'];
                    }
                    echo "<tr><td>$post_url</td><td>$feedback</td></tr>";
                }
                wp_reset_postdata();
                ?>
            </tbody>
        </table>
        <p>具体错误反馈提示：</p>
<table class="wp_zdy_seo_list widefat fixed striped">
    <thead>
        <tr>
            <th>错误提示</th>
            <th>中文描述</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>site error</td>
            <td>站点未在站长平台验证</td>
        </tr>
        <tr>
            <td>empty content</td>
            <td>post内容为空</td>
        </tr>
        <tr>
            <td>only 2000 urls are allowed once</td>
            <td>每次最多只能提交2000条链接</td>
        </tr>
        <tr>
            <td>over quota</td>
            <td>超过每日配额了，超配额后再提交都是无效的</td>
        </tr>
        <tr>
            <td>token is not valid</td>
            <td>token错误</td>
        </tr>
        <tr>
            <td>not found</td>
            <td>接口地址填写错误</td>
        </tr>
        <tr>
            <td>internal error, please try later</td>
            <td>服务器偶然异常，通常重试就会成功</td>
        </tr>
    </tbody>
</table>
    </div>
    <?php
}

// 注册
add_action('admin_init', 'wp_zdy_seo_admin_init');
function wp_zdy_seo_admin_init(){
    register_setting( 'wp-zdy-seo-settings-group', 'website_title' );
    register_setting( 'wp-zdy-seo-settings-group', 'website_subtitle' );
    register_setting( 'wp-zdy-seo-settings-group', 'title_separator' );
    register_setting( 'wp-zdy-seo-settings-group', 'enable_wp_zdy_seo' );
    register_setting( 'wp-zdy-seo-settings-group', 'website_description', 'sanitize_textarea_field' );
    register_setting( 'wp-zdy-seo-settings-group', 'website_keywords', 'sanitize_textarea_field' );
}


// 添加seo框
add_action('add_meta_boxes', 'wp_zdy_seo_add_custom_meta_box');
function wp_zdy_seo_add_custom_meta_box(){
    add_meta_box( 'wp-zdy-seo-meta-box', '自定义 SEO', 'wp_zdy_seo_meta_box', 'post', 'normal', 'high' );
    add_meta_box( 'wp-zdy-seo-meta-box', '自定义 SEO', 'wp_zdy_seo_meta_box', 'page', 'normal', 'high' );
    add_meta_box( 'wp-zdy-seo-meta-box', '自定义 SEO', 'wp_zdy_seo_meta_box', 'category', 'normal', 'high' );
}

// seo框
function wp_zdy_seo_meta_box($post){
    $seo_title = get_post_meta($post->ID, 'wp_zdy_seo_title', true);
    $seo_description = get_post_meta($post->ID, 'wp_zdy_seo_description', true);
    $seo_keywords = get_post_meta($post->ID, 'wp_zdy_seo_keywords', true);
    ?>
    <label for="wp_zdy_seo_title">SEO 标题:</label>
    <input type="text" id="wp_zdy_seo_title" name="wp_zdy_seo_title" value="<?php echo $seo_title; ?>" style="width: 100%;" />
    <br/><br/>
    <label for="wp_zdy_seo_description">SEO 描述:</label>
    <textarea id="wp_zdy_seo_description" name="wp_zdy_seo_description" style="width: 100%;"><?php echo $seo_description; ?></textarea>
    <br/><br/>
    <label for="wp_zdy_seo_keywords">SEO 关键词:</label>
    <input type="text" id="wp_zdy_seo_keywords" name="wp_zdy_seo_keywords" value="<?php echo $seo_keywords; ?>" style="width: 100%;" />
    <?php
}

// seo框保存
add_action('save_post', 'wp_zdy_seo_save_post');
function wp_zdy_seo_save_post($post_id){
    if(isset($_POST['wp_zdy_seo_title'])){
        update_post_meta($post_id, 'wp_zdy_seo_title', sanitize_text_field($_POST['wp_zdy_seo_title']));
    }
    if(isset($_POST['wp_zdy_seo_description'])){
        update_post_meta($post_id, 'wp_zdy_seo_description', sanitize_text_field($_POST['wp_zdy_seo_description']));
    }
    if(isset($_POST['wp_zdy_seo_keywords'])){
        update_post_meta($post_id, 'wp_zdy_seo_keywords', sanitize_text_field($_POST['wp_zdy_seo_keywords']));
    }
}

// 输出seo内容
add_action('wp_head', 'wp_zdy_seo_apply_custom_seo', 1);
function wp_zdy_seo_apply_custom_seo(){
    if(get_option('enable_wp_zdy_seo')){
        $title = get_option('website_title');
        $subtitle = get_option('website_subtitle');
        $description = get_option('website_description');
        $separator = get_option('title_separator');
        $keywords = get_option('website_keywords');
        $seo_title = '';
        $seo_description = '';
        $seo_keywords = '';
        
        if(is_single() || is_page() || is_category()){
            if(is_single() || is_page()){
                $post_id = get_the_ID();
                $seo_title = get_post_meta($post_id, 'wp_zdy_seo_title', true);
                $seo_description = get_post_meta($post_id, 'wp_zdy_seo_description', true);
                $seo_keywords = get_post_meta($post_id, 'wp_zdy_seo_keywords', true);
                
                // 截取前80个字符
                if(empty($seo_description)) {
                    $content = get_post_field('post_content', $post_id);
                    $content = preg_replace('/<[^>]*>/', '', $content); // 删除html标签
                    $content = preg_replace('/\s+/', ' ', $content); // 删除空格
                    $content = trim($content); // 删除末尾特殊符号
                    $seo_description = mb_substr($content, 0, 80); // 设置80个字符
                }
                
                // 文章自动将标签调为关键词
                if(empty($seo_keywords)) {
                    $post_tags = get_the_tags($post_id);
                    if($post_tags){
                        $tag_names = array();
                        foreach($post_tags as $tag){
                            $tag_names[] = $tag->name;
                        }
                        $seo_keywords = implode(', ', $tag_names);
                    } else {
                        $seo_keywords = $keywords;
                    }
                }
            } elseif(is_category()){
                $category_id = get_queried_object_id();
                $category = get_category($category_id);
                $seo_title = single_cat_title('', false).' '.$separator.' '.$title;
                $seo_description = wp_strip_all_tags(category_description($category_id)); // 移除HTML标签

                // 如果描述为空，不显示description
                if(empty($seo_description)) {
                    $seo_description = '';
                }

                $seo_keywords = single_cat_title('', false);
            }
        }

        if(empty($seo_title)){
            if(is_front_page()) {
                $seo_title = $title.' '.$separator.' '.$subtitle;
            } else {
                $seo_title = get_the_title().' '.$separator.' '.$title;
            }
        }

        if(is_front_page()) {
            $seo_description = $description;
            $seo_keywords = $keywords;
        }

        // 安全转义并输出meta标签
        echo '<title>'.esc_attr($seo_title).'</title>'."\n";
        echo '<meta name="keywords" content="'.esc_attr($seo_keywords).'" />'."\n";
        echo '<meta name="description" content="'.esc_attr($seo_description).'" />'."\n";
    }
}


// 防止部分主题出现2个标题，删除默认的
add_action('init', 'remove_default_title_output');
function remove_default_title_output() {
    if (get_option('enable_wp_zdy_seo')) {
        remove_action('wp_head', '_wp_render_title_tag', 1);
        //remove_action('wp_head', 'wp_seo_auto_desc', 1);  //默认的描述
    }
}




// 标题
add_filter('wp_title', 'wp_zdy_apply_custom_title', 10, 2);
function wp_zdy_apply_custom_title($title, $sep){
    if(get_option('enable_wp_zdy_seo')){
        $seo_title = '';
        if(is_single() || is_page() || is_category()){
            $post_id = get_queried_object_id();
            $seo_title = get_post_meta($post_id, 'wp_zdy_seo_title', true);
        }
        if(!empty($seo_title)){
            return $seo_title . ' ' . $sep . ' ' . get_bloginfo('name');
        }
    }
    return $title;
}

// 描述
add_filter('get_the_excerpt', 'wp_zdy_apply_custom_description');
function wp_zdy_apply_custom_description($excerpt){
    if(get_option('enable_wp_zdy_seo')){
        $seo_description = '';
        if(is_single() || is_page() || is_category()){
            $post_id = get_queried_object_id();
            $seo_description = get_post_meta($post_id, 'wp_zdy_seo_description', true);
        }
        if(!empty($seo_description)){
            return $seo_description;
        }
    }
    return $excerpt;
}

// 关键词
add_filter('wpseo_metakey', 'wp_zdy_apply_custom_keywords');
function wp_zdy_apply_custom_keywords($keywords){
    if(get_option('enable_wp_zdy_seo')){
        $seo_keywords = '';
        if(is_single() || is_page() || is_category()){
            $post_id = get_queried_object_id();
            $seo_keywords = get_post_meta($post_id, 'wp_zdy_seo_keywords', true);
        }
        if(!empty($seo_keywords)){
            return $seo_keywords;
        }
    }
    return $keywords;
}


// 添加对WooCommerce产品页面的支持
add_action('add_meta_boxes', 'wp_zdy_seo_add_product_meta_box');
function wp_zdy_seo_add_product_meta_box(){
    add_meta_box( 'wp-zdy-seo-product-meta-box', '自定义 SEO', 'wp_zdy_seo_product_meta_box', 'product', 'normal', 'high' );
}

// WooCommerce seo框
function wp_zdy_seo_product_meta_box($post){
    $seo_title = get_post_meta($post->ID, 'wp_zdy_seo_title', true);
    $seo_description = get_post_meta($post->ID, 'wp_zdy_seo_description', true);
    $seo_keywords = get_post_meta($post->ID, 'wp_zdy_seo_keywords', true);
    ?>
    <label for="wp_zdy_seo_title">SEO 标题:</label>
    <input type="text" id="wp_zdy_seo_title" name="wp_zdy_seo_title" value="<?php echo $seo_title; ?>" style="width: 100%;" />
    <br/><br/>
    <label for="wp_zdy_seo_description">SEO 描述:</label>
    <textarea id="wp_zdy_seo_description" name="wp_zdy_seo_description" style="width: 100%;"><?php echo $seo_description; ?></textarea>
    <br/><br/>
    <label for="wp_zdy_seo_keywords">SEO 关键词:</label>
    <input type="text" id="wp_zdy_seo_keywords" name="wp_zdy_seo_keywords" value="<?php echo $seo_keywords; ?>" style="width: 100%;" />
    <?php
}

// 产品seo框保存
add_action('save_post_product', 'wp_zdy_seo_save_product');
function wp_zdy_seo_save_product($post_id){
    if(isset($_POST['wp_zdy_seo_title'])){
        update_post_meta($post_id, 'wp_zdy_seo_title', sanitize_text_field($_POST['wp_zdy_seo_title']));
    }
    if(isset($_POST['wp_zdy_seo_description'])){
        update_post_meta($post_id, 'wp_zdy_seo_description', sanitize_text_field($_POST['wp_zdy_seo_description']));
    }
    if(isset($_POST['wp_zdy_seo_keywords'])){
        update_post_meta($post_id, 'wp_zdy_seo_keywords', sanitize_text_field($_POST['wp_zdy_seo_keywords']));
    }
}

// 给产品调用
add_action('woocommerce_before_main_content', 'wp_zdy_seo_apply_product_custom_seo');
function wp_zdy_seo_apply_product_custom_seo(){
    if(get_option('enable_wp_zdy_seo') && is_product()){
        global $post;
        $title = get_option('website_title');
        $subtitle = get_option('website_subtitle');
        $description = get_option('website_description');
        $separator = get_option('title_separator');
        $default_keywords = get_option('website_keywords');
        $seo_title = get_post_meta($post->ID, 'wp_zdy_seo_title', true);
        $seo_description = get_post_meta($post->ID, 'wp_zdy_seo_description', true);
        $seo_keywords = get_post_meta($post->ID, 'wp_zdy_seo_keywords', true);
        
        // 检查产品是否有标签
        $product_tags = wp_get_post_terms($post->ID, 'product_tag', array('fields' => 'names'));
        
        if (!empty($product_tags)) {
            $seo_keywords = implode(', ', $product_tags);
        } elseif (empty($seo_keywords)) {
            $seo_keywords = $default_keywords;
        }

        if(empty($seo_title)){
            $seo_title = get_the_title().' '.$separator.' '.$title;
        }

        if(empty($seo_description)){
            $seo_description = $description;
        }

        echo '<title>'.$seo_title.'</title>'."\n";
        echo '<meta name="description" content="'.$seo_description.'" />'."\n";
        echo '<meta name="keywords" content="'.$seo_keywords.'" />'."\n";
    }
}


//百度站长代码
// 百度站长api设置
add_action('admin_init', 'wp_zdy_baidu_auto_submit_settings');
function wp_zdy_baidu_auto_submit_settings() {
    register_setting('wp_zdy_baidu_auto_submit_settings_group', 'wp_zdy_baidu_api_token');
    register_setting('wp_zdy_baidu_auto_submit_settings_group', 'wp_zdy_baidu_auto_submit_enabled');

    add_settings_section('wp_zdy_baidu_auto_submit_section', '百度站长Api设置', 'wp_zdy_baidu_auto_submit_section_callback', 'baidu-auto-submit-settings');

    add_settings_field('wp_zdy_baidu_api_token', '站长API Token:', 'wp_zdy_baidu_api_token_callback', 'baidu-auto-submit-settings', 'wp_zdy_baidu_auto_submit_section');
    add_settings_field('wp_zdy_baidu_auto_submit_enabled', '开启自动提交:', 'wp_zdy_baidu_auto_submit_enabled_callback', 'baidu-auto-submit-settings', 'wp_zdy_baidu_auto_submit_section');
}

// 信息
function wp_zdy_baidu_auto_submit_section_callback() {
    echo '百度站长api自动提交设置，请先到https://ziyuan.baidu.com/ 添加验证你的网站.';
}

// 设置api
function wp_zdy_baidu_api_token_callback() {
    $baidu_api_token = esc_attr(get_option('wp_zdy_baidu_api_token'));
    echo "<input type='text' name='wp_zdy_baidu_api_token' value='$baidu_api_token' />";
}

// api复选框
function wp_zdy_baidu_auto_submit_enabled_callback() {
    $enabled = get_option('wp_zdy_baidu_auto_submit_enabled');
    echo "<input type='checkbox' name='wp_zdy_baidu_auto_submit_enabled' value='1' " . checked(1, $enabled, false) . " />";
}

// 验证api
add_action('admin_init', 'wp_zdy_baidu_auto_submit_verify_api');
function wp_zdy_baidu_auto_submit_verify_api() {
    if (isset($_POST['submit'])) {
        $enabled = isset($_POST['wp_zdy_baidu_auto_submit_enabled']) ? 1 : 0;
        if ($enabled) {
            $api_token = sanitize_text_field($_POST['wp_zdy_baidu_api_token']);

            // 检查
            if (!empty($api_token)) {
                // 提交api
                $api = "http://data.zz.baidu.com/urls?site=" . home_url() . "&token=$api_token";
                $ch = curl_init();
                $options =  array(
                    CURLOPT_URL => $api,
                    CURLOPT_POST => true,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POSTFIELDS => home_url(), // 获取网站主网址
                    CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
                );
                curl_setopt_array($ch, $options);
                $result = curl_exec($ch);
                $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);

                // 检查反馈信息
                if ($http_code === 200) {
                    // 如果是200就成功
                    add_settings_error('wp_zdy_baidu_api_token', 'api_verified', 'API Token 验证成功', 'updated');
                } elseif ($http_code === 401) {
                    // 错误401，Token 错误
                    add_settings_error('wp_zdy_baidu_api_token', 'api_verification_failed', 'API Token 验证失败：Token 错误', 'error');
                } elseif ($http_code === 400) {
                    // 错误400，可能是站点未在站长平台验证
                    $error_response = json_decode($result, true);
                    if ($error_response && isset($error_response['error']) && $error_response['error'] === 400 && strpos($error_response['message'], 'site error') !== false) {
                        // 包含 "site error"，站点未在站长平台验证
                        add_settings_error('wp_zdy_baidu_api_token', 'api_verification_failed', 'API Token 验证失败：站点未在站长平台验证', 'error');
                    }
                } elseif ($http_code === 404) {
                    // 错误404，接口地址填写错误
                    add_settings_error('wp_zdy_baidu_api_token', 'api_verification_failed', 'API Token 验证失败：接口地址填写错误', 'error');
                } elseif ($http_code === 500) {
                    // 错误500，服务器偶然异常，通常重试就会成功
                    add_settings_error('wp_zdy_baidu_api_token', 'api_verification_failed', 'API Token 验证失败：服务器偶然异常，通常重试就会成功', 'error');
                }
            }
        }
    }
}


/*// 确保反馈信息显示 可以不用
add_action('admin_notices', 'wp_zdy_baidu_auto_submit_display_settings_errors');
function wp_zdy_baidu_auto_submit_display_settings_errors() {
    settings_errors('wp_zdy_baidu_api_token');
}
*/

// 验证最新帖子
add_action('save_post', 'wp_zdy_baidu_auto_submit_new_post');
function wp_zdy_baidu_auto_submit_new_post($post_id) {
    // 检测是否启用自动提交
    if (get_option('wp_zdy_baidu_auto_submit_enabled')) {
        // 获取帖子链接
        $post_url = get_permalink($post_id);

        // 检查该链接是否已经提交过
        $submitted_before = get_post_meta($post_id, 'wp_zdy_baidu_auto_submit_submitted', true);

        // 如果链接尚未提交过，则进行提交
        if (!$submitted_before) {
            // 获取百度 API 设置
            $api_token = get_option('wp_zdy_baidu_api_token');

            // 提交链接给百度
            $urls = array($post_url);
            $api = "http://data.zz.baidu.com/urls?site=" . get_site_url() . "&token=$api_token";
            $ch = curl_init();
            $options =  array(
                CURLOPT_URL => $api,
                CURLOPT_POST => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POSTFIELDS => implode("\n", $urls),
                CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
            );
            curl_setopt_array($ch, $options);
            $result = curl_exec($ch);

            // 记录提交结果
            $result = json_decode($result, true);
            update_post_meta($post_id, 'wp_zdy_baidu_auto_submit_result', $result);

            // 标记链接为已提交
            update_post_meta($post_id, 'wp_zdy_baidu_auto_submit_submitted', true);
        }
    }
}

?>