jQuery(document).ready(function($) {
    const $input = $('#xb-jiejiari-input');
    const $type = $('#xb-jiejiari-type');
    const $processBtn = $('#xb-jiejiari-process-btn');
    const $clearBtn = $('#xb-jiejiari-clear-btn');
    const $loginBtn = $('#xb-jiejiari-login-btn');
    const $result = $('#xb-jiejiari-result');
    const $notification = $('#xb-jiejiari-notification');
    const $usage = $('.xb-jiejiari-usage');
    const isUserLoggedIn = xb_jiejiari_vars.is_user_logged_in === 'yes';
    const today = xb_jiejiari_vars.today;

    // 初始化日历
    $('#xb-jiejiari-calendar').datepicker({
        dateFormat: 'yy-mm-dd',
        changeMonth: true,
        changeYear: true,
        showButtonPanel: false,
        prevText: '',
        nextText: '',
        onSelect: function(dateText) {
            $input.val(dateText);
            $type.val('0');
            $processBtn.prop('disabled', false);
            $processBtn.click();
        }
    });

    // 初始化输入框
    $input.val(today);

    // 输入框变化时更新按钮状态
    $input.on('input', function() {
        const value = $(this).val().trim();
        $processBtn.prop('disabled', !value);
    });

    // 查询类型变化时调整输入框提示
    $type.on('change', function() {
        const type = $(this).val();
        if (type === '0') {
            $input.attr('placeholder', '请输入日期（如2025-01-01）');
        } else if (type === '1') {
            $input.attr('placeholder', '请输入年份（如2025）');
        } else if (type === '2') {
            $input.attr('placeholder', '请输入年月（如2025-01）');
        }
    });

    // 提交查询
    $processBtn.on('click', function() {
        const date = $input.val().trim();
        const type = $type.val();
        
        if (!date) {
            showNotification('请输入查询日期', 'error');
            return;
        }

        $result.html('<div class="xb-jiejiari-processing">正在查询中...</div>');
        fetchHoliday(date, type);
    });

    // 获取节假日信息
    function fetchHoliday(date, type) {
        const ajaxOptions = {
            url: xb_jiejiari_vars.ajax_url + 'process',
            method: 'POST',
            data: JSON.stringify({ date: date, type: type }),
            contentType: 'application/json',
            success: function(response) {
                if (response.error) {
                    showNotification(response.error, 'error');
                    $result.html('<p class="xb-jiejiari-no-result">无相关节假日信息</p>');
                    if (response.error === '今日查询次数已用尽' || response.error === '游客查询次数已用尽，请登录后继续使用') {
                        $processBtn.hide();
                        if (!isUserLoggedIn) {
                            $loginBtn.show();
                        }
                    }
                    return;
                }

                let resultHtml = '';
                if (response.list && response.list.length > 0) {
                    response.list.forEach(item => {
                        const vacation = typeof item.vacation === 'string' ? item.vacation.split('|') : (Array.isArray(item.vacation) ? item.vacation : []);
                        const remark = typeof item.remark === 'string' ? item.remark.split('|') : (Array.isArray(item.remark) ? item.remark : []);
                        const wage = typeof item.wage === 'string' ? item.wage.split('|') : (Array.isArray(item.wage) ? item.wage : []);

                        if (type === '1') {
                            // 年查询只显示官方节假日，突出显示 holiday
                            resultHtml += `
                                <div class="xb-jiejiari-result-item">
                                    <div class="xb-jiejiari-result-date xb-jiejiari-holiday-highlight">${item.holiday || '未知日期'}</div>
                                    <div class="xb-jiejiari-result-name">${item.name || '无节假日'}</div>
                                    <div class="xb-jiejiari-result-content">
                                        <p><span class="xb-jiejiari-result-important">假期范围:</span> ${vacation.length > 0 ? vacation.join(', ') : '无'}</p>
                                        ${remark.length > 0 ? `<p><span class="xb-jiejiari-result-important">调休日:</span> ${remark.join(', ')}</p>` : ''}
                                        <p><span class="xb-jiejiari-result-important">三倍薪资日期:</span> ${wage.length > 0 ? wage.join(', ') : '无'}</p>
                                        <p><span class="xb-jiejiari-result-important">放假提示:</span> ${item.tip || '无'}</p>
                                        <p><span class="xb-jiejiari-result-important">拼假建议:</span> ${item.rest || '无'}</p>
                                    </div>
                                </div>`;
                        } else {
                            // 日期或月查询
                            resultHtml += `
                                <div class="xb-jiejiari-result-item">
                                    <div class="xb-jiejiari-result-date">${item.date || '未知日期'}</div>
                                    <div class="xb-jiejiari-result-name">${item.name || '无节假日'} ${item.enname ? '(' + item.enname + ')' : ''}</div>
                                    <div class="xb-jiejiari-result-content">
                                        <p><span class="xb-jiejiari-result-important">类型:</span> ${item.info || '未知'}</p>
                                        <p><span class="xb-jiejiari-result-important">农历:</span> ${item.lunaryear || ''}年${item.lunarmonth || ''}${item.lunarday || ''}</p>
                                        <p><span class="xb-jiejiari-result-important">星期:</span> ${item.cnweekday || '未知'}</p>
                                        <p><span class="xb-jiejiari-result-important">是否休息:</span> ${item.isnotwork ? '是' : '否'}</p>
                                        <p><span class="xb-jiejiari-result-important">薪资倍数:</span> ${item.wage || 0}倍</p>
                                        ${vacation.length > 0 ? `<p><span class="xb-jiejiari-result-important">假期范围:</span> ${vacation.join(', ')}</p>` : ''}
                                        ${remark.length > 0 ? `<p><span class="xb-jiejiari-result-important">调休日:</span> ${remark.join(', ')}</p>` : ''}
                                        <p><span class="xb-jiejiari-result-important">放假提示:</span> ${item.tip || '无'}</p>
                                        <p><span class="xb-jiejiari-result-important">拼假建议:</span> ${item.rest || '无'}</p>
                                    </div>
                                </div>`;
                        }
                    });
                } else {
                    resultHtml = '<p class="xb-jiejiari-no-result">无相关节假日信息</p>';
                }
                $result.html(resultHtml);
                updateUsageCount(response.remaining, response.limit);
                if (response.remaining === 0) {
                    $processBtn.hide();
                    if (!isUserLoggedIn) {
                        $loginBtn.show();
                    }
                }
            },
            error: function(xhr, status, error) {
                showNotification('暂时无法查询，请联系客服', 'error');
                $result.html('<p class="xb-jiejiari-no-result">无相关节假日信息</p>');
            }
        };

        if (isUserLoggedIn && xb_jiejiari_vars.nonce) {
            ajaxOptions.headers = { 'X-WP-Nonce': xb_jiejiari_vars.nonce };
        }

        $.ajax(ajaxOptions);
    }

    // 清空输入和结果
    $clearBtn.on('click', function() {
        $input.val(today);
        $type.val('0');
        $input.attr('placeholder', '请输入日期（如2025-01-01）');
        $result.html('<p class="xb-jiejiari-no-result">加载中...</p>');
        $notification.empty();
        $processBtn.prop('disabled', false);
        fetchHoliday(today, 0);
    });

    // 快速登录按钮点击事件
    $loginBtn.on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });

    // 更新使用次数显示
    function updateUsageCount(remaining, limit) {
        if (!$usage.length) return;
        if (remaining > 0) {
            $usage.text(`今日剩余查询次数：${remaining}/${limit}`);
        } else {
            $usage.text(isUserLoggedIn ? '今日查询次数已用完，请明天再来' : '游客查询次数已用尽，请登录后继续使用');
        }
    }

    // 显示通知消息
    function showNotification(message, type) {
        const className = type === 'error' ? 'xb-jiejiari-error' : 'xb-jiejiari-success';
        $notification.html(`<div class="${className}">${message}</div>`);
        setTimeout(() => {
            $notification.empty();
        }, 3000);
    }
});