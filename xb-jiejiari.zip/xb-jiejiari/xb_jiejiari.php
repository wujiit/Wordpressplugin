<?php
/*
Plugin Name: 节假日查询
Description: 基于天API的节假日查询插件
Version: 1.0.7
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 创建数据表（记录表、计数表和缓存表）
function xb_jiejiari_create_table() {
    global $wpdb;
    $table_name_records = $wpdb->prefix . 'xb_jiejiari_records';
    $table_name_counts = $wpdb->prefix . 'xb_jiejiari_counts';
    $table_name_cache = $wpdb->prefix . 'xb_jiejiari_cache';
    $charset_collate = $wpdb->get_charset_collate();

    // 创建记录表
    $sql_records = "CREATE TABLE $table_name_records (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        device_id VARCHAR(255) NOT NULL,
        ip_address VARCHAR(45) NOT NULL,
        input_date VARCHAR(255) NOT NULL,
        error_message TEXT,
        processed_time DATETIME NOT NULL,
        status VARCHAR(50) NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY device_id (device_id)
    ) $charset_collate;";

    // 创建计数表
    $sql_counts = "CREATE TABLE $table_name_counts (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        device_id VARCHAR(255) NOT NULL,
        count_date DATE NOT NULL,
        usage_count INT UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY user_date (user_id, device_id, count_date)
    ) $charset_collate;";

    // 创建缓存表
    $sql_cache = "CREATE TABLE $table_name_cache (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        query_date VARCHAR(255) NOT NULL,
        query_type INT NOT NULL,
        result LONGTEXT NOT NULL,
        cached_time DATETIME NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY query_date_type (query_date, query_type)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_records);
    dbDelta($sql_counts);
    dbDelta($sql_cache);
}

// 创建前台页面
function xb_jiejiari_create_page() {
    $pages = get_posts([
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_jiejiari_frontend]',
        'numberposts' => 1,
    ]);

    if (empty($pages)) {
        wp_insert_post([
            'post_title'    => '节假日查询',
            'post_content'  => '[xb_jiejiari_frontend]',
            'post_status'   => 'publish',
            'post_type'     => 'page',
        ]);
    }
}

// 加载前端资源
function xb_jiejiari_enqueue_frontend_assets() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_jiejiari_frontend')) {
        wp_enqueue_style('xb-jiejiari-style', plugins_url('xb_jiejiari.css', __FILE__), [], '1.0.7');
        wp_enqueue_style('jquery-ui', plugins_url('jquery-ui-custom.css', __FILE__), [], '1.0.7');
        wp_enqueue_script('jquery');
        wp_enqueue_script('jquery-ui-datepicker', '', ['jquery-ui-core', 'jquery-ui-datepicker'], null, true);
        wp_enqueue_script('xb-jiejiari-script', plugins_url('xb_jiejiari.js', __FILE__), ['jquery', 'jquery-ui-datepicker'], '1.0.7', true);
        
        $is_logged_in = is_user_logged_in();
        wp_localize_script('xb-jiejiari-script', 'xb_jiejiari_vars', [
            'ajax_url' => rest_url('xb_jiejiari/v1/'),
            'nonce'    => $is_logged_in ? wp_create_nonce('wp_rest') : '',
            'login_url' => wp_login_url(),
            'is_user_logged_in' => $is_logged_in ? 'yes' : 'no',
            'today' => date('Y-m-d')
        ]);
    }
}

// 插件激活
function xb_jiejiari_activate() {
    xb_jiejiari_create_table();
    xb_jiejiari_create_page();
}
register_activation_hook(__FILE__, 'xb_jiejiari_activate');

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_jiejiari_enqueue_frontend_assets');

// 获取设备指纹
function xb_jiejiari_get_device_id() {
    $ip = sanitize_text_field($_SERVER['REMOTE_ADDR']);
    $user_agent = sanitize_text_field($_SERVER['HTTP_USER_AGENT']);
    return md5($ip . $user_agent . wp_salt());
}

// 注册短代码
function xb_jiejiari_frontend_shortcode() {
    ob_start();
    $daily_limit = (int) get_option('xb_jiejiari_daily_limit', 10);
    $guest_limit = (int) get_option('xb_jiejiari_guest_limit', 5);
    $show_stats = get_option('xb_jiejiari_show_stats', 'yes') === 'yes';
    $user_id = get_current_user_id();
    $device_id = xb_jiejiari_get_device_id();
    
    global $wpdb;
    $today = date('Y-m-d');
    $table_name_counts = $wpdb->prefix . 'xb_jiejiari_counts';
    $table_name_cache = $wpdb->prefix . 'xb_jiejiari_cache';

    // Check cache for today's date (type=0)
    $cached_result = $wpdb->get_var($wpdb->prepare(
        "SELECT result FROM $table_name_cache WHERE query_date = %s AND query_type = %d",
        $today, 0
    ));
    $initial_result = $cached_result ? json_decode($cached_result, true) : [];

    if ($user_id) {
        $limit = $daily_limit;
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT usage_count FROM $table_name_counts WHERE user_id = %d AND count_date = %s",
            $user_id, $today
        ));
    } else {
        $limit = $guest_limit;
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT usage_count FROM $table_name_counts WHERE device_id = %s AND count_date = %s",
            $device_id, $today
        ));
    }
    $count = $count ? (int) $count : 0;
    $remaining = max(0, $limit - $count);
    $usage_text = $remaining > 0 ? "今日剩余查询次数：{$remaining}/{$limit}" : ($user_id ? "今日查询次数已用完，请明天再来" : "游客查询次数已用尽，请登录后继续使用");
    $show_process_btn = $remaining > 0 ? '' : 'style="display:none;"';
    $show_login_btn = (!$user_id && $remaining <= 0) ? '' : 'style="display:none;"';
    ?>
    <div class="xb-jiejiari-container">
        <div class="xb-jiejiari-custom-title">节假日查询</div>
        <div class="xb-jiejiari-input-area">
            <div class="xb-jiejiari-title">输入查询日期</div>
            <input type="text" id="xb-jiejiari-input" placeholder="请输入日期（如2025-01-01 或 2025-01 或 2025）" value="<?php echo esc_attr($today); ?>" />
            <select id="xb-jiejiari-type">
                <option value="0">按日期查询</option>
                <option value="1">按年查询</option>
                <option value="2">按月查询</option>
            </select>
            <button id="xb-jiejiari-process-btn" <?php echo $show_process_btn; ?> disabled>开始查询</button>
            <button id="xb-jiejiari-login-btn" <?php echo $show_login_btn; ?> href="<?php echo esc_url(wp_login_url()); ?>">快速登录</button>
        </div>
        <div class="xb-jiejiari-calendar-area">
            <div class="xb-jiejiari-calendar" id="xb-jiejiari-calendar"></div>
        </div>
        <div class="xb-jiejiari-result-area">
            <button id="xb-jiejiari-clear-btn">清空结果</button>
            <div class="xb-jiejiari-title">查询结果</div>
            <div id="xb-jiejiari-result">
                <?php
                if ($initial_result && !empty($initial_result)) {
                    foreach ($initial_result as $item) {
                        ?>
                        <div class="xb-jiejiari-result-item">
                            <div class="xb-jiejiari-result-date"><?php echo esc_html($item['date']); ?></div>
                            <div class="xb-jiejiari-result-name"><?php echo esc_html($item['name'] ?: '无节假日'); ?> <?php echo esc_html($item['enname'] ? "({$item['enname']})" : ''); ?></div>
                            <div class="xb-jiejiari-result-content">
                                <p><span class="xb-jiejiari-result-important">类型:</span> <?php echo esc_html($item['info']); ?></p>
                                <p><span class="xb-jiejiari-result-important">农历:</span> <?php echo esc_html($item['lunaryear'] . '年' . $item['lunarmonth'] . $item['lunarday']); ?></p>
                                <p><span class="xb-jiejiari-result-important">星期:</span> <?php echo esc_html($item['cnweekday']); ?></p>
                                <p><span class="xb-jiejiari-result-important">是否休息:</span> <?php echo $item['isnotwork'] ? '是' : '否'; ?></p>
                                <p><span class="xb-jiejiari-result-important">薪资倍数:</span> <?php echo esc_html($item['wage']); ?>倍</p>
                                <?php if (!empty($item['vacation'])): ?>
                                    <p><span class="xb-jiejiari-result-important">假期范围:</span> <?php echo esc_html(is_array($item['vacation']) ? implode(', ', $item['vacation']) : $item['vacation']); ?></p>
                                <?php endif; ?>
                                <?php if (!empty($item['remark'])): ?>
                                    <p><span class="xb-jiejiari-result-important">调休日:</span> <?php echo esc_html(is_array($item['remark']) ? implode(', ', $item['remark']) : $item['remark']); ?></p>
                                <?php endif; ?>
                                <p><span class="xb-jiejiari-result-important">放假提示:</span> <?php echo esc_html($item['tip']); ?></p>
                                <p><span class="xb-jiejiari-result-important">拼假建议:</span> <?php echo esc_html($item['rest']); ?></p>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    echo '<p class="xb-jiejiari-no-result">加载中...</p>';
                }
                ?>
            </div>
        </div>
        <div id="xb-jiejiari-notification"></div>
        <?php if ($show_stats): ?>
            <div class="xb-jiejiari-usage"><?php echo $usage_text; ?></div>
        <?php endif; ?>
        <?php if ($notice = get_option('xb_jiejiari_notice')): ?>
            <div class="xb-jiejiari-notice-content"><?php echo wp_kses_post($notice); ?></div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('xb_jiejiari_frontend', 'xb_jiejiari_frontend_shortcode');

// REST API 注册
function xb_jiejiari_register_rest_routes() {
    register_rest_route('xb_jiejiari/v1', '/process', [
        'methods'  => 'POST',
        'callback' => 'xb_jiejiari_handle_process',
        'permission_callback' => function ($request) {
            if (is_user_logged_in()) {
                $nonce = $request->get_header('X-WP-Nonce');
            return wp_verify_nonce($nonce, 'wp_rest');
            }
            return true;
        },
    ]);
}
add_action('rest_api_init', 'xb_jiejiari_register_rest_routes');

// 处理查询请求
function xb_jiejiari_handle_process($request) {
    $date = sanitize_text_field($request['date']);
    $type = (int) $request['type'];
    $user_id = get_current_user_id();
    $device_id = xb_jiejiari_get_device_id();
    $ip = sanitize_text_field($_SERVER['REMOTE_ADDR']);
    $api_key = get_option('xb_jiejiari_api_key');
    $daily_limit = (int) get_option('xb_jiejiari_daily_limit', 10);
    $guest_limit = (int) get_option('xb_jiejiari_guest_limit', 5);

    if (!$api_key) {
        return new WP_Error('no_api_key', '未设置API Key', ['status' => 500]);
    }

    // 验证日期格式
    $is_valid_date = false;
    if ($type == 0 && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        $is_valid_date = true;
    } elseif ($type == 1 && preg_match('/^\d{4}$/', $date)) {
        $is_valid_date = true;
    } elseif ($type == 2 && preg_match('/^\d{4}-\d{2}$/', $date)) {
        $is_valid_date = true;
    }

    if (!$is_valid_date) {
        return new WP_Error('invalid_date', '日期格式错误', ['status' => 400]);
    }

    global $wpdb;
    $table_name_records = $wpdb->prefix . 'xb_jiejiari_records';
    $table_name_counts = $wpdb->prefix . 'xb_jiejiari_counts';
    $table_name_cache = $wpdb->prefix . 'xb_jiejiari_cache';
    $today = date('Y-m-d');

    // 检查缓存
    $cached = $wpdb->get_var($wpdb->prepare(
        "SELECT result FROM $table_name_cache WHERE query_date = %s AND query_type = %d",
        $date, $type
    ));
    if ($cached !== null) {
        // 初始化计数和限制
        if ($user_id) {
            $limit = $daily_limit;
            $count = $wpdb->get_var($wpdb->prepare(
                "SELECT usage_count FROM $table_name_counts WHERE user_id = %d AND count_date = %s",
                $user_id, $today
            ));
        } else {
            $limit = $guest_limit;
            $count = $wpdb->get_var($wpdb->prepare(
                "SELECT usage_count FROM $table_name_counts WHERE device_id = %s AND count_date = %s",
                $device_id, $today
            ));
        }
        $count = $count ? (int) $count : 0;

        $result = [
            'list' => json_decode($cached, true),
            'remaining' => max(0, $limit - $count),
            'limit' => $limit
        ];
        // 插入记录（不增加计数）
        $wpdb->insert(
            $table_name_records,
            [
                'user_id' => $user_id,
                'device_id' => $device_id,
                'ip_address' => $ip,
                'input_date' => $date,
                'error_message' => '',
                'processed_time' => current_time('mysql'),
                'status' => 'cached'
            ],
            ['%d', '%s', '%s', '%s', '%s', '%s', '%s']
        );
        return $result;
    }

    // 检查使用次数
    if ($user_id) {
        $limit = $daily_limit;
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT usage_count FROM $table_name_counts WHERE user_id = %d AND count_date = %s",
            $user_id, $today
        ));
    } else {
        $limit = $guest_limit;
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT usage_count FROM $table_name_counts WHERE device_id = %s AND count_date = %s",
            $device_id, $today
        ));
    }
    $count = $count ? (int) $count : 0;

    if ($count >= $limit) {
        return new WP_Error('limit_exceeded', $user_id ? '今日查询次数已用尽' : '游客查询次数已用尽，请登录后继续使用', ['status' => 400]);
    }

    // 调用API
    $url = 'https://apis.tianapi.com/jiejiari/index?key=' . urlencode($api_key) . '&date=' . urlencode($date) . '&type=' . $type . '&mode=1';
    $response = wp_remote_get($url, [
        'timeout' => 30,
        'sslverify' => false,
    ]);

    $status = 'error';
    $error_message = '';
    $result = ['error' => '暂时无法查询请联系客服'];

    if (!is_wp_error($response)) {
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($body['code']) && $body['code'] === 200 && isset($body['result']['list'])) {
            $status = 'success';
            $result = [
                'list' => $body['result']['list'],
                'remaining' => max(0, $limit - ($count + 1)),
                'limit' => $limit
            ];
            // 缓存结果
            $wpdb->insert(
                $table_name_cache,
                [
                    'query_date' => $date,
                    'query_type' => $type,
                    'result' => json_encode($body['result']['list']),
                    'cached_time' => current_time('mysql')
                ],
                ['%s', '%d', '%s', '%s']
            );
        } else {
            $error_message = isset($body['msg']) ? $body['msg'] : 'API处理失败';
        }
    } else {
        $error_message = $response->get_error_message();
    }

    // 插入记录
    $wpdb->insert(
        $table_name_records,
        [
            'user_id' => $user_id,
            'device_id' => $device_id,
            'ip_address' => $ip,
            'input_date' => $date,
            'error_message' => $error_message,
            'processed_time' => current_time('mysql'),
            'status' => $status
        ],
        ['%d', '%s', '%s', '%s', '%s', '%s', '%s']
    );

    // 更新使用次数（仅当非缓存时）
    if ($status === 'success' && $cached === null) {
        $wpdb->replace(
            $table_name_counts,
            [
                'user_id' => $user_id,
                'device_id' => $device_id,
                'count_date' => $today,
                'usage_count' => $count + 1
            ],
            ['%d', '%s', '%s', '%d']
        );
    }

    return $result;
}

// 后台菜单
function xb_jiejiari_admin_menu() {
    add_menu_page('节假日查询设置', '节假日查询', 'manage_options', 'xb-jiejiari-settings', 'xb_jiejiari_settings_page');
    add_submenu_page('xb-jiejiari-settings', '用户查询记录', '用户记录', 'manage_options', 'xb-jiejiari-records', 'xb_jiejiari_records_page');
    add_submenu_page('xb-jiejiari-settings', '缓存管理', '缓存管理', 'manage_options', 'xb-jiejiari-cache', 'xb_jiejiari_cache_page');
}
add_action('admin_menu', 'xb_jiejiari_admin_menu');

// 设置页面
function xb_jiejiari_settings_page() {
    if (isset($_POST['xb_jiejiari_save'])) {
        update_option('xb_jiejiari_api_key', sanitize_text_field($_POST['api_key']));
        update_option('xb_jiejiari_daily_limit', (int) $_POST['daily_limit']);
        update_option('xb_jiejiari_guest_limit', (int) $_POST['guest_limit']);
        update_option('xb_jiejiari_show_stats', sanitize_text_field($_POST['show_stats']));
        update_option('xb_jiejiari_notice', wp_kses_post($_POST['notice']));
        echo '<div class="updated xb-jiejiari-admin-notice"><p>设置已保存</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>节假日查询设置</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>API Key</th>
                    <td><input type="text" name="api_key" value="<?php echo esc_attr(get_option('xb_jiejiari_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>默认每日使用次数（登录用户）</th>
                    <td><input type="number" name="daily_limit" value="<?php echo esc_attr(get_option('xb_jiejiari_daily_limit', 10)); ?>" min="1" class="small-text"> 次</td>
                </tr>
                <tr>
                    <th>游客每日使用次数</th>
                    <td><input type="number" name="guest_limit" value="<?php echo esc_attr(get_option('xb_jiejiari_guest_limit', 5)); ?>" min="1" class="small-text"> 次</td>
                </tr>
                <tr>
                    <th>显示统计信息</th>
                    <td>
                        <select name="show_stats">
                            <option value="yes" <?php selected(get_option('xb_jiejiari_show_stats', 'yes'), 'yes'); ?>>是</option>
                            <option value="no" <?php selected(get_option('xb_jiejiari_show_stats', 'yes'), 'no'); ?>>否</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>公告内容</th>
                    <td><textarea name="notice" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_jiejiari_notice')); ?></textarea></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="xb_jiejiari_save" class="button-primary" value="保存设置"></p>
        </form>
        由天API提供服务：https://apis.tianapi.com/jiejiari/index
    </div>
    <script>
        jQuery(document).ready(function($) {
            setTimeout(function() {
                $('.xb-jiejiari-admin-notice').fadeOut(500);
            }, 3000);
        });
    </script>
    <?php
}

// 用户记录页面
function xb_jiejiari_records_page() {
    global $wpdb;
    $table_name_records = $wpdb->prefix . 'xb_jiejiari_records';
    $table_name_counts = $wpdb->prefix . 'xb_jiejiari_counts';
    $per_page = 20;
    $paged = isset($_GET['paged']) ? (int) $_GET['paged'] : 1;
    $offset = ($paged - 1) * $per_page;
    $user_id_filter = isset($_GET['user_id']) ? (int) $_GET['user_id'] : 0;

    // 删除单条记录
    if (isset($_GET['delete_id'])) {
        $wpdb->delete($table_name_records, ['id' => (int) $_GET['delete_id']], ['%d']);
        echo '<div class="updated xb-jiejiari-admin-notice"><p>记录已删除</p></div>';
    }

    // 删除所有记录
    if (isset($_POST['xb_jiejiari_clear_all'])) {
        $wpdb->query("TRUNCATE TABLE $table_name_records");
        echo '<div class="updated xb-jiejiari-admin-notice"><p>所有记录已删除</p></div>';
    }

    // 删除当前用户记录
    if (isset($_POST['xb_jiejiari_clear_user']) && $user_id_filter) {
        $wpdb->delete($table_name_records, ['user_id' => $user_id_filter], ['%d']);
        echo '<div class="updated xb-jiejiari-admin-notice"><p>用户记录已删除</p></div>';
    }

    $where = $user_id_filter ? $wpdb->prepare('WHERE user_id = %d', $user_id_filter) : '';
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name_records $where");
    $records = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name_records $where ORDER BY processed_time DESC LIMIT %d OFFSET %d",
        $per_page, $offset
    ));

    $today = date('Y-m-d');
    $daily_count = $user_id_filter ? $wpdb->get_var($wpdb->prepare(
        "SELECT usage_count FROM $table_name_counts WHERE user_id = %d AND count_date = %s",
        $user_id_filter, $today
    )) : 0;
    $daily_count = $daily_count ? (int) $daily_count : 0;
    $total_user_count = $user_id_filter ? $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name_records WHERE user_id = %d",
        $user_id_filter
    )) : 0;
    $daily_limit = (int) get_option('xb_jiejiari_daily_limit', 10);

    ?>
    <div class="wrap">
        <h1>用户查询记录</h1>
        <p>网站总处理数量：<?php echo $total; ?></p>
        <form method="post">
            <input type="submit" name="xb_jiejiari_clear_all" value="删除所有记录" class="button" onclick="return confirm('确定要删除所有记录吗？此操作不可恢复！');">
        </form>
        <form method="get">
            <input type="hidden" name="page" value="xb-jiejiari-records">
            <label>查询用户 ID: </label>
            <input type="number" name="user_id" value="<?php echo $user_id_filter; ?>">
            <input type="submit" value="查询" class="button">
        </form>
        <?php if ($user_id_filter): ?>
            <p>今日使用次数：<?php echo $daily_count; ?>/<?php echo $daily_limit; ?>，总处理次数：<?php echo $total_user_count; ?></p>
            <form method="post">
                <input type="submit" name="xb_jiejiari_clear_user" value="删除当前用户记录" class="button" onclick="return confirm('确定要删除用户 <?php echo $user_id_filter; ?> 的所有记录吗？此操作不可恢复！');">
            </form>
            <a href="?page=xb-jiejiari-records" class="button" style="margin-top: 10px;">返回全部记录</a>
        <?php endif; ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>用户名</th>
                    <th>设备 ID</th>
                    <th>IP</th>
                    <th>输入日期</th>
                    <th>状态</th>
                    <th>错误信息</th>
                    <th>处理时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record): ?>
                    <tr>
                        <td><?php echo $record->user_id; ?></td>
                        <td><?php echo $record->user_id ? get_userdata($record->user_id)->user_login : '游客'; ?></td>
                        <td><?php echo esc_html($record->device_id); ?></td>
                        <td><?php echo esc_html($record->ip_address); ?></td>
                        <td><?php echo esc_html($record->input_date); ?></td>
                        <td><?php echo esc_html($record->status); ?></td>
                        <td><?php echo esc_html($record->error_message); ?></td>
                        <td><?php echo $record->processed_time; ?></td>
                        <td><a href="?page=xb-jiejiari-records&delete_id=<?php echo $record->id; ?>" class="button">删除</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        $pagination = paginate_links([
            'base'    => add_query_arg('paged', '%#%'),
            'format'  => '',
            'total'   => ceil($total / $per_page),
            'current' => $paged,
        ]);
        if ($pagination) {
            echo '<div class="tablenav"><div class="tablenav-pages">' . $pagination . '</div></div>';
        }
        ?>
    </div>
    <script>
        jQuery(document).ready(function($) {
            setTimeout(function() {
                $('.xb-jiejiari-admin-notice').fadeOut(500);
            }, 3000);
        });
    </script>
    <?php
}

// 缓存管理页面
function xb_jiejiari_cache_page() {
    global $wpdb;
    $table_name_cache = $wpdb->prefix . 'xb_jiejiari_cache';
    $per_page = 20;
    $paged = isset($_GET['paged']) ? (int) $_GET['paged'] : 1;
    $offset = ($paged - 1) * $per_page;

    // 删除单条缓存
    if (isset($_GET['delete_id'])) {
        $wpdb->delete($table_name_cache, ['id' => (int) $_GET['delete_id']], ['%d']);
        echo '<div class="updated xb-jiejiari-admin-notice"><p>缓存已删除</p></div>';
    }

    // 删除所有缓存
    if (isset($_POST['xb_jiejiari_clear_all_cache'])) {
        $wpdb->query("TRUNCATE TABLE $table_name_cache");
        echo '<div class="updated xb-jiejiari-admin-notice"><p>所有缓存已删除</p></div>';
    }

    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name_cache");
    $caches = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name_cache ORDER BY cached_time DESC LIMIT %d OFFSET %d",
        $per_page, $offset
    ));

    ?>
    <div class="wrap">
        <h1>缓存管理</h1>
        <p>缓存总数：<?php echo $total; ?></p>
        <form method="post">
            <input type="submit" name="xb_jiejiari_clear_all_cache" value="删除所有缓存" class="button" onclick="return confirm('确定要删除所有缓存吗？此操作不可恢复！');">
        </form>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>查询日期</th>
                    <th>查询类型</th>
                    <th>缓存时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($caches as $cache): ?>
                    <tr>
                        <td><?php echo esc_html($cache->query_date); ?></td>
                        <td><?php echo $cache->query_type == 0 ? '按日期' : ($cache->query_type == 1 ? '按年' : '按月'); ?></td>
                        <td><?php echo $cache->cached_time; ?></td>
                        <td><a href="?page=xb-jiejiari-cache&delete_id=<?php echo $cache->id; ?>" class="button">删除</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        $pagination = paginate_links([
            'base'    => add_query_arg('paged', '%#%'),
            'format'  => '',
            'total'   => ceil($total / $per_page),
            'current' => $paged,
        ]);
        if ($pagination) {
            echo '<div class="tablenav"><div class="tablenav-pages">' . $pagination . '</div></div>';
        }
        ?>
    </div>
    <script>
        jQuery(document).ready(function($) {
            setTimeout(function() {
                $('.xb-jiejiari-admin-notice').fadeOut(500);
            }, 3000);
        });
    </script>
    <?php
}
?>