(function($) {
    console.log('AI Creation Plugin: JavaScript initialized.');

    // 平台按钮处理
    $(document).on('click', '.ai_creation_platform_button', function() {
        console.log('Platform button clicked:', $(this).data('platform'));
        $('.ai_creation_platform_button').removeClass('active');
        $(this).addClass('active');
    });

    // 示例按钮
    $(document).on('click', '.ai_creation_example_button', function(e) {
        e.preventDefault();
        console.log('Example button clicked.');
        var $textarea = $('#ai_creation_input');
        var exampleLines = ai_creation_example_data.split('\n');
        var newValue = exampleLines.join('\n');
        $textarea.val(newValue);
    });

    // 生成按钮
    $(document).on('click', '.ai_creation_generate_button', function(e) {
        e.preventDefault();
        console.log('Generate button clicked.');

        var $resultContent = $('.ai_creation_result_content');
        var inputData = $('#ai_creation_input').val();
        var $generateButton = $(this);

        // 前端验证违规词
        var forbiddenWords = AICreationData.forbidden_words || [];
        var foundForbiddenWord = null;
        if (forbiddenWords.length > 0) {
            forbiddenWords.forEach(function(word) {
                if (inputData.toLowerCase().indexOf(word.toLowerCase()) !== -1) {
                    foundForbiddenWord = word;
                }
            });
        }

        if (foundForbiddenWord) {
            console.log('Forbidden word detected:', foundForbiddenWord);
            $resultContent.html('<p class="ai_creation_error">输入内容包含违规词“' + foundForbiddenWord + '”，请重新编辑主题</p>');
            return;
        }

        // 显示加载中状态
        $resultContent.html('<span class="loading">正在生成中...</span>');
        
        // 确保用户登录
        if (!AICreationData.nonce) {
            console.log('Nonce not found, user not logged in.');
            $resultContent.html('<p class="ai_creation_error">请先登录以使用文本创作助手。</p>');
            return;
        }

        var data = {
            model: $('#ai_creation_model').val(),
            data: inputData,
            platform: $('.ai_creation_platform_button.active').data('platform') || '',
            enable_search: $('#ai_creation_enable_search').is(':checked')
        };
        console.log('Sending API request with data:', data);

        // 禁用生成按钮，防止重复点击
        $generateButton.prop('disabled', true);

        // 使用 fetch 发起 REST API 请求
        fetch(AICreationData.rest_url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': AICreationData.nonce,
                'Accept': 'text/event-stream'
            },
            body: JSON.stringify(data)
        }).then(response => {
            if (!response.ok) {
                return response.json().then(error => {
                    throw new Error(error.message || '未知错误');
                });
            }

            console.log('API request successful, processing stream...');
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let done = false;
            let hasContent = false;

            function readStream() {
                reader.read().then(({ done: streamDone, value }) => {
                    if (streamDone) {
                        done = true;
                        if (hasContent) {
                            console.log('Stream completed, updating usage count.');
                            updateUsageCount();
                        } else {
                            console.log('No content received.');
                            $resultContent.html('<p class="ai_creation_error">生成失败，未收到有效内容。</p>');
                        }
                        $generateButton.prop('disabled', false);
                        return;
                    }

                    const chunk = decoder.decode(value, { stream: true });
                    const lines = chunk.split('\n');
                    lines.forEach(line => {
                        if (line.trim().startsWith('data: ')) {
                            const jsonData = line.trim().substring(6);
                            if (jsonData === '[DONE]') {
                                done = true;
                                if (hasContent) {
                                    console.log('Stream done, updating usage count.');
                                    updateUsageCount();
                                } else {
                                    console.log('No content received at stream end.');
                                    $resultContent.html('<p class="ai_creation_error">生成失败，未收到有效内容。</p>');
                                }
                                $generateButton.prop('disabled', false);
                                return;
                            }

                            try {
                                const data = JSON.parse(jsonData);
                                if (data.error) {
                                    console.log('API error:', data.error);
                                    $resultContent.html('<p class="ai_creation_error">' + data.error + '</p>');
                                    $generateButton.prop('disabled', false);
                                    return;
                                }
                                if ($resultContent.text() === '正在生成中...') {
                                    $resultContent.empty();
                                }
                                if (data.content) {
                                    hasContent = true;
                                    $resultContent.append(data.content);
                                    console.log('Received content chunk:', data.content);
                                }
                            } catch (e) {
                                console.error('解析流数据出错:', e, ' - 原始数据:', jsonData);
                                $resultContent.html('<p class="ai_creation_error">生成过程中发生错误，请检查日志。</p>');
                                $generateButton.prop('disabled', false);
                            }
                        }
                    });

                    if (!done) {
                        readStream();
                    }
                }).catch(error => {
                    console.error('流读取失败:', error);
                    $resultContent.html('<p class="ai_creation_error">生成过程中发生错误，请检查日志。</p>');
                    $generateButton.prop('disabled', false);
                });
            }

            readStream();
        }).catch(error => {
            console.error('API 请求失败:', error);
            $resultContent.html('<p class="ai_creation_error">' + error.message + '</p>');
            $generateButton.prop('disabled', false);
        });
    });

    // 复制按钮
    $(document).on('click', '.ai_creation_copy_button', function(e) {
        e.preventDefault();
        console.log('Copy button clicked.');
        var $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val($('.ai_creation_result_content').text()).select();
        document.execCommand('copy');
        $temp.remove();

        $('.ai_creation_copy_success').html('<p class="copy-success">复制成功！</p>');
        setTimeout(function() {
            $('.ai_creation_copy_success').empty();
        }, 2000);
    });

    // 清空按钮
    $(document).on('click', '.ai_creation_clear_button', function(e) {
        e.preventDefault();
        console.log('Clear button clicked.');
        $('.ai_creation_result_content').empty();
    });

    // 快速登录按钮
    $(document).on('click', '.ai_creation_quick_login_button', function(e) {
        e.preventDefault();
        console.log('Quick login button clicked.');
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = '<?php echo esc_url(wp_login_url(get_permalink())); ?>';
        }
    });

    // 更新使用次数显示
    function updateUsageCount() {
        console.log('更新使用次数通过 AJAX.');
        $.ajax({
            url: AICreationData.rest_url.replace('/generate', '/usage'),
            method: 'GET',
            headers: {
                'X-WP-Nonce': AICreationData.nonce
            },
            success: function(response) {
                console.log('使用次数更新:', response);
                var $usageDisplay = $('.ai_creation_usage');
                var $generateButton = $('.ai_creation_generate_button');
                if (response.remaining <= 0) {
                    $usageDisplay.text('今日已经使用完，请明天再来');
                    $generateButton.hide(); // 隐藏生成按钮
                } else {
                    $usageDisplay.text('今日可用次数：' + response.limit + '/' + response.remaining);
                    $generateButton.show(); // 显示生成按钮
                }
            },
            error: function(error) {
                console.error('更新使用次数失败:', error);
                $('.ai_creation_usage').text('今日可用次数：无法加载');
                $('.ai_creation_generate_button').hide(); // 隐藏生成按钮以防出错
            }
        });
    }

    // 启用联网搜索开关的点击处理
    $(document).on('click', '.ai_creation_search_toggle .slider', function(e) {
        e.preventDefault();
        var $checkbox = $(this).siblings('input[type="checkbox"]');
        $checkbox.prop('checked', !$checkbox.prop('checked'));
        console.log('搜索开关滑块点击，新状态:', $checkbox.prop('checked'));
    });

    // 防止点击文字触发开关
    $(document).on('click', '.ai_creation_search_toggle', function(e) {
        // 只允许 .slider 触发切换，其他点击（包括文字）不触发
        if (!$(e.target).hasClass('slider')) {
            e.preventDefault();
            e.stopPropagation();
            console.log('点击搜索开关文字或周围区域，无切换动作.');
        }
    });

    // 页面加载时初始化使用次数
    $(document).ready(function() {
        updateUsageCount(); // 初始加载时检查使用次数
    });

    // 初始化检查
    console.log('AICreationData:', AICreationData);
})(jQuery);