/*
 * 英汉词典前端脚本
 * Version: 1.0.9
 * Author: Summer
 */
jQuery(document).ready(function($) {
    const $input = $('#xb-cidian-input');
    const $processBtn = $('#xb-cidian-process-btn');
    const $clearBtn = $('#xb-cidian-clear-btn');
    const $loginBtn = $('#xb-cidian-login-btn');
    const $result = $('#xb-cidian-result');
    const $notification = $('#xb-cidian-notification');
    const $usage = $('.xb-cidian-usage');
    const isUserLoggedIn = xb_cidian_vars.is_user_logged_in === 'yes';

    // 新增：初始化使用次数显示
    function initUsageCount() {
        const ajaxOptions = {
            url: xb_cidian_vars.ajax_url + 'usage',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                console.log('Usage response:', response); // 调试：记录响应
                if (response.show_stats && $usage.length) {
                    if (response.remaining > 0) {
                        $usage.text(`今日剩余查询次数：${response.remaining}/${response.limit}`);
                        $processBtn.show();
                        $loginBtn.hide();
                    } else {
                        $usage.text(isUserLoggedIn ? '今日使用次数已用完，请明天再来' : '游客的使用次数已用完，请登录之后继续');
                        $processBtn.hide();
                        if (!isUserLoggedIn) {
                            $loginBtn.show();
                        }
                    }
                    $usage.show(); // 确保元素可见
                } else {
                    $usage.hide(); // 隐藏统计信息（如果 show_stats 为 false）
                }
                // 更新按钮状态
                $processBtn.prop('disabled', response.remaining <= 0 || $input.val().trim() === '');
            },
            error: function(xhr) {
                console.error('Failed to fetch usage count:', xhr.responseJSON?.message || 'Unknown error');
            }
        };

        if (isUserLoggedIn && xb_cidian_vars.nonce) {
            ajaxOptions.headers = { 'X-WP-Nonce': xb_cidian_vars.nonce };
        }

        $.ajax(ajaxOptions);
    }

    // 实时更新按钮状态
    $input.on('input', function() {
        const value = $(this).val().trim();
        initUsageCount(); // 优化：输入时重新检查使用次数
    });

    // 回车键触发查询
    $input.on('keydown', function(e) {
        if (e.key === 'Enter' && !$processBtn.prop('disabled')) {
            e.preventDefault();
            $processBtn.click();
        }
    });

    // 提交查询
    $processBtn.on('click', function() {
        const word = $input.val().trim();
        if (!word) {
            showNotification('请输入英文单词', 'error');
            return;
        }

        $result.html('<div class="xb-cidian-processing">正在查询中...</div>');

        const ajaxOptions = {
            url: xb_cidian_vars.ajax_url + 'process',
            method: 'POST',
            data: JSON.stringify({ word: word }),
            contentType: 'application/json',
            success: function(response) {
                console.log('Process response:', response); // 调试：记录响应
                if (response.error) {
                    showNotification(response.error, 'error');
                    $result.empty();
                    if (response.remaining === 0) {
                        $processBtn.hide();
                        if (response.is_guest) {
                            $loginBtn.show();
                        }
                    }
                    initUsageCount(); // 优化：重新获取使用次数
                    return;
                }

                let resultHtml = '';
                if (response.word && response.content) {
                    const parts = response.content.split(':');
                    const pos = parts[0] ? `<span class="xb-cidian-pos">${parts[0]}:</span>` : '';
                    const meanings = parts[1] ? parts[1].split(',').map(m => `<span class="xb-cidian-meaning">${m.trim()}</span>`).join(', ') : '';
                    resultHtml = `<div class="xb-cidian-result-item">
                        <div class="xb-cidian-result-word">${response.word}</div>
                        <div class="xb-cidian-result-content">${pos} ${meanings}</div>
                    </div>`;
                } else {
                    resultHtml = '<p class="xb-cidian-no-result">无相关查询结果，请尝试其他单词</p>';
                }
                $result.html(resultHtml);
                initUsageCount(); // 优化：查询成功后重新获取使用次数
            },
            error: function(xhr) {
                const message = xhr.responseJSON?.message || '暂时无法查询请联系客服';
                showNotification(message, 'error');
                $result.empty();
                initUsageCount(); // 优化：错误时也尝试更新使用次数
            }
        };

        if (isUserLoggedIn && xb_cidian_vars.nonce) {
            ajaxOptions.headers = { 'X-WP-Nonce': xb_cidian_vars.nonce };
        }

        $.ajax(ajaxOptions);
    });

    // 清空输入和结果
    $clearBtn.on('click', function() {
        $input.val('');
        $result.empty();
        $notification.empty();
        initUsageCount(); // 优化：清空时重新检查使用次数
    });

    // 快速登录按钮点击事件
    $loginBtn.on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = xb_cidian_vars.login_url;
        }
    });

    // 更新使用次数显示（保留原函数，供兼容性）
    function updateUsageCount(remaining, limit) {
        if (!$usage.length || !$usage.is(':visible')) return;
        if (remaining > 0) {
            $usage.text(`今日剩余查询次数：${remaining}/${limit}`);
            $processBtn.show();
            $loginBtn.hide();
        } else {
            $usage.text(isUserLoggedIn ? '今日使用次数已用完，请明天再来' : '游客的使用次数已用完，请登录之后继续');
            $processBtn.hide();
            if (!isUserLoggedIn) {
                $loginBtn.show();
            }
        }
    }

    // 显示通知消息
    function showNotification(message, type) {
        const className = type === 'error' ? 'xb-cidian-error' : 'xb-cidian-success';
        $notification.html(`<div class="${className}">${message}</div>`);
        setTimeout(() => {
            $notification.empty();
        }, 3000);
    }

    // 初始化：加载页面时获取使用次数
    initUsageCount();
});