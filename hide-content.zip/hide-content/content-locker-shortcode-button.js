(function() {
    tinymce.PluginManager.add('custom_content_locker_shortcode_button', function(editor, url) {
        editor.addButton('custom_content_locker_shortcode_button', {
            text: '隐藏内容',
            icon: false,
            onclick: function() {
                editor.windowManager.open({
                    title: '隐藏内容需要输入验证码才能查看',
                    body: [{
                        type: 'textbox',
                        name: 'content',
                        label: '内容',
                        multiline: true,
                        minWidth: editor.getParam('vc_welcome_editor_width', 400),
                        minHeight: Math.min(tinymce.DOM.getViewPort().h - 200, 600)
                    }],
                    onsubmit: function(e) {
                        editor.insertContent('[content_locker]' + e.data.content + '[/content_locker]');
                    }
                });
            }
        });
    });
})();
