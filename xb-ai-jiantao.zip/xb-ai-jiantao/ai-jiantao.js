(function($) {
    console.log('AI Jiantao Plugin: JavaScript initialized.');

    // 老师或领导按钮处理
    $(document).on('click', '.ai_jiantao_leader_button', function() {
        console.log('Leader button clicked:', $(this).data('leader'));
        $('.ai_jiantao_leader_button').removeClass('active');
        $(this).addClass('active');
    });

    // 示例按钮
    $(document).on('click', '.ai_jiantao_example_button', function(e) {
        e.preventDefault();
        console.log('Example button clicked.');
        var $textarea = $('#ai_jiantao_input');
        var exampleLines = ai_jiantao_example_data.split('\n');
        var newValue = exampleLines.join('\n');
        $textarea.val(newValue);
    });

    // 生成按钮
    $(document).on('click', '.ai_jiantao_generate_button', function(e) {
        e.preventDefault();
        console.log('Generate button clicked.');

        var $resultContent = $('.ai_jiantao_result_content');
        var inputData = $('#ai_jiantao_input').val();
        var $generateButton = $(this);

        // 前端验证违规词
        var forbiddenWords = AIJiantaoData.forbidden_words || [];
        var foundForbiddenWord = null;
        if (forbiddenWords.length > 0) {
            forbiddenWords.forEach(function(word) {
                if (inputData.toLowerCase().indexOf(word.toLowerCase()) !== -1) {
                    foundForbiddenWord = word;
                }
            });
        }

        if (foundForbiddenWord) {
            console.log('Forbidden word detected: ', foundForbiddenWord);
            $resultContent.html('<p class="ai_jiantao_error">输入内容包含违规词“' + $('<div>').text(foundForbiddenWord).html() + '”，请重新编辑错误描述</p>');
            return;
        }

        // 显示加载中状态
        $resultContent.html('<span class="loading">正在生成中...</span>');

        // 确保用户登录
        if (!AIJiantaoData.nonce) {
            console.log('Nonce not found, user not logged in.');
            $resultContent.html('<p class="ai_jiantao_error">请先登录以使用检讨书生成助手。</p>');
            return;
        }

        var data = {
            model: $('#ai_jiantao_model').val(),
            data: inputData,
            leader: $('.ai_jiantao_leader_button.active').data('leader') || '',
            enable_search: $('#ai_jiantao_enable_search').is(':checked')
        };

        console.log('Sending API request with data:', data);

        // 禁用生成按钮，防止重复点击
        $generateButton.prop('disabled', true);

        // 使用 fetch 发起 REST API 请求
        fetch(AIJiantaoData.rest_url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': AIJiantaoData.nonce,
                'Accept': 'text/event-stream'
            },
            body: JSON.stringify(data)
        }).then(response => {
            if (!response.ok) {
                return response.json().then(json => {
                    throw new Error(json.message || '未知错误');
                });
            }

            console.log('API request successful, processing stream...');
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let done = false;
            let hasContent = false;

            function readStream() {
                reader.read().then(({ done: streamDone, value }) => {
                    if (streamDone) {
                        done = true;
                        if (hasContent) {
                            console.log('Stream completed, updating usage count.');
                            updateUsageCount();
                        } else {
                            console.log('No content received.');
                            $resultContent.html('<p class="ai_jiantao_error">生成失败，未收到有效内容。</p>');
                        }
                        $generateButton.prop('disabled', false);
                        return;
                    }

                    const chunk = decoder.decode(value, { stream: true });
                    const lines = chunk.split('\n');
                    lines.forEach(line => {
                        if (line.trim().startsWith('data: ')) {
                            const jsonData = line.trim().substring(6);
                            if (jsonData === '[DONE]') {
                                done = true;
                                if (hasContent) {
                                    console.log('Stream done, updating usage count.');
                                    updateUsageCount();
                                } else {
                                    console.log('No content received at stream end.');
                                    $resultContent.html('<p class="ai_jiantao_error">生成失败，未收到有效内容。</p>');
                                }
                                $generateButton.prop('disabled', false);
                                return;
                            }

                            try {
                                const data = JSON.parse(jsonData);
                                if (data.error) {
                                    console.log('API error:', data.error);
                                    $resultContent.html('<p class="ai_jiantao_error">' + $('<div>').text(data.error).html() + '</p>');
                                    $generateButton.prop('disabled', false);
                                    return;
                                }
                                if ($resultContent.text() === '正在生成中...') {
                                    $resultContent.empty();
                                }
                                if (data.content) {
                                    hasContent = true;
                                    $resultContent.append($('<div>').text(data.content).html());
                                    console.log('Received content chunk:', data.content);
                                }
                            } catch (e) {
                                console.error('解析流数据出错:', e, ' - 原始数据:', jsonData);
                                $resultContent.html('<p class="ai_jiantao_error">生成过程中发生错误，请检查日志。</p>');
                                $generateButton.prop('disabled', false);
                            }
                        }
                    });

                    if (!done) {
                        readStream();
                    }
                }).catch(error => {
                    console.error('Stream reading failed:', error);
                    $resultContent.html('<p class="ai_jiantao_error">生成过程中发生错误。</p>');
                    $generateButton.prop('disabled', false);
                });
            }

            readStream();
        }).then(response => {
            if (!response.ok) {
                return response.json().then(json => {
                    throw new Error(json.message || '未知错误');
                });
            }

            console.log('API request successful, processing stream...');
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let done = false;
            let hasContent = false;

            function readStream() {
                reader.read().then(({ done: streamDone, value }) => {
                    if (streamDone) {
                        done = true;
                        if (hasContent) {
                            console.log('Stream completed, updating usage count.');
                            updateUsageCount();
                        } else {
                            console.log('No content received.');
                            $resultContent.html('<p class="ai_jiantao_error">生成失败，未收到有效内容。</p>');
                        }
                        $generateButton.prop('disabled', false);
                        return;
                    }

                    const chunk = decoder.decode(value, { stream: true });
                    const lines = chunk.split('\n');
                    lines.forEach(line => {
                        if (line.trim().startsWith('data: ')) {
                            const jsonData = line.trim().substring(6);
                            if (jsonData === '[DONE]') {
                                done = true;
                                if (hasContent) {
                                    console.log('Stream done, updating usage count.');
                                    updateUsageCount();
                                } else {
                                    console.log('No content received at stream end.');
                                    $resultContent.html('<p class="ai_jiantao_error">生成失败，未收到有效内容。</p>');
                                }
                                $generateButton.prop('disabled', false);
                                return;
                            }

                            try {
                                const data = JSON.parse(jsonData);
                                if (data.error) {
                                    console.log('API error:', data.error);
                                    $resultContent.html('<p class="ai_jiantao_error">' + $('<div>').text(data.error).html() + '</p>');
                                    $generateButton.prop('disabled', false);
                                    return;
                                }
                                if ($resultContent.text() === '正在生成中...') {
                                    $resultContent.empty();
                                }
                                if (data.content) {
                                    hasContent = true;
                                    $resultContent.append($('<div>').text(data.content).html());
                                    console.log('Received content chunk:', data.content);
                                }
                            } catch (e) {
                                console.error('解析流数据出错:', e, ' - 原始数据:', jsonData);
                                $resultContent.html('<p class="ai_jiantao_error">生成过程中发生错误，请检查日志。</p>');
                                $generateButton.prop('disabled', false);
                            }
                        }
                    });

                    if (!done) {
                        readStream();
                    }
                }).catch(error => {
                    console.error('Stream reading failed:', error);
                    $resultContent.html('<p class="ai_jiantao_error">生成过程中发生错误。</p>');
                    $generateButton.prop('disabled', false);
                });
            }

            readStream();
        }).catch(error => {
            console.error('API request failed:', error);
            $resultContent.html('<p class="ai_jiantao_error">' + $('<div>').text(error.message).html() + '</p>');
            $generateButton.prop('disabled', false);
        });
    });

    // 复制按钮
    $(document).on('click', '.ai_jiantao_copy_button', function(e) {
        e.preventDefault();
        console.log('Copy button clicked.');
        var $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val($('.ai_jiantao_result_content').text()).select();
        try {
            document.execCommand('copy');
            $('.ai_jiantao_copy_success').html('<p class="copy-success">复制成功！</p>');
            setTimeout(function() {
                $('.ai_jiantao_copy_success').empty();
            }, 2000);
        } catch (err) {
            console.error('Copy failed:', err);
            $('.ai_jiantao_copy_success').html('<p class="copy-error">复制失败，请手动复制。</p>');
        }
        $temp.remove();
    });

    // 清空按钮
    $(document).on('click', '.ai_jiantao_clear_button', function(e) {
        e.preventDefault();
        console.log('Clear button clicked.');
        $('.ai_jiantao_result_content').empty();
    });

    // 快速登录按钮
    $(document).on('click', '.ai_jiantao_quick_login_button', function(e) {
        e.preventDefault();
        console.log('Quick login button clicked.');
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.click();
        } else {
            window.location.href = '<?php echo esc_url(wp_login_url(get_permalink())); ?>';
        }
    });

    // 更新使用次数显示
    function updateUsageCount() {
        console.log('Updating usage count via AJAX.');
        $.ajax({
            url: AIJiantaoData.rest_url.replace('/generate', '/usage'),
            method: 'GET',
            headers: {
                'X-WP-Nonce': AIJiantaoData.nonce
            },
            success: function(response) {
                console.log('Usage count updated:', response);
                var $usageDisplay = $('.ai_jiantao_usage');
                var $generateButton = $('.ai_jiantao_generate_button');
                if (response.remaining <= 0) {
                    $usageDisplay.text('今日已用尽可用次数，请明天再来');
                    $generateButton.hide();
                } else {
                    $usageDisplay.text('今日可用次数：' + response.limit + '/' + response.remaining);
                    $generateButton.show();
                }
            },
            error: function(error) {
                console.error('Failed to update usage count:', error);
                $('.ai_jiantao_usage').text('今日可用次数：无法加载');
                $('.ai_jiantao_generate_button').hide();
            }
        });
    }

    // 启用联网搜索开关的点击处理
    $(document).on('click', '.ai_jiantao_search_toggle .slider', function(e) {
        e.preventDefault();
        var $checkbox = $(this).siblings('input[type="checkbox"]');
        $checkbox.prop('checked', !$checkbox.prop('checked'));
        console.log('Search switch clicked, new state:', $checkbox.prop('checked'));
    });

    // 防止点击文字触发开关
    $(document).on('click', '.ai_jiantao_search_toggle', function(e) {
        if (!$(e.target).hasClass('slider')) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Clicked search toggle label or surrounding area, no toggle action.');
        }
    });

    // 页面加载时初始化使用次数
    $(document).ready(function() {
        updateUsageCount();
    });

    // 初始化检查
    console.log('AIJiantaoData:', AIJiantaoData);
})(jQuery);