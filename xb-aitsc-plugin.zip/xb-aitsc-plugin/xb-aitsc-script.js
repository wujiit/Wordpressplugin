/**
 * AI提示词大全插件前端脚本
 */

(function($) {
    'use strict';
    
    // 页面加载完成后初始化
    $(document).ready(function() {
        initCopyButtons();
        initLikeButtons();
        initToast();
        initSearch();
    });
    
    /**
     * 初始化复制按钮功能
     */
    function initCopyButtons() {
        $(document).off('click.xbAitscCopy').on('click.xbAitscCopy', '.xb-aitsc-copy-btn', function() {
            const button = $(this);
            const promptId = button.data('prompt-id');
            const content = button.data('content');
            
            // 防止重复点击
            if (button.prop('disabled')) {
                return;
            }
            
            // 复制到剪贴板
            copyToClipboard(content).then(function() {
                // 复制成功，更新热度
                updateHotCount(promptId, button);
                showToast('复制成功！', 'success');
            }).catch(function() {
                showToast('复制失败，请手动复制', 'error');
            });
        });
    }
    
    /**
     * 复制文本到剪贴板
     */
    function copyToClipboard(text) {
        return new Promise(function(resolve, reject) {
            // 现代浏览器使用 Clipboard API
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(resolve).catch(reject);
            } else {
                // 兼容旧浏览器
                const textArea = document.createElement('textarea');
                textArea.value = text;
                textArea.style.position = 'fixed';
                textArea.style.left = '-999999px';
                textArea.style.top = '-999999px';
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                
                try {
                    const successful = document.execCommand('copy');
                    document.body.removeChild(textArea);
                    if (successful) {
                        resolve();
                    } else {
                        reject();
                    }
                } catch (err) {
                    document.body.removeChild(textArea);
                    reject(err);
                }
            }
        });
    }
    
    /**
     * 更新提示词热度
     */
    function updateHotCount(promptId, button) {
        // 禁用按钮防止重复点击
        button.prop('disabled', true);
        const originalText = button.text();
        button.html('<span class="xb-aitsc-loading"></span> 复制中');
        
        $.ajax({
            url: xb_aitsc_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_aitsc_copy_prompt',
                prompt_id: promptId,
                nonce: xb_aitsc_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    // 更新热度显示
                    const hotCountElement = button.closest('.xb-aitsc-prompt-card').find('.xb-aitsc-hot-count');
                    const currentCount = parseInt(hotCountElement.text().replace(/[^\d]/g, '')) || 0;
                    hotCountElement.text('🔥 ' + (currentCount + 1));
                }
            },
            error: function() {
                console.log('热度更新失败');
            },
            complete: function() {
                // 恢复按钮状态
                setTimeout(function() {
                    button.prop('disabled', false);
                    button.text(originalText);
                }, 1000);
            }
        });
    }

    function initLikeButtons() {
        $(document).off('click.xbAitscLike').on('click.xbAitscLike', '.xb-aitsc-like-btn', function() {
            const button = $(this);
            const promptId = parseInt(button.data('prompt-id'), 10) || 0;
            if (!promptId) return;

            const storeKey = 'xb_aitsc_likes';
            let liked = {};
            try {
                liked = JSON.parse(localStorage.getItem(storeKey) || '{}') || {};
            } catch (e) {
                liked = {};
            }

            if (liked[String(promptId)]) {
                button.prop('disabled', true);
                return;
            }

            if (button.prop('disabled')) {
                return;
            }

            button.prop('disabled', true);

            $.ajax({
                url: xb_aitsc_ajax.ajax_url,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: xb_aitsc_ajax.like_action || 'xb_aitsc_like_prompt',
                    prompt_id: promptId,
                    nonce: xb_aitsc_ajax.nonce
                },
                success: function(response) {
                    if (response && response.success && response.data && typeof response.data.like_count !== 'undefined') {
                        const countEl = button.find('.xb-aitsc-like-count');
                        if (countEl.length) {
                            countEl.text(String(response.data.like_count));
                        }
                        liked[String(promptId)] = 1;
                        try {
                            localStorage.setItem(storeKey, JSON.stringify(liked));
                        } catch (e) {}
                        showToast('点赞成功！', 'success');
                    } else {
                        button.prop('disabled', false);
                        if (response && response.data) {
                            showToast(String(response.data), 'error');
                        } else {
                            showToast('点赞失败', 'error');
                        }
                    }
                },
                error: function() {
                    button.prop('disabled', false);
                    showToast('点赞失败', 'error');
                }
            });
        });
    }
    
    /**
     * 初始化提示框
     */
    function initToast() {
        // 如果不存在提示框，创建一个
        if ($('#xb-aitsc-toast').length === 0) {
            $('body').append('<div id="xb-aitsc-toast" class="xb-aitsc-toast"><span id="xb-aitsc-toast-message"></span></div>');
        }
    }
    
    /**
     * 显示提示消息
     */
    function showToast(message, type) {
        const toast = $('#xb-aitsc-toast');
        const messageElement = $('#xb-aitsc-toast-message');
        
        // 设置消息内容和类型
        messageElement.text(message);
        toast.removeClass('success error').addClass(type || 'success');
        
        // 显示提示框
        toast.addClass('show');
        
        // 3秒后自动隐藏
        setTimeout(function() {
            toast.removeClass('show');
        }, 3000);
    }
    /**
     * 搜索功能
     */
    function initSearch() {
        const container = $('.xb-aitsc-container').first();
        if (container.length === 0 || typeof xb_aitsc_ajax === 'undefined') {
            return;
        }

        const baseUrl = container.data('base-url') || window.location.href;
        const state = {
            category: parseInt(container.data('category'), 10) || 0,
            sort: (container.data('sort') || 'hot').toString(),
            search: (container.data('search') || '').toString()
        };
        const searchParam = xb_aitsc_ajax.search_param || 'xbsearch';
        const pageParam = xb_aitsc_ajax.page_param || 'xbpage';
        let debounceTimer = null;
        let lastRequest = null;

        // 添加搜索框
        const searchHtml = `
            <div class="xb-aitsc-search-box">
                <input type="text" id="xb-aitsc-search-input" placeholder="搜索提示词..." />
                <button id="xb-aitsc-search-btn" class="xb-aitsc-search-btn">🔍</button>
            </div>
        `;
        
        $('.xb-aitsc-filters').prepend(searchHtml);

        const input = $('#xb-aitsc-search-input');
        input.val(state.search);

        function parseUrl(urlString) {
            try {
                const url = new URL(urlString, window.location.origin);
                const categoryValue = parseInt(url.searchParams.get('category'), 10);
                const sortValue = (url.searchParams.get('sort') || 'hot').toString();
                const searchValue = (url.searchParams.get(searchParam) || '').toString();
                const pageValue = parseInt(url.searchParams.get(pageParam), 10);

                return {
                    category: Number.isFinite(categoryValue) ? categoryValue : 0,
                    sort: sortValue,
                    search: searchValue,
                    page: Number.isFinite(pageValue) && pageValue > 0 ? pageValue : 1
                };
            } catch (e) {
                return { category: 0, sort: 'hot', search: '', page: 1 };
            }
        }

        function buildUrl(searchTerm, page) {
            const url = new URL(baseUrl, window.location.origin);
            if (state.category > 0) {
                url.searchParams.set('category', String(state.category));
            } else {
                url.searchParams.delete('category');
            }
            if (state.sort) {
                url.searchParams.set('sort', String(state.sort));
            } else {
                url.searchParams.delete('sort');
            }
            if (searchTerm) {
                url.searchParams.set(searchParam, searchTerm);
            } else {
                url.searchParams.delete(searchParam);
            }
            if (page && page > 1) {
                url.searchParams.set(pageParam, String(page));
            } else {
                url.searchParams.delete(pageParam);
            }
            return url.toString();
        }

        function parsePageFromHref(href) {
            try {
                const url = new URL(href, window.location.origin);
                const value = parseInt(url.searchParams.get(pageParam), 10);
                return Number.isFinite(value) && value > 0 ? value : 1;
            } catch (e) {
                return 1;
            }
        }

        function updateFilterActiveUi() {
            $('.xb-aitsc-filter-btn').each(function() {
                const href = $(this).attr('href') || '';
                const parsed = parseUrl(href);
                const isActive = (parseInt(parsed.category, 10) || 0) === (parseInt(state.category, 10) || 0);
                $(this).toggleClass('active', isActive);
            });

            $('.xb-aitsc-sort-btn').each(function() {
                const href = $(this).attr('href') || '';
                const parsed = parseUrl(href);
                const isActive = (parsed.sort || 'hot') === (state.sort || 'hot');
                $(this).toggleClass('active', isActive);
            });
        }

        function setResultsHtml(html) {
            const currentResults = $('.xb-aitsc-results').first();
            if (currentResults.length) {
                currentResults.replaceWith(html);
            }
        }

        function performSearch(page, historyMode) {
            const searchTerm = input.val().toString().trim();
            const targetPage = Number.isFinite(page) && page > 0 ? page : 1;
            state.search = searchTerm;
            container.attr('data-search', searchTerm);

            if (lastRequest && lastRequest.readyState !== 4) {
                lastRequest.abort();
            }

            lastRequest = $.ajax({
                url: xb_aitsc_ajax.ajax_url,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: xb_aitsc_ajax.search_action || 'xb_aitsc_search_prompts',
                    nonce: xb_aitsc_ajax.nonce,
                    search_term: searchTerm,
                    category: state.category,
                    sort: state.sort,
                    page: targetPage,
                    base_url: baseUrl
                },
                success: function(response) {
                    if (response && response.success && response.data && response.data.html) {
                        setResultsHtml(response.data.html);
                        updateFilterActiveUi();
                        if (historyMode === 'push') {
                            const url = buildUrl(searchTerm, targetPage);
                            window.history.pushState({}, '', url);
                        } else if (historyMode === 'replace') {
                            const url = buildUrl(searchTerm, targetPage);
                            window.history.replaceState({}, '', url);
                        }
                    }
                },
                error: function() {
                    const fallback = searchTerm.toLowerCase();
                    if (fallback) {
                        filterPrompts(fallback);
                    }
                }
            });
        }
        
        input.on('input', function() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(function() {
                performSearch(1, 'replace');
            }, 300);
        });
        
        $('#xb-aitsc-search-btn').on('click', function() {
            performSearch(1, 'push');
        });
        
        // 回车搜索
        input.on('keypress', function(e) {
            if (e.which === 13) {
                performSearch(1, 'push');
            }
        });

        $(document).off('click.xbAitscPagination').on('click.xbAitscPagination', '.xb-aitsc-pagination a.page-numbers', function(e) {
            const href = $(this).attr('href');
            if (!href) return;
            e.preventDefault();
            const nextPage = parsePageFromHref(href);
            performSearch(nextPage, 'push');
        });

        $(document).off('click.xbAitscFilter').on('click.xbAitscFilter', '.xb-aitsc-filter-btn, .xb-aitsc-sort-btn', function(e) {
            const href = $(this).attr('href');
            if (!href) return;
            e.preventDefault();

            const parsed = parseUrl(href);
            state.category = parseInt(parsed.category, 10) || 0;
            state.sort = (parsed.sort || 'hot').toString();

            container.attr('data-category', String(state.category));
            container.attr('data-sort', state.sort);

            updateFilterActiveUi();
            performSearch(1, 'push');
        });

        window.addEventListener('popstate', function() {
            const parsed = parseUrl(window.location.href);

            state.category = parseInt(parsed.category, 10) || 0;
            state.sort = (parsed.sort || 'hot').toString();
            state.search = (parsed.search || '').toString();

            container.attr('data-category', String(state.category));
            container.attr('data-sort', state.sort);
            container.attr('data-search', state.search);

            input.val(state.search);
            updateFilterActiveUi();
            performSearch(parsed.page || 1, false);
        });
    }
    
    /**
     * 过滤提示词
     */
    function filterPrompts(searchTerm) {
        $('.xb-aitsc-prompt-card').each(function() {
            const card = $(this);
            const title = card.find('.xb-aitsc-prompt-title').text().toLowerCase();
            const content = card.find('.xb-aitsc-prompt-content').text().toLowerCase();
            
            if (title.includes(searchTerm) || content.includes(searchTerm)) {
                card.show();
            } else {
                card.hide();
            }
        });
        
        // 检查是否有可见的卡片
        const visibleCards = $('.xb-aitsc-prompt-card:visible');
        if (visibleCards.length === 0) {
            if ($('.xb-aitsc-no-search-result').length === 0) {
                $('.xb-aitsc-prompts-grid').append('<div class="xb-aitsc-no-search-result xb-aitsc-no-data"><p>没有找到匹配的提示词</p></div>');
            }
        } else {
            $('.xb-aitsc-no-search-result').remove();
        }
    }
    

    
})(jQuery);
