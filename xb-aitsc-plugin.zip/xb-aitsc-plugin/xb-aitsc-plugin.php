<?php
/**
 * Plugin Name: 启灵AI提示词
 * Plugin URI: https://www.wujiit.com/
 * Description: 一个功能完整的AI提示词管理和展示插件
 * Version: 1.0.3
 * Author: Summer
 */

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('XB_AITSC_VERSION', '1.0.3');
define('XB_AITSC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('XB_AITSC_PLUGIN_PATH', plugin_dir_path(__FILE__));

class XB_AITSC_Plugin {
    
    public function __construct() {
        // 插件激活和停用钩子
        register_activation_hook(__FILE__, array($this, 'xb_aitsc_activate'));
        register_deactivation_hook(__FILE__, array($this, 'xb_aitsc_deactivate'));
        
        // 初始化钩子
        add_action('init', array($this, 'xb_aitsc_init'));
        add_action('admin_menu', array($this, 'xb_aitsc_admin_menu'));
        add_action('wp_enqueue_scripts', array($this, 'xb_aitsc_enqueue_scripts'));
        add_action('wp_ajax_xb_aitsc_copy_prompt', array($this, 'xb_aitsc_handle_copy_prompt'));
        add_action('wp_ajax_nopriv_xb_aitsc_copy_prompt', array($this, 'xb_aitsc_handle_copy_prompt'));
        add_action('wp_ajax_update_hot_count', array($this, 'xb_aitsc_update_hot_count_ajax'));
        add_action('wp_ajax_xb_aitsc_search_prompts', array($this, 'xb_aitsc_search_prompts_ajax'));
        add_action('wp_ajax_nopriv_xb_aitsc_search_prompts', array($this, 'xb_aitsc_search_prompts_ajax'));
        add_action('wp_ajax_xb_aitsc_like_prompt', array($this, 'xb_aitsc_like_prompt_ajax'));
        add_action('wp_ajax_nopriv_xb_aitsc_like_prompt', array($this, 'xb_aitsc_like_prompt_ajax'));
        add_action('admin_footer', array($this, 'xb_aitsc_admin_auto_dismiss_script'));
    }
    
    /**
     * 插件激活时执行
     */
    public function xb_aitsc_activate() {
        $this->xb_aitsc_create_tables();
        $this->xb_aitsc_create_page();
        flush_rewrite_rules();
    }
    
    /**
     * 插件停用时执行
     */
    public function xb_aitsc_deactivate() {
        flush_rewrite_rules();
    }
    
    /**
     * 创建数据库表
     */
    private function xb_aitsc_create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // 创建分类表
        $categories_table = $wpdb->prefix . 'xb_aitsc_categories';
        $categories_sql = "CREATE TABLE $categories_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            description text,
            sort_order int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // 创建提示词表
        $prompts_table = $wpdb->prefix . 'xb_aitsc_prompts';
        $prompts_sql = "CREATE TABLE $prompts_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            title varchar(200) NOT NULL,
            content text NOT NULL,
            category_id mediumint(9) NOT NULL,
            image_url varchar(500) DEFAULT NULL,
            source varchar(200) DEFAULT NULL,
            hot_count int(11) DEFAULT 0,
            like_count int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY category_id (category_id)
        ) $charset_collate;";
        
        // 创建设置表
        $settings_table = $wpdb->prefix . 'xb_aitsc_settings';
        $settings_sql = "CREATE TABLE $settings_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            option_name varchar(100) NOT NULL,
            option_value longtext,
            PRIMARY KEY (id),
            UNIQUE KEY option_name (option_name)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($categories_sql);
        dbDelta($prompts_sql);
        dbDelta($settings_sql);
        
        // 升级现有数据库(添加image_url字段)
        $this->xb_aitsc_upgrade_database();
        
        // 插入默认设置
        $this->xb_aitsc_insert_default_settings();
    }
    
    /**
     * 升级数据库结构
     */
    private function xb_aitsc_upgrade_database() {
        global $wpdb;
        $prompts_table = $wpdb->prefix . 'xb_aitsc_prompts';
        
        // 检查image_url字段是否存在
        $image_url_exists = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s",
            DB_NAME,
            $prompts_table,
            'image_url'
        ));
        
        // 如果字段不存在,则添加
        if (empty($image_url_exists)) {
            $wpdb->query("ALTER TABLE $prompts_table ADD COLUMN image_url varchar(500) DEFAULT NULL AFTER category_id");
        }
        
        // 检查source字段是否存在
        $source_exists = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s",
            DB_NAME,
            $prompts_table,
            'source'
        ));
        
        // 如果字段不存在,则添加
        if (empty($source_exists)) {
            $wpdb->query("ALTER TABLE $prompts_table ADD COLUMN source varchar(200) DEFAULT NULL AFTER image_url");
        }

        $like_count_exists = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s",
            DB_NAME,
            $prompts_table,
            'like_count'
        ));
        if (empty($like_count_exists)) {
            $wpdb->query("ALTER TABLE $prompts_table ADD COLUMN like_count int(11) DEFAULT 0 AFTER hot_count");
        }

        $created_at_index_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(1) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND INDEX_NAME = %s",
            DB_NAME,
            $prompts_table,
            'created_at_idx'
        ));
        if (empty($created_at_index_exists)) {
            $wpdb->query("ALTER TABLE $prompts_table ADD INDEX created_at_idx (created_at)");
        }

        $hot_created_index_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(1) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND INDEX_NAME = %s",
            DB_NAME,
            $prompts_table,
            'hot_created_idx'
        ));
        if (empty($hot_created_index_exists)) {
            $wpdb->query("ALTER TABLE $prompts_table ADD INDEX hot_created_idx (hot_count, created_at)");
        }

        $like_created_index_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(1) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND INDEX_NAME = %s",
            DB_NAME,
            $prompts_table,
            'like_created_idx'
        ));
        if (empty($like_created_index_exists)) {
            $wpdb->query("ALTER TABLE $prompts_table ADD INDEX like_created_idx (like_count, created_at)");
        }
    }
    
    /**
     * 插入默认设置
     */
    private function xb_aitsc_insert_default_settings() {
        global $wpdb;
        $settings_table = $wpdb->prefix . 'xb_aitsc_settings';
        
        $default_notice = '<div class="xb-aitsc-notice-info">欢迎使用AI提示词大全！这里收集了各种实用的AI提示词，帮助您更好地使用AI工具。</div>';
        
        $wpdb->replace($settings_table, array(
            'option_name' => 'notice_content',
            'option_value' => $default_notice
        ));
        
        // 添加页面标题设置
        $wpdb->replace($settings_table, array(
            'option_name' => 'page_title',
            'option_value' => 'AI提示词大全'
        ));
    }
    
    /**
     * 创建前台页面
     */
    private function xb_aitsc_create_page() {
        $page_title = 'AI提示词大全';
        $page_slug = 'ai-prompts';

        $saved_page_id = intval(get_option('xb_aitsc_page_id', 0));
        if ($saved_page_id > 0) {
            $saved_page = get_post($saved_page_id);
            if ($saved_page && $saved_page->post_type === 'page') {
                if (has_shortcode($saved_page->post_content, 'xb_aitsc_display')) {
                    return;
                }
            }
        }

        global $wpdb;
        $candidate_pages = $wpdb->get_results(
            "SELECT ID, post_content FROM {$wpdb->posts}
             WHERE post_type = 'page'
               AND post_status IN ('publish','draft','private')
               AND post_content LIKE '%[xb_aitsc_display%'"
        );
        if (!empty($candidate_pages)) {
            foreach ($candidate_pages as $candidate) {
                if (has_shortcode($candidate->post_content, 'xb_aitsc_display')) {
                    update_option('xb_aitsc_page_id', intval($candidate->ID), false);
                    return;
                }
            }
        }

        $existing_page = get_page_by_path($page_slug);
        if ($existing_page) {
            update_option('xb_aitsc_page_id', intval($existing_page->ID), false);
            return;
        }

        $page_data = array(
            'post_title' => $page_title,
            'post_name' => $page_slug,
            'post_content' => '[xb_aitsc_display]',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1
        );
        $new_page_id = wp_insert_post($page_data);
        if (!is_wp_error($new_page_id) && intval($new_page_id) > 0) {
            update_option('xb_aitsc_page_id', intval($new_page_id), false);
        }
    }
    
    /**
     * 初始化
     */
    public function xb_aitsc_init() {
        // 注册短代码
        add_shortcode('xb_aitsc_display', array($this, 'xb_aitsc_display_shortcode'));
    }
    
    /**
     * 加载前端资源 - 修复了 null 对象错误
     */
    public function xb_aitsc_enqueue_scripts() {
        $should_load = false;
        
        // 检查是否是插件页面
        if (is_page('ai-prompts')) {
            $should_load = true;
        } elseif (is_singular()) {
            // 安全地检查当前文章是否包含短代码
            $current_post = get_post();
            if ($current_post && !empty($current_post->post_content)) {
                $should_load = has_shortcode($current_post->post_content, 'xb_aitsc_display');
            }
        }
        
        if ($should_load) {
            wp_enqueue_style('xb-aitsc-style', XB_AITSC_PLUGIN_URL . 'xb-aitsc-style.css', array(), XB_AITSC_VERSION);
            wp_enqueue_script('xb-aitsc-script', XB_AITSC_PLUGIN_URL . 'xb-aitsc-script.js', array('jquery'), XB_AITSC_VERSION, true);
            
            // 传递AJAX URL和nonce
            wp_localize_script('xb-aitsc-script', 'xb_aitsc_ajax', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('xb_aitsc_nonce'),
                'search_action' => 'xb_aitsc_search_prompts',
                'search_param' => 'xbsearch',
                'page_param' => 'xbpage',
                'like_action' => 'xb_aitsc_like_prompt'
            ));
        }
    }
    
    /**
     * 后台自动消失通知脚本
     */
    public function xb_aitsc_admin_auto_dismiss_script() {
        ?>
        <script>
        jQuery(document).ready(function($) {
            // 3秒后自动隐藏带有 xb-aitsc-auto-dismiss 类的通知
            setTimeout(function() {
                $('.xb-aitsc-auto-dismiss').fadeOut();
            }, 3000);
        });
        </script>
        <?php
    }
    
    /**
     * 添加管理菜单
     */
    public function xb_aitsc_admin_menu() {
        add_menu_page(
            'AI提示词大全',
            'AI提示词',
            'manage_options',
            'xb-aitsc-admin',
            array($this, 'xb_aitsc_admin_page'),
            'dashicons-format-chat',
            30
        );
        
        add_submenu_page(
            'xb-aitsc-admin',
            '分类管理',
            '分类管理',
            'manage_options',
            'xb-aitsc-categories',
            array($this, 'xb_aitsc_categories_page')
        );
        
        add_submenu_page(
            'xb-aitsc-admin',
            '提示词管理',
            '提示词管理',
            'manage_options',
            'xb-aitsc-prompts',
            array($this, 'xb_aitsc_prompts_page')
        );
        
        add_submenu_page(
            'xb-aitsc-admin',
            '设置',
            '设置',
            'manage_options',
            'xb-aitsc-settings',
            array($this, 'xb_aitsc_settings_page')
        );
    }
    
    /**
     * 主管理页面
     */
    public function xb_aitsc_admin_page() {
        global $wpdb;
        
        $categories_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}xb_aitsc_categories");
        $prompts_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}xb_aitsc_prompts");
        $total_hot = $wpdb->get_var("SELECT SUM(hot_count) FROM {$wpdb->prefix}xb_aitsc_prompts");
        
        ?>
        <div class="wrap">
            <h1>AI提示词大全 - 概览</h1>
            <div class="xb-aitsc-dashboard">
                <div class="xb-aitsc-stat-box">
                    <h3>分类总数</h3>
                    <p class="xb-aitsc-stat-number"><?php echo intval($categories_count); ?></p>
                </div>
                <div class="xb-aitsc-stat-box">
                    <h3>提示词总数</h3>
                    <p class="xb-aitsc-stat-number"><?php echo intval($prompts_count); ?></p>
                </div>
                <div class="xb-aitsc-stat-box">
                    <h3>总热度</h3>
                    <p class="xb-aitsc-stat-number"><?php echo intval($total_hot ?: 0); ?></p>
                </div>
            </div>
            
            <h2>热门提示词 TOP 10</h2>
            <?php
            $hot_prompts = $wpdb->get_results("
                SELECT p.title, p.hot_count, c.name as category_name 
                FROM {$wpdb->prefix}xb_aitsc_prompts p 
                LEFT JOIN {$wpdb->prefix}xb_aitsc_categories c ON p.category_id = c.id 
                ORDER BY p.hot_count DESC 
                LIMIT 10
            ");
            
            if ($hot_prompts) {
                echo '<table class="wp-list-table widefat fixed striped">';
                echo '<thead><tr><th>提示词标题</th><th>分类</th><th>热度</th></tr></thead>';
                echo '<tbody>';
                foreach ($hot_prompts as $prompt) {
                    echo '<tr>';
                    echo '<td>' . esc_html($prompt->title) . '</td>';
                    echo '<td>' . esc_html($prompt->category_name ?: '未分类') . '</td>';
                    echo '<td>' . intval($prompt->hot_count) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
            } else {
                echo '<p>暂无数据</p>';
            }
            ?>
        </div>
        <style>
        .xb-aitsc-dashboard {
            display: flex;
            gap: 20px;
            margin: 20px 0;
        }
        .xb-aitsc-stat-box {
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            padding: 20px;
            text-align: center;
            flex: 1;
        }
        .xb-aitsc-stat-number {
            font-size: 2em;
            font-weight: bold;
            color: #0073aa;
            margin: 10px 0;
        }
        </style>
        <?php
    }
    
    /**
     * 分类管理页面
     */
    public function xb_aitsc_categories_page() {
        global $wpdb;
        
        // 处理表单提交
        if (isset($_POST['action']) || (isset($_GET['action']) && $_GET['action'] === 'delete')) {
            $this->xb_aitsc_handle_category_actions();
        }
        
        $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $per_page = 20;
        $offset = ($page - 1) * $per_page;
        
        $categories = $wpdb->get_results($wpdb->prepare("
            SELECT * FROM {$wpdb->prefix}xb_aitsc_categories 
            ORDER BY sort_order ASC, id DESC 
            LIMIT %d OFFSET %d
        ", $per_page, $offset));
        
        $total_categories = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}xb_aitsc_categories");
        $total_pages = ceil($total_categories / $per_page);
        
        ?>
        <div class="wrap">
            <h1>分类管理</h1>
            
            <!-- 添加分类表单 -->
            <h2>添加新分类</h2>
            <form method="post" action="">
                <?php wp_nonce_field('xb_aitsc_category_action', 'xb_aitsc_nonce'); ?>
                <input type="hidden" name="action" value="add_category">
                <table class="form-table">
                    <tr>
                        <th><label for="category_name">分类名称</label></th>
                        <td><input type="text" id="category_name" name="category_name" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="category_description">分类描述</label></th>
                        <td><textarea id="category_description" name="category_description" rows="3" class="large-text"></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="sort_order">排序</label></th>
                        <td><input type="number" id="sort_order" name="sort_order" value="0" class="small-text"></td>
                    </tr>
                </table>
                <p class="submit">
                    <input type="submit" class="button-primary" value="添加分类">
                </p>
            </form>
            
            <!-- 分类列表 -->
            <h2>分类列表</h2>
            <?php if ($categories): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>分类名称</th>
                            <th>描述</th>
                            <th>排序</th>
                            <th>提示词数量</th>
                            <th>创建时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories as $category): ?>
                            <?php
                            $prompt_count = $wpdb->get_var($wpdb->prepare("
                                SELECT COUNT(*) FROM {$wpdb->prefix}xb_aitsc_prompts WHERE category_id = %d
                            ", $category->id));
                            ?>
                            <tr>
                                <td><?php echo intval($category->id); ?></td>
                                <td><?php echo esc_html($category->name); ?></td>
                                <td><?php echo esc_html($category->description); ?></td>
                                <td><?php echo intval($category->sort_order); ?></td>
                                <td><?php echo intval($prompt_count); ?></td>
                                <td><?php echo esc_html($category->created_at); ?></td>
                                <td>
                                    <a href="?page=xb-aitsc-categories&action=edit&id=<?php echo intval($category->id); ?>" class="button">编辑</a>
                                    <a href="?page=xb-aitsc-categories&action=delete&id=<?php echo intval($category->id); ?>&_wpnonce=<?php echo wp_create_nonce('delete_category_' . $category->id); ?>" 
                                       class="button" onclick="return confirm('确定要删除这个分类吗？')">删除</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <!-- 分页 -->
                <?php if ($total_pages > 1): ?>
                    <div class="tablenav">
                        <div class="tablenav-pages">
                            <?php
                            echo paginate_links(array(
                                'base' => add_query_arg('paged', '%#%'),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $page
                            ));
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <p>暂无分类</p>
            <?php endif; ?>
        </div>
        <?php
        
        // 编辑分类表单
        if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
            $category_id = intval($_GET['id']);
            $category = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}xb_aitsc_categories WHERE id = %d", $category_id));
            
            if ($category) {
                ?>
                <div class="wrap">
                    <h2>编辑分类</h2>
                    <form method="post" action="">
                        <?php wp_nonce_field('xb_aitsc_category_action', 'xb_aitsc_nonce'); ?>
                        <input type="hidden" name="action" value="edit_category">
                        <input type="hidden" name="category_id" value="<?php echo intval($category->id); ?>">
                        <table class="form-table">
                            <tr>
                                <th><label for="category_name">分类名称</label></th>
                                <td><input type="text" id="category_name" name="category_name" value="<?php echo esc_attr($category->name); ?>" required class="regular-text"></td>
                            </tr>
                            <tr>
                                <th><label for="category_description">分类描述</label></th>
                                <td><textarea id="category_description" name="category_description" rows="3" class="large-text"><?php echo esc_textarea($category->description); ?></textarea></td>
                            </tr>
                            <tr>
                                <th><label for="sort_order">排序</label></th>
                                <td><input type="number" id="sort_order" name="sort_order" value="<?php echo intval($category->sort_order); ?>" class="small-text"></td>
                            </tr>
                        </table>
                        <p class="submit">
                            <input type="submit" class="button-primary" value="更新分类">
                            <a href="?page=xb-aitsc-categories" class="button">取消</a>
                        </p>
                    </form>
                </div>
                <?php
            }
        }
    }
    
    /**
     * 提示词管理页面
     */
    public function xb_aitsc_prompts_page() {
        global $wpdb;
        
        // 处理表单提交
        if (isset($_POST['action']) || (isset($_GET['action']) && $_GET['action'] === 'delete')) {
            $this->xb_aitsc_handle_prompt_actions();
        }
        
        $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $per_page = 20;
        $offset = ($page - 1) * $per_page;
        
        $prompts = $wpdb->get_results($wpdb->prepare("
            SELECT p.*, c.name as category_name 
            FROM {$wpdb->prefix}xb_aitsc_prompts p 
            LEFT JOIN {$wpdb->prefix}xb_aitsc_categories c ON p.category_id = c.id 
            ORDER BY p.id DESC 
            LIMIT %d OFFSET %d
        ", $per_page, $offset));
        
        $total_prompts = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}xb_aitsc_prompts");
        $total_pages = ceil($total_prompts / $per_page);
        
        $categories = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}xb_aitsc_categories ORDER BY sort_order ASC, name ASC");
        
        ?>
        <div class="wrap">
            <h1>提示词管理</h1>
            
            <!-- 添加提示词表单 -->
            <h2>添加新提示词</h2>
            <form method="post" action="">
                <?php wp_nonce_field('xb_aitsc_prompt_action', 'xb_aitsc_nonce'); ?>
                <input type="hidden" name="action" value="add_prompt">
                <table class="form-table">
                    <tr>
                        <th><label for="prompt_title">提示词标题</label></th>
                        <td><input type="text" id="prompt_title" name="prompt_title" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="prompt_content">提示词内容</label></th>
                        <td><textarea id="prompt_content" name="prompt_content" rows="5" required class="large-text"></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="category_id">分类</label></th>
                        <td>
                            <select id="category_id" name="category_id" required>
                                <option value="">请选择分类</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo intval($category->id); ?>"><?php echo esc_html($category->name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="prompt_image_url">图片链接</label></th>
                        <td>
                            <input type="url" id="prompt_image_url" name="prompt_image_url" class="regular-text" placeholder="https://example.com/image.jpg">
                            <p class="description">输入提示词效果图的URL链接(可选)</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="prompt_source">提示词来源</label></th>
                        <td>
                            <input type="text" id="prompt_source" name="prompt_source" class="regular-text" placeholder="例如：某位用户的分享">
                            <p class="description">输入提示词的来源信息(可选)</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="hot_count">初始热度</label></th>
                        <td><input type="number" id="hot_count" name="hot_count" value="0" min="0" class="small-text"></td>
                    </tr>
                </table>
                <p class="submit">
                    <input type="submit" class="button-primary" value="添加提示词">
                </p>
            </form>
            
            <!-- 提示词列表 -->
            <h2>提示词列表</h2>
            <div style="background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; padding: 15px; margin-bottom: 15px;">
                <p style="margin: 0; font-size: 14px; color: #555;">
                    📊 <strong>统计信息：</strong>当前共有 <strong style="color: #0073aa;"><?php echo intval($total_prompts); ?></strong> 个提示词
                </p>
            </div>
            <?php if ($prompts): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>标题</th>
                            <th>图片预览</th>
                            <th>内容预览</th>
                            <th>分类</th>
                            <th>热度</th>
                            <th>点赞</th>
                            <th>创建时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($prompts as $prompt): ?>
                            <tr>
                                <td><?php echo intval($prompt->id); ?></td>
                                <td><?php echo esc_html($prompt->title); ?></td>
                                <td>
                                    <?php if (!empty($prompt->image_url)): ?>
                                        <img src="<?php echo esc_url($prompt->image_url); ?>" alt="预览图" style="max-width: 60px; max-height: 60px; border-radius: 8px; object-fit: cover;">
                                    <?php else: ?>
                                        <span style="color: #999;">无图片</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html(mb_substr($prompt->content, 0, 50)) . '...'; ?></td>
                                <td><?php echo esc_html($prompt->category_name ?: '未分类'); ?></td>
                                <td>
                                    <input type="number" value="<?php echo intval($prompt->hot_count); ?>" 
                                           onchange="updateHotCount(<?php echo intval($prompt->id); ?>, this.value)" 
                                           style="width: 60px;" min="0">
                                </td>
                                <td><?php echo intval($prompt->like_count ?? 0); ?></td>
                                <td><?php echo esc_html($prompt->created_at); ?></td>
                                <td>
                                    <a href="?page=xb-aitsc-prompts&action=edit&id=<?php echo intval($prompt->id); ?>" class="button">编辑</a>
                                    <a href="?page=xb-aitsc-prompts&action=delete&id=<?php echo intval($prompt->id); ?>&_wpnonce=<?php echo wp_create_nonce('delete_prompt_' . $prompt->id); ?>" 
                                       class="button" onclick="return confirm('确定要删除这个提示词吗？')">删除</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <!-- 分页 -->
                <?php if ($total_pages > 1): ?>
                    <div class="tablenav">
                        <div class="tablenav-pages">
                            <?php
                            echo paginate_links(array(
                                'base' => add_query_arg('paged', '%#%'),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $page
                            ));
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <p>暂无提示词</p>
            <?php endif; ?>
        </div>
        
        <script>
        function updateHotCount(promptId, newCount) {
            if (newCount < 0) return;
            
            var data = new FormData();
            data.append('action', 'update_hot_count');
            data.append('prompt_id', promptId);
            data.append('hot_count', newCount);
            data.append('_wpnonce', '<?php echo wp_create_nonce('xb_aitsc_update_hot'); ?>');
            
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                body: data
            }).then(response => response.json())
              .then(data => {
                  if (!data.success) {
                      alert('更新失败');
                  }
              }).catch(error => {
                  console.error('Error:', error);
                  alert('更新失败');
              });
        }
        </script>
        <?php
        
        // 编辑提示词表单
        if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
            $prompt_id = intval($_GET['id']);
            $prompt = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}xb_aitsc_prompts WHERE id = %d", $prompt_id));
            
            if ($prompt) {
                ?>
                <div class="wrap">
                    <h2>编辑提示词</h2>
                    <form method="post" action="">
                        <?php wp_nonce_field('xb_aitsc_prompt_action', 'xb_aitsc_nonce'); ?>
                        <input type="hidden" name="action" value="edit_prompt">
                        <input type="hidden" name="prompt_id" value="<?php echo intval($prompt->id); ?>">
                        <table class="form-table">
                            <tr>
                                <th><label for="prompt_title">提示词标题</label></th>
                                <td><input type="text" id="prompt_title" name="prompt_title" value="<?php echo esc_attr($prompt->title); ?>" required class="regular-text"></td>
                            </tr>
                            <tr>
                                <th><label for="prompt_content">提示词内容</label></th>
                                <td><textarea id="prompt_content" name="prompt_content" rows="5" required class="large-text"><?php echo esc_textarea($prompt->content); ?></textarea></td>
                            </tr>
                            <tr>
                                <th><label for="category_id">分类</label></th>
                                <td>
                                    <select id="category_id" name="category_id" required>
                                        <option value="">请选择分类</option>
                                        <?php foreach ($categories as $category): ?>
                                            <option value="<?php echo intval($category->id); ?>" <?php selected($prompt->category_id, $category->id); ?>>
                                                <?php echo esc_html($category->name); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label for="prompt_image_url">图片链接</label></th>
                                <td>
                                    <input type="url" id="prompt_image_url" name="prompt_image_url" value="<?php echo esc_attr($prompt->image_url); ?>" class="regular-text" placeholder="https://example.com/image.jpg">
                                    <p class="description">输入提示词效果图的URL链接(可选)</p>
                                    <?php if (!empty($prompt->image_url)): ?>
                                        <div style="margin-top: 10px;">
                                            <img src="<?php echo esc_url($prompt->image_url); ?>" alt="当前图片" style="max-width: 200px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th><label for="prompt_source">提示词来源</label></th>
                                <td>
                                    <input type="text" id="prompt_source" name="prompt_source" value="<?php echo esc_attr($prompt->source ?? ''); ?>" class="regular-text" placeholder="例如：某位用户的分享">
                                    <p class="description">输入提示词的来源信息(可选)</p>
                                </td>
                            </tr>
                            <tr>
                                <th><label for="hot_count">热度</label></th>
                                <td><input type="number" id="hot_count" name="hot_count" value="<?php echo intval($prompt->hot_count); ?>" min="0" class="small-text"></td>
                            </tr>
                        </table>
                        <p class="submit">
                            <input type="submit" class="button-primary" value="更新提示词">
                            <a href="?page=xb-aitsc-prompts" class="button">取消</a>
                        </p>
                    </form>
                </div>
                <?php
            }
        }
    }
    
    /**
     * 设置页面
     */
    public function xb_aitsc_settings_page() {
        global $wpdb;
        
        if (isset($_POST['action']) && $_POST['action'] == 'save_settings') {
            if (wp_verify_nonce($_POST['xb_aitsc_nonce'], 'xb_aitsc_settings_action')) {
                $notice_content = wp_kses_post($_POST['notice_content']);
                $page_title = sanitize_text_field($_POST['page_title']);
                
                $wpdb->replace($wpdb->prefix . 'xb_aitsc_settings', array(
                    'option_name' => 'notice_content',
                    'option_value' => $notice_content
                ));
                
                $wpdb->replace($wpdb->prefix . 'xb_aitsc_settings', array(
                    'option_name' => 'page_title',
                    'option_value' => $page_title
                ));
                
                echo '<div class="notice notice-success is-dismissible xb-aitsc-auto-dismiss"><p>设置已保存！</p></div>';
            }
        }
        
        $notice_content = $wpdb->get_var("SELECT option_value FROM {$wpdb->prefix}xb_aitsc_settings WHERE option_name = 'notice_content'");
        $page_title = $wpdb->get_var("SELECT option_value FROM {$wpdb->prefix}xb_aitsc_settings WHERE option_name = 'page_title'") ?: 'AI提示词大全';
        
        ?>
        <div class="wrap">
            <h1>插件设置</h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('xb_aitsc_settings_action', 'xb_aitsc_nonce'); ?>
                <input type="hidden" name="action" value="save_settings">
                
                <table class="form-table">
                    <tr>
                        <th><label for="page_title">页面标题</label></th>
                        <td>
                            <input type="text" id="page_title" name="page_title" value="<?php echo esc_attr($page_title); ?>" class="regular-text">
                            <p class="description">显示在前台页面顶部的标题</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="notice_content">公告内容</label></th>
                        <td>
                            <textarea id="notice_content" name="notice_content" rows="8" class="large-text"><?php echo esc_textarea($notice_content); ?></textarea>
                            <p class="description">支持HTML格式，将显示在前台页面底部</p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" class="button-primary" value="保存设置">
                </p>
            </form>
        </div>
        <?php
    }
    
    /**
     * 处理分类操作
     */
    private function xb_aitsc_handle_category_actions() {
        global $wpdb;
        
        // 处理删除操作
        if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
            $category_id = intval($_GET['id']);
            if (wp_verify_nonce($_GET['_wpnonce'], 'delete_category_' . $category_id)) {
                // 检查是否有提示词使用此分类
                $prompt_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}xb_aitsc_prompts WHERE category_id = %d", $category_id));
                
                if ($prompt_count > 0) {
                    echo '<div class="notice notice-error is-dismissible xb-aitsc-auto-dismiss"><p>无法删除：该分类下还有 ' . intval($prompt_count) . ' 个提示词！</p></div>';
                } else {
                    $result = $wpdb->delete($wpdb->prefix . 'xb_aitsc_categories', array('id' => $category_id));
                    if ($result !== false) {
                        echo '<div class="notice notice-success is-dismissible xb-aitsc-auto-dismiss"><p>分类删除成功！</p></div>';
                    } else {
                        echo '<div class="notice notice-error is-dismissible"><p>分类删除失败！</p></div>';
                    }
                }
            }
            return;
        }

        if (!isset($_POST['action']) || !wp_verify_nonce($_POST['xb_aitsc_nonce'], 'xb_aitsc_category_action')) {
            return;
        }

        switch ($_POST['action']) {
            case 'add_category':
                $name = sanitize_text_field($_POST['category_name']);
                $description = sanitize_textarea_field($_POST['category_description']);
                $sort_order = intval($_POST['sort_order']);
                
                $result = $wpdb->insert($wpdb->prefix . 'xb_aitsc_categories', array(
                    'name' => $name,
                    'description' => $description,
                    'sort_order' => $sort_order
                ));
                
                if ($result !== false) {
                    echo '<div class="notice notice-success is-dismissible xb-aitsc-auto-dismiss"><p>分类添加成功！</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>分类添加失败！</p></div>';
                }
                break;
                
            case 'edit_category':
                $category_id = intval($_POST['category_id']);
                $name = sanitize_text_field($_POST['category_name']);
                $description = sanitize_textarea_field($_POST['category_description']);
                $sort_order = intval($_POST['sort_order']);
                
                $result = $wpdb->update($wpdb->prefix . 'xb_aitsc_categories', array(
                    'name' => $name,
                    'description' => $description,
                    'sort_order' => $sort_order
                ), array('id' => $category_id));
                
                if ($result !== false) {
                    echo '<div class="notice notice-success is-dismissible xb-aitsc-auto-dismiss"><p>分类更新成功！</p></div>';
                    echo '<script>setTimeout(function(){window.location.href="?page=xb-aitsc-categories";}, 1000);</script>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>分类更新失败！</p></div>';
                }
                break;
        }
    }
    
    /**
     * 处理提示词操作
     */
    private function xb_aitsc_handle_prompt_actions() {
        global $wpdb;
        
        // 处理删除操作
        if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
            $prompt_id = intval($_GET['id']);
            if (wp_verify_nonce($_GET['_wpnonce'], 'delete_prompt_' . $prompt_id)) {
                $result = $wpdb->delete($wpdb->prefix . 'xb_aitsc_prompts', array('id' => $prompt_id));
                if ($result !== false) {
                    echo '<div class="notice notice-success is-dismissible xb-aitsc-auto-dismiss"><p>提示词删除成功！</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>提示词删除失败！</p></div>';
                }
            }
            return;
        }

        if (!isset($_POST['action']) || !wp_verify_nonce($_POST['xb_aitsc_nonce'], 'xb_aitsc_prompt_action')) {
            return;
        }

        switch ($_POST['action']) {
            case 'add_prompt':
                $title = sanitize_text_field($_POST['prompt_title']);
                $content = sanitize_textarea_field(wp_unslash($_POST['prompt_content']));
                $category_id = intval($_POST['category_id']);
                $image_url = !empty($_POST['prompt_image_url']) ? esc_url_raw($_POST['prompt_image_url']) : '';
                $source = !empty($_POST['prompt_source']) ? sanitize_text_field($_POST['prompt_source']) : '';
                $hot_count = intval($_POST['hot_count']);
                
                $result = $wpdb->insert($wpdb->prefix . 'xb_aitsc_prompts', array(
                    'title' => $title,
                    'content' => $content,
                    'category_id' => $category_id,
                    'image_url' => $image_url,
                    'source' => $source,
                    'hot_count' => $hot_count
                ));
                
                if ($result !== false) {
                    echo '<div class="notice notice-success is-dismissible xb-aitsc-auto-dismiss"><p>提示词添加成功！</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>提示词添加失败！</p></div>';
                }
                break;
                
            case 'edit_prompt':
                $prompt_id = intval($_POST['prompt_id']);
                $title = sanitize_text_field($_POST['prompt_title']);
                $content = sanitize_textarea_field(wp_unslash($_POST['prompt_content']));
                $category_id = intval($_POST['category_id']);
                $image_url = !empty($_POST['prompt_image_url']) ? esc_url_raw($_POST['prompt_image_url']) : '';
                $source = !empty($_POST['prompt_source']) ? sanitize_text_field($_POST['prompt_source']) : '';
                $hot_count = intval($_POST['hot_count']);
                
                $result = $wpdb->update($wpdb->prefix . 'xb_aitsc_prompts', array(
                    'title' => $title,
                    'content' => $content,
                    'category_id' => $category_id,
                    'image_url' => $image_url,
                    'source' => $source,
                    'hot_count' => $hot_count
                ), array('id' => $prompt_id));
                
                if ($result !== false) {
                    echo '<div class="notice notice-success is-dismissible xb-aitsc-auto-dismiss"><p>提示词更新成功！</p></div>';
                    echo '<script>setTimeout(function(){window.location.href="?page=xb-aitsc-prompts";}, 1000);</script>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>提示词更新失败！</p></div>';
                }
                break;
        }
    }
    
    /**
     * 处理复制提示词AJAX请求
     */
    public function xb_aitsc_handle_copy_prompt() {
        if (!wp_verify_nonce($_POST['nonce'], 'xb_aitsc_nonce')) {
            wp_send_json_error('安全验证失败');
        }
        
        $prompt_id = intval($_POST['prompt_id']);
        
        if ($prompt_id <= 0) {
            wp_send_json_error('无效的提示词ID');
        }
        
        global $wpdb;
        $result = $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}xb_aitsc_prompts SET hot_count = hot_count + 1 WHERE id = %d", $prompt_id));
        
        if ($result !== false) {
            wp_send_json_success();
        } else {
            wp_send_json_error('更新失败');
        }
    }

    public function xb_aitsc_update_hot_count_ajax() {
        if (!wp_verify_nonce($_POST['_wpnonce'], 'xb_aitsc_update_hot')) {
            wp_send_json_error('安全验证失败');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('权限不足');
        }
        
        $prompt_id = intval($_POST['prompt_id']);
        $hot_count = intval($_POST['hot_count']);
        
        if ($prompt_id <= 0 || $hot_count < 0) {
            wp_send_json_error('参数无效');
        }
        
        global $wpdb;
        $result = $wpdb->update(
            $wpdb->prefix . 'xb_aitsc_prompts',
            array('hot_count' => $hot_count),
            array('id' => $prompt_id),
            array('%d'),
            array('%d')
        );
        
        if ($result !== false) {
            wp_send_json_success();
        } else {
            wp_send_json_error('更新失败');
        }
    }

    private function xb_aitsc_get_prompts_data($current_category, $sort_type, $search_term, $per_page, $current_page) {
        global $wpdb;

        $page_param = 'xbpage';
        $per_page = intval($per_page);
        if ($per_page <= 0) {
            $per_page = 24;
        }
        $current_page = max(1, intval($current_page));
        $offset = ($current_page - 1) * $per_page;

        $where_parts = array();
        $where_params = array();
        if ($current_category > 0) {
            $where_parts[] = 'p.category_id = %d';
            $where_params[] = $current_category;
        }
        if (!empty($search_term)) {
            $like = '%' . $wpdb->esc_like($search_term) . '%';
            $where_parts[] = '(p.title LIKE %s OR p.content LIKE %s)';
            $where_params[] = $like;
            $where_params[] = $like;
        }
        $where_clause = '';
        if (!empty($where_parts)) {
            $where_clause = ' WHERE ' . implode(' AND ', $where_parts);
        }

        $order_clause = '';
        switch ($sort_type) {
            case 'random':
                $order_clause = ' ORDER BY RAND()';
                break;
            case 'like':
                $order_clause = ' ORDER BY p.like_count DESC, p.created_at DESC';
                break;
            case 'new':
                $order_clause = ' ORDER BY p.created_at DESC';
                break;
            default:
                $order_clause = ' ORDER BY p.hot_count DESC, p.created_at DESC';
                break;
        }

        $count_sql = "
            SELECT COUNT(1)
            FROM {$wpdb->prefix}xb_aitsc_prompts p
            {$where_clause}
        ";
        $total_prompts = $where_clause ? intval($wpdb->get_var($wpdb->prepare($count_sql, $where_params))) : intval($wpdb->get_var($count_sql));
        $total_pages = $per_page > 0 ? max(1, (int) ceil($total_prompts / $per_page)) : 1;
        if ($current_page > $total_pages) {
            $current_page = $total_pages;
            $offset = ($current_page - 1) * $per_page;
        }

        $sql = "
            SELECT p.*, c.name as category_name
            FROM {$wpdb->prefix}xb_aitsc_prompts p
            LEFT JOIN {$wpdb->prefix}xb_aitsc_categories c ON p.category_id = c.id
            {$where_clause}
            {$order_clause}
            LIMIT %d OFFSET %d
        ";
        $query_params = array_merge($where_params, array($per_page, $offset));
        $prompts = $where_clause ? $wpdb->get_results($wpdb->prepare($sql, $query_params)) : $wpdb->get_results($wpdb->prepare($sql, array($per_page, $offset)));

        return array(
            'prompts' => $prompts,
            'total_prompts' => $total_prompts,
            'total_pages' => $total_pages,
            'current_page' => $current_page,
            'page_param' => $page_param
        );
    }

    private function xb_aitsc_render_results_html($data, $base_url, $current_category, $sort_type, $search_term) {
        $prompts = $data['prompts'];
        $total_prompts = $data['total_prompts'];
        $total_pages = $data['total_pages'];
        $current_page = $data['current_page'];
        $page_param = $data['page_param'];

        $pagination_args = array(
            'category' => intval($current_category),
            'sort' => $sort_type,
            $page_param => '%#%'
        );
        if (!empty($search_term)) {
            $pagination_args['xbsearch'] = $search_term;
        }

        ob_start();
        ?>
            <div class="xb-aitsc-results">
                <div class="xb-aitsc-prompts-grid">
                    <?php if ($prompts): ?>
                        <?php foreach ($prompts as $prompt): ?>
                            <div class="xb-aitsc-prompt-card">
                                <?php if (!empty($prompt->image_url)): ?>
                                    <div class="xb-aitsc-prompt-image">
                                        <a href="<?php echo esc_url($prompt->image_url); ?>" data-fancybox="gallery" data-caption="<?php echo esc_attr($prompt->title); ?>">
                                            <img src="<?php echo esc_url($prompt->image_url); ?>" alt="<?php echo esc_attr($prompt->title); ?>" loading="lazy">
                                        </a>
                                    </div>
                                <?php endif; ?>
                                <div class="xb-aitsc-prompt-header">
                                    <div class="xb-aitsc-prompt-title"><?php echo esc_html($prompt->title); ?></div>
                                    <div class="xb-aitsc-prompt-meta">
                                        <span class="xb-aitsc-category-tag"><?php echo esc_html($prompt->category_name ?: '未分类'); ?></span>
                                        <span class="xb-aitsc-hot-count">🔥 <?php echo intval($prompt->hot_count); ?></span>
                                    </div>
                                </div>
                                <div class="xb-aitsc-prompt-content">
                                    <?php echo nl2br(esc_html($prompt->content)); ?>
                                </div>
                                <div class="xb-aitsc-prompt-actions">
                                    <button class="xb-aitsc-copy-btn" data-prompt-id="<?php echo intval($prompt->id); ?>" data-content="<?php echo esc_attr($prompt->content); ?>">
                                        📋 复制
                                    </button>
                                    <button class="xb-aitsc-like-btn" data-prompt-id="<?php echo intval($prompt->id); ?>">
                                        👍 <span class="xb-aitsc-like-count"><?php echo intval($prompt->like_count ?? 0); ?></span>
                                    </button>
                                    <?php if (!empty($prompt->source)): ?>
                                        <span class="xb-aitsc-prompt-source">
                                            来源：<?php echo esc_html($prompt->source); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="xb-aitsc-no-data">
                            <p><?php echo !empty($search_term) ? '没有找到匹配的提示词' : '暂无提示词数据'; ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if ($total_pages > 1): ?>
                    <div class="xb-aitsc-pagination">
                        <?php
                        echo paginate_links(array(
                            'base' => add_query_arg($pagination_args, $base_url),
                            'format' => '',
                            'prev_text' => '&laquo;',
                            'next_text' => '&raquo;',
                            'total' => $total_pages,
                            'current' => $current_page
                        ));
                        ?>
                    </div>
                <?php endif; ?>

                <div class="xb-aitsc-stats-info">
                    <p>📊 当前共收录 <strong><?php echo intval($total_prompts); ?></strong> 个提示词，本页显示 <strong><?php echo intval(count($prompts)); ?></strong> 个</p>
                </div>
            </div>
        <?php
        return ob_get_clean();
    }

    public function xb_aitsc_search_prompts_ajax() {
        if (!wp_verify_nonce($_POST['nonce'], 'xb_aitsc_nonce')) {
            wp_send_json_error('安全验证失败');
        }

        $current_category = isset($_POST['category']) ? intval($_POST['category']) : 0;
        $sort_type = isset($_POST['sort']) ? sanitize_text_field($_POST['sort']) : 'hot';
        $search_term = isset($_POST['search_term']) ? sanitize_text_field(wp_unslash($_POST['search_term'])) : '';
        $per_page = intval(apply_filters('xb_aitsc_prompts_per_page', 24));
        $current_page = isset($_POST['page']) ? max(1, intval($_POST['page'])) : 1;
        $base_url = isset($_POST['base_url']) ? esc_url_raw($_POST['base_url']) : '';
        if (empty($base_url)) {
            $base_url = home_url('/');
        }

        $data = $this->xb_aitsc_get_prompts_data($current_category, $sort_type, $search_term, $per_page, $current_page);
        $html = $this->xb_aitsc_render_results_html($data, $base_url, $current_category, $sort_type, $search_term);

        wp_send_json_success(array(
            'html' => $html,
            'total_prompts' => intval($data['total_prompts']),
            'total_pages' => intval($data['total_pages']),
            'current_page' => intval($data['current_page'])
        ));
    }

    public function xb_aitsc_like_prompt_ajax() {
        if (!wp_verify_nonce($_POST['nonce'], 'xb_aitsc_nonce')) {
            wp_send_json_error('安全验证失败');
        }

        $prompt_id = isset($_POST['prompt_id']) ? intval($_POST['prompt_id']) : 0;
        if ($prompt_id <= 0) {
            wp_send_json_error('无效的提示词ID');
        }

        $identity = '';
        if (is_user_logged_in()) {
            $identity = 'u:' . get_current_user_id();
        } else {
            $ip = '';
            if (!empty($_SERVER['REMOTE_ADDR'])) {
                $ip = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR']));
            }
            $ua = '';
            if (!empty($_SERVER['HTTP_USER_AGENT'])) {
                $ua = sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT']));
            }
            $identity = 'g:' . md5($ip . '|' . $ua);
        }

        $transient_key = 'xb_aitsc_like_' . $prompt_id . '_' . $identity;
        if (get_transient($transient_key)) {
            wp_send_json_error('已点赞');
        }

        global $wpdb;
        $table = $wpdb->prefix . 'xb_aitsc_prompts';
        $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(1) FROM {$table} WHERE id = %d", $prompt_id));
        if (empty($exists)) {
            wp_send_json_error('提示词不存在');
        }

        $like_column = $wpdb->get_var("SHOW COLUMNS FROM {$table} LIKE 'like_count'");
        if (empty($like_column)) {
            $alter = $wpdb->query("ALTER TABLE {$table} ADD COLUMN like_count int(11) DEFAULT 0 AFTER hot_count");
            if ($alter === false) {
                if (is_user_logged_in() && current_user_can('manage_options') && !empty($wpdb->last_error)) {
                    wp_send_json_error('更新失败：' . $wpdb->last_error);
                }
                wp_send_json_error('更新失败');
            }
        }

        $result = $wpdb->query($wpdb->prepare("UPDATE {$table} SET like_count = like_count + 1 WHERE id = %d", $prompt_id));
        if ($result === false) {
            if (is_user_logged_in() && current_user_can('manage_options') && !empty($wpdb->last_error)) {
                wp_send_json_error('更新失败：' . $wpdb->last_error);
            }
            wp_send_json_error('更新失败');
        }

        set_transient($transient_key, 1, 30 * DAY_IN_SECONDS);
        $like_count = intval($wpdb->get_var($wpdb->prepare("SELECT like_count FROM {$table} WHERE id = %d", $prompt_id)));
        wp_send_json_success(array('like_count' => $like_count));
    }
    
    /**
     * 前台显示短代码
     */
    public function xb_aitsc_display_shortcode($atts) {
        global $wpdb;
        
        // 获取设置
        $notice_content = $wpdb->get_var("SELECT option_value FROM {$wpdb->prefix}xb_aitsc_settings WHERE option_name = 'notice_content'");
        $page_title = $wpdb->get_var("SELECT option_value FROM {$wpdb->prefix}xb_aitsc_settings WHERE option_name = 'page_title'") ?: 'AI提示词大全';
        
        // 获取分类
        $categories = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}xb_aitsc_categories ORDER BY sort_order ASC, name ASC");
        
        // 获取当前选中的分类和排序方式
        $current_category = isset($_GET['category']) ? intval($_GET['category']) : 0;
        $sort_type = isset($_GET['sort']) ? sanitize_text_field($_GET['sort']) : 'hot';
        $search_term = isset($_GET['xbsearch']) ? sanitize_text_field(wp_unslash($_GET['xbsearch'])) : '';

        $per_page = intval(apply_filters('xb_aitsc_prompts_per_page', 24));
        if ($per_page <= 0) {
            $per_page = 24;
        }
        $page_param = 'xbpage';
        $current_page = isset($_GET[$page_param]) ? max(1, intval($_GET[$page_param])) : 1;
        $base_url = get_permalink();
        $data = $this->xb_aitsc_get_prompts_data($current_category, $sort_type, $search_term, $per_page, $current_page);
        $results_html = $this->xb_aitsc_render_results_html($data, $base_url, $current_category, $sort_type, $search_term);
        
        ob_start();
        ?>
        <div class="xb-aitsc-container" data-base-url="<?php echo esc_attr($base_url); ?>" data-category="<?php echo esc_attr(intval($current_category)); ?>" data-sort="<?php echo esc_attr($sort_type); ?>" data-page-param="<?php echo esc_attr($page_param); ?>" data-search="<?php echo esc_attr($search_term); ?>">
            <!-- 页面标题 -->
            <div class="xb-aitsc-page-title">
                <?php echo esc_html($page_title); ?>
            </div>
            
            <!-- 筛选和排序 -->
            <div class="xb-aitsc-filters">
                <div class="xb-aitsc-filter-group">
                    <span class="xb-aitsc-filter-label">分类筛选：</span>
                    <a href="<?php echo esc_url(add_query_arg(array_filter(array('category' => 0, 'sort' => $sort_type, $page_param => 1, 'xbsearch' => $search_term)), $base_url)); ?>" 
                       class="xb-aitsc-filter-btn <?php echo $current_category == 0 ? 'active' : ''; ?>">
                        全部
                    </a>
                    <?php foreach ($categories as $category): ?>
                        <a href="<?php echo esc_url(add_query_arg(array_filter(array('category' => intval($category->id), 'sort' => $sort_type, $page_param => 1, 'xbsearch' => $search_term)), $base_url)); ?>" 
                           class="xb-aitsc-filter-btn <?php echo $current_category == $category->id ? 'active' : ''; ?>">
                            <?php echo esc_html($category->name); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
                
                <div class="xb-aitsc-filter-group">
                    <span class="xb-aitsc-filter-label">排序方式：</span>
                    <a href="<?php echo esc_url(add_query_arg(array_filter(array('category' => intval($current_category), 'sort' => 'hot', $page_param => 1, 'xbsearch' => $search_term)), $base_url)); ?>" 
                       class="xb-aitsc-sort-btn <?php echo $sort_type == 'hot' ? 'active' : ''; ?>">
                        按热度
                    </a>
                    <a href="<?php echo esc_url(add_query_arg(array_filter(array('category' => intval($current_category), 'sort' => 'like', $page_param => 1, 'xbsearch' => $search_term)), $base_url)); ?>" 
                       class="xb-aitsc-sort-btn <?php echo $sort_type == 'like' ? 'active' : ''; ?>">
                        按点赞
                    </a>
                    <a href="<?php echo esc_url(add_query_arg(array_filter(array('category' => intval($current_category), 'sort' => 'new', $page_param => 1, 'xbsearch' => $search_term)), $base_url)); ?>" 
                       class="xb-aitsc-sort-btn <?php echo $sort_type == 'new' ? 'active' : ''; ?>">
                        按时间
                    </a>
                    <a href="<?php echo esc_url(add_query_arg(array_filter(array('category' => intval($current_category), 'sort' => 'random', $page_param => 1, 'xbsearch' => $search_term)), $base_url)); ?>" 
                       class="xb-aitsc-sort-btn <?php echo $sort_type == 'random' ? 'active' : ''; ?>">
                        随机排序
                    </a>
                </div>
            </div>

            <?php echo $results_html; ?>
            
            <!-- 公告区域 -->
            <?php if ($notice_content): ?>
                <div class="xb-aitsc-notice">
                    <?php echo wp_kses_post($notice_content); ?>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- 自定义提示框 -->
        <div id="xb-aitsc-toast" class="xb-aitsc-toast">
            <span id="xb-aitsc-toast-message"></span>
        </div>
        <?php
        
        return ob_get_clean();
    }
}

// 初始化插件
new XB_AITSC_Plugin();
?>
