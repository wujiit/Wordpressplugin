jQuery(document).ready(function ($) {
    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('XB AISHIPU: jQuery 未加载！');
        $('#xb_aishipu_result').html('<div class="xb_aishipu_message xb_aishipu_message_error">脚本加载失败，请刷新页面！</div>');
        return;
    }

    // 确保 xb_aishipu_ajax 配置
    if (typeof xb_aishipu_ajax === 'undefined') {
        console.error('XB AISHIPU: xb_aishipu_ajax 未定义！');
        $('#xb_aishipu_result').html('<div class="xb_aishipu_message xb_aishipu_message_error">脚本配置失败，请检查插件设置！</div>');
        return;
    }

    let currentFormData = null;
    let isRecommending = false;
    let typingTimer = null;
    let isFirstTimeRecommend = true;

    // 字符计数器
    $('#xb_aishipu_custom_content').on('input', function() {
        const length = $(this).val().length;
        $('.xb_aishipu_char_count').text(length + '/500');
        
        if (length > 500) {
            $(this).val($(this).val().substring(0, 500));
            $('.xb_aishipu_char_count').text('500/500');
        }
    });

    // 用餐人数选择处理
    $('#xb_aishipu_serving_size').on('change', function() {
        if ($(this).val() === 'custom') {
            $('#xb_aishipu_custom_serving').show().focus();
        } else {
            $('#xb_aishipu_custom_serving').hide();
        }
    });

    // 表单提交处理
    $('#xb_aishipu_form').on('submit', function (e) {
        e.preventDefault();
        
        if (isRecommending) {
            return;
        }

        const formData = getFormData();
        if (!validateFormData(formData)) {
            return;
        }

        currentFormData = formData;
        isFirstTimeRecommend = true;
        
        showResultPanel();
        recommendRecipe(formData);
    });

    // 显示结果面板
    function showResultPanel() {
        $('.xb_aishipu_result_section').show();
        
        setTimeout(function() {
            $('.xb_aishipu_result_section')[0].scrollIntoView({ 
                behavior: 'smooth',
                block: 'start'
            });
        }, 300);
    }

    // 获取表单数据
    function getFormData() {
        const servingSize = $('#xb_aishipu_serving_size').val();
        const customServing = $('#xb_aishipu_custom_serving').val();

        return {
            ingredients: $('#xb_aishipu_ingredients').val().trim(),
            cuisine_type: $('input[name="cuisine_type"]:checked').val(),
            taste_preference: $('input[name="taste_preference"]:checked').val(),
            serving_size: servingSize,
            custom_serving: customServing,
            custom_content: $('#xb_aishipu_custom_content').val().trim(),
            model: $('#xb_aishipu_model').val() || '',
            enable_search: $('#xb_aishipu_enable_search').is(':checked') ? 1 : 0
        };
    }

    // 验证表单数据
    function validateFormData(data) {
        if (!data.ingredients) {
            xb_aishipu_show_alert('请输入您现有的食材');
            return false;
        }

        if (!data.cuisine_type) {
            xb_aishipu_show_alert('请选择菜系');
            return false;
        }

        if (!data.taste_preference) {
            xb_aishipu_show_alert('请选择口味偏好');
            return false;
        }

        if (!data.serving_size) {
            xb_aishipu_show_alert('请选择用餐人数');
            return false;
        }

        if (data.serving_size === 'custom' && (!data.custom_serving || data.custom_serving < 1)) {
            xb_aishipu_show_alert('请输入有效的用餐人数');
            return false;
        }

        return true;
    }

    // 推荐食谱
    function recommendRecipe(data) {
        isRecommending = true;
        
        $('#xb_aishipu_submit_button')
            .prop('disabled', true)
            .html('<span class="xb_aishipu_button_icon">⏳</span>推荐中...');

        showLoadingMessage();
        $('.xb_aishipu_result_actions').hide();

        if (xb_aishipu_ajax.is_logged_in == 1) {
            handleLoggedUserRecommend(data);
        }
    }

    // 处理登录用户推荐
    function handleLoggedUserRecommend(data) {
        $.ajax({
            url: xb_aishipu_ajax.rest_url,
            type: 'POST',
            data: JSON.stringify(data),
            contentType: 'application/json',
            headers: { 'X-WP-Nonce': xb_aishipu_ajax.nonce },
            success: function (response) {
                if (response.success && response.content) {
                    if (isFirstTimeRecommend) {
                        displayStreamingResult(response.content);
                    } else {
                        displayDirectResult(response.content);
                    }
                    updateUsageInfo(response.remaining, response.limit);
                    
                    if (response.remaining <= 0) {
                        hideFormAndShowMessage();
                    }
                    
                    if (typeof xb_aishipu_load_history === 'function') {
                        xb_aishipu_load_history();
                    }
                } else {
                    xb_aishipu_show_alert(response.message || '暂时无法推荐请联系客服');
                }
                resetRecommendButton();
            },
            error: function (xhr) {
                const message = xhr.responseJSON && xhr.responseJSON.message ? 
                    xhr.responseJSON.message : '暂时无法推荐请联系客服';
                xb_aishipu_show_alert(message);
                resetRecommendButton();
            }
        });
    }

    // 显示真正的流式结果（像ChatGPT一样从上往下实时显示）
    function displayStreamingResult(content) {
        const $resultContainer = $('#xb_aishipu_result');
        $resultContainer.html('<div class="xb_aishipu_result_content"></div>');
        
        const $content = $('.xb_aishipu_result_content');
        
        // 从顶部开始，确保用户看到内容从上往下出现
        $content[0].scrollTop = 0;
        
        // 将内容按字符分割，模拟真正的流式输出
        let displayedContent = '';
        let currentIndex = 0;
        
        function streamContent() {
            if (currentIndex < content.length) {
                // 每次添加1-3个字符，模拟真实的AI流式输出
                const chunkSize = Math.floor(Math.random() * 3) + 1;
                const chunk = content.substring(currentIndex, currentIndex + chunkSize);
                displayedContent += chunk;
                currentIndex += chunkSize;
                
                // 实时渲染内容（先显示纯文本，避免Markdown渲染导致的跳跃）
                let renderedContent = displayedContent.replace(/\n/g, '<br>');
                
                // 更新显示内容
                $content.html(renderedContent);
                
                // 自动滚动跟随最新内容（像真正的AI对话一样）
                const contentElement = $content[0];
                contentElement.scrollTop = contentElement.scrollHeight;
                
                // 继续流式输出
                const delay = Math.random() * 50 + 20; // 20-70ms随机延迟
                typingTimer = setTimeout(streamContent, delay);
            } else {
                // 流式输出完成后，最后渲染一次Markdown格式
                if (typeof marked !== 'undefined') {
                    try {
                        const finalRendered = marked.parse(content);
                        $content.html(finalRendered);
                    } catch (e) {
                        console.warn('Markdown解析失败，保持纯文本显示:', e);
                    }
                }
                
                // 显示操作按钮
                $('.xb_aishipu_result_actions').show();
            }
        }
        
        // 开始流式输出
        streamContent();
    }

    // 直接显示结果
    function displayDirectResult(content) {
        let renderedContent = '';
        if (typeof marked !== 'undefined') {
            try {
                renderedContent = marked.parse(content);
            } catch (e) {
                console.warn('Markdown解析失败，使用纯文本显示:', e);
                renderedContent = content.replace(/\n/g, '<br>');
            }
        } else {
            renderedContent = content.replace(/\n/g, '<br>');
        }
        
        const $resultContainer = $('#xb_aishipu_result');
        $resultContainer.html('<div class="xb_aishipu_result_content">' + renderedContent + '</div>');
        $('.xb_aishipu_result_actions').show();
    }

    // 显示加载信息
    function showLoadingMessage() {
        $('#xb_aishipu_result').html(
            '<div class="xb_aishipu_loading">' +
            '<div class="xb_aishipu_spinner"></div>' +
            '<div class="xb_aishipu_ts_subtitle">🍳 AI正在推荐中</div>' +
            '<p>请稍候，AI正在为您推荐美味食谱...</p>' +
            '</div>'
        );
    }

    // 重置推荐按钮
    function resetRecommendButton() {
        isRecommending = false;
        $('#xb_aishipu_submit_button')
            .prop('disabled', false)
            .html('<span class="xb_aishipu_button_icon">🍳</span>推荐食谱');
    }

    // 更新使用次数信息
    function updateUsageInfo(remaining, limit) {
        let text;
        
        if (remaining > 0) {
            text = `今日剩余推荐次数：${remaining}/${limit}`;
        } else {
            text = '今日使用次数已经用完，请明天再来。';
        }
        
        $('#xb_aishipu_usage_text').text(text);
    }

    // 隐藏表单并显示相应消息
    function hideFormAndShowMessage() {
        $('#xb_aishipu_form').fadeOut(300, function() {
            const message = 
                '<div class="xb_aishipu_message xb_aishipu_message_info">' +
                '<div class="xb_aishipu_message_icon">📅</div>' +
                '<div class="xb_aishipu_message_content">' +
                '<div class="xb_aishipu_ts_subtitle">今日使用次数已经用完，请明天再来。</div>' +
                '</div>' +
                '</div>';
            $('.xb_aishipu_config_section').append(message);
        });
    }

    // 复制结果按钮
    $('#xb_aishipu_copy_button').on('click', function(e) {
        e.preventDefault();
        
        const $button = $(this);
        const originalText = $button.html();
        const content = $('.xb_aishipu_result_content').text();
        
        if (content) {
            if (navigator.clipboard) {
                navigator.clipboard.writeText(content).then(function() {
                    showCopySuccess($button, originalText);
                }).catch(function() {
                    fallbackCopyText(content, $button, originalText);
                });
            } else {
                fallbackCopyText(content, $button, originalText);
            }
        }
    });

    // 导出图片按钮
    $('#xb_aishipu_export_image_button').on('click', function(e) {
        e.preventDefault();
        const $content = $('.xb_aishipu_result_content');
        if ($content.length && typeof html2canvas !== 'undefined') {
            // 临时移除最大高度限制和滚动条，确保导出完整内容
            const originalMaxHeight = $content.css('max-height');
            const originalOverflow = $content.css('overflow-y');
            
            $content.css({
                'max-height': 'none',
                'overflow-y': 'visible'
            });
            
            // 等待DOM更新后再截图
            setTimeout(function() {
                const options = {
                    useCORS: true,
                    allowTaint: true,
                    scale: 1.5, // 提高清晰度
                    scrollX: 0,
                    scrollY: 0,
                    width: $content[0].scrollWidth,
                    height: $content[0].scrollHeight,
                    backgroundColor: '#ffffff',
                    logging: false,
                    removeContainer: true
                };
                
                html2canvas($content[0], options).then(function(canvas) {
                    // 恢复原始样式
                    $content.css({
                        'max-height': originalMaxHeight,
                        'overflow-y': originalOverflow
                    });
                    
                    const link = document.createElement('a');
                    link.download = 'ai-recipe-' + new Date().getTime() + '.png';
                    link.href = canvas.toDataURL('image/png', 1.0);
                    link.click();
                }).catch(function(error) {
                    console.error('导出图片失败:', error);
                    // 恢复原始样式
                    $content.css({
                        'max-height': originalMaxHeight,
                        'overflow-y': originalOverflow
                    });
                    xb_aishipu_show_alert('导出图片失败，请重试');
                });
            }, 100);
        } else {
            xb_aishipu_show_alert('导出图片功能需要加载html2canvas库');
        }
    });

    // 重新推荐按钮
    $('#xb_aishipu_regenerate_button').on('click', function(e) {
        e.preventDefault();
        
        if (currentFormData && !isRecommending) {
            isFirstTimeRecommend = true;
            recommendRecipe(currentFormData);
        }
    });

    // 清空内容按钮
    $('#xb_aishipu_clear_button').on('click', function(e) {
        e.preventDefault();
        
        if (typingTimer) {
            clearTimeout(typingTimer);
            typingTimer = null;
        }
        
        $('#xb_aishipu_result').empty();
        $('.xb_aishipu_result_actions').hide();
        $('.xb_aishipu_result_section').hide();
        currentFormData = null;
        
        const hasLimitMessage = $('.xb_aishipu_config_section .xb_aishipu_message').length > 0;
        
        if (!hasLimitMessage) {
            resetForm();
        }
    });

    // 历史记录点击处理
    $(document).on('click', '.xb_aishipu_history_item', function(e) {
        if ($(e.target).hasClass('xb_aishipu_delete_record_btn') || $(e.target).closest('.xb_aishipu_delete_record_btn').length) {
            return;
        }
        
        const recordId = $(this).data('id');
        if (recordId) {
            isFirstTimeRecommend = false;
            
            showResultPanel();
            loadHistoryRecord(recordId);
        }
    });

    // 加载历史记录详情
    function loadHistoryRecord(recordId) {
        $.ajax({
            url: xb_aishipu_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_aishipu_get_history_detail',
                record_id: recordId
            },
            success: function(response) {
                if (response.success && response.data.ai_response) {
                    displayDirectResult(response.data.ai_response);
                    $('.xb_aishipu_result_actions').show();
                    
                    $('.xb_aishipu_result_section')[0].scrollIntoView({ behavior: 'smooth' });
                    
                    $('.xb_aishipu_history_item').removeClass('xb_aishipu_selected');
                    $(`.xb_aishipu_history_item[data-id="${recordId}"]`).addClass('xb_aishipu_selected');
                } else {
                    xb_aishipu_show_alert(response.data.message || '加载历史记录失败');
                }
            },
            error: function() {
                xb_aishipu_show_alert('加载历史记录失败');
            }
        });
    }

    // 备用复制方法
    function fallbackCopyText(text, $button, originalText) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
            showCopySuccess($button, originalText);
        } catch (err) {
            $button.html('<span class="xb_aishipu_button_icon">❌</span>复制失败');
            setTimeout(function() {
                $button.html(originalText);
            }, 2000);
        }
        
        document.body.removeChild(textArea);
    }

    // 显示复制成功
    function showCopySuccess($button, originalText) {
        $button.html('<span class="xb_aishipu_button_icon">✅</span>已复制');
        setTimeout(function() {
            $button.html(originalText);
        }, 2000);
    }

    // 重置表单
    function resetForm() {
        $('#xb_aishipu_form')[0].reset();
        $('.xb_aishipu_char_count').text('0/500');
        $('input[name="cuisine_type"]:first').prop('checked', true);
        $('input[name="taste_preference"]:first').prop('checked', true);
        $('#xb_aishipu_serving_size').val($('#xb_aishipu_serving_size option:first').val());
        $('#xb_aishipu_custom_serving').hide();
        currentFormData = null;
        isFirstTimeRecommend = true;
    }

    // 快速登录处理
    $(document).on('click', '.xb_aishipu_login_btn', function (e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });

    // 防止表单重复提交
    $(document).on('keydown', function(e) {
        if (e.key === 'Enter' && $(e.target).closest('#xb_aishipu_form').length && isRecommending) {
            e.preventDefault();
            return false;
        }
    });

    // 页面离开前的提醒
    $(window).on('beforeunload', function() {
        if (isRecommending) {
            return '正在推荐中，确定要离开吗？';
        }
    });

    // 自定义确认对话框
    window.xb_aishipu_show_confirm = function(title, message, onConfirm) {
        $('#xb_aishipu_confirm_title').text(title);
        $('#xb_aishipu_confirm_message').text(message);
        $('#xb_aishipu_confirm_modal').show();
        
        $('#xb_aishipu_confirm_ok').off('click').on('click', function() {
            $('#xb_aishipu_confirm_modal').hide();
            if (typeof onConfirm === 'function') {
                onConfirm();
            }
        });
        
        $('#xb_aishipu_confirm_cancel').off('click').on('click', function() {
            $('#xb_aishipu_confirm_modal').hide();
        });
        
        $('.xb_aishipu_modal_overlay').off('click').on('click', function() {
            $('#xb_aishipu_confirm_modal').hide();
        });
    };
    
    // 自定义提示对话框
    function xb_aishipu_show_alert(message, title) {
        $('#xb_aishipu_alert_title').text(title || '提示');
        $('#xb_aishipu_alert_message').text(message);
        $('#xb_aishipu_alert_modal').show();
        
        $('#xb_aishipu_alert_ok').off('click').on('click', function() {
            $('#xb_aishipu_alert_modal').hide();
        });
        
        $('.xb_aishipu_modal_overlay').off('click').on('click', function() {
            $('#xb_aishipu_alert_modal').hide();
        });
    }

    // 初始化历史记录
    if (xb_aishipu_ajax.is_logged_in == 1) {
        if (typeof xb_aishipu_load_history === 'function') {
            xb_aishipu_load_history();
        }
    }
});