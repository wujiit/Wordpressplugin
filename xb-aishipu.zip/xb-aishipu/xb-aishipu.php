<?php
/*
Plugin Name: AI食谱推荐
Description: 基于AI的智能食谱推荐工具，根据用户手头的食材、饮食偏好或健康需求，生成定制化食谱。
Version: 1.0.0
Author: Summer
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xb_aishipu_activate');
function xb_aishipu_activate() {
    xb_aishipu_create_database();
    xb_aishipu_create_front_page();
    xb_aishipu_upgrade_database();
}

// 数据库升级函数
function xb_aishipu_upgrade_database() {
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aishipu_records';
    
    // 检查是否需要添加新字段
    $columns = $wpdb->get_results("SHOW COLUMNS FROM $records_table");
    $column_names = array_column($columns, 'Field');
    
    if (!in_array('cuisine_type', $column_names)) {
        $wpdb->query("ALTER TABLE $records_table ADD COLUMN cuisine_type varchar(50) DEFAULT NULL AFTER custom_content");
    }
    if (!in_array('taste_preference', $column_names)) {
        $wpdb->query("ALTER TABLE $records_table ADD COLUMN taste_preference varchar(50) DEFAULT NULL AFTER cuisine_type");
    }
    if (!in_array('serving_size', $column_names)) {
        $wpdb->query("ALTER TABLE $records_table ADD COLUMN serving_size varchar(20) DEFAULT NULL AFTER taste_preference");
    }
    if (!in_array('ingredients', $column_names)) {
        $wpdb->query("ALTER TABLE $records_table ADD COLUMN ingredients text DEFAULT NULL AFTER serving_size");
    }
}

// 创建数据库表
function xb_aishipu_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 用户使用次数表
    $usage_table = $wpdb->prefix . 'xb_aishipu_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        device_id varchar(255) NOT NULL,
        usage_date date NOT NULL,
        usage_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_device_date (user_id, device_id, usage_date)
    ) $charset_collate;";

    // 用户记录表
    $records_table = $wpdb->prefix . 'xb_aishipu_records';
    $records_sql = "CREATE TABLE $records_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        device_id varchar(255) NOT NULL,
        ingredients text DEFAULT NULL,
        cuisine_type varchar(50) DEFAULT NULL,
        taste_preference varchar(50) DEFAULT NULL,
        serving_size varchar(20) DEFAULT NULL,
        custom_content text DEFAULT NULL,
        model_name varchar(100) DEFAULT NULL,
        enable_search tinyint(1) DEFAULT 0,
        ai_response longtext DEFAULT NULL,
        status varchar(20) NOT NULL,
        error_message text DEFAULT NULL,
        user_ip varchar(45) DEFAULT NULL,
        user_agent text DEFAULT NULL,
        create_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($usage_sql);
    dbDelta($records_sql);
}

// 创建前台页面
function xb_aishipu_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_aishipu_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => 'AI食谱推荐',
            'post_content' => '[xb_aishipu_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 生成设备指纹
function xb_aishipu_generate_device_id() {
    $user_agent = !empty($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : 'Unknown';
    $ip_address = !empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : 'Unknown';
    $accept_language = !empty($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? sanitize_text_field($_SERVER['HTTP_ACCEPT_LANGUAGE']) : 'Unknown';
    $raw_string = $user_agent . $ip_address . $accept_language;
    return hash('sha256', $raw_string);
}

// 获取设备ID（优先从Cookie获取，失效则生成新的）
function xb_aishipu_get_device_id() {
    $cookie_name = 'xb_aishipu_device_id';
    $device_id = isset($_COOKIE[$cookie_name]) ? sanitize_text_field($_COOKIE[$cookie_name]) : null;

    if (!$device_id) {
        $device_id = xb_aishipu_generate_device_id();
        // 设置365天有效期的Cookie
        setcookie($cookie_name, $device_id, time() + (365 * 24 * 60 * 60), '/');
    }

    return $device_id;
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_aishipu_enqueue_scripts');
function xb_aishipu_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_aishipu_form')) {
        wp_enqueue_style('xb_aishipu_styles', plugins_url('xb-aishipu.css', __FILE__), array(), '1.0.0');
        wp_enqueue_script('xb_aishipu_scripts', plugins_url('xb-aishipu.js', __FILE__), array('jquery'), '1.0.0', true);
        wp_enqueue_script('html2canvas', 'https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js', array(), '1.4.1', true);
        
        // 添加Markdown渲染库
        wp_enqueue_script('marked', 'https://cdn.jsdelivr.net/npm/marked@9.1.6/marked.min.js', array(), '9.1.6', true);

        wp_localize_script('xb_aishipu_scripts', 'xb_aishipu_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => rest_url('xb_aishipu/v1/recommend'),
            'rest_delete_url' => rest_url('xb_aishipu/v1/delete-record'),
            'nonce'    => wp_create_nonce('wp_rest'),
            'login_url' => wp_login_url(get_permalink()),
            'is_logged_in' => is_user_logged_in() ? 1 : 0,
        ));
    }
}

// 短代码
add_shortcode('xb_aishipu_form', 'xb_aishipu_form_shortcode');
function xb_aishipu_form_shortcode() {
    $ad_content = get_option('xb_aishipu_ad_content', '');
    $default_limit = absint(get_option('xb_aishipu_default_limit', 10));
    $show_stats = get_option('xb_aishipu_show_stats', 1);
    $enable_model_selection = get_option('xb_aishipu_enable_model_selection', 0);
    $enable_search = get_option('xb_aishipu_enable_search', 0);
    $cuisine_options = get_option('xb_aishipu_cuisine_options', '川菜,湘菜,粤菜,鲁菜,苏菜,浙菜,闽菜,徽菜');
    $taste_options = get_option('xb_aishipu_taste_options', '偏辣,偏甜,常规,清淡');
    $serving_options = get_option('xb_aishipu_serving_options', '1,2,3,4,5,6');
    $models = array_filter(array_map('trim', explode(',', get_option('xb_aishipu_models', 'qwen-plus'))));

    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $today = current_time('Y-m-d');
    $device_id = xb_aishipu_get_device_id();

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aishipu_usage';

    // 已登录用户按 user_id 和日期查询，忽略设备信息
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
                $user_id, $today
            )
        );
    } else {
        // 游客按 user_id、device_id 和日期查询
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND device_id = %s AND usage_date = %s",
                $user_id, $device_id, $today
            )
        );
    }

    $usage_count = $row ? absint($row->usage_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;
    $remaining = max(0, $user_limit - $usage_count);
    $stats_text = "今日剩余推荐次数：{$remaining}/{$user_limit}";

    // 判断是否显示推荐区域
    $show_form = true;
    $disable_reason = '';

    if (!is_user_logged_in()) {
        $show_form = false;
        $disable_reason = 'guest_disabled';
    } elseif (is_user_logged_in() && $usage_count >= $user_limit) {
        $show_form = false;
        $disable_reason = 'user_limit_exceeded';
    }

    ob_start();
    ?>
    <div class="xb_aishipu_container">
        <div class="xb_aishipu_header">
            <div class="xb_aishipu_title">🍳 AI食谱推荐</div>
            <p class="xb_aishipu_subtitle">智能推荐，美味生活</p>
        </div>

        <div class="xb_aishipu_main_content">
            <!-- 配置区域 -->
            <div class="xb_aishipu_config_section">
                <div class="xb_aishipu_section_title">🥗 食谱配置</div>
                
                <?php if (!$show_form) { ?>
                    <div class="xb_aishipu_message xb_aishipu_message_info">
                        <?php if ($disable_reason === 'guest_disabled') { ?>
                            <div class="xb_aishipu_message_icon">🔐</div>
                            <div class="xb_aishipu_message_content">
                                <div class="xb_aishipu_ts_subtitle">请登录后使用食谱推荐功能</div>
                                <p>为了更好地为您提供个性化食谱推荐，请先登录。</p>
                                <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xb_aishipu_login_btn">立即登录</a>
                            </div>
                        <?php } elseif ($disable_reason === 'user_limit_exceeded') { ?>
                            <div class="xb_aishipu_message_icon">📅</div>
                            <div class="xb_aishipu_message_content">
                                <div class="xb_aishipu_ts_subtitle">今日使用次数已经用完，请明天再来。</div>
                            </div>
                        <?php } ?>
                    </div>
                <?php } else { ?>
                    <form id="xb_aishipu_form" method="post">
                        <!-- 已有食材 -->
                        <div class="xb_aishipu_ingredients_section">
                            <label for="xb_aishipu_ingredients">已有食材：</label>
                            <textarea id="xb_aishipu_ingredients" name="ingredients" rows="3" placeholder="请输入您现有的食材，如：鸡蛋、番茄、土豆..." class="xb_aishipu_ingredients_input" required></textarea>
                        </div>

                        <!-- 菜系选择 -->
                        <div class="xb_aishipu_cuisine_section">
                            <label>菜系选择：</label>
                            <div class="xb_aishipu_cuisine_select">
                                <?php 
                                $cuisines = array_filter(array_map('trim', explode(',', $cuisine_options)));
                                foreach ($cuisines as $index => $cuisine) { ?>
                                    <div class="xb_aishipu_cuisine_option">
                                        <input type="radio" name="cuisine_type" value="<?php echo esc_attr($cuisine); ?>" <?php echo $index === 0 ? 'checked' : ''; ?> id="cuisine_<?php echo $index; ?>">
                                        <label for="cuisine_<?php echo $index; ?>"><?php echo esc_html($cuisine); ?></label>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>

                        <!-- 口味选择 -->
                        <div class="xb_aishipu_taste_section">
                            <label>口味偏好：</label>
                            <div class="xb_aishipu_taste_select">
                                <?php 
                                $tastes = array_filter(array_map('trim', explode(',', $taste_options)));
                                foreach ($tastes as $index => $taste) { ?>
                                    <div class="xb_aishipu_taste_option">
                                        <input type="radio" name="taste_preference" value="<?php echo esc_attr($taste); ?>" <?php echo $index === 0 ? 'checked' : ''; ?> id="taste_<?php echo $index; ?>">
                                        <label for="taste_<?php echo $index; ?>"><?php echo esc_html($taste); ?></label>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>

                        <!-- 用餐人数 -->
                        <div class="xb_aishipu_serving_section">
                            <label for="xb_aishipu_serving_size">用餐人数：</label>
                            <div class="xb_aishipu_serving_wrapper">
                                <select id="xb_aishipu_serving_size" name="serving_size" class="xb_aishipu_serving_select">
                                    <?php 
                                    $servings = array_filter(array_map('trim', explode(',', $serving_options)));
                                    foreach ($servings as $serving) { ?>
                                        <option value="<?php echo esc_attr($serving); ?>"><?php echo esc_html($serving); ?>人</option>
                                    <?php } ?>
                                    <option value="custom">自定义</option>
                                </select>
                                <input type="number" id="xb_aishipu_custom_serving" name="custom_serving" min="1" max="50" placeholder="人数" class="xb_aishipu_custom_serving" style="display:none;">
                            </div>
                        </div>

                        <!-- 补充需求 -->
                        <div class="xb_aishipu_custom_section">
                            <label for="xb_aishipu_custom_content">补充需求（可选）：</label>
                            <textarea id="xb_aishipu_custom_content" name="custom_content" maxlength="500" rows="3" placeholder="请描述特殊需求，如：低盐、素食、快手菜..." class="xb_aishipu_custom_content"></textarea>
                            <div class="xb_aishipu_char_count">0/500</div>
                        </div>

                        <!-- AI模型和联网搜索 -->
                        <?php if ($enable_model_selection && count($models) > 1 || $enable_search) { ?>
                        <div class="xb_aishipu_advanced_options">
                            <div class="xb_aishipu_advanced_title">高级选项</div>
                            <div class="xb_aishipu_advanced_row">
                                <?php if ($enable_model_selection && count($models) > 1) { ?>
                                <div class="xb_aishipu_model_wrapper">
                                    <label for="xb_aishipu_model">AI模型：</label>
                                    <select id="xb_aishipu_model" name="model" class="xb_aishipu_model_select">
                                        <?php foreach ($models as $model) { ?>
                                            <option value="<?php echo esc_attr($model); ?>"><?php echo esc_html($model); ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <?php } ?>

                                <?php if ($enable_search) { ?>
                                <div class="xb_aishipu_search_option">
                                    <input type="checkbox" id="xb_aishipu_enable_search" name="enable_search" value="1" class="xb_aishipu_search_checkbox">
                                    <label for="xb_aishipu_enable_search">启用联网搜索</label>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <?php } ?>

                        <button type="submit" class="xb_aishipu_submit_button" id="xb_aishipu_submit_button">
                            <span class="xb_aishipu_button_icon">🍳</span>
                            推荐食谱
                        </button>

                        <?php if (is_user_logged_in()) { ?>
                            <input type="hidden" name="xb_aishipu_nonce" value="<?php echo wp_create_nonce('xb_aishipu_nonce'); ?>">
                        <?php } ?>
                    </form>
                <?php } ?>
            </div>
            
            <!-- 结果区域 -->
            <div class="xb_aishipu_result_section" style="display:none;">
                <div class="xb_aishipu_section_title">📋 推荐结果</div>
                
                <div class="xb_aishipu_result_actions" style="display:none;">
                    <button id="xb_aishipu_copy_button" class="xb_aishipu_action_button">
                        <span class="xb_aishipu_button_icon">📋</span>
                        复制结果
                    </button>
                    <button id="xb_aishipu_export_image_button" class="xb_aishipu_action_button">
                        <span class="xb_aishipu_button_icon">🖼️</span>
                        导出图片
                    </button>
                    <button id="xb_aishipu_regenerate_button" class="xb_aishipu_action_button">
                        <span class="xb_aishipu_button_icon">🔄</span>
                        重新推荐
                    </button>
                    <button id="xb_aishipu_clear_button" class="xb_aishipu_action_button">
                        <span class="xb_aishipu_button_icon">🗑️</span>
                        清空内容
                    </button>
                </div>

                <div id="xb_aishipu_result"></div>
                
                <?php if ($show_stats && $show_form) { ?>
                    <div class="xb_aishipu_usage_info">
                        <span class="xb_aishipu_usage_icon">📊</span>
                        <span id="xb_aishipu_usage_text"><?php echo esc_html($stats_text); ?></span>
                    </div>
                <?php } ?>
            </div>
        </div>

        <!-- 历史记录 -->
        <?php if (is_user_logged_in()) { ?>
            <div class="xb_aishipu_history_section">
                <div class="xb_aishipu_section_title">📚 我的推荐记录</div>
                <div id="xb_aishipu_history_list" class="xb_aishipu_history_list"></div>
            </div>
        <?php } ?>
        
        <!-- 公告内容 -->
        <?php if (!empty($ad_content)) { ?>
            <div class="xb_aishipu_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
        <?php } ?>
    </div>
    
    <!-- 自定义确认对话框 -->
    <div id="xb_aishipu_confirm_modal" class="xb_aishipu_modal" style="display: none;">
        <div class="xb_aishipu_modal_overlay"></div>
        <div class="xb_aishipu_modal_content">
            <div class="xb_aishipu_modal_header">
                <h3 id="xb_aishipu_confirm_title">确认操作</h3>
            </div>
            <div class="xb_aishipu_modal_body">
                <p id="xb_aishipu_confirm_message">您确定要执行此操作吗？</p>
            </div>
            <div class="xb_aishipu_modal_footer">
                <button id="xb_aishipu_confirm_cancel" class="xb_aishipu_modal_btn xb_aishipu_modal_btn_cancel">取消</button>
                <button id="xb_aishipu_confirm_ok" class="xb_aishipu_modal_btn xb_aishipu_modal_btn_confirm">确定</button>
            </div>
        </div>
    </div>
    
    <!-- 自定义提示对话框 -->
    <div id="xb_aishipu_alert_modal" class="xb_aishipu_modal" style="display: none;">
        <div class="xb_aishipu_modal_overlay"></div>
        <div class="xb_aishipu_modal_content">
            <div class="xb_aishipu_modal_header">
                <h3 id="xb_aishipu_alert_title">提示</h3>
            </div>
            <div class="xb_aishipu_modal_body">
                <p id="xb_aishipu_alert_message">操作完成</p>
            </div>
            <div class="xb_aishipu_modal_footer">
                <button id="xb_aishipu_alert_ok" class="xb_aishipu_modal_btn xb_aishipu_modal_btn_confirm">确定</button>
            </div>
        </div>
    </div>

    <script type="text/javascript">
    // 用餐人数选择处理
    jQuery(document).ready(function($) {
        $('#xb_aishipu_serving_size').on('change', function() {
            if ($(this).val() === 'custom') {
                $('#xb_aishipu_custom_serving').show().focus();
            } else {
                $('#xb_aishipu_custom_serving').hide();
            }
        });

        // 加载历史记录
        <?php if (is_user_logged_in()) { ?>
        xb_aishipu_load_history();
        <?php } ?>
        
        // 历史记录点击事件
        $(document).on('click', '.xb_aishipu_history_item', function(e) {
            // 如果点击的是删除按钮，不执行查看记录
            if ($(e.target).hasClass('xb_aishipu_delete_record_btn') || $(e.target).closest('.xb_aishipu_delete_record_btn').length) {
                return;
            }
            
            var recordId = $(this).data('id');
            
            // 通过AJAX获取完整的历史记录内容
            jQuery.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'xb_aishipu_get_history_detail',
                    record_id: recordId
                },
                success: function(response) {
                    if (response.success && response.data.ai_response) {
                        // 使用Markdown渲染器渲染内容
                        var renderedContent = '';
                        if (typeof marked !== 'undefined') {
                            renderedContent = marked.parse(response.data.ai_response);
                        } else {
                            renderedContent = response.data.ai_response.replace(/ /g, '<br>');
                        }
                        
                        // 显示历史记录内容到结果区域
                        $('#xb_aishipu_result').html('<div class="xb_aishipu_result_content">' + renderedContent + '</div>');
                        $('.xb_aishipu_result_section').show();
                        $('.xb_aishipu_result_actions').show();
                        
                        // 滚动到结果区域
                        $('.xb_aishipu_result_section')[0].scrollIntoView({ behavior: 'smooth' });
                        
                        // 高亮选中的记录
                        $('.xb_aishipu_history_item').removeClass('xb_aishipu_selected');
                        $('[data-id="' + recordId + '"]').addClass('xb_aishipu_selected');
                    } else {
                        xb_aishipu_show_alert('加载记录失败');
                    }
                },
                error: function() {
                    xb_aishipu_show_alert('加载记录失败');
                }
            });
        });
        
        // 删除记录按钮点击事件
        $(document).on('click', '.xb_aishipu_delete_record_btn', function(e) {
            e.stopPropagation();
            var recordId = $(this).data('id');
            
            xb_aishipu_show_confirm('确认删除', '您确定要删除这条推荐记录吗？删除后无法恢复。', function() {
                // 发送删除请求
                jQuery.ajax({
                    url: '<?php echo rest_url('xb_aishipu/v1/delete-record'); ?>',
                    type: 'DELETE',
                    headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                    data: JSON.stringify({ record_id: recordId }),
                    contentType: 'application/json',
                    success: function(response) {
                        if (response.success) {
                            // 前台用户删除自己记录时不弹提示框，直接重新加载历史记录
                            xb_aishipu_load_history();
                            // 如果当前显示的是被删除的记录，清空结果区域
                            if ($('.xb_aishipu_history_item.xb_aishipu_selected').data('id') == recordId) {
                                $('#xb_aishipu_result').empty();
                                $('.xb_aishipu_result_actions').hide();
                                $('.xb_aishipu_result_section').hide();
                            }
                        } else {
                            xb_aishipu_show_alert(response.message || '删除失败');
                        }
                    },
                    error: function(xhr) {
                        var message = xhr.responseJSON && xhr.responseJSON.message ? 
                            xhr.responseJSON.message : '删除失败';
                        xb_aishipu_show_alert(message);
                    }
                });
            });
        });
    });
    
    // 加载历史记录函数
    function xb_aishipu_load_history() {
        jQuery.ajax({
            url: '<?php echo rest_url('xb_aishipu/v1/history'); ?>',
            type: 'GET',
            headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
            success: function(response) {
                if (response && response.length > 0) {
                    var html = '';
                    response.forEach(function(record) {
                        html += '<div class="xb_aishipu_history_item" data-id="' + record.id + '">';
                        html += '<button class="xb_aishipu_delete_record_btn" data-id="' + record.id + '" title="删除记录">×</button>';
                        html += '<div class="xb_aishipu_history_date">' + record.create_time + '</div>';
                        html += '<div class="xb_aishipu_history_preview">' + (record.ingredients || '食谱推荐记录').substring(0, 50) + '...</div>';
                        html += '<div class="xb_aishipu_history_cuisine">' + (record.cuisine_type || '未知菜系') + '</div>';
                        html += '</div>';
                    });
                    jQuery('#xb_aishipu_history_list').html(html);
                } else {
                    jQuery('#xb_aishipu_history_list').html('<div class="xb_aishipu_no_history">暂无推荐记录</div>');
                }
            },
            error: function() {
                jQuery('#xb_aishipu_history_list').html('<div class="xb_aishipu_no_history">加载记录失败</div>');
            }
        });
    }
    
    // 自定义确认对话框
    function xb_aishipu_show_confirm(title, message, onConfirm) {
        $('#xb_aishipu_confirm_title').text(title);
        $('#xb_aishipu_confirm_message').text(message);
        $('#xb_aishipu_confirm_modal').show();
        
        // 绑定确认按钮事件
        $('#xb_aishipu_confirm_ok').off('click').on('click', function() {
            $('#xb_aishipu_confirm_modal').hide();
            if (typeof onConfirm === 'function') {
                onConfirm();
            }
        });
        
        // 绑定取消按钮事件
        $('#xb_aishipu_confirm_cancel').off('click').on('click', function() {
            $('#xb_aishipu_confirm_modal').hide();
        });
        
        // 点击遮罩层关闭
        $('.xb_aishipu_modal_overlay').off('click').on('click', function() {
            $('#xb_aishipu_confirm_modal').hide();
        });
    }
    
    // 自定义提示对话框
    function xb_aishipu_show_alert(message, title) {
        $('#xb_aishipu_alert_title').text(title || '提示');
        $('#xb_aishipu_alert_message').text(message);
        $('#xb_aishipu_alert_modal').show();
        
        // 绑定确定按钮事件
        $('#xb_aishipu_alert_ok').off('click').on('click', function() {
            $('#xb_aishipu_alert_modal').hide();
        });
        
        // 点击遮罩层关闭
        $('.xb_aishipu_modal_overlay').off('click').on('click', function() {
            $('#xb_aishipu_alert_modal').hide();
        });
    }
    </script>
    <?php
    return ob_get_clean();
}

// 注册 REST API 端点
add_action('rest_api_init', 'xb_aishipu_register_rest_routes');
function xb_aishipu_register_rest_routes() {
    register_rest_route('xb_aishipu/v1', '/recommend', array(
        'methods' => 'POST',
        'callback' => 'xb_aishipu_handle_logged_recommend',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ));
    
    register_rest_route('xb_aishipu/v1', '/history', array(
        'methods' => 'GET',
        'callback' => 'xb_aishipu_get_user_history',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ));
    
    register_rest_route('xb_aishipu/v1', '/delete-record', array(
        'methods' => 'DELETE',
        'callback' => 'xb_aishipu_delete_user_record',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ));
}

// 处理登录用户推荐
function xb_aishipu_handle_logged_recommend(WP_REST_Request $request) {
    $data = json_decode($request->get_body(), true);
    
    // 验证必填字段
    if (empty($data['ingredients'])) {
        return new WP_REST_Response(array('message' => '请输入您现有的食材'), 400);
    }

    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $device_id = xb_aishipu_get_device_id();

    // 检查使用次数
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aishipu_usage';
    $default_limit = absint(get_option('xb_aishipu_default_limit', 10));
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
            $user_id, $today
        )
    );
    $usage_count = $row ? absint($row->usage_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;

    if ($usage_count >= $user_limit) {
        return new WP_REST_Response(array('message' => '今日使用次数已经用完，请明天再来。'), 403);
    }

    // 检查违规词
    $forbidden_words = get_option('xb_aishipu_forbidden_words', '');
    if (!empty($forbidden_words)) {
        $words = array_filter(array_map('trim', explode(',', $forbidden_words)));
        $check_content = $data['ingredients'] . ' ' . ($data['custom_content'] ?? '');
        foreach ($words as $word) {
            if (stripos($check_content, $word) !== false) {
                return new WP_REST_Response(array('message' => '输入内容包含违规词，请重新输入'), 400);
            }
        }
    }

    $result = xb_aishipu_call_api($data, $user_id, $device_id, $today);
    return new WP_REST_Response($result, $result['success'] ? 200 : 400);
}

// 获取用户历史记录
function xb_aishipu_get_user_history(WP_REST_Request $request) {
    $user_id = get_current_user_id();
    
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aishipu_records';
    
    $records = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT id, ingredients, cuisine_type, taste_preference, serving_size, custom_content, create_time, status 
             FROM $records_table 
             WHERE user_id = %d AND status = 'success' 
             ORDER BY create_time DESC 
             LIMIT 20",
            $user_id
        )
    );
    
    return $records;
}

// 删除用户记录
function xb_aishipu_delete_user_record(WP_REST_Request $request) {
    $data = json_decode($request->get_body(), true);
    $record_id = isset($data['record_id']) ? absint($data['record_id']) : 0;
    
    if (!$record_id) {
        return new WP_REST_Response(array('success' => false, 'message' => '记录ID无效'), 400);
    }
    
    $user_id = get_current_user_id();
    
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aishipu_records';
    
    // 验证记录是否属于当前用户
    $record = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id FROM $records_table WHERE id = %d AND user_id = %d",
            $record_id, $user_id
        )
    );
    
    if (!$record) {
        return new WP_REST_Response(array('success' => false, 'message' => '记录不存在或无权限删除'), 403);
    }
    
    // 删除记录
    $deleted = $wpdb->delete(
        $records_table,
        array('id' => $record_id, 'user_id' => $user_id),
        array('%d', '%d')
    );
    
    if ($deleted) {
        return new WP_REST_Response(array('success' => true, 'message' => '删除成功'));
    } else {
        return new WP_REST_Response(array('success' => false, 'message' => '删除失败'), 500);
    }
}

// 获取历史记录详情
add_action('wp_ajax_xb_aishipu_get_history_detail', 'xb_aishipu_get_history_detail');
function xb_aishipu_get_history_detail() {
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => '请先登录'));
    }

    $record_id = isset($_POST['record_id']) ? absint($_POST['record_id']) : 0;
    if (!$record_id) {
        wp_send_json_error(array('message' => '记录ID无效'));
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aishipu_records';
    
    $record = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM $records_table WHERE id = %d AND user_id = %d",
            $record_id, get_current_user_id()
        )
    );

    if (!$record) {
        wp_send_json_error(array('message' => '记录不存在'));
    }

    wp_send_json_success(array(
        'ai_response' => $record->ai_response,
        'ingredients' => $record->ingredients,
        'cuisine_type' => $record->cuisine_type,
        'taste_preference' => $record->taste_preference,
        'serving_size' => $record->serving_size,
        'custom_content' => $record->custom_content,
        'create_time' => $record->create_time
    ));
}

// API 调用
function xb_aishipu_call_api($data, $user_id, $device_id, $today) {
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aishipu_records';

    $api_url = get_option('xb_aishipu_api_url', 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions');
    $api_key = get_option('xb_aishipu_api_key', '');
    $models = array_filter(array_map('trim', explode(',', get_option('xb_aishipu_models', 'qwen-plus'))));
    $model = !empty($data['model']) ? $data['model'] : $models[0];

    // 调试日志
    error_log('XB_AISHIPU_DEBUG: API调用开始');
    error_log('XB_AISHIPU_DEBUG: API URL: ' . $api_url);
    error_log('XB_AISHIPU_DEBUG: Model: ' . $model);
    error_log('XB_AISHIPU_DEBUG: API Key存在: ' . (!empty($api_key) ? '是' : '否'));

    if (empty($api_key)) {
        error_log('XB_AISHIPU_DEBUG: API Key为空');
        return array('success' => false, 'message' => '暂时无法推荐请联系客服');
    }

    // 处理用餐人数
    $serving_size = $data['serving_size'];
    if ($serving_size === 'custom' && !empty($data['custom_serving'])) {
        $serving_size = $data['custom_serving'];
    }

    // 构建提示词 - 专业厨师推荐
    $prompt = "你是一位经验丰富的专业厨师 👨‍🍳，擅长各种菜系的烹饪。现在需要根据用户的食材和需求推荐食谱，请严格按照以下要求：

用户信息：
- 现有食材：{$data['ingredients']}
- 菜系偏好：{$data['cuisine_type']}
- 口味偏好：{$data['taste_preference']}
- 用餐人数：{$serving_size}人
";

    if (!empty($data['custom_content'])) {
        $prompt .= "- 特殊需求：{$data['custom_content']}
";
    }

    $prompt .= "
请根据以上信息推荐1-2道适合的菜品，包括：

## 🍽️ 推荐菜品

### 菜品一：[菜名]
**难度等级：** ⭐⭐⭐ (1-5星)
**制作时间：** 约XX分钟
**适合人数：** {$serving_size}人

**所需食材：**
- 主料：[列出主要食材及用量]
- 辅料：[列出辅助食材及用量]
- 调料：[列出调料及用量]

**制作步骤：**
1. [详细步骤1]
2. [详细步骤2]
3. [详细步骤3]
...

**烹饪小贴士：** 💡
- [提供专业的烹饪技巧和注意事项]

---

### 菜品二：[菜名]（如果合适的话）
[按照相同格式提供第二道菜的信息]

## 🌟 营养搭配建议
[简要说明营养价值和搭配建议]

## 👨‍🍳 厨师小贴士
[提供额外的烹饪建议或食材替换方案]

请用温暖、专业且易懂的语言回复 😊，适当使用表情符号让内容更加生动有趣 ✨，确保推荐的菜品符合用户的菜系和口味偏好，制作步骤详细易懂，让用户能够轻松上手制作美味佳肴 🍳！";

    // 构建请求数据
    $request_data = array(
        'model' => $model,
        'messages' => array(
            array(
                'role' => 'system',
                'content' => '你是一位专业的厨师，擅长根据用户的食材和需求推荐合适的食谱。你的回复要详细、实用，适当使用表情符号让交流更加生动友好。'
            ),
            array(
                'role' => 'user',
                'content' => $prompt
            )
        ),
        'stream' => false,
        'temperature' => 0.7
    );

    // 如果启用联网搜索
    if (!empty($data['enable_search'])) {
        $request_data['enable_search'] = true;
    }

    // 记录到数据库
    $insert_data = array(
        'user_id' => $user_id,
        'device_id' => $device_id,
        'ingredients' => $data['ingredients'],
        'cuisine_type' => $data['cuisine_type'],
        'taste_preference' => $data['taste_preference'],
        'serving_size' => $serving_size,
        'custom_content' => $data['custom_content'] ?? '',
        'model_name' => $model,
        'enable_search' => !empty($data['enable_search']) ? 1 : 0,
        'status' => 'pending',
        'user_ip' => !empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '',
        'user_agent' => !empty($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '',
        'create_time' => current_time('mysql'),
    );

    $args = array(
        'method' => 'POST',
        'timeout' => 60,
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json',
        ),
        'body' => json_encode($request_data),
    );

    // 调试日志
    error_log('XB_AISHIPU_DEBUG: 请求数据: ' . json_encode($request_data, JSON_UNESCAPED_UNICODE));

    $response = wp_remote_request($api_url, $args);
    
    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        error_log('XB_AISHIPU_DEBUG: WP错误: ' . $error_message);
        $insert_data['status'] = 'failed';
        $insert_data['error_message'] = $error_message;
        $wpdb->insert($records_table, $insert_data);
        return array('success' => false, 'message' => '暂时无法推荐请联系客服');
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);

    error_log('XB_AISHIPU_DEBUG: HTTP状态码: ' . $status_code);
    error_log('XB_AISHIPU_DEBUG: 响应内容: ' . substr($body, 0, 500) . '...');

    if ($status_code >= 400) {
        error_log('XB_AISHIPU_DEBUG: HTTP错误 ' . $status_code . ': ' . $body);
        $insert_data['status'] = 'failed';
        $insert_data['error_message'] = 'HTTP ' . $status_code . ': ' . $body;
        $wpdb->insert($records_table, $insert_data);
        return array('success' => false, 'message' => '暂时无法推荐请联系客服');
    }

    // 解析响应
    $response_data = json_decode($body, true);
    $content = '';
    
    if (isset($response_data['choices'][0]['message']['content'])) {
        $content = $response_data['choices'][0]['message']['content'];
    }

    if (empty($content)) {
        $insert_data['status'] = 'failed';
        $insert_data['error_message'] = '接口返回空内容';
        $wpdb->insert($records_table, $insert_data);
        return array('success' => false, 'message' => '暂时无法推荐请联系客服');
    }

    // 成功，更新使用次数
    $usage_table = $wpdb->prefix . 'xb_aishipu_usage';
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
                $user_id, $today
            )
        );
        $usage_count = $row ? absint($row->usage_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : absint(get_option('xb_aishipu_default_limit', 10));

        $existing_row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id FROM $usage_table WHERE user_id = %d AND device_id = %s AND usage_date = %s LIMIT 1",
                $user_id, $device_id, $today
            )
        );
        if ($existing_row) {
            $wpdb->update(
                $usage_table,
                array('usage_count' => $usage_count + 1),
                array('id' => $existing_row->id),
                array('%d'),
                array('%d')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'device_id' => $device_id,
                    'usage_date' => $today,
                    'usage_count' => 1,
                    'custom_limit' => null,
                )
            );
        }
    }

    $insert_data['status'] = 'success';
    $insert_data['ai_response'] = $content;
    $wpdb->insert($records_table, $insert_data);

    $remaining = $user_limit - ($usage_count + 1);
    
    return array(
        'success' => true,
        'content' => $content,
        'remaining' => $remaining,
        'limit' => $user_limit
    );
}

// 包含管理功能
if (is_admin()) {
    require_once(plugin_dir_path(__FILE__) . 'xb-aishipu-admin.php');
}
?>