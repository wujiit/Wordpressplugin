<?php
// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 添加管理菜单
add_action('admin_menu', 'xb_aishipu_admin_menu');
function xb_aishipu_admin_menu() {
    add_menu_page(
        'AI食谱推荐设置',
        'AI食谱推荐',
        'manage_options',
        'xb_aishipu_settings',
        'xb_aishipu_settings_page',
        'dashicons-carrot',
        80
    );
    add_submenu_page(
        'xb_aishipu_settings',
        '用户记录',
        '用户记录',
        'manage_options',
        'xb_aishipu_records',
        'xb_aishipu_records_page'
    );
}

// 插件设置页面
function xb_aishipu_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['xb_aishipu_save_settings'])) {
        check_admin_referer('xb_aishipu_settings_nonce');
        
        update_option('xb_aishipu_api_url', sanitize_text_field($_POST['xb_aishipu_api_url']));
        update_option('xb_aishipu_api_key', sanitize_text_field($_POST['xb_aishipu_api_key']));
        update_option('xb_aishipu_models', sanitize_text_field($_POST['xb_aishipu_models']));
        update_option('xb_aishipu_default_limit', absint($_POST['xb_aishipu_default_limit']));
        update_option('xb_aishipu_show_stats', isset($_POST['xb_aishipu_show_stats']) ? 1 : 0);
        update_option('xb_aishipu_enable_model_selection', isset($_POST['xb_aishipu_enable_model_selection']) ? 1 : 0);
        update_option('xb_aishipu_enable_search', isset($_POST['xb_aishipu_enable_search']) ? 1 : 0);
        update_option('xb_aishipu_forbidden_words', sanitize_textarea_field($_POST['xb_aishipu_forbidden_words']));
        update_option('xb_aishipu_cuisine_options', sanitize_text_field($_POST['xb_aishipu_cuisine_options']));
        update_option('xb_aishipu_taste_options', sanitize_text_field($_POST['xb_aishipu_taste_options']));
        update_option('xb_aishipu_serving_options', sanitize_text_field($_POST['xb_aishipu_serving_options']));
        
        $allowed_html = array(
            'a' => array('href' => array(), 'title' => array(), 'target' => array()),
            'img' => array('src' => array(), 'alt' => array(), 'width' => array(), 'height' => array()),
            'p' => array(),
            'div' => array('class' => array(), 'style' => array()),
            'span' => array('class' => array(), 'style' => array()),
            'strong' => array(),
            'em' => array(),
            'br' => array()
        );
        update_option('xb_aishipu_ad_content', wp_kses($_POST['xb_aishipu_ad_content'], $allowed_html));
        
        echo '<div class="updated xb_aishipu_auto_hide_message"><p>设置已保存！</p></div>';
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aishipu_records';
    $stats = array(
        'total_records' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table"),
        'success_records' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE status = 'success'"),
        'failed_records' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE status = 'failed'"),
        'today_records' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE DATE(create_time) = %s", current_time('Y-m-d')))
    );

    ?>
    <div class="wrap">
        <h1>🍳 AI食谱推荐设置</h1>
        <form method="post">
            <?php wp_nonce_field('xb_aishipu_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_aishipu_api_url">API 接口地址</label></th>
                    <td><input type="text" name="xb_aishipu_api_url" id="xb_aishipu_api_url" value="<?php echo esc_attr(get_option('xb_aishipu_api_url', 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_aishipu_api_key">API 密钥</label></th>
                    <td><input type="text" name="xb_aishipu_api_key" id="xb_aishipu_api_key" value="<?php echo esc_attr(get_option('xb_aishipu_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_aishipu_models">AI模型</label></th>
                    <td>
                        <input type="text" name="xb_aishipu_models" id="xb_aishipu_models" value="<?php echo esc_attr(get_option('xb_aishipu_models', 'qwen-plus')); ?>" class="regular-text">
                        <p class="description">多个模型用英文逗号分隔，如：qwen-plus,qwen-turbo</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aishipu_default_limit">登录用户每日使用次数</label></th>
                    <td><input type="number" name="xb_aishipu_default_limit" id="xb_aishipu_default_limit" value="<?php echo esc_attr(get_option('xb_aishipu_default_limit', 10)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_aishipu_cuisine_options">菜系选项</label></th>
                    <td>
                        <input type="text" name="xb_aishipu_cuisine_options" id="xb_aishipu_cuisine_options" value="<?php echo esc_attr(get_option('xb_aishipu_cuisine_options', '川菜,湘菜,粤菜,鲁菜,苏菜,浙菜,闽菜,徽菜')); ?>" class="regular-text">
                        <p class="description">多个选项用英文逗号分隔，如：川菜,湘菜,粤菜,鲁菜</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aishipu_taste_options">口味选项</label></th>
                    <td>
                        <input type="text" name="xb_aishipu_taste_options" id="xb_aishipu_taste_options" value="<?php echo esc_attr(get_option('xb_aishipu_taste_options', '偏辣,偏甜,常规,清淡')); ?>" class="regular-text">
                        <p class="description">多个选项用英文逗号分隔，如：偏辣,偏甜,常规,清淡</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aishipu_serving_options">用餐人数选项</label></th>
                    <td>
                        <input type="text" name="xb_aishipu_serving_options" id="xb_aishipu_serving_options" value="<?php echo esc_attr(get_option('xb_aishipu_serving_options', '1,2,3,4,5,6')); ?>" class="regular-text">
                        <p class="description">多个选项用英文逗号分隔，如：1,2,3,5</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aishipu_forbidden_words">违规词设置</label></th>
                    <td>
                        <textarea name="xb_aishipu_forbidden_words" id="xb_aishipu_forbidden_words" rows="3" class="large-text"><?php echo esc_textarea(get_option('xb_aishipu_forbidden_words')); ?></textarea>
                        <p class="description">多个违规词用英文逗号分隔</p>
                    </td>
                </tr>
                <tr>
                    <th>功能开关</th>
                    <td>
                        <label><input type="checkbox" name="xb_aishipu_show_stats" <?php checked(get_option('xb_aishipu_show_stats', 1), 1); ?> value="1"> 显示统计信息</label><br>
                        <label><input type="checkbox" name="xb_aishipu_enable_model_selection" <?php checked(get_option('xb_aishipu_enable_model_selection', 0), 1); ?> value="1"> 启用前台模型选择</label><br>
                        <label><input type="checkbox" name="xb_aishipu_enable_search" <?php checked(get_option('xb_aishipu_enable_search', 0), 1); ?> value="1"> 启用联网搜索功能</label>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aishipu_ad_content">公告内容</label></th>
                    <td>
                        <textarea name="xb_aishipu_ad_content" id="xb_aishipu_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_aishipu_ad_content')); ?></textarea>
                        <p class="description">支持 HTML 格式。</p>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="xb_aishipu_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        
        <div class="xb_aishipu_stats">
            <h3>📊 统计信息</h3>
            <p>总推荐次数：<?php echo esc_html($stats['total_records'] ?: 0); ?></p>
            <p>成功推荐次数：<?php echo esc_html($stats['success_records'] ?: 0); ?></p>
            <p>失败推荐次数：<?php echo esc_html($stats['failed_records'] ?: 0); ?></p>
            <p>今日推荐次数：<?php echo esc_html($stats['today_records'] ?: 0); ?></p>
        </div>
    </div>
    
    <style>
    .xb_aishipu_stats {
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        margin-top: 20px;
        border-left: 4px solid #4CAF50;
    }
    .xb_aishipu_stats h3 {
        margin-top: 0;
        color: #4CAF50;
    }
    .xb_aishipu_auto_hide_message {
        animation: fadeOut 3s ease-in-out 3s forwards;
    }
    @keyframes fadeOut {
        0% { opacity: 1; }
        100% { opacity: 0; display: none; }
    }
    </style>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aishipu_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}

// 用户记录页面
function xb_aishipu_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aishipu_records';
    $usage_table = $wpdb->prefix . 'xb_aishipu_usage';
    $user_id = isset($_POST['xb_aishipu_user_id']) ? absint($_POST['xb_aishipu_user_id']) : '';
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    // 一键删除所有记录
    if (isset($_POST['xb_aishipu_delete_all_records'])) {
        check_admin_referer('xb_aishipu_delete_all_records_nonce');
        $wpdb->query("TRUNCATE TABLE $records_table");
        echo '<div class="updated xb_aishipu_auto_hide_message"><p>所有记录已删除！</p></div>';
    }

    // 删除指定用户记录
    if (isset($_POST['xb_aishipu_delete_user_records']) && $user_id !== '') {
        check_admin_referer('xb_aishipu_delete_user_records_nonce');
        $wpdb->delete($records_table, array('user_id' => $user_id), array('%d'));
        echo '<div class="updated xb_aishipu_auto_hide_message"><p>用户记录已删除！</p></div>';
    }

    // 删除单条记录
    if (isset($_POST['xb_aishipu_delete_single_record'])) {
        check_admin_referer('xb_aishipu_delete_single_record_nonce');
        $record_id = isset($_POST['record_id']) ? absint($_POST['record_id']) : 0;
        if ($record_id) {
            $deleted = $wpdb->delete($records_table, array('id' => $record_id), array('%d'));
            if ($deleted) {
                echo '<div class="updated xb_aishipu_auto_hide_message"><p>记录删除成功！</p></div>';
            } else {
                echo '<div class="error xb_aishipu_auto_hide_message"><p>记录删除失败！</p></div>';
            }
        }
    }

    // 设置用户自定义使用次数
    if (isset($_POST['xb_aishipu_set_user_limit']) && $user_id !== '') {
        check_admin_referer('xb_aishipu_set_user_limit_nonce');
        $custom_limit = isset($_POST['xb_aishipu_custom_limit']) ? absint($_POST['xb_aishipu_custom_limit']) : null;
        
        // 获取今天的记录
        $today = current_time('Y-m-d');
        $existing_row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id FROM $usage_table WHERE user_id = %d AND usage_date = %s LIMIT 1",
                $user_id, $today
            )
        );
        
        if ($existing_row) {
            // 更新现有记录
            $wpdb->update(
                $usage_table,
                array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
                array('id' => $existing_row->id),
                array('%d'),
                array('%d')
            );
        } else {
            // 创建新记录
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'device_id' => 'admin_set',
                    'usage_date' => $today,
                    'usage_count' => 0,
                    'custom_limit' => $custom_limit === 0 ? null : $custom_limit,
                )
            );
        }
        
        echo '<div class="updated xb_aishipu_auto_hide_message"><p>用户使用次数限制已设置！</p></div>';
    }

    // 重置用户使用次数
    if (isset($_POST['xb_aishipu_reset_user_usage']) && $user_id !== '') {
        check_admin_referer('xb_aishipu_reset_user_usage_nonce');
        $wpdb->delete($usage_table, array('user_id' => $user_id), array('%d'));
        echo '<div class="updated xb_aishipu_auto_hide_message"><p>用户使用次数已重置！</p></div>';
    }

    $offset = ($paged - 1) * $per_page;
    
    if ($user_id !== '') {
        $query = $wpdb->prepare("SELECT * FROM $records_table WHERE user_id = %d ORDER BY create_time DESC LIMIT %d, %d", $user_id, $offset, $per_page);
        $total_records = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE user_id = %d", $user_id));
    } else {
        $query = $wpdb->prepare("SELECT * FROM $records_table ORDER BY create_time DESC LIMIT %d, %d", $offset, $per_page);
        $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $records_table");
    }
    
    $records = $wpdb->get_results($query);
    $total_pages = ceil($total_records / $per_page);

    ?>
    <div class="wrap">
        <h1>🍳 用户记录</h1>
        
        <div style="margin-bottom: 20px;">
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('xb_aishipu_delete_all_records_nonce'); ?>
                <input type="submit" name="xb_aishipu_delete_all_records" class="button-secondary" value="一键删除所有记录" onclick="return confirm('确定删除所有记录吗？');">
            </form>
        </div>

        <form method="post">
            <p>
                <label for="xb_aishipu_user_id">用户 ID（留空显示所有记录）：</label>
                <input type="number" name="xb_aishipu_user_id" id="xb_aishipu_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <?php if ($user_id !== '') { ?>
            <?php
            // 获取用户当前的使用次数设置
            $today = current_time('Y-m-d');
            $user_usage_row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
                    $user_id, $today
                )
            );
            $current_usage = $user_usage_row ? $user_usage_row->usage_count : 0;
            $current_custom_limit = $user_usage_row && $user_usage_row->custom_limit !== null ? $user_usage_row->custom_limit : null;
            $default_limit = get_option('xb_aishipu_default_limit', 10);
            $effective_limit = $current_custom_limit !== null ? $current_custom_limit : $default_limit;
            ?>
            
            <div style="background: #fff; padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid #4CAF50;">
                <h3>🍳 用户 ID: <?php echo esc_html($user_id); ?> 的使用情况</h3>
                <p><strong>今日已使用：</strong><?php echo esc_html($current_usage); ?> 次</p>
                <p><strong>当前限制：</strong><?php echo esc_html($effective_limit); ?> 次/天 
                    <?php if ($current_custom_limit !== null) { ?>
                        <span style="color: #d63638;">(自定义)</span>
                    <?php } else { ?>
                        <span style="color: #4CAF50;">(默认)</span>
                    <?php } ?>
                </p>
                
                <form method="post" style="margin-top: 15px;">
                    <?php wp_nonce_field('xb_aishipu_set_user_limit_nonce'); ?>
                    <input type="hidden" name="xb_aishipu_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <label for="xb_aishipu_custom_limit">设置专属使用次数（0表示使用默认值）：</label>
                    <input type="number" name="xb_aishipu_custom_limit" id="xb_aishipu_custom_limit" 
                           value="<?php echo esc_attr($current_custom_limit !== null ? $current_custom_limit : 0); ?>" 
                           min="0" max="999" style="width: 80px;">
                    <input type="submit" name="xb_aishipu_set_user_limit" class="button-primary" value="设置限制">
                </form>
            </div>
            
            <div style="margin-bottom: 20px;">
                <form method="post" style="display:inline;">
                    <?php wp_nonce_field('xb_aishipu_delete_user_records_nonce'); ?>
                    <input type="hidden" name="xb_aishipu_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_aishipu_delete_user_records" class="button-secondary" value="删除当前用户记录" onclick="return confirm('确定删除当前用户所有记录吗？');">
                </form>
                <form method="post" style="display:inline; margin-left: 10px;">
                    <?php wp_nonce_field('xb_aishipu_reset_user_usage_nonce'); ?>
                    <input type="hidden" name="xb_aishipu_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_aishipu_reset_user_usage" class="button-secondary" value="重置使用次数" onclick="return confirm('确定重置当前用户的使用次数吗？');">
                </form>
            </div>
        <?php } ?>

        <table class="widefat">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>用户ID</th>
                    <th>食材</th>
                    <th>菜系</th>
                    <th>口味</th>
                    <th>人数</th>
                    <th>模型</th>
                    <th>状态</th>
                    <th>创建时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)) { ?>
                    <tr><td colspan="10">暂无记录。</td></tr>
                <?php } else { ?>
                    <?php foreach ($records as $record) { ?>
                        <tr>
                            <td><?php echo esc_html($record->id); ?></td>
                            <td><?php echo esc_html($record->user_id); ?></td>
                            <td><?php echo esc_html($record->ingredients ? substr($record->ingredients, 0, 30) . '...' : '-'); ?></td>
                            <td><?php echo esc_html($record->cuisine_type ?: '-'); ?></td>
                            <td><?php echo esc_html($record->taste_preference ?: '-'); ?></td>
                            <td><?php echo esc_html($record->serving_size ?: '-'); ?></td>
                            <td><?php echo esc_html($record->model_name ?: '-'); ?></td>
                            <td><?php echo esc_html($record->status); ?></td>
                            <td><?php echo esc_html($record->create_time); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_aishipu_delete_single_record_nonce'); ?>
                                    <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>">
                                    <input type="submit" name="xb_aishipu_delete_single_record" class="button-secondary" value="删除" onclick="return confirm('确定删除这条记录吗？');">
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    
    <style>
    .xb_aishipu_auto_hide_message {
        animation: fadeOut 3s ease-in-out 3s forwards;
    }
    @keyframes fadeOut {
        0% { opacity: 1; }
        100% { opacity: 0; display: none; }
    }
    </style>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aishipu_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}
?>