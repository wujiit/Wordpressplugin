<?php
/*
Plugin Name: 小半朋友圈文案
Description: 一个支持第三方接口和本地数据管理的朋友圈文案插件，包含前台展示、后台设置和数据管理功能。
Version: 1.0
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('AI_PYQWENAN_VERSION', '1.0');
define('AI_PYQWENAN_DIR', plugin_dir_path(__FILE__));
define('AI_PYQWENAN_URL', plugin_dir_url(__FILE__));

// 激活插件时执行
register_activation_hook(__FILE__, 'ai_pyqwenan_activate');
function ai_pyqwenan_activate() {
    ai_pyqwenan_create_table();
    ai_pyqwenan_create_page();
}

// 创建数据库表
function ai_pyqwenan_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'pyqwenan';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        content TEXT NOT NULL,
        source VARCHAR(100) DEFAULT '',
        image_url VARCHAR(255) DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // 初始化调用统计
    if (!get_option('ai_pyqwenan_stats')) {
        update_option('ai_pyqwenan_stats', [
            'total' => [
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ],
            'today' => [
                'date' => current_time('Y-m-d'),
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ]
        ]);
    }
}

// 创建前台页面，检查是否已有包含短代码的页面
function ai_pyqwenan_create_page() {
    $pages = get_posts([
        'post_type' => 'page',
        'post_status' => 'publish',
        's' => '[ai_pyqwenan_display]',
        'numberposts' => 1,
    ]);

    if (empty($pages) && !get_option('ai_pyqwenan_page_id')) {
        $page = [
            'post_title' => '朋友圈文案',
            'post_content' => '[ai_pyqwenan_display]',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        ];
        $page_id = wp_insert_post($page);
        update_option('ai_pyqwenan_page_id', $page_id);
    }
}

// 加载前端资源，仅在包含短代码的页面加载
function ai_pyqwenan_enqueue_assets() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'ai_pyqwenan_display')) {
        wp_enqueue_style('ai_pyqwenan_styles', AI_PYQWENAN_URL . 'ai-pyqwenan.css', [], AI_PYQWENAN_VERSION);
        wp_enqueue_script('ai_pyqwenan_scripts', AI_PYQWENAN_URL . 'ai-pyqwenan.js', ['jquery'], AI_PYQWENAN_VERSION, true);
        wp_localize_script('ai_pyqwenan_scripts', 'ai_pyqwenan_vars', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ai_pyqwenan_refresh')
        ]);
    }
}
add_action('wp_enqueue_scripts', 'ai_pyqwenan_enqueue_assets');

// 注册短代码
add_shortcode('ai_pyqwenan_display', 'ai_pyqwenan_display_page');
function ai_pyqwenan_display_page() {
    $options = get_option('ai_pyqwenan_settings', [
        'use_third_party' => 0,
        'api_url' => 'https://apis.tianapi.com/pyqwenan/index',
        'api_key' => '',
        'ad_content' => ''
    ]);

    $content = '';
    $source = '';
    $image_url = '';

    if ($options['use_third_party']) {
        $data = ai_pyqwenan_fetch_third_party();
        $content = $data['content'] ?? '';
        $source = $data['source'] ?? '佚名';
    } else {
        $data = ai_pyqwenan_fetch_local();
        $content = $data['content'] ?? '';
        $source = $data['source'] ?: '佚名';
        $image_url = $data['image_url'] ?? '';
    }

    // 更新调用统计
    ai_pyqwenan_update_stats($options['use_third_party'], !empty($content));

    ob_start();
    ?>
    <div class="ai_pyqwenan_container">
        <div class="ai_pyqwenan_title">朋友圈文案</div>
        <div class="ai_pyqwenan_card">
            <div class="ai_pyqwenan_content" id="ai_pyqwenan_content"><?php echo esc_html($content); ?></div>
            <?php if ($source): ?>
                <div class="ai_pyqwenan_source" id="ai_pyqwenan_source">—— <?php echo esc_html($source); ?></div>
            <?php endif; ?>
            <?php if ($image_url): ?>
                <div class="ai_pyqwenan_image" id="ai_pyqwenan_image">
                    <img src="<?php echo esc_url($image_url); ?>" alt="朋友圈文案图片">
                </div>
            <?php else: ?>
                <div class="ai_pyqwenan_image" id="ai_pyqwenan_image"></div>
            <?php endif; ?>
        </div>
        <div class="ai_pyqwenan_buttons">
            <button class="ai_pyqwenan_refresh">换一个</button>
            <button class="ai_pyqwenan_copy" data-content="<?php echo esc_attr($content . ($source ? ' —— ' . $source : '')); ?>">复制</button>
        </div>
        <div class="ai_pyqwenan_notice" id="ai_pyqwenan_notice"></div>
        <div class="ai_pyqwenan_ad"><?php echo wp_kses_post($options['ad_content'], [
            'img' => ['src' => [], 'alt' => [], 'class' => [], 'width' => [], 'height' => []],
            'a' => ['href' => [], 'target' => [], 'rel' => []],
            'p' => [],
            'div' => ['class' => []],
            'span' => ['class' => []]
        ]); ?></div>
    </div>
    <?php
    return ob_get_clean();
}

// 更新调用统计
function ai_pyqwenan_update_stats($use_third_party, $third_party_success) {
    $stats = get_option('ai_pyqwenan_stats', [
        'total' => [
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ],
        'today' => [
            'date' => current_time('Y-m-d'),
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ]
    ]);

    if ($stats['today']['date'] !== current_time('Y-m-d')) {
        $stats['today'] = [
            'date' => current_time('Y-m-d'),
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ];
    }

    if ($use_third_party) {
        $stats['total']['third_party_total']++;
        $stats['today']['third_party_total']++;
        if ($third_party_success) {
            $stats['total']['third_party_success']++;
            $stats['today']['third_party_success']++;
        }
    } else {
        $stats['total']['local_total']++;
        $stats['today']['local_total']++;
    }

    update_option('ai_pyqwenan_stats', $stats);
}

// AJAX 刷新朋友圈文案
add_action('wp_ajax_ai_pyqwenan_refresh', 'ai_pyqwenan_refresh_callback');
function ai_pyqwenan_refresh_callback() {
    check_ajax_referer('ai_pyqwenan_refresh', 'nonce');
    $options = get_option('ai_pyqwenan_settings', ['use_third_party' => 0]);
    $content = '';
    $source = '';
    $image_url = '';

    if ($options['use_third_party']) {
        $data = ai_pyqwenan_fetch_third_party();
        $content = $data['content'] ?? '';
        $source = $data['source'] ?? '佚名';
    } else {
        $seed = isset($_POST['_t']) ? intval($_POST['_t']) : time();
        $data = ai_pyqwenan_fetch_local($seed);
        $content = $data['content'] ?? '';
        $source = $data['source'] ?: '佚名';
        $image_url = $data['image_url'] ?? '';
    }

    // 更新调用统计
    ai_pyqwenan_update_stats($options['use_third_party'], !empty($content));

    wp_send_json_success(['content' => $content, 'source' => $source, 'image_url' => $image_url]);
}

// 获取第三方接口数据
function ai_pyqwenan_fetch_third_party() {
    $options = get_option('ai_pyqwenan_settings', [
        'api_url' => 'https://apis.tianapi.com/pyqwenan/index',
        'api_key' => ''
    ]);

    $args = [
        'method' => 'POST',
        'body' => ['key' => $options['api_key']],
        'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
        'timeout' => 10,
    ];

    $response = wp_remote_request($options['api_url'], $args);
    if (is_wp_error($response)) {
        return ['content' => '', 'source' => '佚名'];
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['code']) && $data['code'] == 200 && isset($data['result']['content'])) {
        return [
            'content' => $data['result']['content'],
            'source' => isset($data['result']['source']) ? $data['result']['source'] : '佚名'
        ];
    }
    return ['content' => '', 'source' => '佚名'];
}

// 获取本地数据，使用动态种子避免缓存影响
function ai_pyqwenan_fetch_local($seed = null) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'pyqwenan';

    $ids = $wpdb->get_col("SELECT id FROM $table_name");
    if (empty($ids)) {
        return ['content' => '暂无朋友圈文案数据，请在后台添加！', 'source' => '佚名', 'image_url' => ''];
    }

    $seed = $seed ?? time();
    mt_srand($seed);
    $random_id = $ids[mt_rand(0, count($ids) - 1)];

    $result = $wpdb->get_row(
        $wpdb->prepare("SELECT content, source, image_url FROM $table_name WHERE id = %d", $random_id),
        ARRAY_A
    );

    return $result ?? ['content' => '暂无朋友圈文案数据，请在后台添加！', 'source' => '佚名', 'image_url' => ''];
}

// 后台菜单
add_action('admin_menu', 'ai_pyqwenan_admin_menu');
function ai_pyqwenan_admin_menu() {
    add_menu_page('朋友圈文案设置', '朋友圈文案', 'manage_options', 'ai-pyqwenan-settings', 'ai_pyqwenan_settings_page', 'dashicons-format-quote');
    add_submenu_page('ai-pyqwenan-settings', '数据管理', '数据管理', 'manage_options', 'ai-pyqwenan-data', 'ai_pyqwenan_data_page');
}

// 设置页面
function ai_pyqwenan_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['ai_pyqwenan_save_settings'])) {
        check_admin_referer('ai_pyqwenan_settings');
        $settings = [
            'use_third_party' => isset($_POST['ai_pyqwenan_use_third_party']) ? 1 : 0,
            'api_url' => sanitize_text_field($_POST['ai_pyqwenan_api_url']),
            'api_key' => sanitize_text_field($_POST['ai_pyqwenan_api_key']),
            'ad_content' => wp_kses_post($_POST['ai_pyqwenan_ad_content'], [
                'img' => ['src' => [], 'alt' => [], 'class' => [], 'width' => [], 'height' => []],
                'a' => ['href' => [], 'target' => [], 'rel' => []],
                'p' => [],
                'div' => ['class' => []],
                'span' => ['class' => []]
            ])
        ];
        update_option('ai_pyqwenan_settings', $settings);
        echo '<div class="notice notice-success is-dismissible ai_pyqwenan_notice"><p>设置已保存。</p></div>';
    }

    if (isset($_POST['ai_pyqwenan_clear_stats'])) {
        check_admin_referer('ai_pyqwenan_clear_stats');
        update_option('ai_pyqwenan_stats', [
            'total' => [
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ],
            'today' => [
                'date' => current_time('Y-m-d'),
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ]
        ]);
        echo '<div class="notice notice-success is-dismissible ai_pyqwenan_notice"><p>调用统计已清空。</p></div>';
    }

    $options = get_option('ai_pyqwenan_settings', [
        'use_third_party' => 0,
        'api_url' => 'https://apis.tianapi.com/pyqwenan/index',
        'api_key' => '',
        'ad_content' => ''
    ]);

    $stats = get_option('ai_pyqwenan_stats', [
        'total' => [
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ],
        'today' => [
            'date' => current_time('Y-m-d'),
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ]
    ]);

    ?>
    <div class="wrap">
        <h1>小半朋友圈文案设置</h1>
        <form method="post" action="">
            <?php wp_nonce_field('ai_pyqwenan_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="ai_pyqwenan_use_third_party">使用第三方接口</label></th>
                    <td><input type="checkbox" name="ai_pyqwenan_use_third_party" id="ai_pyqwenan_use_third_party" <?php checked($options['use_third_party'], 1); ?>></td>
                </tr>
                <tr>
                    <th><label for="ai_pyqwenan_api_url">API 接口地址</label></th>
                    <td><input type="text" name="ai_pyqwenan_api_url" id="ai_pyqwenan_api_url" value="<?php echo esc_attr($options['api_url']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="ai_pyqwenan_api_key">API 密钥</label></th>
                    <td><input type="text" name="ai_pyqwenan_api_key" id="ai_pyqwenan_api_key" value="<?php echo esc_attr($options['api_key']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="ai_pyqwenan_ad_content">广告内容</label></th>
                    <td><textarea name="ai_pyqwenan_ad_content" id="ai_pyqwenan_ad_content" rows="5" class="large-text"><?php echo esc_textarea($options['ad_content']); ?></textarea></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="ai_pyqwenan_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        <p>第三方接口: https://www.tianapi.com/apiview/194 </p>
        <h2>调用统计</h2>
        <h3>总计</h3>
        <p>第三方接口总调用次数: <?php echo esc_html($stats['total']['third_party_total']); ?></p>
        <p>第三方接口成功调用次数: <?php echo esc_html($stats['total']['third_party_success']); ?></p>
        <p>本地接口调用次数: <?php echo esc_html($stats['total']['local_total']); ?></p>
        <h3>今日 (<?php echo esc_html($stats['today']['date']); ?>)</h3>
        <p>第三方接口总调用次数: <?php echo esc_html($stats['today']['third_party_total']); ?></p>
        <p>第三方接口成功调用次数: <?php echo esc_html($stats['today']['third_party_success']); ?></p>
        <p>本地接口调用次数: <?php echo esc_html($stats['today']['local_total']); ?></p>
        <form method="post" action="">
            <?php wp_nonce_field('ai_pyqwenan_clear_stats'); ?>
            <p class="submit"><input type="submit" name="ai_pyqwenan_clear_stats" class="button-secondary" value="清空统计" onclick="return confirm('确定清空所有调用统计？');"></p>
        </form>
    </div>
    <?php
}

// 数据管理页面
function ai_pyqwenan_data_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'pyqwenan';

    // 处理添加
    if (isset($_POST['ai_pyqwenan_add_data'])) {
        check_admin_referer('ai_pyqwenan_data');
        $content = sanitize_text_field($_POST['ai_pyqwenan_content']);
        $source = sanitize_text_field($_POST['ai_pyqwenan_source']);
        $image_url = esc_url_raw($_POST['ai_pyqwenan_image_url']);
        $wpdb->insert($table_name, [
            'content' => $content,
            'source' => $source ?: '佚名',
            'image_url' => $image_url
        ]);
        echo '<div class="notice notice-success is-dismissible ai_pyqwenan_notice"><p>数据已添加。</p></div>';
    }

    // 处理编辑
    if (isset($_POST['ai_pyqwenan_edit_data'])) {
        check_admin_referer('ai_pyqwenan_edit_data');
        $id = intval($_POST['ai_pyqwenan_edit_id']);
        $content = sanitize_text_field($_POST['ai_pyqwenan_content']);
        $source = sanitize_text_field($_POST['ai_pyqwenan_source']);
        $image_url = esc_url_raw($_POST['ai_pyqwenan_image_url']);
        $wpdb->update($table_name, [
            'content' => $content,
            'source' => $source ?: '佚名',
            'image_url' => $image_url
        ], ['id' => $id]);
        echo '<div class="notice notice-success is-dismissible ai_pyqwenan_notice"><p>数据已更新。</p></div>';
    }

    // 处理删除
    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
        check_admin_referer('ai_pyqwenan_delete_' . $_GET['id']);
        $wpdb->delete($table_name, ['id' => intval($_GET['id'])]);
        echo '<div class="notice notice-success is-dismissible ai_pyqwenan_notice"><p>数据已删除。</p></div>';
    }

    // 处理删除全部
    if (isset($_POST['ai_pyqwenan_delete_all'])) {
        check_admin_referer('ai_pyqwenan_delete_all');
        $wpdb->query("TRUNCATE TABLE $table_name");
        echo '<div class="notice notice-success is-dismissible ai_pyqwenan_notice"><p>所有数据已删除。</p></div>';
    }

    // 获取编辑数据
    $edit_item = null;
    if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
        $edit_item = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", intval($_GET['id'])), ARRAY_A);
    }

    // 分页
    $per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;
    $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $total_pages = ceil($total_items / $per_page);
    $items = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC LIMIT $offset, $per_page", ARRAY_A);

    ?>
    <div class="wrap">
        <h1>朋友圈文案数据管理</h1>
        
        <!-- 添加数据表单 -->
        <h2>添加新数据</h2>
        <form method="post" action="">
            <?php wp_nonce_field('ai_pyqwenan_data'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="ai_pyqwenan_content_add">文案内容</label></th>
                    <td><input type="text" name="ai_pyqwenan_content" id="ai_pyqwenan_content_add" value="" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="ai_pyqwenan_source_add">来源出处</label></th>
                    <td><input type="text" name="ai_pyqwenan_source" id="ai_pyqwenan_source_add" value="" class="regular-text" placeholder="佚名"></td>
                </tr>
                <tr>
                    <th><label for="ai_pyqwenan_image_url_add">图片 URL</label></th>
                    <td><input type="url" name="ai_pyqwenan_image_url" id="ai_pyqwenan_image_url_add" value="" class="regular-text"></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="ai_pyqwenan_add_data" class="button-primary" value="添加数据"></p>
        </form>

        <!-- 编辑数据表单 -->
        <?php if ($edit_item): ?>
            <h2>编辑数据</h2>
            <form method="post" action="">
                <?php wp_nonce_field('ai_pyqwenan_edit_data'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="ai_pyqwenan_content_edit">文案内容</label></th>
                        <td><input type="text" name="ai_pyqwenan_content" id="ai_pyqwenan_content_edit" value="<?php echo esc_attr($edit_item['content']); ?>" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="ai_pyqwenan_source_edit">来源出处</label></th>
                        <td><input type="text" name="ai_pyqwenan_source" id="ai_pyqwenan_source_edit" value="<?php echo esc_attr($edit_item['source']); ?>" class="regular-text" placeholder="佚名"></td>
                    </tr>
                    <tr>
                        <th><label for="ai_pyqwenan_image_url_edit">图片 URL</label></th>
                        <td><input type="url" name="ai_pyqwenan_image_url" id="ai_pyqwenan_image_url_edit" value="<?php echo esc_url($edit_item['image_url']); ?>" class="regular-text"></td>
                    </tr>
                </table>
                <input type="hidden" name="ai_pyqwenan_edit_id" value="<?php echo esc_attr($edit_item['id']); ?>">
                <p class="submit"><input type="submit" name="ai_pyqwenan_edit_data" class="button-primary" value="更新数据"></p>
            </form>
        <?php endif; ?>

        <!-- 删除所有数据 -->
        <form method="post" action="">
            <?php wp_nonce_field('ai_pyqwenan_delete_all'); ?>
            <p class="submit"><input type="submit" name="ai_pyqwenan_delete_all" class="button-secondary" value="删除所有数据" onclick="return confirm('确定删除所有数据？');"></p>
        </form>

        <!-- 数据列表 -->
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>文案内容</th>
                    <th>来源出处</th>
                    <th>图片 URL</th>
                    <th>创建时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td><?php echo esc_html($item['content']); ?></td>
                        <td><?php echo esc_html($item['source'] ?: '佚名'); ?></td>
                        <td><?php echo esc_url($item['image_url']); ?></td>
                        <td><?php echo esc_html($item['created_at']); ?></td>
                        <td>
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ai-pyqwenan-data&action=edit&id=' . $item['id']), 'ai_pyqwenan_edit_' . $item['id']); ?>">编辑</a> |
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ai-pyqwenan-data&action=delete&id=' . $item['id']), 'ai_pyqwenan_delete_' . $item['id']); ?>" onclick="return confirm('确定删除？');">删除</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- 分页 -->
        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links([
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => '«',
                'next_text' => '»',
                'total' => $total_pages,
                'current' => $current_page
            ]);
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}

// 后台通知自动消失脚本
add_action('admin_footer', 'ai_pyqwenan_admin_scripts');
function ai_pyqwenan_admin_scripts() {
    ?>
    <script>
    jQuery(document).ready(function($) {
        setTimeout(function() {
            $('.ai_pyqwenan_notice').fadeOut('slow');
        }, 3000);
    });
    </script>
    <?php
}
?>