jQuery(document).ready(function($) {
    // 刷新朋友圈文案按钮点击事件
    $('.ai_pyqwenan_refresh').on('click', function() {
        var $button = $(this);
        $button.prop('disabled', true);
        $('#ai_pyqwenan_content, #ai_pyqwenan_source, #ai_pyqwenan_image').css('opacity', '0');

        $.ajax({
            url: ai_pyqwenan_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'ai_pyqwenan_refresh',
                nonce: ai_pyqwenan_vars.nonce,
                _t: new Date().getTime()
            },
            cache: false,
            success: function(response) {
                if (response.success) {
                    $('#ai_pyqwenan_content').text(response.data.content).css('opacity', '1');
                    $('#ai_pyqwenan_source').text('—— ' + response.data.source).css('opacity', '1');
                    if (response.data.image_url) {
                        $('#ai_pyqwenan_image').html('<img src="' + response.data.image_url + '" alt="朋友圈文案图片">').css('opacity', '1');
                    } else {
                        $('#ai_pyqwenan_image').empty().css('opacity', '1');
                    }
                    $('.ai_pyqwenan_copy').data('content', response.data.content + ' —— ' + response.data.source);
                } else {
                    $('#ai_pyqwenan_notice').text('刷新失败：' + (response.data.message || '未知错误')).show();
                    setTimeout(function() {
                        $('#ai_pyqwenan_notice').fadeOut('slow', function() {
                            $(this).empty();
                        });
                    }, 3000);
                }
                $button.prop('disabled', false);
            },
            error: function() {
                $('#ai_pyqwenan_content, #ai_pyqwenan_source, #ai_pyqwenan_image').css('opacity', '1');
                $button.prop('disabled', false);
                $('#ai_pyqwenan_notice').text('网络错误，请稍后再试！').show();
                setTimeout(function() {
                    $('#ai_pyqwenan_notice').fadeOut('slow', function() {
                        $(this).empty();
                    });
                }, 3000);
            }
        });
    });

    // 复制朋友圈文案文字按钮点击事件
    $('.ai_pyqwenan_copy').on('click', function() {
        var content = $(this).data('content');
        var $button = $(this);
        var $notice = $('#ai_pyqwenan_notice');

        navigator.clipboard.writeText(content).then(function() {
            $button.addClass('copied').text('已复制');
            $notice.empty();
            setTimeout(function() {
                $button.removeClass('copied').text('复制');
            }, 2000);
        }).catch(function() {
            $notice.text('复制失败，请手动复制！').show();
            setTimeout(function() {
                $notice.fadeOut('slow', function() {
                    $notice.empty();
                });
            }, 3000);
        });
    });
});