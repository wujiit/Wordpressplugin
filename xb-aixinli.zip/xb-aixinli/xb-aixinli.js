jQuery(document).ready(function ($) {
    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('XB AIXINLI: jQuery 未加载！');
        $('#xb_aixinli_result').html('<div class="xb_aixinli_message xb_aixinli_message_error">脚本加载失败，请刷新页面！</div>');
        return;
    }

    // 确保 xb_aixinli_ajax 配置
    if (typeof xb_aixinli_ajax === 'undefined') {
        console.error('XB AIXINLI: xb_aixinli_ajax 未定义！');
        $('#xb_aixinli_result').html('<div class="xb_aixinli_message xb_aixinli_message_error">脚本配置失败，请检查插件设置！</div>');
        return;
    }

    let currentFormData = null;
    let isAnalyzing = false;
    let typingTimer = null;
    let isFirstTimeAnalysis = true; // 标记是否为首次分析

    // 游客本地存储相关函数
    const GUEST_STORAGE_KEY = 'xb_aixinli_guest_records';
    
    // 保存游客记录到本地存储
    function saveGuestRecord(record) {
        if (xb_aixinli_ajax.is_logged_in == 1) return; // 登录用户不使用本地存储
        
        try {
            let records = JSON.parse(localStorage.getItem(GUEST_STORAGE_KEY) || '[]');
            records.unshift(record); // 添加到开头
            
            // 限制最多保存20条记录
            if (records.length > 20) {
                records = records.slice(0, 20);
            }
            
            localStorage.setItem(GUEST_STORAGE_KEY, JSON.stringify(records));
        } catch (e) {
            console.error('保存游客记录失败:', e);
        }
    }
    
    // 获取游客本地记录
    function getGuestRecords() {
        if (xb_aixinli_ajax.is_logged_in == 1) return []; // 登录用户不使用本地存储
        
        try {
            return JSON.parse(localStorage.getItem(GUEST_STORAGE_KEY) || '[]');
        } catch (e) {
            console.error('读取游客记录失败:', e);
            return [];
        }
    }
    
    // 删除游客本地记录
    function deleteGuestRecord(recordId) {
        if (xb_aixinli_ajax.is_logged_in == 1) return; // 登录用户不使用本地存储
        
        try {
            let records = JSON.parse(localStorage.getItem(GUEST_STORAGE_KEY) || '[]');
            records = records.filter(record => record.id !== recordId);
            localStorage.setItem(GUEST_STORAGE_KEY, JSON.stringify(records));
        } catch (e) {
            console.error('删除游客记录失败:', e);
        }
    }
    
    // 加载游客历史记录
    function loadGuestHistory() {
        if (xb_aixinli_ajax.is_logged_in == 1) return; // 登录用户不使用此函数
        
        const records = getGuestRecords();
        const $historyList = $('#xb_aixinli_history_list');
        
        if (records.length > 0) {
            let html = '';
            records.forEach(function(record) {
                html += '<div class="xb_aixinli_history_item" data-id="' + record.id + '">';
                html += '<button class="xb_aixinli_delete_record_btn" data-id="' + record.id + '" title="删除记录">×</button>';
                html += '<div class="xb_aixinli_history_date">' + record.create_time + '</div>';
                html += '<div class="xb_aixinli_history_preview">' + (record.custom_content || '心理分析记录').substring(0, 50) + '...</div>';
                html += '<div class="xb_aixinli_history_crowd">' + (record.crowd_type || '未知') + '</div>';
                html += '</div>';
            });
            $historyList.html(html);
        } else {
            $historyList.html('<div class="xb_aixinli_no_history">暂无分析记录</div>');
        }
    }

    // 自定义确认对话框
    window.xb_aixinli_show_confirm = function(title, message, onConfirm) {
        $('#xb_aixinli_confirm_title').text(title);
        $('#xb_aixinli_confirm_message').text(message);
        $('#xb_aixinli_confirm_modal').show();
        
        // 绑定确认按钮事件
        $('#xb_aixinli_confirm_ok').off('click').on('click', function() {
            $('#xb_aixinli_confirm_modal').hide();
            if (typeof onConfirm === 'function') {
                onConfirm();
            }
        });
        
        // 绑定取消按钮事件
        $('#xb_aixinli_confirm_cancel').off('click').on('click', function() {
            $('#xb_aixinli_confirm_modal').hide();
        });
        
        // 点击遮罩层关闭
        $('.xb_aixinli_modal_overlay').off('click').on('click', function() {
            $('#xb_aixinli_confirm_modal').hide();
        });
    };
    
    // 自定义提示对话框
    window.xb_aixinli_show_alert = function(message, title) {
        $('#xb_aixinli_alert_title').text(title || '提示');
        $('#xb_aixinli_alert_message').text(message);
        $('#xb_aixinli_alert_modal').show();
        
        // 绑定确定按钮事件
        $('#xb_aixinli_alert_ok').off('click').on('click', function() {
            $('#xb_aixinli_alert_modal').hide();
        });
        
        // 点击遮罩层关闭
        $('.xb_aixinli_modal_overlay').off('click').on('click', function() {
            $('#xb_aixinli_alert_modal').hide();
        });
    };

    // 字符计数器
    $('#xb_aixinli_custom_content').on('input', function() {
        const length = $(this).val().length;
        $('.xb_aixinli_char_count').text(length + '/500');
        
        if (length > 500) {
            $(this).val($(this).val().substring(0, 500));
            $('.xb_aixinli_char_count').text('500/500');
        }
    });

    // 人群选择变化时加载对应问题
    $('input[name="crowd_type"]').on('change', function() {
        const crowdType = $(this).val();
        loadQuestionsForCrowd(crowdType);
    });

    // 页面加载时加载默认人群的问题
    const defaultCrowd = $('input[name="crowd_type"]:checked').val();
    if (defaultCrowd) {
        loadQuestionsForCrowd(defaultCrowd);
    }

    // 加载指定人群的问题
    function loadQuestionsForCrowd(crowdType) {
        $.ajax({
            url: xb_aixinli_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_aixinli_get_questions',
                crowd_type: crowdType
            },
            success: function(response) {
                if (response.success && response.data.html) {
                    $('#xb_aixinli_questions_list').html(response.data.html);
                } else {
                    $('#xb_aixinli_questions_list').html('<p class="xb_aixinli_no_questions">暂无相关问题，请在补充说明中详细描述您的情况。</p>');
                }
            },
            error: function() {
                $('#xb_aixinli_questions_list').html('<p class="xb_aixinli_no_questions">加载问题失败，请刷新页面重试。</p>');
            }
        });
    }

    // 表单提交处理
    $('#xb_aixinli_form').on('submit', function (e) {
        e.preventDefault();
        
        if (isAnalyzing) {
            return;
        }

        const formData = getFormData();
        if (!validateFormData(formData)) {
            return;
        }

        currentFormData = formData;
        isFirstTimeAnalysis = true; // 标记为首次分析
        
        // 显示右侧面板
        showAnalysisPanel();
        
        analyzeContent(formData);
    });

    // 显示分析面板（切换布局）
    function showAnalysisPanel() {
        $('.xb_aixinli_main_content').addClass('analyzing');
        
        // 滚动到结果区域
        setTimeout(function() {
            $('.xb_aixinli_result_section')[0].scrollIntoView({ 
                behavior: 'smooth',
                block: 'start'
            });
        }, 300);
    }

    // 获取表单数据
    function getFormData() {
        const questionAnswers = [];
        const questionIds = [];
        
        $('.xb_aixinli_question_answer').each(function(index) {
            const answer = $(this).val().trim();
            const questionId = $('input[name="question_ids[]"]').eq(index).val();
            if (answer && questionId) {
                questionAnswers.push(answer);
                questionIds.push(questionId);
            }
        });

        return {
            crowd_type: $('input[name="crowd_type"]:checked').val(),
            question_answers: questionAnswers,
            question_ids: questionIds,
            custom_content: $('#xb_aixinli_custom_content').val().trim(),
            model: $('#xb_aixinli_model').val() || '',
            enable_search: $('#xb_aixinli_enable_search').is(':checked') ? 1 : 0
        };
    }

    // 验证表单数据
    function validateFormData(data) {
        if (!data.crowd_type) {
            xb_aixinli_show_alert('请选择您的身份');
            return false;
        }

        if (data.question_answers.length === 0 && !data.custom_content) {
            xb_aixinli_show_alert('请至少回答一个问题或填写补充说明');
            return false;
        }

        return true;
    }

    // 分析内容
    function analyzeContent(data) {
        isAnalyzing = true;
        
        // 更新按钮状态
        $('#xb_aixinli_submit_button')
            .prop('disabled', true)
            .html('<span class="xb_aixinli_button_icon">⏳</span>分析中...');

        // 显示加载动画
        showLoadingMessage();
        
        // 隐藏操作按钮
        $('.xb_aixinli_result_actions').hide();

        if (xb_aixinli_ajax.is_logged_in == 1) {
            // 登录用户使用 REST API
            handleLoggedUserAnalyze(data);
        } else {
            // 游客使用 AJAX
            handleGuestAnalyze(data);
        }
    }

    // 处理登录用户分析
    function handleLoggedUserAnalyze(data) {
        $.ajax({
            url: xb_aixinli_ajax.rest_url,
            type: 'POST',
            data: JSON.stringify(data),
            contentType: 'application/json',
            headers: { 'X-WP-Nonce': xb_aixinli_ajax.nonce },
            success: function (response) {
                if (response.success && response.content) {
                    // 首次分析使用流式输出，历史记录直接显示
                    if (isFirstTimeAnalysis) {
                        displayStreamingResult(response.content);
                    } else {
                        displayDirectResult(response.content);
                    }
                    updateUsageInfo(response.remaining, response.limit);
                    
                    // 检查是否用完次数
                    if (response.remaining <= 0) {
                        hideFormAndShowMessage(false);
                    }
                    
                    // 刷新历史记录
                    if (typeof xb_aixinli_load_history === 'function') {
                        xb_aixinli_load_history();
                    }
                } else {
                    xb_aixinli_show_alert(response.message || '暂时无法分析请联系客服');
                }
                resetAnalyzeButton();
            },
            error: function (xhr) {
                const message = xhr.responseJSON && xhr.responseJSON.message ? 
                    xhr.responseJSON.message : '暂时无法分析请联系客服';
                xb_aixinli_show_alert(message);
                resetAnalyzeButton();
            }
        });
    }

    // 处理游客分析
    function handleGuestAnalyze(data) {
        $.ajax({
            url: xb_aixinli_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_aixinli_guest_analyze',
                ...data
            },
            success: function (response) {
                if (response.success && response.data.content) {
                    // 首次分析使用流式输出，历史记录直接显示
                    if (isFirstTimeAnalysis) {
                        displayStreamingResult(response.data.content);
                        
                        // 游客保存记录到本地存储
                        const guestRecord = {
                            id: Date.now(), // 使用时间戳作为ID
                            crowd_type: data.crowd_type,
                            custom_content: data.custom_content,
                            ai_response: response.data.content,
                            create_time: new Date().toLocaleString('zh-CN'),
                            status: 'success'
                        };
                        saveGuestRecord(guestRecord);
                        
                        // 刷新游客历史记录显示
                        loadGuestHistory();
                    } else {
                        displayDirectResult(response.data.content);
                    }
                    updateUsageInfo(response.data.remaining, response.data.limit);
                    
                    // 检查是否用完次数
                    if (response.data.remaining <= 0) {
                        hideFormAndShowMessage(true);
                    }
                } else {
                    xb_aixinli_show_alert(response.data.message || '暂时无法分析请联系客服');
                }
                resetAnalyzeButton();
            },
            error: function (xhr) {
                const message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ? 
                    xhr.responseJSON.data.message : '暂时无法分析请联系客服';
                xb_aixinli_show_alert(message);
                resetAnalyzeButton();
            }
        });
    }

    // 显示流式结果（优化的打字机效果）
    function displayStreamingResult(content) {
        // 先渲染Markdown内容
        let renderedContent = '';
        if (typeof marked !== 'undefined') {
            try {
                renderedContent = marked.parse(content);
            } catch (e) {
                console.warn('Markdown解析失败，使用纯文本显示:', e);
                renderedContent = content.replace(/\n/g, '<br>');
            }
        } else {
            // 如果没有marked库，简单处理换行
            renderedContent = content.replace(/\n/g, '<br>');
        }
        
        const $resultContainer = $('#xb_aixinli_result');
        $resultContainer.html('<div class="xb_aixinli_result_content"></div>');
        
        const $content = $('.xb_aixinli_result_content');
        
        // 优化的打字机效果：先完整渲染HTML，然后逐步显示文本
        $content.html(renderedContent);
        
        // 获取所有文本节点
        const textNodes = [];
        function collectTextNodes(node) {
            if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) {
                textNodes.push({
                    node: node,
                    originalText: node.textContent,
                    currentIndex: 0
                });
                node.textContent = ''; // 清空文本
            } else {
                for (let child of node.childNodes) {
                    collectTextNodes(child);
                }
            }
        }
        
        collectTextNodes($content[0]);
        
        let currentNodeIndex = 0;
        
        function typeWriter() {
            if (currentNodeIndex < textNodes.length) {
                const textNode = textNodes[currentNodeIndex];
                
                if (textNode.currentIndex < textNode.originalText.length) {
                    // 逐字符显示当前文本节点
                    textNode.currentIndex++;
                    textNode.node.textContent = textNode.originalText.substring(0, textNode.currentIndex);
                    
                    // 滚动到底部
                    $content[0].scrollTop = $content[0].scrollHeight;
                    
                    const delay = Math.random() * 30 + 10; // 10-40ms随机延迟
                    typingTimer = setTimeout(typeWriter, delay);
                } else {
                    // 当前文本节点完成，移到下一个
                    currentNodeIndex++;
                    typingTimer = setTimeout(typeWriter, 50);
                }
            } else {
                // 打字完成，显示操作按钮
                $('.xb_aixinli_result_actions').show();
            }
        }
        
        if (textNodes.length > 0) {
            typeWriter();
        } else {
            // 没有文本节点，直接显示操作按钮
            $('.xb_aixinli_result_actions').show();
        }
    }

    // 直接显示结果（历史记录查看）
    function displayDirectResult(content) {
        // 使用Markdown渲染器渲染内容
        let renderedContent = '';
        if (typeof marked !== 'undefined') {
            try {
                renderedContent = marked.parse(content);
            } catch (e) {
                console.warn('Markdown解析失败，使用纯文本显示:', e);
                renderedContent = content.replace(/\n/g, '<br>');
            }
        } else {
            // 如果没有marked库，简单处理换行
            renderedContent = content.replace(/\n/g, '<br>');
        }
        
        const $resultContainer = $('#xb_aixinli_result');
        $resultContainer.html('<div class="xb_aixinli_result_content">' + renderedContent + '</div>');
        $('.xb_aixinli_result_actions').show();
    }

    // 显示加载信息
    function showLoadingMessage() {
        $('#xb_aixinli_result').html(
            '<div class="xb_aixinli_loading">' +
            '<div class="xb_aixinli_spinner"></div>' +
            '<div class="xb_aixinli_ts_subtitle">🧠 AI正在分析中</div>' +
            '<p>请稍候，AI正在为您进行深度心理分析...</p>' +
            '</div>'
        );
    }

    // 显示错误信息
    function showError(message) {
        $('#xb_aixinli_result').html(
            '<div class="xb_aixinli_message xb_aixinli_message_error">' +
            '<span class="xb_aixinli_message_icon">❌</span>' + message + 
            '</div>'
        );
        $('.xb_aixinli_result_actions').show();
    }

    // 重置分析按钮
    function resetAnalyzeButton() {
        isAnalyzing = false;
        $('#xb_aixinli_submit_button')
            .prop('disabled', false)
            .html('<span class="xb_aixinli_button_icon">🧠</span>开始分析');
    }

    // 更新使用次数信息
    function updateUsageInfo(remaining, limit) {
        const isGuest = xb_aixinli_ajax.is_logged_in == 0;
        let text;
        
        if (remaining > 0) {
            text = `今日剩余分析次数：${remaining}/${limit}`;
        } else {
            if (isGuest) {
                text = '游客的使用次数已经用完，请登录之后继续。';
            } else {
                text = '今日使用次数已经用完，请明天再来。';
            }
        }
        
        $('#xb_aixinli_usage_text').text(text);
    }

    // 隐藏表单并显示相应消息
    function hideFormAndShowMessage(isGuest) {
        $('#xb_aixinli_form').fadeOut(300, function() {
            let message;
            if (isGuest) {
                message = 
                    '<div class="xb_aixinli_message xb_aixinli_message_info">' +
                    '<div class="xb_aixinli_message_icon">🔐</div>' +
                    '<div class="xb_aixinli_message_content">' +
                    '<div class="xb_aixinli_ts_subtitle">游客的使用次数已经用完，请登录之后继续。</div>' +
                    '<a href="' + xb_aixinli_ajax.login_url + '" class="xb_aixinli_login_btn">' +
                    '<span class="xb_aixinli_button_icon">🚀</span>立即登录' +
                    '</a>' +
                    '</div>' +
                    '</div>';
            } else {
                message = 
                    '<div class="xb_aixinli_message xb_aixinli_message_info">' +
                    '<div class="xb_aixinli_message_icon">📅</div>' +
                    '<div class="xb_aixinli_message_content">' +
                    '<div class="xb_aixinli_ts_subtitle">今日使用次数已经用完，请明天再来。</div>' +
                    '</div>' +
                    '</div>';
            }
            $('.xb_aixinli_form_section').append(message);
        });
    }

    // 复制结果按钮
    $('#xb_aixinli_copy_button').on('click', function(e) {
        e.preventDefault();
        
        const $button = $(this);
        const originalText = $button.html();
        const content = $('.xb_aixinli_result_content').text();
        
        if (content) {
            // 使用现代浏览器的 Clipboard API
            if (navigator.clipboard) {
                navigator.clipboard.writeText(content).then(function() {
                    showCopySuccess($button, originalText);
                }).catch(function() {
                    fallbackCopyText(content, $button, originalText);
                });
            } else {
                fallbackCopyText(content, $button, originalText);
            }
        }
    });

    // 导出Markdown按钮
    $('#xb_aixinli_export_md_button').on('click', function(e) {
        e.preventDefault();
        const content = $('.xb_aixinli_result_content').text();
        if (content) {
            downloadFile(content, 'ai-analysis.md', 'text/markdown');
        }
    });

    // 导出HTML按钮
    $('#xb_aixinli_export_html_button').on('click', function(e) {
        e.preventDefault();
        const content = $('.xb_aixinli_result_content').html();
        if (content) {
            const htmlContent = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>AI心理分析结果</title></head><body>${content}</body></html>`;
            downloadFile(htmlContent, 'ai-analysis.html', 'text/html');
        }
    });

    // 导出图片按钮
    $('#xb_aixinli_export_image_button').on('click', function(e) {
        e.preventDefault();
        const $content = $('.xb_aixinli_result_content');
        if ($content.length && typeof html2canvas !== 'undefined') {
            html2canvas($content[0]).then(function(canvas) {
                const link = document.createElement('a');
                link.download = 'ai-analysis.png';
                link.href = canvas.toDataURL();
                link.click();
            });
        } else {
            xb_aixinli_show_alert('导出图片功能需要加载html2canvas库');
        }
    });

    // 清空内容按钮
    $('#xb_aixinli_clear_button').on('click', function(e) {
        e.preventDefault();
        
        // 停止打字机效果
        if (typingTimer) {
            clearTimeout(typingTimer);
            typingTimer = null;
        }
        
        $('#xb_aixinli_result').empty();
        $('.xb_aixinli_result_actions').hide();
        currentFormData = null;
        
        // 隐藏右侧面板，恢复初始布局
        $('.xb_aixinli_main_content').removeClass('analyzing');
        
        // 检查是否有使用次数限制消息
        const hasLimitMessage = $('.xb_aixinli_form_section .xb_aixinli_message').length > 0;
        
        // 如果没有限制消息，重置表单
        if (!hasLimitMessage) {
            resetForm();
        }
    });

    // 历史记录点击处理
    $(document).on('click', '.xb_aixinli_history_item', function(e) {
        // 如果点击的是删除按钮，不执行查看记录
        if ($(e.target).hasClass('xb_aixinli_delete_record_btn') || $(e.target).closest('.xb_aixinli_delete_record_btn').length) {
            return;
        }
        
        const recordId = $(this).data('id');
        if (recordId) {
            isFirstTimeAnalysis = false; // 标记为历史记录查看
            
            // 显示右侧面板
            showAnalysisPanel();
            
            if (xb_aixinli_ajax.is_logged_in == 1) {
                // 登录用户从服务器加载
                loadHistoryRecord(recordId);
            } else {
                // 游客从本地存储加载
                loadGuestHistoryRecord(recordId);
            }
        }
    });

    // 删除记录按钮点击事件
    $(document).on('click', '.xb_aixinli_delete_record_btn', function(e) {
        e.stopPropagation();
        const recordId = $(this).data('id');
        
        xb_aixinli_show_confirm('确认删除', '您确定要删除这条分析记录吗？删除后无法恢复。', function() {
            if (xb_aixinli_ajax.is_logged_in == 1) {
                // 登录用户删除服务器记录
                deleteServerRecord(recordId);
            } else {
                // 游客删除本地记录
                deleteGuestRecord(recordId);
                // 游客删除记录不弹提示框，直接刷新历史记录
                loadGuestHistory();
                
                // 如果当前显示的是被删除的记录，清空结果区域
                if ($('.xb_aixinli_history_item.xb_aixinli_selected').data('id') == recordId) {
                    $('#xb_aixinli_result').empty();
                    $('.xb_aixinli_result_actions').hide();
                    $('.xb_aixinli_main_content').removeClass('analyzing');
                }
            }
        });
    });

    // 加载登录用户历史记录详情
    function loadHistoryRecord(recordId) {
        $.ajax({
            url: xb_aixinli_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_aixinli_get_history_detail',
                record_id: recordId
            },
            success: function(response) {
                if (response.success && response.data.ai_response) {
                    // 历史记录直接显示，不使用打字机效果
                    displayDirectResult(response.data.ai_response);
                    $('.xb_aixinli_result_actions').show();
                    
                    // 滚动到结果区域
                    $('.xb_aixinli_result_section')[0].scrollIntoView({ behavior: 'smooth' });
                    
                    // 更新历史记录选中状态
                    $('.xb_aixinli_history_item').removeClass('xb_aixinli_selected');
                    $(`.xb_aixinli_history_item[data-id="${recordId}"]`).addClass('xb_aixinli_selected');
                } else {
                    xb_aixinli_show_alert(response.data.message || '加载历史记录失败');
                }
            },
            error: function() {
                xb_aixinli_show_alert('加载历史记录失败');
            }
        });
    }
    
    // 加载游客本地历史记录详情
    function loadGuestHistoryRecord(recordId) {
        const records = getGuestRecords();
        const record = records.find(r => r.id == recordId);
        
        if (record && record.ai_response) {
            // 历史记录直接显示，不使用打字机效果
            displayDirectResult(record.ai_response);
            $('.xb_aixinli_result_actions').show();
            
            // 滚动到结果区域
            $('.xb_aixinli_result_section')[0].scrollIntoView({ behavior: 'smooth' });
            
            // 更新历史记录选中状态
            $('.xb_aixinli_history_item').removeClass('xb_aixinli_selected');
            $(`.xb_aixinli_history_item[data-id="${recordId}"]`).addClass('xb_aixinli_selected');
        } else {
            xb_aixinli_show_alert('加载历史记录失败');
        }
    }
    
    // 删除服务器记录
    function deleteServerRecord(recordId) {
        $.ajax({
            url: xb_aixinli_ajax.rest_delete_url,
            type: 'DELETE',
            headers: { 'X-WP-Nonce': xb_aixinli_ajax.nonce },
            data: JSON.stringify({ record_id: recordId }),
            contentType: 'application/json',
            success: function(response) {
                if (response.success) {
                    // 前台用户删除自己记录时不弹提示框，直接重新加载历史记录
                    if (typeof xb_aixinli_load_history === 'function') {
                        xb_aixinli_load_history();
                    }
                    // 如果当前显示的是被删除的记录，清空结果区域
                    if ($('.xb_aixinli_history_item.xb_aixinli_selected').data('id') == recordId) {
                        $('#xb_aixinli_result').empty();
                        $('.xb_aixinli_result_actions').hide();
                        $('.xb_aixinli_main_content').removeClass('analyzing');
                    }
                } else {
                    xb_aixinli_show_alert(response.message || '删除失败');
                }
            },
            error: function(xhr) {
                var message = xhr.responseJSON && xhr.responseJSON.message ? 
                    xhr.responseJSON.message : '删除失败';
                xb_aixinli_show_alert(message);
            }
        });
    }

    // 备用复制方法
    function fallbackCopyText(text, $button, originalText) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
            showCopySuccess($button, originalText);
        } catch (err) {
            $button.html('<span class="xb_aixinli_button_icon">❌</span>复制失败');
            setTimeout(function() {
                $button.html(originalText);
            }, 2000);
        }
        
        document.body.removeChild(textArea);
    }

    // 显示复制成功
    function showCopySuccess($button, originalText) {
        $button.html('<span class="xb_aixinli_button_icon">✅</span>已复制');
        setTimeout(function() {
            $button.html(originalText);
        }, 2000);
    }

    // 下载文件
    function downloadFile(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }

    // 重置表单
    function resetForm() {
        $('#xb_aixinli_form')[0].reset();
        $('.xb_aixinli_char_count').text('0/500');
        // 重新选择第一个人群选项
        $('input[name="crowd_type"]:first').prop('checked', true);
        // 重新加载问题
        const defaultCrowd = $('input[name="crowd_type"]:checked').val();
        if (defaultCrowd) {
            loadQuestionsForCrowd(defaultCrowd);
        }
        currentFormData = null;
        isFirstTimeAnalysis = true; // 重置为首次分析
    }

    // 快速登录处理
    $(document).on('click', '.xb_aixinli_login_btn', function (e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });

    // 防止表单重复提交
    $(document).on('keydown', function(e) {
        if (e.key === 'Enter' && $(e.target).closest('#xb_aixinli_form').length && isAnalyzing) {
            e.preventDefault();
            return false;
        }
    });

    // 页面离开前的提醒
    $(window).on('beforeunload', function() {
        if (isAnalyzing) {
            return '正在分析中，确定要离开吗？';
        }
    });
    
    // 初始化历史记录
    if (xb_aixinli_ajax.is_logged_in == 1) {
        // 登录用户加载服务器历史记录
        if (typeof xb_aixinli_load_history === 'function') {
            xb_aixinli_load_history();
        }
    } else {
        // 游客加载本地历史记录
        loadGuestHistory();
    }
});