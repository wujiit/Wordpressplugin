<?php
/*
Plugin Name: AI心理分析
Description: 基于AI的智能心理分析工具，支持个性化心理问题分析，包含用户次数管理和多种配置选项。
Version: 1.0.0
Author: Summer
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xb_aixinli_activate');
function xb_aixinli_activate() {
    xb_aixinli_create_database();
    xb_aixinli_create_front_page();
    xb_aixinli_upgrade_database();
}

// 数据库升级函数
function xb_aixinli_upgrade_database() {
    global $wpdb;
    $questions_table = $wpdb->prefix . 'xb_aixinli_questions';
    
    // 检查是否需要添加 sort_order 字段
    $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $questions_table LIKE 'sort_order'");
    if (empty($column_exists)) {
        $wpdb->query("ALTER TABLE $questions_table ADD COLUMN sort_order int(11) DEFAULT 0 AFTER crowd_types");
    }
}

// 创建数据库表
function xb_aixinli_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 用户使用次数表
    $usage_table = $wpdb->prefix . 'xb_aixinli_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        device_id varchar(255) NOT NULL,
        usage_date date NOT NULL,
        usage_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_device_date (user_id, device_id, usage_date)
    ) $charset_collate;";

    // 用户记录表
    $records_table = $wpdb->prefix . 'xb_aixinli_records';
    $records_sql = "CREATE TABLE $records_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        device_id varchar(255) NOT NULL,
        crowd_type varchar(50) NOT NULL,
        custom_content text DEFAULT NULL,
        model_name varchar(100) DEFAULT NULL,
        enable_search tinyint(1) DEFAULT 0,
        ai_response longtext DEFAULT NULL,
        status varchar(20) NOT NULL,
        error_message text DEFAULT NULL,
        user_ip varchar(45) DEFAULT NULL,
        user_agent text DEFAULT NULL,
        create_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // 通用问题表
    $questions_table = $wpdb->prefix . 'xb_aixinli_questions';
    $questions_sql = "CREATE TABLE $questions_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        question_text text NOT NULL,
        crowd_types text NOT NULL,
        sort_order int(11) DEFAULT 0,
        is_active tinyint(1) DEFAULT 1,
        create_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($usage_sql);
    dbDelta($records_sql);
    dbDelta($questions_sql);
}

// 创建前台页面
function xb_aixinli_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_aixinli_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => 'AI心理自动分析',
            'post_content' => '[xb_aixinli_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 生成设备指纹
function xb_aixinli_generate_device_id() {
    $user_agent = !empty($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : 'Unknown';
    $ip_address = !empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : 'Unknown';
    $accept_language = !empty($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? sanitize_text_field($_SERVER['HTTP_ACCEPT_LANGUAGE']) : 'Unknown';
    $raw_string = $user_agent . $ip_address . $accept_language;
    return hash('sha256', $raw_string);
}

// 获取设备ID（优先从Cookie获取，失效则生成新的）
function xb_aixinli_get_device_id() {
    $cookie_name = 'xb_aixinli_device_id';
    $device_id = isset($_COOKIE[$cookie_name]) ? sanitize_text_field($_COOKIE[$cookie_name]) : null;

    if (!$device_id) {
        $device_id = xb_aixinli_generate_device_id();
        // 设置365天有效期的Cookie
        setcookie($cookie_name, $device_id, time() + (365 * 24 * 60 * 60), '/');
    }

    return $device_id;
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_aixinli_enqueue_scripts');
function xb_aixinli_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_aixinli_form')) {
        wp_enqueue_style('xb_aixinli_styles', plugins_url('xb-aixinli.css', __FILE__), array(), '1.0.0');
        wp_enqueue_script('xb_aixinli_scripts', plugins_url('xb-aixinli.js', __FILE__), array('jquery'), '1.0.0', true);
        wp_enqueue_script('html2canvas', 'https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js', array(), '1.4.1', true);
        
        // 添加Markdown渲染库
        wp_enqueue_script('marked', 'https://cdn.jsdelivr.net/npm/marked@9.1.6/marked.min.js', array(), '9.1.6', true);

        wp_localize_script('xb_aixinli_scripts', 'xb_aixinli_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => rest_url('xb_aixinli/v1/analyze'),
            'rest_delete_url' => rest_url('xb_aixinli/v1/delete-record'),
            'nonce'    => wp_create_nonce('wp_rest'),
            'login_url' => wp_login_url(get_permalink()),
            'is_logged_in' => is_user_logged_in() ? 1 : 0,
        ));
    }
}

// 短代码
add_shortcode('xb_aixinli_form', 'xb_aixinli_form_shortcode');
function xb_aixinli_form_shortcode() {
    $ad_content = get_option('xb_aixinli_ad_content', '');
    $default_limit = absint(get_option('xb_aixinli_default_limit', 10));
    $guest_limit = absint(get_option('xb_aixinli_guest_limit', 5));
    $show_stats = get_option('xb_aixinli_show_stats', 1);
    $guest_enabled = get_option('xb_aixinli_guest_enabled', 1);
    $enable_model_selection = get_option('xb_aixinli_enable_model_selection', 0);
    $enable_search = get_option('xb_aixinli_enable_search', 0);
    $crowd_options = get_option('xb_aixinli_crowd_options', '学生,职场工作者,自由职业者,退休人员');
    $models = array_filter(array_map('trim', explode(',', get_option('xb_aixinli_models', 'qwen-plus'))));

    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $today = current_time('Y-m-d');
    $device_id = xb_aixinli_get_device_id();

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aixinli_usage';

    // 已登录用户按 user_id 和日期查询，忽略设备信息
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
                $user_id, $today
            )
        );
    } else {
        // 游客按 user_id、device_id 和日期查询
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND device_id = %s AND usage_date = %s",
                $user_id, $device_id, $today
            )
        );
    }

    $usage_count = $row ? absint($row->usage_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : ($user_id ? $default_limit : $guest_limit);
    $remaining = max(0, $user_limit - $usage_count);
    $stats_text = "今日剩余分析次数：{$remaining}/{$user_limit}";

    // 判断是否显示分析区域
    $show_form = true;
    $disable_reason = '';

    if (!is_user_logged_in() && !$guest_enabled) {
        $show_form = false;
        $disable_reason = 'guest_disabled';
    } elseif (!is_user_logged_in() && $usage_count >= $user_limit) {
        $show_form = false;
        $disable_reason = 'guest_limit_exceeded';
    } elseif (is_user_logged_in() && $usage_count >= $user_limit) {
        $show_form = false;
        $disable_reason = 'user_limit_exceeded';
    }

    ob_start();
    ?>
    <div class="xb_aixinli_container">
        <div class="xb_aixinli_header">
            <div class="xb_aixinli_title">AI心理评估分析</div>
            <p class="xb_aixinli_subtitle">智能分析，洞察内心</p>
        </div>

        <div class="xb_aixinli_main_content">
            <div class="xb_aixinli_left_panel">
                <div class="xb_aixinli_form_section">
                <div class="xb_aixinli_section_title">✨ 心理分析配置</div>
                
                <?php if (!$show_form) { ?>
                    <div class="xb_aixinli_message xb_aixinli_message_info">
                        <?php if ($disable_reason === 'guest_disabled') { ?>
                            <div class="xb_aixinli_message_icon">🚫</div>
                            <div class="xb_aixinli_message_content">
                                <div class="xb_aixinli_ts_subtitle">游客功能已关闭</div>
                                <p>管理员已关闭游客使用功能，请登录后继续使用。</p>
                                <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xb_aixinli_login_btn">立即登录</a>
                            </div>
                        <?php } elseif ($disable_reason === 'guest_limit_exceeded') { ?>
                            <div class="xb_aixinli_message_icon">⏰</div>
                            <div class="xb_aixinli_message_content">
                                <div class="xb_aixinli_ts_subtitle">游客的使用次数已经用完，请登录之后继续。</div>
                                <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xb_aixinli_login_btn">立即登录</a>
                            </div>
                        <?php } elseif ($disable_reason === 'user_limit_exceeded') { ?>
                            <div class="xb_aixinli_message_icon">📅</div>
                            <div class="xb_aixinli_message_content">
                                <div class="xb_aixinli_ts_subtitle">今日使用次数已经用完，请明天再来。</div>
                            </div>
                        <?php } ?>
                    </div>
                <?php } else { ?>
                    <form id="xb_aixinli_form" method="post">
                        <!-- 人群选择 -->
                        <div class="xb_aixinli_crowd_section">
                            <label>选择您的身份：</label>
                            <div class="xb_aixinli_crowd_select">
                                <?php 
                                $crowds = array_filter(array_map('trim', explode(',', $crowd_options)));
                                foreach ($crowds as $index => $crowd) { ?>
                                    <div class="xb_aixinli_crowd_option">
                                        <input type="radio" name="crowd_type" value="<?php echo esc_attr($crowd); ?>" <?php echo $index === 0 ? 'checked' : ''; ?> id="crowd_<?php echo $index; ?>">
                                        <label for="crowd_<?php echo $index; ?>"><?php echo esc_html($crowd); ?></label>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>

                        <!-- 问题列表 -->
                        <div id="xb_aixinli_questions_section" class="xb_aixinli_questions_section">
                            <div id="xb_aixinli_questions_list"></div>
                        </div>

                        <!-- 自定义补充内容 -->
                        <div class="xb_aixinli_custom_section">
                            <label for="xb_aixinli_custom_content">补充说明（可选）：</label>
                            <textarea id="xb_aixinli_custom_content" name="custom_content" maxlength="500" rows="4" placeholder="请详细描述您的心理状况或想要分析的问题..." class="xb_aixinli_custom_content"></textarea>
                            <div class="xb_aixinli_char_count">0/500</div>
                        </div>

                        <!-- AI模型和联网搜索 -->
                        <?php if ($enable_model_selection && count($models) > 1 || $enable_search) { ?>
                        <div class="xb_aixinli_advanced_options">
                            <div class="xb_aixinli_advanced_title">高级选项</div>
                            <div class="xb_aixinli_advanced_row">
                                <?php if ($enable_model_selection && count($models) > 1) { ?>
                                <div>
                                    <select id="xb_aixinli_model" name="model" class="xb_aixinli_model_select">
                                        <?php foreach ($models as $model) { ?>
                                            <option value="<?php echo esc_attr($model); ?>"><?php echo esc_html($model); ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <?php } ?>

                                <?php if ($enable_search) { ?>
                                <div class="xb_aixinli_search_option">
                                    <input type="checkbox" id="xb_aixinli_enable_search" name="enable_search" value="1" class="xb_aixinli_search_checkbox">
                                    <label for="xb_aixinli_enable_search">启用联网搜索</label>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <?php } ?>

                        <button type="submit" class="xb_aixinli_submit_button" id="xb_aixinli_submit_button">
                            <span class="xb_aixinli_button_icon">🧠</span>
                            开始分析
                        </button>

                        <?php if (is_user_logged_in()) { ?>
                            <input type="hidden" name="xb_aixinli_nonce" value="<?php echo wp_create_nonce('xb_aixinli_nonce'); ?>">
                        <?php } ?>
                    </form>
                <?php } ?>
                </div>
            </div>
            
            <div class="xb_aixinli_right_panel">
                <div class="xb_aixinli_result_section">
                    <div class="xb_aixinli_section_title">📋 分析结果</div>
                    
                    <div class="xb_aixinli_result_actions" style="display:none;">
                        <button id="xb_aixinli_copy_button" class="xb_aixinli_action_button">
                            <span class="xb_aixinli_button_icon">📋</span>
                            复制结果
                        </button>
                        <button id="xb_aixinli_export_md_button" class="xb_aixinli_action_button">
                            <span class="xb_aixinli_button_icon">📄</span>
                            导出MD
                        </button>
                        <button id="xb_aixinli_export_html_button" class="xb_aixinli_action_button">
                            <span class="xb_aixinli_button_icon">🌐</span>
                            导出HTML
                        </button>
                        <button id="xb_aixinli_export_image_button" class="xb_aixinli_action_button">
                            <span class="xb_aixinli_button_icon">🖼️</span>
                            导出图片
                        </button>
                        <button id="xb_aixinli_clear_button" class="xb_aixinli_action_button">
                            <span class="xb_aixinli_button_icon">🗑️</span>
                            清空内容
                        </button>
                    </div>

                    <div id="xb_aixinli_result"></div>
                    
                    <?php if ($show_stats && $show_form) { ?>
                        <div class="xb_aixinli_usage_info">
                            <span class="xb_aixinli_usage_icon">📊</span>
                            <span id="xb_aixinli_usage_text"><?php echo esc_html($stats_text); ?></span>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>

        <!-- 历史记录 - 占满宽度 -->
        <?php if (is_user_logged_in()) { ?>
            <div class="xb_aixinli_history_section">
                <div class="xb_aixinli_section_title">📚 我的分析记录</div>
                <div id="xb_aixinli_history_list" class="xb_aixinli_history_list"></div>
            </div>
        <?php } ?>
        
        <!-- 公告内容 - 移到总容器内的最下面 -->
        <?php if (!empty($ad_content)) { ?>
            <div class="xb_aixinli_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
        <?php } ?>
    </div>
    
    <!-- 自定义确认对话框 -->
    <div id="xb_aixinli_confirm_modal" class="xb_aixinli_modal" style="display: none;">
        <div class="xb_aixinli_modal_overlay"></div>
        <div class="xb_aixinli_modal_content">
            <div class="xb_aixinli_modal_header">
                <h3 id="xb_aixinli_confirm_title">确认操作</h3>
            </div>
            <div class="xb_aixinli_modal_body">
                <p id="xb_aixinli_confirm_message">您确定要执行此操作吗？</p>
            </div>
            <div class="xb_aixinli_modal_footer">
                <button id="xb_aixinli_confirm_cancel" class="xb_aixinli_modal_btn xb_aixinli_modal_btn_cancel">取消</button>
                <button id="xb_aixinli_confirm_ok" class="xb_aixinli_modal_btn xb_aixinli_modal_btn_confirm">确定</button>
            </div>
        </div>
    </div>
    
    <!-- 自定义提示对话框 -->
    <div id="xb_aixinli_alert_modal" class="xb_aixinli_modal" style="display: none;">
        <div class="xb_aixinli_modal_overlay"></div>
        <div class="xb_aixinli_modal_content">
            <div class="xb_aixinli_modal_header">
                <h3 id="xb_aixinli_alert_title">提示</h3>
            </div>
            <div class="xb_aixinli_modal_body">
                <p id="xb_aixinli_alert_message">操作完成</p>
            </div>
            <div class="xb_aixinli_modal_footer">
                <button id="xb_aixinli_alert_ok" class="xb_aixinli_modal_btn xb_aixinli_modal_btn_confirm">确定</button>
            </div>
        </div>
    </div>

    <script type="text/javascript">
    // 获取问题列表
    function xb_aixinli_load_questions(crowd_type) {
        jQuery.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'xb_aixinli_get_questions',
                crowd_type: crowd_type
            },
            success: function(response) {
                if (response.success) {
                    jQuery('#xb_aixinli_questions_list').html(response.data.html);
                } else {
                    jQuery('#xb_aixinli_questions_list').html('<p>暂无相关问题</p>');
                }
            }
        });
    }

    // 页面加载时获取默认问题
    jQuery(document).ready(function($) {
        var defaultCrowd = $('input[name="crowd_type"]:checked').val();
        if (defaultCrowd) {
            xb_aixinli_load_questions(defaultCrowd);
        }

        // 人群选择变化时更新问题
        $('input[name="crowd_type"]').on('change', function() {
            xb_aixinli_load_questions($(this).val());
        });

        // 加载历史记录
        <?php if (is_user_logged_in()) { ?>
        xb_aixinli_load_history();
        <?php } ?>
        
        // 历史记录点击事件
        $(document).on('click', '.xb_aixinli_history_item', function(e) {
            // 如果点击的是删除按钮，不执行查看记录
            if ($(e.target).hasClass('xb_aixinli_delete_record_btn') || $(e.target).closest('.xb_aixinli_delete_record_btn').length) {
                return;
            }
            
            var recordId = $(this).data('id');
            
            // 通过AJAX获取完整的历史记录内容
            jQuery.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'xb_aixinli_get_history_detail',
                    record_id: recordId
                },
                success: function(response) {
                    if (response.success && response.data.ai_response) {
                        // 使用Markdown渲染器渲染内容
                        var renderedContent = '';
                        if (typeof marked !== 'undefined') {
                            renderedContent = marked.parse(response.data.ai_response);
                        } else {
                            renderedContent = response.data.ai_response.replace(/ /g, '<br>');
                        }
                        
                        // 显示历史记录内容到结果区域
                        $('#xb_aixinli_result').html('<div class="xb_aixinli_result_content">' + renderedContent + '</div>');
                        $('.xb_aixinli_result_actions').show();
                        
                        // 滚动到结果区域
                        $('.xb_aixinli_result_section')[0].scrollIntoView({ behavior: 'smooth' });
                        
                        // 高亮选中的记录
                        $('.xb_aixinli_history_item').removeClass('xb_aixinli_selected');
                        $('[data-id="' + recordId + '"]').addClass('xb_aixinli_selected');
                    } else {
                        xb_aixinli_show_alert('加载记录失败');
                    }
                },
                error: function() {
                    xb_aixinli_show_alert('加载记录失败');
                }
            });
        });
        
        // 删除记录按钮点击事件
        $(document).on('click', '.xb_aixinli_delete_record_btn', function(e) {
            e.stopPropagation();
            var recordId = $(this).data('id');
            
            xb_aixinli_show_confirm('确认删除', '您确定要删除这条分析记录吗？删除后无法恢复。', function() {
                // 发送删除请求
                jQuery.ajax({
                    url: '<?php echo rest_url('xb_aixinli/v1/delete-record'); ?>',
                    type: 'DELETE',
                    headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                    data: JSON.stringify({ record_id: recordId }),
                    contentType: 'application/json',
                    success: function(response) {
                        if (response.success) {
                            // 前台用户删除自己记录时不弹提示框，直接重新加载历史记录
                            xb_aixinli_load_history();
                            // 如果当前显示的是被删除的记录，清空结果区域
                            if ($('.xb_aixinli_history_item.xb_aixinli_selected').data('id') == recordId) {
                                $('#xb_aixinli_result').empty();
                                $('.xb_aixinli_result_actions').hide();
                            }
                        } else {
                            xb_aixinli_show_alert(response.message || '删除失败');
                        }
                    },
                    error: function(xhr) {
                        var message = xhr.responseJSON && xhr.responseJSON.message ? 
                            xhr.responseJSON.message : '删除失败';
                        xb_aixinli_show_alert(message);
                    }
                });
            });
        });
    });
    
    // 加载历史记录函数
    function xb_aixinli_load_history() {
        jQuery.ajax({
            url: '<?php echo rest_url('xb_aixinli/v1/history'); ?>',
            type: 'GET',
            headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
            success: function(response) {
                if (response && response.length > 0) {
                    var html = '';
                    response.forEach(function(record) {
                        html += '<div class="xb_aixinli_history_item" data-id="' + record.id + '">';
                        html += '<button class="xb_aixinli_delete_record_btn" data-id="' + record.id + '" title="删除记录">×</button>';
                        html += '<div class="xb_aixinli_history_date">' + record.create_time + '</div>';
                        html += '<div class="xb_aixinli_history_preview">' + (record.custom_content || '心理分析记录').substring(0, 50) + '...</div>';
                        html += '<div class="xb_aixinli_history_crowd">' + (record.crowd_type || '未知') + '</div>';
                        html += '</div>';
                    });
                    jQuery('#xb_aixinli_history_list').html(html);
                } else {
                    jQuery('#xb_aixinli_history_list').html('<div class="xb_aixinli_no_history">暂无分析记录</div>');
                }
            },
            error: function() {
                jQuery('#xb_aixinli_history_list').html('<div class="xb_aixinli_no_history">加载记录失败</div>');
            }
        });
    }
    
    // 自定义确认对话框
    function xb_aixinli_show_confirm(title, message, onConfirm) {
        $('#xb_aixinli_confirm_title').text(title);
        $('#xb_aixinli_confirm_message').text(message);
        $('#xb_aixinli_confirm_modal').show();
        
        // 绑定确认按钮事件
        $('#xb_aixinli_confirm_ok').off('click').on('click', function() {
            $('#xb_aixinli_confirm_modal').hide();
            if (typeof onConfirm === 'function') {
                onConfirm();
            }
        });
        
        // 绑定取消按钮事件
        $('#xb_aixinli_confirm_cancel').off('click').on('click', function() {
            $('#xb_aixinli_confirm_modal').hide();
        });
        
        // 点击遮罩层关闭
        $('.xb_aixinli_modal_overlay').off('click').on('click', function() {
            $('#xb_aixinli_confirm_modal').hide();
        });
    }
    
    // 自定义提示对话框
    function xb_aixinli_show_alert(message, title) {
        $('#xb_aixinli_alert_title').text(title || '提示');
        $('#xb_aixinli_alert_message').text(message);
        $('#xb_aixinli_alert_modal').show();
        
        // 绑定确定按钮事件
        $('#xb_aixinli_alert_ok').off('click').on('click', function() {
            $('#xb_aixinli_alert_modal').hide();
        });
        
        // 点击遮罩层关闭
        $('.xb_aixinli_modal_overlay').off('click').on('click', function() {
            $('#xb_aixinli_alert_modal').hide();
        });
    }
    </script>
    <?php
    return ob_get_clean();
}

// 获取问题列表 AJAX
add_action('wp_ajax_xb_aixinli_get_questions', 'xb_aixinli_get_questions');
add_action('wp_ajax_nopriv_xb_aixinli_get_questions', 'xb_aixinli_get_questions');
function xb_aixinli_get_questions() {
    $crowd_type = sanitize_text_field($_POST['crowd_type']);
    
    global $wpdb;
    $questions_table = $wpdb->prefix . 'xb_aixinli_questions';
    
    $questions = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM $questions_table WHERE is_active = 1 AND FIND_IN_SET(%s, crowd_types) ORDER BY sort_order DESC, id ASC",
            $crowd_type
        )
    );
    
    $html = '';
    if (!empty($questions)) {
        foreach ($questions as $question) {
            $html .= '<div class="xb_aixinli_question_item">';
            $html .= '<div class="xb_aixinli_question_text">' . esc_html($question->question_text) . '</div>';
            $html .= '<textarea name="question_answers[]" placeholder="请回答这个问题..." rows="2" class="xb_aixinli_question_answer"></textarea>';
            $html .= '<input type="hidden" name="question_ids[]" value="' . esc_attr($question->id) . '">';
            $html .= '</div>';
        }
    } else {
        $html = '<p class="xb_aixinli_no_questions">暂无相关问题，请在补充说明中详细描述您的情况。</p>';
    }
    
    wp_send_json_success(array('html' => $html));
}

// 注册 REST API 端点
add_action('rest_api_init', 'xb_aixinli_register_rest_routes');
function xb_aixinli_register_rest_routes() {
    register_rest_route('xb_aixinli/v1', '/analyze', array(
        'methods' => 'POST',
        'callback' => 'xb_aixinli_handle_logged_analyze',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ));
    
    register_rest_route('xb_aixinli/v1', '/history', array(
        'methods' => 'GET',
        'callback' => 'xb_aixinli_get_user_history',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ));
    
    register_rest_route('xb_aixinli/v1', '/delete-record', array(
        'methods' => 'DELETE',
        'callback' => 'xb_aixinli_delete_user_record',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ));
}

// 处理登录用户分析
function xb_aixinli_handle_logged_analyze(WP_REST_Request $request) {
    $data = json_decode($request->get_body(), true);
    
    // 验证必填字段
    if (empty($data['crowd_type'])) {
        return new WP_REST_Response(array('message' => '请选择您的身份'), 400);
    }

    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $device_id = xb_aixinli_get_device_id();

    // 检查使用次数
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aixinli_usage';
    $default_limit = absint(get_option('xb_aixinli_default_limit', 10));
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
            $user_id, $today
        )
    );
    $usage_count = $row ? absint($row->usage_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;

    if ($usage_count >= $user_limit) {
        return new WP_REST_Response(array('message' => '今日使用次数已经用完，请明天再来。'), 403);
    }

    // 检查违规词
    $forbidden_words = get_option('xb_aixinli_forbidden_words', '');
    if (!empty($forbidden_words) && !empty($data['custom_content'])) {
        $words = array_filter(array_map('trim', explode(',', $forbidden_words)));
        foreach ($words as $word) {
            if (stripos($data['custom_content'], $word) !== false) {
                return new WP_REST_Response(array('message' => '输入内容包含违规词，请重新输入'), 400);
            }
        }
    }

    $result = xb_aixinli_call_api($data, $user_id, $device_id, $today);
    return new WP_REST_Response($result, $result['success'] ? 200 : 400);
}

// 获取用户历史记录
function xb_aixinli_get_user_history(WP_REST_Request $request) {
    $user_id = get_current_user_id();
    
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aixinli_records';
    
    $records = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT id, crowd_type, custom_content, create_time, status 
             FROM $records_table 
             WHERE user_id = %d AND status = 'success' 
             ORDER BY create_time DESC 
             LIMIT 20",
            $user_id
        )
    );
    
    return $records;
}

// 删除用户记录
function xb_aixinli_delete_user_record(WP_REST_Request $request) {
    $data = json_decode($request->get_body(), true);
    $record_id = isset($data['record_id']) ? absint($data['record_id']) : 0;
    
    if (!$record_id) {
        return new WP_REST_Response(array('success' => false, 'message' => '记录ID无效'), 400);
    }
    
    $user_id = get_current_user_id();
    
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aixinli_records';
    
    // 验证记录是否属于当前用户
    $record = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id FROM $records_table WHERE id = %d AND user_id = %d",
            $record_id, $user_id
        )
    );
    
    if (!$record) {
        return new WP_REST_Response(array('success' => false, 'message' => '记录不存在或无权限删除'), 403);
    }
    
    // 删除记录
    $deleted = $wpdb->delete(
        $records_table,
        array('id' => $record_id, 'user_id' => $user_id),
        array('%d', '%d')
    );
    
    if ($deleted) {
        return new WP_REST_Response(array('success' => true, 'message' => '删除成功'));
    } else {
        return new WP_REST_Response(array('success' => false, 'message' => '删除失败'), 500);
    }
}

// 获取历史记录详情
add_action('wp_ajax_xb_aixinli_get_history_detail', 'xb_aixinli_get_history_detail');
function xb_aixinli_get_history_detail() {
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => '请先登录'));
    }

    $record_id = isset($_POST['record_id']) ? absint($_POST['record_id']) : 0;
    if (!$record_id) {
        wp_send_json_error(array('message' => '记录ID无效'));
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aixinli_records';
    
    $record = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM $records_table WHERE id = %d AND user_id = %d",
            $record_id, get_current_user_id()
        )
    );

    if (!$record) {
        wp_send_json_error(array('message' => '记录不存在'));
    }

    wp_send_json_success(array(
        'ai_response' => $record->ai_response,
        'crowd_type' => $record->crowd_type,
        'custom_content' => $record->custom_content,
        'create_time' => $record->create_time
    ));
}

// 处理游客分析
add_action('wp_ajax_nopriv_xb_aixinli_guest_analyze', 'xb_aixinli_handle_guest_analyze');
function xb_aixinli_handle_guest_analyze() {
    // 验证必填字段
    if (empty($_POST['crowd_type'])) {
        wp_send_json_error(array('message' => '请选择您的身份'));
    }

    // 检查游客是否允许使用
    $guest_enabled = get_option('xb_aixinli_guest_enabled', 1);
    if (!$guest_enabled) {
        wp_send_json_error(array('message' => '游客功能已关闭，请登录后使用'));
    }

    $user_id = 0;
    $today = current_time('Y-m-d');
    $device_id = xb_aixinli_get_device_id();

    // 检查游客使用次数
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aixinli_usage';
    $guest_limit = absint(get_option('xb_aixinli_guest_limit', 5));
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND device_id = %s AND usage_date = %s",
            $user_id, $device_id, $today
        )
    );

    $usage_count = $row ? absint($row->usage_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $guest_limit;

    if ($usage_count >= $user_limit) {
        wp_send_json_error(array('message' => '游客的使用次数已经用完，请登录之后继续。'));
    }

    // 检查违规词
    $forbidden_words = get_option('xb_aixinli_forbidden_words', '');
    if (!empty($forbidden_words) && !empty($_POST['custom_content'])) {
        $words = array_filter(array_map('trim', explode(',', $forbidden_words)));
        foreach ($words as $word) {
            if (stripos($_POST['custom_content'], $word) !== false) {
                wp_send_json_error(array('message' => '输入内容包含违规词，请重新输入'));
            }
        }
    }

    $data = array(
        'crowd_type' => sanitize_text_field($_POST['crowd_type']),
        'custom_content' => sanitize_textarea_field($_POST['custom_content']),
        'question_answers' => isset($_POST['question_answers']) ? array_map('sanitize_textarea_field', $_POST['question_answers']) : array(),
        'question_ids' => isset($_POST['question_ids']) ? array_map('absint', $_POST['question_ids']) : array(),
        'model' => sanitize_text_field($_POST['model']),
        'enable_search' => isset($_POST['enable_search']) ? 1 : 0,
    );

    $result = xb_aixinli_call_api($data, $user_id, $device_id, $today);
    
    if ($result['success']) {
        wp_send_json_success($result);
    } else {
        wp_send_json_error($result);
    }
}

// API 调用
function xb_aixinli_call_api($data, $user_id, $device_id, $today) {
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aixinli_records';
    $questions_table = $wpdb->prefix . 'xb_aixinli_questions';

    $api_url = get_option('xb_aixinli_api_url', 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions');
    $api_key = get_option('xb_aixinli_api_key', '');
    $models = array_filter(array_map('trim', explode(',', get_option('xb_aixinli_models', 'qwen-plus'))));
    $model = !empty($data['model']) ? $data['model'] : $models[0];

    // 调试日志
    error_log('XB_AIXINLI_DEBUG: API调用开始');
    error_log('XB_AIXINLI_DEBUG: API URL: ' . $api_url);
    error_log('XB_AIXINLI_DEBUG: Model: ' . $model);
    error_log('XB_AIXINLI_DEBUG: API Key存在: ' . (!empty($api_key) ? '是' : '否'));

    if (empty($api_key)) {
        error_log('XB_AIXINLI_DEBUG: API Key为空');
        return array('success' => false, 'message' => '暂时无法分析请联系客服');
    }

    // 构建提示词 - 优化版本，增加表情和活跃度
    $prompt = "你是一个专业且温暖的心理分析师 😊。现在需要对用户进行心理分析，请严格按照以下要求：

基本信息：
- 用户身份：{$data['crowd_type']}

";

    // 添加问题和回答
    if (!empty($data['question_answers']) && !empty($data['question_ids'])) {
        $prompt .= "用户回答的问题：
";
        foreach ($data['question_ids'] as $index => $question_id) {
            if (!empty($data['question_answers'][$index])) {
                $question = $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT question_text FROM $questions_table WHERE id = %d",
                        $question_id
                    )
                );
                if ($question) {
                    $prompt .= "问题：{$question}
";
                    $prompt .= "回答：{$data['question_answers'][$index]}

";
                }
            }
        }
    }

    if (!empty($data['custom_content'])) {
        $prompt .= "用户补充说明：
{$data['custom_content']}

";
    }

    $prompt .= "
请根据以上信息进行专业的心理分析，包括：
1. 心理状态评估 💭
2. 可能存在的问题分析 🔍
3. 建议和改善方法 💡
4. 注意事项 ⚠️

请用温和、专业且富有同理心的语言回复 😌，适当使用表情符号让回复更加生动活泼 ✨，给出具体可行的建议。回复应该有条理、易懂，帮助用户更好地了解自己的心理状况 🌟。记住要保持积极正面的态度，给用户带来希望和力量 💪！";

    // 构建请求数据
    $request_data = array(
        'model' => $model,
        'messages' => array(
            array(
                'role' => 'system',
                'content' => '你是一个专业的心理分析师，擅长根据用户描述进行心理状态分析并给出专业建议。你的回复要温暖、有同理心，适当使用表情符号让交流更加生动友好。'
            ),
            array(
                'role' => 'user',
                'content' => $prompt
            )
        ),
        'stream' => false,
        'temperature' => 0.7
    );

    // 如果启用联网搜索
    if (!empty($data['enable_search'])) {
        $request_data['enable_search'] = true;
    }

    // 记录到数据库
    $insert_data = array(
        'user_id' => $user_id,
        'device_id' => $device_id,
        'crowd_type' => $data['crowd_type'],
        'custom_content' => $data['custom_content'],
        'model_name' => $model,
        'enable_search' => !empty($data['enable_search']) ? 1 : 0,
        'status' => 'pending',
        'user_ip' => !empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '',
        'user_agent' => !empty($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '',
        'create_time' => current_time('mysql'),
    );

    $args = array(
        'method' => 'POST',
        'timeout' => 60,
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json',
        ),
        'body' => json_encode($request_data),
    );

    // 调试日志
    error_log('XB_AIXINLI_DEBUG: 请求数据: ' . json_encode($request_data, JSON_UNESCAPED_UNICODE));

    $response = wp_remote_request($api_url, $args);
    
    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        error_log('XB_AIXINLI_DEBUG: WP错误: ' . $error_message);
        $insert_data['status'] = 'failed';
        $insert_data['error_message'] = $error_message;
        $wpdb->insert($records_table, $insert_data);
        return array('success' => false, 'message' => '暂时无法分析请联系客服');
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);

    error_log('XB_AIXINLI_DEBUG: HTTP状态码: ' . $status_code);
    error_log('XB_AIXINLI_DEBUG: 响应内容: ' . substr($body, 0, 500) . '...');

    if ($status_code >= 400) {
        error_log('XB_AIXINLI_DEBUG: HTTP错误 ' . $status_code . ': ' . $body);
        $insert_data['status'] = 'failed';
        $insert_data['error_message'] = 'HTTP ' . $status_code . ': ' . $body;
        $wpdb->insert($records_table, $insert_data);
        return array('success' => false, 'message' => '暂时无法分析请联系客服');
    }

    // 解析响应
    $response_data = json_decode($body, true);
    $content = '';
    
    if (isset($response_data['choices'][0]['message']['content'])) {
        $content = $response_data['choices'][0]['message']['content'];
    }

    if (empty($content)) {
        $insert_data['status'] = 'failed';
        $insert_data['error_message'] = '接口返回空内容';
        $wpdb->insert($records_table, $insert_data);
        return array('success' => false, 'message' => '暂时无法分析请联系客服');
    }

    // 成功，更新使用次数
    $usage_table = $wpdb->prefix . 'xb_aixinli_usage';
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
                $user_id, $today
            )
        );
        $usage_count = $row ? absint($row->usage_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : absint(get_option('xb_aixinli_default_limit', 10));

        $existing_row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id FROM $usage_table WHERE user_id = %d AND device_id = %s AND usage_date = %s LIMIT 1",
                $user_id, $device_id, $today
            )
        );
        if ($existing_row) {
            $wpdb->update(
                $usage_table,
                array('usage_count' => $usage_count + 1),
                array('id' => $existing_row->id),
                array('%d'),
                array('%d')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'device_id' => $device_id,
                    'usage_date' => $today,
                    'usage_count' => 1,
                    'custom_limit' => null,
                )
            );
        }
    } else {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND device_id = %s AND usage_date = %s",
                $user_id, $device_id, $today
            )
        );
        $usage_count = $row ? absint($row->usage_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : absint(get_option('xb_aixinli_guest_limit', 5));

        if ($usage_count > 0) {
            $wpdb->update(
                $usage_table,
                array('usage_count' => $usage_count + 1),
                array('user_id' => $user_id, 'device_id' => $device_id, 'usage_date' => $today),
                array('%d'),
                array('%d', '%s', '%s')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'device_id' => $device_id,
                    'usage_date' => $today,
                    'usage_count' => 1,
                    'custom_limit' => null,
                )
            );
        }
    }

    $insert_data['status'] = 'success';
    $insert_data['ai_response'] = $content;
    $wpdb->insert($records_table, $insert_data);

    $remaining = $user_limit - ($usage_count + 1);
    
    return array(
        'success' => true,
        'content' => $content,
        'remaining' => $remaining,
        'limit' => $user_limit
    );
}

// 包含管理功能
if (is_admin()) {
    require_once(plugin_dir_path(__FILE__) . 'xb-aixinli-admin.php');
}
?>