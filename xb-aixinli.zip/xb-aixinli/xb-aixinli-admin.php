<?php
// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 添加管理菜单
add_action('admin_menu', 'xb_aixinli_admin_menu');
function xb_aixinli_admin_menu() {
    add_menu_page(
        'AI心理分析设置',
        'AI心理分析',
        'manage_options',
        'xb_aixinli_settings',
        'xb_aixinli_settings_page',
        'dashicons-admin-users',
        80
    );
    add_submenu_page(
        'xb_aixinli_settings',
        '用户记录',
        '用户记录',
        'manage_options',
        'xb_aixinli_records',
        'xb_aixinli_records_page'
    );
    add_submenu_page(
        'xb_aixinli_settings',
        '问题管理',
        '问题管理',
        'manage_options',
        'xb_aixinli_questions',
        'xb_aixinli_questions_page'
    );
}

// 插件设置页面
function xb_aixinli_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['xb_aixinli_save_settings'])) {
        check_admin_referer('xb_aixinli_settings_nonce');
        
        update_option('xb_aixinli_api_url', sanitize_text_field($_POST['xb_aixinli_api_url']));
        update_option('xb_aixinli_api_key', sanitize_text_field($_POST['xb_aixinli_api_key']));
        update_option('xb_aixinli_models', sanitize_text_field($_POST['xb_aixinli_models']));
        update_option('xb_aixinli_default_limit', absint($_POST['xb_aixinli_default_limit']));
        update_option('xb_aixinli_guest_limit', absint($_POST['xb_aixinli_guest_limit']));
        update_option('xb_aixinli_show_stats', isset($_POST['xb_aixinli_show_stats']) ? 1 : 0);
        update_option('xb_aixinli_guest_enabled', isset($_POST['xb_aixinli_guest_enabled']) ? 1 : 0);
        update_option('xb_aixinli_enable_model_selection', isset($_POST['xb_aixinli_enable_model_selection']) ? 1 : 0);
        update_option('xb_aixinli_enable_search', isset($_POST['xb_aixinli_enable_search']) ? 1 : 0);
        update_option('xb_aixinli_forbidden_words', sanitize_text_field($_POST['xb_aixinli_forbidden_words']));
        update_option('xb_aixinli_crowd_options', sanitize_text_field($_POST['xb_aixinli_crowd_options']));
        
        $allowed_html = array(
            'a' => array('href' => array(), 'title' => array(), 'target' => array()),
            'img' => array('src' => array(), 'alt' => array(), 'width' => array(), 'height' => array()),
            'p' => array(),
            'div' => array('class' => array(), 'style' => array()),
            'span' => array('class' => array(), 'style' => array()),
            'strong' => array(),
            'em' => array(),
            'br' => array()
        );
        update_option('xb_aixinli_ad_content', wp_kses($_POST['xb_aixinli_ad_content'], $allowed_html));
        
        echo '<div class="updated xb_aixinli_auto_hide_message"><p>设置已保存！</p></div>';
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aixinli_records';
    $stats = array(
        'total_records' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table"),
        'success_records' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE status = 'success'"),
        'failed_records' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE status = 'failed'"),
        'today_records' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE DATE(create_time) = %s", current_time('Y-m-d')))
    );

    ?>
    <div class="wrap">
        <h1>AI心理分析设置</h1>
        <form method="post">
            <?php wp_nonce_field('xb_aixinli_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_aixinli_api_url">API 接口地址</label></th>
                    <td><input type="text" name="xb_aixinli_api_url" id="xb_aixinli_api_url" value="<?php echo esc_attr(get_option('xb_aixinli_api_url', 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_aixinli_api_key">API 密钥</label></th>
                    <td><input type="text" name="xb_aixinli_api_key" id="xb_aixinli_api_key" value="<?php echo esc_attr(get_option('xb_aixinli_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_aixinli_models">AI模型</label></th>
                    <td>
                        <input type="text" name="xb_aixinli_models" id="xb_aixinli_models" value="<?php echo esc_attr(get_option('xb_aixinli_models', 'qwen-plus')); ?>" class="regular-text">
                        <p class="description">多个模型用英文逗号分隔，如：qwen-plus,qwen-turbo</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aixinli_default_limit">登录用户每日使用次数</label></th>
                    <td><input type="number" name="xb_aixinli_default_limit" id="xb_aixinli_default_limit" value="<?php echo esc_attr(get_option('xb_aixinli_default_limit', 10)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_aixinli_guest_limit">游客每日使用次数</label></th>
                    <td><input type="number" name="xb_aixinli_guest_limit" id="xb_aixinli_guest_limit" value="<?php echo esc_attr(get_option('xb_aixinli_guest_limit', 5)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_aixinli_crowd_options">人群选项</label></th>
                    <td>
                        <input type="text" name="xb_aixinli_crowd_options" id="xb_aixinli_crowd_options" value="<?php echo esc_attr(get_option('xb_aixinli_crowd_options', '学生,职场工作者,自由职业者,退休人员')); ?>" class="regular-text">
                        <p class="description">多个选项用英文逗号分隔，如：学生,职场工作者,自由职业者,退休人员</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aixinli_forbidden_words">违规词设置</label></th>
                    <td>
                        <input type="text" name="xb_aixinli_forbidden_words" id="xb_aixinli_forbidden_words" value="<?php echo esc_attr(get_option('xb_aixinli_forbidden_words')); ?>" class="regular-text">
                        <p class="description">多个违规词用英文逗号分隔</p>
                    </td>
                </tr>
                <tr>
                    <th>功能开关</th>
                    <td>
                        <label><input type="checkbox" name="xb_aixinli_guest_enabled" <?php checked(get_option('xb_aixinli_guest_enabled', 1), 1); ?> value="1"> 允许游客使用</label><br>
                        <label><input type="checkbox" name="xb_aixinli_show_stats" <?php checked(get_option('xb_aixinli_show_stats', 1), 1); ?> value="1"> 显示统计信息</label><br>
                        <label><input type="checkbox" name="xb_aixinli_enable_model_selection" <?php checked(get_option('xb_aixinli_enable_model_selection', 0), 1); ?> value="1"> 启用前台模型选择</label><br>
                        <label><input type="checkbox" name="xb_aixinli_enable_search" <?php checked(get_option('xb_aixinli_enable_search', 0), 1); ?> value="1"> 启用联网搜索功能</label>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aixinli_ad_content">公告内容</label></th>
                    <td>
                        <textarea name="xb_aixinli_ad_content" id="xb_aixinli_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_aixinli_ad_content')); ?></textarea>
                        <p class="description">支持 HTML 格式。</p>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="xb_aixinli_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        
        <div class="xb_aixinli_stats">
            <h3>统计信息</h3>
            <p>总分析次数：<?php echo esc_html($stats['total_records'] ?: 0); ?></p>
            <p>成功分析次数：<?php echo esc_html($stats['success_records'] ?: 0); ?></p>
            <p>失败分析次数：<?php echo esc_html($stats['failed_records'] ?: 0); ?></p>
            <p>今日分析次数：<?php echo esc_html($stats['today_records'] ?: 0); ?></p>
        </div>
    </div>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aixinli_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}

// 用户记录页面
function xb_aixinli_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aixinli_records';
    $usage_table = $wpdb->prefix . 'xb_aixinli_usage';
    $user_id = isset($_POST['xb_aixinli_user_id']) ? absint($_POST['xb_aixinli_user_id']) : '';
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    // 一键删除所有记录
    if (isset($_POST['xb_aixinli_delete_all_records'])) {
        check_admin_referer('xb_aixinli_delete_all_records_nonce');
        $wpdb->query("TRUNCATE TABLE $records_table");
        echo '<div class="updated xb_aixinli_auto_hide_message"><p>所有记录已删除！</p></div>';
    }

    // 删除指定用户记录
    if (isset($_POST['xb_aixinli_delete_user_records']) && $user_id !== '') {
        check_admin_referer('xb_aixinli_delete_user_records_nonce');
        $wpdb->delete($records_table, array('user_id' => $user_id), array('%d'));
        echo '<div class="updated xb_aixinli_auto_hide_message"><p>用户记录已删除！</p></div>';
    }

    // 删除单条记录 - 修复后台删除功能
    if (isset($_POST['xb_aixinli_delete_single_record'])) {
        check_admin_referer('xb_aixinli_delete_single_record_nonce');
        $record_id = isset($_POST['record_id']) ? absint($_POST['record_id']) : 0;
        if ($record_id) {
            $deleted = $wpdb->delete($records_table, array('id' => $record_id), array('%d'));
            if ($deleted) {
                echo '<div class="updated xb_aixinli_auto_hide_message"><p>记录删除成功！</p></div>';
            } else {
                echo '<div class="error xb_aixinli_auto_hide_message"><p>记录删除失败！</p></div>';
            }
        }
    }

    // 设置用户自定义使用次数
    if (isset($_POST['xb_aixinli_set_user_limit']) && $user_id !== '') {
        check_admin_referer('xb_aixinli_set_user_limit_nonce');
        $custom_limit = isset($_POST['xb_aixinli_custom_limit']) ? absint($_POST['xb_aixinli_custom_limit']) : null;
        
        // 获取今天的记录
        $today = current_time('Y-m-d');
        $existing_row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id FROM $usage_table WHERE user_id = %d AND usage_date = %s LIMIT 1",
                $user_id, $today
            )
        );
        
        if ($existing_row) {
            // 更新现有记录
            $wpdb->update(
                $usage_table,
                array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
                array('id' => $existing_row->id),
                array('%d'),
                array('%d')
            );
        } else {
            // 创建新记录
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'device_id' => 'admin_set',
                    'usage_date' => $today,
                    'usage_count' => 0,
                    'custom_limit' => $custom_limit === 0 ? null : $custom_limit,
                )
            );
        }
        
        echo '<div class="updated xb_aixinli_auto_hide_message"><p>用户使用次数限制已设置！</p></div>';
    }

    // 重置用户使用次数
    if (isset($_POST['xb_aixinli_reset_user_usage']) && $user_id !== '') {
        check_admin_referer('xb_aixinli_reset_user_usage_nonce');
        $wpdb->delete($usage_table, array('user_id' => $user_id), array('%d'));
        echo '<div class="updated xb_aixinli_auto_hide_message"><p>用户使用次数已重置！</p></div>';
    }

    $offset = ($paged - 1) * $per_page;
    
    if ($user_id !== '') {
        $query = $wpdb->prepare("SELECT * FROM $records_table WHERE user_id = %d ORDER BY create_time DESC LIMIT %d, %d", $user_id, $offset, $per_page);
        $total_records = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE user_id = %d", $user_id));
    } else {
        $query = $wpdb->prepare("SELECT * FROM $records_table ORDER BY create_time DESC LIMIT %d, %d", $offset, $per_page);
        $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $records_table");
    }
    
    $records = $wpdb->get_results($query);
    $total_pages = ceil($total_records / $per_page);

    ?>
    <div class="wrap">
        <h1>用户记录</h1>
        
        <div style="margin-bottom: 20px;">
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('xb_aixinli_delete_all_records_nonce'); ?>
                <input type="submit" name="xb_aixinli_delete_all_records" class="button-secondary" value="一键删除所有记录" onclick="return confirm('确定删除所有记录吗？');">
            </form>
        </div>

        <form method="post">
            <p>
                <label for="xb_aixinli_user_id">用户 ID（0 表示游客，留空显示所有记录）：</label>
                <input type="number" name="xb_aixinli_user_id" id="xb_aixinli_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <?php if ($user_id !== '') { ?>
            <?php
            // 获取用户当前的使用次数设置
            $today = current_time('Y-m-d');
            $user_usage_row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
                    $user_id, $today
                )
            );
            $current_usage = $user_usage_row ? $user_usage_row->usage_count : 0;
            $current_custom_limit = $user_usage_row && $user_usage_row->custom_limit !== null ? $user_usage_row->custom_limit : null;
            $default_limit = $user_id == 0 ? get_option('xb_aixinli_guest_limit', 5) : get_option('xb_aixinli_default_limit', 10);
            $effective_limit = $current_custom_limit !== null ? $current_custom_limit : $default_limit;
            ?>
            
            <div style="background: #fff; padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid #0073aa;">
                <h3>用户 ID: <?php echo esc_html($user_id == 0 ? '游客' : $user_id); ?> 的使用情况</h3>
                <p><strong>今日已使用：</strong><?php echo esc_html($current_usage); ?> 次</p>
                <p><strong>当前限制：</strong><?php echo esc_html($effective_limit); ?> 次/天 
                    <?php if ($current_custom_limit !== null) { ?>
                        <span style="color: #d63638;">(自定义)</span>
                    <?php } else { ?>
                        <span style="color: #135e96;">(默认)</span>
                    <?php } ?>
                </p>
                
                <form method="post" style="margin-top: 15px;">
                    <?php wp_nonce_field('xb_aixinli_set_user_limit_nonce'); ?>
                    <input type="hidden" name="xb_aixinli_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <label for="xb_aixinli_custom_limit">设置专属使用次数（0表示使用默认值）：</label>
                    <input type="number" name="xb_aixinli_custom_limit" id="xb_aixinli_custom_limit" 
                           value="<?php echo esc_attr($current_custom_limit !== null ? $current_custom_limit : 0); ?>" 
                           min="0" max="999" style="width: 80px;">
                    <input type="submit" name="xb_aixinli_set_user_limit" class="button-primary" value="设置限制">
                </form>
            </div>
            
            <div style="margin-bottom: 20px;">
                <form method="post" style="display:inline;">
                    <?php wp_nonce_field('xb_aixinli_delete_user_records_nonce'); ?>
                    <input type="hidden" name="xb_aixinli_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_aixinli_delete_user_records" class="button-secondary" value="删除当前用户记录" onclick="return confirm('确定删除当前用户所有记录吗？');">
                </form>
                <form method="post" style="display:inline; margin-left: 10px;">
                    <?php wp_nonce_field('xb_aixinli_reset_user_usage_nonce'); ?>
                    <input type="hidden" name="xb_aixinli_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_aixinli_reset_user_usage" class="button-secondary" value="重置使用次数" onclick="return confirm('确定重置当前用户的使用次数吗？');">
                </form>
            </div>
        <?php } ?>

        <table class="widefat">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>用户ID</th>
                    <th>设备ID</th>
                    <th>人群</th>
                    <th>补充内容</th>
                    <th>模型</th>
                    <th>状态</th>
                    <th>创建时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)) { ?>
                    <tr><td colspan="9">暂无记录。</td></tr>
                <?php } else { ?>
                    <?php foreach ($records as $record) { ?>
                        <tr>
                            <td><?php echo esc_html($record->id); ?></td>
                            <td><?php echo esc_html($record->user_id == 0 ? '游客' : $record->user_id); ?></td>
                            <td><?php echo esc_html($record->device_id ?: '-'); ?></td>
                            <td><?php echo esc_html($record->crowd_type ?: '-'); ?></td>
                            <td><?php echo esc_html($record->custom_content ? substr($record->custom_content, 0, 30) . '...' : '-'); ?></td>
                            <td><?php echo esc_html($record->model_name ?: '-'); ?></td>
                            <td><?php echo esc_html($record->status); ?></td>
                            <td><?php echo esc_html($record->create_time); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_aixinli_delete_single_record_nonce'); ?>
                                    <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>">
                                    <input type="submit" name="xb_aixinli_delete_single_record" class="button-secondary" value="删除" onclick="return confirm('确定删除这条记录吗？');">
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aixinli_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}

// 问题管理页面
function xb_aixinli_questions_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $questions_table = $wpdb->prefix . 'xb_aixinli_questions';

    // 添加问题
    if (isset($_POST['xb_aixinli_add_question'])) {
        check_admin_referer('xb_aixinli_add_question_nonce');
        
        $question_text = sanitize_textarea_field($_POST['question_text']);
        $crowd_types = sanitize_text_field($_POST['crowd_types']);
        $sort_order = absint($_POST['sort_order']);
        
        if (!empty($question_text)) {
            $wpdb->insert(
                $questions_table,
                array(
                    'question_text' => $question_text,
                    'crowd_types' => $crowd_types,
                    'sort_order' => $sort_order,
                    'create_time' => current_time('mysql'),
                )
            );
            echo '<div class="updated xb_aixinli_auto_hide_message"><p>问题已添加！</p></div>';
        }
    }

    // 编辑问题
    if (isset($_POST['xb_aixinli_edit_question'])) {
        check_admin_referer('xb_aixinli_edit_question_nonce');
        
        $question_id = absint($_POST['edit_question_id']);
        $question_text = sanitize_textarea_field($_POST['edit_question_text']);
        $crowd_types = sanitize_text_field($_POST['edit_crowd_types']);
        $sort_order = absint($_POST['edit_sort_order']);
        
        if ($question_id && !empty($question_text)) {
            $wpdb->update(
                $questions_table,
                array(
                    'question_text' => $question_text,
                    'crowd_types' => $crowd_types,
                    'sort_order' => $sort_order,
                ),
                array('id' => $question_id),
                array('%s', '%s', '%d'),
                array('%d')
            );
            echo '<div class="updated xb_aixinli_auto_hide_message"><p>问题已更新！</p></div>';
        }
    }

    // 删除问题
    if (isset($_POST['xb_aixinli_delete_question'])) {
        check_admin_referer('xb_aixinli_delete_question_nonce');
        $question_id = absint($_POST['question_id']);
        if ($question_id) {
            $wpdb->delete($questions_table, array('id' => $question_id), array('%d'));
            echo '<div class="updated xb_aixinli_auto_hide_message"><p>问题已删除！</p></div>';
        }
    }

    // 获取所有问题
    $questions = $wpdb->get_results("SELECT * FROM $questions_table ORDER BY sort_order DESC, id DESC");
    $crowd_options = get_option('xb_aixinli_crowd_options', '学生,职场工作者,自由职业者,退休人员');

    ?>
    <div class="wrap">
        <h1>问题管理</h1>
        
        <!-- 添加问题表单 -->
        <div style="background: #fff; padding: 20px; margin-bottom: 20px; border-radius: 5px;">
            <h2>添加新问题</h2>
            <form method="post">
                <?php wp_nonce_field('xb_aixinli_add_question_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="question_text">问题内容</label></th>
                        <td><textarea name="question_text" id="question_text" rows="3" class="large-text" required></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="crowd_types">适用人群</label></th>
                        <td>
                            <input type="text" name="crowd_types" id="crowd_types" value="" class="regular-text">
                            <p class="description">多个人群用英文逗号分隔，如：学生,职场工作者。留空表示适用于所有人群。</p>
                            <p class="description">可选人群：<?php echo esc_html($crowd_options); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="sort_order">排序</label></th>
                        <td>
                            <input type="number" name="sort_order" id="sort_order" value="0" min="0" max="999">
                            <p class="description">数字越大排序越靠前</p>
                        </td>
                    </tr>
                </table>
                <p><input type="submit" name="xb_aixinli_add_question" class="button-primary" value="添加问题"></p>
            </form>
        </div>

        <!-- 问题列表 -->
        <div style="background: #fff; padding: 20px; border-radius: 5px;">
            <h2>问题列表</h2>
            <?php if (empty($questions)) { ?>
                <p>暂无问题。</p>
            <?php } else { ?>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>问题内容</th>
                            <th>适用人群</th>
                            <th>排序</th>
                            <th>创建时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($questions as $question) { ?>
                            <tr>
                                <td><?php echo esc_html($question->id); ?></td>
                                <td><?php echo esc_html($question->question_text); ?></td>
                                <td><?php echo esc_html($question->crowd_types ?: '所有人群'); ?></td>
                                <td><?php echo esc_html($question->sort_order); ?></td>
                                <td><?php echo esc_html($question->create_time); ?></td>
                                <td>
                                    <button type="button" class="button xb_aixinli_edit_question_btn" 
                                            data-id="<?php echo esc_attr($question->id); ?>"
                                            data-text="<?php echo esc_attr($question->question_text); ?>"
                                            data-crowds="<?php echo esc_attr($question->crowd_types); ?>"
                                            data-sort="<?php echo esc_attr($question->sort_order); ?>">
                                        编辑
                                    </button>
                                    <form method="post" style="display:inline;">
                                        <?php wp_nonce_field('xb_aixinli_delete_question_nonce'); ?>
                                        <input type="hidden" name="question_id" value="<?php echo esc_attr($question->id); ?>">
                                        <input type="submit" name="xb_aixinli_delete_question" class="button-secondary" value="删除" onclick="return confirm('确定删除这个问题吗？');">
                                    </form>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            <?php } ?>
        </div>
    </div>

    <!-- 编辑问题模态框 -->
    <div id="xb_aixinli_edit_question_modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:9999;">
        <div style="position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); background:#fff; padding:30px; border-radius:8px; width:90%; max-width:600px; max-height:80%; overflow-y:auto;">
            <h2>编辑问题</h2>
            <form method="post">
                <?php wp_nonce_field('xb_aixinli_edit_question_nonce'); ?>
                <input type="hidden" name="edit_question_id" id="edit_question_id" value="">
                <table class="form-table">
                    <tr>
                        <th><label for="edit_question_text">问题内容</label></th>
                        <td><textarea name="edit_question_text" id="edit_question_text" rows="3" class="large-text" required></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="edit_crowd_types">适用人群</label></th>
                        <td>
                            <input type="text" name="edit_crowd_types" id="edit_crowd_types" value="" class="regular-text">
                            <p class="description">多个人群用英文逗号分隔，留空表示适用于所有人群。</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="edit_sort_order">排序</label></th>
                        <td>
                            <input type="number" name="edit_sort_order" id="edit_sort_order" value="0" min="0" max="999">
                            <p class="description">数字越大排序越靠前</p>
                        </td>
                    </tr>
                </table>
                <p>
                    <input type="submit" name="xb_aixinli_edit_question" class="button-primary" value="保存修改">
                    <button type="button" class="button" onclick="document.getElementById('xb_aixinli_edit_question_modal').style.display='none';">取消</button>
                </p>
            </form>
        </div>
    </div>

    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aixinli_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
        
        // 编辑问题按钮点击事件
        $('.xb_aixinli_edit_question_btn').on('click', function() {
            var id = $(this).data('id');
            var text = $(this).data('text');
            var crowds = $(this).data('crowds');
            var sort = $(this).data('sort');
            
            $('#edit_question_id').val(id);
            $('#edit_question_text').val(text);
            $('#edit_crowd_types').val(crowds);
            $('#edit_sort_order').val(sort);
            
            $('#xb_aixinli_edit_question_modal').show();
        });
        
        // 点击模态框背景关闭
        $('#xb_aixinli_edit_question_modal').on('click', function(e) {
            if (e.target === this) {
                $(this).hide();
            }
        });
    });
    </script>
    <?php
}
?>