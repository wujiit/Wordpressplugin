(function ($) {
    // 初始化日志
    console.log('XBMovieTV Plugin: JavaScript initialized.');

    // 平台按钮点击处理
    $(document).on('click', '.xb_movietv_platform_button', function () {
        console.log('Platform button clicked:', $(this).data('platform'));
        $('.xb_movietv_platform_button').removeClass('active');
        $(this).addClass('active');
    });

    // 生成按钮点击事件
    $(document).on('click', '.xb_movietv_generate_button', function (e) {
        e.preventDefault();
        console.log('Generate button clicked.');

        var $resultContent = $('.xb_movietv_result_content');
        var inputData = $('#xb_movietv_input').val().trim();
        var $generateButton = $(this);

        // 验证输入是否为空
        if (!inputData) {
            console.log('Input data is empty.');
            $resultContent.html('<p class="xb_movietv_error">请输入影视剧名称。</p>');
            return;
        }

        // 前端验证违规词
        var forbiddenWords = XBMovieTVData.forbidden_words || [];
        var foundForbiddenWord = null;
        if (forbiddenWords.length > 0) {
            forbiddenWords.forEach(function (word) {
                // 防御性检查，确保 word 是字符串
                if (typeof word === 'string' && typeof inputData === 'string') {
                    if (inputData.toLowerCase().indexOf(word.toLowerCase()) !== -1) {
                        foundForbiddenWord = word;
                    }
                }
            });
        }

        if (foundForbiddenWord) {
            console.log('Forbidden word detected:', foundForbiddenWord);
            $resultContent.html('<p class="xb_movietv_error">输入内容包含违规词“' + foundForbiddenWord + '”，请重新输入</p>');
            return;
        }

        // 显示加载提示
        $resultContent.html('<span class="loading">正在推荐中...</span>');

        // 验证用户登录状态
        if (!XBMovieTVData.nonce) {
            console.log('Nonce not found, user not logged in.');
            $resultContent.html('<p class="xb_movietv_error">请先登录以使用影视剧推荐助手。</p>');
            return;
        }

        // 构造请求数据，始终包含模型参数
        var data = {
            model: $('#xb_movietv_model').val() || XBMovieTVData.default_model || 'qwen-plus', // 使用用户选择的模型或默认模型
            data: inputData,
            platform: $('.xb_movietv_platform_button.active').data('platform') || '',
            enable_search: $('#xb_movietv_enable_search').is(':checked') // 修正 ID 拼写
        };
        console.log('Sending API request with data:', data);

        // 禁用生成按钮，防止重复提交
        $generateButton.prop('disabled', true);

        // 使用 fetch 发起 API 请求
        fetch(XBMovieTVData.rest_url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': XBMovieTVData.nonce,
                'Accept': 'text/event-stream'
            },
            body: JSON.stringify(data)
        }).then(function (response) {
            if (!response.ok) {
                return response.json().then(function (errorData) {
                    throw new Error(errorData.message || '未知错误');
                });
            }

            console.log('API request successful, processing stream...');
            var reader = response.body.getReader();
            var decoder = new TextDecoder();
            var done = false;
            var hasContent = false;

            function readStream() {
                reader.read().then(function (result) {
                    if (result.done) {
                        done = true;
                        if (hasContent) {
                            console.log('Stream completed, updating usage count.');
                            updateUsageCount();
                        } else {
                            console.log('No content received.');
                            $resultContent.html('<p class="xb_movietv_error">推荐失败，未收到有效内容。</p>');
                        }
                        $generateButton.prop('disabled', false);
                        return;
                    }

                    var chunk = decoder.decode(result.value, { stream: true });
                    var lines = chunk.split('\n');
                    lines.forEach(function (line) {
                        if (line.trim().startsWith('data: ')) {
                            var jsonData = line.trim().substring(6);
                            if (jsonData === '[DONE]') {
                                done = true;
                                if (hasContent) {
                                    console.log('Stream done, updating usage count.');
                                    updateUsageCount();
                                } else {
                                    console.log('No content received at stream end.');
                                    $resultContent.html('<p class="xb_movietv_error">推荐失败，未收到有效内容。</p>');
                                }
                                $generateButton.prop('disabled', false);
                                return;
                            }

                            try {
                                var data = JSON.parse(jsonData);
                                if (data.error) {
                                    console.log('API error:', data.error);
                                    $resultContent.html('<p class="xb_movietv_error">' + data.error + '</p>');
                                    $generateButton.prop('disabled', false);
                                    return;
                                }
                                if ($resultContent.text() === '正在推荐中...') {
                                    $resultContent.empty();
                                }
                                if (data.content) {
                                    hasContent = true;
                                    $resultContent.append(data.content);
                                    console.log('Received content chunk:', data.content);
                                }
                            } catch (e) {
                                console.error('解析流数据出错:', e, ' - 原始数据:', jsonData);
                                $resultContent.html('<p class="xb_movietv_error">生成过程中发生错误，请检查日志。</p>');
                                $generateButton.prop('disabled', false);
                            }
                        }
                    });

                    if (!done) {
                        readStream();
                    }
                }).catch(function (error) {
                    console.error('流读取失败:', error);
                    $resultContent.html('<p class="xb_movietv_error">生成过程中发生错误，请检查日志。</p>');
                    $generateButton.prop('disabled', false);
                });
            }

            readStream();
        }).catch(function (error) {
            console.error('API 请求失败:', error);
            $resultContent.html('<p class="xb_movietv_error">' + error.message + '</p>');
            $generateButton.prop('disabled', false);
        });
    });

    // 一键复制按钮
    $(document).on('click', '.xb_movietv_copy_button', function (e) {
        e.preventDefault();
        console.log('Copy button clicked.');
        var $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val($('.xb_movietv_result_content').text()).select();
        document.execCommand('copy');
        $temp.remove();

        $('.xb_movietv_copy_success').html('<p class="copy-success">复制成功！</p>');
        setTimeout(function () {
            $('.xb_movietv_copy_success').empty();
        }, 2000);
    });

    // 清空按钮
    $(document).on('click', '.xb_movietv_clear_button', function (e) {
        e.preventDefault();
        console.log('Clear button clicked.');
        $('.xb_movietv_result_content').empty();
    });

    // 快速登录按钮
    $(document).on('click', '.xb_movietv_quick_login_button', function (e) {
        e.preventDefault();
        console.log('Quick login button clicked.');
        var $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.click();
        } else {
            window.location.href = '<?php echo esc_url(wp_login_url(get_permalink())); ?>';
        }
    });

    // 更新使用次数
    function updateUsageCount() {
        console.log('Updating usage count via AJAX.');
        $.ajax({
            url: XBMovieTVData.rest_url.replace('/recommend', '/usage'),
            method: 'GET',
            headers: {
                'X-WP-Nonce': XBMovieTVData.nonce
            },
            success: function (response) {
                console.log('Usage count updated:', response);
                var $usageDisplay = $('.xb_movietv_usage');
                var $generateButton = $('.xb_movietv_generate_button');
                if (response.remaining <= 0) {
                    $usageDisplay.text('今日已用完，请明天再来');
                    $generateButton.hide();
                } else {
                    $usageDisplay.text('今日可用次数：' + response.limit + '/' + response.remaining);
                    $generateButton.show();
                }
            },
            error: function (error) {
                console.error('Failed to update usage count:', error);
                $('.xb_movietv_usage').text('今日可用次数：无法加载');
                $('.xb_movietv_generate_button').hide();
            }
        });
    }

    // 联网搜索开关点击处理
    $(document).on('click', '.xb_movietv_search_toggle .slider', function (e) {
        e.preventDefault();
        var $checkbox = $(this).siblings('input[type="checkbox"]');
        $checkbox.prop('checked', !$checkbox.prop('checked'));
        console.log('Search toggle clicked, new state:', $checkbox.prop('checked'));
    });

    // 防止点击文字触发开关
    $(document).on('click', '.xb_movietv_search_toggle', function (e) {
        if (!$(e.target).hasClass('slider')) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Clicked on search toggle label or surrounding area, no toggle action.');
        }
    });

    // 页面加载时获取使用次数
    $(document).ready(function () {
        updateUsageCount();
    });

    // 初始化检查
    console.log('XBMovieTVData:', XBMovieTVData);
})(jQuery);