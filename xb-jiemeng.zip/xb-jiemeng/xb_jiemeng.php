<?php
/*
Plugin Name: 周公解梦
Description: 基于天API的周公解梦插件，仅供娱乐
Version: 1.0.2
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 创建数据表（记录表和计数表分开）
function xb_jiemeng_create_table() {
    global $wpdb;
    $table_name_records = $wpdb->prefix . 'xb_jiemeng_records';
    $table_name_counts = $wpdb->prefix . 'xb_jiemeng_counts';
    $charset_collate = $wpdb->get_charset_collate();

    // 创建记录表
    $sql_records = "CREATE TABLE $table_name_records (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        device_id VARCHAR(255) NOT NULL,
        ip_address VARCHAR(45) NOT NULL,
        input_text VARCHAR(255) NOT NULL,
        error_message TEXT,
        processed_time DATETIME NOT NULL,
        status VARCHAR(50) NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY device_id (device_id)
    ) $charset_collate;";

    // 创建计数表
    $sql_counts = "CREATE TABLE $table_name_counts (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        device_id VARCHAR(255) NOT NULL,
        count_date DATE NOT NULL,
        usage_count INT UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY user_device_date (user_id, device_id, count_date)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_records);
    dbDelta($sql_counts);
}

// 创建前台页面
function xb_jiemeng_create_page() {
    $pages = get_posts([
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_jiemeng_frontend]',
        'numberposts' => 1,
    ]);

    if (empty($pages)) {
        wp_insert_post([
            'post_title'    => '周公解梦',
            'post_content'  => '[xb_jiemeng_frontend]',
            'post_status'   => 'publish',
            'post_type'     => 'page',
        ]);
    }
}

// 加载前端资源
function xb_jiemeng_enqueue_frontend_assets() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_jiemeng_frontend')) {
        wp_enqueue_style('xb-jiemeng-style', plugins_url('xb_jiemeng.css', __FILE__), [], '1.0.2');
        wp_enqueue_script('xb-jiemeng-script', plugins_url('xb_jiemeng.js', __FILE__), ['jquery'], '1.0.2', true);
        
        $is_logged_in = is_user_logged_in();
        
        wp_localize_script('xb-jiemeng-script', 'xb_jiemeng_vars', [
            'ajax_url' => rest_url('xb_jiemeng/v1/'),
            'nonce'    => $is_logged_in ? wp_create_nonce('wp_rest') : '',
            'login_url' => wp_login_url(),
            'max_chars' => (int) get_option('xb_jiemeng_max_chars', 500),
            'is_user_logged_in' => is_user_logged_in() ? 'yes' : 'no'
        ]);
    }
}

// 插件激活
function xb_jiemeng_activate() {
    xb_jiemeng_create_table();
    xb_jiemeng_create_page();
}
register_activation_hook(__FILE__, 'xb_jiemeng_activate');

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_jiemeng_enqueue_frontend_assets');

// 优化：改进设备指纹生成，优先使用 Cookie，失效时回退到基于 user_agent 等生成
function xb_jiemeng_get_device_id() {
    // 检查 Cookie 是否存在
    $device_id = isset($_COOKIE['xb_jiemeng_device_id']) ? sanitize_text_field($_COOKIE['xb_jiemeng_device_id']) : '';

    if (empty($device_id)) {
        // 如果 Cookie 不存在，基于 user_agent、ip_address、accept_language 生成设备指纹
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $accept_language = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
        $headers = [
            'user_agent' => $user_agent,
            'ip_address' => $ip_address,
            'accept_language' => $accept_language,
        ];
        $device_id = md5(json_encode($headers) . wp_salt('nonce')); // 使用 wp_salt 增加安全性
        // 设置 Cookie，365 天有效期，HttpOnly 和 Secure（若 HTTPS）
        setcookie('xb_jiemeng_device_id', $device_id, time() + 365 * DAY_IN_SECONDS, '/', '', is_ssl(), true);
        error_log('XB Jiemeng: Generated and set new device_id in Cookie: ' . $device_id);
    } else {
        error_log('XB Jiemeng: Retrieved device_id from Cookie: ' . $device_id);
    }

    return $device_id;
}

// 优化：改进短代码，使用次数统计支持已登录用户跨设备、游客按设备独立
function xb_jiemeng_frontend_shortcode() {
    ob_start();
    $daily_limit = (int) get_option('xb_jiemeng_daily_limit', 10);
    $guest_limit = (int) get_option('xb_jiemeng_guest_limit', 5);
    $show_stats = get_option('xb_jiemeng_show_stats', 'yes') === 'yes';
    $user_id = get_current_user_id();
    $device_id = xb_jiemeng_get_device_id();
    $max_chars = (int) get_option('xb_jiemeng_max_chars', 500);

    global $wpdb;
    $today = date('Y-m-d');
    $table_name_counts = $wpdb->prefix . 'xb_jiemeng_counts';

    // 已登录用户：按 user_id 汇总所有设备的使用次数
    if ($user_id) {
        $user_limit = get_user_meta($user_id, 'xb_jiemeng_custom_limit', true);
        $limit = $user_limit ? (int) $user_limit : $daily_limit;
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(usage_count) FROM $table_name_counts WHERE user_id = %d AND count_date = %s",
            $user_id, $today
        ));
    } else {
        // 游客：按 device_id 统计
        $limit = $guest_limit;
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT usage_count FROM $table_name_counts WHERE user_id = 0 AND device_id = %s AND count_date = %s",
            $device_id, $today
        ));
    }
    $count = $count ? (int) $count : 0;
    $remaining = max(0, $limit - $count);
    $usage_text = $remaining > 0 ? "今日剩余解梦次数：{$remaining}/{$limit}" : ($user_id ? "今日使用次数已用完，请明天再来" : "游客解梦次数已用尽，请登录后继续使用");
    $show_process_btn = $remaining > 0 ? '' : 'style="display:none;"';
    $show_login_btn = (!$user_id && $remaining <= 0) ? '' : 'style="display:none;"';
    ?>
    <div class="xb-jiemeng-container">
        <div class="xb-jiemeng-custom-title">周公解梦工具</div>
        <div class="xb-jiemeng-input-area">
            <div class="xb-jiemeng-title">输入梦境关键词</div>
            <textarea id="xb-jiemeng-input" maxlength="<?php echo $max_chars; ?>" placeholder="请输入梦境关键词（最多<?php echo $max_chars; ?>字，仅供娱乐）"></textarea>
            <div class="xb-jiemeng-char-count">已输入: <span id="xb-jiemeng-char-count">0</span>/<?php echo $max_chars; ?></div>
            <button id="xb-jiemeng-process-btn" <?php echo $show_process_btn; ?> disabled>开始解梦</button>
            <button id="xb-jiemeng-login-btn" <?php echo $show_login_btn; ?>>快速登录</button>
        </div>
        <div class="xb-jiemeng-result-area">
            <button id="xb-jiemeng-clear-btn">清空结果</button>
            <div class="xb-jiemeng-title">解梦结果</div>
            <div id="xb-jiemeng-result"></div>
        </div>
        <div id="xb-jiemeng-notification"></div>
        <?php if ($show_stats): ?>
            <div class="xb-jiemeng-usage"><?php echo $usage_text; ?></div>
        <?php endif; ?>
        <?php if ($notice = get_option('xb_jiemeng_notice')): ?>
            <div class="xb-jiemeng-notice-content"><?php echo wp_kses_post($notice); ?></div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('xb_jiemeng_frontend', 'xb_jiemeng_frontend_shortcode');

// 新增：获取当前使用情况的 REST API 接口
function xb_jiemeng_register_rest_usage_route() {
    register_rest_route('xb_jiemeng/v1', '/usage', [
        'methods'  => 'GET',
        'callback' => 'xb_jiemeng_get_usage',
        'permission_callback' => function ($request) {
            if (is_user_logged_in()) {
                $nonce = $request->get_header('X-WP-Nonce');
                return wp_verify_nonce($nonce, 'wp_rest');
            }
            return true;
        },
    ]);
}
add_action('rest_api_init', 'xb_jiemeng_register_rest_usage_route');

// 新增：处理使用情况查询
function xb_jiemeng_get_usage($request) {
    $user_id = get_current_user_id();
    $device_id = xb_jiemeng_get_device_id();
    $daily_limit = (int) get_option('xb_jiemeng_daily_limit', 10);
    $guest_limit = (int) get_option('xb_jiemeng_guest_limit', 5);
    $today = date('Y-m-d');

    global $wpdb;
    $table_name_counts = $wpdb->prefix . 'xb_jiemeng_counts';

    // 已登录用户：按 user_id 汇总所有设备的使用次数
    if ($user_id) {
        $user_limit = get_user_meta($user_id, 'xb_jiemeng_custom_limit', true);
        $limit = $user_limit ? (int) $user_limit : $daily_limit;
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(usage_count) FROM $table_name_counts WHERE user_id = %d AND count_date = %s",
            $user_id, $today
        ));
    } else {
        // 游客：按 device_id 统计
        $limit = $guest_limit;
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT usage_count FROM $table_name_counts WHERE user_id = 0 AND device_id = %s AND count_date = %s",
            $device_id, $today
        ));
    }
    $count = $count ? (int) $count : 0;
    $remaining = max(0, $limit - $count);

    // 调试：记录查询结果
    error_log('XB Jiemeng: Usage query - user_id: ' . $user_id . ', device_id: ' . $device_id . ', count: ' . $count . ', limit: ' . $limit);

    return [
        'remaining' => $remaining,
        'limit' => $limit,
        'is_guest' => !$user_id,
        'show_stats' => get_option('xb_jiemeng_show_stats', 'yes') === 'yes'
    ];
}

// REST API 注册
function xb_jiemeng_register_rest_routes() {
    register_rest_route('xb_jiemeng/v1', '/process', [
        'methods'  => 'POST',
        'callback' => 'xb_jiemeng_handle_process',
        'permission_callback' => function ($request) {
            if (is_user_logged_in()) {
                $nonce = $request->get_header('X-WP-Nonce');
                return wp_verify_nonce($nonce, 'wp_rest');
            }
            return true;
        },
    ]);
}
add_action('rest_api_init', 'xb_jiemeng_register_rest_routes');

// 优化：改进解梦请求处理，完善使用次数统计逻辑
function xb_jiemeng_handle_process($request) {
    $text = sanitize_text_field($request['text']);
    $max_chars = (int) get_option('xb_jiemeng_max_chars', 500);
    $text = mb_substr($text, 0, $max_chars, 'UTF-8');
    $user_id = get_current_user_id();
    $device_id = xb_jiemeng_get_device_id();
    $ip = sanitize_text_field($_SERVER['REMOTE_ADDR']);
    $api_key = get_option('xb_jiemeng_api_key');
    $daily_limit = (int) get_option('xb_jiemeng_daily_limit', 10);
    $guest_limit = (int) get_option('xb_jiemeng_guest_limit', 5);

    if (!$api_key) {
        return new WP_Error('no_api_key', '未设置API Key', ['status' => 500]);
    }

    global $wpdb;
    $table_name_records = $wpdb->prefix . 'xb_jiemeng_records';
    $table_name_counts = $wpdb->prefix . 'xb_jiemeng_counts';
    $today = date('Y-m-d');

    // 检查使用次数
    if ($user_id) {
        $user_limit = get_user_meta($user_id, 'xb_jiemeng_custom_limit', true);
        $limit = $user_limit ? (int) $user_limit : $daily_limit;
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(usage_count) FROM $table_name_counts WHERE user_id = %d AND count_date = %s",
            $user_id, $today
        ));
    } else {
        $limit = $guest_limit;
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT usage_count FROM $table_name_counts WHERE user_id = 0 AND device_id = %s AND count_date = %s",
            $device_id, $today
        ));
    }
    $count = $count ? (int) $count : 0;

    // 调试：记录使用次数检查
    error_log('XB Jiemeng: Process - user_id: ' . $user_id . ', device_id: ' . $device_id . ', count: ' . $count . ', limit: ' . $limit);

    if ($count >= $limit) {
        return new WP_Error('limit_exceeded', $user_id ? '今日解梦次数已用尽' : '游客解梦次数已用尽，请登录后继续使用', [
            'status' => 400,
            'remaining' => 0,
            'limit' => $limit,
            'is_guest' => !$user_id
        ]);
    }

    // 调用API
    $url = 'https://apis.tianapi.com/dream/index?key=' . urlencode($api_key) . '&num=10&word=' . urlencode($text);
    $response = wp_remote_get($url, [
        'timeout' => 30,
        'sslverify' => false,
    ]);

    $status = 'error';
    $error_message = '';
    $result = [
        'error' => '暂时无法解梦请联系客服',
        'remaining' => max(0, $limit - ($count + 1)),
        'limit' => $limit,
        'is_guest' => !$user_id
    ];

    if (!is_wp_error($response)) {
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($body['code']) && $body['code'] === 200 && isset($body['result']['list'])) {
            $status = 'success';
            $result = [
                'list' => $body['result']['list'],
                'remaining' => max(0, $limit - ($count + 1)),
                'limit' => $limit,
                'is_guest' => !$user_id
            ];
        } else {
            $error_message = isset($body['msg']) ? $body['msg'] : 'API处理失败';
        }
    } else {
        $error_message = $response->get_error_message();
    }

    // 插入记录
    $wpdb->insert(
        $table_name_records,
        [
            'user_id' => $user_id,
            'device_id' => $device_id,
            'ip_address' => $ip,
            'input_text' => mb_substr($text, 0, 10, 'UTF-8'),
            'error_message' => $error_message,
            'processed_time' => current_time('mysql'),
            'status' => $status
        ],
        ['%d', '%s', '%s', '%s', '%s', '%s', '%s']
    );

    // 更新使用次数
    if ($status === 'success') {
        if ($user_id) {
            // 已登录用户：查找当前 device_id 的记录，如果不存在则插入
            $existing_row = $wpdb->get_row($wpdb->prepare(
                "SELECT id, usage_count FROM $table_name_counts WHERE user_id = %d AND device_id = %s AND count_date = %s",
                $user_id, $device_id, $today
            ));
            if ($existing_row) {
                $wpdb->update(
                    $table_name_counts,
                    ['usage_count' => $existing_row->usage_count + 1],
                    ['id' => $existing_row->id],
                    ['%d'],
                    ['%d']
                );
            } else {
                $wpdb->insert(
                    $table_name_counts,
                    [
                        'user_id' => $user_id,
                        'device_id' => $device_id,
                        'count_date' => $today,
                        'usage_count' => 1
                    ],
                    ['%d', '%s', '%s', '%d']
                );
            }
        } else {
            // 游客：按 device_id 更新
            $wpdb->replace(
                $table_name_counts,
                [
                    'user_id' => 0,
                    'device_id' => $device_id,
                    'count_date' => $today,
                    'usage_count' => $count + 1
                ],
                ['%d', '%s', '%s', '%d']
            );
        }
        // 调试：记录使用次数更新
        error_log('XB Jiemeng: Updated usage_count - user_id: ' . $user_id . ', device_id: ' . $device_id . ', new_count: ' . ($count + 1));
    }

    return $result;
}

// 后台菜单
function xb_jiemeng_admin_menu() {
    add_menu_page('周公解梦设置', '周公解梦', 'manage_options', 'xb-jiemeng-settings', 'xb_jiemeng_settings_page');
    add_submenu_page('xb-jiemeng-settings', '用户解梦记录', '用户记录', 'manage_options', 'xb-jiemeng-records', 'xb_jiemeng_records_page');
}
add_action('admin_menu', 'xb_jiemeng_admin_menu');

// 设置页面
function xb_jiemeng_settings_page() {
    if (isset($_POST['xb_jiemeng_save'])) {
        update_option('xb_jiemeng_api_key', sanitize_text_field($_POST['api_key']));
        update_option('xb_jiemeng_daily_limit', (int) $_POST['daily_limit']);
        update_option('xb_jiemeng_guest_limit', (int) $_POST['guest_limit']);
        update_option('xb_jiemeng_max_chars', (int) $_POST['max_chars']);
        update_option('xb_jiemeng_show_stats', sanitize_text_field($_POST['show_stats']));
        update_option('xb_jiemeng_notice', wp_kses_post($_POST['notice']));
        echo '<div class="updated xb-jiemeng-admin-notice"><p>设置已保存</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>周公解梦设置</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>API Key</th>
                    <td><input type="text" name="api_key" value="<?php echo esc_attr(get_option('xb_jiemeng_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>默认每日使用次数（登录用户）</th>
                    <td><input type="number" name="daily_limit" value="<?php echo esc_attr(get_option('xb_jiemeng_daily_limit', 10)); ?>" min="1" class="small-text"> 次</td>
                </tr>
                <tr>
                    <th>游客每日使用次数</th>
                    <td><input type="number" name="guest_limit" value="<?php echo esc_attr(get_option('xb_jiemeng_guest_limit', 5)); ?>" min="1" class="small-text"> 次</td>
                </tr>
                <tr>
                    <th>最大输入字符数</th>
                    <td><input type="number" name="max_chars" value="<?php echo esc_attr(get_option('xb_jiemeng_max_chars', 500)); ?>" min="100" class="small-text"> 字</td>
                </tr>
                <tr>
                    <th>显示统计信息</th>
                    <td>
                        <select name="show_stats">
                            <option value="yes" <?php selected(get_option('xb_jiemeng_show_stats', 'yes'), 'yes'); ?>>是</option>
                            <option value="no" <?php selected(get_option('xb_jiemeng_show_stats', 'yes'), 'no'); ?>>否</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>公告内容</th>
                    <td><textarea name="notice" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_jiemeng_notice')); ?></textarea></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="xb_jiemeng_save" class="button-primary" value="保存设置"></p>
        </form>
        由天API提供服务：https://apis.tianapi.com/dream/index
    </div>
    <script>
        jQuery(document).ready(function($) {
            setTimeout(function() {
                $('.xb-jiemeng-admin-notice').fadeOut(500);
            }, 3000);
        });
    </script>
    <?php
}

// 优化：改进用户记录页面，支持 device_id 显示和管理
function xb_jiemeng_records_page() {
    global $wpdb;
    $table_name_records = $wpdb->prefix . 'xb_jiemeng_records';
    $table_name_counts = $wpdb->prefix . 'xb_jiemeng_counts';
    $per_page = 20;
    $paged = isset($_GET['paged']) ? (int) $_GET['paged'] : 1;
    $offset = ($paged - 1) * $per_page;
    $user_id_filter = isset($_GET['user_id']) ? (int) $_GET['user_id'] : 0;

    // 删除单条记录
    if (isset($_GET['delete_id'])) {
        $wpdb->delete($table_name_records, ['id' => (int) $_GET['delete_id']], ['%d']);
        echo '<div class="updated xb-jiemeng-admin-notice"><p>记录已删除</p></div>';
    }

    // 删除所有记录
    if (isset($_POST['xb_jiemeng_clear_all'])) {
        $wpdb->query("TRUNCATE TABLE $table_name_records");
        $wpdb->query("TRUNCATE TABLE $table_name_counts"); // 优化：同时清除计数表
        echo '<div class="updated xb-jiemeng-admin-notice"><p>所有记录已删除</p></div>';
    }

    // 删除当前用户记录
    if (isset($_POST['xb_jiemeng_clear_user']) && $user_id_filter) {
        $wpdb->delete($table_name_records, ['user_id' => $user_id_filter], ['%d']);
        $wpdb->delete($table_name_counts, ['user_id' => $user_id_filter], ['%d']); // 优化：同时清除计数表
        echo '<div class="updated xb-jiemeng-admin-notice"><p>用户记录已删除</p></div>';
    }

    // 更新用户每日限制
    if (isset($_POST['xb_jiemeng_user_limit'])) {
        $custom_limit = (int) $_POST['custom_limit'];
        if ($custom_limit > 0) {
            update_user_meta($user_id_filter, 'xb_jiemeng_custom_limit', $custom_limit);
        } else {
            delete_user_meta($user_id_filter, 'xb_jiemeng_custom_limit');
        }
        echo '<div class="updated xb-jiemeng-admin-notice"><p>用户限制已更新</p></div>';
    }

    $where = $user_id_filter ? $wpdb->prepare('WHERE user_id = %d', $user_id_filter) : '';
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name_records $where");
    $records = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name_records $where ORDER BY processed_time DESC LIMIT %d OFFSET %d",
        $per_page, $offset
    ));

    $today = date('Y-m-d');
    $daily_count = $user_id_filter ? $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(usage_count) FROM $table_name_counts WHERE user_id = %d AND count_date = %s",
        $user_id_filter, $today
    )) : 0;
    $daily_count = $daily_count ? (int) $daily_count : 0;
    $total_user_count = $user_id_filter ? $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name_records WHERE user_id = %d",
        $user_id_filter
    )) : 0;
    $daily_limit = (int) get_option('xb_jiemeng_daily_limit', 10);
    $user_limit = $user_id_filter ? get_user_meta($user_id_filter, 'xb_jiemeng_custom_limit', true) : '';
    $limit = $user_limit ? (int) $user_limit : $daily_limit;

    ?>
    <div class="wrap">
        <h1>用户解梦记录</h1>
        <p>网站总处理数量：<?php echo $total; ?></p>
        <form method="post">
            <input type="submit" name="xb_jiemeng_clear_all" value="删除所有记录" class="button" onclick="return confirm('确定要删除所有记录吗？此操作不可恢复！');">
        </form>
        <form method="get">
            <input type="hidden" name="page" value="xb-jiemeng-records">
            <label>查询用户 ID: </label>
            <input type="number" name="user_id" value="<?php echo $user_id_filter; ?>">
            <input type="submit" value="查询" class="button">
        </form>
        <?php if ($user_id_filter): ?>
            <p>今日使用次数：<?php echo $daily_count; ?>/<?php echo $limit; ?>，总处理次数：<?php echo $total_user_count; ?></p>
            <form method="post">
                <label>设置用户每日限制: </label>
                <input type="number" name="custom_limit" value="<?php echo $user_limit ?: $daily_limit; ?>" min="0">
                <input type="submit" name="xb_jiemeng_user_limit" value="保存" class="button">
                <p class="description">设置为 0 或留空将恢复为默认值 (<?php echo $daily_limit; ?> 次)</p>
            </form>
            <form method="post">
                <input type="submit" name="xb_jiemeng_clear_user" value="删除当前用户记录" class="button" onclick="return confirm('确定要删除用户 <?php echo $user_id_filter; ?> 的所有记录吗？此操作不可恢复！');">
            </form>
            <a href="?page=xb-jiemeng-records" class="button" style="margin-top: 10px;">返回全部记录</a>
        <?php endif; ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>用户名</th>
                    <th>设备 ID</th>
                    <th>IP</th>
                    <th>输入文本（前10字）</th>
                    <th>状态</th>
                    <th>错误信息</th>
                    <th>处理时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record): ?>
                    <tr>
                        <td><?php echo $record->user_id; ?></td>
                        <td><?php echo $record->user_id ? get_userdata($record->user_id)->user_login : '游客'; ?></td>
                        <td><?php echo esc_html($record->device_id); ?></td>
                        <td><?php echo esc_html($record->ip_address); ?></td>
                        <td><?php echo esc_html($record->input_text); ?></td>
                        <td><?php echo esc_html($record->status); ?></td>
                        <td><?php echo esc_html($record->error_message); ?></td>
                        <td><?php echo $record->processed_time; ?></td>
                        <td><a href="?page=xb-jiemeng-records&delete_id=<?php echo $record->id; ?>" class="button">删除</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        $pagination = paginate_links([
            'base'    => add_query_arg('paged', '%#%'),
            'format'  => '',
            'total'   => ceil($total / $per_page),
            'current' => $paged,
        ]);
        if ($pagination) {
            echo '<div class="tablenav"><div class="tablenav-pages">' . $pagination . '</div></div>';
        }
        ?>
    </div>
    <script>
        jQuery(document).ready(function($) {
            setTimeout(function() {
                $('.xb-jiemeng-admin-notice').fadeOut(500);
            }, 3000);
        });
    </script>
    <?php
}
?>