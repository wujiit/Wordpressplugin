/*
 * 周公解梦前端脚本
 * Version: 1.0.2
 * Author: Summer
 */
jQuery(document).ready(function($) {
    const $input = $('#xb-jiemeng-input');
    const $charCount = $('#xb-jiemeng-char-count');
    const $processBtn = $('#xb-jiemeng-process-btn');
    const $clearBtn = $('#xb-jiemeng-clear-btn');
    const $loginBtn = $('#xb-jiemeng-login-btn');
    const $result = $('#xb-jiemeng-result');
    const $notification = $('#xb-jiemeng-notification');
    const $usage = $('.xb-jiemeng-usage');
    const maxChars = xb_jiemeng_vars.max_chars;
    const isUserLoggedIn = xb_jiemeng_vars.is_user_logged_in === 'yes';

    // 新增：初始化使用次数显示
    function initUsageCount() {
        const ajaxOptions = {
            url: xb_jiemeng_vars.ajax_url + 'usage',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                console.log('Usage response:', response); // 调试：记录响应
                if (response.show_stats && $usage.length) {
                    if (response.remaining > 0) {
                        $usage.text(`今日剩余解梦次数：${response.remaining}/${response.limit}`);
                        $processBtn.show();
                        $loginBtn.hide();
                    } else {
                        $usage.text(isUserLoggedIn ? '今日使用次数已用完，请明天再来' : '游客解梦次数已用尽，请登录后继续使用');
                        $processBtn.hide();
                        if (!isUserLoggedIn) {
                            $loginBtn.show();
                        }
                    }
                    $usage.show(); // 确保元素可见
                } else {
                    $usage.hide(); // 隐藏统计信息（如果 show_stats 为 false）
                }
            },
            error: function(xhr) {
                console.error('Failed to fetch usage count:', xhr.responseJSON?.message || 'Unknown error');
            }
        };

        if (isUserLoggedIn && xb_jiemeng_vars.nonce) {
            ajaxOptions.headers = { 'X-WP-Nonce': xb_jiemeng_vars.nonce };
        }

        $.ajax(ajaxOptions);
    }

    // 实时更新字符计数和按钮状态
    $input.on('input', function() {
        const count = $(this).val().length;
        $charCount.text(count);
        $processBtn.prop('disabled', count === 0);
    });

    // 提交解梦
    $processBtn.on('click', function() {
        const text = $input.val().trim();
        if (!text) {
            showNotification('请输入梦境关键词', 'error');
            return;
        }

        $result.html('<div class="xb-jiemeng-processing">正在解梦中...</div>');

        const ajaxOptions = {
            url: xb_jiemeng_vars.ajax_url + 'process',
            method: 'POST',
            data: JSON.stringify({ text: text }),
            contentType: 'application/json',
            success: function(response) {
                console.log('Process response:', response); // 调试：记录响应
                if (response.error) {
                    showNotification(response.error, 'error');
                    $result.empty();
                    if (response.remaining === 0) {
                        $processBtn.hide();
                        if (response.is_guest) {
                            $loginBtn.show();
                        }
                    }
                    initUsageCount(); // 优化：重新获取使用次数
                    return;
                }

                let resultHtml = '';
                if (response.list && response.list.length > 0) {
                    response.list.forEach(item => {
                        resultHtml += `<div class="xb-jiemeng-result-item">
                            <div class="xb-jiemeng-result-title">${item.title}</div>
                            <div class="xb-jiemeng-result-type">类型: ${item.type}</div>
                            <p class="xb-jiemeng-result-content">${item.result}</p>
                        </div>`;
                    });
                } else {
                    resultHtml = '<p class="xb-jiemeng-no-result">无相关解梦结果，请尝试其他关键词</p>';
                }
                $result.html(resultHtml);
                initUsageCount(); // 优化：解梦成功后重新获取使用次数
            },
            error: function(xhr) {
                showNotification(xhr.responseJSON?.message || '暂时无法解梦请联系客服、请刷新重试或更换梦境重要关键词', 'error');
                $result.empty();
                initUsageCount(); // 优化：错误时也尝试更新使用次数
            }
        };

        if (isUserLoggedIn && xb_jiemeng_vars.nonce) {
            ajaxOptions.headers = { 'X-WP-Nonce': xb_jiemeng_vars.nonce };
        }

        $.ajax(ajaxOptions);
    });

    // 清空输入和结果
    $clearBtn.on('click', function() {
        $input.val('');
        $charCount.text('0');
        $result.empty();
        $notification.empty();
        $processBtn.prop('disabled', true);
    });

    // 快速登录按钮点击事件
    $loginBtn.on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = xb_jiemeng_vars.login_url;
        }
    });

    // 更新使用次数显示（保留原函数，供兼容性）
    function updateUsageCount(remaining, limit) {
        if (!$usage.length || !$usage.is(':visible')) return;
        if (remaining > 0) {
            $usage.text(`今日剩余解梦次数：${remaining}/${limit}`);
            $processBtn.show();
            $loginBtn.hide();
        } else {
            $usage.text(isUserLoggedIn ? '今日使用次数已用完，请明天再来' : '游客解梦次数已用尽，请登录后继续使用');
            $processBtn.hide();
            if (!isUserLoggedIn) {
                $loginBtn.show();
            }
        }
    }

    // 显示通知消息
    function showNotification(message, type) {
        const className = type === 'error' ? 'xb-jiemeng-error' : 'xb-jiemeng-success';
        $notification.html(`<div class="${className}">${message}</div>`);
        setTimeout(() => {
            $notification.empty();
        }, 3000);
    }

    // 初始化：加载页面时获取使用次数
    initUsageCount();
});