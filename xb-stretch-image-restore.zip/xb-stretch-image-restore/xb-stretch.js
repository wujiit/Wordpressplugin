jQuery(document).ready(function($) {
    // 初始化变量
    const $uploadBtn = $('.xb-stretch-upload-btn');
    const $fileInput = $('#xb-stretch-file-input');
    const $originalPreview = $('#xb-stretch-original-preview');
    const $processBtn = $('#xb-stretch-process-btn');
    const $processedPreview = $('#xb-stretch-processed-preview');
    const $processing = $('#xb-stretch-processing');
    const $downloadBtn = $('#xb-stretch-download-btn');
    const $loginBtn = $('.xb-stretch-login-btn');
    let imageUrl = '';
    let attachmentId = '';
    let originalFormat = '';

    // 上传按钮点击事件
    $uploadBtn.on('click', function() {
        $fileInput.click();
    });

    // 文件选择事件 - 前端初步检查
    $fileInput.on('change', function() {
        const file = this.files[0];
        if (!file) return;

        // 前端检查文件扩展名
        const ext = file.name.split('.').pop().toLowerCase();
        const allowedFormats = xbStretchData.allowed_formats.map(fmt => fmt.toLowerCase());

        if (!allowedFormats.includes(ext)) {
            showModal(`图片格式不支持，只支持: ${allowedFormats.join(',')}`);
            $fileInput.val(''); // 清空输入
            return;
        }

        // 前端检查文件类型（基于MIME）
        const reader = new FileReader();
        reader.onload = function(e) {
            const arr = (new Uint8Array(e.target.result)).subarray(0, 4);
            let header = '';
            for(let i = 0; i < arr.length; i++) {
                header += arr[i].toString(16);
            }

            // 检查文件头是否匹配常见图片格式
            let isValidImage = false;
            switch (header) {
                case '89504e47': // PNG
                    isValidImage = ext === 'png';
                    break;
                case 'ffd8ffe0': // JPEG
                case 'ffd8ffe1':
                case 'ffd8ffdb':
                    isValidImage = ext === 'jpg' || ext === 'jpeg';
                    break;
                case '47494638': // GIF
                    isValidImage = ext === 'gif';
                    break;
                default:
                    isValidImage = false;
            }

            if (!isValidImage) {
                showModal('文件不是真实的图片，请更换图片');
                $fileInput.val(''); // 清空输入
                return;
            }

            // 如果前端检查通过，则上传文件
            const formData = new FormData();
            formData.append('file', file);

            $.ajax({
                url: xbStretchData.ajax_url + 'upload',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-WP-Nonce': xbStretchData.nonce
                },
                success: function(response) {
                    imageUrl = response.url;
                    attachmentId = response.attachment_id;
                    originalFormat = ext;
                    $originalPreview.html(`<img src="${imageUrl}" alt="Original" />`);
                    $processBtn.prop('disabled', false); // 上传成功后启用“开始拉伸”按钮
                },
                error: function(xhr) {
                    showModal(xhr.responseJSON ? xhr.responseJSON.message : '上传失败，请重试');
                    $fileInput.val(''); // 清空输入
                }
            });
        };
        reader.readAsArrayBuffer(file.slice(0, 4)); // 只读取文件头
    });

    // 开始拉伸按钮点击事件
    $processBtn.on('click', function() {
        if (!imageUrl) {
            showModal('请先上传图片');
            return;
        }

        $processing.show();
        $.ajax({
            url: xbStretchData.ajax_url + 'process',
            type: 'POST',
            data: {
                image_url: imageUrl,
                attachment_id: attachmentId
            },
            headers: {
                'X-WP-Nonce': xbStretchData.nonce
            },
            success: function(response) {
                $processing.hide();
                $processedPreview.html(`<img src="data:image/${response.format};base64,${response.image}" alt="Processed" />`);
                $downloadBtn.show();
                updateUsageCount();
            },
            error: function(xhr) {
                $processing.hide();
                showModal(xhr.responseJSON ? xhr.responseJSON.message : '处理失败，请重试');
            }
        });
    });

    // 下载按钮点击事件
    $downloadBtn.on('click', function() {
        const base64Image = $processedPreview.find('img').attr('src');
        const link = document.createElement('a');
        link.href = base64Image;
        link.download = `processed_image_${Date.now()}.${originalFormat}`;
        link.click();
    });

    // 快速登录按钮点击事件
    $loginBtn.on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = xbStretchData.login_url;
        }
    });

    // 更新使用次数显示
    function updateUsageCount() {
        const used = parseInt(xbStretchData.used_count) + 1;
        const limit = parseInt(xbStretchData.daily_limit);
        const $usage = $('.xb-stretch-usage');
        if (used >= limit) {
            $usage.text('今日使用次数已经用完，请明天再来');
        } else {
            $usage.text(`今日剩余拉伸次数：${limit - used}/${limit}`);
        }
        xbStretchData.used_count = used;
    }

    // 显示自定义提示框并设置3秒自动消失
    function showModal(message) {
        $('#xb-stretch-modal-message').text(message);
        $('#xb-stretch-modal').show();
        setTimeout(function() {
            $('#xb-stretch-modal').fadeOut(300);
        }, 3000);
        $('.xb-stretch-modal-close').on('click', function() {
            $('#xb-stretch-modal').hide();
        });
    }
});