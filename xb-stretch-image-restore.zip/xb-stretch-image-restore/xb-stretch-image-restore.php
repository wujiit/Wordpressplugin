<?php
/*
Plugin Name: 小半图像拉伸
Description: 使用百度云API恢复拉伸图像的WordPress插件
Version: 1.0
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('XB_STRETCH_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('XB_STRETCH_PLUGIN_URL', plugin_dir_url(__FILE__));

// 插件激活钩子
register_activation_hook(__FILE__, 'xb_stretch_activate');
function xb_stretch_activate() {
    xb_stretch_create_tables();
    xb_stretch_create_frontend_page();
}

// 创建数据库表
function xb_stretch_create_tables() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_stretch_records';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        original_image_id BIGINT(20) UNSIGNED NOT NULL,
        processed_time DATETIME NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// 创建前台页面
function xb_stretch_create_frontend_page() {
    $pages = get_posts([
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_stretch_restore]',
        'numberposts' => 1,
    ]);

    if (empty($pages)) {
        wp_insert_post([
            'post_title'    => '图像拉伸图像恢复',
            'post_content'  => '[xb_stretch_restore]',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        ]);
    }
}

// 加载前台脚本和样式，仅在包含短代码的页面加载
add_action('wp_enqueue_scripts', 'xb_stretch_enqueue_frontend_assets');
function xb_stretch_enqueue_frontend_assets() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_stretch_restore')) {
        //wp_enqueue_style('xb-stretch-style', XB_STRETCH_PLUGIN_URL . 'xb-stretch.css', [], '1.2');
        //wp_enqueue_script('xb-stretch-script', XB_STRETCH_PLUGIN_URL . 'xb-stretch.js', ['jquery'], '1.2', true);

        wp_enqueue_style('xb-stretch-style', 'https://img.qiyucloud.com/cloud/xb-stretch-image-restore/xb-stretch.css', [], '1.2');
        wp_enqueue_script('xb-stretch-script', 'https://img.qiyucloud.com/cloud/xb-stretch-image-restore/xb-stretch.js', ['jquery'], '1.2', true);

        $user_id = get_current_user_id();
        $daily_limit = xb_stretch_get_user_daily_limit($user_id);
        $used_count = xb_stretch_get_user_daily_usage($user_id);
        $allowed_formats = explode(',', get_option('xb_stretch_allowed_formats', 'jpg,png'));

        wp_localize_script('xb-stretch-script', 'xbStretchData', [
            'ajax_url' => rest_url('xb_stretch/v1/'),
            'nonce'    => wp_create_nonce('wp_rest'),
            'user_id'  => $user_id,
            'daily_limit' => $daily_limit,
            'used_count' => $used_count,
            'login_url' => wp_login_url(get_permalink()),
            'allowed_formats' => $allowed_formats // 传递允许的格式给前端
        ]);
    }
}

// 前台页面短代码（调整 accept 属性）
add_shortcode('xb_stretch_restore', 'xb_stretch_render_frontend');
function xb_stretch_render_frontend() {
    $user_id = get_current_user_id();
    $daily_limit = xb_stretch_get_user_daily_limit($user_id);
    $used_count = xb_stretch_get_user_daily_usage($user_id);
    $announcement = get_option('xb_stretch_announcement', '');
    $allowed_formats = explode(',', get_option('xb_stretch_allowed_formats', 'jpg,png'));
    // 动态生成 accept 属性值
    $accept_value = implode(',', array_map(function($format) { return '.' . trim($format); }, $allowed_formats));

    ob_start();
    ?>
    <div class="xb-stretch-container">
        <div class="xb-stretch-title">图像拉伸恢复</div>
        <div class="xb-stretch-content">
            <?php if (!is_user_logged_in()) : ?>
                <div class="xb-stretch-login-prompt">
                    <p>请先登录</p>
                    <a href="<?php echo wp_login_url(get_permalink()); ?>" class="xb-stretch-login-btn">快速登录</a>
                </div>
            <?php elseif ($used_count < $daily_limit) : ?>
                <div class="xb-stretch-left">
                    <div class="xb-stretch-subtitle">需要拉伸的图片</div>
                    <div class="xb-stretch-upload-btn">上传图片</div>
                    <input type="file" id="xb-stretch-file-input" accept="<?php echo esc_attr($accept_value); ?>" style="display:none;">
                    <div class="xb-stretch-preview" id="xb-stretch-original-preview"></div>
                </div>
                <div class="xb-stretch-right">
                    <div class="xb-stretch-subtitle">处理后的图片</div>
                    <button class="xb-stretch-process-btn" id="xb-stretch-process-btn" disabled>开始拉伸</button>
                    <div class="xb-stretch-processing" id="xb-stretch-processing" style="display:none;">正在处理中...</div>
                    <div class="xb-stretch-preview" id="xb-stretch-processed-preview"></div>
                    <div class="xb-stretch-download-btn" id="xb-stretch-download-btn" style="display:none;">快速下载</div>
                </div>
            <?php endif; ?>
        </div>
        <div class="xb-stretch-usage">
            <?php if (is_user_logged_in()) : ?>
                <?php if ($used_count >= $daily_limit) : ?>
                    今日使用次数已经用完，请明天再来
                <?php else : ?>
                    今日剩余拉伸次数：<?php echo ($daily_limit - $used_count) . '/' . $daily_limit; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php if ($announcement) : ?>
            <div class="xb-stretch-announcement"><?php echo wp_kses_post($announcement); ?></div>
        <?php endif; ?>
        <!-- 两个独立板块 -->
        <div class="xb-stretch-example">
            <div class="xb-stretch-example-title">示例图</div>
            <div class="xb-stretch-example-wrapper">
                <div class="xb-stretch-example-left">
                    <div class="xb-stretch-example-subtitle">原始图</div>
                    <div class="xb-stretch-example-image">
                        <img src="https://aiimg.qiyucloud.com/htai/2025/04/20250409080624916.jpg" alt="拉伸前" />
                    </div>
                </div>
                <div class="xb-stretch-example-right">
                    <div class="xb-stretch-example-subtitle">处理后的图片</div>
                    <div class="xb-stretch-example-image">
                        <img src="https://aiimg.qiyucloud.com/htai/2025/04/20250414141849625.jpg" alt="拉伸后" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="xb-stretch-modal" id="xb-stretch-modal" style="display:none;">
        <div class="xb-stretch-modal-content">
            <span class="xb-stretch-modal-close">×</span>
            <p id="xb-stretch-modal-message"></p>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// 后台菜单
add_action('admin_menu', 'xb_stretch_admin_menu');
function xb_stretch_admin_menu() {
    add_menu_page('图像拉伸设置', '图像拉伸', 'manage_options', 'xb-stretch-settings', 'xb_stretch_settings_page');
    add_submenu_page('xb-stretch-settings', '用户图像拉伸记录', '用户图像拉伸记录', 'manage_options', 'xb-stretch-records', 'xb_stretch_records_page');
}

// 设置页面
function xb_stretch_settings_page() {
    if (isset($_POST['xb_stretch_save_settings'])) {
        update_option('xb_stretch_baidu_apikey', sanitize_text_field($_POST['xb_stretch_baidu_apikey']));
        update_option('xb_stretch_allowed_formats', sanitize_text_field($_POST['xb_stretch_allowed_formats']));
        update_option('xb_stretch_max_size', intval($_POST['xb_stretch_max_size']));
        update_option('xb_stretch_daily_limit', intval($_POST['xb_stretch_daily_limit']));
        update_option('xb_stretch_announcement', wp_kses_post($_POST['xb_stretch_announcement']));
        echo '<div class="updated xb-stretch-notice"><p>设置已保存。</p></div>';
        echo '<script>setTimeout(function(){document.querySelector(".xb-stretch-notice").style.display="none";}, 3000);</script>';
    }

    $apikey = get_option('xb_stretch_baidu_apikey', '');
    $allowed_formats = get_option('xb_stretch_allowed_formats', 'jpg,png');
    $max_size = get_option('xb_stretch_max_size', 5);
    $daily_limit = get_option('xb_stretch_daily_limit', 10);
    $announcement = get_option('xb_stretch_announcement', '');
    ?>
    <div class="wrap">
        <h1>图像拉伸恢复设置</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>百度云 API Key</th>
                    <td><input type="text" name="xb_stretch_baidu_apikey" value="<?php echo esc_attr($apikey); ?>" size="50"></td>
                </tr>
                <tr>
                    <th>支持的图片格式</th>
                    <td><input type="text" name="xb_stretch_allowed_formats" value="<?php echo esc_attr($allowed_formats); ?>" size="50"> (用英文逗号分隔，如 jpg,png)</td>
                </tr>
                <tr>
                    <th>最大图片大小 (MB)</th>
                    <td><input type="number" name="xb_stretch_max_size" value="<?php echo esc_attr($max_size); ?>" min="1"></td>
                </tr>
                <tr>
                    <th>每日使用次数限制</th>
                    <td><input type="number" name="xb_stretch_daily_limit" value="<?php echo esc_attr($daily_limit); ?>" min="1"></td>
                </tr>
                <tr>
                    <th>公告内容 (支持 HTML)</th>
                    <td><textarea name="xb_stretch_announcement" rows="5" cols="50"><?php echo esc_textarea($announcement); ?></textarea></td>
                </tr>
            </table>
            <p><input type="submit" name="xb_stretch_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        由百度云提供：https://ai.baidu.com/tech/imageprocess/stretch_restore <br>
        单价：0.008元 1000次8元
    </div>
    <?php
}

// 记录页面
function xb_stretch_records_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_stretch_records';
    $per_page = 20;
    $paged = isset($_GET['paged']) ? intval($_GET['paged']) : 1;
    $user_id_filter = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

    if (isset($_POST['xb_stretch_update_user_limit'])) {
        $user_id = intval($_POST['user_id']);
        $custom_limit = intval($_POST['xb_stretch_custom_limit']);
        if ($custom_limit > 0) {
            update_user_meta($user_id, 'xb_stretch_custom_limit', $custom_limit);
        } else {
            delete_user_meta($user_id, 'xb_stretch_custom_limit');
        }
        echo '<div class="updated xb-stretch-notice"><p>用户限制已更新。</p></div>';
        echo '<script>setTimeout(function(){document.querySelector(".xb-stretch-notice").style.display="none";}, 3000);</script>';
    }

    if (isset($_GET['delete_record'])) {
        $record_id = intval($_GET['delete_record']);
        $wpdb->delete($table_name, ['id' => $record_id]);
        echo '<div class="updated xb-stretch-notice"><p>记录已删除。</p></div>';
        echo '<script>setTimeout(function(){document.querySelector(".xb-stretch-notice").style.display="none";}, 3000);</script>';
    }

    $where = $user_id_filter ? "WHERE user_id = $user_id_filter" : '';
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
    $records = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name $where ORDER BY processed_time DESC LIMIT %d, %d", ($paged - 1) * $per_page, $per_page));

    $pagination = paginate_links([
        'base' => add_query_arg('paged', '%#%'),
        'format' => '',
        'total' => ceil($total / $per_page),
        'current' => $paged,
    ]);
    ?>
    <div class="wrap">
        <h1>用户图像拉伸记录</h1>
        <p>总处理次数：<?php echo $total; ?></p>
        <form method="get">
            <input type="hidden" name="page" value="xb-stretch-records">
            <label>查询用户 ID: </label><input type="number" name="user_id" value="<?php echo $user_id_filter; ?>">
            <input type="submit" class="button" value="查询">
        </form>
        <?php if ($user_id_filter) : 
            $user_limit = xb_stretch_get_user_daily_limit($user_id_filter);
            $usedpq_count = xb_stretch_get_user_daily_usage($user_id_filter);
            $user_total = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d", $user_id_filter));
        ?>
            <p>当前用户每日限额：<?php echo $user_limit; ?> 次，已使用：<?php echo $used_count; ?> 次，总处理次数：<?php echo $user_total; ?></p>
            <form method="post">
                <input type="hidden" name="user_id" value="<?php echo $user_id_filter; ?>">
                <label>设置自定义每日限制: </label><input type="number" name="xb_stretch_custom_limit" min="0" placeholder="留空恢复默认">
                <input type="submit" name="xb_stretch_update_user_limit" class="button" value="更新限制">
            </form>
        <?php endif; ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>用户名</th>
                    <th>原始图片</th>
                    <th>处理时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record) : 
                    $user = get_userdata($record->user_id);
                    $image = wp_get_attachment_image_url($record->original_image_id, 'thumbnail');
                ?>
                    <tr>
                        <td><?php echo $record->user_id; ?></td>
                        <td><?php echo $user ? $user->user_login : '未知'; ?></td>
                        <td><img src="<?php echo $image; ?>" style="width:100px;height:100px;"></td>
                        <td><?php echo $record->processed_time; ?></td>
                        <td><a href="<?php echo add_query_arg('delete_record', $record->id); ?>" class="button">删除</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="tablenav"><?php echo $pagination; ?></div>
    </div>
    <?php
}

// 注册 REST API 端点
add_action('rest_api_init', 'xb_stretch_register_api');
function xb_stretch_register_api() {
    register_rest_route('xb_stretch/v1', '/upload', [
        'methods' => 'POST',
        'callback' => 'xb_stretch_upload_image',
        'permission_callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_forbidden', '请先登录', ['status' => 401]);
            }
            $nonce = $request->get_header('X-WP-Nonce');
            if (!$nonce || !wp_verify_nonce($nonce, 'wp_rest')) {
                return new WP_Error('rest_invalid_nonce', '无效的 nonce', ['status' => 401]);
            }
            return true;
        },
    ]);

    register_rest_route('xb_stretch/v1', '/process', [
        'methods' => 'POST',
        'callback' => 'xb_stretch_process_image',
        'permission_callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_forbidden', '请先登录', ['status' => 401]);
            }
            $nonce = $request->get_header('X-WP-Nonce');
            if (!$nonce || !wp_verify_nonce($nonce, 'wp_rest')) {
                return new WP_Error('rest_invalid_nonce', '无效的 nonce', ['status' => 401]);
            }
            return true;
        },
    ]);
}

// 处理图片上传
function xb_stretch_upload_image($request) {
    require_once(ABSPATH . 'wp-admin/includes/file.php');

    $files = $request->get_file_params();
    if (empty($files['file'])) {
        return new WP_Error('no_file', '请上传图片', ['status' => 400]);
    }

    $allowed_formats = array_map('strtolower', explode(',', get_option('xb_stretch_allowed_formats', 'jpg,png')));
    $max_size = get_option('xb_stretch_max_size', 5) * 1024 * 1024;
    $file = $files['file'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    // 检查文件扩展名是否在允许的格式中
    if (!in_array($ext, $allowed_formats)) {
        return new WP_Error('invalid_format', '图片格式不支持，只支持: ' . implode(',', $allowed_formats), ['status' => 400]);
    }

    // 检查文件大小
    if ($file['size'] > $max_size) {
        return new WP_Error('file_too_large', '文件太大，请上传小于' . ($max_size / 1024 / 1024) . 'MB的图片', ['status' => 400]);
    }

    // 获取真实的文件MIME类型
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    // 定义允许的MIME类型与扩展名映射
    $allowed_mime_types = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
    ];

    // 检查MIME类型是否匹配扩展名
    if (!isset($allowed_mime_types[$ext]) || $mime_type !== $allowed_mime_types[$ext]) {
        return new WP_Error('invalid_image', '文件不是真实的图片，请更换图片', ['status' => 400]);
    }

    $upload = wp_handle_upload($file, ['test_form' => false]);
    if (isset($upload['error'])) {
        return new WP_Error('upload_error', $upload['error'], ['status' => 500]);
    }

    $attachment_id = wp_insert_attachment([
        'guid'           => $upload['url'],
        'post_mime_type' => $upload['type'],
        'post_title'     => sanitize_file_name($file['name']),
        'post_content'   => '',
        'post_status'    => 'inherit',
    ], $upload['file']);

    require_once(ABSPATH . 'wp-admin/includes/image.php');
    wp_generate_attachment_metadata($attachment_id, $upload['file']);
    return ['url' => $upload['url'], 'attachment_id' => $attachment_id];
}

// 处理图片拉伸
function xb_stretch_process_image($request) {
    $user_id = get_current_user_id();
    $daily_limit = xb_stretch_get_user_daily_limit($user_id);
    $used_count = xb_stretch_get_user_daily_usage($user_id);

    if ($used_count >= $daily_limit) {
        return new WP_Error('limit_exceeded', '今日使用次数已用完', ['status' => 403]);
    }

    $image_url = $request['image_url'];
    $attachment_id = $request['attachment_id'];
    $apikey = get_option('xb_stretch_baidu_apikey');

    if (!$apikey) {
        return new WP_Error('no_apikey', '未设置百度云 API Key', ['status' => 500]);
    }

    $response = wp_remote_post('https://aip.baidubce.com/rest/2.0/image-process/v1/stretch_restore', [
        'headers' => [
            'Content-Type' => 'application/x-www-form-urlencoded',
            'Accept'       => 'application/json',
            'Authorization' => 'Bearer ' . $apikey,
        ],
        'body' => ['url' => $image_url],
    ]);

    if (is_wp_error($response)) {
        return new WP_Error('api_error', $response->get_error_message(), ['status' => 500]);
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    if (isset($body['image'])) {
        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'xb_stretch_records', [
            'user_id' => $user_id,
            'original_image_id' => $attachment_id,
            'processed_time' => current_time('mysql'),
        ]);
        return ['image' => $body['image'], 'format' => pathinfo($image_url, PATHINFO_EXTENSION)];
    }

    return new WP_Error('api_failure', '图像处理失败', ['status' => 500]);
}

// 获取用户每日使用限制
function xb_stretch_get_user_daily_limit($user_id) {
    $custom_limit = get_user_meta($user_id, 'xb_stretch_custom_limit', true);
    return $custom_limit ? intval($custom_limit) : intval(get_option('xb_stretch_daily_limit', 10));
}

// 获取用户每日使用次数
function xb_stretch_get_user_daily_usage($user_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_stretch_records';
    return $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(processed_time) = CURDATE()",
        $user_id
    ));
}