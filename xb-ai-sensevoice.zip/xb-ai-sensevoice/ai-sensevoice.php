<?php
/*
Plugin Name: Ai语音转文字
Description: 基于第三方API的语音转文字插件，支持上传音频文件、选择语言并将语音转换为文字。
Version: 1.0.2
Author: summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 插件激活时执行
 */
register_activation_hook(__FILE__, 'ai_sensevoice_activate');
function ai_sensevoice_activate() {
    ai_sensevoice_create_tables();
    ai_sensevoice_create_front_page();
}

/**
 * 创建数据库表
 */
function ai_sensevoice_create_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 任务表
    $table_name = $wpdb->prefix . 'sensevoice_tasks';
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        task_id varchar(255) NOT NULL,
        audio_url varchar(255) NOT NULL,
        language varchar(50) NOT NULL,
        result_text text DEFAULT NULL,
        status varchar(50) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        completed_at datetime DEFAULT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // 用户每日限制表
    $limit_table = $wpdb->prefix . 'sensevoice_user_limits';
    $limit_sql = "CREATE TABLE $limit_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        daily_limit int NOT NULL,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    dbDelta($limit_sql);
}

/**
 * 创建前台页面
 */
function ai_sensevoice_create_front_page() {
    $pages = get_posts([
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[ai_sensevoice_form]',
        'numberposts' => 1,
    ]);

    if (empty($pages)) {
        wp_insert_post([
            'post_title'   => '语音转文字助手',
            'post_content' => '[ai_sensevoice_form]',
            'post_status'  => 'publish',
            'post_author'  => 1,
            'post_type'    => 'page',
            'post_name'    => 'speech-to-text'
        ]);
    }
}

/**
 * 在插件列表添加设置链接
 */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'ai_sensevoice_add_settings_link');
function ai_sensevoice_add_settings_link($links) {
    $settings_link = '<a href="admin.php?page=ai-sensevoice-settings">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}

/**
 * 添加后台菜单
 */
add_action('admin_menu', 'ai_sensevoice_admin_menu');
function ai_sensevoice_admin_menu() {
    add_menu_page('语音转文字设置', '语音转文字', 'manage_options', 'ai-sensevoice-settings', 'ai_sensevoice_settings_page', 'dashicons-microphone');
    add_submenu_page('ai-sensevoice-settings', '转换记录', '转换记录', 'manage_options', 'ai-sensevoice-records', 'ai_sensevoice_records_page');
}

/**
 * 设置页面
 */
function ai_sensevoice_settings_page() {
    if (isset($_POST['ai_sensevoice_save'])) {
        update_option('ai_sensevoice_api_url', sanitize_text_field($_POST['api_url']));
        update_option('ai_sensevoice_api_key', sanitize_text_field($_POST['api_key']));
        update_option('ai_sensevoice_model_params', sanitize_text_field($_POST['model_params']));
        update_option('ai_sensevoice_allowed_formats', sanitize_text_field($_POST['allowed_formats']));
        update_option('ai_sensevoice_max_size', max(1, intval($_POST['max_size'])));
        update_option('ai_sensevoice_supported_languages', sanitize_text_field($_POST['supported_languages']));
        update_option('ai_sensevoice_daily_limit', max(0, intval($_POST['daily_limit'])));
        update_option('ai_sensevoice_notice', wp_kses_post($_POST['notice_content']));
        update_option('ai_sensevoice_disfluency_removal_enabled', isset($_POST['disfluency_removal_enabled']) ? 1 : 0);
        echo '<div class="updated" id="ai-sensevoice-settings-saved-message"><p>设置已保存</p></div>';
    }

    $api_url = get_option('ai_sensevoice_api_url', 'https://dashscope.aliyuncs.com/api/v1/services/audio/asr/transcription');
    $api_key = get_option('ai_sensevoice_api_key', '');
    $model_params = get_option('ai_sensevoice_model_params', 'sensevoice-v1');
    $allowed_formats = get_option('ai_sensevoice_allowed_formats', 'mp3,wav,aac');
    $max_size = get_option('ai_sensevoice_max_size', 3);
    $supported_languages = get_option('ai_sensevoice_supported_languages', 'auto,zh,en,ja');
    $daily_limit = get_option('ai_sensevoice_daily_limit', 10);
    $notice_content = get_option('ai_sensevoice_notice', '');
    $disfluency_removal_enabled = get_option('ai_sensevoice_disfluency_removal_enabled', 0);

    ?>
    <div class="wrap">
        <h1>语音转文字设置</h1>
        <form method="POST">
            <table class="form-table">
                <tr>
                    <th>API 请求地址</th>
                    <td><input type="text" name="api_url" value="<?php echo esc_attr($api_url); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>API Key</th>
                    <td><input type="text" name="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text-field ai-sensevoice-long-input"></td>
                </tr>
                <tr>
                    <th>模型参数</th>
                    <td><input type="text" name="model_params" value="<?php echo esc_attr($model_params); ?>" class="regular-text-field"><p>多个参数请用逗号分隔，默认使用第一个</p></td>
                </tr>
                <tr>
                    <th>支持的格式</th>
                    <td><input type="text" name="allowed_formats" value="<?php echo esc_attr($allowed_formats); ?>" class="regular-text-field ai-sensevoice-long-input"><p>支持的音频文件格式，例如： mp3,wav,aac</p></td>
                </tr>
                <tr>
                    <th>支持的文件大小 (MB)</th>
                    <td><input type="number" name="max_size" value="<?php echo esc_attr($max_size); ?>" min="1" class="regular-text-field"><p>支持上传文件的最大MB</p></td>
                </tr>
                <tr>
                    <th>支持的语言</th>
                    <td><input type="text" name="supported_languages" value="<?php echo esc_attr($supported_languages); ?>" class="regular-text-field ai-sensevoice-long-input"><p>支持多个语言，列如： auto,zh,en,ja（官方说支持50多种语言，但测试就重点的10种语言还可以）</p></td>
                </tr>
                <tr>
                    <th>默认限制的使用次数</th>
                    <td><input type="number" name="daily_limit" value="<?php echo esc_attr($daily_limit); ?>" min="0" class="regular-text-field"><p>每个用户的默认每日使用限额</p></td>
                </tr>
                <tr>
                    <th>启用过滤语气词</th>
                    <td>
                        <input type="checkbox" name="disfluency_removal_enabled" value="1" <?php checked($disfluency_removal_enabled, 1); ?>>
                        <p>启用后，前台将显示过滤语气词的滑动开关，允许用户选择是否过滤语气词</p>
                    </td>
                </tr>
                <tr>
                    <th>广告设置</th>
                    <td><textarea name="notice_content" rows="5" class="large-text"><?php echo esc_textarea($notice_content); ?></textarea><p>支持HTML格式</p></td>
                </tr>
            </table>
            <p><input type="submit" name="ai_sensevoice_save" class="button-primary" value="保存设置"></p>
        </form>
        <p>通义千问文档: <a href="https://help.aliyun.com/zh/model-studio/developer-reference/sensevoice-recorded-speech-recognition-restful-api" target="_blank">通义千问 API</a></p>
    </div>
    <style>
        #ai-sensevoice-settings-saved-message {
            transition: opacity 1s;
        }
        #ai-sensevoice-settings-saved-message.fade-out {
            opacity: 0;
        }
        .ai-sensevoice-long-input {
            width: 40em !important;
            max-width: 100%;
        }        
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const message = document.getElementById('ai-sensevoice-settings-saved-message');
            if (message) {
                setTimeout(() => {
                    message.classList.add('fade-out');
                    setTimeout(() => message.style.display = 'none', 1000);
                }, 3000);
            }
        });
    </script>
    <?php
}

/**
 * 转换记录页面
 */
function ai_sensevoice_records_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'sensevoice_tasks';
    $limit_table = $wpdb->prefix . 'sensevoice_user_limits';
    $per_page = 20;
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $search_user_id = isset($_GET['search_user_id']) ? intval($_GET['search_user_id']) : '';

    if (isset($_POST['set_user_limit']) && isset($_POST['user_id']) && isset($_POST['new_limit'])) {
        $user_id = intval($_POST['user_id']);
        $new_limit = max(0, intval($_POST['new_limit']));
        $existing = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $limit_table WHERE user_id = %d", $user_id));
        if ($existing) {
            $wpdb->update($limit_table, ['daily_limit' => $new_limit, 'updated_at' => current_time('mysql')], ['user_id' => $user_id]);
        } else {
            $wpdb->insert($limit_table, ['user_id' => $user_id, 'daily_limit' => $new_limit]);
        }
        echo '<div class="updated" id="ai-sensevoice-limit-updated-message"><p>用户每日限制已更新</p></div>';
    }

    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['record_id'])) {
        $record_id = intval($_GET['record_id']);
        $wpdb->delete($table_name, ['id' => $record_id]);
        echo '<div class="updated" id="ai-sensevoice-record-deleted-message"><p>记录已删除</p></div>';
    }

    if (isset($_GET['action']) && $_GET['action'] === 'delete_all' && isset($_GET['user_id'])) {
        $user_id = intval($_GET['user_id']);
        $wpdb->delete($table_name, ['user_id' => $user_id]);
        echo '<div class="updated" id="ai-sensevoice-record-deleted-message"><p>用户所有记录已删除</p></div>';
    }

    if (isset($_GET['action']) && $_GET['action'] === 'clear_limit' && isset($_GET['user_id'])) {
        $user_id = intval($_GET['user_id']);
        $wpdb->delete($limit_table, ['user_id' => $user_id]);
        wp_redirect(admin_url('admin.php?page=ai-sensevoice-records&search_user_id=' . $user_id));
        exit;
    }

    $where = '';
    if ($search_user_id) {
        $where = $wpdb->prepare("WHERE user_id = %d", $search_user_id);
    }

    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
    $offset = ($paged - 1) * $per_page;
    $records = $wpdb->get_results("SELECT * FROM $table_name $where ORDER BY created_at DESC LIMIT $offset, $per_page");

    $all_records_total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $all_success = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 'SUCCEEDED'");
    $all_failed = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 'FAILED'");
    $today_start = current_time('Y-m-d 00:00:00');
    $today_end = current_time('Y-m-d 23:59:59');
    $today_total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE created_at BETWEEN '$today_start' AND '$today_end'");
    $user_total = $search_user_id ? $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d", $search_user_id)) : 0;
    $user_success = $search_user_id ? $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND status = 'SUCCEEDED'", $search_user_id)) : 0;
    $user_failed = $search_user_id ? $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND status = 'FAILED'", $search_user_id)) : 0;
    $user_today = $search_user_id ? $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND created_at BETWEEN '$today_start' AND '$today_end'", $search_user_id)) : 0;
    $user_limit = $search_user_id ? $wpdb->get_var($wpdb->prepare("SELECT daily_limit FROM $limit_table WHERE user_id = %d", $search_user_id)) : null;
    $default_limit = get_option('ai_sensevoice_daily_limit', 10);

    ?>
    <div class="wrap">
        <h1>转换记录</h1>
        <p>总转换次数: <?php echo $all_records_total; ?> | 成功: <?php echo $all_success; ?> | 失败: <?php echo $all_failed; ?> | 今日总次数: <?php echo $today_total; ?></p>
        <?php if ($search_user_id) { ?>
            <p>用户 <?php echo esc_html($search_user_id); ?> 统计: 总次数: <?php echo $user_total; ?> | 成功: <?php echo $user_success; ?> | 失败: <?php echo $user_failed; ?> | 今日次数: <?php echo $user_today; ?> | 
            每日限制: <?php echo $user_limit !== null ? $user_limit : $default_limit . ' (默认)'; ?></p>
        <?php } ?>

        <form method="get" action="" style="margin-bottom: 10px;">
            <input type="hidden" name="page" value="ai-sensevoice-records">
            <label>搜索用户ID: <input type="number" name="search_user_id" value="<?php echo esc_attr($search_user_id); ?>"></label>
            <input type="submit" class="button" value="搜索">
            <?php if ($search_user_id) { ?>
                <a href="?page=ai-sensevoice-records" class="button">查看全部记录</a>
                <a href="?page=ai-sensevoice-records&action=delete_all&user_id=<?php echo $search_user_id; ?>" 
                   class="button" 
                   onclick="return confirm('确定删除此用户的所有记录吗？');">删除用户所有记录</a>
            <?php } ?>
        </form>

        <?php if ($search_user_id) { ?>
            <form method="post" style="margin-bottom: 10px;">
                <label>设置用户 <?php echo esc_html($search_user_id); ?> 的每日转换次数限制:
                    <input type="number" name="new_limit" value="<?php echo esc_attr($user_limit !== null ? $user_limit : $default_limit); ?>" min="0">
                </label>
                <input type="hidden" name="user_id" value="<?php echo esc_attr($search_user_id); ?>">
                <input type="submit" name="set_user_limit" class="button" value="更新限制">
                <?php if ($user_limit !== null) { ?>
                    <a href="?page=ai-sensevoice-records&action=clear_limit&user_id=<?php echo $search_user_id; ?>" 
                       class="button" 
                       onclick="return confirm('确定要清除此用户的自定义限制吗？将恢复使用默认限制');">清除自定义限制</a>
                <?php } ?>
            </form>
        <?php } ?>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户ID</th>
                    <th>用户名</th>
                    <th>音频URL</th>
                    <th>语言</th>
                    <th>创建时间</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record) {
                    $user = get_user_by('id', $record->user_id);
                    ?>
                    <tr>
                        <td><?php echo esc_html($record->user_id); ?></td>
                        <td><?php echo esc_html($user ? $user->user_login : '未知用户'); ?></td>
                        <td><a href="<?php echo esc_url($record->audio_url); ?>" target="_blank">查看音频</a></td>
                        <td><?php echo esc_html($record->language); ?></td>
                        <td><?php echo esc_html($record->created_at); ?></td>
                        <td><?php echo $record->status === 'SUCCEEDED' ? '成功' : ($record->status === 'FAILED' ? '失败' : '处理中'); ?></td>
                        <td><a href="?page=ai-sensevoice-records&action=delete&record_id=<?php echo $record->id; ?><?php echo $search_user_id ? '&search_user_id=' . $search_user_id : ''; ?>" class="button" onclick="return confirm('确定删除此记录吗？');">删除</a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <?php
        $total_pages = ceil($total / $per_page);
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            $pagination_args = [
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ];
            if ($search_user_id) {
                $pagination_args['add_args'] = ['search_user_id' => $search_user_id];
            }
            echo paginate_links($pagination_args);
            echo '</div></div>';
        }
        ?>
    </div>
    <style>
        #ai-sensevoice-limit-updated-message, #ai-sensevoice-record-deleted-message {
            transition: opacity 1s;
        }
        #ai-sensevoice-limit-updated-message.fade-out, #ai-sensevoice-record-deleted-message.fade-out {
            opacity: 0;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            ['ai-sensevoice-limit-updated-message', 'ai-sensevoice-record-deleted-message'].forEach(id => {
                const message = document.getElementById(id);
                if (message) {
                    setTimeout(() => {
                        message.classList.add('fade-out');
                        setTimeout(() => message.style.display = 'none', 1000);
                    }, 3000);
                }
            });
        });
    </script>
    <?php
}

/**
 * 加载前端资源
 */
add_action('wp_enqueue_scripts', 'ai_sensevoice_enqueue_assets');
function ai_sensevoice_enqueue_assets() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'ai_sensevoice_form')) {
        wp_enqueue_style('ai-sensevoice-style', plugins_url('style.css', __FILE__), [], '1.4');
        wp_enqueue_script('ai-sensevoice-script', plugins_url('script.js', __FILE__), ['jquery'], '1.4', true);
        wp_localize_script('ai-sensevoice-script', 'aiSensevoice', [
            'restUrl' => rest_url('ai-sensevoice/v1'),
            'nonce' => wp_create_nonce('wp_rest'),
            'allowedFormats' => explode(',', get_option('ai_sensevoice_allowed_formats', 'mp3,wav,aac')),
            'maxSize' => get_option('ai_sensevoice_max_size', 3) * 1024 * 1024,
            'loginUrl' => wp_login_url(get_permalink()),
            'supportedLanguages' => explode(',', get_option('ai_sensevoice_supported_languages', 'auto,zh,en,ja')),
            'disfluencyRemovalEnabled' => get_option('ai_sensevoice_disfluency_removal_enabled', 0)
        ]);
    }
}

/**
 * 检查用户每日转换次数
 */
function ai_sensevoice_check_daily_limit($user_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'sensevoice_tasks';
    $limit_table = $wpdb->prefix . 'sensevoice_user_limits';

    $user_limit = $wpdb->get_var($wpdb->prepare("SELECT daily_limit FROM $limit_table WHERE user_id = %d", $user_id));
    $daily_limit = $user_limit !== null ? $user_limit : get_option('ai_sensevoice_daily_limit', 10);

    if ($daily_limit == 0) {
        return ['exceeded' => false, 'count' => 0, 'limit' => $daily_limit, 'remaining' => PHP_INT_MAX];
    }

    $today_start = current_time('Y-m-d 00:00:00');
    $today_end = current_time('Y-m-d 23:59:59');
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND created_at BETWEEN %s AND %s AND status = 'SUCCEEDED'",
        $user_id, $today_start, $today_end
    ));

    return [
        'exceeded' => $count >= $daily_limit,
        'count' => $count,
        'limit' => $daily_limit,
        'remaining' => $daily_limit - $count
    ];
}

/**
 * 前台短代码
 */
add_shortcode('ai_sensevoice_form', 'ai_sensevoice_form_shortcode');
function ai_sensevoice_form_shortcode() {
    $supported_languages = explode(',', get_option('ai_sensevoice_supported_languages', 'auto,zh,en,ja'));
    $disfluency_removal_enabled = get_option('ai_sensevoice_disfluency_removal_enabled', 0);
    $language_map = [
        'auto' => '自动',
        'zh' => '中文',
        'en' => '英语',
        'ja' => '日语',
        'yue' => '粤语',
        'ko' => '韩语',
        'ru' => '俄语',
        'fr' => '法语',
        'it' => '意大利语',
        'de' => '德语',
        'es' => '西班牙语',
    ];
    $notice_content = get_option('ai_sensevoice_notice', '');

    $user_id = get_current_user_id();
    $limit_check = $user_id ? ai_sensevoice_check_daily_limit($user_id) : ['exceeded' => false, 'count' => 0, 'limit' => 0, 'remaining' => 0];
    $exceeded_limit = $limit_check['exceeded'];
    $daily_count = $limit_check['count'];
    $daily_limit = $limit_check['limit'];
    $remaining_count = $limit_check['remaining'];

    ob_start();
    ?>
    <div id="ai-sensevoice-form">
        <div class="ai-sensevoice-page-title">AI 语音转文字助手</div>
        <?php if (!$user_id) { ?>
            <div class="ai-sensevoice-login-prompt">
                <p>请先登录以使用语音转文字功能！</p>
                <a href="<?php echo wp_login_url(get_permalink()); ?>" class="ai-sensevoice-modern-btn ai-sensevoice-login-btn">点击这里登录</a>
            </div>
        <?php } else if ($exceeded_limit) { ?>
            <div class="ai-sensevoice-limit-prompt">
                <p>今日使用次数已经用完了，请明天再来</p>
            </div>
        <?php } else { ?>
            <div class="ai-sensevoice-main-area">
                <div class="ai-sensevoice-left-panel">
                    <div class="ai-sensevoice-section-title">上传与配置</div>
                    <div class="ai-sensevoice-upload-field">
                        <label>上传音频文件:</label>
                        <input type="file" id="audio_file" accept="audio/*,video/*" hidden>
                        <button type="button" class="ai-sensevoice-modern-btn ai-sensevoice-upload-btn" data-target="audio_file">选择音频</button>
                        <div class="ai-sensevoice-drag-area" id="ai-sensevoice-drag-area">或将文件拖拽到此处</div>
                        <div id="ai-sensevoice-upload-status"></div>
                    </div>
                    <div id="audio-info" class="ai-sensevoice-info-box"></div>
                    <div class="ai-sensevoice-upload-field">
                        <label>选择语言:</label>
                        <div class="ai-sensevoice-language-buttons">
                            <?php foreach ($supported_languages as $lang) { ?>
                                <button type="button" class="ai-sensevoice-language-btn <?php echo $lang === 'auto' ? 'active' : ''; ?>" data-lang="<?php echo esc_attr($lang); ?>">
                                    <?php echo esc_html($language_map[$lang] ?? $lang); ?>
                                </button>
                            <?php } ?>
                        </div>
                    </div>
                    <?php if ($disfluency_removal_enabled) { ?>
                        <div class="ai-sensevoice-upload-field">
                            <label for="ai-sensevoice-disfluency-toggle">过滤语气词:</label>
                            <div class="ai-sensevoice-toggle-switch">
                                <input type="checkbox" id="ai-sensevoice-disfluency-toggle" hidden>
                                <button type="button" class="ai-sensevoice-toggle-btn" data-target="ai-sensevoice-disfluency-toggle"></button>
                            </div>
                        </div>
                    <?php } ?>
                </div>
                <div class="ai-sensevoice-right-panel">
                    <div class="ai-sensevoice-section-title">转换结果</div>
                    <div id="ai-sensevoice-copy-area">
                        <button id="ai-sensevoice-copy-btn" class="ai-sensevoice-copy-btn" style="display: none;">复制结果</button>
                        <button id="ai-sensevoice-clear-btn" class="ai-sensevoice-clear-btn" style="display: none;">清空</button>
                        <div id="ai-sensevoice-copy-message"></div>
                    </div>
                    <div id="ai-sensevoice-result-message"></div>
                    <div id="result-text" class="ai-sensevoice-result-box"></div>
                    <div id="ai-sensevoice-remaining-count">
                        今日剩余转换次数：<span id="remaining-count"><?php echo esc_html($remaining_count); ?></span>/<?php echo esc_html($daily_limit); ?>
                    </div>
                </div>
            </div>
            <div class="ai-sensevoice-submit-area">
                <button id="ai-sensevoice-submit" class="ai-sensevoice-modern-btn" disabled>开始转换</button>
            </div>
        <?php } ?>
        <?php if (!empty($notice_content)) { ?>
            <div id="ai-sensevoice-notice">
                <div class="ai-sensevoice-notice-content"><?php echo wp_kses_post($notice_content); ?></div>
            </div>
        <?php } ?>
        <div id="ai-sensevoice-custom-alert" class="ai-sensevoice-custom-alert">
            <div class="ai-sensevoice-custom-alert-content">
                <span id="ai-sensevoice-custom-alert-message"></span>
                <button id="ai-sensevoice-custom-alert-close" class="ai-sensevoice-custom-alert-close">×</button>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * 注册 REST API
 */
add_action('rest_api_init', 'ai_sensevoice_register_api');
function ai_sensevoice_register_api() {
    register_rest_route('ai-sensevoice/v1', '/upload', [
        'methods' => 'POST',
        'callback' => 'ai_sensevoice_upload_audio',
        'permission_callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_forbidden', '请先登录', ['status' => 401]);
            }
            return wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest');
        }
    ]);

    register_rest_route('ai-sensevoice/v1', '/submit', [
        'methods' => 'POST',
        'callback' => 'ai_sensevoice_submit_task',
        'permission_callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_forbidden', '请先登录', ['status' => 401]);
            }
            $user_id = get_current_user_id();
            $limit_check = ai_sensevoice_check_daily_limit($user_id);
            if ($limit_check['exceeded']) {
                return new WP_Error('rest_forbidden', '今日转换次数已用完，请明天再来', ['status' => 403]);
            }
            return wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest');
        }
    ]);

    register_rest_route('ai-sensevoice/v1', '/result/(?P<task_id>[a-zA-Z0-9-]+)', [
        'methods' => 'GET',
        'callback' => 'ai_sensevoice_get_result',
        'permission_callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_forbidden', '请先登录', ['status' => 401]);
            }
            return wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest');
        }
    ]);
}

/**
 * 上传音频
 */
function ai_sensevoice_upload_audio($request) {
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    $files = $request->get_file_params();
    if (empty($files['audio_file'])) {
        return new WP_REST_Response(['success' => false, 'message' => '请上传音频文件'], 400);
    }

    $file = $files['audio_file'];
    $allowed_formats = array_map('trim', explode(',', get_option('ai_sensevoice_allowed_formats', 'mp3,wav,aac')));
    $max_size = get_option('ai_sensevoice_max_size', 3) * 1024 * 1024;

    if ($file['size'] > $max_size) {
        return new WP_REST_Response(['success' => false, 'message' => "文件太大，请上传 {$max_size}MB 以内的文件"], 400);
    }

    $file_name = strtolower($file['name']);
    $file_extension = pathinfo($file_name, PATHINFO_EXTENSION);
    if (!in_array($file_extension, $allowed_formats)) {
        return new WP_REST_Response(['success' => false, 'message' => "不支持的文件格式：{$file_extension}，请更换支持的格式"], 400);
    }

    $allowed_mime_types = [
        'mp3' => 'audio/mpeg',
        'wav' => 'audio/wav',
        'wav' => 'audio/x-wav',
        'aac' => 'audio/aac',
        'amr' => 'audio/amr',
        'flac' => 'audio/flac',
        'ogg' => 'audio/ogg',
        'opus' => 'audio/ogg',
        'm4a' => 'audio/mp4',
        'wma' => 'audio/x-ms-wma',
        'mp4' => 'video/mp4',
        'mkv' => 'video/x-matroska',
        'mov' => 'video/quicktime',
        'avi' => 'video/x-msvideo',
        'flv' => 'video/x-flv',
        'webm' => 'video/webm',
        'wmv' => 'video/x-ms-wmv',
    ];

    $declared_mime = strtolower($file['type']);
    $valid_mime = false;
    foreach ($allowed_mime_types as $ext => $mime) {
        if ($ext === $file_extension && ($declared_mime === $mime || ($ext === 'wav' && $declared_mime === 'audio/x-wav'))) {
            $valid_mime = true;
            break;
        }
    }
    if (!$valid_mime) {
        return new WP_REST_Response(['success' => false, 'message' => '文件声明的MIME类型无效：' . $declared_mime], 400);
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if (!$finfo) {
        return new WP_REST_Response(['success' => false, 'message' => '服务器配置错误：无法初始化文件检测'], 500);
    }
    $detected_mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    $valid_delta_mime = in_array($detected_mime, array_values($allowed_mime_types)) || $detected_mime === 'audio/x-wav';
    if (!$valid_delta_mime) {
        return new WP_REST_Response(['success' => false, 'message' => '文件不是有效的音频/视频文件，检测到MIME类型：' . $detected_mime], 400);
    }

    $upload_id = media_handle_upload('audio_file', 0);
    if (is_wp_error($upload_id)) {
        return new WP_REST_Response(['success' => false, 'message' => '上传失败: ' . $upload_id->get_error_message()], 500);
    }

    $audio_url = wp_get_attachment_url($upload_id);
    if (!$audio_url) {
        return new WP_REST_Response(['success' => false, 'message' => '无法获取上传文件的URL'], 500);
    }

    $file_size = round($file['size'] / 1024 / 1024, 2);
    return new WP_REST_Response([
        'success' => true,
        'audio_url' => $audio_url,
        'format' => $file_extension,
        'size' => $file_size
    ], 200);
}

/**
 * 提交转换任务
 */
function ai_sensevoice_submit_task($request) {
    $params = $request->get_json_params();
    if (!$params) {
        return new WP_REST_Response(['success' => false, 'message' => '无效请求数据'], 400);
    }

    $audio_url = $params['audio_url'] ?? '';
    $language = $params['language'] ?? 'auto';
    $disfluency_removal = isset($params['disfluency_removal']) ? filter_var($params['disfluency_removal'], FILTER_VALIDATE_BOOLEAN) : false;

    if (empty($audio_url)) {
        return new WP_REST_Response(['success' => false, 'message' => '缺少音频文件'], 400);
    }

    if (preg_match('/[\x{4e00}-\x{9fff}]/u', $audio_url)) {
        return new WP_REST_Response(['success' => false, 'message' => '音频URL不能包含中文字符'], 400);
    }

    $api_url = get_option('ai_sensevoice_api_url');
    $api_key = get_option('ai_sensevoice_api_key');
    $model = explode(',', get_option('ai_sensevoice_model_params', 'sensevoice-v1'))[0];

    if (empty($api_key)) {
        return new WP_REST_Response(['success' => false, 'message' => 'API Key 未配置'], 500);
    }

    $body = [
        'model' => $model,
        'input' => [
            'file_urls' => [$audio_url]
        ],
        'parameters' => [
            'channel_id' => [0],
            'disfluency_removal_enabled' => $disfluency_removal,
            'language_hints' => [$language]
        ]
    ];

    $response = wp_remote_post($api_url, [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'X-DashScope-Async' => 'enable',
            'Content-Type' => 'application/json'
        ],
        'body' => json_encode($body),
        'timeout' => 30
    ]);

    if (is_wp_error($response)) {
        return new WP_REST_Response(['success' => false, 'message' => 'API 请求失败: ' . $response->get_error_message()], 500);
    }

    $response_body = wp_remote_retrieve_body($response);
    $response_code = wp_remote_retrieve_response_code($response);
    $data = json_decode($response_body, true);

    if ($response_code !== 200 || !isset($data['output']['task_id'])) {
        $error_message = $data['message'] ?? '未知错误';
        $error_code = $data['code'] ?? 'Unknown';
        return new WP_REST_Response(['success' => false, 'message' => "API 错误: $error_message ($error_code)"], 500);
    }

    global $wpdb;
    $wpdb->insert($wpdb->prefix . 'sensevoice_tasks', [
        'user_id' => get_current_user_id(),
        'task_id' => $data['output']['task_id'],
        'audio_url' => $audio_url,
        'language' => $language,
        'status' => $data['output']['task_status']
    ]);

    return new WP_REST_Response([
        'success' => true,
        'task_id' => $data['output']['task_id']
    ], 200);
}

/**
 * 获取转换结果
 */
function ai_sensevoice_get_result($request) {
    $task_id = $request['task_id'];
    global $wpdb;
    $table_name = $wpdb->prefix . 'sensevoice_tasks';
    $task = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE task_id = %s", $task_id));

    if (!$task) {
        return new WP_REST_Response(['success' => false, 'message' => '任务不存在'], 404);
    }

    if ($task->result_text) {
        return new WP_REST_Response(['success' => true, 'result_text' => $task->result_text], 200);
    }

    $api_key = get_option('ai_sensevoice_api_key');
    $response = wp_remote_post("https://dashscope.aliyuncs.com/api/v1/tasks/$task_id", [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json'
        ],
        'timeout' => 15
    ]);

    if (is_wp_error($response)) {
        return new WP_REST_Response(['success' => false, 'message' => 'API 请求失败: ' . $response->get_error_message()], 500);
    }

    $response_body = wp_remote_retrieve_body($response);
    $response_code = wp_remote_retrieve_response_code($response);
    $data = json_decode($response_body, true);

    if ($response_code !== 200 || !isset($data['output'])) {
        $error_message = $data['message'] ?? '无法获取任务状态';
        $error_code = $data['code'] ?? 'Unknown';
        return new WP_REST_Response(['success' => false, 'message' => "API 错误: $error_message ($error_code)"], 500);
    }

    $task_status = $data['output']['task_status'];
    $wpdb->update($table_name, ['status' => $task_status], ['task_id' => $task_id]);

    if ($task_status === 'SUCCEEDED' && !empty($data['output']['results'][0]['transcription_url'])) {
        $transcription_url = $data['output']['results'][0]['transcription_url'];
        $transcription_response = wp_remote_get($transcription_url, ['timeout' => 15]);
        if (is_wp_error($transcription_response)) {
            return new WP_REST_Response(['success' => false, 'message' => '获取识别结果失败'], 500);
        }

        $transcription_data = json_decode(wp_remote_retrieve_body($transcription_response), true);
        $sentences = $transcription_data['transcripts'][0]['sentences'] ?? [];
        $formatted_text = '';
        if ($sentences) {
            foreach ($sentences as $sentence) {
                $text = $sentence['text'];
                // 移除特殊标记
                $text = preg_replace('/<\|.*?\|>/', '', $text);
                $text = preg_replace('/<\|.*?\|/', '', $text);
                $formatted_text .= $text . "\n";
            }
        }

        $wpdb->update($table_name, [
            'result_text' => $formatted_text,
            'status' => 'SUCCEEDED',
            'completed_at' => current_time('mysql')
        ], ['task_id' => $task_id]);

        return new WP_REST_Response(['success' => true, 'result_text' => $formatted_text], 200);
    } elseif ($task_status === 'FAILED') {
        $error_message = $data['output']['message'] ?? '转换失败';
        $error_code = $data['output']['code'] ?? 'Unknown';
        $wpdb->update($table_name, ['status' => 'FAILED'], ['task_id' => $task_id]);
        return new WP_REST_Response(['success' => false, 'message' => "转换失败: $error_message ($error_code)"], 500);
    } elseif ($task_status === 'UNKNOWN') {
        $wpdb->update($table_name, ['status' => 'UNKNOWN'], ['task_id' => $task_id]);
        return new WP_REST_Response(['success' => false, 'message' => '任务状态未知或不存在'], 404);
    }

    return new WP_REST_Response(['success' => false, 'message' => '任务尚未完成'], 202);
}
?>