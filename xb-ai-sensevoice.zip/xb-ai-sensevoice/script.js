/**
 * 语音转文字插件前端脚本
 */
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('ai-sensevoice-form');
    if (!form) return;

    let audioUrl = null;
    let audioFormat = '';
    let audioSize = 0;
    let selectedLanguage = 'auto';
    let disfluencyRemoval = false;
    let remainingCount = parseInt(document.getElementById('remaining-count')?.textContent || '0');
    const submitBtn = document.getElementById('ai-sensevoice-submit');
    const dragArea = document.getElementById('ai-sensevoice-drag-area');
    const uploadStatus = document.getElementById('ai-sensevoice-upload-status');
    const copyBtn = document.getElementById('ai-sensevoice-copy-btn');
    const clearBtn = document.getElementById('ai-sensevoice-clear-btn');
    const audioInput = document.getElementById('audio_file');
    const disfluencyToggle = document.getElementById('ai-sensevoice-disfluency-toggle');

    // Load saved preferences from localStorage
    function loadPreferences() {
        const savedLanguage = localStorage.getItem('ai_sensevoice_language');
        if (savedLanguage && aiSensevoice.supportedLanguages.includes(savedLanguage)) {
            selectedLanguage = savedLanguage;
            document.querySelectorAll('.ai-sensevoice-language-btn').forEach(btn => {
                btn.classList.toggle('active', btn.dataset.lang === savedLanguage);
            });
        }

        if (aiSensevoice.disfluencyRemovalEnabled) {
            const savedDisfluency = localStorage.getItem('ai_sensevoice_disfluency_removal');
            disfluencyRemoval = savedDisfluency === 'true';
            if (disfluencyToggle) {
                disfluencyToggle.checked = disfluencyRemoval;
                updateToggleButtonState();
            }
        }
    }

    // Save preferences to localStorage
    function savePreferences() {
        localStorage.setItem('ai_sensevoice_language', selectedLanguage);
        localStorage.setItem('ai_sensevoice_disfluency_removal', disfluencyRemoval);
    }

    // Update toggle button state
    function updateToggleButtonState() {
        const toggleBtn = document.querySelector('.ai-sensevoice-toggle-btn');
        if (toggleBtn) {
            toggleBtn.classList.toggle('active', disfluencyToggle.checked);
        }
    }

    // Initialize preferences
    loadPreferences();

    // Upload button event
    document.querySelectorAll('.ai-sensevoice-upload-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById(btn.dataset.target).click();
        });
    });

    // Toggle switch event
    if (disfluencyToggle) {
        document.querySelector('.ai-sensevoice-toggle-btn').addEventListener('click', () => {
            disfluencyToggle.checked = !disfluencyToggle.checked;
            disfluencyRemoval = disfluencyToggle.checked;
            updateToggleButtonState();
            savePreferences();
        });
    }

    // Drag and drop events
    if (dragArea) {
        dragArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            dragArea.classList.add('active');
        });
        dragArea.addEventListener('dragleave', () => {
            dragArea.classList.remove('active');
        });
        dragArea.addEventListener('drop', (e) => {
            e.preventDefault();
            dragArea.classList.remove('active');
            audioInput.files = e.dataTransfer.files;
            validateAndUpload(audioInput);
        });
    }

    // File upload handling
    if (audioInput) {
        audioInput.addEventListener('change', () => validateAndUpload(audioInput));
    }

    // Validate and upload file
    async function validateAndUpload(input) {
        const file = input.files[0];
        if (!file) {
            showCustomAlert('请选择音频文件');
            return;
        }

        const ext = file.name.split('.').pop().toLowerCase();
        if (!aiSensevoice.allowedFormats.includes(ext)) {
            showCustomAlert(`不支持的格式：${ext}，请使用 ${aiSensevoice.allowedFormats.join(', ')}`);
            input.value = '';
            return;
        }

        if (file.size > aiSensevoice.maxSize) {
            showCustomAlert(`文件太大，请上传 ${aiSensevoice.maxSize / 1024 / 1024}MB 以内的文件`);
            input.value = '';
            return;
        }

        const allowedMimeTypes = [
            'audio/mpeg', 'audio/wav', 'audio/aac', 'audio/amr', 'audio/flac', 
            'audio/ogg', 'audio/mp4', 'audio/x-ms-wma', 'video/mp4', 'video/x-matroska',
            'video/quicktime', 'video/x-msvideo', 'video/x-flv', 'video/webm', 'video/x-ms-wmv'
        ];
        if (!allowedMimeTypes.includes(file.type.toLowerCase())) {
            showCustomAlert('文件不是有效的音频/视频格式');
            input.value = '';
            return;
        }

        uploadAudio(input);
    }

    // Upload audio
    function uploadAudio(input) {
        uploadStatus.innerHTML = '<div class="ai-sensevoice-uploading">正在上传中<span class="ai-sensevoice-loading-dots"><span>.</span><span>.</span><span>.</span></span></div>';
        const formData = new FormData();
        formData.append('audio_file', input.files[0]);

        fetch(`${aiSensevoice.restUrl}/upload`, {
            method: 'POST',
            body: formData,
            headers: { 'X-WP-Nonce': aiSensevoice.nonce }
        })
        .then(response => {
            uploadStatus.innerHTML = '';
            return response.json().then(data => ({ status: response.status, data }));
        })
        .then(({ status, data }) => {
            if (status !== 200) {
                throw new Error(data.message || `上传失败 (HTTP ${status})`);
            }
            if (data.success) {
                audioUrl = data.audio_url;
                audioFormat = data.format;
                audioSize = data.size;
                document.getElementById('audio-info').innerHTML = `
                    <p>文件名称: ${input.files[0].name}</p>
                    <p>文件格式: ${audioFormat}</p>
                    <p>文件大小: ${audioSize} MB</p>
                    <audio controls src="${audioUrl}"></audio>
                `;
                uploadStatus.innerHTML = '<div class="ai-sensevoice-success">上传成功！</div>';
                setTimeout(() => { uploadStatus.innerHTML = ''; }, 3000);
                if (submitBtn) submitBtn.disabled = false;
            } else {
                throw new Error(data.message || '上传失败');
            }
        })
        .catch(error => {
            uploadStatus.innerHTML = '';
            showCustomAlert('上传失败: ' + error.message);
            input.value = '';
            if (submitBtn) submitBtn.disabled = true;
        });
    }

    // Language selection
    document.querySelectorAll('.ai-sensevoice-language-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.ai-sensevoice-language-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            selectedLanguage = btn.dataset.lang;
            savePreferences();
        });
    });

    // Submit conversion task
    if (submitBtn) {
        submitBtn.addEventListener('click', () => {
            if (!audioUrl) {
                showCustomAlert('请上传音频文件');
                return;
            }

            document.getElementById('ai-sensevoice-result-message').innerHTML = '<div class="ai-sensevoice-loading">正在转换中<span class="ai-sensevoice-loading-dots"><span>.</span><span>.</span><span>.</span></span></div>';

            fetch(`${aiSensevoice.restUrl}/submit`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': aiSensevoice.nonce
                },
                body: JSON.stringify({
                    audio_url: audioUrl,
                    language: selectedLanguage,
                    disfluency_removal: disfluencyRemoval
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    pollResult(data.task_id);
                    submitBtn.disabled = true;
                } else {
                    document.getElementById('ai-sensevoice-result-message').innerHTML = `<div class="ai-sensevoice-error">${data.message}</div>`;
                    submitBtn.disabled = false;
                }
            })
            .catch(() => {
                document.getElementById('ai-sensevoice-result-message').innerHTML = '<div class="ai-sensevoice-error">提交失败，请稍后再试</div>';
                submitBtn.disabled = false;
            });
        });
    }

    // Poll result
    function pollResult(task_id) {
        const interval = setInterval(() => {
            fetch(`${aiSensevoice.restUrl}/result/${task_id}`, {
                headers: { 'X-WP-Nonce': aiSensevoice.nonce }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('ai-sensevoice-result-message').innerHTML = '<div class="ai-sensevoice-success">转换成功！</div>';
                    document.getElementById('result-text').innerHTML = `
                        <div class="ai-sensevoice-result-content">${data.result_text.replace(/\n/g, '<br>')}</div>
                    `;
                    copyBtn.style.display = 'inline-block';
                    clearBtn.style.display = 'inline-block';
                    remainingCount--;
                    document.getElementById('remaining-count').textContent = remainingCount;
                    if (remainingCount <= 0) {
                        document.getElementById('ai-sensevoice-remaining-count').innerHTML = '今日使用次数已经用完了，请明天再来';
                        document.querySelector('.ai-sensevoice-main-area').style.display = 'none';
                        document.querySelector('.ai-sensevoice-submit-area').style.display = 'none';
                    }
                    setTimeout(() => { 
                        document.getElementById('ai-sensevoice-result-message').innerHTML = '';
                    }, 3000);
                    attachCopyEvent();
                    attachClearEvent();
                    clearInterval(interval);
                } else if (data.message !== '任务尚未完成') {
                    let errorMessage = data.message;
                    if (data.message.includes('InvalidFile.DecodeFailed')) {
                        errorMessage = '转换失败：无法解码文件，请检查文件编码是否正确';
                    }
                    document.getElementById('ai-sensevoice-result-message').innerHTML = `<div class="ai-sensevoice-error">${errorMessage}</div>`;
                    submitBtn.disabled = false;
                    clearInterval(interval);
                }
            })
            .catch(() => {
                document.getElementById('ai-sensevoice-result-message').innerHTML = '<div class="ai-sensevoice-error">获取结果失败，请稍后再试</div>';
                submitBtn.disabled = false;
                clearInterval(interval);
            });
        }, 5000);
    }

    // Copy result
    function attachCopyEvent() {
        copyBtn.addEventListener('click', () => {
            const text = document.querySelector('.ai-sensevoice-result-content').textContent;
            navigator.clipboard.writeText(text).then(() => {
                document.getElementById('ai-sensevoice-copy-message').innerHTML = '<div class="ai-sensevoice-success">转换结果已复制到剪贴板</div>';
                setTimeout(() => {
                    document.getElementById('ai-sensevoice-copy-message').innerHTML = '';
                }, 3000);
            }).catch(() => {
                showCustomAlert('复制失败，请手动复制');
            });
        }, { once: true });
    }

    // Clear content
    function attachClearEvent() {
        clearBtn.addEventListener('click', () => {
            audioInput.value = '';
            document.getElementById('audio-info').innerHTML = '';
            document.getElementById('result-text').innerHTML = '';
            document.getElementById('ai-sensevoice-result-message').innerHTML = '';
            document.getElementById('ai-sensevoice-copy-message').innerHTML = '';
            copyBtn.style.display = 'none';
            clearBtn.style.display = 'none';
            submitBtn.disabled = true;
            audioUrl = null;
        }, { once: true });
    }

    // Custom alert
    function showCustomAlert(message, duration = 3000) {
        const alertBox = document.getElementById('ai-sensevoice-custom-alert');
        const alertMessage = document.getElementById('ai-sensevoice-custom-alert-message');
        alertMessage.textContent = message;
        alertBox.classList.add('show');
        setTimeout(() => alertBox.classList.remove('show'), duration);
        document.getElementById('ai-sensevoice-custom-alert-close').addEventListener('click', () => {
            alertBox.classList.remove('show');
        }, { once: true });
    }

    // Login button event
    document.querySelectorAll('.ai-sensevoice-login-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const themeLoginBtn = document.querySelector('.nav-login .signin-loader');
            if (themeLoginBtn) {
                themeLoginBtn.click();
            } else {
                window.location.href = aiSensevoice.loginUrl;
            }
        });
    });
});