<?php
/*
Plugin Name: 小半经典台词
Description: 一个支持第三方接口和本地数据管理的经典台词插件，包含前台展示、后台设置、数据管理和台词类型选择功能。
Version: 1.1
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('AI_TAICI_VERSION', '1.1');
define('AI_TAICI_DIR', plugin_dir_path(__FILE__));
define('AI_TAICI_URL', plugin_dir_url(__FILE__));

// 激活插件时执行
register_activation_hook(__FILE__, 'ai_taici_activate');
function ai_taici_activate() {
    ai_taici_create_table();
    ai_taici_create_page();
}

// 创建数据库表
function ai_taici_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'taici';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        content TEXT NOT NULL,
        english TEXT DEFAULT '',
        source VARCHAR(255) DEFAULT '',
        type TINYINT(1) NOT NULL DEFAULT 1,
        image_url VARCHAR(255) DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // 初始化调用统计
    if (!get_option('ai_taici_stats')) {
        update_option('ai_taici_stats', [
            'total' => [
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ],
            'today' => [
                'date' => current_time('Y-m-d'),
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ]
        ]);
    }
}

// 创建前台页面
function ai_taici_create_page() {
    $pages = get_posts([
        'post_type' => 'page',
        'post_status' => 'publish',
        's' => '[ai_taici_display]',
        'numberposts' => 1,
    ]);

    if (empty($pages) && !get_option('ai_taici_page_id')) {
        $page = [
            'post_title' => '经典台词',
            'post_content' => '[ai_taici_display]',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        ];
        $page_id = wp_insert_post($page);
        update_option('ai_taici_page_id', $page_id);
    }
}

// 加载前端资源
function ai_taici_enqueue_assets() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'ai_taici_display')) {
        wp_enqueue_style('ai_taici_styles', AI_TAICI_URL . 'ai-taici.css', [], AI_TAICI_VERSION);
        wp_enqueue_script('ai_taici_scripts', AI_TAICI_URL . 'ai-taici.js', ['jquery'], AI_TAICI_VERSION, true);
        wp_localize_script('ai_taici_scripts', 'ai_taici_vars', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ai_taici_refresh')
        ]);
    }
}
add_action('wp_enqueue_scripts', 'ai_taici_enqueue_assets');

// 注册短代码
add_shortcode('ai_taici_display', 'ai_taici_display_page');
function ai_taici_display_page() {
    $options = get_option('ai_taici_settings', [
        'use_third_party' => 0,
        'api_url' => 'https://apis.tianapi.com/dialogue/index',
        'api_key' => '',
        'ad_content' => ''
    ]);

    $data = ['content' => '', 'english' => '', 'source' => '', 'image_url' => '', 'type' => 1];
    if ($options['use_third_party']) {
        $data = ai_taici_fetch_third_party();
    } else {
        $type = isset($_GET['taici_type']) && in_array($_GET['taici_type'], [0, 1]) ? intval($_GET['taici_type']) : 1;
        $data = ai_taici_fetch_local($type);
    }

    // 更新调用统计
    ai_taici_update_stats($options['use_third_party'], !empty($data['content']));

    // 构造复制内容，包含 source（如果存在）
    $copy_content = $data['content'] . "\n" . $data['english'];
    if (!empty($data['source'])) {
        $copy_content .= "\n出处：" . $data['source'];
    }

    ob_start();
    ?>
    <div class="ai_taici_container">
        <div class="ai_taici_title">经典台词</div>
        <div class="ai_taici_type_selector">
            <button class="ai_taici_type_button <?php echo $data['type'] == 1 ? 'active' : ''; ?>" data-type="1">华语</button>
            <button class="ai_taici_type_button <?php echo $data['type'] == 0 ? 'active' : ''; ?>" data-type="0">外语</button>
        </div>
        <div class="ai_taici_card">
            <div class="ai_taici_content" id="ai_taici_content"><?php echo esc_html($data['content']); ?></div>
            <div class="ai_taici_english" id="ai_taici_english"><?php echo esc_html($data['english']); ?></div>
            <div class="ai_taici_source" id="ai_taici_source"><?php echo !empty($data['source']) ? '出处：' . esc_html($data['source']) : ''; ?></div>
            <?php if ($data['image_url']): ?>
                <div class="ai_taici_image" id="ai_taici_image">
                    <img src="<?php echo esc_url($data['image_url']); ?>" alt="台词图片">
                </div>
            <?php else: ?>
                <div class="ai_taici_image" id="ai_taici_image"></div>
            <?php endif; ?>
        </div>
        <div class="ai_taici_buttons">
            <button class="ai_taici_refresh">换一个</button>
            <button class="ai_taici_copy" data-content="<?php echo esc_attr($copy_content); ?>">复制</button>
        </div>
        <div class="ai_taici_notice" id="ai_taici_notice"></div>
        <div class="ai_taici_ad"><?php echo wp_kses_post($options['ad_content']); ?></div>
    </div>
    <?php
    return ob_get_clean();
}

// 更新调用统计
function ai_taici_update_stats($use_third_party, $third_party_success) {
    $stats = get_option('ai_taici_stats', [
        'total' => [
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ],
        'today' => [
            'date' => current_time('Y-m-d'),
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ]
    ]);

    if ($stats['today']['date'] !== current_time('Y-m-d')) {
        $stats['today'] = [
            'date' => current_time('Y-m-d'),
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ];
    }

    if ($use_third_party) {
        $stats['total']['third_party_total']++;
        $stats['today']['third_party_total']++;
        if ($third_party_success) {
            $stats['total']['third_party_success']++;
            $stats['today']['third_party_success']++;
        }
    } else {
        $stats['total']['local_total']++;
        $stats['today']['local_total']++;
    }

    update_option('ai_taici_stats', $stats);
}

// AJAX 刷新台词
add_action('wp_ajax_ai_taici_refresh', 'ai_taici_refresh_callback');
function ai_taici_refresh_callback() {
    check_ajax_referer('ai_taici_refresh', 'nonce');
    $options = get_option('ai_taici_settings', ['use_third_party' => 0]);
    $type = isset($_POST['type']) && in_array($_POST['type'], ['0', '1']) ? intval($_POST['type']) : 1;
    $data = ['content' => '', 'english' => '', 'source' => '', 'image_url' => ''];

    if ($options['use_third_party']) {
        $data = ai_taici_fetch_third_party();
    } else {
        $seed = isset($_POST['_t']) ? intval($_POST['_t']) : time();
        $data = ai_taici_fetch_local($type, $seed);
    }

    // 构造复制内容
    $copy_content = $data['content'] . "\n" . $data['english'];
    if (!empty($data['source'])) {
        $copy_content .= "\n出处：" . $data['source'];
    }
    $data['copy_content'] = $copy_content;

    ai_taici_update_stats($options['use_third_party'], !empty($data['content']));
    wp_send_json_success($data);
}

// 获取第三方接口数据
function ai_taici_fetch_third_party() {
    $options = get_option('ai_taici_settings', [
        'api_url' => 'https://apis.tianapi.com/dialogue/index',
        'api_key' => ''
    ]);

    $args = [
        'method' => 'POST',
        'body' => ['key' => $options['api_key']],
        'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
        'timeout' => 10,
    ];

    $response = wp_remote_request($options['api_url'], $args);
    if (is_wp_error($response)) {
        return ['content' => '', 'english' => '', 'source' => '', 'image_url' => '', 'type' => 1];
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['code']) && $data['code'] == 200 && isset($data['result']['dialogue'])) {
        return [
            'content' => $data['result']['dialogue'],
            'english' => $data['result']['english'] ?? '',
            'source' => $data['result']['source'] ?? '',
            'image_url' => '',
            'type' => $data['result']['type'] ?? 1
        ];
    }
    return ['content' => '', 'english' => '', 'source' => '', 'image_url' => '', 'type' => 1];
}

// 获取本地数据
function ai_taici_fetch_local($type = 1, $seed = null) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'taici';

    $ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM $table_name WHERE type = %d", $type));
    if (empty($ids)) {
        return [
            'content' => '暂无台词数据，请在后台添加！',
            'english' => '',
            'source' => '',
            'image_url' => '',
            'type' => $type
        ];
    }

    $seed = $seed ?? time();
    mt_srand($seed);
    $random_id = $ids[mt_rand(0, count($ids) - 1)];

    $result = $wpdb->get_row(
        $wpdb->prepare("SELECT content, english, source, image_url, type FROM $table_name WHERE id = %d", $random_id),
        ARRAY_A
    );

    return $result ?? [
        'content' => '暂无台词数据，请在后台添加！',
        'english' => '',
        'source' => '',
        'image_url' => '',
        'type' => $type
    ];
}

// 后台菜单
add_action('admin_menu', 'ai_taici_admin_menu');
function ai_taici_admin_menu() {
    add_menu_page('经典台词设置', '经典台词', 'manage_options', 'ai-taici-settings', 'ai_taici_settings_page', 'dashicons-format-quote');
    add_submenu_page('ai-taici-settings', '数据管理', '数据管理', 'manage_options', 'ai-taici-data', 'ai_taici_data_page');
}

// 设置页面
function ai_taici_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['ai_taici_save_settings'])) {
        check_admin_referer('ai_taici_settings');
        $settings = [
            'use_third_party' => isset($_POST['ai_taici_use_third_party']) ? 1 : 0,
            'api_url' => sanitize_text_field($_POST['ai_taici_api_url']),
            'api_key' => sanitize_text_field($_POST['ai_taici_api_key']),
            'ad_content' => wp_kses_post($_POST['ai_taici_ad_content'])
        ];
        update_option('ai_taici_settings', $settings);
        echo '<div class="notice notice-success is-dismissible ai_taici_notice"><p>设置已保存。</p></div>';
    }

    if (isset($_POST['ai_taici_clear_stats'])) {
        check_admin_referer('ai_taici_clear_stats');
        update_option('ai_taici_stats', [
            'total' => [
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ],
            'today' => [
                'date' => current_time('Y-m-d'),
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ]
        ]);
        echo '<div class="notice notice-success is-dismissible ai_taici_notice"><p>调用统计已清空。</p></div>';
    }

    $options = get_option('ai_taici_settings', [
        'use_third_party' => 0,
        'api_url' => 'https://apis.tianapi.com/dialogue/index',
        'api_key' => '',
        'ad_content' => ''
    ]);

    $stats = get_option('ai_taici_stats', [
        'total' => [
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ],
        'today' => [
            'date' => current_time('Y-m-d'),
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ]
    ]);

    ?>
    <div class="wrap">
        <h1>小半经典台词设置</h1>
        <form method="post" action="">
            <?php wp_nonce_field('ai_taici_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="ai_taici_use_third_party">使用第三方接口</label></th>
                    <td><input type="checkbox" name="ai_taici_use_third_party" id="ai_taici_use_third_party" <?php checked($options['use_third_party'], 1); ?>></td>
                </tr>
                <tr>
                    <th><label for="ai_taici_api_url">API 接口地址</label></th>
                    <td><input type="text" name="ai_taici_api_url" id="ai_taici_api_url" value="<?php echo esc_attr($options['api_url']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="ai_taici_api_key">API 密钥</label></th>
                    <td><input type="text" name="ai_taici_api_key" id="ai_taici_api_key" value="<?php echo esc_attr($options['api_key']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="ai_taici_ad_content">广告内容</label></th>
                    <td><textarea name="ai_taici_ad_content" id="ai_taici_ad_content" rows="5" class="large-text"><?php echo esc_textarea($options['ad_content']); ?></textarea></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="ai_taici_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        <p>第三方接口: https://www.tianapi.com/apiview/183 </p>
        <h2>调用统计</h2>
        <h3>总计</h3>
        <p>第三方接口总调用次数: <?php echo esc_html($stats['total']['third_party_total']); ?></p>
        <p>第三方接口成功调用次数: <?php echo esc_html($stats['total']['third_party_success']); ?></p>
        <p>本地接口调用次数: <?php echo esc_html($stats['total']['local_total']); ?></p>
        <h3>今日 (<?php echo esc_html($stats['today']['date']); ?>)</h3>
        <p>第三方接口总调用次数: <?php echo esc_html($stats['today']['third_party_total']); ?></p>
        <p>第三方接口成功调用次数: <?php echo esc_html($stats['today']['third_party_success']); ?></p>
        <p>本地接口调用次数: <?php echo esc_html($stats['today']['local_total']); ?></p>
        <form method="post" action="">
            <?php wp_nonce_field('ai_taici_clear_stats'); ?>
            <p class="submit"><input type="submit" name="ai_taici_clear_stats" class="button-secondary" value="清空统计" onclick="return confirm('确定清空所有调用统计？');"></p>
        </form>
    </div>
    <?php
}

// 数据管理页面
function ai_taici_data_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'taici';

    // 处理添加
    if (isset($_POST['ai_taici_add_data'])) {
        check_admin_referer('ai_taici_data');
        $content = sanitize_text_field($_POST['ai_taici_content']);
        $english = sanitize_text_field($_POST['ai_taici_english']);
        $source = sanitize_text_field($_POST['ai_taici_source']);
        $type = in_array($_POST['ai_taici_type'], ['0', '1']) ? intval($_POST['ai_taici_type']) : 1;
        $image_url = esc_url_raw($_POST['ai_taici_image_url']);
        $wpdb->insert($table_name, [
            'content' => $content,
            'english' => $english,
            'source' => $source,
            'type' => $type,
            'image_url' => $image_url
        ]);
        echo '<div class="notice notice-success is-dismissible ai_taici_notice"><p>数据已添加。</p></div>';
    }

    // 处理编辑
    if (isset($_POST['ai_taici_edit_data'])) {
        check_admin_referer('ai_taici_edit_data');
        $id = intval($_POST['ai_taici_edit_id']);
        $content = sanitize_text_field($_POST['ai_taici_content']);
        $english = sanitize_text_field($_POST['ai_taici_english']);
        $source = sanitize_text_field($_POST['ai_taici_source']);
        $type = in_array($_POST['ai_taici_type'], ['0', '1']) ? intval($_POST['ai_taici_type']) : 1;
        $image_url = esc_url_raw($_POST['ai_taici_image_url']);
        $wpdb->update($table_name, [
            'content' => $content,
            'english' => $english,
            'source' => $source,
            'type' => $type,
            'image_url' => $image_url
        ], ['id' => $id]);
        echo '<div class="notice notice-success is-dismissible ai_taici_notice"><p>数据已更新。</p></div>';
    }

    // 处理删除
    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
        check_admin_referer('ai_taici_delete_' . $_GET['id']);
        $wpdb->delete($table_name, ['id' => intval($_GET['id'])]);
        echo '<div class="notice notice-success is-dismissible ai_taici_notice"><p>数据已删除。</p></div>';
    }

    // 处理删除全部
    if (isset($_POST['ai_taici_delete_all'])) {
        check_admin_referer('ai_taici_delete_all');
        $wpdb->query("TRUNCATE TABLE $table_name");
        echo '<div class="notice notice-success is-dismissible ai_taici_notice"><p>所有数据已删除。</p></div>';
    }

    // 获取编辑数据
    $edit_item = null;
    if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
        $edit_item = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", intval($_GET['id'])), ARRAY_A);
    }

    // 分页
    $per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;
    $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $total_pages = ceil($total_items / $per_page);
    $items = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC LIMIT $offset, $per_page", ARRAY_A);

    ?>
    <div class="wrap">
        <h1>经典台词数据管理</h1>
        
        <!-- 添加数据表单 -->
        <h2>添加新数据</h2>
        <form method="post" action="">
            <?php wp_nonce_field('ai_taici_data'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="ai_taici_content_add">台词内容</label></th>
                    <td><input type="text" name="ai_taici_content" id="ai_taici_content_add" value="" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="ai_taici_english_add">英文翻译</label></th>
                    <td><input type="text" name="ai_taici_english" id="ai_taici_english_add" value="" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="ai_taici_source_add">出处</label></th>
                    <td><input type="text" name="ai_taici_source" id="ai_taici_source_add" value="" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="ai_taici_type_add">台词类型</label></th>
                    <td>
                        <select name="ai_taici_type" id="ai_taici_type_add">
                            <option value="1">华语</option>
                            <option value="0">外语</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="ai_taici_image_url_add">图片 URL</label></th>
                    <td><input type="url" name="ai_taici_image_url" id="ai_taici_image_url_add" value="" class="regular-text"></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="ai_taici_add_data" class="button-primary" value="添加数据"></p>
        </form>

        <!-- 编辑数据表单 -->
        <?php if ($edit_item): ?>
            <h2>编辑数据</h2>
            <form method="post" action="">
                <?php wp_nonce_field('ai_taici_edit_data'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="ai_taici_content_edit">台词内容</label></th>
                        <td><input type="text" name="ai_taici_content" id="ai_taici_content_edit" value="<?php echo esc_attr($edit_item['content']); ?>" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="ai_taici_english_edit">英文翻译</label></th>
                        <td><input type="text" name="ai_taici_english" id="ai_taici_english_edit" value="<?php echo esc_attr($edit_item['english']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="ai_taici_source_edit">出处</label></th>
                        <td><input type="text" name="ai_taici_source" id="ai_taici_source_edit" value="<?php echo esc_attr($edit_item['source']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="ai_taici_type_edit">台词类型</label></th>
                        <td>
                            <select name="ai_taici_type" id="ai_taici_type_edit">
                                <option value="1" <?php selected($edit_item['type'], 1); ?>>华语</option>
                                <option value="0" <?php selected($edit_item['type'], 0); ?>>外语</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="ai_taici_image_url_edit">图片 URL</label></th>
                        <td><input type="url" name="ai_taici_image_url" id="ai_taici_image_url_edit" value="<?php echo esc_url($edit_item['image_url']); ?>" class="regular-text"></td>
                    </tr>
                </table>
                <input type="hidden" name="ai_taici_edit_id" value="<?php echo esc_attr($edit_item['id']); ?>">
                <p class="submit"><input type="submit" name="ai_taici_edit_data" class="button-primary" value="更新数据"></p>
            </form>
        <?php endif; ?>

        <!-- 删除所有数据 -->
        <form method="post" action="">
            <?php wp_nonce_field('ai_taici_delete_all'); ?>
            <p class="submit"><input type="submit" name="ai_taici_delete_all" class="button-secondary" value="删除所有数据" onclick="return confirm('确定删除所有数据？');"></p>
        </form>

        <!-- 数据列表 -->
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>台词内容</th>
                    <th>英文翻译</th>
                    <th>出处</th>
                    <th>类型</th>
                    <th>图片 URL</th>
                    <th>创建时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td><?php echo esc_html($item['content']); ?></td>
                        <td><?php echo esc_html($item['english']); ?></td>
                        <td><?php echo esc_html($item['source']); ?></td>
                        <td><?php echo $item['type'] == 1 ? '华语' : '外语'; ?></td>
                        <td><?php echo esc_url($item['image_url']); ?></td>
                        <td><?php echo esc_html($item['created_at']); ?></td>
                        <td>
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ai-taici-data&action=edit&id=' . $item['id']), 'ai_taici_edit_' . $item['id']); ?>">编辑</a> |
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ai-taici-data&action=delete&id=' . $item['id']), 'ai_taici_delete_' . $item['id']); ?>" onclick="return confirm('确定删除？');">删除</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- 分页 -->
        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links([
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => '«',
                'next_text' => '»',
                'total' => $total_pages,
                'current' => $current_page
            ]);
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}

// 后台通知自动消失脚本
add_action('admin_footer', 'ai_taici_admin_scripts');
function ai_taici_admin_scripts() {
    ?>
    <script>
    jQuery(document).ready(function($) {
        setTimeout(function() {
            $('.ai_taici_notice').fadeOut('slow');
        }, 3000);
    });
    </script>
    <?php
}
?>