jQuery(document).ready(function($) {
    // 刷新台词按钮点击事件
    $('.ai_taici_refresh').on('click', function() {
        var $button = $(this);
        $button.prop('disabled', true);
        $('#ai_taici_content, #ai_taici_english, #ai_taici_source, #ai_taici_image').css('opacity', '0');

        var type = $('.ai_taici_type_button.active').data('type') || 1;

        $.ajax({
            url: ai_taici_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'ai_taici_refresh',
                nonce: ai_taici_vars.nonce,
                type: type,
                _t: new Date().getTime()
            },
            cache: false,
            success: function(response) {
                if (response.success) {
                    $('#ai_taici_content').text(response.data.content).css('opacity', '1');
                    $('#ai_taici_english').text(response.data.english).css('opacity', '1');
                    $('#ai_taici_source').text(response.data.source ? '出处：' + response.data.source : '').css('opacity', '1');
                    if (response.data.image_url) {
                        $('#ai_taici_image').html('<img src="' + response.data.image_url + '" alt="台词图片">').css('opacity', '1');
                    } else {
                        $('#ai_taici_image').empty().css('opacity', '1');
                    }
                    $('.ai_taici_copy').data('content', response.data.copy_content);
                } else {
                    $('#ai_taici_notice').text('刷新失败：' + (response.data.message || '未知错误')).show();
                    setTimeout(function() {
                        $('#ai_taici_notice').fadeOut('slow', function() {
                            $(this).empty();
                        });
                    }, 3000);
                }
                $button.prop('disabled', false);
            },
            error: function() {
                $('#ai_taici_content, #ai_taici_english, #ai_taici_source, #ai_taici_image').css('opacity', '1');
                $button.prop('disabled', false);
                $('#ai_taici_notice').text('网络错误，请稍后再试！').show();
                setTimeout(function() {
                    $('#ai_taici_notice').fadeOut('slow', function() {
                        $(this).empty();
                    });
                }, 3000);
            }
        });
    });

    // 复制台词文字按钮点击事件
    $('.ai_taici_copy').on('click', function() {
        var content = $(this).data('content');
        var $button = $(this);
        var $notice = $('#ai_taici_notice');

        navigator.clipboard.writeText(content).then(function() {
            $button.addClass('copied').text('已复制');
            $notice.empty();
            setTimeout(function() {
                $button.removeClass('copied').text('复制');
            }, 2000);
        }).catch(function() {
            $notice.text('复制失败，请手动复制！').show();
            setTimeout(function() {
                $notice.fadeOut('slow', function() {
                    $notice.empty();
                });
            }, 3000);
        });
    });

    // 类型切换按钮事件
    $('.ai_taici_type_button').on('click', function() {
        var $button = $(this);
        var type = $button.data('type');
        
        // 切换 active 状态
        $('.ai_taici_type_button').removeClass('active');
        $button.addClass('active');

        // 更新 URL 参数
        var url = new URL(window.location.href);
        url.searchParams.set('taici_type', type);
        window.location.href = url.toString();
    });
});