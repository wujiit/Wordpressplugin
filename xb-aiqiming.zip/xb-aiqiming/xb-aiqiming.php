<?php
/*
Plugin Name: AI起名
Description: 基于AI的智能起名工具，支持个性化起名需求，包含用户次数管理和多种配置选项。
Version: 1.2.0
Author: Summer
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xb_aiqiming_activate');
function xb_aiqiming_activate() {
    xb_aiqiming_create_database();
    xb_aiqiming_create_front_page();
}

// 创建数据库表
function xb_aiqiming_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 用户使用次数表
    $usage_table = $wpdb->prefix . 'xb_aiqiming_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        device_id varchar(255) NOT NULL,
        usage_date date NOT NULL,
        usage_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_device_date (user_id, device_id, usage_date)
    ) $charset_collate;";

    // 用户记录表
    $records_table = $wpdb->prefix . 'xb_aiqiming_records';
    $records_sql = "CREATE TABLE $records_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        device_id varchar(255) NOT NULL,
        surname varchar(50) NOT NULL,
        middle_char varchar(50) DEFAULT NULL,
        requirements text DEFAULT NULL,
        gender varchar(20) NOT NULL,
        name_length int(11) NOT NULL,
        name_count int(11) NOT NULL,
        model_name varchar(100) DEFAULT NULL,
        enable_search tinyint(1) DEFAULT 0,
        ai_response longtext DEFAULT NULL,
        status varchar(20) NOT NULL,
        error_message text DEFAULT NULL,
        create_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($usage_sql);
    dbDelta($records_sql);
}

// 创建前台页面
function xb_aiqiming_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_aiqiming_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => 'AI起名',
            'post_content' => '[xb_aiqiming_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 生成设备指纹
function xb_aiqiming_generate_device_id() {
    $user_agent = !empty($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : 'Unknown';
    $ip_address = !empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : 'Unknown';
    $accept_language = !empty($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? sanitize_text_field($_SERVER['HTTP_ACCEPT_LANGUAGE']) : 'Unknown';
    $raw_string = $user_agent . $ip_address . $accept_language;
    return hash('sha256', $raw_string);
}

// 获取设备ID（优先从Cookie获取，失效则生成新的）
function xb_aiqiming_get_device_id() {
    $cookie_name = 'xb_aiqiming_device_id';
    $device_id = isset($_COOKIE[$cookie_name]) ? sanitize_text_field($_COOKIE[$cookie_name]) : null;

    if (!$device_id) {
        $device_id = xb_aiqiming_generate_device_id();
        // 设置365天有效期的Cookie
        setcookie($cookie_name, $device_id, time() + (365 * 24 * 60 * 60), '/');
    }

    return $device_id;
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_aiqiming_enqueue_scripts');
function xb_aiqiming_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_aiqiming_form')) {
        wp_enqueue_style('xb_aiqiming_styles', plugins_url('xb-aiqiming.css', __FILE__), array(), '1.2.0');
        wp_enqueue_script('xb_aiqiming_scripts', plugins_url('xb-aiqiming.js', __FILE__), array('jquery'), '1.2.0', true);

        wp_localize_script('xb_aiqiming_scripts', 'xb_aiqiming_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => rest_url('xb_aiqiming/v1/generate'),
            'nonce'    => wp_create_nonce('wp_rest'),
            'login_url' => wp_login_url(get_permalink()),
            'is_logged_in' => is_user_logged_in() ? 1 : 0,
        ));
    }
}

// 短代码
add_shortcode('xb_aiqiming_form', 'xb_aiqiming_form_shortcode');
function xb_aiqiming_form_shortcode() {
    $ad_content = get_option('xb_aiqiming_ad_content', '');
    $default_limit = absint(get_option('xb_aiqiming_default_limit', 10));
    $guest_limit = absint(get_option('xb_aiqiming_guest_limit', 5));
    $show_stats = get_option('xb_aiqiming_show_stats', 1);
    $guest_enabled = get_option('xb_aiqiming_guest_enabled', 1);
    $enable_model_selection = get_option('xb_aiqiming_enable_model_selection', 0);
    $enable_search = get_option('xb_aiqiming_enable_search', 0);
    $gender_options = get_option('xb_aiqiming_gender_options', '男,女');
    $models = array_filter(array_map('trim', explode(',', get_option('xb_aiqiming_models', 'qwen-plus'))));

    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $today = current_time('Y-m-d');
    $device_id = xb_aiqiming_get_device_id();

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aiqiming_usage';

    // 已登录用户按 user_id 和日期查询，忽略设备信息
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
                $user_id, $today
            )
        );
    } else {
        // 游客按 user_id、device_id 和日期查询
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND device_id = %s AND usage_date = %s",
                $user_id, $device_id, $today
            )
        );
    }

    $usage_count = $row ? absint($row->usage_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : ($user_id ? $default_limit : $guest_limit);
    $remaining = max(0, $user_limit - $usage_count);
    $stats_text = "今日剩余起名次数：{$remaining}/{$user_limit}";

    // 判断是否显示起名区域
    $show_form = true;
    $disable_reason = '';

    if (!is_user_logged_in() && !$guest_enabled) {
        $show_form = false;
        $disable_reason = 'guest_disabled';
    } elseif (!is_user_logged_in() && $usage_count >= $user_limit) {
        $show_form = false;
        $disable_reason = 'guest_limit_exceeded';
    } elseif (is_user_logged_in() && $usage_count >= $user_limit) {
        $show_form = false;
        $disable_reason = 'user_limit_exceeded';
    }

    ob_start();
    ?>
    <div class="xb_aiqiming_container">
        <div class="xb_aiqiming_header">
            <div class="xb_aiqiming_title">AI宝宝起名</div>
            <p class="xb_aiqiming_subtitle">智能起名，寓意美好</p>
        </div>

        <div class="xb_aiqiming_content">
            <div class="xb_aiqiming_form_section">
                <div class="xb_aiqiming_section_title">✨ 起名配置</div>
                
                <?php if (!$show_form) { ?>
                    <div class="xb_aiqiming_message xb_aiqiming_message_info">
                        <?php if ($disable_reason === 'guest_disabled') { ?>
                            <div class="xb_aiqiming_message_icon">🚫</div>
                            <div class="xb_aiqiming_message_content">
                                <div class="xb_aiqiming_ts_subtitle">游客功能已关闭</div>
                                <p>管理员已关闭游客使用功能，请登录后继续使用。</p>
                                <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xb_aiqiming_login_btn">立即登录</a>
                            </div>
                        <?php } elseif ($disable_reason === 'guest_limit_exceeded') { ?>
                            <div class="xb_aiqiming_message_icon">⏰</div>
                            <div class="xb_aiqiming_message_content">
                                <div class="xb_aiqiming_ts_subtitle">游客的使用次数已经用完，请登录之后继续。</div>
                                <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xb_aiqiming_login_btn">立即登录</a>
                            </div>
                        <?php } elseif ($disable_reason === 'user_limit_exceeded') { ?>
                            <div class="xb_aiqiming_message_icon">📅</div>
                            <div class="xb_aiqiming_message_content">
                                <div class="xb_aiqiming_ts_subtitle">今日使用次数已经用完，请明天再来。</div>
                            </div>
                        <?php } ?>
                    </div>
                <?php } else { ?>
                    <form id="xb_aiqiming_form" method="post">
                        <!-- 姓氏和中间字一行 -->
                        <div class="xb_aiqiming_form_row">
                            <div class="xb_aiqiming_form_group xb_aiqiming_form_half">
                                <label for="xb_aiqiming_surname">姓氏：</label>
                                <input type="text" id="xb_aiqiming_surname" name="surname" required maxlength="10" placeholder="请输入姓氏">
                            </div>
                            <div class="xb_aiqiming_form_group xb_aiqiming_form_half">
                                <label for="xb_aiqiming_middle_char">中间辈分汉字（可选）：</label>
                                <input type="text" id="xb_aiqiming_middle_char" name="middle_char" maxlength="10" placeholder="如：龙、志等">
                            </div>
                        </div>

                        <!-- 起名要求一行 -->
                        <div class="xb_aiqiming_form_group">
                            <label for="xb_aiqiming_requirements">起名要求（可选）：</label>
                            <textarea id="xb_aiqiming_requirements" name="requirements" maxlength="100" rows="3" placeholder="如：参考《山海经》的内容，要大气，好记"></textarea>
                            <div class="xb_aiqiming_char_count">0/100</div>
                        </div>

                        <!-- 性别选项一行 -->
                        <div class="xb_aiqiming_form_group">
                            <label>性别：</label>
                            <div class="xb_aiqiming_radio_group">
                                <?php 
                                $genders = array_filter(array_map('trim', explode(',', $gender_options)));
                                foreach ($genders as $index => $gender) { ?>
                                    <label class="xb_aiqiming_radio_option">
                                        <input type="radio" name="gender" value="<?php echo esc_attr($gender); ?>" <?php echo $index === 0 ? 'checked' : ''; ?>>
                                        <span><?php echo esc_html($gender); ?></span>
                                    </label>
                                <?php } ?>
                            </div>
                        </div>

                        <!-- 名字字数和起名数量一行 -->
                        <div class="xb_aiqiming_form_row">
                            <div class="xb_aiqiming_form_group xb_aiqiming_form_half">
                                <label for="xb_aiqiming_name_length">名字字数：</label>
                                <select id="xb_aiqiming_name_length" name="name_length">
                                    <option value="2">2个字</option>
                                    <option value="3" selected>3个字</option>
                                    <option value="4">4个字</option>
                                </select>
                            </div>
                            <div class="xb_aiqiming_form_group xb_aiqiming_form_half">
                                <label for="xb_aiqiming_name_count">起名数量：</label>
                                <select id="xb_aiqiming_name_count" name="name_count">
                                    <option value="5" selected>5个</option>
                                    <option value="10">10个</option>
                                    <option value="15">15个</option>
                                    <option value="20">20个</option>
                                </select>
                            </div>
                        </div>

                        <!-- AI模型和联网搜索一行 -->
                        <?php if ($enable_model_selection && count($models) > 1 || $enable_search) { ?>
                        <div class="xb_aiqiming_form_row">
                            <?php if ($enable_model_selection && count($models) > 1) { ?>
                            <div class="xb_aiqiming_form_group <?php echo $enable_search ? 'xb_aiqiming_form_half' : ''; ?>">
                                <label for="xb_aiqiming_model">AI模型：</label>
                                <select id="xb_aiqiming_model" name="model">
                                    <?php foreach ($models as $model) { ?>
                                        <option value="<?php echo esc_attr($model); ?>"><?php echo esc_html($model); ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <?php } ?>

                            <?php if ($enable_search) { ?>
                            <div class="xb_aiqiming_form_group <?php echo ($enable_model_selection && count($models) > 1) ? 'xb_aiqiming_form_half' : ''; ?>">
                                <label>&nbsp;</label> <!-- 占位标签保持对齐 -->
                                <label class="xb_aiqiming_checkbox_option">
                                    <input type="checkbox" id="xb_aiqiming_enable_search" name="enable_search" value="1">
                                    <span>启用联网搜索</span>
                                </label>
                            </div>
                            <?php } ?>
                        </div>
                        <?php } ?>

                        <button type="submit" class="xb_aiqiming_submit_button" id="xb_aiqiming_submit_button">
                            <span class="xb_aiqiming_button_icon">🚀</span>
                            开始起名
                        </button>

                        <?php if (is_user_logged_in()) { ?>
                            <input type="hidden" name="xb_aiqiming_nonce" value="<?php echo wp_create_nonce('xb_aiqiming_nonce'); ?>">
                        <?php } ?>
                    </form>
                <?php } ?>
            </div>
            
            <div class="xb_aiqiming_result_section">
                <div class="xb_aiqiming_section_title">📋 起名结果</div>
                
                <div class="xb_aiqiming_result_actions" style="display:none;">
                    <button id="xb_aiqiming_regenerate_button" class="xb_aiqiming_action_button">
                        <span class="xb_aiqiming_button_icon">🔄</span>
                        换一批
                    </button>
                    <button id="xb_aiqiming_copy_button" class="xb_aiqiming_action_button">
                        <span class="xb_aiqiming_button_icon">📋</span>
                        复制结果
                    </button>
                    <button id="xb_aiqiming_clear_button" class="xb_aiqiming_action_button">
                        <span class="xb_aiqiming_button_icon">🗑️</span>
                        清空内容
                    </button>
                </div>

                <div id="xb_aiqiming_result"></div>
                
                <?php if ($show_stats && $show_form) { ?>
                    <div class="xb_aiqiming_usage_info">
                        <span class="xb_aiqiming_usage_icon">📊</span>
                        <span id="xb_aiqiming_usage_text"><?php echo esc_html($stats_text); ?></span>
                    </div>
                <?php } ?>
            </div>
        </div>
        
        <?php if (!empty($ad_content)) { ?>
            <div class="xb_aiqiming_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
        <?php } ?>
    </div>
    <?php
    return ob_get_clean();
}

// 注册 REST API 端点
add_action('rest_api_init', 'xb_aiqiming_register_rest_routes');
function xb_aiqiming_register_rest_routes() {
    register_rest_route('xb_aiqiming/v1', '/generate', array(
        'methods' => 'POST',
        'callback' => 'xb_aiqiming_handle_logged_generate',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ));
}

// 处理登录用户起名
function xb_aiqiming_handle_logged_generate(WP_REST_Request $request) {
    $data = json_decode($request->get_body(), true);
    
    // 验证必填字段
    if (empty($data['surname']) || empty($data['gender']) || empty($data['name_length']) || empty($data['name_count'])) {
        return new WP_REST_Response(array('message' => '请填写完整的起名信息'), 400);
    }

    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $device_id = xb_aiqiming_get_device_id();

    // 检查使用次数
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aiqiming_usage';
    $default_limit = absint(get_option('xb_aiqiming_default_limit', 10));
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
            $user_id, $today
        )
    );
    $usage_count = $row ? absint($row->usage_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;

    if ($usage_count >= $user_limit) {
        return new WP_REST_Response(array('message' => '今日使用次数已经用完，请明天再来。'), 403);
    }

    // 检查违规词
    $forbidden_words = get_option('xb_aiqiming_forbidden_words', '');
    if (!empty($forbidden_words) && !empty($data['requirements'])) {
        $words = array_filter(array_map('trim', explode(',', $forbidden_words)));
        foreach ($words as $word) {
            if (stripos($data['requirements'], $word) !== false) {
                return new WP_REST_Response(array('message' => '输入内容包含违规词，请重新输入'), 400);
            }
        }
    }

    $result = xb_aiqiming_call_api($data, $user_id, $device_id, $today);
    return new WP_REST_Response($result, $result['success'] ? 200 : 400);
}

// 处理游客起名
add_action('wp_ajax_nopriv_xb_aiqiming_guest_generate', 'xb_aiqiming_handle_guest_generate');
function xb_aiqiming_handle_guest_generate() {
    // 验证必填字段
    if (empty($_POST['surname']) || empty($_POST['gender']) || empty($_POST['name_length']) || empty($_POST['name_count'])) {
        wp_send_json_error(array('message' => '请填写完整的起名信息'));
    }

    // 检查游客是否允许使用
    $guest_enabled = get_option('xb_aiqiming_guest_enabled', 1);
    if (!$guest_enabled) {
        wp_send_json_error(array('message' => '游客功能已关闭，请登录后使用'));
    }

    $user_id = 0;
    $today = current_time('Y-m-d');
    $device_id = xb_aiqiming_get_device_id();

    // 检查游客使用次数
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aiqiming_usage';
    $guest_limit = absint(get_option('xb_aiqiming_guest_limit', 5));
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND device_id = %s AND usage_date = %s",
            $user_id, $device_id, $today
        )
    );

    $usage_count = $row ? absint($row->usage_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $guest_limit;

    if ($usage_count >= $user_limit) {
        wp_send_json_error(array('message' => '游客的使用次数已经用完，请登录之后继续。'));
    }

    // 检查违规词
    $forbidden_words = get_option('xb_aiqiming_forbidden_words', '');
    if (!empty($forbidden_words) && !empty($_POST['requirements'])) {
        $words = array_filter(array_map('trim', explode(',', $forbidden_words)));
        foreach ($words as $word) {
            if (stripos($_POST['requirements'], $word) !== false) {
                wp_send_json_error(array('message' => '输入内容包含违规词，请重新输入'));
            }
        }
    }

    $data = array(
        'surname' => sanitize_text_field($_POST['surname']),
        'middle_char' => sanitize_text_field($_POST['middle_char']),
        'requirements' => sanitize_textarea_field($_POST['requirements']),
        'gender' => sanitize_text_field($_POST['gender']),
        'name_length' => absint($_POST['name_length']),
        'name_count' => absint($_POST['name_count']),
        'model' => sanitize_text_field($_POST['model']),
        'enable_search' => isset($_POST['enable_search']) ? 1 : 0,
    );

    $result = xb_aiqiming_call_api($data, $user_id, $device_id, $today);
    
    if ($result['success']) {
        wp_send_json_success($result);
    } else {
        wp_send_json_error($result);
    }
}

// API 调用
function xb_aiqiming_call_api($data, $user_id, $device_id, $today) {
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aiqiming_records';

    $api_url = get_option('xb_aiqiming_api_url', 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions');
    $api_key = get_option('xb_aiqiming_api_key', '');
    $models = array_filter(array_map('trim', explode(',', get_option('xb_aiqiming_models', 'qwen-plus'))));
    $model = !empty($data['model']) ? $data['model'] : $models[0];

    if (empty($api_key)) {
        return array('success' => false, 'message' => '暂时无法起名请联系客服');
    }

    // 构建提示词
    $total_chars = absint($data['name_length']);
    $surname = $data['surname'];
    $middle_char = !empty($data['middle_char']) ? $data['middle_char'] : '';
    
    $prompt = "你是一个专业的起名师。现在需要为宝宝起名，请严格按照以下要求：

";
    $prompt .= "基本信息：
";
    $prompt .= "- 姓氏：{$surname}
";
    if (!empty($middle_char)) {
        $prompt .= "- 中间字：{$middle_char}
";
    }
    $prompt .= "- 性别：{$data['gender']}
";
    $prompt .= "- 名字总字数：{$total_chars}个字（这是包含姓氏的完整名字字数）
";
    $prompt .= "- 需要起名数量：{$data['name_count']}个
";
    
    if (!empty($data['requirements'])) {
        $prompt .= "- 特殊要求：{$data['requirements']}
";
    }
    
    $prompt .= "
重要提醒：
";
    if (!empty($middle_char)) {
        $remaining_chars = $total_chars - mb_strlen($surname) - mb_strlen($middle_char);
        $prompt .= "- 姓氏「{$surname}」占" . mb_strlen($surname) . "个字
";
        $prompt .= "- 中间字「{$middle_char}」占" . mb_strlen($middle_char) . "个字
";
        $prompt .= "- 你需要再起{$remaining_chars}个字来组成完整的{$total_chars}字名字
";
        $prompt .= "- 完整格式应该是：{$surname}{$middle_char}XX（总共{$total_chars}个字）
";
    } else {
        $remaining_chars = $total_chars - mb_strlen($surname);
        $prompt .= "- 姓氏「{$surname}」占" . mb_strlen($surname) . "个字
";
        $prompt .= "- 你需要再起{$remaining_chars}个字来组成完整的{$total_chars}字名字
";
        $prompt .= "- 完整格式应该是：{$surname}XX（总共{$total_chars}个字）
";
    }
    
    $prompt .= "
请直接回复{$data['name_count']}个名字，每个名字后面跟一个简短解释（20字以内）。格式如下：
";
    $prompt .= "1. [完整名字] - [简短解释]
";
    $prompt .= "2. [完整名字] - [简短解释]
";
    $prompt .= "...

";
    $prompt .= "务必确保每个名字都是{$total_chars}个字！";

    // 构建请求数据
    $request_data = array(
        'model' => $model,
        'messages' => array(
            array(
                'role' => 'system',
                'content' => '你是一个专业的起名专家，擅长根据用户需求起出寓意美好的名字。'
            ),
            array(
                'role' => 'user',
                'content' => $prompt
            )
        ),
        'stream' => true,
        'temperature' => 0.7
    );

    // 如果启用联网搜索
    if (!empty($data['enable_search'])) {
        $request_data['enable_search'] = true;
    }

    // 记录到数据库
    $insert_data = array(
        'user_id' => $user_id,
        'device_id' => $device_id,
        'surname' => $data['surname'],
        'middle_char' => $data['middle_char'],
        'requirements' => $data['requirements'],
        'gender' => $data['gender'],
        'name_length' => $data['name_length'],
        'name_count' => $data['name_count'],
        'model_name' => $model,
        'enable_search' => !empty($data['enable_search']) ? 1 : 0,
        'status' => 'pending',
        'create_time' => current_time('mysql'),
    );

    $args = array(
        'method' => 'POST',
        'timeout' => 30,
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json',
        ),
        'body' => json_encode($request_data),
    );

    $response = wp_remote_request($api_url, $args);
    
    if (is_wp_error($response)) {
        $insert_data['status'] = 'failed';
        $insert_data['error_message'] = $response->get_error_message();
        $wpdb->insert($records_table, $insert_data);
        return array('success' => false, 'message' => '暂时无法起名请联系客服');
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);

    if ($status_code >= 400) {
        $insert_data['status'] = 'failed';
        $insert_data['error_message'] = 'HTTP ' . $status_code;
        $wpdb->insert($records_table, $insert_data);
        return array('success' => false, 'message' => '暂时无法起名请联系客服');
    }

    // 处理流式响应
    $lines = explode("\n", $body);
    $content = '';
    
    foreach ($lines as $line) {
        $line = trim($line);
        if (strpos($line, 'data: ') === 0) {
            $json_str = substr($line, 6);
            if ($json_str === '[DONE]') {
                break;
            }
            
            $data_obj = json_decode($json_str, true);
            if (isset($data_obj['choices'][0]['delta']['content'])) {
                $content .= $data_obj['choices'][0]['delta']['content'];
            }
        }
    }

    if (empty($content)) {
        $insert_data['status'] = 'failed';
        $insert_data['error_message'] = '接口返回空内容';
        $wpdb->insert($records_table, $insert_data);
        return array('success' => false, 'message' => '暂时无法起名请联系客服');
    }

    // 成功，更新使用次数
    $usage_table = $wpdb->prefix . 'xb_aiqiming_usage';
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
                $user_id, $today
            )
        );
        $usage_count = $row ? absint($row->usage_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : absint(get_option('xb_aiqiming_default_limit', 10));

        $existing_row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id FROM $usage_table WHERE user_id = %d AND device_id = %s AND usage_date = %s LIMIT 1",
                $user_id, $device_id, $today
            )
        );
        if ($existing_row) {
            $wpdb->update(
                $usage_table,
                array('usage_count' => $usage_count + 1),
                array('id' => $existing_row->id),
                array('%d'),
                array('%d')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'device_id' => $device_id,
                    'usage_date' => $today,
                    'usage_count' => 1,
                    'custom_limit' => null,
                )
            );
        }
    } else {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND device_id = %s AND usage_date = %s",
                $user_id, $device_id, $today
            )
        );
        $usage_count = $row ? absint($row->usage_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : absint(get_option('xb_aiqiming_guest_limit', 5));

        if ($usage_count > 0) {
            $wpdb->update(
                $usage_table,
                array('usage_count' => $usage_count + 1),
                array('user_id' => $user_id, 'device_id' => $device_id, 'usage_date' => $today),
                array('%d'),
                array('%d', '%s', '%s')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'device_id' => $device_id,
                    'usage_date' => $today,
                    'usage_count' => 1,
                    'custom_limit' => null,
                )
            );
        }
    }

    $insert_data['status'] = 'success';
    $insert_data['ai_response'] = $content;
    $wpdb->insert($records_table, $insert_data);

    $remaining = $user_limit - ($usage_count + 1);
    
    return array(
        'success' => true,
        'content' => $content,
        'remaining' => $remaining,
        'limit' => $user_limit
    );
}

// 添加管理菜单
add_action('admin_menu', 'xb_aiqiming_admin_menu');
function xb_aiqiming_admin_menu() {
    add_menu_page(
        'AI起名设置',
        'AI起名',
        'manage_options',
        'xb_aiqiming_settings',
        'xb_aiqiming_settings_page',
        'dashicons-admin-users',
        80
    );
    add_submenu_page(
        'xb_aiqiming_settings',
        '用户记录',
        '用户记录',
        'manage_options',
        'xb_aiqiming_records',
        'xb_aiqiming_records_page'
    );
}

// 插件设置页面
function xb_aiqiming_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['xb_aiqiming_save_settings'])) {
        check_admin_referer('xb_aiqiming_settings_nonce');
        
        update_option('xb_aiqiming_api_url', sanitize_text_field($_POST['xb_aiqiming_api_url']));
        update_option('xb_aiqiming_api_key', sanitize_text_field($_POST['xb_aiqiming_api_key']));
        update_option('xb_aiqiming_models', sanitize_text_field($_POST['xb_aiqiming_models']));
        update_option('xb_aiqiming_default_limit', absint($_POST['xb_aiqiming_default_limit']));
        update_option('xb_aiqiming_guest_limit', absint($_POST['xb_aiqiming_guest_limit']));
        update_option('xb_aiqiming_show_stats', isset($_POST['xb_aiqiming_show_stats']) ? 1 : 0);
        update_option('xb_aiqiming_guest_enabled', isset($_POST['xb_aiqiming_guest_enabled']) ? 1 : 0);
        update_option('xb_aiqiming_enable_model_selection', isset($_POST['xb_aiqiming_enable_model_selection']) ? 1 : 0);
        update_option('xb_aiqiming_enable_search', isset($_POST['xb_aiqiming_enable_search']) ? 1 : 0);
        update_option('xb_aiqiming_forbidden_words', sanitize_text_field($_POST['xb_aiqiming_forbidden_words']));
        update_option('xb_aiqiming_gender_options', sanitize_text_field($_POST['xb_aiqiming_gender_options']));
        
        $allowed_html = array(
            'a' => array('href' => array(), 'title' => array(), 'target' => array()),
            'img' => array('src' => array(), 'alt' => array(), 'width' => array(), 'height' => array()),
            'p' => array(),
            'div' => array('class' => array(), 'style' => array()),
            'span' => array('class' => array(), 'style' => array()),
            'strong' => array(),
            'em' => array(),
            'br' => array()
        );
        update_option('xb_aiqiming_ad_content', wp_kses($_POST['xb_aiqiming_ad_content'], $allowed_html));
        
        echo '<div class="updated xb_aiqiming_auto_hide_message"><p>设置已保存！</p></div>';
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aiqiming_records';
    $stats = array(
        'total_records' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table"),
        'success_records' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE status = 'success'"),
        'failed_records' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE status = 'failed'"),
        'today_records' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE DATE(create_time) = %s", current_time('Y-m-d')))
    );

    ?>
    <div class="wrap">
        <h1>AI起名设置</h1>
        <form method="post">
            <?php wp_nonce_field('xb_aiqiming_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_aiqiming_api_url">API 接口地址</label></th>
                    <td><input type="text" name="xb_aiqiming_api_url" id="xb_aiqiming_api_url" value="<?php echo esc_attr(get_option('xb_aiqiming_api_url', 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_aiqiming_api_key">API 密钥</label></th>
                    <td><input type="text" name="xb_aiqiming_api_key" id="xb_aiqiming_api_key" value="<?php echo esc_attr(get_option('xb_aiqiming_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_aiqiming_models">AI模型</label></th>
                    <td>
                        <input type="text" name="xb_aiqiming_models" id="xb_aiqiming_models" value="<?php echo esc_attr(get_option('xb_aiqiming_models', 'qwen-plus')); ?>" class="regular-text">
                        <p class="description">多个模型用英文逗号分隔，如：qwen-plus,qwen-turbo</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aiqiming_default_limit">登录用户每日使用次数</label></th>
                    <td><input type="number" name="xb_aiqiming_default_limit" id="xb_aiqiming_default_limit" value="<?php echo esc_attr(get_option('xb_aiqiming_default_limit', 10)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_aiqiming_guest_limit">游客每日使用次数</label></th>
                    <td><input type="number" name="xb_aiqiming_guest_limit" id="xb_aiqiming_guest_limit" value="<?php echo esc_attr(get_option('xb_aiqiming_guest_limit', 5)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_aiqiming_gender_options">性别选项</label></th>
                    <td>
                        <input type="text" name="xb_aiqiming_gender_options" id="xb_aiqiming_gender_options" value="<?php echo esc_attr(get_option('xb_aiqiming_gender_options', '男,女')); ?>" class="regular-text">
                        <p class="description">多个选项用英文逗号分隔，如：男,女</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aiqiming_forbidden_words">违规词设置</label></th>
                    <td>
                        <input type="text" name="xb_aiqiming_forbidden_words" id="xb_aiqiming_forbidden_words" value="<?php echo esc_attr(get_option('xb_aiqiming_forbidden_words')); ?>" class="regular-text">
                        <p class="description">多个违规词用英文逗号分隔</p>
                    </td>
                </tr>
                <tr>
                    <th>功能开关</th>
                    <td>
                        <label><input type="checkbox" name="xb_aiqiming_guest_enabled" <?php checked(get_option('xb_aiqiming_guest_enabled', 1), 1); ?> value="1"> 允许游客使用</label><br>
                        <label><input type="checkbox" name="xb_aiqiming_show_stats" <?php checked(get_option('xb_aiqiming_show_stats', 1), 1); ?> value="1"> 显示统计信息</label><br>
                        <label><input type="checkbox" name="xb_aiqiming_enable_model_selection" <?php checked(get_option('xb_aiqiming_enable_model_selection', 0), 1); ?> value="1"> 启用前台模型选择</label><br>
                        <label><input type="checkbox" name="xb_aiqiming_enable_search" <?php checked(get_option('xb_aiqiming_enable_search', 0), 1); ?> value="1"> 启用联网搜索功能</label>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aiqiming_ad_content">公告内容</label></th>
                    <td>
                        <textarea name="xb_aiqiming_ad_content" id="xb_aiqiming_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_aiqiming_ad_content')); ?></textarea>
                        <p class="description">支持 HTML 格式。</p>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="xb_aiqiming_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        
        <div class="xb_aiqiming_stats">
            <h3>统计信息</h3>
            <p>总起名次数：<?php echo esc_html($stats['total_records'] ?: 0); ?></p>
            <p>成功起名次数：<?php echo esc_html($stats['success_records'] ?: 0); ?></p>
            <p>失败起名次数：<?php echo esc_html($stats['failed_records'] ?: 0); ?></p>
            <p>今日起名次数：<?php echo esc_html($stats['today_records'] ?: 0); ?></p>
        </div>
    </div>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aiqiming_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}

// 用户记录页面
function xb_aiqiming_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aiqiming_records';
    $usage_table = $wpdb->prefix . 'xb_aiqiming_usage';
    $user_id = isset($_POST['xb_aiqiming_user_id']) ? absint($_POST['xb_aiqiming_user_id']) : '';
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    // 一键删除所有记录
    if (isset($_POST['xb_aiqiming_delete_all_records'])) {
        check_admin_referer('xb_aiqiming_delete_all_records_nonce');
        $wpdb->query("TRUNCATE TABLE $records_table");
        echo '<div class="updated xb_aiqiming_auto_hide_message"><p>所有记录已删除！</p></div>';
    }

    // 删除指定用户记录
    if (isset($_POST['xb_aiqiming_delete_user_records']) && $user_id !== '') {
        check_admin_referer('xb_aiqiming_delete_user_records_nonce');
        $wpdb->delete($records_table, array('user_id' => $user_id), array('%d'));
        echo '<div class="updated xb_aiqiming_auto_hide_message"><p>用户记录已删除！</p></div>';
    }

    // 设置用户自定义使用次数
    if (isset($_POST['xb_aiqiming_set_user_limit']) && $user_id !== '') {
        check_admin_referer('xb_aiqiming_set_user_limit_nonce');
        $custom_limit = isset($_POST['xb_aiqiming_custom_limit']) ? absint($_POST['xb_aiqiming_custom_limit']) : null;
        
        // 获取今天的记录
        $today = current_time('Y-m-d');
        $existing_row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id FROM $usage_table WHERE user_id = %d AND usage_date = %s LIMIT 1",
                $user_id, $today
            )
        );
        
        if ($existing_row) {
            // 更新现有记录
            $wpdb->update(
                $usage_table,
                array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
                array('id' => $existing_row->id),
                array('%d'),
                array('%d')
            );
        } else {
            // 创建新记录
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'device_id' => 'admin_set',
                    'usage_date' => $today,
                    'usage_count' => 0,
                    'custom_limit' => $custom_limit === 0 ? null : $custom_limit,
                )
            );
        }
        
        echo '<div class="updated xb_aiqiming_auto_hide_message"><p>用户使用次数限制已设置！</p></div>';
    }

    // 重置用户使用次数
    if (isset($_POST['xb_aiqiming_reset_user_usage']) && $user_id !== '') {
        check_admin_referer('xb_aiqiming_reset_user_usage_nonce');
        $wpdb->delete($usage_table, array('user_id' => $user_id), array('%d'));
        echo '<div class="updated xb_aiqiming_auto_hide_message"><p>用户使用次数已重置！</p></div>';
    }

    $offset = ($paged - 1) * $per_page;
    
    if ($user_id !== '') {
        $query = $wpdb->prepare("SELECT * FROM $records_table WHERE user_id = %d ORDER BY create_time DESC LIMIT %d, %d", $user_id, $offset, $per_page);
        $total_records = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE user_id = %d", $user_id));
    } else {
        $query = $wpdb->prepare("SELECT * FROM $records_table ORDER BY create_time DESC LIMIT %d, %d", $offset, $per_page);
        $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $records_table");
    }
    
    $records = $wpdb->get_results($query);
    $total_pages = ceil($total_records / $per_page);

    ?>
    <div class="wrap">
        <h1>用户记录</h1>
        
        <div style="margin-bottom: 20px;">
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('xb_aiqiming_delete_all_records_nonce'); ?>
                <input type="submit" name="xb_aiqiming_delete_all_records" class="button-secondary" value="一键删除所有记录" onclick="return confirm('确定删除所有记录吗？');">
            </form>
        </div>

        <form method="post">
            <p>
                <label for="xb_aiqiming_user_id">用户 ID（0 表示游客，留空显示所有记录）：</label>
                <input type="number" name="xb_aiqiming_user_id" id="xb_aiqiming_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <?php if ($user_id !== '') { ?>
            <?php
            // 获取用户当前的使用次数设置
            $today = current_time('Y-m-d');
            $user_usage_row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
                    $user_id, $today
                )
            );
            $current_usage = $user_usage_row ? $user_usage_row->usage_count : 0;
            $current_custom_limit = $user_usage_row && $user_usage_row->custom_limit !== null ? $user_usage_row->custom_limit : null;
            $default_limit = $user_id == 0 ? get_option('xb_aiqiming_guest_limit', 5) : get_option('xb_aiqiming_default_limit', 10);
            $effective_limit = $current_custom_limit !== null ? $current_custom_limit : $default_limit;
            ?>
            
            <div style="background: #fff; padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid #0073aa;">
                <h3>用户 ID: <?php echo esc_html($user_id == 0 ? '游客' : $user_id); ?> 的使用情况</h3>
                <p><strong>今日已使用：</strong><?php echo esc_html($current_usage); ?> 次</p>
                <p><strong>当前限制：</strong><?php echo esc_html($effective_limit); ?> 次/天 
                    <?php if ($current_custom_limit !== null) { ?>
                        <span style="color: #d63638;">(自定义)</span>
                    <?php } else { ?>
                        <span style="color: #135e96;">(默认)</span>
                    <?php } ?>
                </p>
                
                <form method="post" style="margin-top: 15px;">
                    <?php wp_nonce_field('xb_aiqiming_set_user_limit_nonce'); ?>
                    <input type="hidden" name="xb_aiqiming_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <label for="xb_aiqiming_custom_limit">设置专属使用次数（0表示使用默认值）：</label>
                    <input type="number" name="xb_aiqiming_custom_limit" id="xb_aiqiming_custom_limit" 
                           value="<?php echo esc_attr($current_custom_limit !== null ? $current_custom_limit : 0); ?>" 
                           min="0" max="999" style="width: 80px;">
                    <input type="submit" name="xb_aiqiming_set_user_limit" class="button-primary" value="设置限制">
                </form>
            </div>
            
            <div style="margin-bottom: 20px;">
                <form method="post" style="display:inline;">
                    <?php wp_nonce_field('xb_aiqiming_delete_user_records_nonce'); ?>
                    <input type="hidden" name="xb_aiqiming_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_aiqiming_delete_user_records" class="button-secondary" value="删除当前用户记录" onclick="return confirm('确定删除当前用户所有记录吗？');">
                </form>
                <form method="post" style="display:inline; margin-left: 10px;">
                    <?php wp_nonce_field('xb_aiqiming_reset_user_usage_nonce'); ?>
                    <input type="hidden" name="xb_aiqiming_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_aiqiming_reset_user_usage" class="button-secondary" value="重置使用次数" onclick="return confirm('确定重置当前用户的使用次数吗？');">
                </form>
            </div>
        <?php } ?>

        <table class="widefat">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>用户ID</th>
                    <th>设备ID</th>
                    <th>姓氏</th>
                    <th>中间字</th>
                    <th>要求</th>
                    <th>性别</th>
                    <th>字数</th>
                    <th>数量</th>
                    <th>状态</th>
                    <th>创建时间</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)) { ?>
                    <tr><td colspan="11">暂无记录。</td></tr>
                <?php } else { ?>
                    <?php foreach ($records as $record) { ?>
                        <tr>
                            <td><?php echo esc_html($record->id); ?></td>
                            <td><?php echo esc_html($record->user_id == 0 ? '游客' : $record->user_id); ?></td>
                            <td><?php echo esc_html($record->device_id ?: '-'); ?></td>
                            <td><?php echo esc_html($record->surname); ?></td>
                            <td><?php echo esc_html($record->middle_char ?: '-'); ?></td>
                            <td><?php echo esc_html($record->requirements ? substr($record->requirements, 0, 30) . '...' : '-'); ?></td>
                            <td><?php echo esc_html($record->gender); ?></td>
                            <td><?php echo esc_html($record->name_length); ?></td>
                            <td><?php echo esc_html($record->name_count); ?></td>
                            <td><?php echo esc_html($record->status); ?></td>
                            <td><?php echo esc_html($record->create_time); ?></td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aiqiming_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}
?>