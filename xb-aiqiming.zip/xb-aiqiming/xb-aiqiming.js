jQuery(document).ready(function ($) {
    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('XB AIQIMING: jQuery 未加载！');
        $('#xb_aiqiming_result').html('<div class="xb_aiqiming_message xb_aiqiming_message_error">脚本加载失败，请刷新页面！</div>');
        return;
    }

    // 确保 xb_aiqiming_ajax 配置
    if (typeof xb_aiqiming_ajax === 'undefined') {
        console.error('XB AIQIMING: xb_aiqiming_ajax 未定义！');
        $('#xb_aiqiming_result').html('<div class="xb_aiqiming_message xb_aiqiming_message_error">脚本配置失败，请检查插件设置！</div>');
        return;
    }

    let currentFormData = null;
    let isGenerating = false;

    // 字符计数器
    $('#xb_aiqiming_requirements').on('input', function() {
        const length = $(this).val().length;
        $('.xb_aiqiming_char_count').text(length + '/100');
        
        if (length > 100) {
            $(this).val($(this).val().substring(0, 100));
            $('.xb_aiqiming_char_count').text('100/100');
        }
    });

    // 表单提交处理
    $('#xb_aiqiming_form').on('submit', function (e) {
        e.preventDefault();
        
        if (isGenerating) {
            return;
        }

        const formData = getFormData();
        if (!validateFormData(formData)) {
            return;
        }

        currentFormData = formData;
        generateNames(formData);
    });

    // 获取表单数据
    function getFormData() {
        return {
            surname: $('#xb_aiqiming_surname').val().trim(),
            middle_char: $('#xb_aiqiming_middle_char').val().trim(),
            requirements: $('#xb_aiqiming_requirements').val().trim(),
            gender: $('input[name="gender"]:checked').val(),
            name_length: $('#xb_aiqiming_name_length').val(),
            name_count: $('#xb_aiqiming_name_count').val(),
            model: $('#xb_aiqiming_model').val() || '',
            enable_search: $('#xb_aiqiming_enable_search').is(':checked') ? 1 : 0
        };
    }

    // 验证表单数据
    function validateFormData(data) {
        if (!data.surname) {
            showError('请输入姓氏');
            return false;
        }

        if (!data.gender) {
            showError('请选择性别');
            return false;
        }

        return true;
    }

    // 生成名字
    function generateNames(data) {
        isGenerating = true;
        
        // 更新按钮状态
        $('#xb_aiqiming_submit_button')
            .prop('disabled', true)
            .html('<span class="xb_aiqiming_button_icon">⏳</span>起名中...');

        // 显示加载动画
        showLoadingMessage();
        
        // 隐藏操作按钮
        $('.xb_aiqiming_result_actions').hide();

        if (xb_aiqiming_ajax.is_logged_in == 1) {
            // 登录用户使用 REST API
            handleLoggedUserGenerate(data);
        } else {
            // 游客使用 AJAX
            handleGuestGenerate(data);
        }
    }

    // 处理登录用户生成
    function handleLoggedUserGenerate(data) {
        $.ajax({
            url: xb_aiqiming_ajax.rest_url,
            type: 'POST',
            data: JSON.stringify(data),
            contentType: 'application/json',
            headers: { 'X-WP-Nonce': xb_aiqiming_ajax.nonce },
            success: function (response) {
                if (response.success && response.content) {
                    displayStreamingResult(response.content);
                    updateUsageInfo(response.remaining, response.limit);
                    
                    // 检查是否用完次数
                    if (response.remaining <= 0) {
                        hideFormAndShowMessage(false);
                    }
                } else {
                    showError(response.message || '暂时无法起名请联系客服');
                }
                resetGenerateButton();
            },
            error: function (xhr) {
                const message = xhr.responseJSON && xhr.responseJSON.message ? 
                    xhr.responseJSON.message : '暂时无法起名请联系客服';
                showError(message);
                resetGenerateButton();
            }
        });
    }

    // 处理游客生成
    function handleGuestGenerate(data) {
        $.ajax({
            url: xb_aiqiming_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_aiqiming_guest_generate',
                ...data
            },
            success: function (response) {
                if (response.success && response.data.content) {
                    displayStreamingResult(response.data.content);
                    updateUsageInfo(response.data.remaining, response.data.limit);
                    
                    // 检查是否用完次数
                    if (response.data.remaining <= 0) {
                        hideFormAndShowMessage(true);
                    }
                } else {
                    showError(response.data.message || '暂时无法起名请联系客服');
                }
                resetGenerateButton();
            },
            error: function (xhr) {
                const message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ? 
                    xhr.responseJSON.data.message : '暂时无法起名请联系客服';
                showError(message);
                resetGenerateButton();
            }
        });
    }

    // 显示流式结果
    function displayStreamingResult(content) {
        const resultHtml = '<div class="xb_aiqiming_result_content">' + 
            content.replace(/\n/g, '<br>') + '</div>';
        
        $('#xb_aiqiming_result').html(resultHtml);
        $('.xb_aiqiming_result_actions').show();
        
        // 模拟流式输出效果
        const $content = $('.xb_aiqiming_result_content');
        $content.addClass('xb_aiqiming_streaming');
        
        setTimeout(function() {
            $content.removeClass('xb_aiqiming_streaming');
        }, 1000);
    }

    // 显示加载信息
    function showLoadingMessage() {
        $('#xb_aiqiming_result').html(
            '<div class="xb_aiqiming_loading">' +
            '<div class="xb_aiqiming_spinner"></div>' +
            '<div class="xb_aiqiming_ts_subtitle">🤖 AI正在起名中</div>' +
            '<p>请稍候，AI正在为您精心挑选寓意美好的名字...</p>' +
            '</div>'
        );
    }

    // 显示错误信息
    function showError(message) {
        $('#xb_aiqiming_result').html(
            '<div class="xb_aiqiming_message xb_aiqiming_message_error">' +
            '<span class="xb_aiqiming_message_icon">❌</span>' + message + 
            '</div>'
        );
        $('.xb_aiqiming_result_actions').show();
    }

    // 重置生成按钮
    function resetGenerateButton() {
        isGenerating = false;
        $('#xb_aiqiming_submit_button')
            .prop('disabled', false)
            .html('<span class="xb_aiqiming_button_icon">🚀</span>开始起名');
    }

    // 更新使用次数信息
    function updateUsageInfo(remaining, limit) {
        const isGuest = xb_aiqiming_ajax.is_logged_in == 0;
        let text;
        
        if (remaining > 0) {
            text = `今日剩余起名次数：${remaining}/${limit}`;
        } else {
            if (isGuest) {
                text = '游客的使用次数已经用完，请登录之后继续。';
            } else {
                text = '今日使用次数已经用完，请明天再来。';
            }
        }
        
        $('#xb_aiqiming_usage_text').text(text);
    }

    // 隐藏表单并显示相应消息
    function hideFormAndShowMessage(isGuest) {
        $('#xb_aiqiming_form').fadeOut(300, function() {
            let message;
            if (isGuest) {
                message = 
                    '<div class="xb_aiqiming_message xb_aiqiming_message_info">' +
                    '<div class="xb_aiqiming_message_icon">🔐</div>' +
                    '<div class="xb_aiqiming_message_content">' +
                    '<div class="xb_aiqiming_ts_subtitle">游客的使用次数已经用完，请登录之后继续。</div>' +
                    '<a href="' + xb_aiqiming_ajax.login_url + '" class="xb_aiqiming_login_btn">' +
                    '<span class="xb_aiqiming_button_icon">🚀</span>立即登录' +
                    '</a>' +
                    '</div>' +
                    '</div>';
            } else {
                message = 
                    '<div class="xb_aiqiming_message xb_aiqiming_message_info">' +
                    '<div class="xb_aiqiming_message_icon">📅</div>' +
                    '<div class="xb_aiqiming_message_content">' +
                    '<div class="xb_aiqiming_ts_subtitle">今日使用次数已经用完，请明天再来。</div>' +
                    '</div>' +
                    '</div>';
            }
            $('.xb_aiqiming_form_section').append(message);
        });
    }

    // 换一批按钮
    $('#xb_aiqiming_regenerate_button').on('click', function(e) {
        e.preventDefault();
        
        if (currentFormData && !isGenerating) {
            generateNames(currentFormData);
        }
    });

    // 复制结果按钮
    $('#xb_aiqiming_copy_button').on('click', function(e) {
        e.preventDefault();
        
        const $button = $(this);
        const originalText = $button.html();
        const content = $('.xb_aiqiming_result_content').text();
        
        if (content) {
            // 使用现代浏览器的 Clipboard API
            if (navigator.clipboard) {
                navigator.clipboard.writeText(content).then(function() {
                    showCopySuccess($button, originalText);
                }).catch(function() {
                    fallbackCopyText(content, $button, originalText);
                });
            } else {
                fallbackCopyText(content, $button, originalText);
            }
        }
    });

    // 备用复制方法
    function fallbackCopyText(text, $button, originalText) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
            showCopySuccess($button, originalText);
        } catch (err) {
            $button.html('<span class="xb_aiqiming_button_icon">❌</span>复制失败');
            setTimeout(function() {
                $button.html(originalText);
            }, 2000);
        }
        
        document.body.removeChild(textArea);
    }

    // 显示复制成功
    function showCopySuccess($button, originalText) {
        $button.html('<span class="xb_aiqiming_button_icon">✅</span>已复制');
        setTimeout(function() {
            $button.html(originalText);
        }, 2000);
    }

    // 清空内容按钮
    $('#xb_aiqiming_clear_button').on('click', function(e) {
        e.preventDefault();
        
        $('#xb_aiqiming_result').empty();
        $('.xb_aiqiming_result_actions').hide();
        currentFormData = null;
        
        // 检查是否有使用次数限制消息
        const hasLimitMessage = $('.xb_aiqiming_form_section .xb_aiqiming_message').length > 0;
        
        // 如果没有限制消息，重置表单
        if (!hasLimitMessage) {
            resetForm();
        }
    });

    // 重置表单
    function resetForm() {
        $('#xb_aiqiming_form')[0].reset();
        $('.xb_aiqiming_char_count').text('0/100');
        // 重新选择第一个性别选项
        $('input[name="gender"]:first').prop('checked', true);
        currentFormData = null;
    }

    // 显示临时消息（保留用于其他用途）
    function showTemporaryMessage(message) {
        const $message = $('<div class="xb_aiqiming_temp_message" style="position:fixed;top:20px;right:20px;background:#48bb78;color:white;padding:1rem;border-radius:8px;z-index:9999;box-shadow:0 4px 12px rgba(0,0,0,0.15);">' + message + '</div>');
        $('body').append($message);
        
        setTimeout(function() {
            $message.fadeOut(300, function() {
                $message.remove();
            });
        }, 2000);
    }

    // 快速登录处理
    $(document).on('click', '.xb_aiqiming_login_btn', function (e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });

    // 防止表单重复提交
    $(document).on('keydown', function(e) {
        if (e.key === 'Enter' && $(e.target).closest('#xb_aiqiming_form').length && isGenerating) {
            e.preventDefault();
            return false;
        }
    });

    // 页面离开前的提醒
    $(window).on('beforeunload', function() {
        if (isGenerating) {
            return '正在起名中，确定要离开吗？';
        }
    });
});