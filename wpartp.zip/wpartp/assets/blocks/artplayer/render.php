<?php
/**
 * Artplayer 块服务端渲染
 * 
 * @package WP-Artplayer
 * @version 2.0.0
 */

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 获取属性
$url = isset($attributes['url']) ? $attributes['url'] : '';
$poster = isset($attributes['poster']) ? $attributes['poster'] : '';
$width = isset($attributes['width']) ? $attributes['width'] : '100%';
$height = isset($attributes['height']) ? $attributes['height'] : '500px';

// 如果没有URL，不渲染
if (empty($url)) {
    return;
}

// 构建 shortcode 属性
$shortcode_atts = array(
    'url' => esc_attr($url),
    'width' => esc_attr($width),
    'height' => esc_attr($height),
);

if (!empty($poster)) {
    $shortcode_atts['poster'] = esc_attr($poster);
}

// 构建 shortcode 字符串
$shortcode_parts = array();
foreach ($shortcode_atts as $key => $value) {
    $shortcode_parts[] = $key . '="' . $value . '"';
}

$shortcode = '[artplayer ' . implode(' ', $shortcode_parts) . ']';

// 获取块包装器属性
$wrapper_attributes = get_block_wrapper_attributes(array(
    'class' => 'wp-block-wpartplayer-artplayer'
));

// 输出
echo '<div ' . $wrapper_attributes . '>';
echo do_shortcode($shortcode);
echo '</div>';
