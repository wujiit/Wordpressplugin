/**
 * Artplayer Gutenberg 块
 * 
 * @package WP-Artplayer
 * @version 2.0.0
 */

(function (wp) {
    const { registerBlockType } = wp.blocks;
    const { useBlockProps, MediaUpload, MediaUploadCheck, InspectorControls } = wp.blockEditor;
    const { PanelBody, TextControl, Button, Placeholder, SelectControl } = wp.components;
    const { createElement: el, Fragment } = wp.element;
    const { __ } = wp.i18n;

    // 块图标
    var blockIcon = el('svg', {
        width: 24,
        height: 24,
        viewBox: '0 0 24 24',
        fill: 'none',
        stroke: 'currentColor',
        strokeWidth: 2
    },
        el('polygon', { points: '5 3 19 12 5 21 5 3' })
    );

    // 注册块
    registerBlockType('wpartplayer/artplayer', {
        title: 'Artplayer 视频',
        description: '嵌入 Artplayer HTML5 视频播放器，支持 MP4、M3U8 格式',
        category: 'media',
        icon: blockIcon,
        keywords: ['video', 'player', 'artplayer', '视频', '播放器'],

        attributes: {
            url: {
                type: 'string',
                default: ''
            },
            poster: {
                type: 'string',
                default: ''
            },
            posterId: {
                type: 'number',
                default: 0
            },
            width: {
                type: 'string',
                default: '100%'
            },
            height: {
                type: 'string',
                default: '500px'
            }
        },

        edit: function (props) {
            const { attributes, setAttributes } = props;
            const { url, poster, posterId, width, height } = attributes;

            const blockProps = useBlockProps({
                className: 'wp-block-artplayer-editor'
            });

            // 处理封面图选择
            const onSelectPoster = function (media) {
                setAttributes({
                    poster: media.url,
                    posterId: media.id
                });
            };

            // 处理封面图移除
            const onRemovePoster = function () {
                setAttributes({
                    poster: '',
                    posterId: 0
                });
            };

            // 检查是否有视频URL
            const hasVideo = url && url.trim() !== '';

            // 侧边栏设置面板
            const inspectorControls = el(InspectorControls, {},
                el(PanelBody, {
                    title: __('播放器设置', 'wpartplayer'),
                    initialOpen: true
                },
                    el(TextControl, {
                        label: __('视频地址', 'wpartplayer'),
                        help: __('支持 MP4、M3U8 格式，多个视频用英文逗号分隔', 'wpartplayer'),
                        value: url,
                        onChange: function (value) {
                            setAttributes({ url: value });
                        }
                    }),
                    el('div', { className: 'artplayer-poster-control' },
                        el('label', { className: 'components-base-control__label' },
                            __('封面图', 'wpartplayer')
                        ),
                        el(MediaUploadCheck, {},
                            el(MediaUpload, {
                                onSelect: onSelectPoster,
                                allowedTypes: ['image'],
                                value: posterId,
                                render: function (obj) {
                                    return el(Fragment, {},
                                        poster ? el('div', { className: 'artplayer-poster-preview' },
                                            el('img', { src: poster, alt: '' }),
                                            el(Button, {
                                                isDestructive: true,
                                                onClick: onRemovePoster
                                            }, __('移除', 'wpartplayer'))
                                        ) : null,
                                        el(Button, {
                                            variant: 'secondary',
                                            onClick: obj.open
                                        }, poster ? __('更换封面图', 'wpartplayer') : __('选择封面图', 'wpartplayer'))
                                    );
                                }
                            })
                        )
                    )
                ),
                el(PanelBody, {
                    title: __('尺寸设置', 'wpartplayer'),
                    initialOpen: false
                },
                    el(TextControl, {
                        label: __('宽度', 'wpartplayer'),
                        help: __('例如: 100%, 800px', 'wpartplayer'),
                        value: width,
                        onChange: function (value) {
                            setAttributes({ width: value });
                        }
                    }),
                    el(TextControl, {
                        label: __('高度', 'wpartplayer'),
                        help: __('例如: 500px, 56.25%', 'wpartplayer'),
                        value: height,
                        onChange: function (value) {
                            setAttributes({ height: value });
                        }
                    })
                )
            );

            // 主编辑区域内容
            var content;

            if (!hasVideo) {
                // 无视频时显示占位符
                content = el(Placeholder, {
                    icon: blockIcon,
                    label: __('Artplayer 视频', 'wpartplayer'),
                    instructions: __('添加视频地址以嵌入播放器', 'wpartplayer')
                },
                    el(TextControl, {
                        placeholder: __('输入视频地址...', 'wpartplayer'),
                        value: url,
                        onChange: function (value) {
                            setAttributes({ url: value });
                        }
                    })
                );
            } else {
                // 有视频时显示预览
                var videoUrls = url.split(',');
                var videoCount = videoUrls.length;

                content = el('div', { className: 'artplayer-block-preview' },
                    el('div', {
                        className: 'artplayer-preview-container',
                        style: {
                            backgroundImage: poster ? 'url(' + poster + ')' : 'none',
                            aspectRatio: '16/9'
                        }
                    },
                        el('div', { className: 'artplayer-preview-overlay' },
                            el('div', { className: 'artplayer-preview-play-icon' },
                                el('svg', { viewBox: '0 0 24 24', width: 48, height: 48 },
                                    el('polygon', {
                                        points: '5 3 19 12 5 21 5 3',
                                        fill: 'currentColor'
                                    })
                                )
                            ),
                            el('div', { className: 'artplayer-preview-info' },
                                el('span', { className: 'artplayer-preview-badge' },
                                    videoCount > 1
                                        ? __('共', 'wpartplayer') + videoCount + __('集', 'wpartplayer')
                                        : 'Artplayer'
                                )
                            )
                        )
                    ),
                    el('div', { className: 'artplayer-preview-url' },
                        el('code', {}, videoUrls[0].trim())
                    )
                );
            }

            return el(Fragment, {},
                inspectorControls,
                el('div', blockProps, content)
            );
        },

        save: function () {
            // 使用服务端渲染
            return null;
        }
    });

})(window.wp);
