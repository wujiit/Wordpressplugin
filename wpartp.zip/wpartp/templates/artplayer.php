<?php
/**
 * Artplayer 播放器模板
 * 
 * @package WP-Artplayer
 * @version 2.0.0
 */

// 获取视频相关信息和HTML生成
$artdplayerjson = get_option('artdplayerjson');
$artdplayer = json_decode($artdplayerjson, true);
$art = $artdplayer;

// 解析URL列表
$urls = explode(',', $atts['url']);
$videoCount = count($urls);
$currentVideoIndex = isset($_GET['video_index']) ? intval($_GET['video_index']) : 0;
$currentVideoUrl = esc_url(trim($urls[$currentVideoIndex]));
$poster = isset($atts['poster']) ? esc_url($atts['poster']) : '';

// 读取广告设置
$enableAds = isset($artdplayer['enable_ads']) && $artdplayer['enable_ads'] == 1;
$adHtml = isset($artdplayer['ad_html']) ? $artdplayer['ad_html'] : '';
$adVideo = isset($artdplayer['ad_video']) ? $artdplayer['ad_video'] : '';
$adUrl = isset($artdplayer['ad_url']) ? $artdplayer['ad_url'] : '';
$adPlayDuration = isset($artdplayer['ad_play_duration']) ? intval($artdplayer['ad_play_duration']) : 5;
$adTotalDuration = isset($artdplayer['ad_total_duration']) ? intval($artdplayer['ad_total_duration']) : 10;

// 生成唯一ID
$playerId = 'artplayer' . $atts['_id'];
?>

<!-- 清理可能的 details/summary 包装 -->
<script>
(function(){
    // 立即执行：移除播放器周围的 details/summary
    var wrapper = document.currentScript.parentElement;
    if (wrapper) {
        // 查找并移除 summary 元素
        var summaries = wrapper.querySelectorAll('summary');
        summaries.forEach(function(s) { s.remove(); });
        
        // 如果被 details 包裹，展开它
        var details = wrapper.closest('details');
        if (details) {
            details.setAttribute('open', 'open');
            details.style.display = 'block';
        }
    }
})();
</script>

<div class="artplayer-wrapper">
    <!-- 播放器容器 -->
    <div id="<?php echo esc_attr($playerId); ?>" class="artplayerbox" 
         style="width:<?php echo esc_attr($atts['width']); ?>;height:<?php echo esc_attr($atts['height']); ?>"
         data-player-id="<?php echo esc_attr($atts['_id']); ?>">
        
        <?php if ($enableAds) : ?>
        <!-- 广告层 -->
        <div class="artplayer-ads" id="ads-<?php echo esc_attr($playerId); ?>">
            <?php if (!empty($adVideo)) : ?>
                <video class="ad-video" autoplay muted playsinline>
                    <source src="<?php echo esc_url($adVideo); ?>" type="video/mp4">
                </video>
            <?php elseif (!empty($adHtml)) : ?>
                <div class="ad-html">
                    <?php echo wp_kses_post($adHtml); ?>
                </div>
            <?php endif; ?>
            <button class="ad-skip-btn" disabled data-countdown="<?php echo esc_attr($adPlayDuration); ?>">
                <?php echo esc_html($adPlayDuration); ?>秒后可跳过
            </button>
        </div>
        <?php endif; ?>
    </div>

    <?php if ($videoCount > 1) : ?>
    <!-- 集数选择器 - 网格布局 -->
    <div class="artplayer-episodes" id="episodes-<?php echo esc_attr($playerId); ?>">
        <div class="episodes-header">
            <span class="episodes-title"><?php esc_html_e('选集', 'wpartplayer'); ?></span>
            <span class="episodes-count"><?php printf(esc_html__('共%d集', 'wpartplayer'), $videoCount); ?></span>
        </div>
        
        <!-- 播放下一集按钮 -->
        <button type="button" class="next-episode-btn" data-player="<?php echo esc_attr($playerId); ?>">
            <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
                <polygon points="5 3 19 12 5 21 5 3" fill="currentColor"></polygon>
            </svg>
            <span><?php esc_html_e('播放下一集', 'wpartplayer'); ?></span>
        </button>
        
        <!-- 集数网格 -->
        <div class="episodes-grid">
            <?php foreach ($urls as $index => $url) : ?>
                <button type="button" 
                        class="episode-btn<?php echo $index === $currentVideoIndex ? ' active' : ''; ?>" 
                        data-video-url="<?php echo esc_url(trim($url)); ?>" 
                        data-video-index="<?php echo esc_attr($index); ?>"
                        data-player="<?php echo esc_attr($playerId); ?>"
                        title="<?php printf(esc_attr__('第%d集', 'wpartplayer'), $index + 1); ?>">
                    <?php echo esc_html($index + 1); ?>
                </button>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<script type="text/javascript">
(function() {
    // 播放器配置
    var playerId = '<?php echo esc_js($playerId); ?>';
    var playerContainer = '#' + playerId;
    var episodesContainer = '#episodes-' + playerId;
    
    // 全局设置右键菜单开关
    <?php if(!(isset($art['contextmenu']) && !empty($art['contextmenu']))): ?>
    if (typeof Artplayer !== 'undefined') {
        Artplayer.CONTEXTMENU = false;
    }
    <?php endif; ?>
    
    var art = null;
    var currentVideoIndex = <?php echo intval($currentVideoIndex); ?>;
    var videoCount = <?php echo intval($videoCount); ?>;
    var urls = <?php echo wp_json_encode(array_map('trim', $urls)); ?>;
    var poster = "<?php echo esc_js($poster); ?>";
    var themeColor = '<?php echo isset($artdplayer['theme']) ? esc_js($artdplayer['theme']) : '#2563eb'; ?>';

    // 更新集数按钮状态
    function updateEpisodeButtons() {
        var buttons = document.querySelectorAll(episodesContainer + ' .episode-btn');
        buttons.forEach(function(btn, index) {
            btn.classList.toggle('active', index === currentVideoIndex);
        });
    }

    // 初始化播放器
    function initializePlayer(videoUrl, autoplay) {
        autoplay = autoplay || false;
        
        if (art) {
            art.destroy();
        }

        art = new Artplayer({
            id: "art<?php echo esc_js($atts['_id']); ?>",
            container: playerContainer,
            url: videoUrl,
            poster: poster,
            theme: themeColor,
            autoplay: autoplay,
            <?php if(isset($art['volume']) && !empty($art['volume'])){ echo 'volume:' . floatval($art['volume']) . ','; } ?>
            <?php if(isset($art['muted']) && !empty($art['muted'])){ echo 'muted:true,'; } ?>
            <?php if(isset($art['autoplayone']) && !empty($art['autoplayone'])){ echo 'autoplay:true,'; } ?>
            <?php if(isset($art['loop']) && !empty($art['loop'])){ echo 'loop:true,'; } ?>
            <?php if(isset($art['autoMini']) && !empty($art['autoMini'])){ echo 'autoMini:true,'; } ?>
            <?php if(isset($art['playbackRate']) && !empty($art['playbackRate'])){ echo 'playbackRate:true,'; } ?>
            <?php if(isset($art['screenshot']) && !empty($art['screenshot'])){ echo 'screenshot:true,'; } ?>
            <?php if(isset($art['pip']) && !empty($art['pip'])){ echo 'pip:true,'; } ?>
            <?php if(isset($art['fullscreenWeb']) && !empty($art['fullscreenWeb'])){ echo 'fullscreenWeb:true,'; } ?>
            <?php if(isset($art['flip']) && !empty($art['flip'])){ echo 'flip:true,'; } ?>
            <?php if(isset($art['miniProgressBar']) && !empty($art['miniProgressBar'])){ echo 'miniProgressBar:true,'; } ?>
            <?php if(isset($art['lock']) && !empty($art['lock'])){ echo 'lock:true,'; } ?>
            <?php if(isset($art['fastForward']) && !empty($art['fastForward'])){ echo 'fastForward:true,'; } ?>
            <?php if(isset($art['autoPlayback']) && !empty($art['autoPlayback'])){ echo 'autoPlayback:true,'; } ?>
            <?php if(isset($art['autoOrientation']) && !empty($art['autoOrientation'])){ echo 'autoOrientation:true,'; } ?>
            <?php if(isset($art['airplay']) && !empty($art['airplay'])){ echo 'airplay:true,'; } ?>
            plugins: [
            <?php if ($enableAds) : ?>
                artplayerPluginAds({
                    html: '<?php echo addslashes($adHtml); ?>',
                    video: '<?php echo esc_url($adVideo); ?>',
                    url: '<?php echo esc_url($adUrl); ?>',
                    playDuration: <?php echo intval($adPlayDuration); ?>,
                    totalDuration: <?php echo intval($adTotalDuration); ?>,
                }),
            <?php endif; ?>
            ],
            hotkey: true,
            fullscreen: true,
            setting: true,
            whitelist: ['*'],
            lang: 'zh-cn',
            customType: {
                m3u8: function (video, url) {
                    if (typeof Hls !== 'undefined' && Hls.isSupported()) {
                        var hls = new Hls();
                        hls.loadSource(url);
                        hls.attachMedia(video);
                    } else {
                        var canPlay = video.canPlayType('application/vnd.apple.mpegurl');
                        if (canPlay === 'probably' || canPlay === 'maybe') {
                            video.src = url;
                        } else {
                            art.notice.show = "<?php esc_html_e('不支持的播放格式: m3u8', 'wpartplayer'); ?>";
                        }
                    }
                }
            }
        });

        // 视频播放结束自动播放下一集
        art.on('video:ended', function() {
            if (currentVideoIndex < videoCount - 1) {
                currentVideoIndex++;
                initializePlayer(urls[currentVideoIndex], true);
                updateEpisodeButtons();
            }
        });
    }

    // DOM 就绪后初始化
    function init() {
        // 初始化播放器
        initializePlayer(urls[currentVideoIndex]);

        // 绑定集数按钮点击事件
        document.querySelectorAll(episodesContainer + ' .episode-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var videoIndex = parseInt(this.dataset.videoIndex, 10);
                if (videoIndex !== currentVideoIndex) {
                    currentVideoIndex = videoIndex;
                    initializePlayer(urls[currentVideoIndex], true);
                    updateEpisodeButtons();
                }
            });
        });

        // 绑定播放下一集按钮
        var nextBtn = document.querySelector(episodesContainer + ' .next-episode-btn');
        if (nextBtn) {
            nextBtn.addEventListener('click', function() {
                if (currentVideoIndex < videoCount - 1) {
                    currentVideoIndex++;
                    initializePlayer(urls[currentVideoIndex], true);
                    updateEpisodeButtons();
                }
            });
        }

        // 兼容旧版按钮（向后兼容）
        document.querySelectorAll('.video-button[data-player="' + playerId + '"]').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var videoIndex = parseInt(this.dataset.videoIndex, 10);
                if (videoIndex !== currentVideoIndex) {
                    currentVideoIndex = videoIndex;
                    initializePlayer(urls[currentVideoIndex], true);
                    document.querySelectorAll('.video-button').forEach(function(b) {
                        b.classList.remove('active');
                    });
                    this.classList.add('active');
                }
            });
        });

        var oldNextBtn = document.querySelector('.next-video-button');
        if (oldNextBtn) {
            oldNextBtn.addEventListener('click', function() {
                if (currentVideoIndex < videoCount - 1) {
                    currentVideoIndex++;
                    initializePlayer(urls[currentVideoIndex], true);
                }
            });
        }
    }

    // 等待 Artplayer 脚本加载
    function waitForArtplayer(callback, maxAttempts) {
        maxAttempts = maxAttempts || 50;
        var attempts = 0;
        
        function check() {
            attempts++;
            if (typeof Artplayer !== 'undefined') {
                callback();
            } else if (attempts < maxAttempts) {
                setTimeout(check, 100);
            } else {
                console.error('Artplayer 脚本加载超时');
            }
        }
        check();
    }

    // 等待 DOM 加载完成后再等待 Artplayer
    function onReady() {
        waitForArtplayer(init);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', onReady);
    } else {
        onReady();
    }
})();
</script>