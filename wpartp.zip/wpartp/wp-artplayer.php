<?php
/**
 * Plugin Name: Artplayer HTML5播放器
 * Plugin URI: https://www.jingxialai.com/4950.html
 * Description: 基于Artplayer的播放器支持mp4和m3u8格式视频，可以设置广告，播放器的大部分功能控件支持自定义。
 * Author: Summer
 * Author URI: https://www.jingxialai.com/
 * Version: 2.0.1
 * Requires PHP: 8.0
 * License: GPL v2
 *
 * 原版：https://github.com/oyjcmyn/wp-artplayer
 * 
 */

defined( 'ABSPATH' ) || exit;

define( 'WP_ARTDPLAYER_VERSION', '2.0.0' );
define( 'WP_ARTDPLAYER_PATH', realpath( plugin_dir_path( __FILE__ ) ) . '/' );
define( 'WP_ARTDPLAYER_INC_PATH', realpath( WP_ARTDPLAYER_PATH . 'inc/' ) . '/' );
define( 'WP_ARTDPLAYER_URL', plugin_dir_url( __FILE__ ) );

$file=WP_ARTDPLAYER_PATH .'config.php';
if(file_exists($file)){
  include $file;//载入配置
}
require_once WP_ARTDPLAYER_INC_PATH . 'main.php';

// 在插件中心添加设置链接
function artplayer_add_settings_link($links) {
    $settings_link = '<a href="admin.php?page=artplayerset">设置</a>';
    array_push($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'artplayer_add_settings_link');


// 菜单入口
function artplayer_menu(){
    add_menu_page('artplayer','Art播放器', 'manage_options', 'artplayerset' ,'artplayerset', 'dashicons-format-video', 80);
    
}
add_action("admin_menu","artplayer_menu");

function artplayerset(){
    include WP_ARTDPLAYER_INC_PATH . 'admin.php';
} 

// 经典编辑器快捷键
function wp_artplayer_register_tinymce_plugin($plugin_array) {
    $plugin_array['wp_artplayer_button'] = plugin_dir_url(__FILE__) . '/assets/js/artplayer-tinymce.js';
    return $plugin_array;
}

function wp_artplayer_add_tinymce_button($buttons) {
    array_push($buttons, 'wp_artplayer_button');
    return $buttons;
}

function wp_artplayer_add_tinymce_plugin() {
    if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {
        return;
    }

    if (get_user_option('rich_editing') !== 'true') {
        return;
    }

    add_filter('mce_external_plugins', 'wp_artplayer_register_tinymce_plugin');
    add_filter('mce_buttons', 'wp_artplayer_add_tinymce_button');
}

add_action('init', 'wp_artplayer_add_tinymce_plugin');
// 经典编辑器快捷键结束

/**
 * 注册 Gutenberg 块
 */
function wp_artplayer_register_block() {
    // 检查是否支持块编辑器
    if (!function_exists('register_block_type')) {
        return;
    }
    
    $version = WP_ARTDPLAYER_VERSION;
    $block_path = WP_ARTDPLAYER_PATH . 'assets/blocks/artplayer/';
    
    // 注册编辑器脚本
    wp_register_script(
        'wpartplayer-artplayer-editor',
        WP_ARTDPLAYER_URL . 'assets/blocks/artplayer/index.js',
        array('wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-i18n', 'wp-block-editor'),
        $version,
        true
    );
    
    // 注册编辑器样式
    wp_register_style(
        'wpartplayer-artplayer-editor-style',
        WP_ARTDPLAYER_URL . 'assets/blocks/artplayer/editor.css',
        array('wp-edit-blocks'),
        $version
    );
    
    // 注册块
    register_block_type('wpartplayer/artplayer', array(
        'editor_script' => 'wpartplayer-artplayer-editor',
        'editor_style' => 'wpartplayer-artplayer-editor-style',
        'render_callback' => 'wp_artplayer_block_render',
        'attributes' => array(
            'url' => array(
                'type' => 'string',
                'default' => ''
            ),
            'poster' => array(
                'type' => 'string',
                'default' => ''
            ),
            'posterId' => array(
                'type' => 'number',
                'default' => 0
            ),
            'width' => array(
                'type' => 'string',
                'default' => '100%'
            ),
            'height' => array(
                'type' => 'string',
                'default' => '500px'
            )
        ),
        'supports' => array(
            'html' => false,
            'align' => array('wide', 'full')
        )
    ));
}
add_action('init', 'wp_artplayer_register_block');

/**
 * Gutenberg 块渲染回调
 */
function wp_artplayer_block_render($attributes, $content, $block) {
    // 获取属性
    $url = isset($attributes['url']) ? $attributes['url'] : '';
    $poster = isset($attributes['poster']) ? $attributes['poster'] : '';
    $width = isset($attributes['width']) ? $attributes['width'] : '100%';
    $height = isset($attributes['height']) ? $attributes['height'] : '500px';
    
    // 如果没有URL，不渲染
    if (empty($url)) {
        return '';
    }
    
    // 构建 shortcode 属性
    $shortcode_atts = array(
        'url="' . esc_attr($url) . '"',
        'width="' . esc_attr($width) . '"',
        'height="' . esc_attr($height) . '"',
    );
    
    if (!empty($poster)) {
        $shortcode_atts[] = 'poster="' . esc_attr($poster) . '"';
    }
    
    $shortcode = '[artplayer ' . implode(' ', $shortcode_atts) . ']';
    
    // 直接返回 shortcode 内容，不添加额外包装器
    return do_shortcode($shortcode);
}

/**
 * 为块编辑器添加分类（可选）
 */
function wp_artplayer_block_category($categories, $post) {
    return array_merge(
        $categories,
        array(
            array(
                'slug' => 'wpartplayer',
                'title' => __('Artplayer', 'wpartplayer'),
                'icon' => 'video-alt3',
            ),
        )
    );
}
// WordPress 5.8+
if (version_compare(get_bloginfo('version'), '5.8', '>=')) {
    add_filter('block_categories_all', 'wp_artplayer_block_category', 10, 2);
} else {
    add_filter('block_categories', 'wp_artplayer_block_category', 10, 2);
}