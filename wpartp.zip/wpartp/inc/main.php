<?php
/**
 * Artplayer 核心功能
 * 
 * @package WP-Artplayer
 * @version 2.0.0
 */

class ART_MAIN_MI {

    public static function save_options() {
        if (wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mi_artplayer_save_field'])), 'mi_artplayer_save_action')) {
            $data = $_POST;
            unset($data['mi_artplayer_save_field'], $data['_wp_http_referer']);
            
            // 处理广告设置，保存到数据库
            if (isset($data['enable_ads'])) {
                $data['enable_ads'] = 1;
            } else {
                $data['enable_ads'] = 0;
            }

            // 处理HTML广告内容，确保不被过滤
            if (isset($data['ad_html'])) {
                $data['ad_html'] = wp_kses_post($data['ad_html']);
            }

            update_option('artdplayerjson', json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }
}


class Artplayer_Admin_Media {

    private static $scripts_enqueued = false;
    
    public function __construct() {
        add_shortcode('artplayer', array($this, 'artplayer_shortcode'));
    }

    /**
     * 按需加载前端资源（只在需要时调用）
     */
    public static function enqueue_player_assets() {
        if (self::$scripts_enqueued) {
            return;
        }
        
        $artdplayerjson = get_option('artdplayerjson');
        if (empty($artdplayerjson)) {
            return;
        }
        $artdplayer = json_decode($artdplayerjson, true);
        
        $version = WP_ARTDPLAYER_VERSION;
        
        // 加载播放器样式
        wp_enqueue_style(
            'artplayer-style',
            WP_ARTDPLAYER_URL . 'assets/css/artplayer-style.css',
            array(),
            $version
        );
        
        // 加载 HLS 支持
        if ((isset($artdplayer['enable_hls']) && $artdplayer['enable_hls'] == 1) || 
            (isset($artdplayer['isLive']) && $artdplayer['isLive'] == 1)) { 
            wp_enqueue_script('arthls', WP_ARTDPLAYER_URL . 'assets/js/hls.min.js', array(), $version, true);
        }
        
        // 加载播放器核心
        $artplayer_url = WP_ARTDPLAYER_URL . 'assets/js/artplayer.js';
        if (!empty($artdplayer['artplayer_cdn_url'])) {
            $artplayer_url = esc_url($artdplayer['artplayer_cdn_url']);
        }
        wp_enqueue_script('artplayer', $artplayer_url, array(), $version, true);

        // 加载广告插件
        if (isset($artdplayer['enable_ads']) && $artdplayer['enable_ads'] == 1) {
            wp_enqueue_script('artplayer-plugin-ads', WP_ARTDPLAYER_URL . 'assets/js/artplayer-plugin-ads.js', array('artplayer'), $version, true);
        }

        self::$scripts_enqueued = true;
    }

    /**
     * Shortcode 处理
     */
    public function artplayer_shortcode($atts, $content = null) {
        // 在 shortcode 执行时加载资源
        self::enqueue_player_assets();
        
        // 获取并设置默认值
        $atts = shortcode_atts(array(
            '_id' => get_the_ID() . '_' . wp_rand(100, 999),
            'url' => '',
            'poster' => '',
            'width' => '100%',
            'height' => '500px',
        ), $atts);

        // 解析视频链接URL列表
        $urls = explode(',', $atts['url']);
        $videoCount = count($urls);
        $buttonsHtml = '';

        // 如果有多个视频链接，则生成集数按钮
        if ($videoCount > 1) {
            for ($i = 0; $i < $videoCount; $i++) {
                $buttonsHtml .= '<button class="video-button" data-video-url="' . esc_url(trim($urls[$i])) . '">第' . ($i + 1) . '集</button>';
            }
        }

        // 检查是否为B站视频
        $isBilibili = false;
        $bilibiliBvid = '';

        foreach ($urls as $url) {
            if (preg_match('/bilibili\.com\/video\/(BV\w+)/', $url, $matches)) {
                $isBilibili = true;
                $bilibiliBvid = $matches[1];
                break;
            }
        }

        // 输出播放器HTML
        ob_start();

        if ($isBilibili) {
            ?>
            <div id="artplayer<?php echo esc_attr($atts['_id']); ?>" class="artplayerbox" style="width:<?php echo esc_attr($atts['width']); ?>;height:<?php echo esc_attr($atts['height']); ?>">
                <iframe src="https://player.bilibili.com/player.html?bvid=<?php echo esc_attr($bilibiliBvid); ?>&autoplay=0" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" style="width:100%; height:100%;"></iframe>
            </div>
            <?php
        } else {
            include WP_ARTDPLAYER_PATH . '/templates/artplayer.php';
        }

        return ob_get_clean();
    }
}

new Artplayer_Admin_Media();