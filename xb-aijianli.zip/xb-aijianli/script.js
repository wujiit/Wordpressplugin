/**
 * AI简历生成与润色插件JavaScript - 修复删除冲突问题
 */

(function($) {
    'use strict';
    
    // 全局变量
    let resumeData = {
        title: '',
        basic: {},
        jobIntention: {},
        workExperience: [],
        education: [],
        skills: [],
        selfEvaluation: ''
    };
    
    let workExperienceCount = 0;
    let educationCount = 0;
    let skillCount = 0;
    
    // 请求控制器，用于取消请求
    let currentRequest = null;
    
    // 主题设置
    let themeSettings = {
        layout: 'default',
        avatarShape: 'circle',
        sectionFontSize: '18px',
        contentFontSize: '14px',
        lineHeight: '1.6',
        sectionSpacing: '25px',
        showBorder: true,
        headerStyle: 'left',
        briefIntroColor: '#333333'
    };
    
    // 初始化
    $(document).ready(function() {
        initializeApp();
        bindEvents();
        loadFromLocalStorage();
        loadThemeSettings();
        updatePreview();
        loadSortableLibrary();
        initializeLoginOptimization();
    });
    
    function initializeLoginOptimization() {
        $('.xb-aijianli-guest-notice a[href*="wp-login"]').addClass('wp-ai-login-btn');
        
        $(document).on('click', '.wp-ai-login-btn', function(e) {
            e.preventDefault();
            const $themeLoginBtn = $('.nav-login .signin-loader');
            if ($themeLoginBtn.length) {
                console.log('检测到主题登录按钮，使用主题登录方式');
                $themeLoginBtn.trigger('click');
            } else {
                console.log('未检测到主题登录按钮，使用默认登录方式');
                window.location.href = $(this).attr('href');
            }
        });
    }
    
    function loadSortableLibrary() {
        if (typeof Sortable === 'undefined') {
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js';
            script.onload = function() {
                console.log('Sortable.js库加载成功');
                initializeSortable();
            };
            script.onerror = function() {
                console.log('Sortable.js库加载失败，拖拽功能不可用');
            };
            document.head.appendChild(script);
        } else {
            initializeSortable();
        }
    }
    
    function initializeApp() {
        setupAvatarUpload();
        setupStyleControls();
        setupThemeControls();
    }
    
    function setupThemeControls() {
        $('#layout-style').on('change', function() {
            themeSettings.layout = $(this).val();
            updatePreview();
            saveThemeSettings();
        });
        
        $('#avatar-shape').on('change', function() {
            themeSettings.avatarShape = $(this).val();
            updatePreview();
            saveThemeSettings();
        });
        
        $('#section-font-size').on('change', function() {
            themeSettings.sectionFontSize = $(this).val();
            updatePreview();
            saveThemeSettings();
        });
        
        $('#content-font-size').on('change', function() {
            themeSettings.contentFontSize = $(this).val();
            updatePreview();
            saveThemeSettings();
        });
        
        $('#line-height').on('change', function() {
            themeSettings.lineHeight = $(this).val();
            updatePreview();
            saveThemeSettings();
        });
        
        $('#section-spacing').on('change', function() {
            themeSettings.sectionSpacing = $(this).val();
            updatePreview();
            saveThemeSettings();
        });
        
        $('#show-border').on('change', function() {
            themeSettings.showBorder = $(this).val() === 'true';
            updatePreview();
            saveThemeSettings();
        });
        
        $('#header-style').on('change', function() {
            themeSettings.headerStyle = $(this).val();
            updatePreview();
            saveThemeSettings();
        });
        
        $('#brief-intro-color').on('change', function() {
            themeSettings.briefIntroColor = $(this).val();
            updatePreview();
            saveThemeSettings();
        });
    }
    
    function saveThemeSettings() {
        localStorage.setItem('xb_aijianli_theme_settings', JSON.stringify(themeSettings));
    }
    
    function loadThemeSettings() {
        const saved = localStorage.getItem('xb_aijianli_theme_settings');
        if (saved) {
            try {
                themeSettings = Object.assign(themeSettings, JSON.parse(saved));
                populateThemeControls();
            } catch (e) {
                console.error('加载主题设置失败:', e);
            }
        }
    }
    
    function populateThemeControls() {
        $('#layout-style').val(themeSettings.layout);
        $('#avatar-shape').val(themeSettings.avatarShape);
        $('#section-font-size').val(themeSettings.sectionFontSize);
        $('#content-font-size').val(themeSettings.contentFontSize);
        $('#line-height').val(themeSettings.lineHeight);
        $('#section-spacing').val(themeSettings.sectionSpacing);
        $('#show-border').val(themeSettings.showBorder ? 'true' : 'false');
        $('#header-style').val(themeSettings.headerStyle);
        $('#brief-intro-color').val(themeSettings.briefIntroColor);
    }
    
    function bindEvents() {
        const debouncedUpdate = debounce(function() {
            updateResumeData();
            updatePreview();
            saveToLocalStorage();
        }, 150);

        $(document).on('input change', 'input, select, textarea', function() {
            debouncedUpdate();
        });
        
        $('.xb-aijianli-modal-close').on('click', function() {
            hideModal();
        });
        
        $(window).on('click', function(e) {
            if ($(e.target).hasClass('xb-aijianli-modal')) {
                hideModal();
            }
        });
    }
    
    function setupAvatarUpload() {
        const $avatarPreview = $('#avatar-preview');
        const $avatarInput = $('#avatar');
        
        $avatarPreview.on('click', function() {
            $avatarInput.click();
        });
        
        $avatarInput.on('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    $avatarPreview.html('<img src="' + e.target.result + '" alt="头像" />');
                    resumeData.basic.avatar = e.target.result;
                    updatePreview();
                    saveToLocalStorage();
                };
                reader.readAsDataURL(file);
            }
        });
        
        $avatarPreview.on('dragover', function(e) {
            e.preventDefault();
            $(this).addClass('dragover');
        });
        
        $avatarPreview.on('dragleave', function(e) {
            e.preventDefault();
            $(this).removeClass('dragover');
        });
        
        $avatarPreview.on('drop', function(e) {
            e.preventDefault();
            $(this).removeClass('dragover');
            
            const files = e.originalEvent.dataTransfer.files;
            if (files.length > 0) {
                const file = files[0];
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        $avatarPreview.html('<img src="' + e.target.result + '" alt="头像" />');
                        resumeData.basic.avatar = e.target.result;
                        updatePreview();
                        saveToLocalStorage();
                    };
                    reader.readAsDataURL(file);
                }
            }
        });
    }
    
    function initializeSortable() {
        if (typeof Sortable === 'undefined') {
            console.log('Sortable.js库未加载，跳过拖拽功能初始化');
            return;
        }
        
        const workExperienceList = document.getElementById('work-experience-list');
        if (workExperienceList) {
            new Sortable(workExperienceList, {
                handle: '.xb-aijianli-drag-handle',
                animation: 150,
                ghostClass: 'xb-aijianli-sortable-ghost',
                chosenClass: 'xb-aijianli-sortable-chosen',
                dragClass: 'xb-aijianli-sortable-drag',
                onEnd: function() {
                    updateResumeData();
                    updatePreview();
                    saveToLocalStorage();
                }
            });
        }
        
        const educationList = document.getElementById('education-background-list');
        if (educationList) {
            new Sortable(educationList, {
                handle: '.xb-aijianli-drag-handle',
                animation: 150,
                ghostClass: 'xb-aijianli-sortable-ghost',
                chosenClass: 'xb-aijianli-sortable-chosen',
                dragClass: 'xb-aijianli-sortable-drag',
                onEnd: function() {
                    updateResumeData();
                    updatePreview();
                    saveToLocalStorage();
                }
            });
        }
        
        const skillsList = document.getElementById('skills-list');
        if (skillsList) {
            new Sortable(skillsList, {
                handle: '.xb-aijianli-drag-handle',
                animation: 150,
                ghostClass: 'xb-aijianli-sortable-ghost',
                chosenClass: 'xb-aijianli-sortable-chosen',
                dragClass: 'xb-aijianli-sortable-drag',
                onEnd: function() {
                    updateResumeData();
                    updatePreview();
                    saveToLocalStorage();
                }
            });
        }
    }
    
    function setupStyleControls() {
        $('#theme-color').on('change', function() {
            updatePreviewStyle();
        });
        
        $('#font-family').on('change', function() {
            updatePreviewStyle();
        });
    }
    
    function updatePreviewStyle() {
        const themeColor = $('#theme-color').val() || '#667eea';
        const fontFamily = $('#font-family').val() || "'Microsoft YaHei', sans-serif";
        const contentFontSize = $('#content-font-size').val() || themeSettings.contentFontSize;
        
        const $preview = $('#resume-preview');
        $preview.css({
            'font-family': fontFamily,
            'font-size': contentFontSize
        });
        
        $preview.find('.xb-aijianli-resume-name, .xb-aijianli-resume-section-title').css('color', themeColor);
        $preview.find('.xb-aijianli-resume-header').css('border-bottom-color', themeColor);
        $preview.find('.xb-aijianli-resume-section-title').css('border-bottom-color', themeColor);
    }
    
    /**
     * 修复：添加工作经验 - 使用唯一的data-type标识符
     */
    window.addWorkExperience = function() {
        workExperienceCount++;
        const html = '<div class="xb-aijianli-list-item" data-type="work" data-index="' + workExperienceCount + '">' +
            '<div class="xb-aijianli-list-item-header">' +
                '<div class="xb-aijianli-drag-handle" title="拖拽排序">⋮⋮</div>' +
                '<span class="xb-aijianli-list-item-title">工作经验 ' + workExperienceCount + '</span>' +
                '<button type="button" class="xb-aijianli-list-item-remove" onclick="removeWorkExperience(' + workExperienceCount + ')">删除</button>' +
            '</div>' +
            '<div class="xb-aijianli-form-grid">' +
                '<div class="xb-aijianli-field">' +
                    '<label class="xb-aijianli-label">工作日期</label>' +
                    '<input type="text" name="work-date-' + workExperienceCount + '" class="xb-aijianli-input" placeholder="如：2020.01-2023.12" />' +
                '</div>' +
                '<div class="xb-aijianli-field">' +
                    '<label class="xb-aijianli-label">公司名称</label>' +
                    '<input type="text" name="work-company-' + workExperienceCount + '" class="xb-aijianli-input" placeholder="请输入公司名称" />' +
                '</div>' +
                '<div class="xb-aijianli-field">' +
                    '<label class="xb-aijianli-label">担任职位</label>' +
                    '<input type="text" name="work-position-' + workExperienceCount + '" class="xb-aijianli-input" placeholder="请输入担任职位" />' +
                '</div>' +
            '</div>' +
            '<div class="xb-aijianli-field">' +
                '<label class="xb-aijianli-label">工作内容</label>' +
                '<textarea name="work-content-' + workExperienceCount + '" class="xb-aijianli-textarea" placeholder="请描述工作内容和成就" rows="3"></textarea>' +
            '</div>' +
        '</div>';
        $('#work-experience-list').append(html);
        setTimeout(initializeSortable, 100);
    };
    
    /**
     * 修复：删除工作经验 - 使用精确的选择器，只删除工作经验类型
     */
    window.removeWorkExperience = function(index) {
        $('.xb-aijianli-list-item[data-type="work"][data-index="' + index + '"]').remove();
        updateResumeData();
        updatePreview();
        saveToLocalStorage();
    };
    
    /**
     * 修复：添加教育背景 - 使用唯一的data-type标识符
     */
    window.addEducationBackground = function() {
        educationCount++;
        const html = '<div class="xb-aijianli-list-item" data-type="education" data-index="' + educationCount + '">' +
            '<div class="xb-aijianli-list-item-header">' +
                '<div class="xb-aijianli-drag-handle" title="拖拽排序">⋮⋮</div>' +
                '<span class="xb-aijianli-list-item-title">教育背景 ' + educationCount + '</span>' +
                '<button type="button" class="xb-aijianli-list-item-remove" onclick="removeEducationBackground(' + educationCount + ')">删除</button>' +
            '</div>' +
            '<div class="xb-aijianli-form-grid">' +
                '<div class="xb-aijianli-field">' +
                    '<label class="xb-aijianli-label">教育日期</label>' +
                    '<input type="text" name="edu-date-' + educationCount + '" class="xb-aijianli-input" placeholder="如：2016.09-2020.06" />' +
                '</div>' +
                '<div class="xb-aijianli-field">' +
                    '<label class="xb-aijianli-label">学校名称</label>' +
                    '<input type="text" name="edu-school-' + educationCount + '" class="xb-aijianli-input" placeholder="请输入学校名称" />' +
                '</div>' +
                '<div class="xb-aijianli-field">' +
                    '<label class="xb-aijianli-label">所学专业</label>' +
                    '<input type="text" name="edu-major-' + educationCount + '" class="xb-aijianli-input" placeholder="请输入所学专业" />' +
                '</div>' +
                '<div class="xb-aijianli-field">' +
                    '<label class="xb-aijianli-label">学历</label>' +
                    '<select name="edu-degree-' + educationCount + '" class="xb-aijianli-select">' +
                        '<option value="">请选择学历</option>' +
                        '<option value="小学">小学</option>' +
                        '<option value="初中">初中</option>' +
                        '<option value="高中">高中</option>' +
                        '<option value="中专">中专</option>' +
                        '<option value="大专">大专</option>' +
                        '<option value="本科">本科</option>' +
                        '<option value="硕士">硕士</option>' +
                        '<option value="博士">博士</option>' +
                        '<option value="副教授">副教授</option>' +
                        '<option value="教授">教授</option>' +
                    '</select>' +
                '</div>' +
            '</div>' +
            '<div class="xb-aijianli-field">' +
                '<label class="xb-aijianli-label">主修课程</label>' +
                '<textarea name="edu-courses-' + educationCount + '" class="xb-aijianli-textarea" placeholder="请输入主修课程" rows="2"></textarea>' +
            '</div>' +
        '</div>';
        $('#education-background-list').append(html);
        setTimeout(initializeSortable, 100);
    };
    
    /**
     * 修复：删除教育背景 - 使用精确的选择器，只删除教育背景类型
     */
    window.removeEducationBackground = function(index) {
        $('.xb-aijianli-list-item[data-type="education"][data-index="' + index + '"]').remove();
        updateResumeData();
        updatePreview();
        saveToLocalStorage();
    };
    
    /**
     * 修复：添加技能 - 使用唯一的data-type标识符
     */
    window.addSkill = function() {
        skillCount++;
        const html = '<div class="xb-aijianli-list-item" data-type="skill" data-index="' + skillCount + '">' +
            '<div class="xb-aijianli-list-item-header">' +
                '<div class="xb-aijianli-drag-handle" title="拖拽排序">⋮⋮</div>' +
                '<span class="xb-aijianli-list-item-title">技能 ' + skillCount + '</span>' +
                '<button type="button" class="xb-aijianli-list-item-remove" onclick="removeSkill(' + skillCount + ')">删除</button>' +
            '</div>' +
            '<div class="xb-aijianli-field">' +
                '<label class="xb-aijianli-label">技能介绍</label>' +
                '<textarea name="skill-' + skillCount + '" class="xb-aijianli-textarea" placeholder="请描述您的技能特长" rows="2"></textarea>' +
            '</div>' +
        '</div>';
        $('#skills-list').append(html);
        setTimeout(initializeSortable, 100);
    };
    
    /**
     * 修复：删除技能 - 使用精确的选择器，只删除技能类型
     */
    window.removeSkill = function(index) {
        $('.xb-aijianli-list-item[data-type="skill"][data-index="' + index + '"]').remove();
        updateResumeData();
        updatePreview();
        saveToLocalStorage();
    };
    
    /**
     * 修复：更新简历数据 - 使用精确的选择器遍历不同类型的项目
     */
    function updateResumeData() {
        // 基本信息
        resumeData.title = $('#resume-title').val();
        resumeData.basic = {
            name: $('#name').val(),
            age: $('#age').val(),
            education: $('#education').val(),
            location: $('#location').val(),
            nationality: $('#nationality').val(),
            affiliation: $('#affiliation').val(),
            hometown: $('#hometown').val(),
            workYears: $('#work-years').val(),
            contact: $('#contact').val(),
            email: $('#email').val(),
            briefIntro: $('#brief-intro').val(),
            briefIntroColor: $('#brief-intro-color').val() || themeSettings.briefIntroColor,
            avatar: resumeData.basic.avatar || ''
        };
        
        // 求职意向
        resumeData.jobIntention = {
            position: $('#job-position').val(),
            city: $('#job-city').val(),
            salary: $('#expected-salary').val(),
            status: $('#job-status').val(),
            type: $('#job-type').val()
        };
        
        // 工作经验 - 修复：只遍历工作经验类型的项目
        resumeData.workExperience = [];
        $('#work-experience-list .xb-aijianli-list-item[data-type="work"]').each(function() {
            const index = $(this).data('index');
            const experience = {
                date: $('[name="work-date-' + index + '"]').val(),
                company: $('[name="work-company-' + index + '"]').val(),
                position: $('[name="work-position-' + index + '"]').val(),
                content: $('[name="work-content-' + index + '"]').val()
            };
            if (experience.company || experience.position || experience.content) {
                resumeData.workExperience.push(experience);
            }
        });
        
        // 教育背景 - 修复：只遍历教育背景类型的项目
        resumeData.education = [];
        $('#education-background-list .xb-aijianli-list-item[data-type="education"]').each(function() {
            const index = $(this).data('index');
            const education = {
                date: $('[name="edu-date-' + index + '"]').val(),
                school: $('[name="edu-school-' + index + '"]').val(),
                major: $('[name="edu-major-' + index + '"]').val(),
                degree: $('[name="edu-degree-' + index + '"]').val(),
                courses: $('[name="edu-courses-' + index + '"]').val()
            };
            if (education.school || education.major) {
                resumeData.education.push(education);
            }
        });
        
        // 技能特长 - 修复：只遍历技能类型的项目
        resumeData.skills = [];
        $('#skills-list .xb-aijianli-list-item[data-type="skill"]').each(function() {
            const index = $(this).data('index');
            const skill = $('[name="skill-' + index + '"]').val();
            if (skill) {
                resumeData.skills.push(skill);
            }
        });
        
        // 自我评价
        resumeData.selfEvaluation = $('#self-evaluation').val();
    }
    
    function updatePreview() {
        let html = '';
        
        if (themeSettings.layout === 'left-avatar') {
            html = generateLeftAvatarLayout();
        } else {
            html = generateDefaultLayout();
        }
        
        $('#resume-preview').html(html);
        updatePreviewStyle();
        applyThemeStyles();
    }

    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function formatText(value) {
        return escapeHtml(value).replace(/\n/g, '<br>');
    }
    
    function generateDefaultLayout() {
        let html = '';
        
        if (resumeData.basic.name) {
            html += '<div class="xb-aijianli-resume-header">';
            
            if (resumeData.basic.avatar) {
                const avatarClass = themeSettings.avatarShape === 'rectangle' ? 'rectangle-avatar' : 'circle-avatar';
                html += '<div class="xb-aijianli-avatar-container ' + avatarClass + '">';
                html += '<img src="' + resumeData.basic.avatar + '" class="xb-aijianli-resume-avatar" />';
                html += '</div>';
            }
            
            html += '<div class="xb-aijianli-resume-name">' + escapeHtml(resumeData.basic.name) + '</div>';
            
            if (resumeData.basic.briefIntro) {
                html += '<div class="xb-aijianli-resume-brief">' + escapeHtml(resumeData.basic.briefIntro) + '</div>';
            }
            
            const contactInfoLine1 = [];
            const contactInfoLine2 = [];
            
            if (resumeData.basic.age) contactInfoLine1.push('年龄：' + escapeHtml(resumeData.basic.age));
            if (resumeData.basic.education) contactInfoLine1.push('学历：' + escapeHtml(resumeData.basic.education));
            if (resumeData.basic.nationality) contactInfoLine1.push('民族：' + escapeHtml(resumeData.basic.nationality));
            if (resumeData.basic.contact) contactInfoLine1.push('电话：' + escapeHtml(resumeData.basic.contact));
            if (resumeData.basic.email) contactInfoLine1.push('邮箱：' + escapeHtml(resumeData.basic.email));
            
            if (resumeData.basic.workYears) contactInfoLine2.push('工作年限：' + escapeHtml(resumeData.basic.workYears));
            if (resumeData.basic.affiliation) contactInfoLine2.push('政治面貌：' + escapeHtml(resumeData.basic.affiliation));
            if (resumeData.basic.hometown) contactInfoLine2.push('籍贯：' + escapeHtml(resumeData.basic.hometown));
            if (resumeData.basic.location) contactInfoLine2.push('住址：' + escapeHtml(resumeData.basic.location));
            
            if (contactInfoLine1.length > 0) {
                html += '<div class="xb-aijianli-resume-contact">' + contactInfoLine1.join(' | ') + '</div>';
            }
            if (contactInfoLine2.length > 0) {
                html += '<div class="xb-aijianli-resume-contact">' + contactInfoLine2.join(' | ') + '</div>';
            }
            
            html += '</div>';
        }
        
        html += generateSections();
        return html;
    }
    
    function generateLeftAvatarLayout() {
        let html = '';
        
        if (resumeData.basic.name) {
            html += '<div class="xb-aijianli-resume-header left-avatar-layout">';
            html += '<div class="xb-aijianli-header-content">';
            
            if (resumeData.basic.avatar) {
                const avatarClass = themeSettings.avatarShape === 'rectangle' ? 'rectangle-avatar' : 'circle-avatar';
                html += '<div class="xb-aijianli-avatar-left ' + avatarClass + '">';
                html += '<img src="' + resumeData.basic.avatar + '" class="xb-aijianli-resume-avatar" />';
                html += '</div>';
            }
            
            html += '<div class="xb-aijianli-info-right">';
            html += '<div class="xb-aijianli-resume-name">' + escapeHtml(resumeData.basic.name) + '</div>';
            
            if (resumeData.basic.briefIntro) {
                html += '<div class="xb-aijianli-resume-brief">' + escapeHtml(resumeData.basic.briefIntro) + '</div>';
            }
            
            const contactInfoLine1 = [];
            const contactInfoLine2 = [];
            
            if (resumeData.basic.age) contactInfoLine1.push('年龄：' + escapeHtml(resumeData.basic.age));
            if (resumeData.basic.education) contactInfoLine1.push('学历：' + escapeHtml(resumeData.basic.education));
            if (resumeData.basic.nationality) contactInfoLine1.push('民族：' + escapeHtml(resumeData.basic.nationality));
            if (resumeData.basic.contact) contactInfoLine1.push('电话：' + escapeHtml(resumeData.basic.contact));
            if (resumeData.basic.email) contactInfoLine1.push('邮箱：' + escapeHtml(resumeData.basic.email));
            
            if (resumeData.basic.workYears) contactInfoLine2.push('工作年限：' + escapeHtml(resumeData.basic.workYears));
            if (resumeData.basic.affiliation) contactInfoLine2.push('政治面貌：' + escapeHtml(resumeData.basic.affiliation));
            if (resumeData.basic.hometown) contactInfoLine2.push('籍贯：' + escapeHtml(resumeData.basic.hometown));
            if (resumeData.basic.location) contactInfoLine2.push('住址：' + escapeHtml(resumeData.basic.location));
            
            if (contactInfoLine1.length > 0) {
                html += '<div class="xb-aijianli-resume-contact">' + contactInfoLine1.join(' | ') + '</div>';
            }
            if (contactInfoLine2.length > 0) {
                html += '<div class="xb-aijianli-resume-contact">' + contactInfoLine2.join(' | ') + '</div>';
            }
            
            html += '</div>';
            html += '</div>';
            html += '</div>';
        }
        
        html += generateSections();
        return html;
    }
    
    function generateSections() {
        let html = '';
        
        // 求职意向
        if (resumeData.jobIntention.position || resumeData.jobIntention.city || resumeData.jobIntention.salary) {
            html += '<div class="xb-aijianli-resume-section">';
            html += '<div class="xb-aijianli-resume-section-title">求职意向</div>';
            
            const intentionsLine1 = [];
            if (resumeData.jobIntention.position) intentionsLine1.push('意向岗位：' + escapeHtml(resumeData.jobIntention.position));
            if (resumeData.jobIntention.city) intentionsLine1.push('意向城市：' + escapeHtml(resumeData.jobIntention.city));
            if (resumeData.jobIntention.salary) intentionsLine1.push('期望薪资：' + escapeHtml(resumeData.jobIntention.salary));
            
            const intentionsLine2 = [];
            if (resumeData.jobIntention.status) intentionsLine2.push('求职状态：' + escapeHtml(resumeData.jobIntention.status));
            if (resumeData.jobIntention.type) intentionsLine2.push('求职类型：' + escapeHtml(resumeData.jobIntention.type));
            
            if (intentionsLine1.length > 0) {
                html += '<div class="xb-aijianli-resume-intention-line">' + intentionsLine1.join(' | ') + '</div>';
            }
            if (intentionsLine2.length > 0) {
                html += '<div class="xb-aijianli-resume-intention-line">' + intentionsLine2.join(' | ') + '</div>';
            }
            
            html += '</div>';
        }
        
        // 工作经验
        if (resumeData.workExperience.length > 0) {
            html += '<div class="xb-aijianli-resume-section">';
            html += '<div class="xb-aijianli-resume-section-title">工作经验</div>';
            
            resumeData.workExperience.forEach(function(exp) {
                html += '<div class="xb-aijianli-resume-item">';
                html += '<div class="xb-aijianli-resume-item-header">' + escapeHtml(exp.position || '职位') + ' - ' + escapeHtml(exp.company || '公司') + '</div>';
                if (exp.date) {
                    html += '<div class="xb-aijianli-resume-item-meta">' + escapeHtml(exp.date) + '</div>';
                }
                if (exp.content) {
                    html += '<div class="xb-aijianli-resume-item-content">' + formatText(exp.content) + '</div>';
                }
                html += '</div>';
            });
            
            html += '</div>';
        }
        
        // 教育背景
        if (resumeData.education.length > 0) {
            html += '<div class="xb-aijianli-resume-section">';
            html += '<div class="xb-aijianli-resume-section-title">教育背景</div>';
            
            resumeData.education.forEach(function(edu) {
                html += '<div class="xb-aijianli-resume-item">';
                html += '<div class="xb-aijianli-resume-item-header">' + escapeHtml(edu.school || '学校') + ' - ' + escapeHtml(edu.major || '专业') + '</div>';
                
                const eduInfo = [];
                if (edu.date) eduInfo.push(escapeHtml(edu.date));
                if (edu.degree) eduInfo.push(escapeHtml(edu.degree));
                
                if (eduInfo.length > 0) {
                    html += '<div class="xb-aijianli-resume-item-meta">' + eduInfo.join(' | ') + '</div>';
                }
                
                if (edu.courses) {
                    html += '<div class="xb-aijianli-resume-item-content">主修课程：' + escapeHtml(edu.courses) + '</div>';
                }
                html += '</div>';
            });
            
            html += '</div>';
        }
        
        // 技能特长
        if (resumeData.skills.length > 0) {
            html += '<div class="xb-aijianli-resume-section">';
            html += '<div class="xb-aijianli-resume-section-title">技能特长</div>';
            
            resumeData.skills.forEach(function(skill) {
                html += '<div class="xb-aijianli-resume-item-content">• ' + escapeHtml(skill) + '</div>';
            });
            
            html += '</div>';
        }
        
        // 自我评价
        if (resumeData.selfEvaluation) {
            html += '<div class="xb-aijianli-resume-section">';
            html += '<div class="xb-aijianli-resume-section-title">自我评价</div>';
            html += '<div class="xb-aijianli-resume-item-content">' + formatText(resumeData.selfEvaluation) + '</div>';
            html += '</div>';
        }
        
        return html;
    }
    
    function applyThemeStyles() {
        const $preview = $('#resume-preview');
        
        $preview.find('.xb-aijianli-resume-section-title').css('font-size', themeSettings.sectionFontSize);
        $preview.find('.xb-aijianli-resume-item-content, .xb-aijianli-resume-contact, .xb-aijianli-resume-intention-line').css('font-size', themeSettings.contentFontSize);
        
        $preview.css('line-height', themeSettings.lineHeight);
        
        $preview.find('.xb-aijianli-resume-section').css('margin-bottom', themeSettings.sectionSpacing);
        
        if (themeSettings.showBorder) {
            $preview.find('.xb-aijianli-resume-section').css('border-bottom', '1px solid #e0e0e0');
        } else {
            $preview.find('.xb-aijianli-resume-section').css('border-bottom', 'none');
        }
        
        $preview.find('.xb-aijianli-resume-section-title').css('text-align', themeSettings.headerStyle);
        
        $preview.find('.xb-aijianli-resume-brief').css('color', themeSettings.briefIntroColor);
    }
    
    function saveToLocalStorage() {
        localStorage.setItem('xb_aijianli_resume_data', JSON.stringify(resumeData));
    }
    
    function loadFromLocalStorage() {
        const saved = localStorage.getItem('xb_aijianli_resume_data');
        if (saved) {
            try {
                resumeData = JSON.parse(saved);
                populateForm();
            } catch (e) {
                console.error('加载本地数据失败:', e);
            }
        }
    }
    
    function populateForm() {
        $('#resume-title').val(resumeData.title || '');
        $('#name').val(resumeData.basic.name || '');
        $('#age').val(resumeData.basic.age || '');
        $('#education').val(resumeData.basic.education || '');
        $('#location').val(resumeData.basic.location || '');
        $('#nationality').val(resumeData.basic.nationality || '');
        $('#affiliation').val(resumeData.basic.affiliation || '');
        $('#hometown').val(resumeData.basic.hometown || '');
        $('#work-years').val(resumeData.basic.workYears || '');
        $('#contact').val(resumeData.basic.contact || '');
        $('#email').val(resumeData.basic.email || '');
        $('#brief-intro').val(resumeData.basic.briefIntro || '');
        
        if (resumeData.basic.avatar) {
            $('#avatar-preview').html('<img src="' + resumeData.basic.avatar + '" alt="头像" />');
        }
        
        $('#job-position').val(resumeData.jobIntention.position || '');
        $('#job-city').val(resumeData.jobIntention.city || '');
        $('#expected-salary').val(resumeData.jobIntention.salary || '');
        $('#job-status').val(resumeData.jobIntention.status || '');
        $('#job-type').val(resumeData.jobIntention.type || '');
        
        if (resumeData.workExperience) {
            resumeData.workExperience.forEach(function(exp, index) {
                addWorkExperience();
                const currentIndex = workExperienceCount;
                $('[name="work-date-' + currentIndex + '"]').val(exp.date || '');
                $('[name="work-company-' + currentIndex + '"]').val(exp.company || '');
                $('[name="work-position-' + currentIndex + '"]').val(exp.position || '');
                $('[name="work-content-' + currentIndex + '"]').val(exp.content || '');
            });
        }
        
        if (resumeData.education) {
            resumeData.education.forEach(function(edu, index) {
                addEducationBackground();
                const currentIndex = educationCount;
                $('[name="edu-date-' + currentIndex + '"]').val(edu.date || '');
                $('[name="edu-school-' + currentIndex + '"]').val(edu.school || '');
                $('[name="edu-major-' + currentIndex + '"]').val(edu.major || '');
                $('[name="edu-degree-' + currentIndex + '"]').val(edu.degree || '');
                $('[name="edu-courses-' + currentIndex + '"]').val(edu.courses || '');
            });
        }
        
        if (resumeData.skills) {
            resumeData.skills.forEach(function(skill) {
                addSkill();
                const currentIndex = skillCount;
                $('[name="skill-' + currentIndex + '"]').val(skill);
            });
        }
        
        $('#self-evaluation').val(resumeData.selfEvaluation || '');
    }
    
    function showModal(message) {
        $('#xb-aijianli-modal-body').html(message);
        $('#xb-aijianli-modal').show();
    }
    
    function hideModal() {
        $('#xb-aijianli-modal').hide();
    }
    
    function streamText($element, text, speed = 30) {
        return new Promise((resolve) => {
            $element.empty();
            let index = 0;
            
            function typeChar() {
                if (index < text.length) {
                    $element.text($element.text() + text.charAt(index));
                    index++;
                    setTimeout(typeChar, speed);
                } else {
                    resolve();
                }
            }
            
            typeChar();
        });
    }
    
    // AI功能
    window.startPolish = function() {
        if (!xbAijianli.isLoggedIn) {
            showModal('请先登录后使用AI功能');
            return;
        }
        
        updateResumeData();
        
        if (!resumeData.basic.name) {
            showModal('请至少填写姓名后再进行分析');
            return;
        }
        
        const $btn = $('#polish-btn');
        const $result = $('#polish-result');
        
        if (currentRequest) {
            currentRequest.abort();
        }
        
        $btn.prop('disabled', true).html('<span class="xb-aijianli-loading-spinner"></span>分析中...');
        $result.removeClass('loading').html('<div class="xb-aijianli-ai-loading"><span class="xb-aijianli-loading-spinner"></span>AI正在深度分析您的简历，请稍候...</div>');
        
        const requestData = Object.assign({}, resumeData);
        
        const selectedModel = $('#ai-model').val();
        if (selectedModel) {
            requestData.ai_model = selectedModel;
        }
        
        currentRequest = new AbortController();
        
        $.ajax({
            url: xbAijianli.restUrl + 'polish',
            method: 'POST',
            headers: {
                'X-WP-Nonce': xbAijianli.nonce
            },
            contentType: 'application/json',
            data: JSON.stringify(requestData),
            timeout: 120000,
            success: function(response) {
                $result.removeClass('loading').empty();
                
                if (response && response.content) {
                    var content = cleanAIResponse(response.content);
                    streamText($result, content, 20).then(() => {
                        console.log('AI分析完成');
                    });
                } else {
                    $result.text('分析完成，但返回内容为空');
                }
                
                updateUserStats();
            },
            error: function(xhr, status, error) {
                $result.removeClass('loading').empty();
                
                let errorMessage = '服务暂时不可用，请稍后重试';
                
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                } else if (status === 'timeout') {
                    errorMessage = '请求超时，请检查网络连接';
                } else if (status === 'error') {
                    errorMessage = '网络错误，请检查网络连接';
                } else if (status === 'abort') {
                    errorMessage = '请求已取消';
                }
                
                $result.text(errorMessage);
                console.error('AI分析失败:', {
                    status: status,
                    error: error,
                    response: xhr.responseText
                });
            },
            complete: function() {
                $btn.prop('disabled', false).text('开始分析');
                currentRequest = null;
            }
        });
    };
    
    window.startInterview = function() {
        if (!xbAijianli.isLoggedIn) {
            showModal('请先登录后使用AI功能');
            return;
        }
        
        updateResumeData();
        
        if (!resumeData.basic.name || !resumeData.jobIntention.position) {
            showModal('请至少填写姓名和意向岗位后再进行面试模拟');
            return;
        }
        
        const $btn = $('#interview-btn');
        const $result = $('#interview-result');
        
        if (currentRequest) {
            currentRequest.abort();
        }
        
        $btn.prop('disabled', true).html('<span class="xb-aijianli-loading-spinner"></span>模拟中...');
        $result.removeClass('loading').html('<div class="xb-aijianli-ai-loading"><span class="xb-aijianli-loading-spinner"></span>AI面试官正在准备问题，请稍候...</div>');
        
        const requestData = Object.assign({}, resumeData);
        
        const selectedModel = $('#ai-model').val();
        if (selectedModel) {
            requestData.ai_model = selectedModel;
        }
        
        currentRequest = new AbortController();
        
        $.ajax({
            url: xbAijianli.restUrl + 'interview',
            method: 'POST',
            headers: {
                'X-WP-Nonce': xbAijianli.nonce
            },
            contentType: 'application/json',
            data: JSON.stringify(requestData),
            timeout: 120000,
            success: function(response) {
                $result.removeClass('loading').empty();
                
                if (response && response.content) {
                    var content = cleanAIResponse(response.content);
                    streamText($result, content, 20).then(() => {
                        console.log('AI面试模拟完成');
                    });
                } else {
                    $result.text('面试模拟完成，但返回内容为空');
                }
                
                updateUserStats();
            },
            error: function(xhr, status, error) {
                $result.removeClass('loading').empty();
                
                let errorMessage = '服务暂时不可用，请稍后重试';
                
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                } else if (status === 'timeout') {
                    errorMessage = '请求超时，请检查网络连接';
                } else if (status === 'error') {
                    errorMessage = '网络错误，请检查网络连接';
                } else if (status === 'abort') {
                    errorMessage = '请求已取消';
                }
                
                $result.text(errorMessage);
                console.error('AI面试失败:', {
                    status: status,
                    error: error,
                    response: xhr.responseText
                });
            },
            complete: function() {
                $btn.prop('disabled', false).text('开始模拟');
                currentRequest = null;
            }
        });
    };
    
    function cleanAIResponse(content) {
        return content
            .replace(/#{1,6}\s*/g, '')
            .replace(/\*\*(.*?)\*\*/g, '$1')
            .replace(/\*(.*?)\*/g, '$1')
            .replace(/`(.*?)`/g, '$1')
            .replace(/^\s*[-*+]\s+/gm, '• ')
            .replace(/^\s*\d+\.\s+/gm, '• ')
            .replace(/```[\s\S]*?```/g, '')
            .replace(/\[.*?\]\(.*?\)/g, '')
            .replace(/^\s*>\s+/gm, '')
            .replace(/\{[\s\S]*?\}/g, '')
            .replace(/帮.*?生成.*?简历/gi, '')
            .replace(/继续.*?对话/gi, '')
            .replace(/如果.*?需要.*?帮助/gi, '')
            .replace(/还有.*?其他.*?问题/gi, '')
            .replace(/以下是.*?分析/gi, '')
            .replace(/希望.*?有帮助/gi, '')
            .trim();
    }
    
    function updateUserStats() {
        if (!xbAijianli.isLoggedIn) return;
        
        $.ajax({
            url: xbAijianli.restUrl + 'stats',
            method: 'GET',
            headers: {
                'X-WP-Nonce': xbAijianli.nonce
            },
            success: function(response) {
                if (response && typeof response.remaining !== 'undefined') {
                    $('#remaining-count').text(response.remaining);
                    
                    if (response.remaining <= 0) {
                        $('#polish-btn, #interview-btn').hide();
                        if ($('.xb-aijianli-limit-message').length === 0) {
                            $('.xb-aijianli-service-controls').append('<div class="xb-aijianli-limit-message">请明天再来</div>');
                        }
                    }
                }
            },
            error: function(xhr, status, error) {
                console.error('获取用户统计失败:', error);
            }
        });
    }
    
    // 复制功能
    window.copyPolishResult = function() {
        const text = $('#polish-result').text();
        const $btn = $('button[onclick="copyPolishResult()"]');
        
        if (text && text.trim()) {
            copyToClipboard(text, $btn);
        } else {
            showModal('没有可复制的内容');
        }
    };
    
    window.copyInterviewResult = function() {
        const text = $('#interview-result').text();
        const $btn = $('button[onclick="copyInterviewResult()"]');
        
        if (text && text.trim()) {
            copyToClipboard(text, $btn);
        } else {
            showModal('没有可复制的内容');
        }
    };
    
    function copyToClipboard(text, $btn) {
        const originalText = $btn.text();
        
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function() {
                showCopySuccess($btn, originalText);
            }).catch(function(err) {
                console.error('复制失败:', err);
                fallbackCopy(text, $btn, originalText);
            });
        } else {
            fallbackCopy(text, $btn, originalText);
        }
    }
    
    function fallbackCopy(text, $btn, originalText) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.select();
        
        try {
            document.execCommand('copy');
            showCopySuccess($btn, originalText);
        } catch (err) {
            console.error('复制失败:', err);
            $btn.text('复制失败').addClass('error');
            setTimeout(() => {
                $btn.text(originalText).removeClass('error');
            }, 2000);
        }
        
        document.body.removeChild(textArea);
    }
    
    function showCopySuccess($btn, originalText) {
        $btn.text('已复制').addClass('success');
        setTimeout(() => {
            $btn.text(originalText).removeClass('success');
        }, 2000);
    }
    
    // 清空结果
    window.clearPolishResult = function() {
        $('#polish-result').text('');
    };
    
    window.clearInterviewResult = function() {
        $('#interview-result').text('');
    };
    
    // 导出功能
    window.exportToPDF = function() {
        try {
            if (typeof window.jspdf === 'undefined') {
                showModal('PDF库未加载，请刷新页面重试');
                return;
            }
            
            if (typeof html2canvas === 'undefined') {
                showModal('html2canvas库未加载，请刷新页面重试');
                return;
            }
            
            updateResumeData();
            
            if (!resumeData.basic.name) {
                showModal('请至少填写姓名后再导出PDF');
                return;
            }
            
            showModal('正在生成PDF，请稍候...');
            
            const resumeElement = document.getElementById('resume-preview');
            if (!resumeElement) {
                hideModal();
                showModal('找不到简历预览内容');
                return;
            }
            
            if (!resumeElement.innerHTML.trim()) {
                hideModal();
                showModal('简历内容为空，请先填写简历信息');
                return;
            }
            
            const tempContainer = document.createElement('div');
            tempContainer.style.cssText = 'position: absolute; top: -9999px; left: -9999px; width: 800px; background: #ffffff; padding: 40px; font-family: ' + ($('#font-family').val() || "'Microsoft YaHei', sans-serif") + '; font-size: ' + ($('#content-font-size').val() || '14px') + '; line-height: 1.6; color: #333;';
            
            tempContainer.innerHTML = resumeElement.innerHTML;
            
            const themeColor = $('#theme-color').val() || '#667eea';
            const briefIntroColor = $('#brief-intro-color').val() || themeSettings.briefIntroColor;
            const styleElement = document.createElement('style');
            styleElement.textContent = `
                .xb-aijianli-resume-name, .xb-aijianli-resume-section-title { color: ${themeColor} !important; }
                .xb-aijianli-resume-brief { color: ${briefIntroColor} !important; text-align: center !important; }
                .xb-aijianli-resume-header { border-bottom: 2px solid ${themeColor} !important; padding-bottom: 15px !important; margin-bottom: 20px !important; }
                .xb-aijianli-resume-section-title { border-bottom: 1px solid ${themeColor} !important; padding-bottom: 5px !important; margin-bottom: 15px !important; font-weight: bold !important; font-size: ${themeSettings.sectionFontSize} !important; text-align: ${themeSettings.headerStyle} !important; }
                .xb-aijianli-resume-name { font-size: 28px !important; font-weight: bold !important; text-align: center !important; margin-bottom: 10px !important; }
                .xb-aijianli-resume-work-years { font-size: 16px !important; text-align: center !important; color: #666 !important; margin-bottom: 15px !important; }
                .xb-aijianli-resume-contact { text-align: center !important; margin-bottom: 8px !important; color: #666 !important; }
                .xb-aijianli-resume-intention-line { margin-bottom: 8px !important; }
                .xb-aijianli-resume-section { margin-bottom: ${themeSettings.sectionSpacing} !important; }
                .xb-aijianli-resume-item { margin-bottom: 15px !important; }
                .xb-aijianli-resume-item-header { font-weight: bold !important; margin-bottom: 5px !important; }
                .xb-aijianli-resume-item-meta { color: #666 !important; font-size: 12px !important; margin-bottom: 8px !important; }
                .xb-aijianli-resume-item-content { line-height: ${themeSettings.lineHeight} !important; margin-bottom: 10px !important; }
                img { max-width: 100% !important; height: auto !important; }
            `;
            tempContainer.appendChild(styleElement);
            
            document.body.appendChild(tempContainer);
            
            html2canvas(tempContainer, {
                backgroundColor: '#ffffff',
                scale: 3,
                useCORS: true,
                allowTaint: true,
                width: 800,
                height: tempContainer.scrollHeight,
                scrollX: 0,
                scrollY: 0,
                logging: false
            }).then(function(canvas) {
                document.body.removeChild(tempContainer);
                
                try {
                    const { jsPDF } = window.jspdf;
                    
                    const doc = new jsPDF({
                        orientation: 'portrait',
                        unit: 'mm',
                        format: 'a4'
                    });
                    
                    const pageWidth = 210;
                    const pageHeight = 297;
                    const margin = 10;
                    
                    const availableWidth = pageWidth - (margin * 2);
                    const availableHeight = pageHeight - (margin * 2);
                    
                    const canvasWidth = canvas.width;
                    const canvasHeight = canvas.height;
                    
                    const scaleX = availableWidth / (canvasWidth * 0.264583);
                    const scaleY = availableHeight / (canvasHeight * 0.264583);
                    const scale = Math.min(scaleX, scaleY, 1);
                    
                    const imgWidth = (canvasWidth * 0.264583) * scale;
                    const imgHeight = (canvasHeight * 0.264583) * scale;
                    
                    const x = (pageWidth - imgWidth) / 2;
                    const y = margin;
                    
                    const imgData = canvas.toDataURL('image/jpeg', 0.95);
                    
                    if (imgHeight > availableHeight) {
                        let currentY = 0;
                        let pageCount = 0;
                        
                        while (currentY < canvasHeight) {
                            if (pageCount > 0) {
                                doc.addPage();
                            }
                            
                            const remainingHeight = canvasHeight - currentY;
                            const pageCanvasHeight = Math.min(availableHeight / 0.264583 / scale, remainingHeight);
                            
                            const pageCanvas = document.createElement('canvas');
                            const pageCtx = pageCanvas.getContext('2d');
                            pageCanvas.width = canvasWidth;
                            pageCanvas.height = pageCanvasHeight;
                            
                            pageCtx.drawImage(canvas, 0, currentY, canvasWidth, pageCanvasHeight, 0, 0, canvasWidth, pageCanvasHeight);
                            
                            const pageImgData = pageCanvas.toDataURL('image/jpeg', 0.95);
                            const pageImgHeight = (pageCanvasHeight * 0.264583) * scale;
                            
                            doc.addImage(pageImgData, 'JPEG', x, margin, imgWidth, pageImgHeight);
                            
                            currentY += pageCanvasHeight;
                            pageCount++;
                        }
                    } else {
                        doc.addImage(imgData, 'JPEG', x, y, imgWidth, imgHeight);
                    }
                    
                    const fileName = (resumeData.basic && resumeData.basic.name ? resumeData.basic.name : '简历') + '.pdf';
                    doc.save(fileName);
                    
                    hideModal();
                    showModal('PDF导出成功！文件已保存为：' + fileName);
                    
                } catch (pdfError) {
                    console.error('PDF生成错误:', pdfError);
                    hideModal();
                    showModal('PDF生成失败：' + pdfError.message);
                }
            }).catch(function(canvasError) {
                console.error('Canvas生成错误:', canvasError);
                hideModal();
                showModal('图片生成失败：' + canvasError.message);
            });
            
        } catch (error) {
            console.error('PDF导出错误:', error);
            hideModal();
            showModal('PDF导出失败：' + error.message);
        }
    };
    
    window.exportToMarkdown = function() {
        updateResumeData();
        
        let markdown = '';
        
        if (resumeData.basic && resumeData.basic.name) {
            markdown += '# ' + resumeData.basic.name + '\n\n';
        }
        
        if (resumeData.basic && resumeData.basic.workYears) {
            markdown += '*' + resumeData.basic.workYears + '*\n\n';
        }
        
        if (resumeData.basic) {
            const basicInfo = [];
            if (resumeData.basic.age) basicInfo.push('**年龄：** ' + resumeData.basic.age);
            if (resumeData.basic.education) basicInfo.push('**学历：** ' + resumeData.basic.education);
            if (resumeData.basic.nationality) basicInfo.push('**民族：** ' + resumeData.basic.nationality);
            if (resumeData.basic.contact) basicInfo.push('**电话：** ' + resumeData.basic.contact);
            if (resumeData.basic.email) basicInfo.push('**邮箱：** ' + resumeData.basic.email);
            
            if (basicInfo.length > 0) {
                markdown += basicInfo.join(' | ') + '\n\n';
            }
            
            const basicInfo2 = [];
            if (resumeData.basic.hometown) basicInfo2.push('**籍贯：** ' + resumeData.basic.hometown);
            if (resumeData.basic.location) basicInfo2.push('**住址：** ' + resumeData.basic.location);
            if (resumeData.basic.affiliation) basicInfo2.push('**政治面貌：** ' + resumeData.basic.affiliation);
            
            if (basicInfo2.length > 0) {
                markdown += basicInfo2.join(' | ') + '\n\n';
            }
            
            if (resumeData.basic.briefIntro) {
                markdown += '*' + resumeData.basic.briefIntro + '*\n\n';
            }
        }
        
        if (resumeData.jobIntention && (resumeData.jobIntention.position || resumeData.jobIntention.city)) {
            markdown += '## 求职意向\n\n';
            
            const intentions1 = [];
            if (resumeData.jobIntention.position) intentions1.push('**意向岗位：** ' + resumeData.jobIntention.position);
            if (resumeData.jobIntention.city) intentions1.push('**意向城市：** ' + resumeData.jobIntention.city);
            if (resumeData.jobIntention.salary) intentions1.push('**期望薪资：** ' + resumeData.jobIntention.salary);
            
            if (intentions1.length > 0) {
                markdown += intentions1.join(' | ') + '\n\n';
            }
            
            const intentions2 = [];
            if (resumeData.jobIntention.status) intentions2.push('**求职状态：** ' + resumeData.jobIntention.status);
            if (resumeData.jobIntention.type) intentions2.push('**求职类型：** ' + resumeData.jobIntention.type);
            
            if (intentions2.length > 0) {
                markdown += intentions2.join(' | ') + '\n\n';
            }
        }
        
        if (resumeData.workExperience && resumeData.workExperience.length > 0) {
            markdown += '## 工作经验\n\n';
            
            resumeData.workExperience.forEach(function(exp) {
                markdown += '### ' + (exp.position || '职位') + ' - ' + (exp.company || '公司') + '\n\n';
                if (exp.date) {
                    markdown += '**时间：** ' + exp.date + '\n\n';
                }
                if (exp.content) {
                    markdown += exp.content + '\n\n';
                }
            });
        }
        
        if (resumeData.education && resumeData.education.length > 0) {
            markdown += '## 教育背景\n\n';
            
            resumeData.education.forEach(function(edu) {
                markdown += '### ' + (edu.school || '学校') + ' - ' + (edu.major || '专业') + '\n\n';
                
                const eduInfo = [];
                if (edu.date) eduInfo.push('**时间：** ' + edu.date);
                if (edu.degree) eduInfo.push('**学历：** ' + edu.degree);
                
                if (eduInfo.length > 0) {
                    markdown += eduInfo.join(' | ') + '\n\n';
                }
                
                if (edu.courses) {
                    markdown += '**主修课程：** ' + edu.courses + '\n\n';
                }
            });
        }
        
        if (resumeData.skills && resumeData.skills.length > 0) {
            markdown += '## 技能特长\n\n';
            
            resumeData.skills.forEach(function(skill) {
                markdown += '- ' + skill + '\n';
            });
            markdown += '\n';
        }
        
        if (resumeData.selfEvaluation) {
            markdown += '## 自我评价\n\n';
            markdown += resumeData.selfEvaluation + '\n\n';
        }
        
        const blob = new Blob([markdown], { type: 'text/markdown;charset=utf-8' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = (resumeData.basic && resumeData.basic.name ? resumeData.basic.name : '简历') + '.md';
        link.click();
        
        showModal('Markdown文件导出成功！');
    };
    
    window.exportToImage = function(format) {
        const element = document.getElementById('resume-preview');
        
        html2canvas(element, {
            backgroundColor: '#ffffff',
            scale: 2,
            useCORS: true,
            allowTaint: true
        }).then(function(canvas) {
            const link = document.createElement('a');
            link.download = (resumeData.basic.name || '简历') + '.' + format;
            
            if (format === 'jpg') {
                link.href = canvas.toDataURL('image/jpeg', 0.9);
            } else {
                link.href = canvas.toDataURL('image/png');
            }
            
            link.click();
            showModal('图片导出成功！');
        }).catch(function(error) {
            console.error('图片导出失败:', error);
            showModal('图片导出失败：' + error.message);
        });
    };
    
    // 本地数据管理
    window.saveToLocal = function() {
        updateResumeData();
        saveToLocalStorage();
        saveThemeSettings();
        showModal('简历数据和主题设置已保存到本地浏览器');
    };
    
    window.loadFromLocal = function() {
        if (confirm('载入本地数据将覆盖当前编辑的内容，确定要继续吗？')) {
            loadFromLocalStorage();
            loadThemeSettings();
            populateForm();
            populateThemeControls();
            updatePreview();
            showModal('本地数据和主题设置已载入');
        }
    };
    
    window.clearLocalData = function() {
        if (confirm('确定要删除本地保存的简历数据和主题设置吗？此操作不可恢复！')) {
            localStorage.removeItem('xb_aijianli_resume_data');
            localStorage.removeItem('xb_aijianli_theme_settings');
            showModal('本地简历数据和主题设置已删除');
        }
    };
    
    function debounce(fn, wait) {
        let timer;
        return function() {
            const context = this;
            const args = arguments;
            clearTimeout(timer);
            timer = setTimeout(function() {
                fn.apply(context, args);
            }, wait);
        };
    }

})(jQuery);
