<?php
/**
 * Plugin Name: 启灵AI简历
 * Plugin URI: https://www.wujiit.com
 * Description: 基于阿里云通义千问API的AI简历生成与润色插件，支持简历润色、面试官模拟等功能
 * Version: 1.0.2
 * Author: summer
 */

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

class XB_AIJianli {
    
    public function __construct() {
        add_action('init', array($this, 'xb_aijianli_init'));
        register_activation_hook(__FILE__, array($this, 'xb_aijianli_activate'));
        register_deactivation_hook(__FILE__, array($this, 'xb_aijianli_deactivate'));
        add_action('admin_menu', array($this, 'xb_aijianli_admin_menu'));
        add_action('rest_api_init', array($this, 'xb_aijianli_register_rest_routes'));

    }
    
    /**
     * 插件初始化
     */
    public function xb_aijianli_init() {
        // 创建前台页面
        $this->xb_aijianli_create_frontend_page();
        
        // 加载前端资源
        add_action('wp_enqueue_scripts', array($this, 'xb_aijianli_enqueue_scripts'));
    }
    
    /**
     * 插件激活
     */
    public function xb_aijianli_activate() {
        $this->xb_aijianli_create_tables();
        $this->xb_aijianli_create_frontend_page();
    }
    
    /**
     * 插件停用
     */
    public function xb_aijianli_deactivate() {
        // 清理工作
    }
    

    
    /**
     * 创建数据库表 - 增加原始错误信息字段
     */
    private function xb_aijianli_create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // 用户使用记录表 - 增加原始错误信息字段
        $table_records = $wpdb->prefix . 'xb_aijianli_records';
        $sql_records = "CREATE TABLE $table_records (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            user_ip varchar(45) NOT NULL,
            user_name varchar(100) NOT NULL,
            user_contact varchar(100) NOT NULL,
            service_type varchar(20) NOT NULL,
            ai_model varchar(50) NOT NULL,
            status varchar(20) NOT NULL,
            error_message text,
            raw_error_code varchar(50),
            raw_error_message text,
            api_response_code int(11),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // 用户使用限制表
        $table_limits = $wpdb->prefix . 'xb_aijianli_user_limits';
        $sql_limits = "CREATE TABLE $table_limits (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            daily_limit int(11) NOT NULL DEFAULT 10,
            used_count int(11) NOT NULL DEFAULT 0,
            last_reset_date date NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY user_id (user_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_records);
        dbDelta($sql_limits);
    }
    
    /**
     * 创建前台页面
     */
private function xb_aijianli_create_frontend_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_aijianli_frontend]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => 'AI简历生成与润色',
            'post_content' => '[xb_aijianli_frontend]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
    
    // 注册短代码
    add_shortcode('xb_aijianli_frontend', array($this, 'xb_aijianli_frontend_shortcode'));
}
    
    /**
     * 加载前端资源
     */
public function xb_aijianli_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_aijianli_frontend')) {
        wp_enqueue_script('jquery');
        wp_enqueue_script('xb-aijianli-script', plugin_dir_url(__FILE__) . 'script.js', array('jquery'), '1.0.0', true);
        wp_enqueue_style('xb-aijianli-style', plugin_dir_url(__FILE__) . 'style.css', array(), '1.0.0');
        
        // 加载第三方库
        wp_enqueue_script('html2canvas', 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js', array(), '1.4.1', true);
        wp_enqueue_script('jspdf', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', array(), '2.5.1', true);
        
        // 传递数据到前端
        wp_localize_script('xb-aijianli-script', 'xbAijianli', array(
            'restUrl' => rest_url('xb-aijianli/v1/'),
            'nonce' => wp_create_nonce('wp_rest'),
            'isLoggedIn' => is_user_logged_in(),
            'pluginUrl' => plugin_dir_url(__FILE__)
        ));
    }
}
    
    /**
     * 前台页面短代码
     */
    public function xb_aijianli_frontend_shortcode() {
        ob_start();
        ?>
        <div id="xb-aijianli-app">
            <!-- 页面标题 -->
            <div class="xb-aijianli-header">
                <div class="xb-aijianli-main-title">简历生成与AI优化模拟</div>
                <div class="xb-aijianli-main-sutitle">简历资料本地保存 ‧ AI优化建议 ‧ 模拟面试官</div>
            </div>
            
            <!-- 主要内容区域 -->
            <div class="xb-aijianli-main-content">
                <!-- 左侧：简历编辑区 -->
                <div class="xb-aijianli-left-panel">
                    <!-- 简历编辑区块 -->
                    <div class="xb-aijianli-section xb-aijianli-neumorphic">
                        <div class="xb-aijianli-section-title">简历编辑</div>
                        
                        <!-- 简历标题 -->
                        <div class="xb-aijianli-field">
                            <label class="xb-aijianli-label">简历标题</label>
                            <input type="text" id="resume-title" class="xb-aijianli-input" placeholder="请输入简历标题" />
                        </div>
                        
                        <!-- 基本资料 -->
                        <div class="xb-aijianli-subsection">
                            <div class="xb-aijianli-subsection-title">基本资料</div>
                            <div class="xb-aijianli-form-grid">
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">姓名 <span style="color: red;">*</span></label>
                                    <input type="text" id="name" class="xb-aijianli-input" placeholder="请输入姓名" required />
                                </div>
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">年龄</label>
                                    <input type="number" id="age" class="xb-aijianli-input" placeholder="请输入年龄" />
                                </div>
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">学历</label>
                                    <select id="education" class="xb-aijianli-select">
                                        <option value="">请选择学历</option>
                                        <option value="小学">小学</option>
                                        <option value="初中">初中</option>
                                        <option value="高中">高中</option>
                                        <option value="中专">中专</option>
                                        <option value="大专">大专</option>
                                        <option value="本科">本科</option>
                                        <option value="硕士">硕士</option>
                                        <option value="博士">博士</option>
                                        <option value="副教授">副教授</option>
                                        <option value="教授">教授</option>
                                    </select>
                                </div>
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">民族</label>
                                    <input type="text" id="nationality" class="xb-aijianli-input" placeholder="请输入民族" />
                                </div>                                
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">住址</label>
                                    <input type="text" id="location" class="xb-aijianli-input" placeholder="请输入所在地区" />
                                </div>
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">籍贯</label>
                                    <input type="text" id="hometown" class="xb-aijianli-input" placeholder="请输入籍贯" />
                                </div>
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">政治面貌(可以不写)</label>
                                    <input type="text" id="affiliation" class="xb-aijianli-input" placeholder="请输入政治面貌(不要乱填)" />
                                </div>
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">工作年限</label>
                                    <input type="text" id="work-years" class="xb-aijianli-input" placeholder="请输入工作年限，如：3年、应届毕业生等" />
                                </div>
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">联系方式</label>
                                    <input type="tel" id="contact" class="xb-aijianli-input" placeholder="请输入联系方式" />
                                </div>
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">联系邮箱</label>
                                    <input type="email" id="email" class="xb-aijianli-input" placeholder="请输入联系邮箱" />
                                </div>
                            </div>
                            <div class="xb-aijianli-field">
                                <label class="xb-aijianli-label">头像</label>
                                <div class="xb-aijianli-avatar-upload" id="avatar-preview">
                                    <div class="xb-aijianli-avatar-placeholder">
                                        点击或拖拽上传头像
                                    </div>
                                    <input type="file" id="avatar" accept="image/*" style="display: none;" />
                                </div>
                            </div>
                            <div class="xb-aijianli-field">
                                <label class="xb-aijianli-label">一句话简介</label>
                                <textarea id="brief-intro" class="xb-aijianli-textarea" placeholder="请输入一句话简介" rows="2"></textarea>
                            </div>
                        </div>
                        
                        <!-- 求职意向 -->
                        <div class="xb-aijianli-subsection">
                            <div class="xb-aijianli-subsection-title">求职意向</div>
                            <div class="xb-aijianli-form-grid">
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">意向岗位</label>
                                    <input type="text" id="job-position" class="xb-aijianli-input" placeholder="请输入意向岗位" />
                                </div>
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">意向城市</label>
                                    <input type="text" id="job-city" class="xb-aijianli-input" placeholder="请输入意向城市" />
                                </div>
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">期望薪资</label>
                                    <input type="text" id="expected-salary" class="xb-aijianli-input" placeholder="请输入期望薪资" />
                                </div>
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">求职状态</label>
                                    <select id="job-status" class="xb-aijianli-select">
                                        <option value="">请选择求职状态</option>
                                        <option value="目前在职，正在寻找新机会">目前在职，正在寻找新机会</option>
                                        <option value="目前离职，可立即上岗">目前离职，可立即上岗</option>
                                        <option value="应届毕业生">应届毕业生</option>
                                    </select>
                                </div>
                                <div class="xb-aijianli-field">
                                    <label class="xb-aijianli-label">求职类型</label>
                                    <select id="job-type" class="xb-aijianli-select">
                                        <option value="">请选择求职类型</option>
                                        <option value="全职">全职</option>
                                        <option value="兼职">兼职</option>
                                        <option value="实习">实习</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <!-- 工作经验 -->
                        <div class="xb-aijianli-subsection">
                            <div class="xb-aijianli-subsection-title">
                                工作经验(可拖动调整位置)
                                <button type="button" class="xb-aijianli-btn xb-aijianli-btn-add" onclick="addWorkExperience()">+ 添加</button>
                            </div>
                            <div id="work-experience-list" class="xb-aijianli-list"></div>
                        </div>
                        
                        <!-- 教育背景 -->
                        <div class="xb-aijianli-subsection">
                            <div class="xb-aijianli-subsection-title">
                                教育背景(可拖动调整位置)
                                <button type="button" class="xb-aijianli-btn xb-aijianli-btn-add" onclick="addEducationBackground()">+ 添加</button>
                            </div>
                            <div id="education-background-list" class="xb-aijianli-list"></div>
                        </div>
                        
                        <!-- 技能特长 -->
                        <div class="xb-aijianli-subsection">
                            <div class="xb-aijianli-subsection-title">
                                技能特长(可拖动调整位置)
                                <button type="button" class="xb-aijianli-btn xb-aijianli-btn-add" onclick="addSkill()">+ 添加</button>
                            </div>
                            <div id="skills-list" class="xb-aijianli-list"></div>
                        </div>
                        
                        <!-- 自我评价 -->
                        <div class="xb-aijianli-subsection">
                            <div class="xb-aijianli-subsection-title">自我评价</div>
                            <div class="xb-aijianli-field">
                                <textarea id="self-evaluation" class="xb-aijianli-textarea" placeholder="请输入自我评价" rows="4"></textarea>
                            </div>
                        </div>
                        
                        <!-- 本地数据管理 -->
                        <div class="xb-aijianli-subsection">
                            <div class="xb-aijianli-subsection-title">本地数据管理(保存到浏览器)</div>
                            <div class="xb-aijianli-local-data-controls">
                                <button type="button" class="xb-aijianli-btn" onclick="saveToLocal()">保存到本地</button>
                                <button type="button" class="xb-aijianli-btn" onclick="loadFromLocal()">载入本地数据</button>
                                <button type="button" class="xb-aijianli-btn" onclick="clearLocalData()">删除本地数据</button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 右侧：简历预览区 -->
                <div class="xb-aijianli-right-panel">
                    <div class="xb-aijianli-section xb-aijianli-neumorphic">
                        <div class="xb-aijianli-section-title">简历预览</div>
                        
                        <!-- 预览控制 -->
                        <div class="xb-aijianli-theme-controls">
                            <div class="xb-aijianli-control-group">
                                <label class="xb-aijianli-label">主题色</label>
                                <input type="color" id="theme-color" class="xb-aijianli-input" value="#667eea" />
                            </div>

                            <div class="xb-aijianli-control-group">
                                <label class="xb-aijianli-label">字体</label>
                                <select id="font-family" class="xb-aijianli-select">
                                    <option value="Arial, sans-serif">Arial</option>
                                    <option value="'Microsoft YaHei', sans-serif">微软雅黑</option>
                                    <option value="'SimSun', serif">宋体</option>
                                    <option value="'SimHei', sans-serif">黑体</option>
                                </select>
                            </div>
                            
                                <div class="xb-aijianli-control-group">
                                    <label class="xb-aijianli-label">简历布局</label>
                                    <select id="layout-style" class="xb-aijianli-select">
                                        <option value="default">默认布局</option>
                                        <option value="left-avatar">左侧头像布局</option>
                                    </select>
                                </div>

                                <div class="xb-aijianli-control-group">
                                    <label class="xb-aijianli-label">头像形状</label>
                                    <select id="avatar-shape" class="xb-aijianli-select">
                                        <option value="circle">圆形头像</option>
                                        <option value="rectangle">证件照头像</option>
                                    </select>
                                </div>

                                <div class="xb-aijianli-control-group">
                                    <label class="xb-aijianli-label">板块标题字体</label>
                                    <select id="section-font-size" class="xb-aijianli-select">
                                        <option value="16px">16px</option>
                                        <option value="18px" selected>18px</option>
                                        <option value="20px">20px</option>
                                        <option value="22px">22px</option>
                                    </select>
                                </div>

                                <div class="xb-aijianli-control-group">
                                    <label class="xb-aijianli-label">内容字体大小</label>
                                    <select id="content-font-size" class="xb-aijianli-select">
                                        <option value="12px">12px</option>
                                        <option value="14px" selected>14px</option>
                                        <option value="16px">16px</option>
                                        <option value="18px">18px</option>
                                    </select>
                                </div>

                                <div class="xb-aijianli-control-group">
                                    <label class="xb-aijianli-label">行高设置</label>
                                    <select id="line-height" class="xb-aijianli-select">
                                        <option value="1.4">紧凑 (1.4)</option>
                                        <option value="1.6" selected>标准 (1.6)</option>
                                        <option value="1.8">宽松 (1.8)</option>
                                        <option value="2.0">超宽松 (2.0)</option>
                                    </select>
                                </div>

                                <div class="xb-aijianli-control-group">
                                    <label class="xb-aijianli-label">板块间距</label>
                                    <select id="section-spacing" class="xb-aijianli-select">
                                        <option value="20px">紧凑 (20px)</option>
                                        <option value="25px" selected>标准 (25px)</option>
                                        <option value="30px">宽松 (30px)</option>
                                        <option value="35px">超宽松 (35px)</option>
                                    </select>
                                </div>

                                <div class="xb-aijianli-control-group">
                                    <label class="xb-aijianli-label">标题对齐</label>
                                    <select id="header-style" class="xb-aijianli-select">
                                        <option value="center" selected>居中对齐</option>
                                        <option value="left">左对齐</option>
                                    </select>
                                </div>

<div class="xb-aijianli-control-group">
    <label class="xb-aijianli-label">简介字体颜色</label>
    <input type="color" id="brief-intro-color" class="xb-aijianli-input" value="#333333" />
</div>
                                <div class="xb-aijianli-control-group">
                                    <label class="xb-aijianli-label">显示边框</label>
                                    <select id="show-border" class="xb-aijianli-select">
                                        <option value="true" selected>显示</option>
                                        <option value="false">隐藏</option>
                                    </select>
                                </div>

                            
                        </div>
                        
                        <!-- 简历预览内容 -->
                        <div id="resume-preview" class="xb-aijianli-resume-preview">
                            <!-- 预览内容将通过JavaScript动态生成 -->
                        </div>
                        
                        <!-- 导出按钮 -->
                        <div class="xb-aijianli-export-controls">
                            <button type="button" class="xb-aijianli-btn xb-aijianli-btn-primary" onclick="exportToPDF()">导出PDF</button>
                            <button type="button" class="xb-aijianli-btn" onclick="exportToMarkdown()">导出Markdown</button>
                            <button type="button" class="xb-aijianli-btn" onclick="exportToImage('png')">导出PNG</button>
                            <button type="button" class="xb-aijianli-btn" onclick="exportToImage('jpg')">导出JPG</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- AI服务区域 -->
            <?php if (is_user_logged_in()): ?>
                <?php
                $user_id = get_current_user_id();
                $stats = $this->xb_aijianli_get_user_usage_stats($user_id);
                $show_stats = get_option('xb_aijianli_show_stats', 1);
                $show_model_select = get_option('xb_aijianli_show_model_select', 0);
                $ai_models = get_option('xb_aijianli_ai_models', 'qwen-plus');
                $model_list = array_map('trim', explode(',', $ai_models));
                $enable_polish = get_option('xb_aijianli_enable_polish', 1);
                $enable_interview = get_option('xb_aijianli_enable_interview', 1);
                ?>
                
                <!-- AI控制面板 - 移动到AI简历润色板块上面 -->
                <?php if ($show_stats || ($show_model_select && count($model_list) > 1)): ?>
                <div class="xb-aijianli-ai-controls-section">
                    <div class="xb-aijianli-section xb-aijianli-neumorphic">
                        <div class="xb-aijianli-section-title">AI设置</div>
                        <div class="xb-aijianli-ai-controls-grid">
                            <?php if ($show_model_select && count($model_list) > 1): ?>
                            <div class="xb-aijianli-model-selector">
                                <label class="xb-aijianli-label">AI模型选择</label>
                                <select id="ai-model" class="xb-aijianli-select">
                                    <?php foreach ($model_list as $model): ?>
                                        <option value="<?php echo esc_attr($model); ?>"><?php echo esc_html($model); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                            
                            <?php if ($show_stats): ?>
                            <div class="xb-aijianli-usage-stats">
                                <div class="xb-aijianli-stats-card">
                                    <div class="xb-aijianli-stats-label">今日剩余次数</div>
                                    <div class="xb-aijianli-stats-count">
                                        <span id="remaining-count"><?php echo $stats['remaining']; ?></span>
                                        <span class="xb-aijianli-stats-total">/ <?php echo $stats['daily_limit']; ?></span>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- AI润色 -->
                <?php if ($enable_polish): ?>
                <div class="xb-aijianli-ai-service">
                    <div class="xb-aijianli-section xb-aijianli-neumorphic">
                        <div class="xb-aijianli-section-title">AI简历分析与优化建议</div>
                        <div class="xb-aijianli-service-content">
                            <div class="xb-aijianli-service-controls">
                                <?php if ($stats['remaining'] > 0): ?>
                                    <button type="button" id="polish-btn" class="xb-aijianli-btn xb-aijianli-btn-primary" onclick="startPolish()">开始分析</button>
                                <?php else: ?>
                                    <div class="xb-aijianli-limit-message">请明天再来</div>
                                <?php endif; ?>
                                <button type="button" id="copy-polish-btn" class="xb-aijianli-btn" onclick="copyPolishResult()">复制</button>
                                <button type="button" class="xb-aijianli-btn" onclick="clearPolishResult()">清空</button>
                            </div>
                            <div id="polish-result" class="xb-aijianli-result"></div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- AI面试官模拟 -->
                <?php if ($enable_interview): ?>
                <div class="xb-aijianli-ai-service">
                    <div class="xb-aijianli-section xb-aijianli-neumorphic">
                        <div class="xb-aijianli-section-title">AI面试官模拟</div>
                        <div class="xb-aijianli-service-content">
                            <div class="xb-aijianli-service-controls">
                                <?php if ($stats['remaining'] > 0): ?>
                                    <button type="button" id="interview-btn" class="xb-aijianli-btn xb-aijianli-btn-primary" onclick="startInterview()">开始模拟</button>
                                <?php else: ?>
                                    <div class="xb-aijianli-limit-message">请明天再来</div>
                                <?php endif; ?>
                                <button type="button" id="copy-interview-btn" class="xb-aijianli-btn" onclick="copyInterviewResult()">复制</button>
                                <button type="button" class="xb-aijianli-btn" onclick="clearInterviewResult()">清空</button>
                            </div>
                            <div id="interview-result" class="xb-aijianli-result"></div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php else: ?>
                <!-- 游客提示 -->
                <div class="xb-aijianli-guest-notice">
                    <div class="xb-aijianli-section xb-aijianli-neumorphic">
                        <div class="xb-aijianli-section-title">AI功能</div>
                        <div style="text-align: center; padding: 30px;">
                            <p>请先登录才能使用AI功能</p>
                            <a href="<?php echo wp_login_url(get_permalink()); ?>" class="xb-aijianli-btn xb-aijianli-btn-primary">立即登录</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- 公告区域 -->
            <?php 
            $announcement = get_option('xb_aijianli_announcement', '');
            if (!empty($announcement)): 
            ?>
            <div class="xb-aijianli-announcement">
                <div class="xb-aijianli-section xb-aijianli-neumorphic">
                    <div class="xb-aijianli-announcement-title">提示说明</div>
                    <div class="xb-aijianli-announcement-content">
                        <?php echo wp_kses_post($announcement); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- 模态框 -->
        <div id="xb-aijianli-modal" class="xb-aijianli-modal">
            <div class="xb-aijianli-modal-content">
                <button class="xb-aijianli-modal-close">&times;</button>
                <div id="xb-aijianli-modal-body"></div>
            </div>
        </div>
        
        <?php
        return ob_get_clean();
    }
    
    /**
     * 后台管理菜单
     */
    public function xb_aijianli_admin_menu() {
        add_menu_page(
            'AI简历',
            'AI简历',
            'manage_options',
            'xb-aijianli',
            array($this, 'xb_aijianli_admin_page'),
            'dashicons-id-alt',
            30
        );
        
        add_submenu_page(
            'xb-aijianli',
            'AI简历设置',
            '基本设置',
            'manage_options',
            'xb-aijianli',
            array($this, 'xb_aijianli_admin_page')
        );
        
        add_submenu_page(
            'xb-aijianli',
            '用户管理',
            '用户管理',
            'manage_options',
            'xb-aijianli-users',
            array($this, 'xb_aijianli_users_page')
        );
        
        add_submenu_page(
            'xb-aijianli',
            '使用记录',
            '使用记录',
            'manage_options',
            'xb-aijianli-records',
            array($this, 'xb_aijianli_records_page')
        );
    }
    
    /**
     * 基本设置页面 - 优化：将富文本框改为textarea，支持HTML格式
     */
    public function xb_aijianli_admin_page() {
        if (isset($_POST['submit'])) {
            check_admin_referer('xb_aijianli_save_settings', 'xb_aijianli_settings_nonce');
            // 更新配置选项
            update_option('xb_aijianli_api_url', sanitize_text_field($_POST['api_url']));
            update_option('xb_aijianli_api_key', sanitize_text_field($_POST['api_key']));
            update_option('xb_aijianli_ai_models', sanitize_text_field($_POST['ai_models']));
            update_option('xb_aijianli_daily_limit', intval($_POST['daily_limit']));
            update_option('xb_aijianli_enable_polish', isset($_POST['enable_polish']) ? 1 : 0);
            update_option('xb_aijianli_enable_interview', isset($_POST['enable_interview']) ? 1 : 0);
            update_option('xb_aijianli_show_stats', isset($_POST['show_stats']) ? 1 : 0);
            update_option('xb_aijianli_show_model_select', isset($_POST['show_model_select']) ? 1 : 0);
            update_option('xb_aijianli_forbidden_words', sanitize_textarea_field($_POST['forbidden_words']));
            
            // 优化：公告内容使用wp_kses_post处理，支持HTML格式
            update_option('xb_aijianli_announcement', wp_kses_post($_POST['announcement']));
            
            // 显示成功提示（会自动3秒消失）
            echo '<div class="notice notice-success"><p>设置已保存！</p></div>';
        }
        
        // 获取当前配置
        $api_url = get_option('xb_aijianli_api_url', 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions');
        $api_key = get_option('xb_aijianli_api_key', '');
        $ai_models = get_option('xb_aijianli_ai_models', 'qwen-plus,qwen-max');
        $daily_limit = get_option('xb_aijianli_daily_limit', 10);
        $enable_polish = get_option('xb_aijianli_enable_polish', 1);
        $enable_interview = get_option('xb_aijianli_enable_interview', 1);
        $show_stats = get_option('xb_aijianli_show_stats', 1);
        $show_model_select = get_option('xb_aijianli_show_model_select', 0);
        $forbidden_words = get_option('xb_aijianli_forbidden_words', '');
        $announcement = get_option('xb_aijianli_announcement', '');
        
        ?>
        <div class="wrap">
            <div class="xb-aijianli-admin-title">AI简历设置</div>
            <form method="post" action="">
                <?php wp_nonce_field('xb_aijianli_save_settings', 'xb_aijianli_settings_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">API接口地址</th>
                        <td><input type="url" name="api_url" value="<?php echo esc_attr($api_url); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th scope="row">API密钥</th>
                        <td><input type="text" name="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th scope="row">AI模型</th>
                        <td>
                            <input type="text" name="ai_models" value="<?php echo esc_attr($ai_models); ?>" class="regular-text" />
                            <p class="description">多个模型用英文逗号分隔，如：qwen-plus,qwen-max</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">每日使用限制</th>
                        <td><input type="number" name="daily_limit" value="<?php echo esc_attr($daily_limit); ?>" min="1" /></td>
                    </tr>
                    <tr>
                        <th scope="row">功能开关</th>
                        <td>
                            <label><input type="checkbox" name="enable_polish" <?php checked($enable_polish); ?> /> 启用AI润色功能</label><br>
                            <label><input type="checkbox" name="enable_interview" <?php checked($enable_interview); ?> /> 启用AI面试官模拟功能</label><br>
                            <label><input type="checkbox" name="show_stats" <?php checked($show_stats); ?> /> 前台显示统计信息</label><br>
                            <label><input type="checkbox" name="show_model_select" <?php checked($show_model_select); ?> /> 前台显示模型选择</label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">违规词设置</th>
                        <td>
                            <textarea name="forbidden_words" rows="5" cols="50"><?php echo esc_textarea($forbidden_words); ?></textarea>
                            <p class="description">多个违规词用英文逗号分隔</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">公告内容</th>
                        <td>
                            <!-- 优化：改为textarea输入框，支持HTML格式 -->
                            <textarea name="announcement" rows="8" cols="80" class="large-text" placeholder="支持HTML格式，如：&lt;p&gt;这是一段公告&lt;/p&gt;&lt;br&gt;&lt;strong&gt;重要提示&lt;/strong&gt;"><?php echo esc_textarea($announcement); ?></textarea>
                            <p class="description">
                                支持HTML格式输入，常用标签：<br>
                                &lt;p&gt;段落&lt;/p&gt; | &lt;br&gt;换行 | &lt;strong&gt;粗体&lt;/strong&gt; | &lt;em&gt;斜体&lt;/em&gt;<br>
                                &lt;a href="链接"&gt;链接文字&lt;/a&gt; | &lt;ul&gt;&lt;li&gt;列表项&lt;/li&gt;&lt;/ul&gt;
                            </p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <script>
        jQuery(document).ready(function($) {
            // 3秒自动消失功能
            setTimeout(function() {
                $('.notice.notice-success, .notice.notice-error, .notice.notice-warning').fadeOut(500);
            }, 3000);
        });
        </script>
        <?php
    }
    
    /**
     * 用户管理页面 - 新增：删除用户所有记录功能
     */
    public function xb_aijianli_users_page() {
        global $wpdb;
        
        // 处理表单提交
        if (isset($_POST['search_user'])) {
            check_admin_referer('xb_aijianli_user_actions', 'xb_aijianli_user_actions_nonce');
            $search_user_id = intval($_POST['user_id']);
            $user_info = get_userdata($search_user_id);
            
            if ($user_info) {
                $stats = $this->xb_aijianli_get_user_usage_stats($search_user_id);
                
                // 处理设置用户限制
                if (isset($_POST['set_user_limit'])) {
                    $new_limit = intval($_POST['new_limit']);
                    $this->xb_aijianli_set_user_limit($search_user_id, $new_limit);
                    echo '<div class="notice notice-success"><p>用户限制已更新！</p></div>';
                    // 重新获取统计信息
                    $stats = $this->xb_aijianli_get_user_usage_stats($search_user_id);
                }
                
                // 处理重置用户使用次数
                if (isset($_POST['reset_user_usage'])) {
                    $this->xb_aijianli_reset_user_usage($search_user_id);
                    echo '<div class="notice notice-success"><p>用户使用次数已重置！</p></div>';
                    // 重新获取统计信息
                    $stats = $this->xb_aijianli_get_user_usage_stats($search_user_id);
                }
                
                // 新增：处理删除用户所有记录
                if (isset($_POST['delete_user_records'])) {
                    $table_records = $wpdb->prefix . 'xb_aijianli_records';
                    $deleted_count = $wpdb->delete($table_records, array('user_id' => $search_user_id), array('%d'));
                    
                    if ($deleted_count !== false) {
                        echo '<div class="notice notice-success"><p>已删除该用户的 ' . $deleted_count . ' 条使用记录！</p></div>';
                    } else {
                        echo '<div class="notice notice-error"><p>删除记录时发生错误！</p></div>';
                    }
                }
                
                echo '<div class="wrap">';
                echo '<div class="xb-aijianli-admin-title">用户管理</div>';
                echo '<div class="xb-aijianli-admin-subtitle">用户信息</div>';
                echo '<table class="form-table">';
                echo '<tr><th>用户ID</th><td>' . esc_html($user_info->ID) . '</td></tr>';
                echo '<tr><th>用户名</th><td>' . esc_html($user_info->user_login) . '</td></tr>';
                echo '<tr><th>邮箱</th><td>' . esc_html($user_info->user_email) . '</td></tr>';
                echo '<tr><th>每日限制</th><td>' . esc_html($stats['daily_limit']) . '</td></tr>';
                echo '<tr><th>已使用</th><td>' . esc_html($stats['used_count']) . '</td></tr>';
                echo '<tr><th>剩余次数</th><td>' . esc_html($stats['remaining']) . '</td></tr>';
                echo '</table>';
                
                // 获取用户记录统计
                $table_records = $wpdb->prefix . 'xb_aijianli_records';
                $user_records_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_records WHERE user_id = %d", $search_user_id));
                
                echo '<div class="xb-aijianli-admin-section-title">用户记录统计</div>';
                echo '<table class="form-table">';
                echo '<tr><th>总使用记录数</th><td>' . esc_html($user_records_count) . '</td></tr>';
                echo '</table>';
                
                // 设置用户限制表单
                echo '<div class="xb-aijianli-admin-section-title">设置用户限制</div>';
                echo '<form method="post" action="">';
                echo wp_nonce_field('xb_aijianli_user_actions', 'xb_aijianli_user_actions_nonce', true, false);
                echo '<input type="hidden" name="user_id" value="' . $search_user_id . '" />';
                echo '<input type="hidden" name="search_user" value="1" />';
                echo '<table class="form-table">';
                echo '<tr><th>每日限制</th><td><input type="number" name="new_limit" value="' . $stats['daily_limit'] . '" min="0" /></td></tr>';
                echo '</table>';
                echo '<input type="submit" name="set_user_limit" class="button-primary" value="设置限制" />';
                echo '</form>';
                
                // 用户操作区域
                echo '<div class="xb-aijianli-admin-section-title">用户操作</div>';
                echo '<div style="margin-bottom: 20px;">';
                
                // 重置使用次数
                echo '<form method="post" action="" style="display: inline-block; margin-right: 10px;">';
                echo wp_nonce_field('xb_aijianli_user_actions', 'xb_aijianli_user_actions_nonce', true, false);
                echo '<input type="hidden" name="user_id" value="' . $search_user_id . '" />';
                echo '<input type="hidden" name="search_user" value="1" />';
                echo '<input type="submit" name="reset_user_usage" class="button" value="重置使用次数" onclick="return confirm(\'确定要重置该用户的使用次数吗？\')" />';
                echo '</form>';
                
                // 新增：删除用户所有记录按钮
                if ($user_records_count > 0) {
                    echo '<form method="post" action="" style="display: inline-block;">';
                    echo wp_nonce_field('xb_aijianli_user_actions', 'xb_aijianli_user_actions_nonce', true, false);
                    echo '<input type="hidden" name="user_id" value="' . $search_user_id . '" />';
                    echo '<input type="hidden" name="search_user" value="1" />';
                    echo '<input type="submit" name="delete_user_records" class="button button-secondary" value="删除所有使用记录 (' . $user_records_count . '条)" onclick="return confirm(\'确定要删除该用户的所有使用记录吗？此操作不可恢复！\')" style="color: #d63638;" />';
                    echo '</form>';
                } else {
                    echo '<span style="color: #666;">该用户暂无使用记录</span>';
                }
                
                echo '</div>';
                echo '</div>';
                
                return;
            } else {
                echo '<div class="notice notice-error"><p>用户不存在！</p></div>';
            }
        }
        
        ?>
        <div class="wrap">
            <div class="xb-aijianli-admin-title">用户管理</div>
            
            <form method="post" action="">
                <?php wp_nonce_field('xb_aijianli_user_actions', 'xb_aijianli_user_actions_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">搜索用户</th>
                        <td>
                            <input type="number" name="user_id" placeholder="请输入用户ID" required />
                            <input type="submit" name="search_user" class="button-primary" value="搜索" />
                            <p class="description">输入用户ID进行搜索，搜索后可以管理该用户的使用限制和记录</p>
                        </td>
                    </tr>
                </table>
            </form>
        </div>
        <?php
    }
    
    /**
     * 使用记录页面 - 增加原始错误信息显示，优化提示消息
     */
    public function xb_aijianli_records_page() {
        global $wpdb;
        
        // 处理删除操作
        if (isset($_POST['delete_all_records'])) {
            check_admin_referer('xb_aijianli_delete_all_records', 'xb_aijianli_delete_all_records_nonce');
            $table_records = $wpdb->prefix . 'xb_aijianli_records';
            $deleted_count = $wpdb->query("DELETE FROM $table_records");
            
            if ($deleted_count !== false) {
                echo '<div class="notice notice-success"><p>所有记录已删除！共删除 ' . $deleted_count . ' 条记录。</p></div>';
            } else {
                echo '<div class="notice notice-error"><p>删除记录时发生错误！</p></div>';
            }
        }
        
        if (isset($_POST['delete_record'])) {
            check_admin_referer('xb_aijianli_delete_record', 'xb_aijianli_delete_record_nonce');
            $record_id = intval($_POST['record_id']);
            $table_records = $wpdb->prefix . 'xb_aijianli_records';
            $deleted = $wpdb->delete($table_records, array('id' => $record_id), array('%d'));
            
            if ($deleted) {
                echo '<div class="notice notice-success"><p>记录已删除！</p></div>';
            } else {
                echo '<div class="notice notice-error"><p>删除记录失败！</p></div>';
            }
        }
        
        // 获取记录
        $table_records = $wpdb->prefix . 'xb_aijianli_records';
        $per_page = 20;
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $offset = ($current_page - 1) * $per_page;
        
        $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $table_records");
        $records = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_records ORDER BY created_at DESC LIMIT %d OFFSET %d", $per_page, $offset));
        
        $total_pages = ceil($total_records / $per_page);
        
        ?>
        <div class="wrap">
            <div class="xb-aijianli-admin-title">使用记录</div>
            
            <div class="tablenav top">
                <form method="post" action="" style="display: inline;">
                    <?php wp_nonce_field('xb_aijianli_delete_all_records', 'xb_aijianli_delete_all_records_nonce'); ?>
                    <input type="submit" name="delete_all_records" class="button" value="删除所有记录" onclick="return confirm('确定要删除所有记录吗？此操作不可恢复！')" />
                </form>
                <span style="margin-left: 20px;">总记录数：<?php echo $total_records; ?></span>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>用户ID</th>
                        <th>IP地址</th>
                        <th>姓名</th>
                        <th>联系方式</th>
                        <th>服务类型</th>
                        <th>AI模型</th>
                        <th>状态</th>
                        <th>错误信息</th>
                        <th>原始错误码</th>
                        <th>原始错误信息</th>
                        <th>时间</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($records): ?>
                        <?php foreach ($records as $record): ?>
                            <tr>
                                <td><?php echo esc_html($record->id); ?></td>
                                <td><?php echo esc_html($record->user_id); ?></td>
                                <td><?php echo esc_html($record->user_ip); ?></td>
                                <td><?php echo esc_html($record->user_name); ?></td>
                                <td><?php echo esc_html($record->user_contact); ?></td>
                                <td><?php echo $record->service_type === 'polish' ? 'AI润色' : 'AI面试'; ?></td>
                                <td><?php echo esc_html($record->ai_model); ?></td>
                                <td>
                                    <?php if ($record->status === 'success'): ?>
                                        <span style="color: green;">成功</span>
                                    <?php else: ?>
                                        <span style="color: red;">失败</span>
                                    <?php endif; ?>
                                </td>
                                <td title="<?php echo esc_attr($record->error_message); ?>">
                                    <?php echo esc_html(mb_substr($record->error_message, 0, 30) . (mb_strlen($record->error_message) > 30 ? '...' : '')); ?>
                                </td>
                                <td><?php echo esc_html($record->raw_error_code); ?></td>
                                <td title="<?php echo esc_attr($record->raw_error_message); ?>">
                                    <?php echo esc_html(mb_substr($record->raw_error_message, 0, 30) . (mb_strlen($record->raw_error_message) > 30 ? '...' : '')); ?>
                                </td>
                                <td><?php echo esc_html($record->created_at); ?></td>
                                <td>
                                    <form method="post" action="" style="display: inline;">
                                        <?php wp_nonce_field('xb_aijianli_delete_record', 'xb_aijianli_delete_record_nonce'); ?>
                                        <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>" />
                                        <input type="submit" name="delete_record" class="button button-small" value="删除" onclick="return confirm('确定要删除这条记录吗？')" />
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="13">暂无记录</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <?php if ($total_pages > 1): ?>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <?php
                    $page_links = paginate_links(array(
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => '&laquo;',
                        'next_text' => '&raquo;',
                        'total' => $total_pages,
                        'current' => $current_page
                    ));
                    echo $page_links;
                    ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * 注册REST API路由 - 增加流式输出支持
     */
    public function xb_aijianli_register_rest_routes() {
        register_rest_route('xb-aijianli/v1', '/polish', array(
            'methods' => 'POST',
            'callback' => array($this, 'xb_aijianli_handle_polish'),
            'permission_callback' => 'is_user_logged_in'
        ));
        
        register_rest_route('xb-aijianli/v1', '/interview', array(
            'methods' => 'POST',
            'callback' => array($this, 'xb_aijianli_handle_interview'),
            'permission_callback' => 'is_user_logged_in'
        ));
        
        register_rest_route('xb-aijianli/v1', '/stats', array(
            'methods' => 'GET',
            'callback' => array($this, 'xb_aijianli_get_user_stats'),
            'permission_callback' => 'is_user_logged_in'
        ));
    }
    
    /**
     * 处理AI润色请求 - 优化为分析和建议模式，支持流式输出
     */
    public function xb_aijianli_handle_polish($request) {
        $user_id = get_current_user_id();
        
        // 检查用户限制
        if (!$this->xb_aijianli_check_user_limit($user_id)) {
            return new WP_Error('limit_exceeded', '今日使用次数已用完', array('status' => 429));
        }
        
        $resume_data = $request->get_json_params();
        
        // 验证必要字段
        if (empty($resume_data) || !is_array($resume_data)) {
            return new WP_Error('invalid_data', '请求数据格式错误', array('status' => 400));
        }
        
        // 检查违规词
        $forbidden_check = $this->xb_aijianli_check_forbidden_words($resume_data);
        if ($forbidden_check !== true) {
            return new WP_Error('forbidden_words', $forbidden_check, array('status' => 400));
        }
        
        // 准备AI请求数据
        $ai_data = $this->xb_aijianli_prepare_polish_data($resume_data);
        
        // 调用AI接口
        $result = $this->xb_aijianli_call_ai_api($ai_data, $resume_data, 'polish');
        
        if (is_wp_error($result)) {
            // 记录失败，包含原始错误信息
            $this->xb_aijianli_log_usage($user_id, $resume_data, 'polish', 'failed', $result->get_error_message(), $result->get_error_data());
            return $result;
        }
        
        // 记录成功使用
        $this->xb_aijianli_log_usage($user_id, $resume_data, 'polish', 'success');
        $this->xb_aijianli_increment_user_usage($user_id);
        
        return rest_ensure_response($result);
    }
    
    /**
     * 处理AI面试请求 - 支持流式输出
     */
    public function xb_aijianli_handle_interview($request) {
        $user_id = get_current_user_id();
        
        // 检查用户限制
        if (!$this->xb_aijianli_check_user_limit($user_id)) {
            return new WP_Error('limit_exceeded', '今日使用次数已用完', array('status' => 429));
        }
        
        $resume_data = $request->get_json_params();
        
        // 验证必要字段
        if (empty($resume_data) || !is_array($resume_data)) {
            return new WP_Error('invalid_data', '请求数据格式错误', array('status' => 400));
        }
        
        // 检查违规词
        $forbidden_check = $this->xb_aijianli_check_forbidden_words($resume_data);
        if ($forbidden_check !== true) {
            return new WP_Error('forbidden_words', $forbidden_check, array('status' => 400));
        }
        
        // 准备AI请求数据
        $ai_data = $this->xb_aijianli_prepare_interview_data($resume_data);
        
        // 调用AI接口
        $result = $this->xb_aijianli_call_ai_api($ai_data, $resume_data, 'interview');
        
        if (is_wp_error($result)) {
            // 记录失败，包含原始错误信息
            $this->xb_aijianli_log_usage($user_id, $resume_data, 'interview', 'failed', $result->get_error_message(), $result->get_error_data());
            return $result;
        }
        
        // 记录成功使用
        $this->xb_aijianli_log_usage($user_id, $resume_data, 'interview', 'success');
        $this->xb_aijianli_increment_user_usage($user_id);
        
        return rest_ensure_response($result);
    }
    
    /**
     * 获取用户统计信息
     */
    public function xb_aijianli_get_user_stats($request) {
        $user_id = get_current_user_id();
        $stats = $this->xb_aijianli_get_user_usage_stats($user_id);
        
        return rest_ensure_response($stats);
    }
    
    /**
     * 检查违规词
     */
    private function xb_aijianli_check_forbidden_words($data) {
        $forbidden_words = get_option('xb_aijianli_forbidden_words', '');
        if (empty($forbidden_words)) {
            return true;
        }
        
        $words = array_filter(array_map('trim', explode(',', $forbidden_words)));
        $content = json_encode($data, JSON_UNESCAPED_UNICODE);
        
        foreach ($words as $word) {
            if (strpos($content, $word) !== false) {
                return '内容包含违规词，请重新输入';
            }
        }
        
        return true;
    }
    
    /**
     * 准备AI润色数据 - 优化为分析和建议模式
     */
    private function xb_aijianli_prepare_polish_data($resume_data) {
        // 移除隐私信息
        $safe_data = $resume_data;
        
        // 排除敏感信息：姓名、联系方式、联系邮箱、头像图片
        if (isset($safe_data['basic'])) {
            unset($safe_data['basic']['name']);
            unset($safe_data['basic']['contact']);
            unset($safe_data['basic']['email']);
            unset($safe_data['basic']['avatar']);
        }
        
        $content = "请作为专业的简历顾问，对以下简历进行深度分析，并提供具体的优化建议：  ";
        $content .= json_encode($safe_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        $content .= "  请从以下几个方面进行分析和建议： ";
        $content .= "1. 简历整体结构和布局 ";
        $content .= "2. 工作经验描述的专业性和亮点 ";
        $content .= "3. 技能特长的表达方式 ";
        $content .= "4. 自我评价的吸引力 ";
        $content .= "5. 针对目标岗位的匹配度 ";
        $content .= "6. 具体的改进建议和优化方案  ";
        $content .= "请提供详细、实用的建议，帮助提升简历的竞争力。";
        
        return array(
            'model' => '',
            'messages' => array(
                array(
                    'role' => 'system',
                    'content' => '你是一位资深的HR专家和简历顾问，拥有丰富的招聘经验。请提供专业、详细、实用的简历分析和优化建议。'
                ),
                array(
                    'role' => 'user',
                    'content' => $content
                )
            ),
            'stream' => false, // 使用非流式输出，前端模拟流式显示
            'temperature' => 0.7,
            'max_tokens' => 2000
        );
    }
    
    /**
     * 准备AI面试数据 - 支持流式输出
     */
    private function xb_aijianli_prepare_interview_data($resume_data) {
        // 移除隐私信息
        $safe_data = $resume_data;
        
        // 排除敏感信息：姓名、联系方式、联系邮箱、头像图片
        if (isset($safe_data['basic'])) {
            unset($safe_data['basic']['name']);
            unset($safe_data['basic']['contact']);
            unset($safe_data['basic']['email']);
            unset($safe_data['basic']['avatar']);
        }
        
        $content = "请根据以下简历信息，模拟专业面试官提出5-8个相关的面试问题，并提供详细的参考答案：  ";
        $content .= json_encode($safe_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        $content .= "  请提供： ";
        $content .= "1. 针对该岗位的核心面试问题 ";
        $content .= "2. 每个问题的详细参考答案 ";
        $content .= "3. 回答技巧和注意事项 ";
        $content .= "4. 可能的追问问题  ";
        $content .= "请确保问题具有针对性和实用性。";
        
        return array(
            'model' => '',
            'messages' => array(
                array(
                    'role' => 'system',
                    'content' => '你是一位经验丰富的面试官，擅长根据候选人背景设计有针对性的面试问题。请提供专业、实用的面试问题和答案指导。'
                ),
                array(
                    'role' => 'user',
                    'content' => $content
                )
            ),
            'stream' => false, // 使用非流式输出，前端模拟流式显示
            'temperature' => 0.7,
            'max_tokens' => 2000
        );
    }
    
    /**
     * 调用AI接口 - 增强错误处理和记录，支持流式输出
     */
    private function xb_aijianli_call_ai_api($ai_data, $resume_data, $service_type) {
        $api_url = get_option('xb_aijianli_api_url', '');
        $api_key = get_option('xb_aijianli_api_key', '');
        $ai_models = get_option('xb_aijianli_ai_models', 'qwen-plus');
        $model_list = array_map('trim', explode(',', $ai_models));
        
        // 验证API配置
        if (empty($api_url) || empty($api_key)) {
            return new WP_Error('api_config_error', 'API配置错误：缺少API地址或密钥', array(
                'status' => 500,
                'raw_error' => 'API URL或API Key未配置',
                'raw_error_code' => 'CONFIG_ERROR',
                'response_code' => 0
            ));
        }
        
        // 设置模型
        $selected_model = isset($resume_data['ai_model']) && !empty($resume_data['ai_model']) ? $resume_data['ai_model'] : $model_list[0];
        $ai_data['model'] = $selected_model;
        
        // 准备请求头
        $headers = array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json',
            'User-Agent' => 'WordPress-AI-Resume-Plugin/1.0'
        );
        
        // 准备请求参数
        $request_args = array(
            'headers' => $headers,
            'body' => json_encode($ai_data, JSON_UNESCAPED_UNICODE),
            'timeout' => 60,
            'method' => 'POST',
            'sslverify' => true
        );
        
        // 调试功能：记录AI返回的原始数据到debug.log
        // 注意：生产环境时请注释掉以下调试代码
        /*
        $debug_data = array(
            'timestamp' => current_time('Y-m-d H:i:s'),
            'service_type' => $service_type,
            'model' => $selected_model,
            'request_data' => $ai_data,
            'user_id' => get_current_user_id()
        );
        error_log('[AI简历插件调试] 请求数据: ' . json_encode($debug_data, JSON_UNESCAPED_UNICODE), 3, WP_CONTENT_DIR . '/debug.log');
        */
        
        // 发送请求
        $response = wp_remote_post($api_url, $request_args);
        
        // 检查请求错误
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            
            // 调试功能：记录错误到debug.log
            // 注意：生产环境时请注释掉以下调试代码
            /*
            error_log('[AI简历插件调试] 请求错误: ' . $error_message, 3, WP_CONTENT_DIR . '/debug.log');
            */
            
            return new WP_Error('api_request_error', '网络请求失败', array(
                'status' => 500,
                'raw_error' => $error_message,
                'raw_error_code' => 'NETWORK_ERROR',
                'response_code' => 0
            ));
        }
        
        // 获取响应信息
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $response_headers = wp_remote_retrieve_headers($response);
        
        // 调试功能：记录AI返回的原始数据到debug.log
        // 注意：生产环境时请注释掉以下调试代码
        /*
        $debug_response = array(
            'timestamp' => current_time('Y-m-d H:i:s'),
            'service_type' => $service_type,
            'response_code' => $response_code,
            'response_body' => substr($response_body, 0, 1000), // 只记录前1000字符
            'user_id' => get_current_user_id()
        );
        error_log('[AI简历插件调试] 响应数据: ' . json_encode($debug_response, JSON_UNESCAPED_UNICODE), 3, WP_CONTENT_DIR . '/debug.log');
        */
        
        // 检查HTTP状态码
        if ($response_code !== 200) {
            $error_data = array(
                'status' => $response_code,
                'raw_error' => $response_body,
                'raw_error_code' => 'HTTP_' . $response_code,
                'response_code' => $response_code
            );
            
            // 尝试解析错误响应
            $error_json = json_decode($response_body, true);
            if ($error_json && isset($error_json['error'])) {
                $error_message = isset($error_json['error']['message']) ? $error_json['error']['message'] : 'API返回错误';
                $error_data['parsed_error'] = $error_json;
                $error_data['raw_error_code'] = isset($error_json['error']['code']) ? $error_json['error']['code'] : 'HTTP_' . $response_code;
            } else {
                $error_message = 'API请求失败，状态码：' . $response_code;
            }
            
            return new WP_Error('api_response_error', $error_message, $error_data);
        }
        
        // 解析响应内容
        $response_data = json_decode($response_body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error('api_parse_error', 'API响应格式错误', array(
                'status' => 500,
                'raw_error' => 'JSON解析失败：' . json_last_error_msg(),
                'raw_error_code' => 'JSON_PARSE_ERROR',
                'response_code' => $response_code,
                'response_body' => substr($response_body, 0, 500)
            ));
        }
        
        // 验证响应结构
        if (!isset($response_data['choices']) || !is_array($response_data['choices']) || empty($response_data['choices'])) {
            return new WP_Error('api_structure_error', 'API响应结构错误', array(
                'status' => 500,
                'raw_error' => '响应中缺少choices字段或为空',
                'raw_error_code' => 'STRUCTURE_ERROR',
                'response_code' => $response_code,
                'response_data' => $response_data
            ));
        }
        
        // 提取内容
        $choice = $response_data['choices'][0];
        if (!isset($choice['message']['content'])) {
            return new WP_Error('api_content_error', 'API响应内容错误', array(
                'status' => 500,
                'raw_error' => '响应中缺少message.content字段',
                'raw_error_code' => 'CONTENT_ERROR',
                'response_code' => $response_code,
                'choice_data' => $choice
            ));
        }
        
        $content = $choice['message']['content'];
        
        // 验证内容不为空
        if (empty(trim($content))) {
            return new WP_Error('api_empty_content', 'AI返回内容为空', array(
                'status' => 500,
                'raw_error' => 'AI生成的内容为空',
                'raw_error_code' => 'EMPTY_CONTENT',
                'response_code' => $response_code
            ));
        }
        
        return array(
            'content' => $content,
            'model' => $selected_model,
            'usage' => isset($response_data['usage']) ? $response_data['usage'] : null
        );
    }
    
    /**
     * 记录使用情况 - 增加原始错误码记录
     */
    private function xb_aijianli_log_usage($user_id, $resume_data, $service_type, $status, $error_message = '', $error_data = null) {
        global $wpdb;
        
        $table_records = $wpdb->prefix . 'xb_aijianli_records';
        
        // 提取用户信息
        $user_name = '';
        $user_contact = '';
        $ai_model = '';
        
        if (isset($resume_data['basic'])) {
            $user_name = isset($resume_data['basic']['name']) ? sanitize_text_field($resume_data['basic']['name']) : '';
            $user_contact = isset($resume_data['basic']['contact']) ? sanitize_text_field($resume_data['basic']['contact']) : '';
        }
        
        if (isset($resume_data['ai_model'])) {
            $ai_model = sanitize_text_field($resume_data['ai_model']);
        }
        
        // 处理错误数据
        $raw_error_message = '';
        $raw_error_code = '';
        $api_response_code = null;
        
        if ($error_data && is_array($error_data)) {
            $raw_error_message = isset($error_data['raw_error']) ? $error_data['raw_error'] : '';
            $raw_error_code = isset($error_data['raw_error_code']) ? $error_data['raw_error_code'] : '';
            $api_response_code = isset($error_data['response_code']) ? intval($error_data['response_code']) : null;
            
            // 如果有更详细的错误信息，记录下来
            if (isset($error_data['parsed_error'])) {
                $raw_error_message = json_encode($error_data['parsed_error'], JSON_UNESCAPED_UNICODE);
            } elseif (isset($error_data['response_body'])) {
                $raw_error_message = $error_data['response_body'];
            }
        }
        
        // 插入记录
        $insert_result = $wpdb->insert(
            $table_records,
            array(
                'user_id' => $user_id,
                'user_ip' => $this->xb_aijianli_get_client_ip(),
                'user_name' => $user_name,
                'user_contact' => $user_contact,
                'service_type' => $service_type,
                'ai_model' => $ai_model,
                'status' => $status,
                'error_message' => $error_message,
                'raw_error_code' => $raw_error_code,
                'raw_error_message' => $raw_error_message,
                'api_response_code' => $api_response_code
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d')
        );
        
        // 记录插入失败的情况
        if ($insert_result === false) {
            error_log('AI简历插件：记录插入失败 - ' . $wpdb->last_error);
        }
    }
    
    /**
     * 获取客户端真实IP地址
     */
    private function xb_aijianli_get_client_ip() {
        $ip_keys = array('HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                $ip = $_SERVER[$key];
                if (strpos($ip, ',') !== false) {
                    $ip = explode(',', $ip)[0];
                }
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    }
    
    /**
     * 检查用户使用限制
     */
    private function xb_aijianli_check_user_limit($user_id) {
        global $wpdb;
        
        $table_limits = $wpdb->prefix . 'xb_aijianli_user_limits';
        $today = current_time('Y-m-d');
        
        $user_limit = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_limits WHERE user_id = %d", $user_id));
        
        if (!$user_limit) {
            // 创建用户限制记录
            $daily_limit = get_option('xb_aijianli_daily_limit', 10);
            $wpdb->insert(
                $table_limits,
                array(
                    'user_id' => $user_id,
                    'daily_limit' => $daily_limit,
                    'used_count' => 0,
                    'last_reset_date' => $today
                ),
                array('%d', '%d', '%d', '%s')
            );
            return true;
        }
        
        // 检查是否需要重置计数
        if ($user_limit->last_reset_date !== $today) {
            $wpdb->update(
                $table_limits,
                array('used_count' => 0, 'last_reset_date' => $today),
                array('user_id' => $user_id),
                array('%d', '%s'),
                array('%d')
            );
            $user_limit->used_count = 0;
        }
        
        return $user_limit->used_count < $user_limit->daily_limit;
    }
    
    /**
     * 增加用户使用次数
     */
    private function xb_aijianli_increment_user_usage($user_id) {
        global $wpdb;
        
        $table_limits = $wpdb->prefix . 'xb_aijianli_user_limits';
        $wpdb->query($wpdb->prepare("UPDATE $table_limits SET used_count = used_count + 1 WHERE user_id = %d", $user_id));
    }
    
    /**
     * 获取用户使用统计
     */
    private function xb_aijianli_get_user_usage_stats($user_id) {
        global $wpdb;
        
        $table_limits = $wpdb->prefix . 'xb_aijianli_user_limits';
        $today = current_time('Y-m-d');
        
        $user_limit = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_limits WHERE user_id = %d", $user_id));
        
        if (!$user_limit) {
            $daily_limit = get_option('xb_aijianli_daily_limit', 10);
            return array(
                'daily_limit' => $daily_limit,
                'used_count' => 0,
                'remaining' => $daily_limit
            );
        }
        
        // 检查是否需要重置计数
        if ($user_limit->last_reset_date !== $today) {
            $wpdb->update(
                $table_limits,
                array('used_count' => 0, 'last_reset_date' => $today),
                array('user_id' => $user_id),
                array('%d', '%s'),
                array('%d')
            );
            $user_limit->used_count = 0;
        }
        
        return array(
            'daily_limit' => $user_limit->daily_limit,
            'used_count' => $user_limit->used_count,
            'remaining' => max(0, $user_limit->daily_limit - $user_limit->used_count)
        );
    }
    
    /**
     * 设置用户限制
     */
    private function xb_aijianli_set_user_limit($user_id, $limit) {
        global $wpdb;
        
        $table_limits = $wpdb->prefix . 'xb_aijianli_user_limits';
        $today = current_time('Y-m-d');
        
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_limits WHERE user_id = %d", $user_id));
        
        if ($existing) {
            $wpdb->update(
                $table_limits,
                array('daily_limit' => $limit),
                array('user_id' => $user_id),
                array('%d'),
                array('%d')
            );
        } else {
            $wpdb->insert(
                $table_limits,
                array(
                    'user_id' => $user_id,
                    'daily_limit' => $limit,
                    'used_count' => 0,
                    'last_reset_date' => $today
                ),
                array('%d', '%d', '%d', '%s')
            );
        }
    }
    
    /**
     * 重置用户使用次数
     */
    private function xb_aijianli_reset_user_usage($user_id) {
        global $wpdb;
        
        $table_limits = $wpdb->prefix . 'xb_aijianli_user_limits';
        $today = current_time('Y-m-d');
        
        $wpdb->update(
            $table_limits,
            array('used_count' => 0, 'last_reset_date' => $today),
            array('user_id' => $user_id),
            array('%d', '%s'),
            array('%d')
        );
    }
}

// 初始化插件
new XB_AIJianli();
?>
