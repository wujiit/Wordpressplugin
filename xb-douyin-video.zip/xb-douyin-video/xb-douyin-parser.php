<?php
/*
Plugin Name: 启灵抖音解析
Plugin URI: https://www.wujiit.com
Description: 一个用于解析抖音短视频链接的WordPress插件，支持去水印视频下载及查询次数限制。
Version: 1.0.3
Author: summer
Author URI: https://www.wujiit.com
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xb_douyin_activate');
function xb_douyin_activate() {
    xb_douyin_create_database();
    xb_douyin_create_front_page();
}

// 创建/更新数据库表
function xb_douyin_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 用户/游客查询次数表，新增 device_id 字段
    $usage_table = $wpdb->prefix . 'xb_douyin_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL DEFAULT 0,
        device_id varchar(255) NOT NULL DEFAULT '',
        query_date date NOT NULL,
        query_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_device_date (user_id, device_id, query_date)
    ) $charset_collate;";

    // 查询记录表，新增 device_id 字段
    $queries_table = $wpdb->prefix . 'xb_douyin_queries';
    $queries_sql = "CREATE TABLE $queries_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL DEFAULT 0,
        device_id varchar(255) NOT NULL DEFAULT '',
        video_url varchar(255) NOT NULL,
        query_status varchar(255) NOT NULL,
        query_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($usage_sql);
    dbDelta($queries_sql);

    error_log('XB Douyin Parser: Database tables created or updated.');
}

// 检查并创建前台页面
function xb_douyin_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_douyin_query_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => '抖音短视频解析',
            'post_content' => '[xb_douyin_query_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_douyin_enqueue_scripts');
function xb_douyin_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_douyin_query_form')) {
        wp_enqueue_style('xb_douyin_styles', plugins_url('xb-douyin-styles.css', __FILE__), array(), '1.3.8');
        wp_enqueue_script('xb_douyin_scripts', plugins_url('xb-douyin-scripts.js', __FILE__), array('jquery'), '1.3.8', true);

        wp_localize_script('xb_douyin_scripts', 'xb_douyin_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('xb_douyin_query_nonce'),
            'login_url' => wp_login_url(get_permalink())
        ));
    }
}

// 新增：生成设备指纹，优先使用 Cookie，失效时回退到基于 user_agent 等生成
function xb_douyin_get_device_id() {
    // 检查 Cookie 是否存在
    $device_id = isset($_COOKIE['xb_douyin_device_id']) ? sanitize_text_field($_COOKIE['xb_douyin_device_id']) : '';

    if (empty($device_id)) {
        // 如果 Cookie 不存在，基于 user_agent、ip_address、accept_language 生成设备指纹
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $accept_language = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
        $headers = array(
            'user_agent' => $user_agent,
            'ip_address' => $ip_address,
            'accept_language' => $accept_language,
        );
        $device_id = md5(json_encode($headers) . wp_salt('nonce')); // 使用 wp_salt 增加安全性
        // 设置 Cookie，365 天有效期，HttpOnly 和 Secure（若 HTTPS）
        setcookie('xb_douyin_device_id', $device_id, time() + 365 * DAY_IN_SECONDS, '/', '', is_ssl(), true);
        error_log('XB Douyin Parser: Generated and set new device_id in Cookie: ' . $device_id);
    } else {
        error_log('XB Douyin Parser: Retrieved device_id from Cookie: ' . $device_id);
    }

    return $device_id;
}

// 修改：优化短代码，使用次数统计支持已登录用户跨设备、游客按设备独立
add_shortcode('xb_douyin_query_form', 'xb_douyin_query_form_shortcode');
function xb_douyin_query_form_shortcode() {
    $ad_content = get_option('xb_douyin_ad_content', '');
    $default_limit = absint(get_option('xb_douyin_default_limit', 5));
    $guest_limit = absint(get_option('xb_douyin_guest_limit', 10));
    $hide_stats = get_option('xb_douyin_hide_stats', '0') === '1';
    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $today = current_time('Y-m-d');

    // 获取设备指纹，仅用于游客
    $device_id = xb_douyin_get_device_id();

    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_douyin_usage';

    // 已登录用户：按 user_id 汇总所有设备的使用次数
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(query_count) as total_count, MAX(custom_limit) as custom_limit 
                 FROM $table_name 
                 WHERE user_id = %d AND query_date = %s",
                $user_id, $today
            )
        );
        $query_count = $row ? absint($row->total_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;
    } else {
        // 游客：按 device_id 统计
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT query_count, custom_limit 
                 FROM $table_name 
                 WHERE user_id = 0 AND device_id = %s AND query_date = %s",
                $device_id, $today
            )
        );
        $query_count = $row ? absint($row->query_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $guest_limit;
    }

    $remaining = max(0, $user_limit - $query_count);
    $show_captcha = $user_id === 0 && $query_count >= $guest_limit;

    error_log("XB Douyin Parser: User ID $user_id, Device ID: $device_id, Limit: $user_limit, Count: $query_count, Remaining: $remaining");

    ob_start();
    ?>
    <div class="xb_douyin_container">
        <div class="xb_douyin_title">抖音短视频解析</div>

        <div class="xb_douyin_query_section">
            <?php if ($query_count >= $user_limit && !$show_captcha): ?>
                <div class="xb_douyin_message"><?php echo $user_id ? '今日解析次数已用完，请明天再试！' : '游客的使用次数已经用完，请登录之后继续。'; ?></div>
                <?php if (!$user_id): ?>
                    <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xb_douyin_login_button wp-ai-login-btn" style="display:block;width:fit-content;margin:10px auto;padding:10px 20px;background:#fe2c55;color:#fff;text-decoration:none;border-radius:4px;">快速登录</a>
                <?php endif; ?>
            <?php else: ?>
                <form id="xb_douyin_query_form" method="post">
                    <input type="text" name="xb_douyin_url" id="xb_douyin_url" placeholder="请输入抖音视频完整链接或者分享内容短链接" required>
                    <?php if ($show_captcha): ?>
                        <div class="xb_douyin_captcha_section">
                            <span id="xb_douyin_captcha_question"></span>
                            <input type="number" name="xb_douyin_captcha_answer" id="xb_douyin_captcha_answer" placeholder="请输入验证码答案" required>
                            <input type="hidden" name="xb_douyin_captcha_value" id="xb_douyin_captcha_value">
                        </div>
                    <?php endif; ?>
                    <button type="submit" class="xb_douyin_submit_button">解析</button>
                    <input type="hidden" name="xb_douyin_nonce" id="xb_douyin_nonce" value="<?php echo wp_create_nonce('xb_douyin_query_nonce'); ?>">
                    <input type="hidden" name="xb_douyin_device_id" id="xb_douyin_device_id" value="">
                </form>
                <div class="xb_douyin_result_section">
                    <div id="xb_douyin_result"></div>
                    <?php if (!$hide_stats): ?>
                        <div class="xb_douyin_usage_info">今日剩余解析次数：<?php echo esc_html($remaining); ?>/<?php echo esc_html($user_limit); ?></div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="xb_douyin_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
    </div>
    <?php
    return ob_get_clean();
}

// 新增：获取当前使用情况的 AJAX 接口
add_action('wp_ajax_xb_douyin_get_usage', 'xb_douyin_get_usage');
add_action('wp_ajax_nopriv_xb_douyin_get_usage', 'xb_douyin_get_usage');
function xb_douyin_get_usage() {
    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $device_id = xb_douyin_get_device_id();
    if (empty($device_id)) {
        wp_send_json_error(array('message' => '无法获取设备指纹，请刷新页面重试！'));
        return;
    }
    $today = current_time('Y-m-d');

    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_douyin_usage';

    // 已登录用户：按 user_id 汇总所有设备的使用次数
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(query_count) as total_count, MAX(custom_limit) as custom_limit 
                 FROM $table_name 
                 WHERE user_id = %d AND query_date = %s",
                $user_id, $today
            )
        );
        $query_count = $row ? absint($row->total_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : absint(get_option('xb_douyin_default_limit', 5));
    } else {
        // 游客：按 device_id 统计
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT query_count, custom_limit 
                 FROM $table_name 
                 WHERE user_id = 0 AND device_id = %s AND query_date = %s",
                $device_id, $today
            )
        );
        $query_count = $row ? absint($row->query_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : absint(get_option('xb_douyin_guest_limit', 10));
    }

    $remaining = max(0, $user_limit - $query_count);

    wp_send_json_success(array(
        'remaining' => $remaining,
        'limit' => $user_limit,
        'is_guest' => !$user_id,
        'hide_stats' => get_option('xb_douyin_hide_stats', '0') === '1'
    ));
}

// 修改：优化 AJAX 解析请求，完善使用次数统计逻辑
add_action('wp_ajax_xb_douyin_query', 'xb_douyin_handle_query');
add_action('wp_ajax_nopriv_xb_douyin_query', 'xb_douyin_handle_query');
function xb_douyin_handle_query() {
    // 验证 nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'xb_douyin_query_nonce')) {
        wp_send_json_error(array('message' => '安全验证失败，请刷新页面重试！', 'is_guest' => !is_user_logged_in(), 'hide_stats' => get_option('xb_douyin_hide_stats', '0') === '1'));
        return;
    }

    $url = sanitize_text_field($_POST['url']);
    if (empty($url)) {
        wp_send_json_error(array('message' => '请输入有效的抖音视频链接！', 'is_guest' => !is_user_logged_in(), 'hide_stats' => get_option('xb_douyin_hide_stats', '0') === '1'));
        return;
    }

    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $device_id = xb_douyin_get_device_id();
    if (empty($device_id)) {
        wp_send_json_error(array('message' => '无法获取设备指纹，请刷新页面重试！', 'is_guest' => !is_user_logged_in(), 'hide_stats' => get_option('xb_douyin_hide_stats', '0') === '1'));
        return;
    }
    $today = current_time('Y-m-d');
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_douyin_usage';
    $queries_table = $wpdb->prefix . 'xb_douyin_queries';

    // 检查查询限制
    $default_limit = absint(get_option('xb_douyin_default_limit', 5));
    $guest_limit = absint(get_option('xb_douyin_guest_limit', 10));

    // 已登录用户：按 user_id 汇总所有设备的使用次数
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(query_count) as total_count, MAX(custom_limit) as custom_limit 
                 FROM $usage_table 
                 WHERE user_id = %d AND query_date = %s",
                $user_id, $today
            )
        );
        $query_count = $row ? absint($row->total_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;
    } else {
        // 游客：按 device_id 统计
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT query_count, custom_limit 
                 FROM $usage_table 
                 WHERE user_id = 0 AND device_id = %s AND query_date = %s",
                $device_id, $today
            )
        );
        $query_count = $row ? absint($row->query_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $guest_limit;
    }

    // 游客验证码验证
    if ($user_id === 0 && $query_count >= $guest_limit) {
        if (!isset($_POST['captcha_answer']) || !isset($_POST['captcha_value']) || absint($_POST['captcha_answer']) !== absint($_POST['captcha_value'])) {
            wp_send_json_error(array(
                'message' => '验证码错误，请重新输入！',
                'is_guest' => true,
                'hide_stats' => get_option('xb_douyin_hide_stats', '0') === '1',
                'remaining' => 0,
                'limit' => $user_limit
            ));
            return;
        }
    }

    if ($query_count >= $user_limit && $user_id !== 0) {
        wp_send_json_error(array(
            'message' => '今日解析次数已用完，请明天再试！',
            'is_guest' => false,
            'hide_stats' => get_option('xb_douyin_hide_stats', '0') === '1',
            'remaining' => 0,
            'limit' => $user_limit
        ));
        return;
    }

    // 提取短链接或直接使用完整链接
    $parsed_url = $url;
    if (preg_match('/https:\/\/v\.douyin\.com\/[a-zA-Z0-9]+/', $url, $matches)) {
        $parsed_url = $matches[0];
    } elseif (!preg_match('/https:\/\/www\.douyin\.com\/video\/[0-9]+/', $url)) {
        wp_send_json_error(array(
            'message' => '请输入有效的抖音视频链接！',
            'is_guest' => !$user_id,
            'hide_stats' => get_option('xb_douyin_hide_stats', '0') === '1',
            'remaining' => $user_limit - $query_count,
            'limit' => $user_limit
        ));
        return;
    }

    // 调用 API
    $api_url = get_option('xb_douyin_api_url', 'https://www.mxnzp.com/api/douyin/video');
    $api_key = get_option('xb_douyin_api_key');
    $app_id = get_option('xb_douyin_app_id');
    $encoded_url = base64_encode($parsed_url);
    $user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36';

    $args = array(
        'body' => array(
            'url' => $encoded_url,
            'app_id' => $app_id,
            'app_secret' => $api_key
        ),
        'headers' => array(
            'User-Agent' => $user_agent,
            'Referer' => 'https://www.douyin.com/',
            'Origin' => 'https://www.douyin.com'
        ),
        'timeout' => 15,
        'sslverify' => false
    );

    $response = wp_remote_get($api_url, $args);
    $query_status = 'failed';

    // 准备插入记录，包含 device_id
    $insert_data = array(
        'user_id' => $user_id,
        'device_id' => $device_id,
        'video_url' => $url,
        'query_status' => $query_status,
        'query_time' => current_time('mysql')
    );

    if (is_wp_error($response)) {
        $query_status = $response->get_error_message();
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s'));
        error_log('XB Douyin Parser: Inserted error record. ID: ' . $wpdb->insert_id . ', Error: ' . $query_status);
        wp_send_json_error(array(
            'message' => '暂时无法解析，请联系客服',
            'is_guest' => !$user_id,
            'hide_stats' => get_option('xb_douyin_hide_stats', '0') === '1',
            'remaining' => $user_limit - $query_count,
            'limit' => $user_limit
        ));
        return;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    // 调试：记录原始 API 响应数据
    error_log('XB Douyin Parser: Raw API Response: ' . print_r($data, true));

    if (isset($data['code']) && $data['code'] == 1) {
        $query_status = 'success';
        $insert_data['query_status'] = $query_status;

        // 更新查询次数
        if ($user_id) {
            // 已登录用户：查找当前 device_id 的记录，如果不存在则插入
            $existing_row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT id, query_count 
                     FROM $usage_table 
                     WHERE user_id = %d AND device_id = %s AND query_date = %s",
                    $user_id, $device_id, $today
                )
            );
            if ($existing_row) {
                $wpdb->update(
                    $usage_table,
                    array('query_count' => $existing_row->query_count + 1),
                    array('id' => $existing_row->id),
                    array('%d'),
                    array('%d')
                );
            } else {
                $wpdb->insert(
                    $usage_table,
                    array(
                        'user_id' => $user_id,
                        'device_id' => $device_id,
                        'query_date' => $today,
                        'query_count' => 1,
                        'custom_limit' => null
                    ),
                    array('%d', '%s', '%s', '%d', '%d')
                );
            }
        } else {
            // 游客：按 device_id 更新
            if ($row) {
                $new_count = $query_count + 1;
                $wpdb->update(
                    $usage_table,
                    array('query_count' => $new_count),
                    array('user_id' => 0, 'device_id' => $device_id, 'query_date' => $today),
                    array('%d'),
                    array('%d', '%s', '%s')
                );
            } else {
                $wpdb->insert(
                    $usage_table,
                    array(
                        'user_id' => 0,
                        'device_id' => $device_id,
                        'query_date' => $today,
                        'query_count' => 1,
                        'custom_limit' => null
                    ),
                    array('%d', '%s', '%s', '%d', '%d')
                );
            }
        }

        // 插入查询记录
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s'));
        error_log('XB Douyin Parser: Inserted success record. ID: ' . $wpdb->insert_id . ', URL: ' . $url);

        // 直接使用原始视频和封面链接，添加 noreferrer
        $video_url = esc_url($data['data']['url']);
        $cover_url = esc_url($data['data']['cover']);

        // 格式化结果
        $result = $data['data'];
        $output = '<div class="xb_douyin_highlight_result">';
        $output .= '<div class="xb_douyin_title_result">视频标题：<span>' . esc_html($result['title']) . '</span></div>';
        $output .= '<div class="xb_douyin_dimensions">视频尺寸：' . esc_html($result['width']) . 'x' . esc_html($result['height']) . '</div>';
        $output .= '<div class="xb_douyin_cover_container">';
        $output .= '<div class="xb_douyin_subtitle">视频封面</div>';
        $output .= '<img src="' . $cover_url . '" class="xb_douyin_cover" alt="视频封面" onerror="this.onerror=null;this.src=\'' . esc_url(plugins_url('fallback-cover.jpg', __FILE__)) . '\';">';
        $output .= '</div>';
        $output .= '<div class="xb_douyin_video_container">';
        $output .= '<div class="xb_douyin_subtitle">视频预览</div>';
        $output .= '<button class="xb_douyin_preview_button" data-video-url="' . $video_url . '">播放预览</button>';
        $output .= '</div>';
        $output .= '<div class="xb_douyin_download"><a href="' . $video_url . '" class="xb_douyin_download_button" target="_blank" download="douyin_video.mp4" rel="noreferrer">下载视频</a></div>';
        $output .= '</div>';

        wp_send_json_success(array(
            'result' => $output,
            'remaining' => $user_limit - ($query_count + 1),
            'limit' => $user_limit,
            'is_guest' => !$user_id,
            'hide_stats' => get_option('xb_douyin_hide_stats', '0') === '1',
            'captcha' => $user_id === 0 && ($query_count + 1) >= $guest_limit
        ));
    } else {
        $query_status = isset($data['msg']) ? $data['msg'] : '未知错误';
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s'));
        error_log('XB Douyin Parser: Inserted failed record. ID: ' . $wpdb->insert_id . ', Status: ' . $query_status);
        wp_send_json_error(array(
            'message' => '暂时无法解析，请联系客服',
            'is_guest' => !$user_id,
            'hide_stats' => get_option('xb_douyin_hide_stats', '0') === '1',
            'remaining' => $user_limit - $query_count,
            'limit' => $user_limit
        ));
    }
}

// 添加管理菜单
add_action('admin_menu', 'xb_douyin_admin_menu');
function xb_douyin_admin_menu() {
    add_menu_page(
        '抖音短视频解析设置',
        '抖音短视频解析',
        'manage_options',
        'xb_douyin_settings',
        'xb_douyin_settings_page',
        'dashicons-video-alt3',
        80
    );
    add_submenu_page(
        'xb_douyin_settings',
        '解析记录',
        '解析记录',
        'manage_options',
        'xb_douyin_all_records',
        'xb_douyin_all_records_page'
    );
}

// 插件设置页面
function xb_douyin_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['xb_douyin_save_settings'])) {
        check_admin_referer('xb_douyin_settings_nonce');
        
        update_option('xb_douyin_api_url', sanitize_text_field($_POST['xb_douyin_api_url']));
        update_option('xb_douyin_app_id', sanitize_text_field($_POST['xb_douyin_app_id']));
        update_option('xb_douyin_api_key', sanitize_text_field($_POST['xb_douyin_api_key']));
        $new_limit = absint($_POST['xb_douyin_default_limit']);
        if ($new_limit > 0) {
            update_option('xb_douyin_default_limit', $new_limit);
        }
        $new_guest_limit = absint($_POST['xb_douyin_guest_limit']);
        if ($new_guest_limit >= 0) {
            update_option('xb_douyin_guest_limit', $new_guest_limit);
        }
        update_option('xb_douyin_ad_content', wp_kses_post($_POST['xb_douyin_ad_content']));
        update_option('xb_douyin_hide_stats', isset($_POST['xb_douyin_hide_stats']) ? '1' : '0');
        
        echo '<div id="xb_douyin_settings_notice" class="updated"><p>设置已保存！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_douyin_settings_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    ?>
    <div class="wrap">
        <div class="xb_douyin_admin_title">抖音短视频解析设置</div>
        <form method="post">
            <?php wp_nonce_field('xb_douyin_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_douyin_api_url">API 接口地址</label></th>
                    <td><input type="text" name="xb_douyin_api_url" id="xb_douyin_api_url" value="<?php echo esc_attr(get_option('xb_douyin_api_url', 'https://www.mxnzp.com/api/douyin/video')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_douyin_app_id">API App ID</label></th>
                    <td><input type="text" name="xb_douyin_app_id" id="xb_douyin_app_id" value="<?php echo esc_attr(get_option('xb_douyin_app_id')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_douyin_api_key">API 密钥</label></th>
                    <td><input type="text" name="xb_douyin_api_key" id="xb_douyin_api_key" value="<?php echo esc_attr(get_option('xb_douyin_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_douyin_default_limit">默认每日解析次数（登录用户）</label></th>
                    <td><input type="number" name="xb_douyin_default_limit" id="xb_douyin_default_limit" value="<?php echo esc_attr(get_option('xb_douyin_default_limit', 5)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_douyin_guest_limit">默认每日解析次数（游客）</label></th>
                    <td><input type="number" name="xb_douyin_guest_limit" id="xb_douyin_guest_limit" value="<?php echo esc_attr(get_option('xb_douyin_guest_limit', 10)); ?>" min="0"></td>
                </tr>
                <tr>
                    <th><label for="xb_douyin_ad_content">公告内容</label></th>
                    <td><textarea name="xb_douyin_ad_content" id="xb_douyin_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_douyin_ad_content')); ?></textarea></td>
                </tr>
                <tr>
                    <th><label for="xb_douyin_hide_stats">隐藏前台统计</label></th>
                    <td><input type="checkbox" name="xb_douyin_hide_stats" id="xb_douyin_hide_stats" value="1" <?php checked(get_option('xb_douyin_hide_stats', '0'), '1'); ?>> 隐藏今日剩余解析次数</td>
                </tr>
            </table>
            <p><input type="submit" name="xb_douyin_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        
        <div style="margin-top: 30px; padding: 15px; background: #fff; border-left: 4px solid #000; box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);">
            <p style="margin: 0; font-size: 14px; color: #666;">
                这是免费开源的插件，基于第三方接口，请考虑使用。 联系方式QQ群：16966111
            </p>
        </div>
    </div>
    <?php
}

// 修改：优化解析记录页面，支持 device_id 显示和管理
function xb_douyin_all_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_douyin_usage';
    $queries_table = $wpdb->prefix . 'xb_douyin_queries';
    $user_id = isset($_POST['xb_douyin_user_id']) ? (int)$_POST['xb_douyin_user_id'] : null;
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    // 删除单条记录
    if (isset($_POST['xb_douyin_delete_record']) && isset($_POST['record_id'])) {
        check_admin_referer('xb_douyin_delete_record_nonce');
        $record_id = absint($_POST['record_id']);
        
        $usage_before = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT user_id, device_id, query_date, query_count, custom_limit FROM $usage_table WHERE user_id = %d OR user_id = 0",
                $user_id !== null ? $user_id : 0
            )
        );
        error_log('XB Douyin Parser: Usage table before single record deletion (record_id: ' . $record_id . '): ' . print_r($usage_before, true));

        $wpdb->delete($queries_table, array('id' => $record_id), array('%d'));
        error_log('XB Douyin Parser: Deleted single record ID: ' . $record_id);

        $usage_after = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT user_id, device_id, query_date, query_count, custom_limit FROM $usage_table WHERE user_id = %d OR user_id = 0",
                $user_id !== null ? $user_id : 0
            )
        );
        error_log('XB Douyin Parser: Usage table after single record deletion (record_id: ' . $record_id . '): ' . print_r($usage_after, true));

        echo '<div id="xb_douyin_delete_notice" class="updated"><p>记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_douyin_delete_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 删除用户/游客全部记录
    if (isset($_POST['xb_douyin_delete_all_records']) && $user_id !== null) {
        check_admin_referer('xb_douyin_delete_all_records_nonce');
        
        $usage_before = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT user_id, device_id, query_date, query_count, custom_limit FROM $usage_table WHERE user_id = %d",
                $user_id
            )
        );
        error_log('XB Douyin Parser: Usage table before all records deletion for user_id: ' . $user_id . ': ' . print_r($usage_before, true));

        $wpdb->delete($queries_table, array('user_id' => $user_id), array('%d'));
        $wpdb->delete($usage_table, array('user_id' => $user_id), array('%d'));
        error_log('XB Douyin Parser: Deleted all records for user_id: ' . $user_id);

        $usage_after = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT user_id, device_id, query_date, query_count, custom_limit FROM $usage_table WHERE user_id = %d",
                $user_id
            )
        );
        error_log('XB Douyin Parser: Usage table after all records deletion for user_id: ' . $user_id . ': ' . print_r($usage_after, true));

        echo '<div id="xb_douyin_delete_all_notice" class="updated"><p>所有记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_douyin_delete_all_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 删除所有记录（包括所有用户和游客）
    if (isset($_POST['xb_douyin_delete_all_global_records'])) {
        check_admin_referer('xb_douyin_delete_all_global_records_nonce');
        
        $usage_before = $wpdb->get_results("SELECT user_id, device_id, query_date, query_count, custom_limit FROM $usage_table");
        error_log('XB Douyin Parser: Usage table before all global records deletion: ' . print_r($usage_before, true));

        $wpdb->query("TRUNCATE TABLE $queries_table");
        $wpdb->query("TRUNCATE TABLE $usage_table");
        error_log('XB Douyin Parser: Truncated queries and usage tables.');

        $usage_after = $wpdb->get_results("SELECT user_id, device_id, query_date, query_count, custom_limit FROM $usage_table");
        error_log('XB Douyin Parser: Usage table after all global records deletion: ' . print_r($usage_after, true));

        echo '<div id="xb_douyin_delete_all_global_notice" class="updated"><p>所有记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_douyin_delete_all_global_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 保存用户/游客自定义限制
    if (isset($_POST['xb_douyin_save_user_limit']) && $user_id !== null) {
        check_admin_referer('xb_douyin_user_limit_nonce');
        $custom_limit = isset($_POST['xb_douyin_custom_limit']) ? absint($_POST['xb_douyin_custom_limit']) : null;

        // 修改：查找任意设备记录以设置 custom_limit
        $existing = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id FROM $usage_table WHERE user_id = %d AND query_date = %s LIMIT 1",
                $user_id,
                current_time('Y-m-d')
            )
        );

        if ($existing) {
            $wpdb->update(
                $usage_table,
                array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
                array('id' => $existing->id),
                array('%d'),
                array('%d')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'device_id' => '',
                    'query_date' => current_time('Y-m-d'),
                    'query_count' => 0,
                    'custom_limit' => $custom_limit === 0 ? null : $custom_limit
                ),
                array('%d', '%s', '%s', '%d', '%d')
            );
        }

        echo '<div id="xb_douyin_limit_notice" class="updated"><p>解析限制已更新！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_douyin_limit_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 统计数据
    $stats = array();
    $where_clause = $user_id !== null ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : '';
    $stats['total_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table $where_clause");
    $stats['success_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table WHERE query_status = 'success' " . ($user_id !== null ? $wpdb->prepare('AND user_id = %d', $user_id) : ''));
    $stats['failed_queries'] = $stats['total_queries'] - $stats['success_queries'];
    $stats['today_queries'] = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $queries_table WHERE DATE(query_time) = %s " . ($user_id !== null ? 'AND user_id = %d' : ''), current_time('Y-m-d'), $user_id)
    );

    // 获取记录，包含 device_id
    $offset = ($paged - 1) * $per_page;
    $query = $user_id !== null
        ? $wpdb->prepare("SELECT id, user_id, device_id, video_url, query_status, query_time FROM $queries_table WHERE user_id = %d ORDER BY query_time DESC LIMIT %d, %d", $user_id, $offset, $per_page)
        : $wpdb->prepare("SELECT id, user_id, device_id, video_url, query_status, query_time FROM $queries_table ORDER BY query_time DESC LIMIT %d, %d", $offset, $per_page);
    $records = $wpdb->get_results($query);
    $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table" . ($user_id !== null ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : ''));
    $total_pages = ceil($total_records / $per_page);

    error_log('XB Douyin Parser: Fetched records. User ID: ' . ($user_id !== null ? $user_id : 'All') . ', Total records: ' . $total_records);

    $user_info = $user_id && $user_id !== 0 ? get_userdata($user_id) : null;
    ?>
    <div class="wrap">
        <div class="xb_douyin_admin_title">所有解析记录</div>
        <form method="post">
            <p>
                <label for="xb_douyin_user_id">输入用户 ID（留空显示所有记录，0 为游客）：</label>
                <input type="number" name="xb_douyin_user_id" id="xb_douyin_user_id" value="<?php echo esc_attr($user_id !== null ? $user_id : ''); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <form method="post">
            <?php wp_nonce_field('xb_douyin_delete_all_global_records_nonce'); ?>
            <p><input type="submit" name="xb_douyin_delete_all_global_records" class="button-secondary" value="删除所有记录" onclick="return confirm('确定删除所有用户的记录吗？此操作不可恢复！');"></p>
        </form>

        <?php if ($user_id !== null && ($user_id === 0 || $user_info)): ?>
            <div class="xb_douyin_subtitle"><?php echo $user_id === 0 ? '游客' : '用户：' . esc_html($user_info->user_login); ?> (ID: <?php echo $user_id; ?>)</div>
            <form method="post">
                <?php wp_nonce_field('xb_douyin_user_limit_nonce'); ?>
                <p>
                    <label for="xb_douyin_custom_limit">设置自定义每日解析次数（0 表示使用默认值）：</label>
                    <input type="number" name="xb_douyin_custom_limit" id="xb_douyin_custom_limit" min="0">
                    <input type="hidden" name="xb_douyin_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_douyin_save_user_limit" class="button-primary" value="保存">
                </p>
            </form>
            <form method="post">
                <?php wp_nonce_field('xb_douyin_delete_all_records_nonce'); ?>
                <input type="hidden" name="xb_douyin_user_id" value="<?php echo esc_attr($user_id); ?>">
                <p><input type="submit" name="xb_douyin_delete_all_records" class="button-secondary" value="删除所有记录" onclick="return confirm('确定删除所有记录吗？');"></p>
            </form>
        <?php endif; ?>

        <div class="xb_douyin_stats">
            <p>总解析次数：<?php echo esc_html($stats['total_queries']); ?></p>
            <p>成功解析次数：<?php echo esc_html($stats['success_queries']); ?></p>
            <p>失败解析次数：<?php echo esc_html($stats['failed_queries']); ?></p>
            <p>今日解析次数：<?php echo esc_html($stats['today_queries']); ?></p>
        </div>

        <table class="widefat">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>设备 ID</th>
                    <th>解析时间</th>
                    <th>视频链接</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="6">暂无解析记录。</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td><?php echo $record->user_id === 0 ? '游客' : esc_html($record->user_id); ?></td>
                            <td><?php echo esc_html($record->device_id); ?></td>
                            <td><?php echo esc_html($record->query_time); ?></td>
                            <td><?php echo esc_html($record->video_url); ?></td>
                            <td><?php echo esc_html($record->query_status); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_douyin_delete_record_nonce'); ?>
                                    <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>">
                                    <input type="submit" name="xb_douyin_delete_record" class="button-link" value="删除" onclick="return confirm('确定删除此记录？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}
?>