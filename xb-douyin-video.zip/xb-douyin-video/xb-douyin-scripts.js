jQuery(document).ready(function ($) {
    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('XB Douyin Parser: jQuery 未加载！');
        $('#xb_douyin_result').html('<div class="xb_douyin_message">脚本加载失败，请刷新页面！</div>');
        return;
    }

    // 确保 xb_douyin_ajax 配置
    if (typeof xb_douyin_ajax === 'undefined') {
        console.error('XB Douyin Parser: xb_douyin_ajax 未定义！');
        $('#xb_douyin_result').html('<div class="xb_douyin_message">脚本配置失败，请检查插件设置！</div>');
        return;
    }

    // 生成随机验证码
    function generateCaptcha() {
        const operators = ['+', '-'];
        const num1 = Math.floor(Math.random() * 10) + 1;
        const num2 = Math.floor(Math.random() * 10) + 1;
        const operator = operators[Math.floor(Math.random() * operators.length)];
        let question, value;

        if (operator === '+') {
            question = `${num1} + ${num2} = `;
            value = num1 + num2;
        } else {
            const maxNum = Math.max(num1, num2);
            const minNum = Math.min(num1, num2);
            question = `${maxNum} - ${minNum} = `;
            value = maxNum - minNum;
        }

        $('#xb_douyin_captcha_question').text(question);
        $('#xb_douyin_captcha_value').val(value);
    }

    // 检查是否需要显示验证码
    if ($('#xb_douyin_captcha_question').length) {
        generateCaptcha();
    }

    // 解析表单提交
    $('#xb_douyin_query_form').on('submit', function (e) {
        e.preventDefault();

        var $form = $(this);
        var url = $('#xb_douyin_url').val().trim();
        var nonce = $('#xb_douyin_nonce').val();
        var captchaAnswer = $('#xb_douyin_captcha_answer').val();
        var captchaValue = $('#xb_douyin_captcha_value').val();

        if (!url) {
            $('#xb_douyin_result').html('<div class="xb_douyin_message">请输入抖音视频链接！</div>');
            return;
        }

        if (!nonce) {
            $('#xb_douyin_result').html('<div class="xb_douyin_message">安全验证参数丢失，请刷新页面！</div>');
            return;
        }

        $.ajax({
            url: xb_douyin_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_douyin_query',
                url: url,
                nonce: nonce,
                captcha_answer: captchaAnswer || '',
                captcha_value: captchaValue || ''
            },
            beforeSend: function () {
                //$('.xb_douyin_submit_button').prop('disabled', true).text('解析中...');
                $('#xb_douyin_result').html('<div class="xb_douyin_message">正在解析，请稍候...</div>');
            },
            success: function (response) {
                if (response.success) {
                    $('#xb_douyin_result').html(response.data.result);
                    if ($('.xb_douyin_usage_info').length) {
                        $('.xb_douyin_usage_info').text('今日剩余解析次数：' + response.data.remaining + '/' + response.data.limit);
                    }

                    if (response.data.remaining <= 0 && !response.data.captcha) {
                        $form.hide();
                        var msg = response.data.is_guest ? '游客的使用次数已经用完，请登录之后继续。' : '今日解析次数已用尽，请明天再试！';
                        $('#xb_douyin_result').append('<div class="xb_douyin_message">' + msg + '</div>');
                        if (response.data.is_guest) {
                            var loginUrl = xb_douyin_ajax.login_url;
                            $('#xb_douyin_result').append('<a href="' + loginUrl + '" class="xb_douyin_login_button wp-ai-login-btn" style="display:block;width:fit-content;margin:10px auto;padding:10px 20px;background:#fe2c55;color:#fff;text-decoration:none;border-radius:4px;">快速登录</a>');
                        }
                    } else if (response.data.captcha) {
                        if (!$('#xb_douyin_captcha_question').length) {
                            $form.find('#xb_douyin_url').after(
                                '<div class="xb_douyin_captcha_section">' +
                                '<span id="xb_douyin_captcha_question"></span>' +
                                '<input type="number" name="xb_douyin_captcha_answer" id="xb_douyin_captcha_answer" placeholder="请输入验证码答案" required>' +
                                '<input type="hidden" name="xb_douyin_captcha_value" id="xb_douyin_captcha_value">' +
                                '</div>'
                            );
                            generateCaptcha();
                        } else {
                            generateCaptcha();
                            $('#xb_douyin_captcha_answer').val('');
                        }
                    }

                    // 添加错误处理
                    $('#xb_douyin_result img').on('error', function () {
                        $(this).replaceWith('<div class="xb_douyin_message">封面加载失败，请稍后重试！</div>');
                    });
                } else {
                    $('#xb_douyin_result').html('<div class="xb_douyin_message">' + response.data.message + '</div>');
                    if ($('#xb_douyin_captcha_question').length) {
                        generateCaptcha();
                        $('#xb_douyin_captcha_answer').val('');
                    }
                }
            },
            error: function (xhr, status, error) {
                console.error('XB Douyin Parser: AJAX 错误：' + error);
                $('#xb_douyin_result').html('<div class="xb_douyin_message">请求失败：' + error + '。请检查网络或刷新页面。</div>');
                if ($('#xb_douyin_captcha_question').length) {
                    generateCaptcha();
                    $('#xb_douyin_captcha_answer').val('');
                }
            },
            complete: function () {
                $('.xb_douyin_submit_button').prop('disabled', false).text('解析');
            }
        });
    });

    // 视频预览弹窗
    $(document).on('click', '.xb_douyin_preview_button', function () {
        var videoUrl = $(this).data('video-url');
        var popup = $('<div class="xb_douyin_popup"></div>');
        var popupContent = $(
            '<div class="xb_douyin_popup_content">' +
            '<meta name="referrer" content="no-referrer">' +
            '<span class="xb_douyin_popup_close">&times;</span>' +
            '<div class="xb_douyin_popup_title">视频预览</div>' +
            '<video class="xb_douyin_popup_video" controls autoplay preload="auto" playsinline>' +
            '<source src="' + videoUrl + '" type="video/mp4">' +
            '您的浏览器不支持视频播放。' +
            '</video>' +
            '</div>'
        );

        popup.append(popupContent);
        $('body').append(popup);

        // 关闭弹窗
        popupContent.find('.xb_douyin_popup_close').on('click', function () {
            popup.remove();
        });

        // 点击弹窗外部关闭
        popup.on('click', function (e) {
            if (e.target === this) {
                popup.remove();
            }
        });

        // 视频加载错误处理
        popupContent.find('video').on('error', function () {
            $(this).replaceWith('<div class="xb_douyin_message">视频加载失败，请稍后重试或检查链接！</div>');
        });
    });

    // 快速登录按钮功能
    $(document).on('click', '.xb_douyin_login_button, .wp-ai-login-btn', function(e) {
        e.preventDefault();

        // 优先调用启灵主题弹窗
        if (typeof window.developerStarterShowLoginModal === 'function') {
            window.developerStarterShowLoginModal('login');
            return;
        }

        const $themeLoginBtn = $('#header-login-toggle');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });
});