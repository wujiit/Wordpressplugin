jQuery(document).ready(function($) {
    // 刷新彩虹屁按钮点击事件
    $('.ai_caipi_refresh').on('click', function() {
        var $button = $(this);
        $button.prop('disabled', true); // 禁用按钮防止重复点击
        $('#ai_caipi_content, #ai_caipi_image').css('opacity', '0'); // 淡出内容和图片

        $.ajax({
            url: ai_caipi_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'ai_caipi_refresh',
                nonce: ai_caipi_vars.nonce,
                _t: new Date().getTime() // 添加时间戳以防止浏览器缓存并传递给后端
            },
            cache: false, // 禁用 AJAX 缓存
            success: function(response) {
                if (response.success) {
                    // 更新内容并淡入显示
                    $('#ai_caipi_content').text(response.data.content).css('opacity', '1');
                    if (response.data.image_url) {
                        $('#ai_caipi_image').html('<img src="' + response.data.image_url + '" alt="彩虹屁图片">').css('opacity', '1');
                    } else {
                        $('#ai_caipi_image').empty().css('opacity', '1');
                    }
                    // 更新复制按钮的 data-content
                    $('.ai_caipi_copy').data('content', response.data.content);
                } else {
                    // 处理服务器返回的失败情况
                    $('#ai_caipi_notice').text('刷新失败：' + (response.data.message || '未知错误')).show();
                    setTimeout(function() {
                        $('#ai_caipi_notice').fadeOut('slow', function() {
                            $(this).empty();
                        });
                    }, 3000);
                }
                $button.prop('disabled', false); // 恢复按钮
            },
            error: function() {
                // 处理 AJAX 请求失败
                $('#ai_caipi_content, #ai_caipi_image').css('opacity', '1');
                $button.prop('disabled', false);
                $('#ai_caipi_notice').text('网络错误，请稍后再试！').show();
                setTimeout(function() {
                    $('#ai_caipi_notice').fadeOut('slow', function() {
                        $(this).empty();
                    });
                }, 3000);
            }
        });
    });

    // 复制彩虹屁文字按钮点击事件
    $('.ai_caipi_copy').on('click', function() {
        var content = $(this).data('content');
        var $button = $(this);
        var $notice = $('#ai_caipi_notice');

        navigator.clipboard.writeText(content).then(function() {
            // 复制成功提示
            $button.addClass('copied').text('已复制');
            $notice.empty();
            setTimeout(function() {
                $button.removeClass('copied').text('复制');
            }, 2000);
        }).catch(function() {
            // 复制失败提示
            $notice.text('复制失败，请手动复制！').show();
            setTimeout(function() {
                $notice.fadeOut('slow', function() {
                    $notice.empty();
                });
            }, 3000);
        });
    });
});