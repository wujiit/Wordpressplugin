<?php
/*
Plugin Name: 小半彩虹屁
Description: 一个支持第三方接口和本地数据管理的彩虹屁插件，包含前台展示、后台设置和数据管理功能。
Version: 1.0.1
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('AI_CAIPI_VERSION', '1.8');
define('AI_CAIPI_DIR', plugin_dir_path(__FILE__));
define('AI_CAIPI_URL', plugin_dir_url(__FILE__));

// 激活插件时执行
register_activation_hook(__FILE__, 'ai_caipi_activate');
function ai_caipi_activate() {
    ai_caipi_create_table();
    ai_caipi_create_page();
}

// 创建数据库表
function ai_caipi_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'caihongpi';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        content TEXT NOT NULL,
        image_url VARCHAR(255) DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // 初始化调用统计
    if (!get_option('ai_caipi_stats')) {
        update_option('ai_caipi_stats', [
            'total' => [
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ],
            'today' => [
                'date' => current_time('Y-m-d'),
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ]
        ]);
    }
}

// 创建前台页面，检查是否已有包含短代码的页面
function ai_caipi_create_page() {
    $pages = get_posts([
        'post_type' => 'page',
        'post_status' => 'publish',
        's' => '[ai_caipi_display]',
        'numberposts' => 1,
    ]);

    if (empty($pages) && !get_option('ai_caipi_page_id')) {
        $page = [
            'post_title' => '彩虹屁',
            'post_content' => '[ai_caipi_display]',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        ];
        $page_id = wp_insert_post($page);
        update_option('ai_caipi_page_id', $page_id);
    }
}

// 加载前端资源，仅在包含短代码的页面加载
function ai_caipi_enqueue_assets() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'ai_caipi_display')) {
        wp_enqueue_style('ai_caipi_styles', AI_CAIPI_URL . 'ai-caihongpi.css', [], AI_CAIPI_VERSION);
        wp_enqueue_script('ai_caipi_scripts', AI_CAIPI_URL . 'ai-caihongpi.js', ['jquery'], AI_CAIPI_VERSION, true);
        wp_localize_script('ai_caipi_scripts', 'ai_caipi_vars', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ai_caipi_refresh')
        ]);
    }
}
add_action('wp_enqueue_scripts', 'ai_caipi_enqueue_assets');

// 注册短代码
add_shortcode('ai_caipi_display', 'ai_caipi_display_page');
function ai_caipi_display_page() {
    $options = get_option('ai_caipi_settings', [
        'use_third_party' => 0,
        'api_url' => 'https://apis.tianapi.com/caihongpi/index',
        'api_key' => '',
        'ad_content' => ''
    ]);

    $content = '';
    $image_url = '';

    if ($options['use_third_party']) {
        $content = ai_caipi_fetch_third_party();
    } else {
        $data = ai_caipi_fetch_local();
        $content = $data['content'] ?? '';
        $image_url = $data['image_url'] ?? '';
    }

    // 更新调用统计
    ai_caipi_update_stats($options['use_third_party'], !empty($content));

    ob_start();
    ?>
    <div class="ai_caipi_container">
        <div class="ai_caipi_title">彩虹屁</div>
        <div class="ai_caipi_card">
            <div class="ai_caipi_content" id="ai_caipi_content"><?php echo esc_html($content); ?></div>
            <?php if ($image_url): ?>
                <div class="ai_caipi_image" id="ai_caipi_image">
                    <img src="<?php echo esc_url($image_url); ?>" alt="彩虹屁图片">
                </div>
            <?php else: ?>
                <div class="ai_caipi_image" id="ai_caipi_image"></div>
            <?php endif; ?>
        </div>
        <div class="ai_caipi_buttons">
            <button class="ai_caipi_refresh">换一个</button>
            <button class="ai_caipi_copy" data-content="<?php echo esc_attr($content); ?>">复制</button>
        </div>
        <div class="ai_caipi_notice" id="ai_caipi_notice"></div>
        <div class="ai_caipi_ad"><?php echo wp_kses_post($options['ad_content']); ?></div>
    </div>
    <?php
    return ob_get_clean();
}

// 更新调用统计
function ai_caipi_update_stats($use_third_party, $third_party_success) {
    $stats = get_option('ai_caipi_stats', [
        'total' => [
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ],
        'today' => [
            'date' => current_time('Y-m-d'),
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ]
    ]);

    // 检查是否需要重置今日统计
    if ($stats['today']['date'] !== current_time('Y-m-d')) {
        $stats['today'] = [
            'date' => current_time('Y-m-d'),
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ];
    }

    if ($use_third_party) {
        $stats['total']['third_party_total']++;
        $stats['today']['third_party_total']++;
        if ($third_party_success) {
            $stats['total']['third_party_success']++;
            $stats['today']['third_party_success']++;
        }
    } else {
        $stats['total']['local_total']++;
        $stats['today']['local_total']++;
    }

    update_option('ai_caipi_stats', $stats);
}

// AJAX 刷新彩虹屁
add_action('wp_ajax_ai_caipi_refresh', 'ai_caipi_refresh_callback');
function ai_caipi_refresh_callback() {
    check_ajax_referer('ai_caipi_refresh', 'nonce');
    $options = get_option('ai_caipi_settings', ['use_third_party' => 0]);
    $content = '';
    $image_url = '';

    if ($options['use_third_party']) {
        $content = ai_caipi_fetch_third_party();
    } else {
        // 获取前端传递的动态参数（时间戳）以增强随机性
        $seed = isset($_POST['_t']) ? intval($_POST['_t']) : time();
        $data = ai_caipi_fetch_local($seed);
        $content = $data['content'] ?? '';
        $image_url = $data['image_url'] ?? '';
    }

    // 更新调用统计
    ai_caipi_update_stats($options['use_third_party'], !empty($content));

    wp_send_json_success(['content' => $content, 'image_url' => $image_url]);
}

// 获取第三方接口数据
function ai_caipi_fetch_third_party() {
    $options = get_option('ai_caipi_settings', [
        'api_url' => 'https://apis.tianapi.com/caihongpi/index',
        'api_key' => ''
    ]);

    $args = [
        'method' => 'POST',
        'body' => ['key' => $options['api_key']],
        'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
        'timeout' => 10,
    ];

    $response = wp_remote_request($options['api_url'], $args);
    if (is_wp_error($response)) {
        return '';
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['code']) && $data['code'] == 200 && isset($data['result']['content'])) {
        return $data['result']['content'];
    }
    return '';
}

// 获取本地数据，使用动态种子避免缓存影响
function ai_caipi_fetch_local($seed = null) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'caihongpi';

    // 获取所有数据的 ID 列表
    $ids = $wpdb->get_col("SELECT id FROM $table_name");
    if (empty($ids)) {
        return ['content' => '暂无彩虹屁数据，请在后台添加！', 'image_url' => ''];
    }

    // 使用动态种子（前端传递的时间戳或当前时间）确保随机性
    $seed = $seed ?? time();
    mt_srand($seed); // 设置随机种子
    $random_id = $ids[mt_rand(0, count($ids) - 1)];

    // 根据随机 ID 获取数据
    $result = $wpdb->get_row(
        $wpdb->prepare("SELECT content, image_url FROM $table_name WHERE id = %d", $random_id),
        ARRAY_A
    );

    return $result ?? ['content' => '暂无彩虹屁数据，请在后台添加！', 'image_url' => ''];
}

// 后台菜单
add_action('admin_menu', 'ai_caipi_admin_menu');
function ai_caipi_admin_menu() {
    add_menu_page('彩虹屁设置', '彩虹屁', 'manage_options', 'ai-caipi-settings', 'ai_caipi_settings_page', 'dashicons-smiley');
    add_submenu_page('ai-caipi-settings', '数据管理', '数据管理', 'manage_options', 'ai-caipi-data', 'ai_caipi_data_page');
}

// 设置页面
function ai_caipi_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['ai_caipi_save_settings'])) {
        check_admin_referer('ai_caipi_settings');
        $settings = [
            'use_third_party' => isset($_POST['ai_caipi_use_third_party']) ? 1 : 0,
            'api_url' => sanitize_text_field($_POST['ai_caipi_api_url']),
            'api_key' => sanitize_text_field($_POST['ai_caipi_api_key']),
            'ad_content' => wp_kses_post($_POST['ai_caipi_ad_content'])
        ];
        update_option('ai_caipi_settings', $settings);
        echo '<div class="notice notice-success is-dismissible ai_caipi_notice"><p>设置已保存。</p></div>';
    }

    if (isset($_POST['ai_caipi_clear_stats'])) {
        check_admin_referer('ai_caipi_clear_stats');
        update_option('ai_caipi_stats', [
            'total' => [
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ],
            'today' => [
                'date' => current_time('Y-m-d'),
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ]
        ]);
        echo '<div class="notice notice-success is-dismissible ai_caipi_notice"><p>调用统计已清空。</p></div>';
    }

    $options = get_option('ai_caipi_settings', [
        'use_third_party' => 0,
        'api_url' => 'https://apis.tianapi.com/caihongpi/index',
        'api_key' => '',
        'ad_content' => ''
    ]);

    $stats = get_option('ai_caipi_stats', [
        'total' => [
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ],
        'today' => [
            'date' => current_time('Y-m-d'),
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ]
    ]);

    ?>
    <div class="wrap">
        <h1>小半彩虹屁设置</h1>
        <form method="post" action="">
            <?php wp_nonce_field('ai_caipi_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="ai_caipi_use_third_party">使用第三方接口</label></th>
                    <td><input type="checkbox" name="ai_caipi_use_third_party" id="ai_caipi_use_third_party" <?php checked($options['use_third_party'], 1); ?>></td>
                </tr>
                <tr>
                    <th><label for="ai_caipi_api_url">API 接口地址</label></th>
                    <td><input type="text" name="ai_caipi_api_url" id="ai_caipi_api_url" value="<?php echo esc_attr($options['api_url']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="ai_caipi_api_key">API 密钥</label></th>
                    <td><input type="text" name="ai_caipi_api_key" id="ai_caipi_api_key" value="<?php echo esc_attr($options['api_key']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="ai_caipi_ad_content">广告内容</label></th>
                    <td><textarea name="ai_caipi_ad_content" id="ai_caipi_ad_content" rows="5" class="large-text"><?php echo esc_textarea($options['ad_content']); ?></textarea></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="ai_caipi_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        <p>第三方接口: https://www.tianapi.com/apiview/181 </p>
        <h2>调用统计</h2>
        <h3>总计</h3>
        <p>第三方接口总调用次数: <?php echo esc_html($stats['total']['third_party_total']); ?></p>
        <p>第三方接口成功调用次数: <?php echo esc_html($stats['total']['third_party_success']); ?></p>
        <p>本地接口调用次数: <?php echo esc_html($stats['total']['local_total']); ?></p>
        <h3>今日 (<?php echo esc_html($stats['today']['date']); ?>)</h3>
        <p>第三方接口总调用次数: <?php echo esc_html($stats['today']['third_party_total']); ?></p>
        <p>第三方接口成功调用次数: <?php echo esc_html($stats['today']['third_party_success']); ?></p>
        <p>本地接口调用次数: <?php echo esc_html($stats['today']['local_total']); ?></p>
        <form method="post" action="">
            <?php wp_nonce_field('ai_caipi_clear_stats'); ?>
            <p class="submit"><input type="submit" name="ai_caipi_clear_stats" class="button-secondary" value="清空统计" onclick="return confirm('确定清空所有调用统计？');"></p>
        </form>
    </div>
    <?php
}

// 数据管理页面
function ai_caipi_data_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'caihongpi';

    // 处理添加
    if (isset($_POST['ai_caipi_add_data'])) {
        check_admin_referer('ai_caipi_data');
        $content = sanitize_text_field($_POST['ai_caipi_content']);
        $image_url = esc_url_raw($_POST['ai_caipi_image_url']);
        $wpdb->insert($table_name, [
            'content' => $content,
            'image_url' => $image_url
        ]);
        echo '<div class="notice notice-success is-dismissible ai_caipi_notice"><p>数据已添加。</p></div>';
    }

    // 处理编辑
    if (isset($_POST['ai_caipi_edit_data'])) {
        check_admin_referer('ai_caipi_edit_data');
        $id = intval($_POST['ai_caipi_edit_id']);
        $content = sanitize_text_field($_POST['ai_caipi_content']);
        $image_url = esc_url_raw($_POST['ai_caipi_image_url']);
        $wpdb->update($table_name, [
            'content' => $content,
            'image_url' => $image_url
        ], ['id' => $id]);
        echo '<div class="notice notice-success is-dismissible ai_caipi_notice"><p>数据已更新。</p></div>';
    }

    // 处理删除
    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
        check_admin_referer('ai_caipi_delete_' . $_GET['id']);
        $wpdb->delete($table_name, ['id' => intval($_GET['id'])]);
        echo '<div class="notice notice-success is-dismissible ai_caipi_notice"><p>数据已删除。</p></div>';
    }

    // 处理删除全部
    if (isset($_POST['ai_caipi_delete_all'])) {
        check_admin_referer('ai_caipi_delete_all');
        $wpdb->query("TRUNCATE TABLE $table_name");
        echo '<div class="notice notice-success is-dismissible ai_caipi_notice"><p>所有数据已删除。</p></div>';
    }

    // 获取编辑数据
    $edit_item = null;
    if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
        $edit_item = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", intval($_GET['id'])), ARRAY_A);
    }

    // 分页
    $per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;
    $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $total_pages = ceil($total_items / $per_page);
    $items = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC LIMIT $offset, $per_page", ARRAY_A);

    ?>
    <div class="wrap">
        <h1>彩虹屁数据管理</h1>
        
        <!-- 添加数据表单 -->
        <h2>添加新数据</h2>
        <form method="post" action="">
            <?php wp_nonce_field('ai_caipi_data'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="ai_caipi_content_add">彩虹屁句子</label></th>
                    <td><input type="text" name="ai_caipi_content" id="ai_caipi_content_add" value="" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="ai_caipi_image_url_add">图片 URL</label></th>
                    <td><input type="url" name="ai_caipi_image_url" id="ai_caipi_image_url_add" value="" class="regular-text"></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="ai_caipi_add_data" class="button-primary" value="添加数据"></p>
        </form>

        <!-- 编辑数据表单 -->
        <?php if ($edit_item): ?>
            <h2>编辑数据</h2>
            <form method="post" action="">
                <?php wp_nonce_field('ai_caipi_edit_data'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="ai_caipi_content_edit">彩虹屁句子</label></th>
                        <td><input type="text" name="ai_caipi_content" id="ai_caipi_content_edit" value="<?php echo esc_attr($edit_item['content']); ?>" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="ai_caipi_image_url_edit">图片 URL</label></th>
                        <td><input type="url" name="ai_caipi_image_url" id="ai_caipi_image_url_edit" value="<?php echo esc_url($edit_item['image_url']); ?>" class="regular-text"></td>
                    </tr>
                </table>
                <input type="hidden" name="ai_caipi_edit_id" value="<?php echo esc_attr($edit_item['id']); ?>">
                <p class="submit"><input type="submit" name="ai_caipi_edit_data" class="button-primary" value="更新数据"></p>
            </form>
        <?php endif; ?>

        <!-- 删除所有数据 -->
        <form method="post" action="">
            <?php wp_nonce_field('ai_caipi_delete_all'); ?>
            <p class="submit"><input type="submit" name="ai_caipi_delete_all" class="button-secondary" value="删除所有数据" onclick="return confirm('确定删除所有数据？');"></p>
        </form>

        <!-- 数据列表 -->
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>句子</th>
                    <th>图片 URL</th>
                    <th>创建时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td><?php echo esc_html($item['content']); ?></td>
                        <td><?php echo esc_url($item['image_url']); ?></td>
                        <td><?php echo esc_html($item['created_at']); ?></td>
                        <td>
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ai-caipi-data&action=edit&id=' . $item['id']), 'ai_caipi_edit_' . $item['id']); ?>">编辑</a> |
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ai-caipi-data&action=delete&id=' . $item['id']), 'ai_caipi_delete_' . $item['id']); ?>" onclick="return confirm('确定删除？');">删除</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- 分页 -->
        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links([
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => '«',
                'next_text' => '»',
                'total' => $total_pages,
                'current' => $current_page
            ]);
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}

// 后台通知自动消失脚本
add_action('admin_footer', 'ai_caipi_admin_scripts');
function ai_caipi_admin_scripts() {
    ?>
    <script>
    jQuery(document).ready(function($) {
        setTimeout(function() {
            $('.ai_caipi_notice').fadeOut('slow');
        }, 3000);
    });
    </script>
    <?php
}
?>