jQuery(document).ready(function($) {
    $('#xp-repaint-form').on('submit', function(e) {
        e.preventDefault();
        let formData = new FormData(this);

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    checkTaskStatus(response.data.task_id);
                } else {
                    alert(response.data);
                }
            }
        });
    });

    function checkTaskStatus(taskId) {
        let interval = setInterval(function() {
            $.post(ajaxurl, {
                action: 'xp_repaint_check',
                task_id: taskId
            }, function(response) {
                if (response.success) {
                    clearInterval(interval);
                    $('#xp-repaint-results').html('<img src="' + response.data.url + '">');
                }
            });
        }, 5000); // 每5秒检查一次
    }
});