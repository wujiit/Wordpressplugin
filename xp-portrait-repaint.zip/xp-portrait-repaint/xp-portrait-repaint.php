<?php
/*
Plugin Name: 小半人像AI重绘插件
Description: 基于通义千问模型的人像风格重绘插件，支持上传图片并选择预置风格或参考图片进行重绘。
Version: 1.0
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时创建数据库表和页面
register_activation_hook(__FILE__, 'xp_repaint_activate');
function xp_repaint_activate() {
    global $wpdb;
    
    // 创建任务表
    $table_name = $wpdb->prefix . 'xp_repaint_tasks';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        task_id varchar(255) NOT NULL,
        original_image_url varchar(255) NOT NULL,
        ref_image_url varchar(255) DEFAULT NULL,
        style_index int NOT NULL,
        result_image_url varchar(255) DEFAULT NULL,
        status varchar(50) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        completed_at datetime DEFAULT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // 创建用户每日限制表
    $limit_table = $wpdb->prefix . 'xp_repaint_user_limits';
    $limit_sql = "CREATE TABLE $limit_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        daily_limit int NOT NULL,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    dbDelta($limit_sql);

    // 查询是否已有包含短代码 [xp_repaint_form] 的页面
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xp_repaint_form]',
        'numberposts' => 1,
    ));

    // 如果没有找到包含短代码的页面，则创建新页面
    if (empty($pages)) {
        wp_insert_post([
            'post_title'   => '人像重绘',
            'post_content' => '[xp_repaint_form]',
            'post_status'  => 'publish',
            'post_author'  => 1,
            'post_type'    => 'page',
            'post_name'    => 'portrait-repaint'
        ]);
    }
}

// 插件列表页面添加设置入口
function xp_repaint_add_settings_link($links) {
    $settings_link = '<a href="admin.php?page=xp-repaint-settings">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'xp_repaint_add_settings_link');

// 添加后台菜单
add_action('admin_menu', 'xp_repaint_admin_menu');
function xp_repaint_admin_menu() {
    add_menu_page('人像重绘设置', '人像重绘', 'manage_options', 'xp-repaint-settings', 'xp_repaint_settings_page', 'dashicons-art');
    add_submenu_page('xp-repaint-settings', '重绘记录', '重绘记录', 'manage_options', 'xp-repaint-records', 'xp_repaint_records_page');
}

function xp_repaint_settings_page() {
    if (isset($_POST['xp_repaint_save'])) {
        update_option('xp_repaint_api_url', sanitize_text_field($_POST['api_url']));
        update_option('xp_repaint_api_key', sanitize_text_field($_POST['api_key']));
        update_option('xp_repaint_model_params', sanitize_text_field($_POST['model_params']));
        update_option('xp_repaint_styles', sanitize_text_field($_POST['styles']));
        update_option('xp_repaint_enable_ref_image', isset($_POST['enable_ref_image']) ? 1 : 0);
        update_option('xp_repaint_notice', wp_kses_post($_POST['notice_content']));
        $daily_limit = isset($_POST['daily_limit']) ? max(1, intval($_POST['daily_limit'])) : 10;
        update_option('xp_repaint_daily_limit', $daily_limit);
        echo '<div class="updated" id="xp-settings-saved-message"><p>设置已保存</p></div>';
    }

    $api_url = get_option('xp_repaint_api_url', 'https://dashscope.aliyuncs.com/api/v1/services/aigc/image-generation/generation');
    $api_key = get_option('xp_repaint_api_key', '');
    $model_params = get_option('xp_repaint_model_params', 'wanx-style-repaint-v1');
    $styles = get_option('xp_repaint_styles', '0(复古漫画),1(3D童话),2(二次元)');
    $enable_ref_image = get_option('xp_repaint_enable_ref_image', 0);
    $notice_content = get_option('xp_repaint_notice', '');
    $daily_limit = get_option('xp_repaint_daily_limit', 10);

    ?>
    <div class="wrap">
        <h1>人像重绘设置</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>API 请求地址</th>
                    <td><input type="text" name="api_url" value="<?php echo esc_attr($api_url); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>API Key</th>
                    <td><input type="text" name="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>模型参数</th>
                    <td><input type="text" name="model_params" value="<?php echo esc_attr($model_params); ?>" class="regular-text"><p>多个参数用英文逗号分隔，默认使用第一个</p></td>
                </tr>
                <tr>
                    <th>预置风格</th>
                    <td><input type="text" name="styles" value="<?php echo esc_attr($styles); ?>" class="regular-text"><p>格式：索引(名称)，如 0(复古漫画),1(3D童话)</p></td>
                </tr>
                <tr>
                    <th>支持参考风格图片</th>
                    <td><input type="checkbox" name="enable_ref_image" value="1" <?php checked($enable_ref_image, 1); ?>> 启用</td>
                </tr>
                <tr>
                    <th>默认每天重绘次数限制</th>
                    <td>
                        <input type="number" name="daily_limit" value="<?php echo esc_attr($daily_limit); ?>" min="1" class="regular-text">
                        <p>设置每个用户默认每天可以重绘的图片次数，设置为 0 表示无限制</p>
                    </td>
                </tr>
                <tr>
                    <th>公告内容</th>
                    <td>
                        <textarea name="notice_content" rows="5" class="large-text"><?php echo esc_textarea($notice_content); ?></textarea>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="xp_repaint_save" class="button-primary" value="保存设置"></p>
        </form>
        有阿里通义千问模型提供：https://help.aliyun.com/zh/model-studio/user-guide/style-repaint <br>
        单价：0.12元一张
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const settingsSavedMessage = document.getElementById('xp-settings-saved-message');
            if (settingsSavedMessage) {
                setTimeout(() => {
                    settingsSavedMessage.style.display = 'none';
                }, 3000);
            }
        });
    </script>
    <?php
}

// 重绘记录页面
function xp_repaint_records_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xp_repaint_tasks';
    $limit_table = $wpdb->prefix . 'xp_repaint_user_limits';
    $per_page = 20;
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $search_user_id = isset($_GET['search_user_id']) ? intval($_GET['search_user_id']) : '';

    // 处理用户限制设置
    if (isset($_POST['set_user_limit']) && isset($_POST['user_id']) && isset($_POST['new_limit'])) {
        $user_id = intval($_POST['user_id']);
        $new_limit = max(0, intval($_POST['new_limit']));
        
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $limit_table WHERE user_id = %d",
            $user_id
        ));
        
        if ($existing) {
            $wpdb->update(
                $limit_table,
                ['daily_limit' => $new_limit, 'updated_at' => current_time('mysql')],
                ['user_id' => $user_id]
            );
        } else {
            $wpdb->insert(
                $limit_table,
                ['user_id' => $user_id, 'daily_limit' => $new_limit]
            );
        }
        echo '<div class="updated" id="xp-limit-updated-message"><p>用户每日限制已更新</p></div>';
    }

    $where = '';
    if ($search_user_id) {
        $where = $wpdb->prepare("WHERE user_id = %d", $search_user_id);
    }

    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
    $offset = ($paged - 1) * $per_page;
    $records = $wpdb->get_results("SELECT * FROM $table_name $where ORDER BY created_at DESC LIMIT $offset, $per_page");

    $all_records_total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $user_total = $search_user_id ? $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d", $search_user_id)) : 0;
    $today_count = 0;
    $user_limit = $search_user_id ? $wpdb->get_var($wpdb->prepare(
        "SELECT daily_limit FROM $limit_table WHERE user_id = %d",
        $search_user_id
    )) : null;
    $default_limit = get_option('xp_repaint_daily_limit', 10);

    if ($search_user_id) {
        $today_start = current_time('Y-m-d 00:00:00');
        $today_end = current_time('Y-m-d 23:59:59');
        $today_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND created_at BETWEEN %s AND %s",
            $search_user_id,
            $today_start,
            $today_end
        ));
    }

    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['record_id'])) {
        $record_id = intval($_GET['record_id']);
        $wpdb->delete($table_name, ['id' => $record_id]);
        echo '<div class="updated" id="xp-record-deleted-message"><p>记录已删除</p></div>';
        $records = $wpdb->get_results("SELECT * FROM $table_name $where ORDER BY created_at DESC LIMIT $offset, $per_page");
        $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
        $all_records_total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        $user_total = $search_user_id ? $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d", $search_user_id)) : 0;
        if ($search_user_id) {
            $today_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND created_at BETWEEN %s AND %s",
                $search_user_id,
                $today_start,
                $today_end
            ));
        }
    }

    if (isset($_GET['action']) && $_GET['action'] === 'clear_limit' && isset($_GET['user_id'])) {
        $user_id = intval($_GET['user_id']);
        $wpdb->delete($limit_table, ['user_id' => $user_id]);
        wp_redirect(admin_url('admin.php?page=xp-repaint-records&search_user_id=' . $user_id));
        exit;
    }

    ?>
    <div class="wrap">
        <h1>重绘记录</h1>
        <p>总记录数: <?php echo $all_records_total; ?>
        <?php if ($search_user_id) { ?>
            (当前用户 <?php echo esc_html($search_user_id); ?> 的记录数: <?php echo $user_total; ?> | 
            今日重绘次数: <?php echo $today_count; ?> | 
            每日限制: <?php echo $user_limit !== null ? $user_limit : $default_limit . ' (默认)'; ?>)
        <?php } ?></p>

        <form method="get" action="" style="margin-bottom: 10px;">
            <input type="hidden" name="page" value="xp-repaint-records">
            <label>搜索用户ID: <input type="number" name="search_user_id" value="<?php echo esc_attr($search_user_id); ?>"></label>
            <input type="submit" class="button" value="搜索">
            <?php if ($search_user_id) { ?>
                <a href="?page=xp-repaint-records" class="button">查看全部记录</a>
            <?php } ?>
        </form>

        <?php if ($search_user_id) { ?>
            <form method="post" style="margin-bottom: 10px;">
                <label>设置用户 <?php echo esc_html($search_user_id); ?> 的每日重绘次数限制:
                    <input type="number" name="new_limit" value="<?php echo esc_attr($user_limit !== null ? $user_limit : $default_limit); ?>" min="0">
                </label>
                <input type="hidden" name="user_id" value="<?php echo esc_attr($search_user_id); ?>">
                <input type="submit" name="set_user_limit" class="button" value="更新限制">
                <?php if ($user_limit !== null) { ?>
                    <a href="?page=xp-repaint-records&action=clear_limit&user_id=<?php echo $search_user_id; ?>" 
                       class="button" 
                       onclick="return confirm('确定要清除此用户的自定义限制吗？将恢复使用默认限制');">清除自定义限制</a>
                <?php } ?>
            </form>
        <?php } ?>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户ID</th>
                    <th>用户名</th>
                    <th>原图预览</th>
                    <th>参考图预览</th>
                    <th>重绘图预览</th>
                    <th>重绘时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record) {
                    $user = get_user_by('id', $record->user_id);
                    ?>
                    <tr>
                        <td><?php echo esc_html($record->user_id); ?></td>
                        <td><?php echo esc_html($user ? $user->user_login : '未知用户'); ?></td>
                        <td><img src="<?php echo esc_url($record->original_image_url); ?>" style="max-width: 100px; max-height: 100px; object-fit: cover;"></td>
                        <td><?php echo $record->ref_image_url ? '<img src="' . esc_url($record->ref_image_url) . '" style="max-width: 100px; max-height: 100px; object-fit: cover;">' : '无'; ?></td>
                        <td><?php echo $record->result_image_url ? '<img src="' . esc_url($record->result_image_url) . '" style="max-width: 100px; max-height: 100px; object-fit: cover;">' : '未完成'; ?></td>
                        <td><?php echo esc_html($record->completed_at ? $record->completed_at : '未完成'); ?></td>
                        <td><a href="?page=xp-repaint-records&action=delete&record_id=<?php echo $record->id; ?><?php echo $search_user_id ? '&search_user_id=' . $search_user_id : ''; ?>" class="button" onclick="return confirm('确定删除此记录吗？');">删除</a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <?php
        $total_pages = ceil($total / $per_page);
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            $pagination_args = [
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ];
            if ($search_user_id) {
                $pagination_args['add_args'] = ['search_user_id' => $search_user_id];
            }
            echo paginate_links($pagination_args);
            echo '</div></div>';
        }
        ?>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const limitUpdatedMessage = document.getElementById('xp-limit-updated-message');
            if (limitUpdatedMessage) {
                setTimeout(() => {
                    limitUpdatedMessage.style.display = 'none';
                }, 3000);
            }
            const recordDeletedMessage = document.getElementById('xp-record-deleted-message');
            if (recordDeletedMessage) {
                setTimeout(() => {
                    recordDeletedMessage.style.display = 'none';
                }, 3000);
            }
        });
    </script>
    <?php
}

// 加载 CSS 文件
add_action('wp_enqueue_scripts', 'xp_repaint_enqueue_styles');
function xp_repaint_enqueue_styles() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xp_repaint_form')) {
        wp_enqueue_style('wp-ai-image-style', 'https://img.qiyucloud.com/cloud/xp-portrait-repaint/style.css');
        //wp_enqueue_style('xb-image-clarity-style', plugins_url('style.css', __FILE__), [], '1.0');
        wp_enqueue_script('jquery');
    }
}

// 检查用户当天重绘次数
function xp_repaint_check_daily_limit($user_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xp_repaint_tasks';
    $limit_table = $wpdb->prefix . 'xp_repaint_user_limits';
    
    $user_limit = $wpdb->get_var($wpdb->prepare(
        "SELECT daily_limit FROM $limit_table WHERE user_id = %d",
        $user_id
    ));
    
    $daily_limit = $user_limit !== null ? $user_limit : get_option('xp_repaint_daily_limit', 10);

    if ($daily_limit == 0) {
        return ['exceeded' => false, 'count' => 0, 'limit' => $daily_limit, 'remaining' => PHP_INT_MAX];
    }

    $today_start = current_time('Y-m-d 00:00:00');
    $today_end = current_time('Y-m-d 23:59:59');

    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND created_at BETWEEN %s AND %s",
        $user_id,
        $today_start,
        $today_end
    ));

    return [
        'exceeded' => $count >= $daily_limit,
        'count' => $count,
        'limit' => $daily_limit,
        'remaining' => $daily_limit - $count // 添加剩余次数
    ];
}

// 前台短代码
add_shortcode('xp_repaint_form', 'xp_repaint_form_shortcode');
function xp_repaint_form_shortcode() {
    $styles = get_option('xp_repaint_styles', '0(复古漫画),1(3D童话),2(二次元)');
    $style_arr = array_map(function($style) {
        preg_match('/(\d+)\((.+)\)/', $style, $matches);
        return ['index' => $matches[1], 'name' => $matches[2]];
    }, explode(',', $styles));
    $enable_ref_image = get_option('xp_repaint_enable_ref_image', 0);
    $notice_content = get_option('xp_repaint_notice', '');

    global $wpdb;
    $user_id = get_current_user_id();
    $history = $user_id ? $wpdb->get_results($wpdb->prepare("SELECT result_image_url FROM {$wpdb->prefix}xp_repaint_tasks WHERE user_id = %d AND result_image_url IS NOT NULL ORDER BY created_at DESC LIMIT 10", $user_id)) : [];

    $limit_check = $user_id ? xp_repaint_check_daily_limit($user_id) : ['exceeded' => false, 'count' => 0, 'limit' => 0, 'remaining' => 0];
    $exceeded_limit = $limit_check['exceeded'];
    $daily_count = $limit_check['count'];
    $daily_limit = $limit_check['limit'];
    $remaining_count = $limit_check['remaining']; // 获取剩余次数

    if ($exceeded_limit) {
        $limit_notice = '<p class="xp-limit-notice">今天已经超额（' . esc_html($daily_count) . '/' . esc_html($daily_limit) . '），请明天再来！</p>';
        $notice_content = $limit_notice . $notice_content;
    }

    ob_start();
    ?>
    <div id="xp-repaint-form">
        <div class="xp-page-title">人像漫画风格AI重绘</div>
        <?php if (!$user_id) { ?>
            <div class="xp-login-prompt">
                <p>请先登录以使用图片风格重绘功能！</p>
                <p><a href="<?php echo wp_login_url(get_permalink()); ?>" class="xp-login-link xp-modern-btn">点击这里登录</a></p>
            </div>
        <?php } else if ($exceeded_limit) { ?>
            <div class="xp-limit-prompt">
                <p>您今天的重绘次数已达上限（<?php echo esc_html($daily_count); ?>/<?php echo esc_html($daily_limit); ?>），请明天再来！</p>
            </div>
        <?php } else { ?>
            <div class="xp-upload-area">
                <div class="xp-upload-row">
                    <div class="xp-upload-field xp-upload-field-inline">
                        <label>选择原人像图片:</label>
                        <input type="file" id="original_image" accept=".jpg,.jpeg,.png,.bmp,.webp" hidden>
                        <button type="button" class="xp-modern-btn xp-upload-btn" data-target="original_image">选择图片</button>
                    </div>
                    <?php if ($enable_ref_image) { ?>
                        <div class="xp-upload-field xp-upload-field-inline">
                            <label>选择参考风格图片:</label>
                            <input type="file" id="ref_image" accept=".jpg,.jpeg,.png,.bmp,.webp" hidden>
                            <button type="button" class="xp-modern-btn xp-upload-btn" data-target="ref_image">选择图片</button>
                        </div>
                    <?php } ?>
                </div>
                <div class="xp-upload-field">
                    <label>选择内置重绘风格:</label>
                    <select id="style_index">
                        <?php foreach ($style_arr as $style) { ?>
                            <option value="<?php echo esc_attr($style['index']); ?>"><?php echo esc_html($style['name']); ?></option>
                        <?php } ?>
                    </select>
                    <button id="xp-repaint-submit" class="xp-modern-btn" disabled>提交重绘</button>
                </div>
            </div>
            <div id="xp-repaint-message"></div>
            <div id="xp-repaint-preview">
                <div class="xp-section-title">上传预览</div>
                <div class="xp-preview-container">
                    <div id="original-preview" class="xp-preview-box"></div>
                    <?php if ($enable_ref_image) { ?>
                        <div id="ref-preview" class="xp-preview-box"></div>
                    <?php } ?>
                </div>
            </div>
            <div id="xp-repaint-results">
                <div class="xp-section-title">重绘结果</div>
                <div id="result-preview" class="xp-result-box"></div>
                <!-- 添加剩余次数显示 -->
                <div id="xp-repaint-remaining" class="xp-remaining-count">
                    今日剩余重绘次数：<span id="remaining-count"><?php echo esc_html($remaining_count); ?></span>/<?php echo esc_html($daily_limit); ?>
                </div>
            </div>
            <?php if (!empty($notice_content)) { ?>
                <div id="xp-repaint-notice">
                    <div class="xp-notice-content"><?php echo wp_kses_post($notice_content); ?></div>
                </div>
            <?php } ?>
        <?php } ?>
        <?php if ($user_id && $history) { ?>
            <div id="xp-repaint-history">
                <div class="xp-section-title">我的重绘</div>
                <div class="xp-history-container" id="history-container">
                    <?php foreach ($history as $item) { ?>
                        <div class="xp-history-item">
                            <a href="<?php echo esc_url($item->result_image_url); ?>" data-fancybox="gallery" data-caption="历史重绘">
                                <img src="<?php echo esc_url($item->result_image_url); ?>" alt="历史重绘">
                            </a>
                            <button class="xp-download-btn" data-url="<?php echo esc_url($item->result_image_url); ?>">快速下载</button>
                        </div>
                    <?php } ?>
                </div>
            </div>
        <?php } ?>

        <!-- 示例图板块 -->
        <div id="xp-repaint-example">
            <div class="xp-section-title">示例图片</div>
            <div class="xp-example-container">
                <img src="https://aiimg.qiyucloud.com/htai/2025/04/20250408170428168.jpg" alt="示例重绘效果">
            </div>
        </div>

        <div id="xp-custom-alert" class="xp-custom-alert">
            <div class="xp-custom-alert-content">
                <span id="xp-custom-alert-message"></span>
                <button id="xp-custom-alert-close" class="xp-custom-alert-close">×</button>
            </div>
        </div>
    </div>
    <script>
        function showCustomAlert(message, duration = 3000) {
            const alertBox = document.getElementById('xp-custom-alert');
            const alertMessage = document.getElementById('xp-custom-alert-message');
            const closeButton = document.getElementById('xp-custom-alert-close');

            alertMessage.textContent = message;
            alertBox.classList.add('show');

            const autoClose = setTimeout(() => {
                alertBox.classList.remove('show');
            }, duration);

            closeButton.addEventListener('click', () => {
                clearTimeout(autoClose);
                alertBox.classList.remove('show');
            });
        }

        // “点击这里登录”按钮点击事件
        document.addEventListener('DOMContentLoaded', function() {
            const loginLink = document.querySelector('.xp-login-link');
            if (loginLink) {
                loginLink.addEventListener('click', function(e) {
                    e.preventDefault();
                    const $themeLoginBtn = document.querySelector('.nav-login .signin-loader');
                    if ($themeLoginBtn) {
                        $themeLoginBtn.click();
                    } else {
                        window.location.href = this.getAttribute('href');
                    }
                });
            }
        });

        <?php if ($user_id && !$exceeded_limit) { ?>
            let originalUrl = null;
            let refUrl = null;
            const allowedFormats = ['image/jpeg', 'image/png', 'image/jpg', 'image/bmp', 'image/webp'];
            const allowedExtensions = ['.jpg', '.jpeg', '.png', '.bmp', '.webp']; // 支持的扩展名
            const maxFileSize = 3 * 1024 * 1024; // 最大文件大小 3MB
            let remainingCount = <?php echo json_encode($remaining_count); ?>; // 初始化剩余次数

            document.querySelectorAll('.xp-upload-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const targetInput = document.getElementById(this.dataset.target);
                    targetInput.click();
                });
            });

            // 处理原图上传
            document.getElementById('original_image').addEventListener('change', async function() {
                const isValid = await validateImage(this);
                if (isValid) {
                    uploadImage(this, 'original');
                } else {
                    this.value = ''; // 清空无效文件
                }
            });

            <?php if ($enable_ref_image) { ?>
            // 处理参考图上传
            document.getElementById('ref_image').addEventListener('change', async function() {
                const isValid = await validateImage(this);
                if (isValid) {
                    uploadImage(this, 'ref');
                } else {
                    this.value = ''; // 清空无效文件
                }
            });
            <?php } ?>

            // 验证图片的函数（前端验证）
            async function validateImage(input) {
                const file = input.files[0];
                if (!file) {
                    showCustomAlert('请选择一个文件！');
                    return false;
                }

                const fileName = file.name.toLowerCase();
                const fileExtension = '.' + fileName.split('.').pop();

                // 检查文件扩展名
                if (!allowedExtensions.includes(fileExtension)) {
                    showCustomAlert('文件格式不正确！仅支持 .jpg, .jpeg, .png, .bmp, .webp 格式。');
                    return false;
                }

                // 检查 MIME 类型
                if (!allowedFormats.includes(file.type.toLowerCase())) {
                    showCustomAlert('文件好像不正确！仅支持 JPEG、PNG、JPG、BMP、WEBP 格式。');
                    return false;
                }

                // 检查文件大小
                if (file.size > maxFileSize) {
                    showCustomAlert('图片大小超过限制！最大支持 3MB。');
                    return false;
                }

                // 使用 FileReader 读取文件内容并验证真实性
                return new Promise((resolve) => {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const img = new Image();
                        img.onload = function() {
                            resolve(true); // 图片加载成功，说明是真实图片
                        };
                        img.onerror = function() {
                            showCustomAlert('文件不是有效的图片！请更换图片。');
                            resolve(false); // 图片加载失败，说明不是真实图片
                        };
                        img.src = e.target.result;
                    };
                    reader.onerror = function() {
                        showCustomAlert('无法读取文件！请更换图片。');
                        resolve(false);
                    };
                    reader.readAsDataURL(file);
                });
            }

            // 上传图片的函数
            function uploadImage(input, type) {
                if (!input.files[0]) return;
                let formData = new FormData();
                formData.append(type + '_image', input.files[0]);

                fetch('<?php echo rest_url('xp-repaint/v1/upload'); ?>', {
                    method: 'POST',
                    body: formData,
                    headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' }
                })
                .then(response => {
                    if (!response.ok) throw new Error('上传失败: ' + response.status);
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        if (type === 'original') {
                            originalUrl = data.image_url;
                            document.getElementById('original-preview').innerHTML = `<img src="${originalUrl}" alt="原图">`;
                            document.getElementById('xp-repaint-submit').disabled = false;
                        } else {
                            refUrl = data.image_url;
                            document.getElementById('ref-preview').innerHTML = `<img src="${refUrl}" alt="参考图">`;
                        }
                    } else {
                        showCustomAlert('上传失败: ' + data.message);
                        input.value = '';
                    }
                })
                .catch(error => {
                    console.error('上传错误:', error);
                    showCustomAlert('上传失败，请稍后再试');
                    input.value = '';
                });
            }

            // 提交重绘
            document.getElementById('xp-repaint-submit').addEventListener('click', function(e) {
                e.preventDefault();
                if (!originalUrl) {
                    showCustomAlert('请先上传原图片');
                    return;
                }

                let styleIndex = refUrl ? -1 : document.getElementById('style_index').value;
                document.getElementById('xp-repaint-message').innerHTML = '<div class="xp-loading">正在提交中，请稍候...</div>';

                fetch('<?php echo rest_url('xp-repaint/v1/submit'); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>'
                    },
                    body: JSON.stringify({
                        original_url: originalUrl,
                        ref_url: refUrl,
                        style_index: styleIndex
                    })
                })
                .then(response => {
                    if (!response.ok) throw new Error('重绘失败: ' + response.status);
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        document.getElementById('xp-repaint-message').innerHTML = '<div class="xp-success"><span>请等待2-5分钟，正在重绘中</span><span class="xp-loading-dots"><span class="dot">.</span><span class="dot">.</span><span class="dot">.</span></span></div>';
                        remainingCount--;
                        updateRemainingCount();
                        xp_repaint_poll_result(data.task_id);
                    } else {
                        document.getElementById('xp-repaint-message').innerHTML = '<div class="xp-error">提交失败: ' + data.message + '</div>';
                    }
                })
                .catch(error => {
                    console.error('重绘错误:', error);
                    document.getElementById('xp-repaint-message').innerHTML = '<div class="xp-error">重绘失败，请检查网络或联系管理员</div>';
                });
            });

            // 更新剩余次数显示的函数
            function updateRemainingCount() {
                const remainingElement = document.getElementById('remaining-count');
                if (remainingElement) {
                    remainingElement.textContent = remainingCount;
                    if (remainingCount <= 0) {
                        document.getElementById('xp-repaint-submit').disabled = true;
                        showCustomAlert('今日重绘次数已用尽，请明天再试！');
                    }
                }
            }

            function xp_repaint_poll_result(task_id) {
                let interval = setInterval(() => {
                    fetch('<?php echo rest_url('xp-repaint/v1/result/'); ?>' + task_id, {
                        headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' }
                    })
                    .then(response => {
                        if (!response.ok) throw new Error('轮询失败: ' + response.status);
                        return response.json();
                    })
                    .then(data => {
                        if (data.success && data.result_url) {
                            document.getElementById('xp-repaint-message').innerHTML = '<div class="xp-success">重绘完成！</div>';
                            document.getElementById('result-preview').innerHTML = `
                                <div class="xp-result-item">
                                    <img src="${data.result_url}" alt="重绘结果">
                                    <button class="xp-download-btn" data-url="${data.result_url}">快速下载</button>
                                </div>`;
                            setTimeout(() => {
                                document.getElementById('xp-repaint-message').innerHTML = '';
                            }, 3000);
                            clearInterval(interval);

                            attachDownloadEvents();

                            const historyContainer = document.getElementById('history-container');
                            if (historyContainer) {
                                const newItem = document.createElement('div');
                                newItem.className = 'xp-history-item';
                                newItem.innerHTML = `
                                    <a href="${data.result_url}" data-fancybox="gallery" data-caption="历史重绘">
                                        <img src="${data.result_url}" alt="历史重绘">
                                    </a>
                                    <button class="xp-download-btn" data-url="${data.result_url}">快速下载</button>`;
                                historyContainer.insertBefore(newItem, historyContainer.firstChild);
                                while (historyContainer.children.length > 10) {
                                    historyContainer.removeChild(historyContainer.lastChild);
                                }
                                attachDownloadEvents();
                            }
                        } else if (!data.success && data.message !== '任务尚未完成') {
                            document.getElementById('xp-repaint-message').innerHTML = '<div class="xp-error">重绘失败: ' + data.message + '</div>';
                            clearInterval(interval);
                        }
                    })
                    .catch(error => {
                        console.error('轮询错误:', error);
                        document.getElementById('xp-repaint-message').innerHTML = '<div class="xp-error">轮询失败，请稍后再试</div>';
                        clearInterval(interval);
                    });
                }, 5000);
            }

            function attachDownloadEvents() {
                document.querySelectorAll('.xp-download-btn').forEach(btn => {
                    btn.removeEventListener('click', handleDownload);
                    btn.addEventListener('click', handleDownload);
                });
            }

            async function handleDownload() {
                const url = this.getAttribute('data-url');
                try {
                    const response = await fetch(url, {
                        method: 'GET',
                        headers: {
                            'Cache-Control': 'no-cache'
                        }
                    });

                    if (!response.ok) {
                        throw new Error('图片下载失败: ' + response.statusText);
                    }

                    const blob = await response.blob();
                    const blobUrl = window.URL.createObjectURL(blob);

                    const urlParts = new URL(url);
                    const path = urlParts.pathname;
                    const extensionMatch = path.match(/\.([a-zA-Z0-9]+)$/);
                    const extension = extensionMatch ? extensionMatch[1] : 'jpg';

                    const link = document.createElement('a');
                    link.href = blobUrl;
                    link.download = `repaint_result_${Date.now()}.${extension}`;
                    document.body.appendChild(link);
                    link.click();

                    document.body.removeChild(link);
                    window.URL.revokeObjectURL(blobUrl);
                } catch (error) {
                    console.error('下载错误:', error);
                    showCustomAlert('图片下载失败，请稍后再试或检查图片链接');
                }
            }

            document.addEventListener('DOMContentLoaded', attachDownloadEvents);
        <?php } ?>
    </script>
    <?php
    return ob_get_clean();
}

// REST API 注册
add_action('rest_api_init', 'xp_repaint_register_api');
function xp_repaint_register_api() {
    register_rest_route('xp-repaint/v1', '/upload', [
        'methods' => 'POST',
        'callback' => 'xp_repaint_upload_image',
        'permission_callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_forbidden', '请先登录以使用此功能', ['status' => 401]);
            }
            $nonce = $request->get_header('X-WP-Nonce');
            return wp_verify_nonce($nonce, 'wp_rest');
        }
    ]);

    register_rest_route('xp-repaint/v1', '/submit', [
        'methods' => 'POST',
        'callback' => 'xp_repaint_submit_image',
        'permission_callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_forbidden', '请先登录以使用此功能', ['status' => 401]);
            }
            $user_id = get_current_user_id();
            $limit_check = xp_repaint_check_daily_limit($user_id);
            if ($limit_check['exceeded']) {
                return new WP_Error('rest_forbidden', '您今天的重绘次数已达上限，请明天再来', ['status' => 403]);
            }
            $nonce = $request->get_header('X-WP-Nonce');
            return wp_verify_nonce($nonce, 'wp_rest');
        }
    ]);

    register_rest_route('xp-repaint/v1', '/result/(?P<task_id>[a-zA-Z0-9-]+)', [
        'methods' => 'GET',
        'callback' => 'xp_repaint_get_result',
        'permission_callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_forbidden', '请先登录以使用此功能', ['status' => 401]);
            }
            $nonce = $request->get_header('X-WP-Nonce');
            return wp_verify_nonce($nonce, 'wp_rest');
        }
    ]);
}

// 上传图片处理（优化后的版本）
function xp_repaint_upload_image($request) {
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    $files = $request->get_file_params();
    $type = !empty($files['original_image']) ? 'original_image' : 'ref_image';

    if (empty($files[$type])) {
        return new WP_REST_Response(['success' => false, 'message' => '请上传图片'], 400);
    }

    $file = $files[$type];
    $allowed_mime_types = ['image/jpeg', 'image/png', 'image/jpg', 'image/bmp', 'image/webp'];
    $max_file_size = 3 * 1024 * 1024;

    // 检查文件大小
    if ($file['size'] > $max_file_size) {
        return new WP_REST_Response(['success' => false, 'message' => '图片大小超过限制！最大支持 3MB。'], 400);
    }

    // 检查文件扩展名
    $file_name = strtolower($file['name']);
    $file_extension = '.' . pathinfo($file_name, PATHINFO_EXTENSION);
    $allowed_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.webp'];
    if (!in_array($file_extension, $allowed_extensions)) {
        return new WP_REST_Response(['success' => false, 'message' => '不支持的文件扩展名！仅支持 .jpg, .jpeg, .png, .bmp, .webp 格式。'], 400);
    }

    // 检查 MIME 类型
    $file_mime_type = strtolower($file['type']);
    if (!in_array($file_mime_type, $allowed_mime_types)) {
        return new WP_REST_Response(['success' => false, 'message' => '文件不是有效的图片！仅支持 JPEG、PNG、JPG、BMP、WEBP 格式。'], 400);
    }

    // 检查文件真实性（使用 getimagesize）
    $image_info = @getimagesize($file['tmp_name']);
    if ($image_info === false) {
        return new WP_REST_Response(['success' => false, 'message' => '文件不是有效的图片！请更换图片。'], 400);
    }

    $actual_mime_type = strtolower($image_info['mime']);
    if (!in_array($actual_mime_type, $allowed_mime_types)) {
        return new WP_REST_Response(['success' => false, 'message' => '文件类型验证失败！仅支持 JPEG、PNG、JPG、BMP、WEBP 格式。'], 400);
    }

    // 额外的文件头检查（防止伪装文件）
    $file_handle = @fopen($file['tmp_name'], 'rb');
    if ($file_handle === false) {
        return new WP_REST_Response(['success' => false, 'message' => '无法读取文件！请更换图片。'], 400);
    }
    $file_header = fread($file_handle, 8);
    fclose($file_handle);

    $valid_headers = [
        "\xFF\xD8" => 'image/jpeg', // JPEG 文件头
        "\x89PNG\r\n" => 'image/png', // PNG 文件头
        "BM" => 'image/bmp', // BMP 文件头
        "RIFF" => 'image/webp' // WEBP 文件头（前4字节，配合后续检查）
    ];

    $is_valid_header = false;
    foreach ($valid_headers as $header => $mime) {
        if (strpos($file_header, $header) === 0) {
            $is_valid_header = true;
            break;
        }
    }

    if (!$is_valid_header) {
        return new WP_REST_Response(['success' => false, 'message' => '文件不是有效的图片！请更换图片。'], 400);
    }

    // 上传文件到 WordPress 媒体库
    $upload_id = media_handle_upload($type, 0);
    if (is_wp_error($upload_id)) {
        return new WP_REST_Response(['success' => false, 'message' => '上传失败: ' . $upload_id->get_error_message()], 500);
    }

    $image_url = wp_get_attachment_url($upload_id);
    if (!$image_url) {
        return new WP_REST_Response(['success' => false, 'message' => '无法获取上传后的图片 URL'], 500);
    }

    return new WP_REST_Response(['success' => true, 'image_url' => $image_url], 200);
}

// 提交重绘任务
function xp_repaint_submit_image($request) {
    $params = $request->get_json_params();
    if (!$params) {
        return new WP_REST_Response(['success' => false, 'message' => '无效的请求数据'], 400);
    }

    $original_url = $params['original_url'] ?? '';
    $ref_url = $params['ref_url'] ?? null;
    $style_index = $params['style_index'] ?? 0;

    if (empty($original_url)) {
        return new WP_REST_Response(['success' => false, 'message' => '缺少原图片链接'], 400);
    }

    $api_url = get_option('xp_repaint_api_url', 'https://dashscope.aliyuncs.com/api/v1/services/aigc/image-generation/generation');
    $api_key = get_option('xp_repaint_api_key', '');
    $model = explode(',', get_option('xp_repaint_model_params', 'wanx-style-repaint-v1'))[0];

    if (empty($api_key)) {
        return new WP_REST_Response(['success' => false, 'message' => 'API Key 未配置'], 500);
    }

    $body = [
        'model' => $model,
        'input' => [
            'image_url' => $original_url,
            'style_index' => (int)$style_index
        ]
    ];
    if ($ref_url) {
        $body['input']['style_ref_url'] = $ref_url;
    }

    $response = wp_remote_post($api_url, [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'X-DashScope-Async' => 'enable',
            'Content-Type' => 'application/json'
        ],
        'body' => json_encode($body),
        'timeout' => 30,
        'sslverify' => true
    ]);

    if (is_wp_error($response)) {
        return new WP_REST_Response(['success' => false, 'message' => 'API 请求失败: ' . $response->get_error_message()], 500);
    }

    $response_body = wp_remote_retrieve_body($response);
    $response_code = wp_remote_retrieve_response_code($response);
    $data = json_decode($response_body, true);

    if ($response_code !== 200 || !isset($data['output']['task_id'])) {
        $error_message = isset($data['message']) ? $data['message'] : '未知错误';
        $error_code = isset($data['code']) ? $data['code'] : 'Unknown';
        return new WP_REST_Response(['success' => false, 'message' => "API 返回错误: [$error_code] $error_message", 'response' => $response_body], 500);
    }

    global $wpdb;
    $user_id = get_current_user_id();
    $insert_result = $wpdb->insert($wpdb->prefix . 'xp_repaint_tasks', [
        'user_id' => $user_id ? $user_id : 0,
        'task_id' => $data['output']['task_id'],
        'original_image_url' => $original_url,
        'ref_image_url' => $ref_url,
        'style_index' => $style_index,
        'status' => $data['output']['task_status']
    ]);

    if ($insert_result === false) {
        return new WP_REST_Response(['success' => false, 'message' => '数据库写入失败: ' . $wpdb->last_error], 500);
    }

    return new WP_REST_Response([
        'success' => true,
        'task_id' => $data['output']['task_id']
    ], 200);
}

// 获取重绘结果
function xp_repaint_get_result($request) {
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    $task_id = $request['task_id'];
    global $wpdb;
    $table_name = $wpdb->prefix . 'xp_repaint_tasks';
    $task = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE task_id = %s", $task_id));

    if (!$task) {
        return new WP_REST_Response(['success' => false, 'message' => '任务不存在'], 404);
    }

    if ($task->result_image_url) {
        return new WP_REST_Response(['success' => true, 'result_url' => $task->result_image_url], 200);
    }

    $api_key = get_option('xp_repaint_api_key');
    if (empty($api_key)) {
        return new WP_REST_Response(['success' => false, 'message' => 'API Key 未配置'], 500);
    }

    $response = wp_remote_get("https://dashscope.aliyuncs.com/api/v1/tasks/$task_id", [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json'
        ],
        'timeout' => 15,
        'sslverify' => true
    ]);

    if (is_wp_error($response)) {
        return new WP_REST_Response(['success' => false, 'message' => 'API 请求失败: ' . $response->get_error_message()], 500);
    }

    $response_body = wp_remote_retrieve_body($response);
    $response_code = wp_remote_retrieve_response_code($response);
    $data = json_decode($response_body, true);

    if ($response_code !== 200) {
        $error_message = isset($data['message']) ? $data['message'] : '未知错误';
        $error_code = isset($data['code']) ? $data['code'] : 'Unknown';
        return new WP_REST_Response(['success' => false, 'message' => "API 返回错误: [$error_code] $error_message"], 500);
    }

    if ($data['output']['task_status'] === 'SUCCEEDED' && !empty($data['output']['results'][0]['url'])) {
        $result_url = $data['output']['results'][0]['url'];
        $parsed_url = parse_url($result_url);
        $clean_url = $parsed_url['scheme'] . '://' . $parsed_url['host'] . $parsed_url['path'];

        $path_info = pathinfo($parsed_url['path']);
        $extension = isset($path_info['extension']) ? strtolower($path_info['extension']) : 'jpg';
        if (empty($extension)) {
            $extension = 'jpg';
        }

        $filename = 'repaint_result_' . $task_id . '_' . time() . '.' . $extension;

        $tmp = download_url($result_url);
        if (is_wp_error($tmp)) {
            return new WP_REST_Response(['success' => false, 'message' => '图片下载失败: ' . $tmp->get_error_message()], 500);
        }

        $file_array = [
            'name' => $filename,
            'tmp_name' => $tmp
        ];

        $attachment_id = media_handle_sideload($file_array, 0, 'Repaint Result for Task ' . $task_id);
        if (is_wp_error($attachment_id)) {
            @unlink($tmp);
            return new WP_REST_Response(['success' => false, 'message' => '保存到媒体库失败: ' . $attachment_id->get_error_message()], 500);
        }

        $saved_image_url = wp_get_attachment_url($attachment_id);

        $update_result = $wpdb->update(
            $table_name,
            [
                'result_image_url' => $saved_image_url,
                'status' => 'SUCCEEDED',
                'completed_at' => current_time('mysql')
            ],
            ['task_id' => $task_id]
        );

        if ($update_result === false) {
            @unlink($tmp);
            return new WP_REST_Response(['success' => false, 'message' => '数据库更新失败: ' . $wpdb->last_error], 500);
        }

        return new WP_REST_Response(['success' => true, 'result_url' => $saved_image_url], 200);
    } elseif ($data['output']['task_status'] === 'FAILED') {
        $wpdb->update(
            $table_name,
            ['status' => 'FAILED'],
            ['task_id' => $task_id]
        );
        return new WP_REST_Response(['success' => false, 'message' => $data['output']['message'] ?? '任务执行失败'], 500);
    }

    return new WP_REST_Response(['success' => false, 'message' => '任务尚未完成'], 202);
}