<?php
/*
Plugin Name: 小半AI文案助手
Description: 基于AI的WordPress文案生成助手
Version: 1.1.0
Author: summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 创建数据库
function Copywriter_create_database() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'Copywriting_records';
    $theme_table = $wpdb->prefix . 'Copywriting_themes';
    $history_table = $wpdb->prefix . 'Copywriting_history';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        usage_date date NOT NULL,
        total_count int DEFAULT 0,
        success_count int DEFAULT 0,
        custom_limit int DEFAULT NULL,
        PRIMARY KEY (id),
        INDEX user_date_index (user_id, usage_date)
    ) $charset_collate;";

    $theme_sql = "CREATE TABLE $theme_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        record_id bigint(20) NOT NULL,
        user_id bigint(20) NOT NULL,
        theme_content text NOT NULL,
        ai_model varchar(100) DEFAULT '',
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        INDEX record_user_index (record_id, user_id)
    ) $charset_collate;";

    $history_sql = "CREATE TABLE $history_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        input_content text NOT NULL,
        output_content longtext NOT NULL,
        platforms text NOT NULL,
        ai_model varchar(100) DEFAULT '',
        operation_type varchar(20) DEFAULT 'generate',
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        INDEX user_time_index (user_id, created_at)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    dbDelta($theme_sql);
    dbDelta($history_sql);
}

// 提前定义回调函数
function Copywriter_generate_handler(WP_REST_Request $request) {
    global $wpdb;
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = get_option('Copywriter_daily_limit', 10);
    
    error_log("处理生成文案请求 - 用户ID: $user_id, 日期: $today");

    // 获取使用数据 - 按user_id汇总所有设备的使用次数
    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT SUM(total_count) as total_count, SUM(success_count) as success_count, 
         MAX(custom_limit) as custom_limit FROM {$wpdb->prefix}Copywriting_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));
    
    $total_count = $usage_data ? $usage_data->total_count : 0;
    $success_count = $usage_data ? $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? $usage_data->custom_limit : $default_limit;
    
    if ($success_count >= $user_limit) {
        error_log("使用限制超出 - 用户ID: $user_id, 成功次数: $success_count, 限制: $user_limit");
        echo "data: " . json_encode(array('error' => '今日使用次数已达上限')) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    // 检查违规词
    $forbidden_words = array_filter(array_map('trim', explode(',', get_option('Copywriter_forbidden_words', ''))));
    $input_data = $request->get_param('data') ?? '';
    $operation_type = $request->get_param('operation_type') ?? 'generate';
    
    if (!empty($forbidden_words)) {
        foreach ($forbidden_words as $word) {
            if (stripos($input_data, $word) !== false) {
                error_log("检测到违规词 - 用户ID: $user_id, 违规词: $word");
                echo "data: " . json_encode(array('error' => '输入内容包含违规词"' . esc_html($word) . '"，请重新编辑主题')) . "\n\n";
                ob_flush();
                flush();
                exit;
            }
        }
    }

    // 构造 AI 提示词 - 专业优化版本，确保平台精准分离
    $platforms = $request->get_param('platforms') ?? array();
    $platforms_str = is_array($platforms) ? implode('、', $platforms) : $platforms;
    
    if ($operation_type === 'optimize') {
        $prompt = "你是一个专业的文案优化专家，擅长为不同社交媒体平台优化文案内容。请严格按照以下要求优化文案：\n\n";
        $prompt .= "1. 保持原文案的核心信息和主要卖点不变\n";
        $prompt .= "2. 优化语言表达，使其更加生动、有吸引力和感染力\n";
        $prompt .= "3. 确保文案语法正确，没有错别字，逻辑清晰\n";
        $prompt .= "4. 增强文案的情感共鸣和用户参与度\n";
        if (!empty($platforms)) {
            $prompt .= "5. **关键要求**：必须严格按照用户选择的平台数量输出对应数量的文案！\n";
            $prompt .= "   用户选择的平台：{$platforms_str}\n";
            $prompt .= "   - 小红书(Xiaohongshu)：生活化表达，真实体验分享，多用emoji表情符号，突出个人感受\n";
            $prompt .= "   - 抖音(Douyin)：简洁有力，有节奏感，朗朗上口，容易记忆传播，适合短视频\n";
            $prompt .= "   - 微博(Weibo)：简洁明了，有话题性，适合转发互动，字数控制在140字内\n";
            $prompt .= "6. **输出格式要求**：必须为每个选中的平台单独输出，格式如下：\n";
            $prompt .= "【平台名称】 优化后的文案内容\n\n";
            $prompt .= "7. **重要提醒**：只输出用户选择的平台文案，不要输出其他平台的内容！\n";
        } else {
            $prompt .= "5. 优化为适合社交媒体传播的通用文案风格\n";
        }
        $prompt .= "\n原始文案： {$input_data}\n\n请对以上文案进行专业优化。";
    } else {
        $prompt = "你是一个专业的文案创作专家，擅长为不同社交媒体平台创作高质量文案。请严格按照以下要求创作：\n\n";
        $prompt .= "1. 确保文案语法正确，没有错别字，逻辑清晰\n";
        $prompt .= "2. 文案要有吸引力，能够引起用户兴趣和共鸣\n";
        $prompt .= "3. 突出产品或服务的核心卖点和优势\n";
        if (!empty($platforms)) {
            $prompt .= "4. **关键要求**：必须严格按照用户选择的平台数量输出对应数量的文案！\n";
            $prompt .= "   用户选择的平台：{$platforms_str}\n";
            $prompt .= "   - 小红书(Xiaohongshu)：生活化表达，真实体验分享，多用emoji表情符号，突出个人感受\n";
            $prompt .= "   - 抖音(Douyin)：简洁有力，有节奏感，朗朗上口，容易记忆传播，适合短视频\n";
            $prompt .= "   - 微博(Weibo)：简洁明了，有话题性，适合转发互动，字数控制在140字内\n";
            $prompt .= "5. **输出格式要求**：必须为每个选中的平台单独输出，格式如下：\n";
            $prompt .= "【平台名称】 文案内容\n\n";
            $prompt .= "6. **重要提醒**：只输出用户选择的平台文案，不要输出其他平台的内容！\n";
        } else {
            $prompt .= "4. 创作适合社交媒体传播的通用文案风格\n";
        }
        $prompt .= "7. 严格按照用户提供的主题信息创作，不得遗漏重要内容\n";
        $prompt .= "\n创作主题： {$input_data}\n\n请根据以上主题创作相应的文案。";
    }

    // 发起 API 请求
    $api_url = get_option('Copywriter_api_url', '');
    $api_key = get_option('Copywriter_api_key', '');
    $model = $request->get_param('model') ?? array_map('trim', explode(',', get_option('Copywriter_models', 'deepseek-chat')))[0];
    
    if (empty($api_url) || empty($api_key)) {
        error_log("API 配置错误 - URL: $api_url, Key: " . (empty($api_key) ? '未设置' : '已设置'));
        echo "data: " . json_encode(array('error' => 'API地址或密钥未配置')) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    // 更新总尝试次数
    $record_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}Copywriting_records WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));
    
    if ($record_id) {
        $wpdb->update(
            $wpdb->prefix . 'Copywriting_records',
            array('total_count' => $total_count + 1),
            array('id' => $record_id)
        );
    } else {
        $wpdb->insert(
            $wpdb->prefix . 'Copywriting_records',
            array('user_id' => $user_id, 'usage_date' => $today, 'total_count' => 1, 'success_count' => 0)
        );
        $record_id = $wpdb->insert_id;
    }

    // 保存创作主题
    if ($input_data) {
        $wpdb->insert(
            $wpdb->prefix . 'Copywriting_themes',
            array(
                'record_id' => $record_id,
                'user_id' => $user_id,
                'theme_content' => $input_data,
                'ai_model' => $model,
                'created_at' => current_time('mysql')
            )
        );
    }

    // 设置流式响应头
    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no');

    // 使用 cURL 发起请求
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Bearer ' . $api_key,
        'Content-Type: application/json',
        'Accept: text/event-stream'
    ));
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
        'model' => $model,
        'messages' => array(
            array('role' => 'user', 'content' => $prompt)
        ),
        'stream' => true
    )));

    // 流式处理回调
    $has_content = false;
    $full_content = '';
    curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $data) use ($user_id, $today, $success_count, &$has_content, &$full_content, $input_data, $platforms, $model, $operation_type) {
        global $wpdb;

        $lines = explode("\n", $data);
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;

            if (strpos($line, 'data: ') === 0) {
                $json_data = trim(substr($line, 6));
                if ($json_data === '[DONE]') {
                    if ($has_content) {
                        // 更新成功次数
                        $wpdb->update(
                            $wpdb->prefix . 'Copywriting_records',
                            array('success_count' => $success_count + 1),
                            array('user_id' => $user_id, 'usage_date' => $today)
                        );
                        
                        // 保存历史记录
                        $wpdb->insert(
                            $wpdb->prefix . 'Copywriting_history',
                            array(
                                'user_id' => $user_id,
                                'input_content' => $input_data,
                                'output_content' => $full_content,
                                'platforms' => is_array($platforms) ? implode(',', $platforms) : $platforms,
                                'ai_model' => $model,
                                'operation_type' => $operation_type,
                                'created_at' => current_time('mysql')
                            )
                        );
                    }
                    echo "data: [DONE]\n\n";
                    ob_flush();
                    flush();
                    return strlen($data);
                }

                $parsed_data = json_decode($json_data, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    error_log('JSON 解析错误: ' . json_last_error_msg() . ' - 数据: ' . $json_data);
                    continue;
                }

                if (isset($parsed_data['choices'][0]['delta']['content'])) {
                    $has_content = true;
                    $content = $parsed_data['choices'][0]['delta']['content'];
                    $full_content .= $content;
                    echo "data: " . json_encode(array('content' => $content)) . "\n\n";
                    ob_flush();
                    flush();
                } elseif (isset($parsed_data['error'])) {
                    echo "data: " . json_encode(array('error' => $parsed_data['error']['message'])) . "\n\n";
                    ob_flush();
                    flush();
                    return strlen($data);
                }
            }
        }
        return strlen($data);
    });

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        error_log('cURL 请求失败: ' . $error);
        echo "data: " . json_encode(array('error' => 'API请求失败: ' . $error)) . "\n\n";
        ob_flush();
        flush();
    } elseif (!$has_content) {
        error_log('未收到有效内容 - cURL 响应状态: ' . curl_getinfo($ch, CURLINFO_HTTP_CODE));
        echo "data: " . json_encode(array('error' => '生成失败，未收到有效内容')) . "\n\n";
        ob_flush();
        flush();
    }

    curl_close($ch);
    exit;
}

// 创建前台页面
function Copywriter_create_frontend_page() {
    // 查询是否已有包含短代码 [copywriting_assistant_shortcode] 的页面
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[copywriting_assistant_shortcode]',
        'numberposts' => 1,
    ));

    // 如果没有找到包含短代码的页面
    if (empty($pages)) {
        // 创建页面
        wp_insert_post(array(
            'post_title'    => 'AI文案助手',
            'post_name'     => 'ai-copywriting-assistant',
            'post_content'  => '[copywriting_assistant_shortcode]',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        ));
    }
}
register_activation_hook(__FILE__, 'Copywriter_create_frontend_page');

// 加载前台资源
function Copywriter_load_resources() {
    wp_enqueue_style('Copywriter_styles', plugin_dir_url(__FILE__) . 'copywriter.css', array(), '1.3.0');
    wp_enqueue_script('Copywriter_script', plugin_dir_url(__FILE__) . 'copywriter.js', array('jquery'), '1.3.0', true);
    
    // 加载 marked.js 用于 Markdown 渲染
    wp_enqueue_script('marked-js', 'https://cdn.jsdelivr.net/npm/marked/marked.min.js', array(), '4.3.0', true);
    
    wp_localize_script('Copywriter_script', 'CopywriterData', array(
        'rest_url' => esc_url_raw(rest_url('copywriter/v1/generate')),
        'history_url' => esc_url_raw(rest_url('copywriter/v1/history')),
        'nonce' => wp_create_nonce('wp_rest'),
        'ajax_url' => admin_url('admin-ajax.php'),
        'forbidden_words' => array_filter(array_map('trim', explode(',', get_option('Copywriter_forbidden_words', ''))))
    ));
}

// 动态加载前端资源
add_action('wp_enqueue_scripts', function() {
    global $post;
    // 仅在包含 [copywriting_assistant_shortcode] 的页面加载资源
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'copywriting_assistant_shortcode')) {
        Copywriter_load_resources();
    }
});

// 注册激活钩子
register_activation_hook(__FILE__, 'Copywriter_create_database');
register_activation_hook(__FILE__, 'Copywriter_create_frontend_page');

// 在前台页面加载资源
add_action('wp_enqueue_scripts', function() {
    if (is_page('ai-copywriting-assistant')) {
        Copywriter_load_resources();
    }
});

// 注册 REST API 端点
add_action('rest_api_init', function() {
    $namespace = 'copywriter/v1';
    $endpoint = '/generate';
    $full_endpoint = rest_url($namespace . $endpoint);
    error_log("尝试注册 REST API 端点: $full_endpoint");

    register_rest_route($namespace, $endpoint, array(
        'methods' => 'POST',
        'callback' => 'Copywriter_generate_handler',
        'permission_callback' => function(WP_REST_Request $request) {
            $is_logged_in = is_user_logged_in();
            error_log("权限检查: 用户登录状态 - " . ($is_logged_in ? '已登录' : '未登录'));
            if (!$is_logged_in) {
                return new WP_Error('rest_not_logged_in', '请先登录', array('status' => 401));
            }
            $nonce = $request->get_header('X-WP-Nonce');
            if (!wp_verify_nonce($nonce, 'wp_rest')) {
                error_log("Nonce 验证失败 - 接收到的 nonce: $nonce");
                return new WP_Error('rest_forbidden', 'Nonce 验证失败', array('status' => 403));
            }
            return true;
        }
    ));

    // 注册使用情况端点
    register_rest_route($namespace, '/usage', array(
        'methods' => 'GET',
        'callback' => 'Copywriter_get_usage',
        'permission_callback' => function() {
            return is_user_logged_in();
        }
    ));

    // 注册历史记录端点
    register_rest_route($namespace, '/history', array(
        'methods' => 'GET',
        'callback' => 'Copywriter_get_history',
        'permission_callback' => function() {
            return is_user_logged_in();
        }
    ));

    // 注册删除历史记录端点
    register_rest_route($namespace, '/history/(?P<id>\d+)', array(
        'methods' => 'DELETE',
        'callback' => 'Copywriter_delete_history',
        'permission_callback' => function() {
            return is_user_logged_in();
        }
    ));
});

// 获取使用情况
function Copywriter_get_usage(WP_REST_Request $request) {
    global $wpdb;
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = get_option('Copywriter_daily_limit', 10);

    // 按user_id汇总所有设备的使用次数
    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT SUM(total_count) as total_count, SUM(success_count) as success_count, 
         MAX(custom_limit) as custom_limit FROM {$wpdb->prefix}Copywriting_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));

    $total_count = $usage_data ? $usage_data->total_count : 0;
    $success_count = $usage_data ? $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? $usage_data->custom_limit : $default_limit;

    return array(
        'remaining' => max(0, $user_limit - $success_count),
        'limit' => $user_limit,
        'total_count' => $total_count,
        'success_count' => $success_count
    );
}

// 获取历史记录
function Copywriter_get_history(WP_REST_Request $request) {
    global $wpdb;
    $user_id = get_current_user_id();
    $page = $request->get_param('page') ?? 1;
    $per_page = 10;
    $offset = ($page - 1) * $per_page;

    $history = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}Copywriting_history 
        WHERE user_id = %d 
        ORDER BY created_at DESC 
        LIMIT %d OFFSET %d",
        $user_id,
        $per_page,
        $offset
    ));

    $total = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}Copywriting_history WHERE user_id = %d",
        $user_id
    ));

    return array(
        'history' => $history,
        'total' => $total,
        'page' => $page,
        'per_page' => $per_page,
        'total_pages' => ceil($total / $per_page)
    );
}

// 删除历史记录
function Copywriter_delete_history(WP_REST_Request $request) {
    global $wpdb;
    $user_id = get_current_user_id();
    $history_id = $request->get_param('id');

    $result = $wpdb->delete(
        $wpdb->prefix . 'Copywriting_history',
        array('id' => $history_id, 'user_id' => $user_id)
    );

    if ($result) {
        return array('success' => true);
    } else {
        return new WP_Error('delete_failed', '删除失败', array('status' => 500));
    }
}

// 后台菜单
function Copywriter_admin_menu() {
    add_menu_page(
        '文案助手',
        '文案助手',
        'manage_options',
        'copywriting-assistant',
        'Copywriter_settings_page',
        'dashicons-edit'
    );
    add_submenu_page(
        'copywriting-assistant',
        '用户记录',
        '用户记录',
        'manage_options',
        'copywriting-user-records',
        'Copywriter_user_records_page'
    );
}
add_action('admin_menu', 'Copywriter_admin_menu');

// 注册设置
function Copywriter_register_settings() {
    register_setting('copywriter_settings', 'Copywriter_api_url');
    register_setting('copywriter_settings', 'Copywriter_models');
    register_setting('copywriter_settings', 'Copywriter_api_key');
    register_setting('copywriter_settings', 'Copywriter_daily_limit');
    register_setting('copywriter_settings', 'Copywriter_forbidden_words');
    register_setting('copywriter_settings', 'Copywriter_ad_content');
    register_setting('copywriter_settings', 'Copywriter_platforms');
    register_setting('copywriter_settings', 'Copywriter_themes');
    register_setting('copywriter_settings', 'Copywriter_example');
    register_setting('copywriter_settings', 'Copywriter_show_model_selector');

    add_settings_section(
        'copywriter_main_section',
        'API设置',
        null,
        'copywriter_settings'
    );

    add_settings_section(
        'copywriter_content_section',
        '内容设置',
        null,
        'copywriter_settings'
    );

    add_settings_field(
        'Copywriter_api_url',
        'API地址',
        'Copywriter_api_url_field',
        'copywriter_settings',
        'copywriter_main_section'
    );

    add_settings_field(
        'Copywriter_models',
        'AI模型',
        'Copywriter_models_field',
        'copywriter_settings',
        'copywriter_main_section'
    );

    add_settings_field(
        'Copywriter_api_key',
        'API密钥',
        'Copywriter_api_key_field',
        'copywriter_settings',
        'copywriter_main_section'
    );

    add_settings_field(
        'Copywriter_daily_limit',
        '每日使用限制',
        'Copywriter_daily_limit_field',
        'copywriter_settings',
        'copywriter_main_section'
    );

    add_settings_field(
        'Copywriter_show_model_selector',
        '前台显示AI模型选择',
        'Copywriter_show_model_selector_field',
        'copywriter_settings',
        'copywriter_main_section'
    );

    add_settings_field(
        'Copywriter_forbidden_words',
        '违规词',
        'Copywriter_forbidden_words_field',
        'copywriter_settings',
        'copywriter_content_section'
    );

    add_settings_field(
        'Copywriter_ad_content',
        '广告内容 (HTML)',
        'Copywriter_ad_content_field',
        'copywriter_settings',
        'copywriter_content_section'
    );

    add_settings_field(
        'Copywriter_platforms',
        '支持平台',
        'Copywriter_platforms_field',
        'copywriter_settings',
        'copywriter_content_section'
    );

    add_settings_field(
        'Copywriter_themes',
        '创作主题',
        'Copywriter_themes_field',
        'copywriter_settings',
        'copywriter_content_section'
    );

    add_settings_field(
        'Copywriter_example',
        '示例内容',
        'Copywriter_example_field',
        'copywriter_settings',
        'copywriter_content_section'
    );
}
add_action('admin_init', 'Copywriter_register_settings');

// 设置字段回调函数
function Copywriter_api_url_field() {
    $value = get_option('Copywriter_api_url', '');
    echo '<input type="text" name="Copywriter_api_url" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入API地址 (如 https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions)</p>';
}

function Copywriter_models_field() {
    $value = get_option('Copywriter_models', 'deepseek-chat');
    echo '<input type="text" name="Copywriter_models" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入AI模型，用逗号分隔 (如 deepseek-chat,deepseek-reasoner)</p>';
}

function Copywriter_api_key_field() {
    $value = get_option('Copywriter_api_key', '');
    echo '<input type="text" name="Copywriter_api_key" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入您的API密钥</p>';
}

function Copywriter_daily_limit_field() {
    $value = get_option('Copywriter_daily_limit', '10');
    echo '<input type="number" name="Copywriter_daily_limit" value="' . esc_attr($value) . '" min="1" />';
    echo '<p class="description">设置用户默认每日使用限制</p>';
}

function Copywriter_show_model_selector_field() {
    $value = get_option('Copywriter_show_model_selector', '1');
    echo '<select name="Copywriter_show_model_selector">';
    echo '<option value="1"' . selected($value, '1', false) . '>显示</option>';
    echo '<option value="0"' . selected($value, '0', false) . '>隐藏</option>';
    echo '</select>';
    echo '<p class="description">是否在前台显示AI模型选择器</p>';
}

function Copywriter_forbidden_words_field() {
    $value = get_option('Copywriter_forbidden_words', '');
    echo '<textarea name="Copywriter_forbidden_words" rows="5" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">输入违规词，用逗号分隔</p>';
}

function Copywriter_ad_content_field() {
    $value = get_option('Copywriter_ad_content', '');
    echo '<textarea name="Copywriter_ad_content" rows="5" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">输入广告内容 (支持HTML，图片建议尺寸：宽度不超过600px，高度不超过400px)</p>';
}

function Copywriter_platforms_field() {
    $value = get_option('Copywriter_platforms', 'Xiaohongshu,Douyin,Weibo');
    echo '<input type="text" name="Copywriter_platforms" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入支持平台，用逗号分隔</p>';
}

function Copywriter_themes_field() {
    $value = get_option('Copywriter_themes', "产品名称：\n品牌：\n功能效果：\n使用场景：\n使用方法：\n产品亮点：");
    echo '<textarea name="Copywriter_themes" rows="6" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">输入创作主题，每行一个</p>';
}

function Copywriter_example_field() {
    $value = get_option('Copywriter_example', "LiLi丝香均衡净颜小面膜\nLiLi\n保护皮肤，让皮肤更加滑嫩，赶走暗哑、粗糙、油腻\n非常适合出行，随时随地都能护肤。在大热天，出门一趟整个人仿佛在冒烟，每次暴晒回来\n敷个大概15分钟后洗掉。\n日本原装触感膜、鹅卵石质地，湿手也能轻易撕开。软糯麻薯质地的泥膜敷在脸上非常舒服，既不会拔干，也不会感觉闷闷的不透气。量也很足，每次涂完脸还有好多能涂在脖子上，洗完之后一整个舒服的状态，面膜泥很细腻，不会有刺痛感。");
    echo '<textarea name="Copywriter_example" rows="6" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">输入示例内容，每行一个，与主题顺序匹配</p>';
}

// 设置页面
function Copywriter_settings_page() {
    ?>
    <div class="wrap">
        <h1>文案助手设置</h1>
        <?php
        if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {
            echo '<div id="setting-saved-notice" class="notice notice-success is-dismissible"><p>设置保存成功！</p></div>';
            echo '<script>
                setTimeout(function() {
                    jQuery("#setting-saved-notice").fadeOut();
                }, 3000);
            </script>';
        }
        ?>
        <form method="post" action="options.php">
            <?php
            settings_fields('copywriter_settings');
            do_settings_sections('copywriter_settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// 用户记录页面
function Copywriter_user_records_page() {
    global $wpdb;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : (isset($_GET['user_id']) ? intval($_GET['user_id']) : 0);
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $per_page = 20;

    // 统计总使用次数和成功次数
    $total_usage = $wpdb->get_var("SELECT SUM(total_count) FROM {$wpdb->prefix}Copywriting_records");
    $total_success = $wpdb->get_var("SELECT SUM(success_count) FROM {$wpdb->prefix}Copywriting_records");

    // 统计今日总使用次数和成功次数
    $today = current_time('Y-m-d');
    $today_total_usage = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(total_count) FROM {$wpdb->prefix}Copywriting_records WHERE usage_date = %s",
        $today
    ));
    $today_total_success = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(success_count) FROM {$wpdb->prefix}Copywriting_records WHERE usage_date = %s",
        $today
    ));

    // 默认显示所有用户记录
    $total_all_records = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}Copywriting_themes");
    $all_records = $wpdb->get_results($wpdb->prepare(
        "SELECT t.*, r.usage_date, r.total_count, r.success_count, r.custom_limit 
        FROM {$wpdb->prefix}Copywriting_themes t 
        LEFT JOIN {$wpdb->prefix}Copywriting_records r ON t.record_id = r.id 
        ORDER BY t.created_at DESC 
        LIMIT %d OFFSET %d",
        $per_page,
        ($paged - 1) * $per_page
    ));

    ?>
    <div class="wrap">
        <h1>用户记录</h1>
        <h2>使用统计</h2>
        <p>网站总共尝试次数：<?php echo esc_html($total_usage ?: 0); ?> 次，成功次数：<?php echo esc_html($total_success ?: 0); ?> 次</p>
        <p>今日总共尝试次数：<?php echo esc_html($today_total_usage ?: 0); ?> 次，成功次数：<?php echo esc_html($today_total_success ?: 0); ?> 次</p>

        <h2>所有用户文案记录</h2>
        <?php
        if ($all_records) {
            echo '<table class="wp-list-table widefat fixed striped" id="all-records-table">';
            echo '<thead><tr><th>用户ID</th><th>日期</th><th>尝试次数</th><th>成功次数</th><th>自定义限制</th><th>AI模型</th><th>创作主题</th><th>创建时间</th><th>操作</th></tr></thead>';
            echo '<tbody>';
            foreach ($all_records as $record) {
                echo '<tr>';
                echo '<td>' . esc_html($record->user_id) . '</td>';
                echo '<td>' . esc_html($record->usage_date) . '</td>';
                echo '<td>' . esc_html($record->total_count) . '</td>';
                echo '<td>' . esc_html($record->success_count) . '</td>';
                echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
                echo '<td>' . esc_html($record->ai_model ?: '未记录') . '</td>';
                echo '<td>' . esc_html($record->theme_content ?: '无记录') . '</td>';
                echo '<td>' . esc_html($record->created_at) . '</td>';
                echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '" style="cursor: pointer;">删除</button></td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
            echo '<button id="delete-all-records" style="cursor: pointer;">删除全部记录</button>';

            // 分页
            $total_pages = ceil($total_all_records / $per_page);
            if ($total_pages > 1) {
                echo '<div id="all-pagination">';
                for ($i = 1; $i <= $total_pages; $i++) {
                    printf('<a href="#" class="page-number%s" data-page="%d">%d</a>', $i === $paged ? ' active' : '', $i, $i);
                }
                echo '</div>';
            }
        } else {
            echo '<p>暂无用户记录。</p>';
        }
        ?>
        
        <h2>查询指定用户</h2>
        <form method="post">
            <input type="number" name="user_id" placeholder="输入用户ID" value="<?php echo esc_attr($user_id); ?>">
            <input type="submit" value="搜索" class="button">
        </form>
        <?php
        if ($user_id) {
            // 指定用户的总使用次数和成功次数 - 按user_id汇总
            $user_total_usage = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(total_count) FROM {$wpdb->prefix}Copywriting_records WHERE user_id = %d",
                $user_id
            ));
            $user_total_success = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(success_count) FROM {$wpdb->prefix}Copywriting_records WHERE user_id = %d",
                $user_id
            ));

            // 指定用户今日使用次数和成功次数 - 按user_id汇总
            $user_today_data = $wpdb->get_row($wpdb->prepare(
                "SELECT SUM(total_count) as total_count, SUM(success_count) as success_count 
                FROM {$wpdb->prefix}Copywriting_records WHERE user_id = %d AND usage_date = %s",
                $user_id,
                $today
            ));
            $user_today_usage = $user_today_data ? $user_today_data->total_count : 0;
            $user_today_success = $user_today_data ? $user_today_data->success_count : 0;

            // 获取用户每日使用限制
            $user_daily_limit = $wpdb->get_var($wpdb->prepare(
                "SELECT custom_limit FROM {$wpdb->prefix}Copywriting_records WHERE user_id = %d AND custom_limit IS NOT NULL LIMIT 1",
                $user_id
            ));
            $default_limit = get_option('Copywriter_daily_limit', 10);
            $current_limit = $user_daily_limit ?: $default_limit;

            // 获取记录并分页
            $total_records = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}Copywriting_records WHERE user_id = %d",
                $user_id
            ));

            $records = $wpdb->get_results($wpdb->prepare(
                "SELECT r.*, t.theme_content, t.ai_model 
                FROM {$wpdb->prefix}Copywriting_records r 
                LEFT JOIN {$wpdb->prefix}Copywriting_themes t ON r.id = t.record_id 
                WHERE r.user_id = %d 
                ORDER BY r.usage_date DESC 
                LIMIT %d OFFSET %d",
                $user_id,
                $per_page,
                ($paged - 1) * $per_page
            ));

            echo '<h2>用户记录 (ID: ' . esc_html($user_id) . ')</h2>';
            echo '<p>用户总共尝试次数：' . esc_html($user_total_usage ?: 0) . ' 次，成功次数：' . esc_html($user_total_success ?: 0) . ' 次</p>';
            echo '<p>用户今日尝试次数：' . esc_html($user_today_usage ?: 0) . ' 次，成功次数：' . esc_html($user_today_success ?: 0) . ' 次</p>';
            echo '<p><strong>用户每日使用限制：' . esc_html($current_limit) . ' 次</strong> ' . ($user_daily_limit ? '(已自定义)' : '(使用默认)') . '</p>';

            if ($records) {
                echo '<table class="wp-list-table widefat fixed striped" id="user-records-table">';
                echo '<thead><tr><th>日期</th><th>尝试次数</th><th>成功次数</th><th>自定义限制</th><th>AI模型</th><th>创作主题</th><th>操作</th></tr></thead>';
                echo '<tbody>';
                foreach ($records as $record) {
                    echo '<tr>';
                    echo '<td>' . esc_html($record->usage_date) . '</td>';
                    echo '<td>' . esc_html($record->total_count) . '</td>';
                    echo '<td>' . esc_html($record->success_count) . '</td>';
                    echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
                    echo '<td>' . esc_html($record->ai_model ?: '未记录') . '</td>';
                    echo '<td>' . esc_html($record->theme_content ?: '无记录') . '</td>';
                    echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '" style="cursor: pointer;">删除</button></td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
                echo '<button id="delete-all-user-records" data-user-id="' . esc_attr($user_id) . '" style="cursor: pointer;">删除全部用户记录</button>';

                // 分页
                $total_pages = ceil($total_records / $per_page);
                if ($total_pages > 1) {
                    echo '<div id="pagination">';
                    for ($i = 1; $i <= $total_pages; $i++) {
                        printf('<a href="#" class="page-number%s" data-page="%d">%d</a>', $i === $paged ? ' active' : '', $i, $i);
                    }
                    echo '</div>';
                }
            } else {
                echo '<p>未找到该用户记录。</p>';
            }
            
            // 自定义限制表单
            ?>
            <form method="post">
                <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="number" name="custom_limit" placeholder="自定义每日限制">
                <input type="submit" name="set_limit" value="设置自定义限制" class="button">
                <input type="submit" name="reset_limit" value="恢复默认" class="button">
            </form>
            <?php
        }
        ?>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $('#pagination .page-number').on('click', function(e) {
            e.preventDefault();
            if (!$(this).hasClass('active')) {
                var user_id = $('input[name="user_id"]').val();
                var page = $(this).data('page');
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'copywriter_load_user_records',
                        user_id: user_id,
                        paged: page
                    },
                    success: function(response) {
                        $('#user-records-table tbody').html(response.data.records);
                        $('#pagination .page-number').removeClass('active');
                        $('#pagination .page-number[data-page="' + page + '"]').addClass('active');
                    }
                });
            }
        });

        $('#all-pagination .page-number').on('click', function(e) {
            e.preventDefault();
            if (!$(this).hasClass('active')) {
                var page = $(this).data('page');
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'copywriter_load_all_records',
                        paged: page
                    },
                    success: function(response) {
                        $('#all-records-table tbody').html(response.data.records);
                        $('#all-pagination .page-number').removeClass('active');
                        $('#all-pagination .page-number[data-page="' + page + '"]').addClass('active');
                    }
                });
            }
        });

        $('.delete-record').on('click', function(e) {
            e.preventDefault();
            var theme_id = $(this).data('id');
            if (confirm('确定删除此记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'copywriter_delete_record',
                        theme_id: theme_id
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#all-records-table tr').each(function() {
                                if ($(this).find('.delete-record').data('id') === theme_id) {
                                    $(this).remove();
                                }
                            });
                            $('#user-records-table tr').each(function() {
                                if ($(this).find('.delete-record').data('id') === theme_id) {
                                    $(this).remove();
                                }
                            });
                        }
                    }
                });
            }
        });

        $('#delete-all-records').on('click', function(e) {
            e.preventDefault();
            if (confirm('确定删除所有记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'copywriter_delete_all_records'
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#all-records-table tbody').empty();
                        }
                    }
                });
            }
        });

        $('#delete-all-user-records').on('click', function(e) {
            e.preventDefault();
            var user_id = $(this).data('user-id');
            if (confirm('确定删除该用户的所有记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'copywriter_delete_user_records',
                        user_id: user_id
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#user-records-table tbody').empty();
                        }
                    }
                });
            }
        });
    });
    </script>
    <?php
}

// AJAX 获取用户记录
add_action('wp_ajax_copywriter_load_user_records', function() {
    global $wpdb;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $paged = isset($_POST['paged']) ? max(1, intval($_POST['paged'])) : 1;
    $per_page = 20;

    if ($user_id) {
        $records = $wpdb->get_results($wpdb->prepare(
            "SELECT r.*, t.theme_content, t.ai_model 
            FROM {$wpdb->prefix}Copywriting_records r 
            LEFT JOIN {$wpdb->prefix}Copywriting_themes t ON r.id = t.record_id 
            WHERE r.user_id = %d 
            ORDER BY r.usage_date DESC 
            LIMIT %d OFFSET %d",
            $user_id,
            $per_page,
            ($paged - 1) * $per_page
        ));

        ob_start();
        foreach ($records as $record) {
            echo '<tr>';
            echo '<td>' . esc_html($record->usage_date) . '</td>';
            echo '<td>' . esc_html($record->total_count) . '</td>';
            echo '<td>' . esc_html($record->success_count) . '</td>';
            echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
            echo '<td>' . esc_html($record->ai_model ?: '未记录') . '</td>';
            echo '<td>' . esc_html($record->theme_content ?: '无记录') . '</td>';
            echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '" style="cursor: pointer;">删除</button></td>';
            echo '</tr>';
        }
        $html = ob_get_clean();

        wp_send_json_success(array('records' => $html));
    }
    wp_die();
});

// AJAX 获取所有用户记录
add_action('wp_ajax_copywriter_load_all_records', function() {
    global $wpdb;
    $paged = isset($_POST['paged']) ? max(1, intval($_POST['paged'])) : 1;
    $per_page = 20;

    $records = $wpdb->get_results($wpdb->prepare(
        "SELECT t.*, r.usage_date, r.total_count, r.success_count, r.custom_limit 
        FROM {$wpdb->prefix}Copywriting_themes t 
        LEFT JOIN {$wpdb->prefix}Copywriting_records r ON t.record_id = r.id 
        ORDER BY t.created_at DESC 
        LIMIT %d OFFSET %d",
        $per_page,
        ($paged - 1) * $per_page
    ));

    ob_start();
    foreach ($records as $record) {
        echo '<tr>';
        echo '<td>' . esc_html($record->user_id) . '</td>';
        echo '<td>' . esc_html($record->usage_date) . '</td>';
        echo '<td>' . esc_html($record->total_count) . '</td>';
        echo '<td>' . esc_html($record->success_count) . '</td>';
        echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
        echo '<td>' . esc_html($record->ai_model ?: '未记录') . '</td>';
        echo '<td>' . esc_html($record->theme_content ?: '无记录') . '</td>';
        echo '<td>' . esc_html($record->created_at) . '</td>';
        echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '" style="cursor: pointer;">删除</button></td>';
        echo '</tr>';
    }
    $html = ob_get_clean();

    wp_send_json_success(array('records' => $html));
    wp_die();
});

// AJAX 删除单条记录
add_action('wp_ajax_copywriter_delete_record', function() {
    global $wpdb;
    $theme_id = isset($_POST['theme_id']) ? intval($_POST['theme_id']) : 0;
    if ($theme_id) {
        $wpdb->delete($wpdb->prefix . 'Copywriting_themes', array('id' => $theme_id));
        wp_send_json_success();
    }
    wp_send_json_error();
});

// AJAX 删除所有记录
add_action('wp_ajax_copywriter_delete_all_records', function() {
    global $wpdb;
    $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}Copywriting_themes");
    $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}Copywriting_records");
    $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}Copywriting_history");
    wp_send_json_success();
});

// AJAX 删除用户所有记录
add_action('wp_ajax_copywriter_delete_user_records', function() {
    global $wpdb;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    if ($user_id) {
        $record_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}Copywriting_records WHERE user_id = %d",
            $user_id
        ));
        if ($record_ids) {
            $wpdb->delete($wpdb->prefix . 'Copywriting_themes', array('record_id' => $record_ids));
            $wpdb->delete($wpdb->prefix . 'Copywriting_records', array('user_id' => $user_id));
            $wpdb->delete($wpdb->prefix . 'Copywriting_history', array('user_id' => $user_id));
        }
        wp_send_json_success();
    }
    wp_send_json_error();
});

// 前台短代码 - Bug 1 修复: 默认只显示生成文案按钮
function Copywriter_shortcode() {
    global $wpdb;
    $ad_content = get_option('Copywriter_ad_content', '');

    // Guest user view
    if (!is_user_logged_in()) {
        ob_start();
        ?>
        <div class="Copywriter_container">
            <div class="Copywriter_page_title">AI智能文案助手</div>
            <div class="Copywriter_login_notice">
                请先登录才能使用AI文案助手。
                <button class="Copywriter_quick_login_button">快速登录</button>
            </div>
            <?php if ($ad_content): ?>
            <div class="Copywriter_ad">
                <?php echo wp_kses_post($ad_content); ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    // 已登录用户的界面
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = get_option('Copywriter_daily_limit', 10);
    
    // 获取记录 - 按user_id汇总所有设备的使用次数
    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT SUM(total_count) as total_count, SUM(success_count) as success_count, 
         MAX(custom_limit) as custom_limit FROM {$wpdb->prefix}Copywriting_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));
    
    $success_count = $usage_data ? $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? $usage_data->custom_limit : $default_limit;
    $remaining_usage = max(0, $user_limit - $success_count);
    
    $models = array_map('trim', explode(',', get_option('Copywriter_models', 'deepseek-chat')));
    $platforms = array_map('trim', explode(',', get_option('Copywriter_platforms', 'Xiaohongshu,Douyin,Weibo')));
    $themes = get_option('Copywriter_themes', "产品名称：\n品牌：\n功能效果：\n使用场景：\n使用方法：\n产品亮点：");
    $example = get_option('Copywriter_example', '');
    $show_model_selector = get_option('Copywriter_show_model_selector', '1');

    ob_start();
    ?>
    <div class="Copywriter_container">
        <div class="Copywriter_page_title">AI智能文案生成助手</div>
        
        <!-- 功能切换区域 -->
        <div class="Copywriter_mode_switcher">
            <button class="Copywriter_mode_button active" data-mode="generate">生成文案</button>
            <button class="Copywriter_mode_button" data-mode="optimize">优化文案</button>
        </div>

        <!-- 上半部分：输入和配置 -->
        <div class="Copywriter_top_section">
            <!-- 左侧：输入区域 -->
            <div class="Copywriter_input_section">
                <!-- 生成文案模式 -->
                <div class="Copywriter_mode_content" id="generate_mode">
                    <div class="Copywriter_section_title">创作主题</div>
                    <div class="Copywriter_input_wrapper">
                        <?php if ($example): ?>
                        <button class="Copywriter_example_button" title="填入示例">
                            <span class="dashicons dashicons-admin-page"></span> 填入示例
                        </button>
                        <?php endif; ?>
                        <textarea id="Copywriter_input" name="Copywriter_input" placeholder="<?php echo esc_attr(str_replace("\n", "\n", $themes)); ?>"><?php echo esc_textarea($themes); ?></textarea>
                    </div>
                </div>

                <!-- 优化文案模式 -->
                <div class="Copywriter_mode_content" id="optimize_mode" style="display: none;">
                    <div class="Copywriter_section_title">现有文案</div>
                    <div class="Copywriter_input_wrapper">
                        <textarea id="Copywriter_optimize_input" name="Copywriter_optimize_input" placeholder="请输入需要优化的现有文案内容..."></textarea>
                    </div>
                </div>
            </div>

            <!-- 右侧：配置区域 -->
            <div class="Copywriter_config_section">
                <div class="Copywriter_section_title">配置选项</div>
                
                <?php if ($show_model_selector == '1' && $models && count($models) > 1): ?>
                <div class="Copywriter_model_wrapper">
                    <label for="Copywriter_model">AI模型选择</label>
                    <select id="Copywriter_model" name="Copywriter_model">
                        <?php foreach ($models as $model): ?>
                            <option value="<?php echo esc_attr($model); ?>"><?php echo esc_html($model); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                
                <?php if ($platforms): ?>
                <div class="Copywriter_platforms">
                    <label>文案平台 (可多选)</label>
                    <div class="Copywriter_platform_buttons">
                        <?php foreach ($platforms as $platform): ?>
                            <button class="Copywriter_platform_button" data-platform="<?php echo esc_attr($platform); ?>">
                                <?php echo esc_html($platform); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="Copywriter_action_buttons">
                    <?php if ($remaining_usage > 0): ?>
                    <!-- Bug 1 修复: 默认只显示生成文案按钮，优化按钮完全隐藏 -->
                    <button class="Copywriter_generate_button" id="generate_btn">生成文案</button>
                    <button class="Copywriter_optimize_button" id="optimize_btn" style="display: none !important;">优化文案</button>
                    <?php endif; ?>
                </div>

                <div class="Copywriter_usage">
                    <?php echo $remaining_usage > 0 ? esc_html('今日可用次数：' . $remaining_usage . '/' . $user_limit) : '今日已经使用完，请明天再来'; ?>
                </div>
            </div>
        </div>
        
        <!-- 下半部分：结果区域 -->
        <div class="Copywriter_results_section">
            <div class="Copywriter_section_title">结果</div>
            <div class="Copywriter_results_container" id="results_container">
                <div class="Copywriter_result_placeholder">AI文案将显示在这里...</div>
            </div>
            <div class="Copywriter_result_actions" style="display: none;">
                <button class="Copywriter_clear_button">清空结果</button>
            </div>
        </div>

        <!-- 历史记录区域 -->
        <div class="Copywriter_history_section">
            <div class="Copywriter_section_title">历史记录</div>
            <div class="Copywriter_history_container" id="history_container">
                <div class="Copywriter_history_placeholder">加载历史记录中...</div>
            </div>
            <div class="Copywriter_history_pagination" id="history_pagination"></div>
        </div>
        
        <?php if ($ad_content): ?>
        <div class="Copywriter_ad">
            <?php echo wp_kses_post($ad_content); ?>
        </div>
        <?php endif; ?>

        <!-- 自定义提示框 -->
        <div class="Copywriter_custom_modal" id="custom_modal">
            <div class="Copywriter_modal_content">
                <div class="Copywriter_modal_message" id="modal_message"></div>
                <div class="Copywriter_modal_buttons">
                    <button class="Copywriter_modal_confirm" id="modal_confirm">确定</button>
                    <button class="Copywriter_modal_cancel" id="modal_cancel">取消</button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        var Copywriter_example_data = <?php echo json_encode($example ? str_replace("\n", "\n", $example) : ''); ?>;
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('copywriting_assistant_shortcode', 'Copywriter_shortcode');

// 处理自定义限制更新
add_action('admin_post', function() {
    if (isset($_POST['user_id']) && (isset($_POST['set_limit']) || isset($_POST['reset_limit']))) {
        global $wpdb;
        $user_id = intval($_POST['user_id']);
        
        if (isset($_POST['set_limit']) && !empty($_POST['custom_limit'])) {
            $custom_limit = intval($_POST['custom_limit']);
            // 更新该用户的所有记录
            $wpdb->update(
                $wpdb->prefix . 'Copywriting_records',
                array('custom_limit' => $custom_limit),
                array('user_id' => $user_id)
            );
        } elseif (isset($_POST['reset_limit'])) {
            // 恢复默认限制
            $wpdb->update(
                $wpdb->prefix . 'Copywriting_records',
                array('custom_limit' => null),
                array('user_id' => $user_id)
            );
        }
        
        wp_redirect(admin_url('admin.php?page=copywriting-user-records&user_id=' . $user_id));
        exit;
    }
});

// 增强 REST API 权限检查
add_filter('rest_authentication_errors', function($result) {
    if (is_wp_error($result)) {
        return $result;
    }
    if (!is_user_logged_in()) {
        return new WP_Error(
            'rest_not_logged_in',
            '您必须登录才能访问此资源。',
            array('status' => 401)
        );
    }
    return $result;
});
?>