jQuery(document).ready(function($) {
    let selectedPlatforms = [];
    let currentMode = 'generate';
    let currentHistoryPage = 1;

    // Bug 1 修复: 模式切换功能 - 确保按钮正确显示/隐藏，不使用JS控制显示
    $('.Copywriter_mode_button').click(function() {
        const mode = $(this).data('mode');
        $('.Copywriter_mode_button').removeClass('active');
        $(this).addClass('active');
        
        $('.Copywriter_mode_content').hide();
        $('#' + mode + '_mode').show();
        
        // Bug 1 修复: 根据模式显示对应按钮，但不覆盖PHP的默认隐藏设置
        if (mode === 'generate') {
            $('#generate_btn').show();
            $('#optimize_btn').hide();
            currentMode = 'generate';
        } else {
            $('#generate_btn').hide();
            $('#optimize_btn').show();
            currentMode = 'optimize';
        }
    });

    // 平台按钮处理 - 支持多选
    $('.Copywriter_platform_button').click(function() {
        const platform = $(this).data('platform');
        
        if ($(this).hasClass('active')) {
            // 取消选择
            $(this).removeClass('active');
            selectedPlatforms = selectedPlatforms.filter(p => p !== platform);
        } else {
            // 选择
            $(this).addClass('active');
            selectedPlatforms.push(platform);
        }
    });

    // 示例按钮
    $('.Copywriter_example_button').click(function(e) {
        e.preventDefault();
        var $textarea = $('#Copywriter_input');
        var exampleLines = Copywriter_example_data.split('\n');
        var newValue = exampleLines.join('\n');
        $textarea.val(newValue);
    });

    // 生成按钮
    $('.Copywriter_generate_button').click(function(e) {
        e.preventDefault();
        handleGenerate('generate');
    });

    // 优化按钮
    $('.Copywriter_optimize_button').click(function(e) {
        e.preventDefault();
        handleGenerate('optimize');
    });

    // 统一处理生成和优化
    function handleGenerate(operationType) {
        const $resultsContainer = $('#results_container');
        const inputData = operationType === 'generate' ? 
            $('#Copywriter_input').val() : 
            $('#Copywriter_optimize_input').val();
        const $generateButton = operationType === 'generate' ? 
            $('.Copywriter_generate_button') : 
            $('.Copywriter_optimize_button');

        // 前端验证违规词
        const forbiddenWords = CopywriterData.forbidden_words || [];
        let foundForbiddenWord = null;
        if (forbiddenWords.length > 0) {
            forbiddenWords.forEach(function(word) {
                if (inputData.toLowerCase().indexOf(word.toLowerCase()) !== -1) {
                    foundForbiddenWord = word;
                }
            });
        }

        if (foundForbiddenWord) {
            showCustomAlert('输入内容包含违规词"' + foundForbiddenWord + '"，请重新编辑内容');
            return;
        }

        if (!inputData.trim()) {
            showCustomAlert('请输入' + (operationType === 'generate' ? '创作主题' : '需要优化的文案'));
            return;
        }

        if (selectedPlatforms.length === 0) {
            showCustomAlert('请至少选择一个平台');
            return;
        }

        // 显示加载中状态
        $resultsContainer.html('<div class="Copywriter_loading">正在' + (operationType === 'generate' ? '生成' : '优化') + '中...</div>');
        
        // 确保用户登录
        if (!CopywriterData.nonce) {
            showCustomAlert('请先登录以使用文案助手');
            return;
        }

        const data = {
            model: $('#Copywriter_model').val() || 'deepseek-chat',
            data: inputData,
            platforms: selectedPlatforms,
            operation_type: operationType
        };

        // 禁用按钮，防止重复点击
        $generateButton.prop('disabled', true);

        // 使用 fetch 发起 REST API 请求
        fetch(CopywriterData.rest_url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': CopywriterData.nonce,
                'Accept': 'text/event-stream'
            },
            body: JSON.stringify(data)
        }).then(response => {
            if (!response.ok) {
                return response.json().then(error => {
                    throw new Error(error.message || '未知错误');
                });
            }

            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let done = false;
            let hasContent = false;
            let fullContent = '';

            function readStream() {
                reader.read().then(({ done: streamDone, value }) => {
                    if (streamDone) {
                        done = true;
                        if (hasContent) {
                            updateUsageCount();
                            loadHistory();
                            processPlatformResults(fullContent);
                            $('.Copywriter_result_actions').show();
                        } else {
                            showCustomAlert('生成失败，未收到有效内容');
                        }
                        $generateButton.prop('disabled', false);
                        return;
                    }

                    const chunk = decoder.decode(value, { stream: true });
                    const lines = chunk.split('\n');
                    lines.forEach(line => {
                        if (line.trim().startsWith('data: ')) {
                            const jsonData = line.trim().substring(6);
                            if (jsonData === '[DONE]') {
                                done = true;
                                if (hasContent) {
                                    updateUsageCount();
                                    loadHistory();
                                    processPlatformResults(fullContent);
                                    $('.Copywriter_result_actions').show();
                                } else {
                                    showCustomAlert('生成失败，未收到有效内容');
                                }
                                $generateButton.prop('disabled', false);
                                return;
                            }

                            try {
                                const data = JSON.parse(jsonData);
                                if (data.error) {
                                    showCustomAlert(data.error);
                                    $generateButton.prop('disabled', false);
                                    return;
                                }
                                if ($resultsContainer.find('.Copywriter_loading').length) {
                                    $resultsContainer.empty();
                                }
                                if (data.content) {
                                    hasContent = true;
                                    fullContent += data.content;
                                    if ($resultsContainer.find('.Copywriter_streaming_content').length === 0) {
                                        $resultsContainer.append('<div class="Copywriter_streaming_content"></div>');
                                    }
                                    $resultsContainer.find('.Copywriter_streaming_content').append(data.content);
                                }
                            } catch (e) {
                                console.error('解析流数据出错:', e, ' - 原始数据:', jsonData);
                                showCustomAlert('生成过程中发生错误，请检查日志');
                                $generateButton.prop('disabled', false);
                            }
                        }
                    });

                    if (!done) {
                        readStream();
                    }
                }).catch(error => {
                    console.error('流读取失败:', error);
                    showCustomAlert('生成过程中发生错误，请检查日志');
                    $generateButton.prop('disabled', false);
                });
            }

            readStream();
        }).catch(error => {
            console.error('API 请求失败:', error);
            showCustomAlert(error.message);
            $generateButton.prop('disabled', false);
        });
    }

    // 处理多平台结果分离
    function processPlatformResults(content) {
        const $resultsContainer = $('#results_container');
        
        if (selectedPlatforms.length === 1) {
            const platformName = selectedPlatforms[0];
            const resultHtml = `
                <div class="Copywriter_platform_result">
                    <div class="Copywriter_platform_header">
                        <span class="Copywriter_platform_name">${platformName}</span>
                        <button class="Copywriter_copy_button" data-content="${escapeHtml(content)}">复制</button>
                    </div>
                    <div class="Copywriter_result_content">${renderMarkdown(content)}</div>
                </div>
            `;
            $resultsContainer.html(resultHtml);
        } else {
            const platformResults = separatePlatformContent(content, selectedPlatforms);
            let resultsHtml = '<div class="Copywriter_multi_platform_results">';
            
            platformResults.forEach(result => {
                resultsHtml += `
                    <div class="Copywriter_platform_result">
                        <div class="Copywriter_platform_header">
                            <span class="Copywriter_platform_name">${result.platform}</span>
                            <button class="Copywriter_copy_button" data-content="${escapeHtml(result.content)}">复制</button>
                        </div>
                        <div class="Copywriter_result_content">${renderMarkdown(result.content)}</div>
                    </div>
                `;
            });
            
            resultsHtml += '</div>';
            $resultsContainer.html(resultsHtml);
        }
    }

    // 分离平台内容
    function separatePlatformContent(content, platforms) {
        const results = [];
        
        platforms.forEach(platform => {
            const patterns = [
                new RegExp(`【${platform}】([\\s\\S]*?)(?=【|$)`, 'i'),
                new RegExp(`\\*\\*${platform}\\*\\*([\\s\\S]*?)(?=\\*\\*|$)`, 'i'),
                new RegExp(`## ${platform}([\\s\\S]*?)(?=##|$)`, 'i'),
                new RegExp(`${platform}：([\\s\\S]*?)(?=${platforms.join('|')}：|$)`, 'i')
            ];
            
            let platformContent = '';
            for (let pattern of patterns) {
                const match = content.match(pattern);
                if (match && match[1]) {
                    platformContent = match[1].trim();
                    break;
                }
            }
            
            if (!platformContent && platforms.length === 1) {
                platformContent = content;
            }
            
            if (!platformContent) {
                platformContent = content;
            }
            
            results.push({
                platform: platform,
                content: platformContent
            });
        });
        
        return results;
    }

    // Markdown 渲染
    function renderMarkdown(content) {
        if (typeof marked !== 'undefined') {
            return marked.parse(content);
        }
        return content
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\n/g, '<br>');
    }

    // HTML 转义
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // 复制按钮处理
    $(document).on('click', '.Copywriter_copy_button', function(e) {
        e.preventDefault();
        const content = $(this).data('content');
        const $button = $(this);
        const originalText = $button.text();
        
        const $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val(content).select();
        
        try {
            document.execCommand('copy');
            $button.text('已复制');
            setTimeout(function() {
                $button.text(originalText);
            }, 2000);
        } catch (err) {
            console.error('复制失败:', err);
            $button.text('复制失败');
            setTimeout(function() {
                $button.text(originalText);
            }, 2000);
        }
        
        $temp.remove();
    });

    // 清空按钮
    $('.Copywriter_clear_button').click(function(e) {
        e.preventDefault();
        $('#results_container').html('<div class="Copywriter_result_placeholder">AI生成文案将显示在这里...</div>');
        $('.Copywriter_result_actions').hide();
    });

    // 快速登录按钮
    $('.Copywriter_quick_login_button').on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = wp.ajax.settings.url.replace('/wp-admin/admin-ajax.php', '/wp-login.php');
        }
    });

    // 更新使用次数显示
    function updateUsageCount() {
        $.ajax({
            url: CopywriterData.rest_url.replace('/generate', '/usage'),
            method: 'GET',
            headers: {
                'X-WP-Nonce': CopywriterData.nonce
            },
            success: function(response) {
                if (response.remaining > 0) {
                    $('.Copywriter_usage').text('今日可用次数：' + response.remaining + '/' + response.limit);
                    // Bug 1 修复: 不通过JS控制按钮显示，保持PHP的控制
                    if (currentMode === 'generate') {
                        $('.Copywriter_generate_button').show();
                    } else {
                        $('.Copywriter_optimize_button').show();
                    }
                } else {
                    $('.Copywriter_usage').text('今日已经使用完，请明天再来');
                    $('.Copywriter_generate_button, .Copywriter_optimize_button').hide();
                }
            },
            error: function() {
                $('.Copywriter_usage').text('今日可用次数：无法加载');
            }
        });
    }

    // 加载历史记录
    function loadHistory(page = 1) {
        currentHistoryPage = page;
        
        $.ajax({
            url: CopywriterData.history_url + '?page=' + page,
            method: 'GET',
            headers: {
                'X-WP-Nonce': CopywriterData.nonce
            },
            success: function(response) {
                displayHistory(response);
            },
            error: function() {
                $('#history_container').html('<div class="Copywriter_history_error">加载历史记录失败</div>');
            }
        });
    }

    // 显示历史记录
    function displayHistory(data) {
        const $container = $('#history_container');
        
        if (!data.history || data.history.length === 0) {
            $container.html('<div class="Copywriter_history_empty">暂无历史记录</div>');
            $('#history_pagination').empty();
            return;
        }

        let historyHtml = '<div class="Copywriter_history_grid">';
        data.history.forEach(item => {
            const platforms = item.platforms ? item.platforms.split(',').join('、') : '未知平台';
            const operationType = item.operation_type === 'optimize' ? '优化' : '生成';
            const shortInput = item.input_content.length > 30 ? 
                item.input_content.substring(0, 30) + '...' : 
                item.input_content;
            const shortOutput = item.output_content.length > 50 ? 
                item.output_content.substring(0, 50) + '...' : 
                item.output_content;

            historyHtml += `
                <div class="Copywriter_history_card" data-id="${item.id}">
                    <div class="Copywriter_history_card_header">
                        <span class="Copywriter_history_type">${operationType}</span>
                        <span class="Copywriter_history_time">${formatDateTime(item.created_at)}</span>
                    </div>
                    <div class="Copywriter_history_card_content">
                        <div class="Copywriter_history_platforms">${platforms}</div>
                        <div class="Copywriter_history_preview">
                            <div class="Copywriter_history_input_preview">${escapeHtml(shortInput)}</div>
                            <div class="Copywriter_history_output_preview">${escapeHtml(shortOutput)}</div>
                        </div>
                    </div>
                    <div class="Copywriter_history_card_actions">
                        <button class="Copywriter_history_expand" data-expanded="false">展开</button>
                        <button class="Copywriter_history_copy" data-content="${escapeHtml(item.output_content)}">复制</button>
                        <button class="Copywriter_history_delete" data-id="${item.id}">删除</button>
                    </div>
                    <div class="Copywriter_history_full_content" style="display: none;">
                        <div class="Copywriter_history_input_full">
                            <strong>输入：</strong>${escapeHtml(item.input_content)}
                        </div>
                        <div class="Copywriter_history_output_full">
                            <strong>输出：</strong>${renderMarkdown(item.output_content)}
                        </div>
                    </div>
                </div>
            `;
        });
        historyHtml += '</div>';

        $container.html(historyHtml);

        if (data.total_pages > 1) {
            let paginationHtml = '';
            for (let i = 1; i <= data.total_pages; i++) {
                paginationHtml += `<button class="Copywriter_history_page ${i === data.page ? 'active' : ''}" data-page="${i}">${i}</button>`;
            }
            $('#history_pagination').html(paginationHtml);
        } else {
            $('#history_pagination').empty();
        }
    }

    // 历史记录展开/收起
    $(document).on('click', '.Copywriter_history_expand', function() {
        const $card = $(this).closest('.Copywriter_history_card');
        const $fullContent = $card.find('.Copywriter_history_full_content');
        const $preview = $card.find('.Copywriter_history_preview');
        const isExpanded = $(this).data('expanded');
        
        if (isExpanded) {
            $fullContent.hide();
            $preview.show();
            $(this).text('展开').data('expanded', false);
            $card.removeClass('expanded');
        } else {
            $fullContent.show();
            $preview.hide();
            $(this).text('收起').data('expanded', true);
            $card.addClass('expanded');
        }
    });

    // 历史记录复制
    $(document).on('click', '.Copywriter_history_copy', function() {
        const content = $(this).data('content');
        const $button = $(this);
        const originalText = $button.text();
        
        const $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val(content).select();
        
        try {
            document.execCommand('copy');
            $button.text('已复制');
            setTimeout(function() {
                $button.text(originalText);
            }, 2000);
        } catch (err) {
            console.error('复制失败:', err);
        }
        
        $temp.remove();
    });

    // 历史记录删除
    $(document).on('click', '.Copywriter_history_delete', function() {
        const historyId = $(this).data('id');
        const $card = $(this).closest('.Copywriter_history_card');
        
        showCustomConfirm('确定要删除这条历史记录吗？', function() {
            $.ajax({
                url: CopywriterData.history_url + '/' + historyId,
                method: 'DELETE',
                headers: {
                    'X-WP-Nonce': CopywriterData.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $card.fadeOut(300, function() {
                            $(this).remove();
                            if ($('#history_container .Copywriter_history_card').length === 0) {
                                loadHistory(Math.max(1, currentHistoryPage - 1));
                            }
                        });
                    } else {
                        showCustomAlert('删除失败，请重试');
                    }
                },
                error: function() {
                    showCustomAlert('删除失败，请重试');
                }
            });
        });
    });

    // 历史记录分页
    $(document).on('click', '.Copywriter_history_page', function() {
        const page = $(this).data('page');
        if (!$(this).hasClass('active')) {
            loadHistory(page);
        }
    });

    // 自定义提示框
    function showCustomAlert(message) {
        $('#modal_message').text(message);
        $('#modal_confirm').show().text('确定');
        $('#modal_cancel').hide();
        $('#custom_modal').css('display', 'flex').hide().fadeIn(300);
    }

    function showCustomConfirm(message, callback) {
        $('#modal_message').text(message);
        $('#modal_confirm').show().text('确定');
        $('#modal_cancel').show();
        $('#custom_modal').css('display', 'flex').hide().fadeIn(300);
        
        $('#modal_confirm').off('click').on('click', function() {
            $('#custom_modal').fadeOut(300);
            if (callback) callback();
        });
    }

    // 模态框关闭
    $('#modal_confirm, #modal_cancel').click(function() {
        $('#custom_modal').fadeOut(300);
    });

    $(document).on('click', '#custom_modal', function(e) {
        if (e.target === this) {
            $('#custom_modal').fadeOut(300);
        }
    });

    // 格式化日期时间
    function formatDateTime(dateTimeString) {
        const date = new Date(dateTimeString);
        return date.toLocaleString('zh-CN', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    // 页面加载时初始化
    updateUsageCount();
    loadHistory();
    
    // 默认选择第一个平台
    if ($('.Copywriter_platform_button').length > 0) {
        $('.Copywriter_platform_button').first().click();
    }
});