<?php
/*
 * Plugin Name: 小半软件下载
 * Description: 用于添加和显示软件下载信息，适合软件站使用。
 * Plugin URI: https://www.jingxialai.com/4865.html
 * Version: 1.3
 * Author: Summer
 * License: GPL License
 * Author URI: https://www.jingxialai.com/
*/

// 创建插件设置菜单
function wp_download_plugin_menu() {
    add_options_page('小半软件下载插件设置', '软件下载设置', 'manage_options', 'wp-download-plugin', 'wp_download_plugin_settings_page');
}
add_action('admin_menu', 'wp_download_plugin_menu');

// 在插件列表页面添加设置链接
function wp_download_plugin_settings_link($links) {
    $settings_link = '<a href="/wp-admin/options-general.php?page=wp-download-plugin">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wp_download_plugin_settings_link');

// 插件设置页面
function wp_download_plugin_settings_page() {
    ?>
    <div class="wrap">
        <h1>小半软件下载插件设置</h1>
        <form method="post" action="options.php">
            <?php settings_fields('wp_download_plugin_options_group'); ?>
            <?php do_settings_sections('wp-download-plugin'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">隐藏下载按钮</th>
                    <td>
                        <input type="checkbox" name="wp_download_plugin_hide_all" <?php checked(get_option('wp_download_plugin_hide_all'), 'on');?> />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">软件框自定义内容</th>
                    <td>
                        <textarea name="wp_download_plugin_software_copyright" rows="5" cols="50"><?php echo esc_textarea(get_option('wp_download_plugin_software_copyright')); ?></textarea>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">文章中的下载自定义内容</th>
                    <td>
                        <textarea name="wp_download_plugin_website_intro" rows="5" cols="50"><?php echo esc_textarea(get_option('wp_download_plugin_website_intro')); ?></textarea>
                    </td>
                </tr>
            </table>
            <?php submit_button('保存更改', 'primary', 'submit', true, ['aria-label' => '保存更改并应用设置']); ?>
<p class="description">自定义内容可以不添加，软件框适合写点版权说明，文章中这里可以挂点广告内容。<br>支持HTML代码，如果文章中软件板块要放图片，高度不要超过80，不然不好看。<br>
如果要在小工具显示软件下载按钮，请到后台小工具去添加。</p>

        </form>
    </div>
    <?php
}

// 注册设置
function wp_download_plugin_register_settings() {
    register_setting('wp_download_plugin_options_group', 'wp_download_plugin_hide_all'); // 隐藏下载按钮
    register_setting('wp_download_plugin_options_group', 'wp_download_plugin_software_copyright', 'wp_kses_post'); // 允许HTML
    register_setting('wp_download_plugin_options_group', 'wp_download_plugin_website_intro', 'wp_kses_post'); // 允许HTML
}
add_action('admin_init', 'wp_download_plugin_register_settings');

//编辑器下面的软件信息添加
function wp_download_plugin_download_area() {
    global $post;
    $downloads = get_post_meta($post->ID, 'downloads', true);
    ?>
    <div id="wp-download-plugin">
        <h3>软件下载信息(版本号必填)</h3>
        <div id="download-entries">
            <?php if ($downloads) : ?>
                <?php foreach ($downloads as $key => $download) : ?>
                    <div class="download-entry">
                        <label>版本*：<input type="text" name="download_version[]" value="<?php echo esc_attr($download['version']); ?>"></label>
                        <label>环境：<input type="text" name="download_environment[]" value="<?php echo esc_attr($download['environment']); ?>"></label>
                        <label>语言：<input type="text" name="download_language[]" value="<?php echo esc_attr($download['language']); ?>"></label>
                        <label>日期：<input type="date" name="download_date[]" value="<?php echo esc_attr($download['date']); ?>"></label>
                        <label>大小：<input type="text" name="download_size[]" value="<?php echo esc_attr($download['size']); ?>"></label>
                        <label>网盘：<input type="text" name="download_drive[]" value="<?php echo esc_attr($download['drive']); ?>"></label>
                        <label>密码：<input type="text" name="download_password[]" value="<?php echo esc_attr($download['password']); ?>"></label>
                        <label>链接：<input type="url" name="download_link[]" value="<?php echo esc_url($download['link']); ?>"></label>
                        <label>磁力链接：<input type="text" name="download_magnet[]" value="<?php echo esc_attr($download['magnet']); ?>"></label>
                        <label>说明：<textarea name="download_description[]"><?php echo esc_textarea($download['description']); ?></textarea></label>
                        <button type="button" class="remove-download-entry">删除</button>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <div class="download-entry">
                    <label>版本：<input type="text" name="download_version[]"></label>
                    <label>环境：<input type="text" name="download_environment[]"></label>
                    <label>语言：<input type="text" name="download_language[]"></label>
                    <label>日期：<input type="date" name="download_date[]"></label>
                    <label>大小：<input type="text" name="download_size[]"></label>
                    <label>网盘：<input type="text" name="download_drive[]"></label>
                    <label>密码：<input type="text" name="download_password[]"></label>
                    <label>链接：<input type="url" name="download_link[]"></label>
                    <label>磁力链接：<input type="text" name="download_magnet[]"></label>
                    <label>说明：<textarea name="download_description[]"></textarea></label>
                    <button type="button" class="remove-download-entry">删除</button>
                </div>
            <?php endif; ?>
        </div>
        <button type="button" id="add-download-entry">添加更多</button>
    </div>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            // 添加新条目
            $('#add-download-entry').on('click', function() {
                $('#download-entries').append('<div class="download-entry"><label>版本：<input type="text" name="download_version[]"></label><label>环境：<input type="text" name="download_environment[]"></label><label>语言：<input type="text" name="download_language[]"></label><label>日期：<input type="date" name="download_date[]"></label><label>大小：<input type="text" name="download_size[]"></label><label>网盘：<input type="text" name="download_drive[]"></label><label>密码：<input type="text" name="download_password[]"></label><label>链接：<input type="url" name="download_link[]"></label><label>磁力链接：<input type="text" name="download_magnet[]"></label><label>说明：<textarea name="download_description[]"></textarea></label><button type="button" class="remove-download-entry">删除</button></div>');
            });

            // 删除条目
            $(document).on('click', '.remove-download-entry', function() {
                $(this).closest('.download-entry').remove();
            });
        });
    </script>
    <?php
}

add_action('edit_form_after_editor', 'wp_download_plugin_download_area');

// 保存下载信息到文章元数据
// 保存下载信息到文章元数据
function wp_download_plugin_save_download_info($post_id) {
    // 防止自动保存干扰
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    // 如果提交的数据中有下载信息，则更新；否则删除原来的数据
    if (isset($_POST['download_version'])) {
        $downloads = [];
        $version     = $_POST['download_version'];
        $environment = $_POST['download_environment'];
        $language    = $_POST['download_language'];
        $date        = $_POST['download_date'];
        $size        = $_POST['download_size'];
        $drive       = $_POST['download_drive'];
        $password    = $_POST['download_password'];
        $link        = $_POST['download_link'];
        $magnet      = $_POST['download_magnet'];
        $description = $_POST['download_description'];

        // 遍历所有条目，只有当版本号不为空时才添加到数组中
        foreach ($version as $key => $ver) {
            if (!empty($ver)) {
                $downloads[] = [
                    'version'     => $ver,
                    'environment' => $environment[$key],
                    'language'    => $language[$key],
                    'date'        => $date[$key],
                    'size'        => $size[$key],
                    'drive'       => $drive[$key],
                    'password'    => $password[$key],
                    'link'        => $link[$key],
                    'magnet'      => sanitize_text_field($magnet[$key]),
                    'description' => $description[$key],
                ];
            }
        }

        update_post_meta($post_id, 'downloads', $downloads);
    } else {
        // 如果前端完全没有提交下载信息，则删除旧的元数据
        delete_post_meta($post_id, 'downloads');
    }

    // 同时保存插件设置页面中软件版权的内容
    if (isset($_POST['wp_download_plugin_software_copyright'])) {
        update_option('wp_download_plugin_software_copyright', sanitize_textarea_field($_POST['wp_download_plugin_software_copyright']));
    }
}
add_action('save_post', 'wp_download_plugin_save_download_info');


// 在文章中显示软件“软件下载”和信息
function wp_download_plugin_display_download_section($content) {
    global $post;
    $downloads = get_post_meta($post->ID, 'downloads', true);
    $hide_all = get_option('wp_download_plugin_hide_all'); //隐藏
    $website_intro = get_option('wp_download_plugin_website_intro');

    if (is_singular() &&!$hide_all && $downloads) :
        ob_start();
        ?>
        <div class="wp-download-section">
            <h2>软件下载</h2>
            <button class="wp-download-button" data-post-id="<?php echo esc_attr($post->ID); ?>">&#9196; 显示下载信息</button>
            <div class="wp-download-modal" style="display:none;">
                <div class="close-button">关闭</div>
                <h3>软件版本信息</h3>
                <div id="download-info-container">加载中...</div>
                <div class="wp-download-software-copyright"><?php echo wp_kses_post(get_option('wp_download_plugin_software_copyright')); ?></div>
            </div>
            <?php if ($website_intro) : ?>
                <div class="wp-download-intro"><?php echo wp_kses_post(get_option('wp_download_plugin_website_intro')); ?></div>
            <?php endif; ?>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // 打开下载信息弹窗并加载数据
                $('.wp-download-button').on('click', function() {
                    const postId = $(this).data('post-id');
                    $('.wp-download-modal').fadeIn();
                    
                    // 动态加载下载信息
                    $.ajax({
                        url: '<?php echo admin_url('admin-ajax.php'); ?>',
                        method: 'POST',
                        data: {
                            action: 'get_download_info',
                            post_id: postId,
                        },
                        success: function(response) {
                            $('#download-info-container').html(response.data);
                        },
                        error: function() {
                            $('#download-info-container').html('加载失败，请稍后再试。');
                        }
                    });
                });

                // 关闭弹窗
                $('.wp-download-modal .close-button').on('click', function() {
                    $('.wp-download-modal').fadeOut();
                });

                // 点击外部关闭弹窗
                $(document).on('click', function(event) {
                    if (!$(event.target).closest('.wp-download-modal, .wp-download-button').length) {
                        $('.wp-download-modal').fadeOut();
                    }
                });
            });
        </script>
        <?php
        $content .= ob_get_clean();
    endif;

    return $content;
}
add_filter('the_content', 'wp_download_plugin_display_download_section');

// 在小工具显示“软件下载”按钮
class WP_Download_Plugin_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'wp_download_plugin_widget',
            '小半软件下载插件',
            ['description' => '显示软件下载信息']
        );
    }

    public function widget($args, $instance) {
        global $post;

        $hide_all = get_option('wp_download_plugin_hide_all'); // 获取隐藏设置

        if ($hide_all) { // 设置为隐藏直接返回，不显示小工具内容
            return;
        }

        // 检查当前文章是否存在下载信息
        if (!is_singular() || empty($post)) {
            return; // 如果不是单篇文章页面或没有文章对象，就不加载
        }

        $downloads = get_post_meta($post->ID, 'downloads', true);

        // 如果没有下载信息，也不加载
        if (!$downloads || !is_array($downloads) || empty($downloads)) {
            return;
        }

        // 如果存在下载信息，显示小工具内容
        echo $args['before_widget'];
        echo '<h3 class="wp-download-widget-title">软件下载</h3>';
        echo '<button class="wp-download-button" data-post-id="' . esc_attr($post->ID) . '">&#9196; 显示下载信息</button>';
        
        // 备用模板
        wp_download_plugin_display_download_section(''); 
        
        echo $args['after_widget'];
    }

    public function form($instance) {
    }

    public function update($new_instance, $old_instance) {
        return $old_instance;
    }
}

function wp_download_plugin_register_widget() {
    register_widget('WP_Download_Plugin_Widget');
}
add_action('widgets_init', 'wp_download_plugin_register_widget');


// 添加AJAX处理器，用于返回下载信息
function wp_download_plugin_get_download_info() {
    // 检查权限
    if (!isset($_POST['post_id']) || !is_numeric($_POST['post_id'])) {
        wp_send_json_error('无效的请求');
    }

    $post_id = intval($_POST['post_id']);
    $downloads = get_post_meta($post_id, 'downloads', true);

    if (!$downloads) {
        wp_send_json_error('未找到下载信息');
    }

    ob_start();
    ?>
    <table>
        <thead>
            <tr>
                <th>版本</th>
                <th>环境</th>
                <th>语言</th>
                <th>日期</th>
                <th>大小</th>
                <th>网盘</th>
                <th>密码</th>
                <th>链接</th>
                <th>磁力链接</th>
                <th>说明</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($downloads as $download) : ?>
                <tr>
                    <td><?php echo esc_html($download['version']); ?></td>
                    <td><?php echo esc_html($download['environment']); ?></td>
                    <td><?php echo esc_html($download['language']); ?></td>
                    <td><?php echo esc_html($download['date']); ?></td>
                    <td><?php echo esc_html($download['size']); ?></td>
                    <td><?php echo esc_html($download['drive']); ?></td>
                    <td><?php echo esc_html($download['password']); ?></td>
                    <td><a href="<?php echo esc_url($download['link']); ?>" target="_blank">访问</a></td>
                                                <td>
                                <?php if (!empty($download['magnet'])) : ?>
                                    <button class="wp-download-copy-magnet" data-magnet="<?php echo esc_attr($download['magnet']); ?>">复制磁力</button>
                                    <div class="wp-download-copy-message"></div> <!-- 消息显示框 -->
                                <?php endif; ?>
                            </td>
                    <td><?php echo esc_html($download['description']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        // 绑定点击事件到复制按钮
        $('.wp-download-copy-magnet').on('click', function() {
            const magnetLink = $(this).data('magnet'); // 获取磁力链接
            const messageBox = $(this).siblings('.wp-download-copy-message'); // 找到对应的消息框
            
            navigator.clipboard.writeText(magnetLink).then(() => {
                // 显示成功消息
                messageBox.text('已复制到剪贴板').removeClass('error').addClass('success').fadeIn();
                setTimeout(() => {
                    messageBox.fadeOut(); // 3秒后淡出
                }, 3000);
            }).catch(() => {
                // 显示失败消息
                messageBox.text('复制失败').removeClass('success').addClass('error').fadeIn();
                setTimeout(() => {
                    messageBox.fadeOut(); // 3秒后淡出
                }, 3000);
            });
        });
    });
</script>


    <?php
    $html = ob_get_clean();

    wp_send_json_success($html);
}
add_action('wp_ajax_get_download_info', 'wp_download_plugin_get_download_info');
add_action('wp_ajax_nopriv_get_download_info', 'wp_download_plugin_get_download_info');



// 加载插件样式，仅当页面需要时加载
function wp_download_plugin_enqueue_styles() {
    if (is_singular()) {
        global $post;

        // 检查当前页面是否是文章页面且包含“软件下载”相关信息
        $downloads = get_post_meta($post->ID, 'downloads', true);

        if ($downloads) {
            $css_path = plugin_dir_path(__FILE__) . 'style.css';

            // 检查CSS文件是否存在
            if (file_exists($css_path)) {
                wp_enqueue_style('wp-download-plugin-styles', plugin_dir_url(__FILE__) . 'style.css');
            }
        }
    }
}
add_action('wp_enqueue_scripts', 'wp_download_plugin_enqueue_styles');