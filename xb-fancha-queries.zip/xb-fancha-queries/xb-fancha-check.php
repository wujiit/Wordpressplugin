<?php
/*
Plugin Name: 小半IP反查域名
Description: 一个用于查询IP反查域名的WordPress插件，支持自定义API接口和密钥，记录查询历史（含IP和设备信息），支持游客查询（单独限制），并优化提示和登录按钮。
Version: 1.1.0
Author: Summer
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xb_fancha_activate');
function xb_fancha_activate() {
    xb_fancha_create_database();
    xb_fancha_create_front_page();
}

// 创建数据库表，包含IP和设备信息
function xb_fancha_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 查询次数表，新增IP和设备信息字段
    $usage_table = $wpdb->prefix . 'xb_fancha_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        ip_address varchar(45) NOT NULL,
        device_info varchar(255) NOT NULL,
        query_date date NOT NULL,
        query_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_ip_date (user_id, ip_address, device_info, query_date)
    ) $charset_collate;";

    // 查询记录表，新增IP和设备信息字段
    $queries_table = $wpdb->prefix . 'xb_fancha_queries';
    $queries_sql = "CREATE TABLE $queries_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        ip_address varchar(45) NOT NULL,
        device_info varchar(255) NOT NULL,
        ip varchar(255) NOT NULL,
        query_status varchar(255) NOT NULL,
        query_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($usage_sql);
    dbDelta($queries_sql);

    error_log('XB Fancha Check: Database tables created or updated.');
}

// 检查并创建前台页面
function xb_fancha_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_fancha_query_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => 'IP反查域名',
            'post_content' => '[xb_fancha_query_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_fancha_enqueue_scripts');
function xb_fancha_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_fancha_query_form')) {
        wp_enqueue_style('xb_fancha_styles', plugins_url('xb-fancha-styles.css', __FILE__), array(), '1.1.0');
        wp_enqueue_script('xb_fancha_scripts', plugins_url('xb-fancha-scripts.js', __FILE__), array('jquery'), '1.1.0', true);

        wp_localize_script('xb_fancha_scripts', 'xb_fancha_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('xb_fancha_query_nonce'),
            'login_url' => wp_login_url(get_permalink()),
            'is_logged_in' => is_user_logged_in() ? 1 : 0
        ));
    }
}

// 创建短代码，支持游客查询并优化登录提示
add_shortcode('xb_fancha_query_form', 'xb_fancha_query_form_shortcode');
function xb_fancha_query_form_shortcode() {
    $ad_content = get_option('xb_fancha_ad_content', '');
    $default_limit = absint(get_option('xb_fancha_default_limit', 5));
    $guest_limit = absint(get_option('xb_fancha_guest_limit', 3));

    ob_start();
    ?>
    <div class="xb_fancha_container">
        <div class="xb_fancha_title">IP反查域名助手</div>

        <?php
        $user_id = is_user_logged_in() ? get_current_user_id() : 0;
        $today = current_time('Y-m-d');
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $device_info = !empty($_SERVER['HTTP_USER_AGENT']) ? substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT']), 0, 255) : 'Unknown';

        global $wpdb;
        $table_name = $wpdb->prefix . 'xb_fancha_usage';
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT query_count, custom_limit FROM $table_name WHERE user_id = %d AND ip_address = %s AND device_info = %s AND query_date = %s",
                $user_id,
                $ip_address,
                $device_info,
                $today
            )
        );

        $query_count = $row ? absint($row->query_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : ($user_id ? $default_limit : $guest_limit);
        $remaining = max(0, $user_limit - $query_count);
        ?>
        <div class="xb_fancha_query_section">
            <?php if ($query_count >= $user_limit): ?>
                <div class="xb_fancha_message">
                    今日查询次数已用完！
                    <?php if (!is_user_logged_in()): ?>
                        登录可使用更多查询次数！
                        <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="wp-ai-login-btn">快速登录</a>
                    <?php else: ?>
                        请明天再试！
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <form id="xb_fancha_query_form" method="post">
                    <input type="text" name="xb_fancha_ip" id="xb_fancha_ip" placeholder="请输入IP地址（如：1.1.1.1）" required>
                    <button type="submit" class="xb_fancha_submit_button">查询</button>
                    <input type="hidden" name="xb_fancha_nonce" id="xb_fancha_nonce" value="<?php echo wp_create_nonce('xb_fancha_query_nonce'); ?>">
                </form>
            <?php endif; ?>
            <div class="xb_fancha_result_section">
                <div id="xb_fancha_result"></div>
                <div id="xb_fancha_pagination"></div>
                <div class="xb_fancha_usage_info">今日剩余查询次数：<?php echo esc_html($remaining); ?>/<?php echo esc_html($user_limit); ?></div>
            </div>
        </div>
        <div class="xb_fancha_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
    </div>
    <?php
    return ob_get_clean();
}

// 处理 AJAX 查询请求，支持游客查询并优化提示信息
add_action('wp_ajax_xb_fancha_query', 'xb_fancha_handle_query');
add_action('wp_ajax_nopriv_xb_fancha_query', 'xb_fancha_handle_query');
function xb_fancha_handle_query() {
    // 验证 nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'xb_fancha_query_nonce')) {
        wp_send_json_error(array('message' => '安全验证失败，请刷新页面重试！'), 403);
        return;
    }

    // 验证 action 参数
    if (!isset($_POST['action']) || $_POST['action'] !== 'xb_fancha_query') {
        wp_send_json_error(array('message' => '无效的请求动作！'), 400);
        return;
    }

    // 验证 IP 参数
    if (!isset($_POST['ip']) || empty(trim($_POST['ip']))) {
        wp_send_json_error(array('message' => '请输入IP地址！'), 400);
        return;
    }

    $ip = sanitize_text_field($_POST['ip']);
    $page = isset($_POST['page']) ? absint($_POST['page']) : 1;

    // 验证 IP 格式
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        wp_send_json_error(array('message' => '请输入有效的IP地址（如：192.168.1.1）！'), 400);
        return;
    }

    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $today = current_time('Y-m-d');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $device_info = !empty($_SERVER['HTTP_USER_AGENT']) ? substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT']), 0, 255) : 'Unknown';

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_fancha_usage';
    $queries_table = $wpdb->prefix . 'xb_fancha_queries';

    // 检查查询限制
    $default_limit = absint(get_option('xb_fancha_default_limit', 5));
    $guest_limit = absint(get_option('xb_fancha_guest_limit', 3));
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT query_count, custom_limit FROM $usage_table WHERE user_id = %d AND ip_address = %s AND device_info = %s AND query_date = %s",
            $user_id,
            $ip_address,
            $device_info,
            $today
        )
    );

    $query_count = $row ? absint($row->query_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : ($user_id ? $default_limit : $guest_limit);

    if ($query_count >= $user_limit && $page == 1) {
        if (!is_user_logged_in()) {
            $message = '今日查询次数已用完！登录可使用更多查询次数！ <a href="' . esc_url(wp_login_url()) . '" class="wp-ai-login-btn">快速登录</a>';
        } else {
            $message = '今日查询次数已用完！请明天再试！';
        }
        wp_send_json_error(array('message' => $message), 403);
        return;
    }

    // 调用 API
    $api_url = get_option('xb_fancha_api_url', 'https://apistore.aizhan.com/site/dnsinfos/');
    $api_key = get_option('xb_fancha_api_key');
    $request_url = trailingslashit($api_url) . $api_key . '?query=' . urlencode($ip) . '&page=' . $page;

    $args = array(
        'timeout' => 10,
        'sslverify' => false
    );

    $response = wp_remote_get($request_url, $args);
    $query_status = 'failed';

    // 准备插入记录，仅在第一页记录
    if ($page == 1) {
        $insert_data = array(
            'user_id' => $user_id,
            'ip_address' => $ip_address,
            'device_info' => $device_info,
            'ip' => $ip,
            'query_status' => $query_status,
            'query_time' => current_time('mysql')
        );

        // 更新查询次数
        if ($row) {
            $new_count = $query_count + 1;
            $wpdb->update(
                $usage_table,
                array('query_count' => $new_count),
                array('user_id' => $user_id, 'ip_address' => $ip_address, 'device_info' => $device_info, 'query_date' => $today),
                array('%d'),
                array('%d', '%s', '%s', '%s')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'ip_address' => $ip_address,
                    'device_info' => $device_info,
                    'query_date' => $today,
                    'query_count' => 1,
                    'custom_limit' => null
                ),
                array('%d', '%s', '%s', '%s', '%d', '%d')
            );
        }
    }

    if (is_wp_error($response)) {
        $query_status = $response->get_error_message();
        if ($page == 1) {
            $insert_data['query_status'] = $query_status;
            $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s', '%s'));
        }
        wp_send_json_error(array('message' => 'API 请求失败：' . esc_html($query_status)), 500);
        return;
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if ($status_code >= 400 && $status_code < 600) {
        $error_codes = array(
            431 => 'APIKey 缺失，请检查配置！',
            432 => 'APIKey 长度错误！',
            433 => '无效的 APIKey！',
            434 => 'APIKey 类型错误！',
            436 => 'API 额度不足或 APIKey 不存在！',
            437 => 'IP 未在白名单内！',
            531 => '请求过于频繁！',
            532 => '未知错误，请联系管理员！'
        );
        $query_status = isset($error_codes[$status_code]) ? $error_codes[$status_code] : (isset($data['msg']) ? $data['msg'] : 'API 请求错误：HTTP ' . $status_code);
        if ($page == 1) {
            $insert_data['query_status'] = $query_status;
            $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s', '%s'));
        }
        wp_send_json_error(array('message' => '查询失败：' . esc_html($query_status)), $status_code);
        return;
    }

    if (isset($data['code']) && $data['code'] == 200000 && !empty($data['data']['domains'])) {
        $query_status = 'success';
        if ($page == 1) {
            $insert_data['query_status'] = $query_status;
            $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s', '%s'));
        }

        // 格式化结果
        $output = '<div class="xb_fancha_result_info">';
        $output .= '<p><strong>IP地址：</strong>' . esc_html($data['data']['ip']) . '</p>';
        $output .= '<p><strong>地区：</strong>' . esc_html($data['data']['address']) . '</p>';
        $output .= '<p><strong>总记录数：</strong>' . esc_html($data['data']['total_num']) . '</p>';
        $output .= '</div>';

        $output .= '<table class="xb_fancha_result_table">';
        $output .= '<tr><th>域名</th><th>标题</th><th>PC权重</th><th>移动权重</th><th>搜狗权重</th><th>谷歌权重</th></tr>';
        foreach ($data['data']['domains'] as $domain) {
            $output .= '<tr>';
            $output .= '<td>' . esc_html($domain['domain']) . '</td>';
            $output .= '<td>' . esc_html($domain['title']) . '</td>';
            $output .= '<td>' . esc_html($domain['pc_br']) . '</td>';
            $output .= '<td>' . esc_html($domain['m_br']) . '</td>';
            $output .= '<td>' . esc_html($domain['sogou_pr']) . '</td>';
            $output .= '<td>' . esc_html($domain['google_pr']) . '</td>';
            $output .= '</tr>';
        }
        $output .= '</table>';

        // 分页导航
        $total_pages = $data['data']['total_pages'];
        $current_page = $data['data']['current_page'];
        if ($total_pages > 1) {
            $output .= '<div class="xb_fancha_pagination">';
            if ($current_page > 1) {
                $output .= '<button class="xb_fancha_page_button" data-page="' . ($current_page - 1) . '">上一页</button>';
            }
            for ($i = max(1, $current_page - 2); $i <= min($total_pages, $current_page + 2); $i++) {
                $active = $i == $current_page ? ' active' : '';
                $output .= '<button class="xb_fancha_page_button' . $active . '" data-page="' . $i . '">' . $i . '</button>';
            }
            if ($current_page < $total_pages) {
                $output .= '<button class="xb_fancha_page_button" data-page="' . ($current_page + 1) . '">下一页</button>';
            }
            $output .= '</div>';
        }

        wp_send_json_success(array(
            'result' => $output,
            'remaining' => $user_limit - ($query_count + ($page == 1 ? 1 : 0)),
            'limit' => $user_limit
        ));
    } else {
        $query_status = isset($data['msg']) ? $data['msg'] : '未知错误';
        if ($page == 1) {
            $insert_data['query_status'] = $query_status;
            $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s', '%s'));
        }
        wp_send_json_error(array('message' => '查询失败：' . esc_html($query_status)), 400);
    }
}

// 添加管理菜单
add_action('admin_menu', 'xb_fancha_admin_menu');
function xb_fancha_admin_menu() {
    add_menu_page(
        'IP反查域名设置',
        'IP反查设置',
        'manage_options',
        'xb_fancha_settings',
        'xb_fancha_settings_page',
        'dashicons-search',
        80
    );
    add_submenu_page(
        'xb_fancha_settings',
        '查询记录',
        '查询记录',
        'manage_options',
        'xb_fancha_all_records',
        'xb_fancha_all_records_page'
    );
}

// 插件设置页面，新增游客查询次数设置
function xb_fancha_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['xb_fancha_save_settings'])) {
        check_admin_referer('xb_fancha_settings_nonce');

        update_option('xb_fancha_api_url', sanitize_text_field($_POST['xb_fancha_api_url']));
        update_option('xb_fancha_api_key', sanitize_text_field($_POST['xb_fancha_api_key']));
        $new_limit = absint($_POST['xb_fancha_default_limit']);
        $new_guest_limit = absint($_POST['xb_fancha_guest_limit']);
        if ($new_limit > 0) {
            update_option('xb_fancha_default_limit', $new_limit);
        }
        if ($new_guest_limit > 0) {
            update_option('xb_fancha_guest_limit', $new_guest_limit);
        }
        $allowed_html = array(
            'a' => array('href' => array(), 'title' => array(), 'target' => array()),
            'img' => array('src' => array(), 'alt' => array(), 'width' => array(), 'height' => array()),
            'p' => array(),
            'div' => array('class' => array(), 'style' => array()),
            'span' => array('class' => array(), 'style' => array()),
            'strong' => array(),
            'em' => array(),
            'br' => array()
        );
        update_option('xb_fancha_ad_content', wp_kses($_POST['xb_fancha_ad_content'], $allowed_html));

        echo '<div id="xb_fancha_settings_notice" class="updated"><p>设置已保存！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_fancha_settings_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    global $wpdb;
    $queries_table = $wpdb->prefix . 'xb_fancha_queries';
    $stats = array();
    $stats['total_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table");
    $stats['success_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table WHERE query_status = 'success'");
    $stats['failed_queries'] = $stats['total_queries'] - $stats['success_queries'];
    $stats['today_queries'] = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $queries_table WHERE DATE(query_time) = %s", current_time('Y-m-d'))
    );

    ?>
    <div class="wrap">
        <div class="xb_fancha_admin_title">IP反查域名设置</div>
        <form method="post">
            <?php wp_nonce_field('xb_fancha_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_fancha_api_url">API 接口地址</label></th>
                    <td><input type="text" name="xb_fancha_api_url" id="xb_fancha_api_url" value="<?php echo esc_attr(get_option('xb_fancha_api_url', 'https://apistore.aizhan.com/site/dnsinfos/')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_fancha_api_key">API 密钥</label></th>
                    <td><input type="text" name="xb_fancha_api_key" id="xb_fancha_api_key" value="<?php echo esc_attr(get_option('xb_fancha_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_fancha_default_limit">登录用户每日查询次数</label></th>
                    <td><input type="number" name="xb_fancha_default_limit" id="xb_fancha_default_limit" value="<?php echo esc_attr(get_option('xb_fancha_default_limit', 5)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_fancha_guest_limit">游客每日查询次数</label></th>
                    <td><input type="number" name="xb_fancha_guest_limit" id="xb_fancha_guest_limit" value="<?php echo esc_attr(get_option('xb_fancha_guest_limit', 3)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_fancha_ad_content">广告内容</label></th>
                    <td>
                        <textarea name="xb_fancha_ad_content" id="xb_fancha_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_fancha_ad_content')); ?></textarea>
                        <p class="description">支持 HTML 格式</p>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="xb_fancha_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        <div class="xb_fancha_stats">
            <p>总查询次数：<?php echo esc_html($stats['total_queries'] ?: 0); ?></p>
            <p>成功查询次数：<?php echo esc_html($stats['success_queries'] ?: 0); ?></p>
            <p>失败查询次数：<?php echo esc_html($stats['failed_queries'] ?: 0); ?></p>
            <p>今日查询次数：<?php echo esc_html($stats['today_queries'] ?: 0); ?></p>
        </div>
    </div>
    <?php
}

// 查询记录页面，显示IP和设备信息
function xb_fancha_all_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_fancha_usage';
    $queries_table = $wpdb->prefix . 'xb_fancha_queries';
    $user_id = isset($_POST['xb_fancha_user_id']) ? absint($_POST['xb_fancha_user_id']) : 0;
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    // 删除单条记录
    if (isset($_POST['xb_fancha_delete_record']) && isset($_POST['record_id'])) {
        check_admin_referer('xb_fancha_delete_record_nonce');
        $wpdb->delete($queries_table, array('id' => absint($_POST['record_id'])), array('%d'));
        echo '<div id="xb_fancha_delete_notice" class="updated"><p>记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_fancha_delete_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 删除用户全部记录
    if (isset($_POST['xb_fancha_delete_all_records']) && $user_id) {
        check_admin_referer('xb_fancha_delete_all_records_nonce');
        $wpdb->delete($queries_table, array('user_id' => $user_id), array('%d'));
        $wpdb->delete($usage_table, array('user_id' => $user_id), array('%d'));
        echo '<div id="xb_fancha_delete_all_notice" class="updated"><p>所有记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_fancha_delete_all_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 保存用户自定义限制
    if (isset($_POST['xb_fancha_save_user_limit']) && $user_id) {
        check_admin_referer('xb_fancha_user_limit_nonce');
        $custom_limit = isset($_POST['xb_fancha_custom_limit']) ? absint($_POST['xb_fancha_custom_limit']) : null;

        $wpdb->update(
            $usage_table,
            array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
            array('user_id' => $user_id, 'query_date' => current_time('Y-m-d')),
            array('%d'),
            array('%d', '%s')
        );

        echo '<div id="xb_fancha_limit_notice" class="updated"><p>用户查询限制已更新！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_fancha_limit_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 获取用户每日查询次数限制
    $default_limit = absint(get_option('xb_fancha_default_limit', 5));
    $guest_limit = absint(get_option('xb_fancha_guest_limit', 3));
    $user_limit = $user_id ? $default_limit : $guest_limit;
    if ($user_id || $user_id === 0) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT custom_limit FROM $usage_table WHERE user_id = %d AND query_date = %s LIMIT 1",
                $user_id,
                current_time('Y-m-d')
            )
        );
        if ($row && $row->custom_limit !== null) {
            $user_limit = absint($row->custom_limit);
        }
    }

    // 统计数据
    $stats = array();
    $where_clause = $user_id ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : '';
    $stats['total_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table $where_clause");
    $stats['success_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table WHERE query_status = 'success' " . ($user_id ? $wpdb->prepare('AND user_id = %d', $user_id) : ''));
    $stats['failed_queries'] = $stats['total_queries'] - $stats['success_queries'];
    $stats['today_queries'] = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $queries_table WHERE DATE(query_time) = %s " . ($user_id ? 'AND user_id = %d' : ''), current_time('Y-m-d'), $user_id)
    );

    // 获取记录
    $offset = ($paged - 1) * $per_page;
    $query = $user_id
        ? $wpdb->prepare("SELECT id, user_id, ip_address, device_info, ip, query_status, query_time FROM $queries_table WHERE user_id = %d ORDER BY query_time DESC LIMIT %d, %d", $user_id, $offset, $per_page)
        : $wpdb->prepare("SELECT id, user_id, ip_address, device_info, ip, query_status, query_time FROM $queries_table ORDER BY query_time DESC LIMIT %d, %d", $offset, $per_page);
    $records = $wpdb->get_results($query);
    $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table" . ($user_id ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : ''));
    $total_pages = ceil($total_records / $per_page);

    $user_info = $user_id && $user_id != 0 ? get_userdata($user_id) : null;
    $user_display = $user_id == 0 ? '游客' : ($user_info ? $user_info->user_login : '未知用户');
    ?>
    <div class="wrap">
        <div class="xb_fancha_admin_title">所有查询记录</div>
        <form method="post">
            <p>
                <label for="xb_fancha_user_id">输入用户 ID（0 表示游客，留空显示所有记录）：</label>
                <input type="number" name="xb_fancha_user_id" id="xb_fancha_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <?php if ($user_id || $user_id === 0): ?>
            <h2>用户：<?php echo esc_html($user_display); ?> (ID: <?php echo $user_id; ?>)</h2>
            <p>当前用户每日查询次数：<?php echo esc_html($user_limit); ?> 次</p>
            <form method="post">
                <?php wp_nonce_field('xb_fancha_user_limit_nonce'); ?>
                <p>
                    <label for="xb_fancha_custom_limit">设置自定义每日查询次数（0 表示使用默认值）：</label>
                    <input type="number" name="xb_fancha_custom_limit" id="xb_fancha_custom_limit" min="0">
                    <input type="hidden" name="xb_fancha_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_fancha_save_user_limit" class="button-primary" value="保存">
                </p>
            </form>
            <form method="post">
                <?php wp_nonce_field('xb_fancha_delete_all_records_nonce'); ?>
                <input type="hidden" name="xb_fancha_user_id" value="<?php echo esc_attr($user_id); ?>">
                <p><input type="submit" name="xb_fancha_delete_all_records" class="button-secondary" value="删除所有记录" onclick="return confirm('确定删除所有记录吗？');"></p>
            </form>
        <?php endif; ?>

        <div class="xb_fancha_stats">
            <p>总查询次数：<?php echo esc_html($stats['total_queries'] ?: 0); ?></p>
            <p>成功查询次数：<?php echo esc_html($stats['success_queries'] ?: 0); ?></p>
            <p>失败查询次数：<?php echo esc_html($stats['failed_queries'] ?: 0); ?></p>
            <p>今日查询次数：<?php echo esc_html($stats['today_queries'] ?: 0); ?></p>
        </div>

        <table class="widefat">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>IP 地址</th>
                    <th>设备信息</th>
                    <th>查询时间</th>
                    <th>IP地址</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="7">暂无查询记录。</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td><?php echo esc_html($record->user_id == 0 ? '游客' : $record->user_id); ?></td>
                            <td><?php echo esc_html($record->ip_address); ?></td>
                            <td><?php echo esc_html($record->device_info); ?></td>
                            <td><?php echo esc_html($record->query_time); ?></td>
                            <td><?php echo esc_html($record->ip); ?></td>
                            <td><?php echo esc_html($record->query_status); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_fancha_delete_record_nonce'); ?>
                                    <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>">
                                    <input type="submit" name="xb_fancha_delete_record" class="button-link" value="删除" onclick="return confirm('确定删除此记录？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}
?>