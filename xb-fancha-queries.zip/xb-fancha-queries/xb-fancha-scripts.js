jQuery(document).ready(function ($) {
    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('XB Fancha Check: jQuery 未加载！');
        $('#xb_fancha_result').html('<div class="xb_fancha_message">脚本加载失败，请刷新页面！</div>');
        return;
    }

    // 确保 xb_fancha_ajax 配置
    if (typeof xb_fancha_ajax === 'undefined') {
        console.error('XB Fancha Check: xb_fancha_ajax 未定义！');
        $('#xb_fancha_result').html('<div class="xb_fancha_message">脚本配置失败，请检查插件设置！</div>');
        return;
    }

    // “快速登录”按钮点击事件
    $(document).on('click', '.wp-ai-login-btn', function (e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });

    // 查询表单提交
    $('#xb_fancha_query_form').on('submit', function (e) {
        e.preventDefault();

        var $form = $(this);
        var ip = $('#xb_fancha_ip').val().trim();
        var nonce = $('#xb_fancha_nonce').val();

        if (!ip) {
            $('#xb_fancha_result').html('<div class="xb_fancha_message">请输入IP地址！</div>');
            return;
        }

        // 前端验证 IP 格式
        var ipPattern = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;
        if (!ipPattern.test(ip)) {
            $('#xb_fancha_result').html('<div class="xb_fancha_message">请输入有效的IP地址（如：192.168.1.1）！</div>');
            return;
        }

        if (!nonce) {
            $('#xb_fancha_result').html('<div class="xb_fancha_message">安全验证参数丢失，请刷新页面！</div>');
            return;
        }

        xb_fancha_query(ip, 1, nonce, $form);
    });

    // 分页按钮点击事件
    $(document).on('click', '.xb_fancha_page_button', function () {
        var page = $(this).data('page');
        var ip = $('#xb_fancha_ip').val().trim();
        var nonce = $('#xb_fancha_nonce').val();
        var $form = $('#xb_fancha_query_form');

        if (!ip || !nonce) {
            $('#xb_fancha_result').html('<div class="xb_fancha_message">参数丢失，请刷新页面！</div>');
            return;
        }

        xb_fancha_query(ip, page, nonce, $form);
    });

    // 查询函数
    function xb_fancha_query(ip, page, nonce, $form) {
        $.ajax({
            url: xb_fancha_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_fancha_query',
                ip: ip,
                page: page,
                nonce: nonce
            },
            beforeSend: function () {
                $('.xb_fancha_submit_button').prop('disabled', true).text('查询中...');
                $('#xb_fancha_result').html('<div class="xb_fancha_message">加载中...</div>');
            },
            success: function (response) {
                if (response.success) {
                    $('#xb_fancha_result').html(response.data.result);
                    $('.xb_fancha_usage_info').text('今日剩余查询次数：' + response.data.remaining + '/' + response.data.limit);

                    if (response.data.remaining <= 0 && page == 1) {
                        $form.hide();
                        var message = '今日查询次数已用尽！';
                        if (!xb_fancha_ajax.is_logged_in) {
                            message += ' 登录可使用更多查询次数！ <a href="' + xb_fancha_ajax.login_url + '" class="wp-ai-login-btn">快速登录</a>';
                        } else {
                            message += ' 请明天再试！';
                        }
                        $('#xb_fancha_result').append('<div class="xb_fancha_message">' + message + '</div>');
                    }
                } else {
                    $('#xb_fancha_result').html('<div class="xb_fancha_message">' + response.data.message + '</div>');
                }
            },
            error: function (xhr, status, error) {
                console.error('XB Fancha Check: AJAX 错误：' + error);
                var message = '请求失败：' + (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ? xhr.responseJSON.data.message : '未知错误，请检查网络或刷新页面。');
                $('#xb_fancha_result').html('<div class="xb_fancha_message">' + message + '</div>');
            },
            complete: function () {
                $('.xb_fancha_submit_button').prop('disabled', false).text('查询');
            }
        });
    }
});