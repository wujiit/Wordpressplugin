<?php
/*
Plugin Name: WPMVP HTML5视频播放器
Plugin URI: https://www.jingxialai.com/4558.html
Description: 集成videojs html5播放器实现对mp4、m3u8视频的播放，编辑器有快捷键，支持多集，短代码[wp_mvp_video url="视频1.mp4,视频2.m3u8"]
Version: 1.7
Author: Summer
Author URI: https://www.jingxialai.com
License: GPL2
*/

if (!defined('ABSPATH')) {
    exit;
}

// 经典编辑器快捷键
function wp_mvp_videojs_register_tinymce_plugin($plugin_array) {
    $plugin_array['wp_mvp_videojs_button'] = plugin_dir_url(__FILE__) . 'wp-mvp-tinymce.js';
    return $plugin_array;
}

function wp_mvp_videojs_add_tinymce_button($buttons) {
    array_push($buttons, 'wp_mvp_videojs_button');
    return $buttons;
}

function wp_mvp_videojs_add_tinymce_plugin() {
    if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {
        return;
    }

    if (get_user_option('rich_editing') !== 'true') {
        return;
    }

    add_filter('mce_external_plugins', 'wp_mvp_videojs_register_tinymce_plugin');
    add_filter('mce_buttons', 'wp_mvp_videojs_add_tinymce_button');
}

add_action('init', 'wp_mvp_videojs_add_tinymce_plugin');
// 经典编辑器快捷键结束


// Gutenberg编辑器快捷引入
function wp_mvp_videojs_gutenberg_register_block() {
    wp_register_script(
        'wp-mvp-videojs-block',
        plugins_url('wp-mvp-gutenberg-block.js', __FILE__),
        array('wp-blocks', 'wp-editor', 'wp-components', 'wp-element')
    );

    register_block_type('wp-mvp/videojs', array(
        'editor_script' => 'wp-mvp-videojs-block',
    ));
}

add_action('init', 'wp_mvp_videojs_gutenberg_register_block');
// Gutenberg编辑器快捷引入结束

// 加载videojs播放器
function wp_mvp_videojs_player_enqueue_scripts() {
    // 检查当前页面是否包含 [wp_mvp_video] 短代码
    if (!is_admin() && has_shortcode(get_the_content(), 'wp_mvp_video')) {
        $plugin_url = plugins_url('', __FILE__);
        wp_enqueue_script('jquery');
        wp_register_style('videojs', $plugin_url . '/videojs/video-js.min.css');
        wp_enqueue_style('videojs');

        wp_register_script('videojs', $plugin_url . '/videojs/video.min.js', array('jquery'), '8.20.0', true);
        wp_enqueue_script('videojs');

        wp_register_script('videojs-playbackrate-adjuster', $plugin_url . '/videojs/videojs-playbackrate-adjuster.min.js', array('videojs'), '1.0', true);
        wp_enqueue_script('videojs-playbackrate-adjuster');
        //设置倍数的js


        wp_register_script('videojs-contrib-hls', $plugin_url . '/videojs/videojs-contrib-hlsjs.min.js', array('videojs'), null, true);
        wp_enqueue_script('videojs-contrib-hls');
        // 加载 videojs-contrib-hlsjs.min.js 插件可以在更多环境下兼容m3u8视频，如果是常见的可以不用。


        // 加载中文语言文件
        wp_register_script('videojs-lang-zh-CN', $plugin_url . '/videojs/lang/zh-CN.js', array('videojs'), null, true);
        wp_enqueue_script('videojs-lang-zh-CN');
    }
}


function wp_mvp_videojs_video_handler($atts) {
    static $instance = 0;
    $instance++;

    $atts = shortcode_atts(array(
        'url' => '',
        'disable_context_menu' => 'true', // 禁用右键
        'controls' => 'true',
        'preload' => 'metadata',
        'autoplay' => 'false',
        'loop' => 'false',
        'muted' => 'false',
        'poster' => '',
    ), $atts);

    $atts = array_map('sanitize_text_field', $atts);
    extract($atts);

    if (empty($url)) {
        return __('视频文件不对', 'wp-mvp-videojs-player');
    }

    // 判断是否为B站视频链接
    $bilibili_regex = '/https?:\/\/(?:www\.)?bilibili\.com\/video\/(BV[a-zA-Z0-9]+)/';
    if (preg_match($bilibili_regex, $url, $matches)) {
        // 提取bvid
        $bvid = $matches[1];
        // 生成B站视频iframe代码
        $output = '<div class="bilibili-video-container" style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%;">';
        $output .= '<iframe src="//player.bilibili.com/player.html?bvid=' . esc_attr($bvid) . '&autoplay=0" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;"></iframe>';
        $output .= '</div>';
        return $output;
    }

    // 支持的视频格式
    $supported_formats = array(
        'mp4' => 'video/mp4',
        'webm' => 'video/webm',
        'ogv' => 'video/ogg',
        'm3u8' => 'application/x-mpegURL',
        'mkv' => 'video/x-matroska',
        'mov' => 'video/quicktime',
        'avi' => 'video/x-msvideo'
    );

    // 将多个链接分割成数组
    $urls = explode(',', $url);

    $src = '';
    foreach ($urls as $video_url) {
        foreach ($supported_formats as $extension => $type) {
            if (strpos($video_url, ".$extension") !== false) {
                $src .= '<source src="'.esc_url(trim($video_url)).'" type="'.$type.'" />';
                break;
            }
        }
    }

    if (empty($src)) {
        return __('不支持的视频格式', 'wp-mvp-videojs-player');
    }

    $controls = ($controls == "false") ? "" : " controls";
    $preload = ($preload == "metadata") ? ' preload="metadata"' : (($preload == "none") ? ' preload="none"' : ' preload="auto"');
    $autoplay = ($autoplay == "true") ? " autoplay" : "";
    $loop = ($loop == "true") ? " loop" : "";
    $muted = ($muted == "true") ? " muted" : "";

    if(!empty($poster)) {
        $poster = ' poster="'.esc_url($poster).'"';
    }

    $context_menu = ($disable_context_menu == 'true') ? ' oncontextmenu="return false;"' : '';

    // 调整data-setup为数组形式
    $data_setup = array(
        "playbackRates" => array(0.5, 1, 1.25, 1.5, 2), // 倍速播放按钮
        "language" => "zh-CN"
    );
    $data_setup_string = esc_attr(json_encode($data_setup));

    // 生成选集按钮
    $playlist_buttons = '';
    if (count($urls) > 1) {
        foreach ($urls as $index => $video_url) {
            $playlist_buttons .= '<div class="playlist-button custom-button" data-source="' . esc_url(trim($video_url)) . '" data-instance="' . $instance . '">第 ' . ($index + 1) . ' 集</div>';
        }
    }

    // 添加播放下一集的按钮
    $play_next_button = '';
    if (count($urls) > 1) {
        $play_next_button = '<button class="play-next-button">播放下一集</button>';
    }

    $output = <<<EOT
    <div class="custom-video-player-container"> <!-- 给播放器加一个外部div可以兼容更多样式 -->
        <div class="video-container" style="max-width:100%;height: 0;overflow: hidden;padding-bottom: 56.25%;position: relative;">
            <video-js class="vjs-big-play-centered vjs-instance-{$instance}"{$controls}{$preload}{$autoplay}{$loop}{$muted}{$poster}{$context_menu} data-setup='{$data_setup_string}' style="position: absolute;top: 0;left: 0;width: 100%;height: 100%;">
                $src
            </video-js>
        </div>
        <div class="playlist-container">
            $play_next_button
            $playlist_buttons
        </div>
    </div>
EOT;
    return $output;
}


// 选集和播放下一集按钮点击事件的JavaScript
function wp_mvp_videojs_playlist_script() {
    ?>
    <style>
    .custom-video-player-container {
    background-color: #fff; /* 背景颜色 */
    width: 100%;
    max-width: 800px;
    height: auto;
    box-sizing: border-box;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}
/*这个就是加的视频播放器外部div*/

/*调整播放按钮为圆圈并且使用绝对定位*/
.video-js .vjs-big-play-button {
    margin: 0 !important;/*防止某些主题覆盖播放器按钮*/
    font-size: 2.5em;
    width: 2.5em;
    height: 2.5em;
    border-radius: 50%; /* 将按钮设置为圆形 */
    background-color: rgba(115, 133, 159, 0.5);
    border: 0.15em solid #73859f;
    position: absolute; /* 使用绝对定位 */
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%); /* 使用transform属性将按钮的中心定位到父容器的中心 */
    line-height: 2.3em;
}

/* 中间的播放箭头 */
.vjs-big-play-button .vjs-icon-placeholder {
    font-size: 1.63em;
}

/* 加载圆圈 */
.vjs-loading-spinner {
    font-size: 2.5em;
    width: 2em;
    height: 2em;
    border-radius: 50%; /* 将加载圆圈设置为圆形 */
    margin: -1em 0 0 -1.5em; /* 调整加载圆圈位置 */
}

/* 当播放器处于播放状态时，允许点击 */
.video-js.vjs-playing .vjs-tech {
    pointer-events: auto;
}

/*播放按钮为圆圈并且使用绝对定位结束*/

/*音量百分比*/
.video-js .vjs-volume-horizontal .vjs-mouse-display {
        width: 20px;
        height: 100%;
}

/*进度条时间显示*/
.video-js .vjs-progress-control .vjs-mouse-display {
    display: none;
    position: absolute;
    width: 30px;
    height: 100%;
    background-color: #000;
    z-index: 1;
}

/*播放器控制栏按钮单独*/
.vjs-control-bar .vjs-control.vjs-button {
    margin: 0 !important;/*防止某些主题覆盖播放器按钮*/
    background: 0 0;
    border: none;
    color: inherit;
    display: inline-block;
    font-size: inherit;
    line-height: inherit;
    text-transform: none;
    text-decoration: none;
    transition: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
}

/*播放下一集等按钮*/
.video-container {
    margin-bottom: 10px; /* 视频容器下方间距 */
}

.playlist-container {
    text-align: center; /* 选集按钮居中 */
}

.playlist-button,
.play-next-button {
    background-color: #4CAF50; /* 按钮背景色 */
    border: none;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    transition-duration: 0.4s;
    cursor: pointer;
}

.playlist-button:hover,
.play-next-button:hover {
    background-color: #45a049;
}

.play-next-button {
    background-color: #008CBA; /* 修改下一集按钮的背景色 */
}

.play-next-button:hover {
    background-color: #005f6b; /* 修改下一集按钮的鼠标悬停颜色 */
}

    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var playlistButtons = document.querySelectorAll('.playlist-button');
            var playNextButton = document.querySelector('.play-next-button');
            var currentIndex = 0;

            if (playNextButton) {
                playNextButton.addEventListener('click', function() {
                    var nextIndex = currentIndex + 1;
                    if (nextIndex < playlistButtons.length) {
                        var nextSource = playlistButtons[nextIndex].getAttribute('data-source');
                        var instance = playlistButtons[nextIndex].getAttribute('data-instance');
                        var player = videojs(document.querySelector('.vjs-big-play-centered.vjs-instance-' + instance));
                        player.src(nextSource);
                        player.load();
                        player.play();
                        currentIndex = nextIndex;
                    }
                });
            }

            playlistButtons.forEach(function(button, index) {
                button.addEventListener('click', function() {
                    currentIndex = index;
                    var source = this.getAttribute('data-source');
                    var instance = this.getAttribute('data-instance');
                    var player = videojs(document.querySelector('.vjs-big-play-centered.vjs-instance-' + instance));
                    player.src(source);
                    player.load();
                    player.play();
                });
            });
        });
    </script>
    <?php
}



add_action('wp_enqueue_scripts', 'wp_mvp_videojs_player_enqueue_scripts');
add_shortcode('wp_mvp_video', 'wp_mvp_videojs_video_handler');
add_action('wp_footer', 'wp_mvp_videojs_playlist_script');


// 卸载插件
register_uninstall_hook(__FILE__, 'wp_mvp_videojs_plugin_uninstall');
function wp_mvp_videojs_plugin_uninstall() {
    // 删除插件添加的所有选集按钮的相关脚本
    remove_action('wp_footer', 'wp_mvp_videojs_playlist_script');

    // 删除插件添加的所有短代码
    //remove_shortcode('wp_mvp_video');

    // 删除插件添加的所有前端脚本和样式
    remove_action('wp_enqueue_scripts', 'wp_mvp_videojs_player_enqueue_scripts');

    // 删除插件添加的所有编辑器按钮和相关脚本
    remove_filter('mce_external_plugins', 'wp_mvp_videojs_register_tinymce_plugin');
    remove_filter('mce_buttons', 'wp_mvp_videojs_add_tinymce_button');

    // 删除 Gutenberg 编辑器相关代码
    unregister_block_type('wp-mvp/videojs');
}

?>