(function() {
    tinymce.PluginManager.add('wp_mvp_videojs_button', function(editor, url) {
        editor.addButton('wp_mvp_videojs_button', {
            text: '插入视频',
            icon: false,
            onclick: function() {
                editor.windowManager.open({
                    title: '插入视频',
                    body: [
                        {
                            type: 'textbox',
                            name: 'video_urls',
                            label: '视频链接（每行一个）',
                            multiline: true,
                            minWidth: 300,
                            minHeight: 100
                        },
                        {
                            type: 'label',
                            text: '请在上面输入视频的完整链接，多个视频就每行一个。'
                        }
                    ],
                    onsubmit: function(e) {
                        var videoUrls = e.data.video_urls.split('\n').map(function(url) {
                            return url.trim();
                        }).join(',');

                        editor.insertContent('[wp_mvp_video url="' + videoUrls + '"]');
                    }
                });
            }
        });
    });
})();
