jQuery(document).ready(function($) {
    // 刷新热评按钮点击事件
    $('.xb_wyreping_refresh').on('click', function() {
        var $button = $(this);
        $button.prop('disabled', true);
        $('#xb_wyreping_content, #xb_wyreping_source, #xb_wyreping_image').css('opacity', '0');

        $.ajax({
            url: xb_wyreping_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_wyreping_refresh',
                nonce: xb_wyreping_vars.nonce,
                _t: new Date().getTime()
            },
            cache: false,
            success: function(response) {
                if (response.success) {
                    $('#xb_wyreping_content').text(response.data.content).css('opacity', '1');
                    if (response.data.source) {
                        $('#xb_wyreping_source').text('来源：' + response.data.source).css('opacity', '1');
                    } else {
                        $('#xb_wyreping_source').empty().css('opacity', '1');
                    }
                    if (response.data.image_url) {
                        $('#xb_wyreping_image').html('<img src="' + response.data.image_url + '" alt="热评图片">').css('opacity', '1');
                    } else {
                        $('#xb_wyreping_image').empty().css('opacity', '1');
                    }
                    $('.xb_wyreping_copy').data('content', response.data.content);
                } else {
                    $('#xb_wyreping_notice').text('刷新失败：' + (response.data.message || '未知错误')).show();
                    setTimeout(function() {
                        $('#xb_wyreping_notice').fadeOut('slow', function() {
                            $(this).empty();
                        });
                    }, 3000);
                }
                $button.prop('disabled', false);
            },
            error: function() {
                $('#xb_wyreping_content, #xb_wyreping_source, #xb_wyreping_image').css('opacity', '1');
                $button.prop('disabled', false);
                $('#xb_wyreping_notice').text('网络错误，请稍后再试！').show();
                setTimeout(function() {
                    $('#xb_wyreping_notice').fadeOut('slow', function() {
                        $(this).empty();
                    });
                }, 3000);
            }
        });
    });

    // 复制热评文字按钮点击事件
    $('.xb_wyreping_copy').on('click', function() {
        var content = $(this).data('content');
        var $button = $(this);
        var $notice = $('#xb_wyreping_notice');

        navigator.clipboard.writeText(content).then(function() {
            $button.addClass('copied').text('已复制');
            $notice.empty();
            setTimeout(function() {
                $button.removeClass('copied').text('复制');
            }, 2000);
        }).catch(function() {
            $notice.text('复制失败，请手动复制！').show();
            setTimeout(function() {
                $notice.fadeOut('slow', function() {
                    $notice.empty();
                });
            }, 3000);
        });
    });
});