<?php
/*
Plugin Name: 小半作品著作权查询
Description: 基于聚美智数实现查询作品的著作权信息。
Plugin URI: https://www.jingxialai.com/4983.html
Version: 1.0.2
Author: Summer
License: GPL License
Author URI: https://www.jingxialai.com/
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('XB_TM_WORK_PATH', plugin_dir_path(__FILE__));
define('XB_TM_WORK_URL', plugin_dir_url(__FILE__));

// 插件激活时创建数据表
register_activation_hook(__FILE__, 'xb_tm_work_create_tables');
function xb_tm_work_create_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 创建查询记录表
    $table_name = $wpdb->prefix . 'xb_tm_work_queries';
    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        query_result VARCHAR(20) NOT NULL,
        query_time DATETIME NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // 创建用户每日限制表
    $table_limit = $wpdb->prefix . 'xb_tm_work_user_limits';
    $sql_limit = "CREATE TABLE $table_limit (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        daily_limit INT NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id)
    ) $charset_collate;";
    dbDelta($sql_limit);
}

// 插件激活时检查并创建前台页面
register_activation_hook(__FILE__, 'xb_tm_work_create_frontend_page');
function xb_tm_work_create_frontend_page() {
    // 查询是否已有包含短代码 [xb_tm_work_copyright_query] 的页面
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_tm_work_copyright_query]',
        'numberposts' => 1,
    ));

    // 如果没有找到包含短代码的页面
    if (empty($pages)) {
        $page = array(
            'post_title'    => '作品著作权查询',
            'post_content'  => '[xb_tm_work_copyright_query]',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_author'   => 1,
        );
        wp_insert_post($page);
    }
}

// 加载前台 JS 和 CSS
add_action('wp_enqueue_scripts', 'xb_tm_work_enqueue_frontend_assets');
function xb_tm_work_enqueue_frontend_assets() {
    global $post;

    // 检查当前页面是否包含 [xb_tm_work_copyright_query] 短代码
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_tm_work_copyright_query')) {
        wp_enqueue_style('xb-tm-work-style', XB_TM_WORK_URL . 'assets/xb-tm-work-style.css', array(), '1.0.2');
        wp_enqueue_script('xb-tm-work-script', XB_TM_WORK_URL . 'assets/xb-tm-work-script.js', array('jquery'), '1.0.2', true);
        
        // 传递 REST API nonce、URL、每日限制和登录页面 URL
        wp_localize_script('xb-tm-work-script', 'xbTmWork', array(
            'ajaxurl' => rest_url('xb-tm-work/v1'),
            'nonce' => wp_create_nonce('wp_rest'),
            'user_id' => get_current_user_id(),
            'daily_limit' => (int) get_option('xb_tm_work_daily_limit', 10),
            'login_url' => wp_login_url(get_permalink()),
        ));
    }
}

// 注册 REST API 路由
add_action('rest_api_init', 'xb_tm_work_register_rest_routes');
function xb_tm_work_register_rest_routes() {
    // 定义权限回调函数
    $permission_callback = function ($request) {
        if (!is_user_logged_in() || !current_user_can('read')) {
            return new WP_Error('rest_forbidden', '您没有权限访问此接口', array('status' => 403));
        }
        return true;
    };

    // 查询著作权信息
    register_rest_route('xb-tm-work/v1', '/query', array(
        'methods' => 'POST',
        'callback' => 'xb_tm_work_handle_query',
        'permission_callback' => $permission_callback,
    ));

    // 获取用户剩余查询次数
    register_rest_route('xb-tm-work/v1', '/remaining-queries', array(
        'methods' => 'GET',
        'callback' => 'xb_tm_work_get_remaining_queries',
        'permission_callback' => $permission_callback,
    ));
}

// 处理查询请求
function xb_tm_work_handle_query($request) {
    $user_id = get_current_user_id();
    $keyword = sanitize_text_field($request['keyword']);
    $page_no = intval($request['frontend_page_no']) ?: 1;

    // 检查每日查询次数限制
    $remaining = xb_tm_work_get_remaining_queries_for_user($user_id);
    if ($remaining <= 0) {
        return new WP_REST_Response(array(
            'code' => 1001, // 使用独立错误码避免与官方605冲突
            'msg' => '今日使用次数已经用完了，请明天再来',
        ), 403);
    }

    // 获取 API 配置
    $app_code = get_option('xb_tm_work_app_code');
    if (!$app_code) {
        return new WP_REST_Response(array(
            'code' => 601,
            'msg' => 'API 配置未设置',
        ), 500);
    }

    // 构造请求参数
    $url = "https://jumwork.market.alicloudapi.com/copyright/work/list";
    $page_size = 10; // API 每页最大记录数（官方文档：默认10，最大10）
    $query_result = '失败';

    // 缓存键（包含用户、关键词和页码）
    $cache_key = 'xb_tm_work_query_' . md5($user_id . $keyword . $page_no);
    $cached_data = get_transient($cache_key);

    // 添加查询锁，防止并发重复请求
    $lock_key = 'xb_tm_work_lock_' . md5($user_id . $keyword . $page_no);
    if (get_transient($lock_key)) {
        return new WP_REST_Response(array(
            'code' => 609,
            'msg' => '请求过于频繁，请稍后再试',
        ), 429);
    }
    set_transient($lock_key, true, 5); // 锁5秒

    if ($cached_data !== false) {
        $results = $cached_data['results'];
        $total_records = $cached_data['total_records'];
        $query_result = '成功';
    } else {
        $params = array(
            'keyword' => $keyword,
            'pageNo' => $page_no,
            'pageSize' => $page_size,
        );

        // 调试日志
        error_log("API Request: pageNo=$page_no, keyword=$keyword, cache_key=$cache_key");

        // 发送请求
        $response = wp_remote_post($url, array(
            'method' => 'POST',
            'body' => http_build_query($params),
            'headers' => array(
                'Authorization' => 'APPCODE ' . $app_code,
                'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8',
            ),
            'sslverify' => false,
            'timeout' => 10,
        ));

        if (is_wp_error($response)) {
            delete_transient($lock_key);
            error_log("API Error: " . $response->get_error_message());
            return new WP_REST_Response(array(
                'code' => 500,
                'msg' => '网络请求失败: ' . $response->get_error_message(),
            ), 500);
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            delete_transient($lock_key);
            error_log("JSON Parse Error");
            return new WP_REST_Response(array(
                'code' => 500,
                'msg' => '响应解析失败',
            ), 500);
        }

        error_log("API Response: " . print_r($body, true));

        if (!$body['success'] || $body['code'] !== 200) {
            delete_transient($lock_key);
            return new WP_REST_Response($body, 200);
        }

        // 获取结果
        $data = $body['data'];
        $results = $data['items'] ?? [];
        $total_records = $data['page']['recordCount'] ?? 0;
        $query_result = '成功';

        // 缓存结果（5分钟）
        set_transient($cache_key, array(
            'results' => $results,
            'total_records' => $total_records,
        ), 5 * MINUTE_IN_SECONDS);
    }

    // 释放锁
    delete_transient($lock_key);

    // 记录查询
    global $wpdb;
    $wpdb->insert(
        $wpdb->prefix . 'xb_tm_work_queries',
        array(
            'user_id' => $user_id,
            'query_result' => $query_result,
            'query_time' => current_time('mysql'),
        )
    );

    // 构造返回数据
    $response_data = array(
        'code' => 200,
        'msg' => '成功',
        'charge' => true,
        'taskNo' => uniqid(),
        'data' => array(
            'page' => array(
                'pageNo' => $page_no,
                'pageSize' => $page_size,
                'recordCount' => $total_records,
            ),
            'items' => $results,
        ),
    );

    return new WP_REST_Response($response_data, 200);
}

// 获取用户剩余查询次数
function xb_tm_work_get_remaining_queries($request) {
    $user_id = get_current_user_id();
    $remaining = xb_tm_work_get_remaining_queries_for_user($user_id);
    return new WP_REST_Response(array('remaining' => $remaining), 200);
}

function xb_tm_work_get_remaining_queries_for_user($user_id) {
    global $wpdb;
    $default_limit = (int) get_option('xb_tm_work_daily_limit', 10);

    // 检查是否有用户特定的限制
    $table_limit = $wpdb->prefix . 'xb_tm_work_user_limits';
    $user_limit = $wpdb->get_var($wpdb->prepare(
        "SELECT daily_limit FROM $table_limit WHERE user_id = %d",
        $user_id
    ));
    $daily_limit = $user_limit ?: $default_limit;

    // 计算今日查询次数
    $today_start = date('Y-m-d 00:00:00');
    $table_queries = $wpdb->prefix . 'xb_tm_work_queries';
    $used_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_queries WHERE user_id = %d AND query_result = '成功' AND query_time >= %s",
        $user_id,
        $today_start
    ));

    return max(0, $daily_limit - $used_count);
}

// 注册短代码
add_shortcode('xb_tm_work_copyright_query', 'xb_tm_work_render_frontend');
function xb_tm_work_render_frontend() {
    ob_start();
    ?>
    <div class="xb-tm-work-container">
        <div class="xb-tm-work-title">企业作品著作权查询</div>
        
        <?php if (!is_user_logged_in()) : ?>
            <div class="xb-tm-work-notice">
                请先登录
                <button class="xb-tm-work-login-btn" data-href="<?php echo esc_url(wp_login_url(get_permalink())); ?>">快速登录</button>
            </div>
            <?php
            $announcement = get_option('xb_tm_work_announcement');
            if ($announcement) : ?>
                <div class="xb-tm-work-announcement"><?php echo wp_kses_post($announcement); ?></div>
            <?php endif; ?>
        <?php else : ?>
            <?php
            $user_id = get_current_user_id();
            $remaining = xb_tm_work_get_remaining_queries_for_user($user_id);
            $daily_limit = (int) get_option('xb_tm_work_daily_limit', 10);
            $hide_query_section = $remaining <= 0;
            ?>

            <?php if (!$hide_query_section) : ?>
                <div class="xb-tm-work-query-section">
                    <input type="text" id="xb-tm-work-keyword" placeholder="请输入企业名称、注册号或社会统一信用代码" />
                    <button id="xb-tm-work-query-btn">查询</button>
                </div>
            <?php endif; ?>

            <div class="xb-tm-work-results" id="xb-tm-work-results">
                <div class="xb-tm-work-subtitle">查询结果</div>
                <div class="xb-tm-work-loading" id="xb-tm-work-loading" style="display: none;">
                    正在查询中...
                </div>
            </div>

            <div class="xb-tm-work-usage">
                <?php if ($remaining > 0) : ?>
                    今日剩余查询次数：<span id="xb-tm-work-remaining"><?php echo $remaining; ?></span>/<?php echo $daily_limit; ?>
                <?php else : ?>
                    今日使用次数已经用完了，请明天再来
                <?php endif; ?>
            </div>

            <?php
            $announcement = get_option('xb_tm_work_announcement');
            if ($announcement) : ?>
                <div class="xb-tm-work-announcement"><?php echo wp_kses_post($announcement); ?></div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

// 注册后台菜单
add_action('admin_menu', 'xb_tm_work_admin_menu');
function xb_tm_work_admin_menu() {
    add_menu_page(
        '作品著作权查询',
        '作品著作权',
        'manage_options',
        'xb-tm-work-settings',
        'xb_tm_work_settings_page'
    );
    add_submenu_page(
        'xb-tm-work-settings',
        '用户查询记录',
        '用户查询',
        'manage_options',
        'xb-tm-work-user-queries',
        'xb_tm_work_user_queries_page'
    );
}

// 设置页面
function xb_tm_work_settings_page() {
    if (isset($_POST['xb_tm_work_save_settings'])) {
        update_option('xb_tm_work_app_code', sanitize_text_field($_POST['xb_tm_work_app_code']));
        update_option('xb_tm_work_daily_limit', intval($_POST['xb_tm_work_daily_limit']));
        update_option('xb_tm_work_announcement', wp_kses_post($_POST['xb_tm_work_announcement']));
        echo '<div class="updated xb-tm-work-admin-notice"><p>设置已保存</p></div>';
        echo '<script type="text/javascript">
            setTimeout(function() {
                var notice = document.querySelector(".xb-tm-work-admin-notice");
                if (notice) {
                    notice.style.transition = "opacity 0.5s ease-out";
                    notice.style.opacity = "0";
                }
            }, 3000);
        </script>';
    }
    ?>
    <div class="wrap">
        <h1>小半作品著作权 设置</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>AppCode</th>
                    <td><input type="text" name="xb_tm_work_app_code" value="<?php echo esc_attr(get_option('xb_tm_work_app_code')); ?>" /></td>
                </tr>
                <tr>
                    <th>每日查询限制</th>
                    <td><input type="number" name="xb_tm_work_daily_limit" value="<?php echo esc_attr(get_option('xb_tm_work_daily_limit', 10)); ?>" /></td>
                </tr>
                <tr>
                    <th>公告内容</th>
                    <td><textarea name="xb_tm_work_announcement" rows="5" cols="50"><?php echo esc_textarea(get_option('xb_tm_work_announcement')); ?></textarea></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="xb_tm_work_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        基于阿里市场的聚美智数https://market.aliyun.com/apimarket/detail/cmapi00049445#sku=yuncode4344500007 <br>
    </div>
    <?php
}

// 用户查询记录页面
function xb_tm_work_user_queries_page() {
    global $wpdb;
    $table_queries = $wpdb->prefix . 'xb_tm_work_queries';
    $table_limits = $wpdb->prefix . 'xb_tm_work_user_limits';
    $default_limit = (int) get_option('xb_tm_work_daily_limit', 10);

    // 处理删除记录
    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['query_id'])) {
        $wpdb->delete($table_queries, array('id' => intval($_GET['query_id'])));
        echo '<div class="updated xb-tm-work-admin-notice"><p>记录已删除</p></div>';
        echo '<script type="text/javascript">
            setTimeout(function() {
                var notice = document.querySelector(".xb-tm-work-admin-notice");
                if (notice) {
                    notice.style.transition = "opacity 0.5s ease-out";
                    notice.style.opacity = "0";
                }
            }, 3000);
        </script>';
    }

    // 处理用户限额设置
    if (isset($_POST['xb_tm_work_set_user_limit'])) {
        $user_id = intval($_POST['user_id']);
        $new_limit = intval($_POST['new_limit']);
        $wpdb->replace(
            $table_limits,
            array('user_id' => $user_id, 'daily_limit' => $new_limit),
            array('%d', '%d')
        );
        echo '<div class="updated xb-tm-work-admin-notice"><p>用户限额已设置</p></div>';
        echo '<script type="text/javascript">
            setTimeout(function() {
                var notice = document.querySelector(".xb-tm-work-admin-notice");
                if (notice) {
                    notice.style.transition = "opacity 0.5s ease-out";
                    notice.style.opacity = "0";
                }
            }, 3000);
        </script>';
    }

    // 处理恢复默认限额
    if (isset($_GET['action']) && $_GET['action'] == 'reset_limit' && isset($_GET['user_id'])) {
        $wpdb->delete($table_limits, array('user_id' => intval($_GET['user_id'])));
        echo '<div class="updated xb-tm-work-admin-notice"><p>已恢复默认限额</p></div>';
        echo '<script type="text/javascript">
            setTimeout(function() {
                var notice = document.querySelector(".xb-tm-work-admin-notice");
                if (notice) {
                    notice.style.transition = "opacity 0.5s ease-out";
                    notice.style.opacity = "0";
                }
            }, 3000);
        </script>';
    }

    // 查询条件
    $user_id_filter = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $per_page = 20;
    $offset = ($paged - 1) * $per_page;

    $where = '';
    if ($user_id_filter) {
        $where = $wpdb->prepare('WHERE user_id = %d', $user_id_filter);
    }

    // 获取查询记录
    $total_queries = $wpdb->get_var("SELECT COUNT(*) FROM $table_queries $where");
    $queries = $wpdb->get_results("SELECT * FROM $table_queries $where ORDER BY query_time DESC LIMIT $offset, $per_page");

    // 计算总查询次数
    $total_all_queries = $wpdb->get_var("SELECT COUNT(*) FROM $table_queries");

    // 如果筛选了用户，计算用户统计信息
    $user_stats = array();
    if ($user_id_filter) {
        $today_start = date('Y-m-d 00:00:00');
        $used_today = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_queries WHERE user_id = %d AND query_result = '成功' AND query_time >= %s",
            $user_id_filter,
            $today_start
        ));
        $total_user_queries = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_queries WHERE user_id = %d",
            $user_id_filter
        ));
        $user_limit = $wpdb->get_var($wpdb->prepare(
            "SELECT daily_limit FROM $table_limits WHERE user_id = %d",
            $user_id_filter
        ));
        $daily_limit = $user_limit ?: $default_limit;

        $user_stats = array(
            'used_today' => $used_today,
            'daily_limit' => $daily_limit,
            'total_queries' => $total_user_queries,
        );
    }
    ?>
    <div class="wrap">
        <h1>用户查询记录</h1>
        <p>网站总共查询次数：<?php echo $total_all_queries; ?></p>

        <form method="get" action="">
            <input type="hidden" name="page" value="xb-tm-work-user-queries">
            <p>
                <label>用户 ID：</label>
                <input type="number" name="user_id" value="<?php echo $user_id_filter; ?>">
                <input type="submit" class="button" value="筛选">
            </p>
        </form>

        <?php if ($user_id_filter && $user_stats) : ?>
            <h3>用户统计</h3>
            <p>今日已使用次数：<?php echo $user_stats['used_today']; ?></p>
            <p>每日限额：<?php echo $user_stats['daily_limit']; ?></p>
            <p>总共查询次数：<?php echo $user_stats['total_queries']; ?></p>

            <form method="post">
                <p>
                    <label>设置用户每日限额：</label>
                    <input type="number" name="new_limit" required>
                    <input type="hidden" name="user_id" value="<?php echo $user_id_filter; ?>">
                    <input type="submit" name="xb_tm_work_set_user_limit" class="button" value="设置限额">
                    <a href="<?php echo add_query_arg(array('action' => 'reset_limit', 'user_id' => $user_id_filter)); ?>" class="button">恢复默认限额</a>
                </p>
            </form>
        <?php endif; ?>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>用户名</th>
                    <th>查询结果</th>
                    <th>处理时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($queries as $query) : ?>
                    <tr>
                        <td><?php echo $query->user_id; ?></td>
                        <td><?php echo get_userdata($query->user_id)->user_login; ?></td>
                        <td><?php echo $query->query_result; ?></td>
                        <td><?php echo $query->query_time; ?></td>
                        <td><a href="<?php echo add_query_arg(array('action' => 'delete', 'query_id' => $query->id)); ?>" class="button">删除</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <?php
        $total_pages = ceil($total_queries / $per_page);
        if ($total_pages > 1) {
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'total' => $total_pages,
                'current' => $paged,
            ));
        }
        ?>
    </div>
    <?php
}
?>