jQuery(document).ready(function($) {
    // 定义错误码到用户友好消息的映射
    var errorMessages = {
        400: '请求参数错误，请检查输入',
        404: '查询错误，请联系管理员检查',
        500: '服务维护中，请稍后再试',
        601: '查询错误，请联系管理员检查',
        602: '查询错误，请联系管理员检查',
        603: '查询错误，请联系管理员检查',
        604: '查询错误，请联系管理员检查',
        605: '查询错误，请联系管理员检查',
        606: '调用频率过高，请稍后再试',
        607: '查询错误，请联系管理员检查',
        609: '请求过于频繁，请稍后再试',
        610: '请求超时，请稍后再试',
        999: '未知错误，请稍后再试',
        1001: '今日查询次数已用完，请明天再来'
    };

    // 更新剩余查询次数
    function updateRemainingQueries() {
        $.ajax({
            url: xbTmWork.ajaxurl + '/remaining-queries',
            method: 'GET',
            headers: {
                'X-WP-Nonce': xbTmWork.nonce
            },
            success: function(response) {
                
                var remaining = response.remaining !== undefined ? response.remaining : 0;
                var dailyLimit = xbTmWork.daily_limit;
                var $usage = $('.xb-tm-work-usage');
                
                if (remaining > 0) {
                    $usage.html('今日剩余查询次数：<span id="xb-tm-work-remaining">' + remaining + '</span>/' + dailyLimit);
                } else {
                    $usage.html('今日使用次数已经用完了，请明天再来');
                }
            },
            error: function(xhr) {
                
                $('.xb-tm-work-usage').html('无法获取剩余查询次数，请刷新页面');
            }
        });
    }

    // 查询按钮点击事件
    $('#xb-tm-work-query-btn').on('click', function() {
        var keyword = $('#xb-tm-work-keyword').val().trim();
        if (!keyword) {
            alert('请输入企业名称、注册号或社会统一信用代码');
            return;
        }

        $('#xb-tm-work-loading').show();
        $('#xb-tm-work-results').find('.xb-tm-work-card-container, .xb-tm-work-pagination, .xb-tm-work-error, .xb-tm-work-no-results, .xb-tm-work-count').remove();

        $.ajax({
            url: xbTmWork.ajaxurl + '/query',
            method: 'POST',
            headers: {
                'X-WP-Nonce': xbTmWork.nonce
            },
            data: {
                keyword: keyword,
                frontend_page_no: 1
            },
            success: function(response) {
                $('#xb-tm-work-loading').hide();
                renderResults(response);
                updateRemainingQueries();
            },
            error: function(xhr) {
                $('#xb-tm-work-loading').hide();
                var errorData = xhr.responseJSON || {};
                var errorCode = errorData.code || 999;
                var errorMsg = errorMessages[errorCode] || errorData.msg || '查询失败，请稍后再试';
                $('#xb-tm-work-results').append('<div class="xb-tm-work-error">' + errorMsg + '</div>');
                
            }
        });
    });

    // 分页点击事件
    $(document).on('click', '.xb-tm-work-page-link', function(e) {
        e.preventDefault();
        var pageNo = $(this).data('page');
        var keyword = $('#xb-tm-work-keyword').val().trim();

        $('#xb-tm-work-loading').show();
        $('#xb-tm-work-results').find('.xb-tm-work-card-container, .xb-tm-work-pagination, .xb-tm-work-error, .xb-tm-work-no-results, .xb-tm-work-count').remove();

        $.ajax({
            url: xbTmWork.ajaxurl + '/query',
            method: 'POST',
            headers: {
                'X-WP-Nonce': xbTmWork.nonce
            },
            data: {
                keyword: keyword,
                frontend_page_no: pageNo
            },
            success: function(response) {
                $('#xb-tm-work-loading').hide();
                renderResults(response);
                updateRemainingQueries();
            },
            error: function(xhr) {
                $('#xb-tm-work-loading').hide();
                var errorData = xhr.responseJSON || {};
                var errorCode = errorData.code || 999;
                var errorMsg = errorMessages[errorCode] || errorData.msg || '查询失败，请稍后再试';
                $('#xb-tm-work-results').append('<div class="xb-tm-work-error">' + errorMsg + '</div>');
                
            }
        });
    });

    // 快速登录按钮点击事件
    $('.xb-tm-work-login-btn').on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('data-href');
        }
    });

    // 渲染查询结果
    function renderResults(response) {

        if (response.code !== 200) {
            var errorCode = response.code || 999;
            var errorMsg = errorMessages[errorCode] || response.msg || '查询失败，请稍后再试';
            $('#xb-tm-work-results').append('<div class="xb-tm-work-error">' + errorMsg + '</div>');
            return;
        }

        var data = response.data;
        var results = data.items || [];
        var page = data.page || {};
        var pageSize = page.pageSize || 10;
        var totalRecords = page.recordCount || 0;
        var currentPage = page.pageNo || 1;
        var totalPages = Math.ceil(totalRecords / pageSize);

        // 显示查询结果总数
        $('#xb-tm-work-results').append('<div class="xb-tm-work-count">共查询到 ' + totalRecords + ' 条结果</div>');

        if (!Array.isArray(results) || results.length === 0) {
            $('#xb-tm-work-results').append('<div class="xb-tm-work-no-results">无查询结果</div>');
            return;
        }

        // 渲染卡片式布局
        var cardContainer = $('<div class="xb-tm-work-card-container"></div>');

        $.each(results, function(i, item) {
            var card = $('<div class="xb-tm-work-card"></div>');
            card.append('<h3>' + (item.Name || '-') + '</h3>');
            card.append('<p><strong>著作权人：</strong>' + (item.Owner || '-') + '</p>');
            card.append('<p><strong>作品类别：</strong>' + (item.Category || '-') + '</p>');
            card.append('<p><strong>登记号：</strong>' + (item.RegisterNo || '-') + '</p>');
            card.append('<p><strong>登记日期：</strong>' + (item.RegisterDate || '-') + '</p>');
            card.append('<p><strong>创作完成日期：</strong>' + (item.FinishDate || '-') + '</p>');
            card.append('<p><strong>首次发表日期：</strong>' + (item.PublishDate || '-') + '</p>');
            cardContainer.append(card);
        });

        $('#xb-tm-work-results').append(cardContainer);

        // 渲染分页
        if (totalPages > 1) {
            var pagination = $('<div class="xb-tm-work-pagination"></div>');

            // 上一页
            if (currentPage > 1) {
                pagination.append('<a href="#" class="xb-tm-work-page-link" data-page="' + (currentPage - 1) + '">上一页</a>');
            }

            // 页码
            var startPage = Math.max(1, currentPage - 2);
            var endPage = Math.min(totalPages, currentPage + 2);
            if (startPage > 1) {
                pagination.append('<a href="#" class="xb-tm-work-page-link" data-page="1">1</a>');
                if (startPage > 2) pagination.append('<span>...</span>');
            }
            for (var i = startPage; i <= endPage; i++) {
                if (i === currentPage) {
                    pagination.append('<span class="xb-tm-work-page-current">' + i + '</span>');
                } else {
                    pagination.append('<a href="#" class="xb-tm-work-page-link" data-page="' + i + '">' + i + '</a>');
                }
            }
            if (endPage < totalPages) {
                if (endPage < totalPages - 1) pagination.append('<span>...</span>');
                pagination.append('<a href="#" class="xb-tm-work-page-link" data-page="' + totalPages + '">' + totalPages + '</a>');
            }

            // 下一页
            if (currentPage < totalPages) {
                pagination.append('<a href="#" class="xb-tm-work-page-link" data-page="' + (currentPage + 1) + '">下一页</a>');
            }

            $('#xb-tm-work-results').append(pagination);
        }
    }

    // 页面加载时初始化剩余查询次数
    updateRemainingQueries();
});