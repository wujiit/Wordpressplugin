<?php
/*
Plugin Name: 小半AI图像编辑
Description: 基于阿里通义千问的 WordPress 图像编辑插件
Version: 1.0.2
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时创建数据表
register_activation_hook(__FILE__, 'xb_imageedit_create_tables');
function xb_imageedit_create_tables() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_imageedit_records';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        original_image_url VARCHAR(255) NOT NULL,
        processed_time DATETIME NOT NULL,
        status VARCHAR(20) DEFAULT 'pending',
        error_message TEXT NULL,
        result_url VARCHAR(255) NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    $table_examples = $wpdb->prefix . 'xb_imageedit_examples';
    $sql_examples = "CREATE TABLE $table_examples (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        function_name VARCHAR(100) NOT NULL,
        input_image_url VARCHAR(255) NOT NULL,
        prompt TEXT NOT NULL,
        output_image_url VARCHAR(255) NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql_examples);
}

// 插件激活时创建前端页面
register_activation_hook(__FILE__, 'xb_imageedit_create_page');
function xb_imageedit_create_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_imageedit_frontend]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        wp_insert_post(array(
            'post_title'    => 'AI多功能图像处理',
            'post_content'  => '[xb_imageedit_frontend]',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        ));
    }
}

// 检查页面是否包含短代码
function xb_imageedit_has_shortcode($shortcode) {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, $shortcode)) {
        return true;
    }
    return false;
}

// 加载前端脚本和样式
add_action('wp_enqueue_scripts', 'xb_imageedit_enqueue_scripts');
function xb_imageedit_enqueue_scripts() {
    if (xb_imageedit_has_shortcode('xb_imageedit_frontend')) {

        //wp_enqueue_style('xb-imageedit-style', 'https://img.qiyucloud.com/cloud/xb-image-editor/xb-image-editor.css', array(), '1.0.2');
        //wp_enqueue_script('xb-imageedit-script', 'https://img.qiyucloud.com/cloud/xb-image-editor/xb-image-editor.js', array('jquery'), '1.0.2', true);

        wp_enqueue_style('xb-imageedit-style', plugin_dir_url(__FILE__) . 'xb-image-editor.css', array(), '1.2');
        wp_enqueue_script('xb-imageedit-script', plugin_dir_url(__FILE__) . 'xb-image-editor.js', array('jquery'), '1.2', true);
        wp_localize_script('xb-imageedit-script', 'xb_imageedit_vars', array(
            'rest_url' => rest_url('xb-imageedit/v1/'),
            'nonce'    => wp_create_nonce('wp_rest'),
            'login_url' => wp_login_url(get_permalink()),
        ));
    }
}

// 注册 REST API 端点
add_action('rest_api_init', 'xb_imageedit_register_rest_routes');
function xb_imageedit_register_rest_routes() {
    register_rest_route('xb-imageedit/v1', '/upload', array(
        'methods'  => 'POST',
        'callback' => 'xb_imageedit_handle_upload',
        'permission_callback' => function() {
            return is_user_logged_in();
        },
    ));

    register_rest_route('xb-imageedit/v1', '/process', array(
        'methods'  => 'POST',
        'callback' => 'xb_imageedit_process_image',
        'permission_callback' => function() {
            return is_user_logged_in();
        },
    ));
}

// 处理图片上传
function xb_imageedit_handle_upload($request) {
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    // 检查 PHP 上传限制
    $php_max_upload = min(
        wp_convert_hr_to_bytes(ini_get('upload_max_filesize')),
        wp_convert_hr_to_bytes(ini_get('post_max_size'))
    );
    $options = get_option('xb_imageedit_settings');
    $max_size = (int)($options['max_size'] ?? 5) * 1024 * 1024; // 插件设置的最大值（字节）
    $effective_max_size = min($php_max_upload, $max_size); // 取最小值
    $effective_max_size_mb = $effective_max_size / (1024 * 1024); // 转换为 MB

    if (!isset($_FILES['file'])) {
        return new WP_Error('no_file', '未选择文件', array('status' => 400));
    }

    $file = $_FILES['file'];

    // 检查文件大小是否超过限制
    if ($file['size'] > $effective_max_size) {
        return new WP_Error('file_too_large', "图片太大，请上传 {$effective_max_size_mb}MB 以内的图片", array('status' => 400));
    }

    // 检查文件扩展名
    $allowed_formats = array_map('trim', explode(',', $options['allowed_formats'] ?? 'jpg,png,webp'));
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($file_ext, $allowed_formats)) {
        return new WP_Error('invalid_format', '不支持此格式的图片，仅支持 ' . implode(', ', $allowed_formats), array('status' => 400));
    }

    // 检查真实文件类型（防止伪装文件）
    $file_path = $file['tmp_name'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE); // 创建文件信息资源
    $mime_type = finfo_file($finfo, $file_path); // 获取真实 MIME 类型
    finfo_close($finfo);

    // 定义允许的 MIME 类型与扩展名的映射
    $allowed_mime_types = array(
        'jpg'  => 'image/jpeg',
        'png'  => 'image/png',
        'webp' => 'image/webp',
    );

    // 检查 MIME 类型是否与扩展名匹配
    if (!isset($allowed_mime_types[$file_ext]) || $allowed_mime_types[$file_ext] !== $mime_type) {
        return new WP_Error('invalid_image', '文件格式不正确，请上传真实的图片文件', array('status' => 400));
    }

    // 上传文件
    $upload = wp_handle_upload($file, array('test_form' => false));
    if (isset($upload['error'])) {
        return new WP_Error('upload_error', $upload['error'], array('status' => 500));
    }

    // 创建附件
    $attachment = array(
        'post_mime_type' => $upload['type'],
        'post_title'     => basename($file['name']),
        'post_content'   => '',
        'post_status'    => 'inherit',
    );
    $attach_id = wp_insert_attachment($attachment, $upload['file']);
    $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
    wp_update_attachment_metadata($attach_id, $attach_data);

    return array(
        'success' => true,
        'data' => array(
            'id'  => $attach_id,
            'url' => wp_get_attachment_url($attach_id),
            'ext' => $file_ext,
        ),
    );
}

// 处理图像编辑请求
function xb_imageedit_process_image($request) {
    $user_id = get_current_user_id();
    $options = get_option('xb_imageedit_settings');
    $daily_limit = !empty($options['daily_limit']) ? intval($options['daily_limit']) : 10;
    $user_custom_limit = get_user_meta($user_id, 'xb_imageedit_custom_limit', true);
    $limit = $user_custom_limit ? intval($user_custom_limit) : $daily_limit;

    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_imageedit_records';

    // 检查今日已成功处理的次数（只计算成功的）
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(processed_time) = CURDATE() AND status = 'success'",
        $user_id
    ));

    // 调试日志：记录初始计数
    error_log("XB_ImageEdit: Initial successful count for user $user_id on CURDATE(): $count");

    if ($count >= $limit) {
        error_log("XB_ImageEdit: User $user_id has reached the daily limit: $count/$limit");
        return new WP_Error('limit_exceeded', '已达到每日编辑次数限制', array('status' => 403));
    }

    $image_id = $request['image_id'];
    $function = sanitize_text_field($request['function']);
    $prompt = sanitize_text_field($request['prompt']);
    $image_url = wp_get_attachment_url($image_id);

    // 验证功能是否在允许的列表中
    $allowed_functions = array_filter(explode(',', $options['enabled_functions']));
    if (!$image_url || !$function || !$prompt || !in_array($function, $allowed_functions)) {
        error_log("XB_ImageEdit: Invalid input parameters: image_id=$image_id, function=$function, prompt=$prompt, allowed_functions=" . implode(',', $allowed_functions));
        return new WP_Error('invalid_input', '无效的输入参数或功能未启用', array('status' => 400));
    }

    // 先插入处理记录（状态为pending）
    $processed_time = current_time('mysql');
    $insert_result = $wpdb->insert($table_name, array(
        'user_id'            => $user_id,
        'original_image_url' => $image_url,
        'processed_time'     => $processed_time,
        'status'             => 'pending',
    ), array('%d', '%s', '%s', '%s'));

    if ($insert_result === false) {
        error_log("XB_ImageEdit: Failed to insert record for user $user_id: " . $wpdb->last_error);
        return new WP_Error('db_error', '无法记录处理操作: ' . $wpdb->last_error, array('status' => 500));
    }

    $record_id = $wpdb->insert_id;
    error_log("XB_ImageEdit: Inserted pending record ID: $record_id for user $user_id at $processed_time");

    $api_key = $options['api_key'];
    $model = explode(',', $options['models'])[0];
    
    // 记录API请求的原始数据
    $api_request_data = array(
        'model' => $model,
        'input' => array(
            'function' => $function,
            'prompt' => $prompt,
            'base_image_url' => $image_url,
        ),
        'parameters' => array('n' => 1),
    );
    error_log("XB_ImageEdit: API Request Data: " . json_encode($api_request_data, JSON_UNESCAPED_UNICODE));
    
    $response = xb_imageedit_call_tongyi_api($image_url, $function, $prompt, $api_key, $model);

    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        error_log("XB_ImageEdit: API call failed: " . $error_message);
        
        // 更新记录状态为失败
        $wpdb->update($table_name, array(
            'status' => 'failed',
            'error_message' => $error_message,
        ), array('id' => $record_id), array('%s', '%s'), array('%d'));
        
        // 前台不显示具体错误，统一显示维护信息
        return new WP_Error('maintenance', '系统暂时维护中，请联系客服', array('status' => 500));
    }

    // 处理成功，更新记录状态
    $wpdb->update($table_name, array(
        'status' => 'success',
        'result_url' => $response['url'],
    ), array('id' => $record_id), array('%s', '%s'), array('%d'));

    error_log("XB_ImageEdit: Successfully processed record ID: $record_id for user $user_id, result URL: " . $response['url']);

    // 重新计算成功的次数（只有成功的才计入限制）
    $new_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(processed_time) = CURDATE() AND status = 'success'",
        $user_id
    ));
    $remaining = $limit - $new_count;

    // 调试日志：记录计算出的剩余次数
    error_log("XB_ImageEdit: Updated remaining for user $user_id: $remaining (limit: $limit, new_count: $new_count)");

    return array(
        'success' => true,
        'data' => array(
            'result_url' => $response['url'],
            'remaining' => $remaining,
            'limit' => $limit,
        ),
    );
}

// 调用通义千问 API
function xb_imageedit_call_tongyi_api($image_url, $function, $prompt, $api_key, $model) {
    $args = array(
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => "Bearer $api_key",
            'X-DashScope-Async' => 'enable',
        ),
        'body' => json_encode(array(
            'model' => $model,
            'input' => array(
                'function' => $function,
                'prompt' => $prompt,
                'base_image_url' => $image_url,
            ),
            'parameters' => array('n' => 1),
        )),
        'timeout' => 30,
    );

    error_log("XB_ImageEdit: API Request URL: https://dashscope.aliyuncs.com/api/v1/services/aigc/image2image/image-synthesis");
    error_log("XB_ImageEdit: API Request Headers: " . json_encode($args['headers'], JSON_UNESCAPED_UNICODE));
    error_log("XB_ImageEdit: API Request Body: " . $args['body']);

    $response = wp_remote_post('https://dashscope.aliyuncs.com/api/v1/services/aigc/image2image/image-synthesis', $args);
    
    if (is_wp_error($response)) {
        error_log("XB_ImageEdit: HTTP Request Error: " . $response->get_error_message());
        return $response;
    }

    $response_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    error_log("XB_ImageEdit: API Response Code: $response_code");
    error_log("XB_ImageEdit: API Response Body: " . $body);

    $body_data = json_decode($body, true);
    if (!isset($body_data['output']) || $body_data['output']['task_status'] !== 'PENDING') {
        $error_msg = 'API任务创建失败: ' . ($body_data['message'] ?? '未知错误');
        error_log("XB_ImageEdit: Task creation failed: " . $error_msg);
        return new WP_Error('api_error', $error_msg, array('status' => 500));
    }

    $task_id = $body_data['output']['task_id'];
    error_log("XB_ImageEdit: Task created successfully, task_id: $task_id");

    // 轮询查询任务结果
    for ($i = 0; $i < 10; $i++) {
        sleep(5);
        $query_url = "https://dashscope.aliyuncs.com/api/v1/tasks/$task_id";
        error_log("XB_ImageEdit: Querying task result (attempt " . ($i + 1) . "): $query_url");
        
        $result = wp_remote_get($query_url, array(
            'headers' => array('Authorization' => "Bearer $api_key"),
        ));
        
        if (is_wp_error($result)) {
            error_log("XB_ImageEdit: Task query HTTP error: " . $result->get_error_message());
            return $result;
        }

        $result_code = wp_remote_retrieve_response_code($result);
        $result_body = wp_remote_retrieve_body($result);
        error_log("XB_ImageEdit: Task query response code: $result_code");
        error_log("XB_ImageEdit: Task query response body: " . $result_body);

        $result_body_data = json_decode($result_body, true);
        if (!isset($result_body_data['output'])) {
            $error_msg = '任务查询失败: ' . ($result_body_data['message'] ?? '未知错误');
            error_log("XB_ImageEdit: Task query failed: " . $error_msg);
            return new WP_Error('api_error', $error_msg, array('status' => 500));
        }

        $task_status = $result_body_data['output']['task_status'];
        error_log("XB_ImageEdit: Task status: $task_status");

        if ($task_status === 'SUCCEEDED') {
            $result_url = $result_body_data['output']['results'][0]['url'];
            error_log("XB_ImageEdit: Task succeeded, result URL: $result_url");
            return array('url' => $result_url);
        } elseif ($task_status === 'FAILED') {
            $error_msg = '任务处理失败: ' . ($result_body_data['output']['message'] ?? '未知错误');
            error_log("XB_ImageEdit: Task failed: " . $error_msg);
            return new WP_Error('api_error', $error_msg, array('status' => 500));
        }
    }
    
    error_log("XB_ImageEdit: Task timeout after 10 attempts");
    return new WP_Error('timeout', '处理超时', array('status' => 504));
}

// 获取用户今日剩余次数
function xb_imageedit_get_remaining_count() {
    $user_id = get_current_user_id();
    $options = get_option('xb_imageedit_settings');
    $daily_limit = !empty($options['daily_limit']) ? intval($options['daily_limit']) : 10;
    $user_custom_limit = get_user_meta($user_id, 'xb_imageedit_custom_limit', true);
    $limit = $user_custom_limit ? intval($user_custom_limit) : $daily_limit;

    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_imageedit_records';
    // 只计算成功的处理次数
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(processed_time) = CURDATE() AND status = 'success'",
        $user_id
    ));

    // 调试日志：记录初始页面加载时的计数
    error_log("XB_ImageEdit: Initial page load successful count for user $user_id on CURDATE(): $count");

    return array(
        'remaining' => $limit - $count,
        'limit' => $limit,
    );
}

// 前端短代码
add_shortcode('xb_imageedit_frontend', 'xb_imageedit_frontend_shortcode');
function xb_imageedit_frontend_shortcode() {
    $options = get_option('xb_imageedit_settings');
    $functions = array_filter(explode(',', $options['enabled_functions']));
    $function_options = '<option value="" disabled selected>请选择编辑功能</option>';
    foreach ($functions as $func) {
        $label = xb_imageedit_get_function_label($func);
        $function_options .= "<option value='$func'>$label</option>";
    }

    $formats = explode(',', $options['allowed_formats'] ?? 'jpg,png,webp');
    $accept = implode(',', array_map(function($format) { return '.' . trim($format); }, $formats));
    $count_data = xb_imageedit_get_remaining_count();

    global $wpdb;
    $table_examples = $wpdb->prefix . 'xb_imageedit_examples';
    $examples = $wpdb->get_results("SELECT * FROM $table_examples");

    ob_start();
    ?>
    <div class="xb-imageedit-wrapper">
        <div class="xb-imageedit-page-title">AI多功能图像处理</div>
        <?php if (!is_user_logged_in()) : ?>
            <div class="xb-imageedit-login-container">
                <div class="xb-imageedit-login-text">请先登录以使用图像编辑功能</div>
                <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xb-imageedit-login-btn">快速登录</a>
            </div>
            <?php echo xb_imageedit_render_notice(); ?>
        <?php else : ?>
            <div class="xb-imageedit-container <?php echo ($count_data['remaining'] <= 0) ? 'xb-imageedit-hidden' : ''; ?>">
                <div class="xb-imageedit-left">
                    <div class="xb-imageedit-section">
                        <label class="xb-imageedit-label">图像处理提示词</label>
                        <textarea id="xb-imageedit-prompt" class="xb-imageedit-input xb-imageedit-prompt" placeholder="请输入处理提示词"></textarea>
                    </div>
                    <div class="xb-imageedit-function-upload-row">
                        <div class="xb-imageedit-section xb-imageedit-function-section">
                            <label class="xb-imageedit-label">选择编辑功能</label>
                            <select id="xb-imageedit-function" class="xb-imageedit-input">
                                <?php echo $function_options; ?>
                            </select>
                        </div>
                        <div class="xb-imageedit-section xb-imageedit-upload-section">
                            <label class="xb-imageedit-label">上传需要处理的图片</label>
                            <button id="xb-imageedit-upload-btn" class="xb-imageedit-upload-btn">选择图片</button>
                            <input type="file" id="xb-imageedit-upload" accept="<?php echo esc_attr($accept); ?>" style="display:none;" />
                        </div>
                    </div>
                    <div class="xb-imageedit-section">
                        <div id="xb-imageedit-preview" class="xb-imageedit-preview"></div>
                    </div>
                </div>
                <div class="xb-imageedit-right">
                    <div class="xb-imageedit-process-wrapper">
                        <button id="xb-imageedit-process" class="xb-imageedit-process-btn" disabled>开始处理</button>
                    </div>
                    <div id="xb-imageedit-result" class="xb-imageedit-preview"></div>
                    <div id="xb-imageedit-download-wrapper" class="xb-imageedit-download-wrapper"></div>
                </div>
            </div>
            <div class="xb-imageedit-usage">
                <?php if ($count_data['remaining'] > 0) : ?>
                    今日剩余处理次数：<span class="xb-imageedit-remaining"><?php echo $count_data['remaining']; ?></span>/<?php echo $count_data['limit']; ?>
                <?php else : ?>
                    今日处理次数已经用完，请明天再来。
                <?php endif; ?>
            </div>
            <?php echo xb_imageedit_render_notice(); ?>
        <?php endif; ?>
        <?php if (!empty($examples)) : ?>
            <div class="xb-imageedit-examples">
                <div class="xb-imageedit-examples-title">效果示例教程</div>
                <table class="xb-imageedit-examples-table">
                    <thead>
                        <tr>
                            <th>功能</th>
                            <th>输入图像</th>
                            <th>输入提示词</th>
                            <th>成果图像</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($examples as $example) : ?>
                            <tr>
                                <td><?php echo esc_html(xb_imageedit_get_function_label($example->function_name)); ?></td>
                                <td><img src="<?php echo esc_url($example->input_image_url); ?>" alt="输入图像" class="xb-imageedit-example-img" /></td>
                                <td><?php echo esc_html($example->prompt); ?></td>
                                <td><img src="<?php echo esc_url($example->output_image_url); ?>" alt="输出图像" class="xb-imageedit-example-img" /></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

// 渲染公告
function xb_imageedit_render_notice() {
    $options = get_option('xb_imageedit_settings');
    if (!empty($options['notice'])) {
        return '<div class="xb-imageedit-notice">' . wp_kses_post($options['notice']) . '</div>';
    }
    return '';
}

// 获取功能标签
function xb_imageedit_get_function_label($function) {
    $labels = array(
        'stylization_all' => '全局风格化',
        'stylization_local' => '局部风格化',
        'remove_watermark' => '去文字水印',
        'super_resolution' => '提升分辨率',
        'colorization' => '图像变彩色',
        'description_edit' => '指令编辑',
        'doodle' => '线稿生图',
        'expand' => '扩图',
        'control_cartoon_feature' => '垫图',
    );
    return $labels[$function] ?? $function;
}

// 后台菜单
add_action('admin_menu', 'xb_imageedit_admin_menu');
function xb_imageedit_admin_menu() {
    add_menu_page('图像编辑设置', '图像编辑', 'manage_options', 'xb-imageedit-settings', 'xb_imageedit_settings_page');
    add_submenu_page('xb-imageedit-settings', '用户图像处理', '用户图像处理', 'manage_options', 'xb-imageedit-records', 'xb_imageedit_records_page');
    add_submenu_page('xb-imageedit-settings', '模型效果示例', '模型效果示例', 'manage_options', 'xb-imageedit-examples', 'xb_imageedit_examples_page');
}

// 后台设置页面
function xb_imageedit_settings_page() {
    if (isset($_POST['xb_imageedit_save'])) {
        check_admin_referer('xb_imageedit_settings');
        $options = array(
            'api_key' => sanitize_text_field($_POST['api_key']),
            'models' => sanitize_text_field($_POST['models']),
            'allowed_formats' => sanitize_text_field($_POST['allowed_formats']),
            'max_size' => intval($_POST['max_size']),
            'daily_limit' => intval($_POST['daily_limit']),
            'enabled_functions' => implode(',', array_map('sanitize_text_field', $_POST['functions'] ?? array())),
            'notice' => wp_kses_post($_POST['notice']),
        );
        update_option('xb_imageedit_settings', $options);
        echo '<div class="notice notice-success xb-imageedit-notice-auto"><p>设置已保存。</p></div>';
    }

    $options = get_option('xb_imageedit_settings');
    $all_functions = array(
        'stylization_all' => '全局风格化',
        'stylization_local' => '局部风格化',
        'remove_watermark' => '去文字水印',
        'super_resolution' => '提升分辨率',
        'colorization' => '图像变彩色',
        'description_edit' => '指令编辑',
        'doodle' => '线稿生图',
        'expand' => '扩图',
        'control_cartoon_feature' => '垫图',
    );
    ?>
    <div class="wrap">
        <h1 class="xb-imageedit-title">图像编辑设置</h1>
        <form method="post" action="">
            <?php wp_nonce_field('xb_imageedit_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label>API Key</label></th>
                    <td><input type="text" name="api_key" value="<?php echo esc_attr($options['api_key'] ?? ''); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th><label>模型参数</label></th>
                    <td><input type="text" name="models" value="<?php echo esc_attr($options['models'] ?? 'wanx2.1-imageedit'); ?>" class="regular-text" placeholder="多个模型用逗号分隔" /></td>
                </tr>
                <tr>
                    <th><label>支持的图片格式</label></th>
                    <td><input type="text" name="allowed_formats" value="<?php echo esc_attr($options['allowed_formats'] ?? 'jpg,png,webp'); ?>" class="regular-text" placeholder="如 jpg,png,webp" /></td>
                </tr>
                <tr>
                    <th><label>最大图片大小（MB）</label></th>
                    <td><input type="number" name="max_size" value="<?php echo esc_attr($options['max_size'] ?? 5); ?>" min="1" class="regular-text" /> <span>请输入数字，例如 5 表示 5MB</span></td>
                </tr>
                <tr>
                    <th><label>每日使用次数限制</label></th>
                    <td><input type="number" name="daily_limit" value="<?php echo esc_attr($options['daily_limit'] ?? 10); ?>" min="1" /></td>
                </tr>
                <tr>
                    <th><label>启用功能</label></th>
                    <td>
                        <?php foreach ($all_functions as $key => $label) : ?>
                            <label><input type="checkbox" name="functions[]" value="<?php echo $key; ?>" <?php checked(in_array($key, explode(',', $options['enabled_functions'] ?? ''))); ?>> <?php echo $label; ?></label><br>
                        <?php endforeach; ?>
                    </td>
                </tr>
                <tr>
                    <th><label>公告内容</label></th>
                    <td><textarea name="notice" rows="5" class="large-text"><?php echo esc_textarea($options['notice'] ?? ''); ?></textarea></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="xb_imageedit_save" class="button-primary" value="保存设置" /></p>
        </form>

        <!-- 嵌入样式和脚本 -->
        <style type="text/css">
            .xb-imageedit-title {
                font-size: 28px;
                color: #333;
                margin-bottom: 25px;
                font-weight: 600;
            }
            .xb-imageedit-notice-auto {
                opacity: 1;
                transition: opacity 0.5s ease;
            }
        </style>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // 自动隐藏提示消息
                $('.xb-imageedit-notice-auto').each(function() {
                    var $notice = $(this);
                    setTimeout(function() {
                        $notice.css('opacity', '0');
                        setTimeout(function() {
                            $notice.remove();
                        }, 500);
                    }, 3000);
                });
            });
        </script>
        由阿里通义千问模型提供：https://help.aliyun.com/zh/model-studio/user-guide/wanx-image-edit <br>
        单价: 0.14元一张
    </div>
    <?php
}

// 用户记录页面
function xb_imageedit_records_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_imageedit_records';
    $per_page = 20;
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $user_id_filter = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

    if (isset($_GET['delete']) && check_admin_referer('xb_imageedit_delete')) {
        $wpdb->delete($table_name, array('id' => intval($_GET['delete'])));
        echo '<div class="notice notice-success xb-imageedit-notice-auto"><p>记录已删除。</p></div>';
    }

    if (isset($_POST['xb_imageedit_user_limit']) && check_admin_referer('xb_imageedit_user_limit')) {
        update_user_meta($user_id_filter, 'xb_imageedit_custom_limit', intval($_POST['custom_limit']));
        echo '<div class="notice notice-success xb-imageedit-notice-auto"><p>用户限制已更新。</p></div>';
    }

    $where = $user_id_filter ? $wpdb->prepare('WHERE user_id = %d', $user_id_filter) : '';
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
    $records = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name $where ORDER BY processed_time DESC LIMIT %d OFFSET %d",
        $per_page, ($paged - 1) * $per_page
    ));

    if ($user_id_filter) {
        $today_success_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(processed_time) = CURDATE() AND status = 'success'",
            $user_id_filter
        ));
        $today_total_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(processed_time) = CURDATE()",
            $user_id_filter
        ));
        $total_user = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d", $user_id_filter));
        $options = get_option('xb_imageedit_settings');
        $default_limit = $options['daily_limit'] ?? 10;
        $custom_limit = get_user_meta($user_id_filter, 'xb_imageedit_custom_limit', true);
        $limit = $custom_limit ? $custom_limit : $default_limit;
    }
    ?>
    <div class="wrap">
        <h1 class="xb-imageedit-title">用户图像处理记录</h1>
        <p>网站总处理次数：<?php echo $total; ?></p>
        <form method="get" action="">
            <input type="hidden" name="page" value="xb-imageedit-records" />
            <label>查询用户ID：</label>
            <input type="number" name="user_id" value="<?php echo $user_id_filter; ?>" />
            <input type="submit" class="button" value="查询" />
        </form>
        <?php if ($user_id_filter) : ?>
            <p>当前用户今日成功处理次数：<?php echo $today_success_count; ?> / 限制：<?php echo $limit; ?>，今日总尝试次数：<?php echo $today_total_count; ?>，总处理次数：<?php echo $total_user; ?></p>
            <form method="post" action="">
                <?php wp_nonce_field('xb_imageedit_user_limit'); ?>
                <label>设置用户每日限制：</label>
                <input type="number" name="custom_limit" value="<?php echo $custom_limit ?: ''; ?>" placeholder="留空使用默认值" />
                <input type="submit" name="xb_imageedit_user_limit" class="button" value="保存" />
            </form>
        <?php endif; ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户ID</th>
                    <th>用户名</th>
                    <th>原始图片</th>
                    <th>处理时间</th>
                    <th>状态</th>
                    <th>结果图片</th>
                    <th>错误信息</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record) : ?>
                    <tr>
                        <td><?php echo $record->user_id; ?></td>
                        <td><?php echo get_userdata($record->user_id)->user_login; ?></td>
                        <td><img src="<?php echo esc_url($record->original_image_url); ?>" style="width:100px;height:100px;" /></td>
                        <td><?php echo $record->processed_time; ?></td>
                        <td>
                            <?php 
                            $status_labels = array(
                                'pending' => '<span style="color: orange;">处理中</span>',
                                'success' => '<span style="color: green;">成功</span>',
                                'failed' => '<span style="color: red;">失败</span>'
                            );
                            echo $status_labels[$record->status] ?? $record->status;
                            ?>
                        </td>
                        <td>
                            <?php if ($record->result_url) : ?>
                                <img src="<?php echo esc_url($record->result_url); ?>" style="width:100px;height:100px;" />
                            <?php else : ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($record->error_message) : ?>
                                <div style="max-width: 200px; word-wrap: break-word; font-size: 12px;">
                                    <?php echo esc_html($record->error_message); ?>
                                </div>
                            <?php else : ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td><a href="<?php echo wp_nonce_url(add_query_arg(array('delete' => $record->id), menu_page_url('xb-imageedit-records', false)), 'xb_imageedit_delete'); ?>" class="button">删除</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        echo paginate_links(array(
            'base' => add_query_arg('paged', '%#%'),
            'format' => '',
            'total' => ceil($total / $per_page),
            'current' => $paged,
        ));
        ?>

        <!-- 嵌入样式和脚本 -->
        <style type="text/css">
            .xb-imageedit-title {
                font-size: 28px;
                color: #333;
                margin-bottom: 25px;
                font-weight: 600;
            }
            .xb-imageedit-notice-auto {
                opacity: 1;
                transition: opacity 0.5s ease;
            }
        </style>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('.xb-imageedit-notice-auto').each(function() {
                    var $notice = $(this);
                    setTimeout(function() {
                        $notice.css('opacity', '0');
                        setTimeout(function() {
                            $notice.remove();
                        }, 500);
                    }, 3000);
                });
            });
        </script>
    </div>
    <?php
}

// 模型效果示例页面
function xb_imageedit_examples_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_imageedit_examples';

    if (isset($_POST['xb_imageedit_add_example']) && check_admin_referer('xb_imageedit_add_example')) {
        $function_name = sanitize_text_field($_POST['function_name']);
        $prompt = sanitize_text_field($_POST['prompt']);
        $input_image_url = esc_url_raw($_POST['input_image_url']);
        $output_image_url = esc_url_raw($_POST['output_image_url']);

        if (filter_var($input_image_url, FILTER_VALIDATE_URL) && filter_var($output_image_url, FILTER_VALIDATE_URL)) {
            $wpdb->insert($table_name, array(
                'function_name' => $function_name,
                'input_image_url' => $input_image_url,
                'prompt' => $prompt,
                'output_image_url' => $output_image_url,
            ));
            echo '<div class="notice notice-success xb-imageedit-notice-auto"><p>示例已添加。</p></div>';
        } else {
            echo '<div class="notice notice-error xb-imageedit-notice-auto"><p>请输入有效的图片 URL。</p></div>';
        }
    }

    if (isset($_POST['xb_imageedit_edit_example']) && check_admin_referer('xb_imageedit_edit_example')) {
        $example_id = intval($_POST['example_id']);
        $function_name = sanitize_text_field($_POST['function_name']);
        $prompt = sanitize_text_field($_POST['prompt']);
        $input_image_url = esc_url_raw($_POST['input_image_url']);
        $output_image_url = esc_url_raw($_POST['output_image_url']);

        if (filter_var($input_image_url, FILTER_VALIDATE_URL) && filter_var($output_image_url, FILTER_VALIDATE_URL)) {
            $wpdb->update(
                $table_name,
                array(
                    'function_name' => $function_name,
                    'input_image_url' => $input_image_url,
                    'prompt' => $prompt,
                    'output_image_url' => $output_image_url,
                ),
                array('id' => $example_id)
            );
            echo '<div class="notice notice-success xb-imageedit-notice-auto"><p>示例已更新。</p></div>';
        } else {
            echo '<div class="notice notice-error xb-imageedit-notice-auto"><p>请输入有效的图片 URL。</p></div>';
        }
    }

    if (isset($_GET['delete']) && check_admin_referer('xb_imageedit_delete_example')) {
        $wpdb->delete($table_name, array('id' => intval($_GET['delete'])));
        echo '<div class="notice notice-success xb-imageedit-notice-auto"><p>示例已删除。</p></div>';
    }

    $examples = $wpdb->get_results("SELECT * FROM $table_name");
    $all_functions = array(
        'stylization_all' => '全局风格化',
        'stylization_local' => '局部风格化',
        'remove_watermark' => '去文字水印',
        'super_resolution' => '提升分辨率',
        'colorization' => '图像变彩色',
        'doodle' => '线稿生图',
        'description_edit' => '指令编辑',
        'expand' => '扩图',
        'control_cartoon_feature' => '垫图',
    );

    $edit_example = null;
    if (isset($_GET['edit']) && check_admin_referer('xb_imageedit_edit_example')) {
        $edit_id = intval($_GET['edit']);
        $edit_example = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $edit_id));
    }
    ?>
    <div class="wrap">
        <h1 class="xb-imageedit-title">模型效果示例</h1>
        <form method="post" action="">
            <?php wp_nonce_field($edit_example ? 'xb_imageedit_edit_example' : 'xb_imageedit_add_example'); ?>
            <?php if ($edit_example) : ?>
                <input type="hidden" name="example_id" value="<?php echo $edit_example->id; ?>" />
            <?php endif; ?>
            <table class="form-table">
                <tr>
                    <th><label>模型功能</label></th>
                    <td>
                        <select name="function_name" required>
                            <?php foreach ($all_functions as $key => $label) : ?>
                                <option value="<?php echo $key; ?>" <?php selected($edit_example && $edit_example->function_name == $key); ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label>输入图像 URL</label></th>
                    <td><input type="url" name="input_image_url" value="<?php echo $edit_example ? esc_attr($edit_example->input_image_url) : ''; ?>" class="regular-text" required /></td>
                </tr>
                <tr>
                    <th><label>输入提示词</label></th>
                    <td><textarea name="prompt" rows="3" class="regular-text" required><?php echo $edit_example ? esc_textarea($edit_example->prompt) : ''; ?></textarea></td>
                </tr>
                <tr>
                    <th><label>输出图像 URL</label></th>
                    <td><input type="url" name="output_image_url" value="<?php echo $edit_example ? esc_attr($edit_example->output_image_url) : ''; ?>" class="regular-text" required /></td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="<?php echo $edit_example ? 'xb_imageedit_edit_example' : 'xb_imageedit_add_example'; ?>" class="button-primary" value="<?php echo $edit_example ? '更新示例' : '添加示例'; ?>" />
                <?php if ($edit_example) : ?>
                    <a href="<?php echo menu_page_url('xb-imageedit-examples', false); ?>" class="button">取消编辑</a>
                <?php endif; ?>
            </p>
        </form>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>模型功能</th>
                    <th>输入图像</th>
                    <th>输入提示词</th>
                    <th>输出图像</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($examples as $example) : ?>
                    <tr>
                        <td><?php echo esc_html(xb_imageedit_get_function_label($example->function_name)); ?></td>
                        <td><img src="<?php echo esc_url($example->input_image_url); ?>" style="width:100px;height:100px;" /></td>
                        <td><?php echo esc_html($example->prompt); ?></td>
                        <td><img src="<?php echo esc_url($example->output_image_url); ?>" style="width:100px;height:100px;" /></td>
                        <td>
                            <a href="<?php echo wp_nonce_url(add_query_arg(array('edit' => $example->id), menu_page_url('xb-imageedit-examples', false)), 'xb_imageedit_edit_example'); ?>" class="button">编辑</a>
                            <a href="<?php echo wp_nonce_url(add_query_arg(array('delete' => $example->id), menu_page_url('xb-imageedit-examples', false)), 'xb_imageedit_delete_example'); ?>" class="button">删除</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- 嵌入样式和脚本 -->
        <style type="text/css">
            .xb-imageedit-title {
                font-size: 28px;
                color: #333;
                margin-bottom: 25px;
                font-weight: 600;
            }
            .xb-imageedit-notice-auto {
                opacity: 1;
                transition: opacity 0.5s ease;
            }
        </style>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('.xb-imageedit-notice-auto').each(function() {
                    var $notice = $(this);
                    setTimeout(function() {
                        $notice.css('opacity', '0');
                        setTimeout(function() {
                            $notice.remove();
                        }, 500);
                    }, 3000);
                });
            });
        </script>
    </div>
    <?php
}