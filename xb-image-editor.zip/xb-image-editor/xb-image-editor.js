jQuery(document).ready(function($) {
    // 元素选择
    const $uploadBtn = $('#xb-imageedit-upload-btn');
    const $upload = $('#xb-imageedit-upload');
    const $preview = $('#xb-imageedit-preview');
    const $prompt = $('#xb-imageedit-prompt');
    const $function = $('#xb-imageedit-function');
    const $process = $('#xb-imageedit-process');
    const $result = $('#xb-imageedit-result');
    const $downloadWrapper = $('#xb-imageedit-download-wrapper');
    const $remaining = $('.xb-imageedit-remaining');
    const $usage = $('.xb-imageedit-usage');
    const $container = $('.xb-imageedit-container');
    let imageId = null;
    let originalExt = null;

    // 检查初始剩余次数并更新 usage 区域
    function checkRemainingCount() {
        const remaining = parseInt($remaining.text());
        if (remaining <= 0) {
            $usage.html('今日处理次数已经用完，请明天再来。');
        }
    }
    checkRemainingCount();

    // 检查是否所有输入都有效以启用处理按钮
    function checkInputs() {
        const hasImage = !!imageId;
        const hasPrompt = $prompt.val().trim() !== '';
        const hasFunction = $function.val() && $function.val() !== '';
        $process.prop('disabled', !(hasImage && hasPrompt && hasFunction));
    }

    // 监听输入变化
    $prompt.on('input', checkInputs);
    $function.on('change', checkInputs);

    // 点击自定义上传按钮触发文件选择
    $uploadBtn.on('click', function(e) {
        e.preventDefault();
        $upload.click();
    });

    // 文件上传处理（前端验证 + 后端上传）
    $upload.on('change', function(e) {
        const file = e.target.files[0];
        if (!file) return;

        // 前端初步检查文件类型
        const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
        if (!allowedTypes.includes(file.type)) {
            xb_imageedit_show_message('文件格式不支持，请上传 jpg、png 或 webp 格式的图片');
            $upload.val('');
            return;
        }

        // 使用 FileReader 读取文件开头并检查图片签名
        const reader = new FileReader();
        reader.onload = function(event) {
            const arrayBuffer = event.target.result;
            const uint8Array = new Uint8Array(arrayBuffer.slice(0, 4));

            // 检查常见的图片文件签名
            const isValidImage = checkImageSignature(uint8Array, file.type);
            if (!isValidImage) {
                xb_imageedit_show_message('文件好像不正确，请更换图片');
                $upload.val('');
                return;
            }

            // 如果前端验证通过，继续上传
            $preview.empty();
            const formData = new FormData();
            formData.append('file', file);

            $.ajax({
                url: xb_imageedit_vars.rest_url + 'upload',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-WP-Nonce': xb_imageedit_vars.nonce
                },
                beforeSend: function() {
                    $uploadBtn.text('上传中...').prop('disabled', true);
                },
                success: function(response) {
                    if (response && response.success && response.data && response.data.url) {
                        imageId = response.data.id;
                        originalExt = response.data.ext;
                        $preview.html('<img src="' + response.data.url + '" alt="上传预览" />');
                        checkInputs();
                    } else {
                        xb_imageedit_show_message('上传失败：响应格式错误');
                    }
                },
                error: function(xhr) {
                    let errorMsg = '系统暂时维护中，请联系客服';
                    if (xhr.status === 403) {
                        errorMsg = '今日处理次数已经用完，请明天再来';
                        $usage.html(errorMsg);
                    }
                    xb_imageedit_show_message(errorMsg);
                },
                complete: function() {
                    $uploadBtn.text('选择图片').prop('disabled', false);
                }
            });
        };
        reader.readAsArrayBuffer(file);
    });

    // 检查图片文件签名的函数
    function checkImageSignature(uint8Array, mimeType) {
        if (mimeType === 'image/jpeg') {
            return uint8Array[0] === 0xFF && uint8Array[1] === 0xD8;
        } else if (mimeType === 'image/png') {
            return uint8Array[0] === 0x89 && uint8Array[1] === 0x50 && uint8Array[2] === 0x4E && uint8Array[3] === 0x47;
        } else if (mimeType === 'image/webp') {
            return uint8Array[0] === 0x52 && uint8Array[1] === 0x49;
        }
        return false;
    }

    // 处理按钮点击
    $process.on('click', function() {
        const functionVal = $function.val();
        if (!imageId || !$prompt.val().trim() || !functionVal) {
            xb_imageedit_show_message('请上传图片、填写提示词并选择编辑功能。');
            return;
        }

        $process.prop('disabled', true).text('处理中...');
        $result.empty();
        $downloadWrapper.empty();
        $result.html('<div class="xb-imageedit-processing">正在处理中，请等待2-5分钟<span class="xb-imageedit-dots"></span></div>');

        $.ajax({
            url: xb_imageedit_vars.rest_url + 'process',
            type: 'POST',
            data: JSON.stringify({
                image_id: imageId,
                prompt: $prompt.val(),
                function: functionVal
            }),
            contentType: 'application/json',
            headers: {
                'X-WP-Nonce': xb_imageedit_vars.nonce
            },
            success: function(response) {
                if (response && response.success && response.data && response.data.result_url) {
                    $result.html('<img src="' + response.data.result_url + '" alt="处理结果" />');
                    $downloadWrapper.html(
                        '<button class="xb-imageedit-download-btn" data-url="' + response.data.result_url + '">快速下载</button>'
                    );

                    if (typeof response.data.remaining === 'number') {
                        if (response.data.remaining > 0) {
                            $remaining.text(response.data.remaining);
                            $usage.html('今日剩余处理次数：<span class="xb-imageedit-remaining">' + response.data.remaining + '</span>/' + response.data.limit);
                        } else {
                            $usage.html('今日处理次数已经用完，请明天再来。');
                        }
                    } else {
                        xb_imageedit_show_message('无法更新剩余次数：响应数据错误');
                    }
                } else {
                    xb_imageedit_show_message('系统暂时维护中，请联系客服');
                }
            },
            error: function(xhr) {
                let errorMsg = '系统暂时维护中，请联系客服';
                if (xhr.status === 403) {
                    errorMsg = '今日处理次数已经用完，请明天再来';
                    $usage.html(errorMsg);
                }
                xb_imageedit_show_message(errorMsg);
            },
            complete: function() {
                $process.prop('disabled', false).text('开始处理');
            }
        });
    });

    // 下载按钮点击
    $downloadWrapper.on('click', '.xb-imageedit-download-btn', function() {
        const url = $(this).data('url');
        const timestamp = new Date().getTime();
        const filename = `processed_image_${timestamp}.${originalExt}`;
        
        try {
            const link = document.createElement('a');
            link.href = url;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (err) {
            xb_imageedit_show_message('下载失败：' + err.message);
        }
    });

    // 快速登录按钮点击
    $('.xb-imageedit-login-btn').on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader, .login-link, .login-button, [href*="login"]');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.first().trigger('click');
        } else {
            window.location.href = xb_imageedit_vars.login_url;
        }
    });

    // 自定义消息显示函数
    function xb_imageedit_show_message(message) {
        const $msg = $('<div class="xb-imageedit-message">' + message + '</div>');
        $('body').append($msg);
        $msg.delay(3000).fadeOut(function() {
            $(this).remove();
        });
    }
});