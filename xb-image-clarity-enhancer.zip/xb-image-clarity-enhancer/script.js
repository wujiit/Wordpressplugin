jQuery(document).ready(function($) {
    let currentImageUrl = '';
    let enhancedImageData = '';
    let enhancedImageFormat = '';

    if (typeof xb_image_clarity === 'undefined') {
        console.error('xb_image_clarity 未定义，请检查服务器配置');
        return;
    }

    function showNotification(message, type = 'error') {
        const $notification = $('#xb-image-clarity-notification');
        $notification.text(message)
            .removeClass('xb-image-clarity-success xb-image-clarity-error')
            .addClass('xb-image-clarity-' + type)
            .fadeIn();
        setTimeout(() => $notification.fadeOut(), 3000);
    }

    function toggleUploadArea(showLogin = false) {
        if (showLogin) {
            $('.xb-image-clarity-image-upload-area').hide();
            $('.xb-image-clarity-login-notice').show();
        } else {
            $('.xb-image-clarity-image-upload-area').show();
            $('.xb-image-clarity-login-notice').hide();
        }
    }

    function updateRemainingCount(remaining) {
        $('#xb-remaining-count').text(remaining);
        if (remaining <= 0) {
            $('.xb-image-clarity-image-upload-area').hide();
            if (!$('#daily-limit-notice').length) {
                $('.xb-image-clarity-notice').append('<p id="daily-limit-notice">今天的使用次数已满，请明天再来</p>');
            }
        }
    }

    if (!xb_image_clarity.is_logged_in) {
        toggleUploadArea(true);
    } else {
        toggleUploadArea(false);
    }

    $('#xb-image-clarity-upload-btn').click(function(e) {
        e.preventDefault();
        $('#xb-image-clarity-image-upload').click();
    });

    $('#xb-image-clarity-image-upload').change(function() {
        let file = this.files[0];
        if (!file) return;

        // 前端初步检查文件扩展名
        let extension = file.name.split('.').pop().toLowerCase();
        if (!xb_image_clarity.allowed_formats.includes(extension)) {
            showNotification('只支持 ' + xb_image_clarity.allowed_formats.join(', ') + ' 格式');
            this.value = ''; // 清空输入
            return;
        }

        // 检查文件大小
        if (file.size > xb_image_clarity.max_size) {
            showNotification('文件大小不能超过 ' + (xb_image_clarity.max_size / (1024 * 1024)) + 'MB');
            this.value = ''; // 清空输入
            return;
        }

        // 使用FileReader读取文件内容并初步验证是否为图片
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = new Image();
            img.onload = function() {
                // 文件是有效图片，继续上传
                $('#xb-image-clarity-download-btn').hide();
                
                let formData = new FormData();
                formData.append('action', 'xb_image_clarity_upload');
                formData.append('nonce', xb_image_clarity.nonce);
                formData.append('file', file);

                $.ajax({
                    url: xb_image_clarity.ajax_url,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            currentImageUrl = response.data.url;
                            $('#xb-image-clarity-original-box .xb-image-clarity-image-wrapper').html('<img src="' + currentImageUrl + '">');
                            $('#xb-image-clarity-enhance-btn').prop('disabled', false);
                            $('#xb-image-clarity-enhanced-box .xb-image-clarity-image-wrapper').empty();
                        } else {
                            showNotification(response.data || '上传失败');
                        }
                    },
                    error: function() {
                        showNotification('上传失败');
                    }
                });
            };
            img.onerror = function() {
                showNotification('文件好像不正确，请更换图片');
                $('#xb-image-clarity-image-upload').val(''); // 清空输入
            };
            img.src = e.target.result;
        };
        reader.onerror = function() {
            showNotification('无法读取文件，请更换图片');
            $('#xb-image-clarity-image-upload').val(''); // 清空输入
        };
        reader.readAsDataURL(file);
    });

    $('#xb-image-clarity-enhance-btn').click(function() {
        $(this).prop('disabled', true).text('增强中...');
        
        $.ajax({
            url: xb_image_clarity.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_image_clarity_enhance',
                nonce: xb_image_clarity.nonce,
                image_url: currentImageUrl
            },
            success: function(response) {
                $('#xb-image-clarity-enhance-btn').prop('disabled', false).text('开始增强');
                if (response.success) {
                    enhancedImageData = response.data.base64;
                    enhancedImageFormat = response.data.format;
                    if (!enhancedImageFormat) {
                        console.warn('未收到图片格式，使用原始URL推断');
                        enhancedImageFormat = currentImageUrl.split('.').pop().toLowerCase() === 'png' ? 'png' : 'jpeg';
                    }
                    const mimeType = enhancedImageFormat === 'png' ? 'png' : 'jpeg';
                    $('#xb-image-clarity-enhanced-box .xb-image-clarity-image-wrapper').html(
                        '<img src="data:image/' + mimeType + ';base64,' + enhancedImageData + '">'
                    );
                    $('#xb-image-clarity-download-btn').show();
                    updateRemainingCount(response.data.remaining);
                    showNotification('增强成功', 'success');
                } else {
                    showNotification(response.data || '增强失败');
                }
            },
            error: function() {
                $('#xb-image-clarity-enhance-btn').prop('disabled', false).text('开始增强');
                showNotification('增强失败');
            }
        });
    });

    $('#xb-image-clarity-download-btn').click(function() {
        if (enhancedImageData) {
            const mimeType = enhancedImageFormat === 'png' ? 'png' : 'jpeg';
            const extension = mimeType === 'png' ? 'png' : 'jpg';
            const randomName = 'enhanced_' + Math.random().toString(36).substr(2, 9) + '.' + extension;
            
            const link = document.createElement('a');
            link.href = 'data:image/' + mimeType + ';base64,' + enhancedImageData;
            link.download = randomName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    });

    $('.xb-image-clarity-login-btn').on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = '/wp-login.php';
        }
    });
});