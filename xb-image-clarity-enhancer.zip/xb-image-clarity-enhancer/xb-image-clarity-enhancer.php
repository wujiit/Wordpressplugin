<?php
/*
Plugin Name: 小半AI图像增强
Description: 使用腾讯云接口增强图片清晰度的WordPress插件，支持用户独立使用次数限制
Version: 1.2
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 创建数据库表
function xb_image_clarity_create_tables() {
    global $wpdb;
    
    $settings_table = $wpdb->prefix . 'xb_image_clarity';
    $records_table = $wpdb->prefix . 'xb_image_clarity_records';
    $user_limits_table = $wpdb->prefix . 'xb_image_clarity_user_limits';
    $charset_collate = $wpdb->get_charset_collate();

    // 设置表
    $settings_sql = "CREATE TABLE $settings_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        secret_id varchar(255) NOT NULL,
        secret_key varchar(255) NOT NULL,
        req_region varchar(100) NOT NULL,
        allowed_formats varchar(255) DEFAULT 'png,jpg,jpeg',
        max_size int DEFAULT 3,
        notice_content text DEFAULT NULL,
        daily_limit int DEFAULT 10,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    // 记录表（新增 status 和 error_message 字段）
    $records_sql = "CREATE TABLE $records_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) NOT NULL,
        image_url varchar(255) NOT NULL,
        status varchar(20) NOT NULL DEFAULT 'success',
        error_message text DEFAULT NULL,
        upload_time datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        INDEX idx_user_time (user_id, upload_time)
    ) $charset_collate;";

    // 用户独立限制表
    $user_limits_sql = "CREATE TABLE $user_limits_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) NOT NULL,
        daily_limit int NOT NULL,
        update_time datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY idx_user_id (user_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($settings_sql);
    dbDelta($records_sql);
    dbDelta($user_limits_sql);
}

// 创建前端页面
function xb_image_clarity_create_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_image_clarity_enhance]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        wp_insert_post(array(
            'post_title'    => '图像清晰度增强',
            'post_name'     => 'image-clarity-enhance',
            'post_content'  => '[xb_image_clarity_enhance]',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_author'   => 1,
        ));
    }
}

// 插件激活
function xb_image_clarity_activate() {
    xb_image_clarity_create_tables();
    xb_image_clarity_create_page();
}
register_activation_hook(__FILE__, 'xb_image_clarity_activate');

// 添加设置链接
function xb_image_clarity_add_settings_link($links) {
    $settings_link = '<a href="admin.php?page=xb-image-clarity">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'xb_image_clarity_add_settings_link');

// 添加菜单
function xb_image_clarity_menu() {
    add_menu_page(
        '图像清晰度增强设置',
        '图像增强',
        'manage_options',
        'xb-image-clarity',
        'xb_image_clarity_settings_page',
        'dashicons-images-alt2'
    );
    add_submenu_page(
        'xb-image-clarity',
        '增强记录',
        '增强记录',
        'manage_options',
        'xb-image-clarity-records',
        'xb_image_clarity_records_page'
    );
}
add_action('admin_menu', 'xb_image_clarity_menu');

// 设置页面
function xb_image_clarity_settings_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_image_clarity';
    $saved = false;
    
    if (isset($_POST['xb_image_clarity_save'])) {
        $secret_id = sanitize_text_field($_POST['secret_id']);
        $secret_key = sanitize_text_field($_POST['secret_key']);
        $req_region = sanitize_text_field($_POST['req_region']);
        $allowed_formats = sanitize_text_field($_POST['allowed_formats']);
        $max_size = intval($_POST['max_size']);
        $notice_content = wp_kses_post($_POST['notice_content'] ?? '');
        $daily_limit = intval($_POST['daily_limit']);

        $existing = $wpdb->get_row("SELECT * FROM $table_name LIMIT 1");
        if ($existing) {
            $wpdb->update(
                $table_name,
                array(
                    'secret_id' => $secret_id,
                    'secret_key' => $secret_key,
                    'req_region' => $req_region,
                    'allowed_formats' => $allowed_formats,
                    'max_size' => $max_size,
                    'notice_content' => $notice_content,
                    'daily_limit' => $daily_limit
                ),
                array('id' => $existing->id)
            );
        } else {
            $wpdb->insert($table_name, array(
                'secret_id' => $secret_id,
                'secret_key' => $secret_key,
                'req_region' => $req_region,
                'allowed_formats' => $allowed_formats,
                'max_size' => $max_size,
                'notice_content' => $notice_content,
                'daily_limit' => $daily_limit
            ));
        }
        $saved = true;
    }
    
    $settings = $wpdb->get_row("SELECT * FROM $table_name LIMIT 1");
    ?>
    <div class="wrap">
        <h1>图像清晰度增强设置</h1>
        <?php if ($saved) { ?>
            <div id="xb-image-clarity-save-notice" class="notice notice-success is-dismissible">
                <p>保存成功</p>
            </div>
            <script>
                setTimeout(() => {
                    document.getElementById('xb-image-clarity-save-notice')?.style.display = 'none';
                }, 3000);
            </script>
        <?php } ?>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>Secret ID</th>
                    <td><input type="text" name="secret_id" value="<?php echo esc_attr($settings->secret_id ?? ''); ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th>Secret Key</th>
                    <td><input type="text" name="secret_key" value="<?php echo esc_attr($settings->secret_key ?? ''); ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th>请求地区</th>
                    <td><input type="text" name="req_region" value="<?php echo esc_attr($settings->req_region ?? ''); ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th>允许的图片格式</th>
                    <td><input type="text" name="allowed_formats" value="<?php echo esc_attr($settings->allowed_formats ?? 'png,jpg,jpeg'); ?>" class="regular-text"> 用英文逗号分隔</td>
                </tr>
                <tr>
                    <th>最大文件大小(MB)</th>
                    <td><input type="number" name="max_size" value="<?php echo esc_attr($settings->max_size ?? 3); ?>" class="regular-text" min="1" max="10"></td>
                </tr>
                <tr>
                    <th>默认每日使用次数限制</th>
                    <td><input type="number" name="daily_limit" value="<?php echo esc_attr($settings->daily_limit ?? 10); ?>" class="regular-text" min="1" max="100"> 次/天/用户</td>
                </tr>
                <tr>
                    <th>公告内容</th>
                    <td><textarea name="notice_content" rows="5" class="large-text"><?php echo esc_textarea($settings->notice_content ?? ''); ?></textarea><p class="description">支持HTML格式</p></td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="xb_image_clarity_save" class="button-primary" value="保存设置">
            </p>
        </form>
        由腾讯云提供：https://cloud.tencent.com/document/product/1590/81379<br>
        单价：0.008元/次
    </div>
    <?php
}

// 获取用户每日限制
function xb_image_clarity_get_user_limit($user_id) {
    global $wpdb;
    $settings_table = $wpdb->prefix . 'xb_image_clarity';
    $user_limits_table = $wpdb->prefix . 'xb_image_clarity_user_limits';
    
    $user_limit = $wpdb->get_var($wpdb->prepare(
        "SELECT daily_limit FROM $user_limits_table WHERE user_id = %d",
        $user_id
    ));
    
    if ($user_limit === null) {
        $default_limit = $wpdb->get_var("SELECT daily_limit FROM $settings_table LIMIT 1");
        return $default_limit !== null ? intval($default_limit) : 10;
    }
    return intval($user_limit);
}

// 增强记录页面（新增显示 status 和 error_message）
function xb_image_clarity_records_page() {
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_image_clarity_records';
    $user_limits_table = $wpdb->prefix . 'xb_image_clarity_user_limits';
    $settings_table = $wpdb->prefix . 'xb_image_clarity';
    $default_limit = $wpdb->get_var("SELECT daily_limit FROM $settings_table LIMIT 1") ?? 10;
    
    $action = $_GET['action'] ?? '';
    $user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
    
    // 处理删除记录
    if ($action === 'delete' && isset($_GET['id'])) {
        $wpdb->delete($records_table, array('id' => intval($_GET['id'])));
        echo '<div class="notice notice-success is-dismissible"><p>已删除记录</p></div>';
    }
    
    // 处理用户限制设置
    if (isset($_POST['set_user_limit']) && $user_id) {
        $new_limit = intval($_POST['user_daily_limit']);
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $user_limits_table WHERE user_id = %d",
            $user_id
        ));
        
        if ($new_limit > 0) {
            if ($existing) {
                $wpdb->update(
                    $user_limits_table,
                    array('daily_limit' => $new_limit),
                    array('user_id' => $user_id)
                );
            } else {
                $wpdb->insert($user_limits_table, array(
                    'user_id' => $user_id,
                    'daily_limit' => $new_limit
                ));
            }
            echo '<div class="notice notice-success is-dismissible"><p>用户限制已更新</p></div>';
        }
    }
    
    // 处理恢复默认设置
    if ($action === 'reset_limit' && $user_id) {
        $wpdb->delete($user_limits_table, array('user_id' => $user_id));
        echo '<div class="notice notice-success is-dismissible"><p>已恢复默认限制</p></div>';
    }
    
    $per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;
    
    $where = $user_id ? "WHERE r.user_id = $user_id" : '';
    $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $records_table r $where");
    $records = $wpdb->get_results("SELECT r.* FROM $records_table r $where ORDER BY upload_time DESC LIMIT $offset, $per_page");
    
    $today = date('Y-m-d');
    $today_count = $user_id ? $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $records_table WHERE user_id = %d AND DATE(upload_time) = %s AND status = 'success'",
        $user_id, $today
    )) : 0;
    
    $user_limit = $user_id ? xb_image_clarity_get_user_limit($user_id) : $default_limit;
    $total_pages = ceil($total_records / $per_page);
    ?>
    <div class="wrap">
        <h1>增强记录</h1>
        <div style="margin-bottom: 20px;">
            <p>总记录数: <?php echo $total_records; ?>
                <?php if ($user_id) { ?>
                    | 当前用户今日成功增强次数: <?php echo $today_count; ?>
                    | 当前用户每日限额: <?php echo $user_limit; ?>
                    | 默认限额: <?php echo $default_limit; ?>
                <?php } ?>
            </p>
            <form method="get" style="display: inline-block;">
                <input type="hidden" name="page" value="xb-image-clarity-records">
                <label>查询用户ID: </label>
                <input type="number" name="user_id" value="<?php echo $user_id ?: ''; ?>" min="0">
                <input type="submit" value="查询" class="button">
            </form>
            <?php if ($user_id) { ?>
                <form method="post" style="display: inline-block; margin-left: 10px;">
                    <label>设置每日限制: </label>
                    <input type="number" name="user_daily_limit" value="<?php echo $user_limit; ?>" min="1" max="100">
                    <input type="submit" name="set_user_limit" value="保存" class="button">
                </form>
                <a href="?page=xb-image-clarity-records&action=reset_limit&user_id=<?php echo $user_id; ?>" 
                   class="button" 
                   style="margin-left: 10px;"
                   onclick="return confirm('确定恢复默认限制?')">恢复默认</a>
                <a href="?page=xb-image-clarity-records" class="button" style="margin-left: 10px;">显示所有记录</a>
            <?php } ?>
        </div>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户ID</th>
                    <th>用户名</th>
                    <th>原始图片</th>
                    <th>状态</th>
                    <th>错误信息</th>
                    <th>上传时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record) {
                    $user = get_userdata($record->user_id);
                    ?>
                    <tr>
                        <td><?php echo $record->user_id; ?></td>
                        <td><?php echo $user ? esc_html($user->user_login) : '未知用户'; ?></td>
                        <td><img src="<?php echo esc_url($record->image_url); ?>" style="width:100px;height:100px;object-fit:cover;"></td>
                        <td><?php echo esc_html($record->status); ?></td>
                        <td><?php echo esc_html($record->error_message ?? '-'); ?></td>
                        <td><?php echo esc_html($record->upload_time); ?></td>
                        <td><a href="?page=xb-image-clarity-records&action=delete&id=<?php echo $record->id; ?><?php echo $user_id ? '&user_id=' . $user_id : ''; ?>" 
                               class="button button-small" 
                               onclick="return confirm('确定删除此记录?')">删除</a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <?php
        $pagination_args = array(
            'base' => add_query_arg('paged', '%#%'),
            'format' => '',
            'total' => $total_pages,
            'current' => $current_page,
            'prev_text' => '« 上一页',
            'next_text' => '下一页 »',
        );
        if ($user_id) {
            $pagination_args['add_args'] = array('user_id' => $user_id);
        }
        echo '<div class="tablenav bottom"><div class="tablenav-pages">';
        echo paginate_links($pagination_args);
        echo '</div></div>';
        ?>
    </div>
    <script>
        setTimeout(() => {
            document.querySelectorAll('.notice-success')?.forEach(notice => notice.style.display = 'none');
        }, 3000);
    </script>
    <?php
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_image_clarity_enqueue_scripts');
function xb_image_clarity_enqueue_scripts() {
    global $post, $wpdb;
    
    if (!is_a($post, 'WP_Post') || !has_shortcode($post->post_content, 'xb_image_clarity_enhance')) {
        return;
    }

    $table_name = $wpdb->prefix . 'xb_image_clarity';
    $settings = $wpdb->get_row("SELECT * FROM $table_name LIMIT 1");

    wp_enqueue_style('xb-image-clarity-style', plugins_url('style.css', __FILE__), [], '1.0');
    wp_enqueue_script('xb-image-clarity-script', plugins_url('script.js', __FILE__), array('jquery'), '1.0', true);

    //wp_enqueue_style('xb-image-clarity-style', 'https://img.qiyucloud.com/cloud/xb-image-clarity-enhancer/style.css');
    //wp_enqueue_script('xb-image-clarity-script', 'https://img.qiyucloud.com/cloud/xb-image-clarity-enhancer/script.js', ['jquery'], '1.0', true);
    
    $default_settings = array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('xb_image_clarity_nonce'),
        'allowed_formats' => array('png', 'jpg', 'jpeg'),
        'max_size' => 3 * 1024 * 1024,
        'is_logged_in' => is_user_logged_in(),
        'daily_limit' => 10
    );

    if ($settings) {
        $default_settings['allowed_formats'] = explode(',', $settings->allowed_formats ?? 'png,jpg,jpeg');
        $default_settings['max_size'] = ($settings->max_size ?? 3) * 1024 * 1024;
        $default_settings['daily_limit'] = is_user_logged_in() ? 
            xb_image_clarity_get_user_limit(get_current_user_id()) : 
            ($settings->daily_limit ?? 10);
    }

    wp_localize_script('xb-image-clarity-script', 'xb_image_clarity', $default_settings);
}

// 前端短代码
function xb_image_clarity_shortcode() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_image_clarity';
    $records_table = $wpdb->prefix . 'xb_image_clarity_records';
    $settings = $wpdb->get_row("SELECT * FROM $table_name LIMIT 1");
    
    // 获取允许的图片格式并生成accept属性
    $allowed_formats = $settings ? explode(',', $settings->allowed_formats ?? 'png,jpg,jpeg') : ['png', 'jpg', 'jpeg'];
    $accept_value = implode(',', array_map(function($format) { return '.' . $format; }, $allowed_formats));
    
    $output = '<div id="xb-image-clarity-container">
        <div class="xb-image-clarity-title">图像清晰度 AI 增强</div>';
    
    $is_logged_in = is_user_logged_in();
    $user_id = get_current_user_id();
    $daily_limit = $is_logged_in ? xb_image_clarity_get_user_limit($user_id) : ($settings->daily_limit ?? 10);
    $today = date('Y-m-d');
    $today_count = $is_logged_in ? $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $records_table WHERE user_id = %d AND DATE(upload_time) = %s AND status = 'success'",
            $user_id,
            $today
        )
    ) : 0;

    if ($is_logged_in) {
        if ($today_count < $daily_limit) {
            $output .= '<div class="xb-image-clarity-image-upload-area">
                <input type="file" id="xb-image-clarity-image-upload" accept="' . esc_attr($accept_value) . '">
                <button id="xb-image-clarity-upload-btn" class="xb-image-clarity-enhance-btn">上传图片</button>
                <button id="xb-image-clarity-enhance-btn" class="xb-image-clarity-enhance-btn" disabled>开始增强</button>
            </div>';
        } else {
            $output .= '<div class="xb-image-clarity-image-upload-area" style="display:none;"></div>';
        }
    } else {
        $output .= '<div class="xb-image-clarity-login-notice">请先登录以使用图像AI增强功能 <a href="' . wp_login_url() . '" class="xb-image-clarity-login-btn">登录</a></div>';
    }

    $output .= '<div class="xb-image-clarity-image-preview">
        <div class="xb-image-clarity-preview-box" id="xb-image-clarity-original-box">
            <div class="xb-image-clarity-subtitle">原始图片</div>
            <div class="xb-image-clarity-image-wrapper"></div>
        </div>
        <div class="xb-image-clarity-preview-box" id="xb-image-clarity-enhanced-box">
            <div class="xb-image-clarity-subtitle">增强效果</div>
            <div class="xb-image-clarity-image-wrapper"></div>
            <button id="xb-image-clarity-download-btn" class="xb-image-clarity-download-btn" style="display:none;">快速下载</button>
        </div>
    </div>';

    // 添加使用次数显示区域
    if ($is_logged_in) {
        $remaining = $daily_limit - $today_count;
        $output .= '<div id="xb-image-clarity-usage-count" class="xb-image-clarity-usage-count">
            <p>今日剩余增强次数: <span id="xb-remaining-count">' . $remaining . '</span>/' . $daily_limit . '</p>
        </div>';
    }

    $output .= '<div id="xb-image-clarity-notification" class="xb-image-clarity-notification"></div>';
    
    $notice_content = $settings ? ($settings->notice_content ?? '') : '';
    if ($is_logged_in && $today_count >= $daily_limit) {
        $notice_content .= '<p id="daily-limit-notice">今天的使用次数已满，请明天再来</p>';
    }
    if (!empty($notice_content)) {
        $output .= '<div class="xb-image-clarity-notice">' . $notice_content . '</div>';
    }
    
    $output .= '</div>';
    return $output;
}
add_shortcode('xb_image_clarity_enhance', 'xb_image_clarity_shortcode');

// 上传图片（优化格式检查，兼容 jpg 和 jpeg）
function xb_image_clarity_upload_image() {
    check_ajax_referer('xb_image_clarity_nonce', 'nonce');
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_image_clarity';
    $records_table = $wpdb->prefix . 'xb_image_clarity_records';
    $settings = $wpdb->get_row("SELECT * FROM $table_name LIMIT 1");
    
    if (!is_user_logged_in()) {
        wp_send_json_error('请先登录');
    }

    $user_id = get_current_user_id();
    $daily_limit = xb_image_clarity_get_user_limit($user_id);
    $today = date('Y-m-d');
    $today_count = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $records_table WHERE user_id = %d AND DATE(upload_time) = %s AND status = 'success'",
            $user_id,
            $today
        )
    );

    if ($today_count >= $daily_limit) {
        wp_send_json_error('今天的使用次数已满，请明天再来');
    }

    if (!empty($_FILES['file'])) {
        $allowed_formats = $settings ? explode(',', $settings->allowed_formats ?? 'png,jpg,jpeg') : array('png', 'jpg', 'jpeg');
        $max_size = ($settings ? ($settings->max_size ?? 3) : 3) * 1024 * 1024;
        
        $file = $_FILES['file'];
        $file_type = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $file_size = $file['size'];
        $file_tmp = $file['tmp_name'];

        // 检查文件真实类型
        if (!function_exists('exif_imagetype')) {
            wp_send_json_error('服务器不支持图片类型检测，请联系管理员');
        }
        
        $image_type = exif_imagetype($file_tmp);
        if ($image_type === false) {
            wp_send_json_error('文件不是真实的图片，请更换图片');
        }

        // 将exif_imagetype的结果转换为扩展名
        $real_extension = image_type_to_extension($image_type, false);

        // 兼容 jpg 和 jpeg
        if ($real_extension === 'jpeg') {
            if (!in_array('jpeg', $allowed_formats) && !in_array('jpg', $allowed_formats)) {
                wp_send_json_error('图片格式不支持，仅支持: ' . implode(', ', $allowed_formats));
            }
        } elseif (!in_array($real_extension, $allowed_formats)) {
            wp_send_json_error('图片格式不支持，仅支持: ' . implode(', ', $allowed_formats));
        }

        // 检查文件扩展名是否与实际类型一致（兼容 jpg 和 jpeg）
        $normalized_file_type = ($file_type === 'jpg') ? 'jpeg' : $file_type;
        $normalized_real_extension = ($real_extension === 'jpeg') ? 'jpeg' : $real_extension;
        if ($normalized_real_extension !== $normalized_file_type) {
            wp_send_json_error('文件扩展名与实际类型不符，请更换图片');
        }

        // 检查文件大小
        if ($file_size > $max_size) {
            wp_send_json_error('图片大小超出限制（最大 ' . ($max_size / (1024 * 1024)) . 'MB）');
        }
        
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        
        $attachment_id = media_handle_upload('file', 0);
        if (!is_wp_error($attachment_id)) {
            $image_url = wp_get_attachment_url($attachment_id);
            wp_send_json_success(array('url' => $image_url));
        }
    }
    wp_send_json_error('上传失败');
}
add_action('wp_ajax_xb_image_clarity_upload', 'xb_image_clarity_upload_image');

// 增强图片（新增记录状态和错误信息，前台统一错误提示）
function xb_image_clarity_enhance_image() {
    check_ajax_referer('xb_image_clarity_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error('请先登录');
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_image_clarity';
    $records_table = $wpdb->prefix . 'xb_image_clarity_records';
    $settings = $wpdb->get_row("SELECT * FROM $table_name LIMIT 1");
    
    $user_id = get_current_user_id();
    $daily_limit = xb_image_clarity_get_user_limit($user_id);
    $today = date('Y-m-d');
    $today_count = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $records_table WHERE user_id = %d AND DATE(upload_time) = %s AND status = 'success'",
            $user_id,
            $today
        )
    );

    if ($today_count >= $daily_limit) {
        wp_send_json_error('今天的使用次数已满，请明天再来');
    }

    $image_url = sanitize_text_field($_POST['image_url']);
    
    $image_path = str_replace(site_url(), ABSPATH, $image_url);
    if (function_exists('mime_content_type') && file_exists($image_path)) {
        $mime_type = mime_content_type($image_path);
        $format = str_replace('image/', '', $mime_type);
    } else {
        $extension = strtolower(pathinfo($image_url, PATHINFO_EXTENSION));
        $format = ($extension === 'png') ? 'png' : 'jpeg';
    }
    
    $response = xb_image_clarity_tencent_api(
        $settings->secret_id ?? '',
        $settings->secret_key ?? '',
        $settings->req_region ?? '',
        $image_url
    );
    $result = json_decode($response, true);
    
    $error_msg = null;
    if (isset($result['Response']['Error'])) {
        $error_msg = $result['Response']['Error']['Code'] . ': ' . $result['Response']['Error']['Message'];
    }
    
    if (isset($result['Response']['EnhancedImage']) && empty($error_msg)) {
        $wpdb->insert($records_table, array(
            'user_id' => $user_id,
            'image_url' => $image_url,
            'status' => 'success',
            'error_message' => null
        ));
        
        $new_count = $today_count + 1;
        wp_send_json_success(array(
            'base64' => $result['Response']['EnhancedImage'],
            'format' => $format,
            'remaining' => $daily_limit - $new_count
        ));
    } else {
        $wpdb->insert($records_table, array(
            'user_id' => $user_id,
            'image_url' => $image_url,
            'status' => 'failed',
            'error_message' => $error_msg
        ));
        wp_send_json_error('增强处理失败，请联系客服排查');
    }
}
add_action('wp_ajax_xb_image_clarity_enhance', 'xb_image_clarity_enhance_image');

// 腾讯云API调用
function xb_image_clarity_tencent_api($secret_id, $secret_key, $req_region, $image_url) {
    $service = "tiia";
    $host = "tiia.tencentcloudapi.com";
    $version = "2019-05-29";
    $action = "EnhanceImage";
    $payload = json_encode(array('ImageUrl' => $image_url));
    $endpoint = "https://tiia.tencentcloudapi.com";
    $algorithm = "TC3-HMAC-SHA256";
    $timestamp = time();
    $date = gmdate("Y-m-d", $timestamp);

    $http_request_method = "POST";
    $canonical_uri = "/";
    $canonical_querystring = "";
    $ct = "application/json; charset=utf-8";
    $canonical_headers = "content-type:".$ct."\nhost:".$host."\nx-tc-action:".strtolower($action)."\n";
    $signed_headers = "content-type;host;x-tc-action";
    $hashed_request_payload = hash("sha256", $payload);
    $canonical_request = "$http_request_method\n$canonical_uri\n$canonical_querystring\n$canonical_headers\n$signed_headers\n$hashed_request_payload";

    $credential_scope = "$date/$service/tc3_request";
    $hashed_canonical_request = hash("sha256", $canonical_request);
    $string_to_sign = "$algorithm\n$timestamp\n$credential_scope\n$hashed_canonical_request";

    $secret_date = hash_hmac("sha256", $date, "TC3".$secret_key, true);
    $secret_service = hash_hmac("sha256", $service, $secret_date, true);
    $secret_signing = hash_hmac("sha256", "tc3_request", $secret_service, true);
    $signature = hash_hmac("sha256", $string_to_sign, $secret_signing);

    $authorization = "$algorithm Credential=$secret_id/$credential_scope, SignedHeaders=$signed_headers, Signature=$signature";

    $headers = [
        "Authorization" => $authorization,
        "Content-Type" => "application/json; charset=utf-8",
        "Host" => $host,
        "X-TC-Action" => $action,
        "X-TC-Timestamp" => $timestamp,
        "X-TC-Version" => $version,
        "X-TC-Region" => $req_region
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $endpoint);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array_map(function ($k, $v) { return "$k: $v"; }, array_keys($headers), $headers));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    
    return $response;
}
?>