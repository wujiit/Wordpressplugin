<?php
/**
 * Plugin Name: 小半多语言翻译
 * Description: 基于translate.js的WordPress在线翻译插件，支持顶部、底部、菜单、小工具和菜单一体化下拉显示，支持自定义添加翻译语言。
 * Plugin URI: https://www.jingxialai.com/4865.html
 * Version: 1.4
 * Author: Summer
 * License: GPL License
 * Author URI: https://www.jingxialai.com/
 */

// 防止直接访问文件
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时调用
function wp_translate_plugin_activate() {
    wp_cache_flush(); // 清除缓存
}
register_activation_hook(__FILE__, 'wp_translate_plugin_activate');

// 插件停用时调用
function wp_translate_plugin_deactivate() {
    wp_cache_flush(); // 清除缓存
}
register_deactivation_hook(__FILE__, 'wp_translate_plugin_deactivate');

// 在插件中心添加设置链接
function wp_translate_settings_link($links) {
    $settings_link = '<a href="options-general.php?page=wp-translate-plugin">设置</a>';
    array_push($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wp_translate_settings_link');

// 添加插件设置页面
function wp_translate_plugin_menu() {
    add_options_page(
        '小半翻译插件设置',
        '小半翻译设置',
        'manage_options',
        'wp-translate-plugin',
        'wp_translate_plugin_settings_page'
    );
}
add_action('admin_menu', 'wp_translate_plugin_menu');

// 设置页面内容
function wp_translate_plugin_settings_page() {
    ?>
    <div class="wrap">
        <h1>小半多语言翻译插件设置</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('wp_translate_plugin_options');
            do_settings_sections('wp-translate-plugin');
            submit_button();
            ?>
            <p class="description">
                <h1>插件说明</h1>
                1、是基于translate.js实现的前端翻译，用的client.edge方式，默认会根据用户客户端ip自动显示对应语言(有设置的前提下).<br>
                2、具体的翻译语言简码到官方查看: https://translate.zvo.cn/43086.html<br>
                3、这是机翻，稳定性、翻译速度、准确性都是根据client.edge（由微软直接提供翻译支持）来的.<br>
                4、翻译语言的图标可以不填写，显示到小工具之后，还需要在小工具去添加位置，设置为菜单的时候，只支持一个菜单，多个菜单会冲突.<br>
                5、默认改为本地调用translate.js文件，没有用官方的staticfile，可以自己把translate.js上传到对象存储加权限，改为远程调用.<br>
                6、<span style="color: #ff0000;">翻译按钮显示错乱或者按钮无反应，是因为和你的主题不兼容，最完美的兼容是联系你的主题作者内置.</span><br>
                7、<span style="color: #009900;">本插件介绍页面: <a target="_blank" href="https://www.jingxialai.com/4865.html">www.jingxialai.com</a></span><br>
            </p>          
        </form>
    </div>
    <?php
}

// 注册设置
function wp_translate_plugin_settings_init() {
    register_setting('wp_translate_plugin_options', 'wp_translate_plugin_position');
    register_setting('wp_translate_plugin_options', 'wp_translate_plugin_custom_languages', 'wp_translate_plugin_sanitize_languages');

    add_settings_section(
        'wp_translate_plugin_section',
        '设置翻译按钮位置',
        null,
        'wp-translate-plugin'
    );

    add_settings_field(
        'wp_translate_plugin_position',
        '翻译按钮显示位置',
        'wp_translate_plugin_position_render',
        'wp-translate-plugin',
        'wp_translate_plugin_section'
    );

    add_settings_section(
        'wp_translate_plugin_custom_languages_section',
        '自定义添加语言',
        null,
        'wp-translate-plugin'
    );

    add_settings_field(
        'wp_translate_plugin_custom_languages',
        '翻译语言设置',
        'wp_translate_plugin_custom_languages_render',
        'wp-translate-plugin',
        'wp_translate_plugin_custom_languages_section'
    );
}
add_action('admin_init', 'wp_translate_plugin_settings_init');

// 保存前清理语言设置
function wp_translate_plugin_sanitize_languages($input) {
    $new_input = [];
    if (is_array($input)) {
        foreach ($input as $language) {
            if (!empty($language['name']) && !empty($language['code'])) {
                $new_language = [];
                $new_language['name'] = sanitize_text_field($language['name']);
                $new_language['code'] = sanitize_text_field($language['code']);
                $new_language['icon'] = isset($language['icon']) ? esc_url_raw($language['icon']) : '';
                $new_input[] = $new_language;
            }
        }
    }
    return $new_input;
}


// 翻译语言设置渲染
function wp_translate_plugin_custom_languages_render() {
    $custom_languages = get_option('wp_translate_plugin_custom_languages', []);
    ?>
    <div id="custom-languages-container">
        <?php 
        if (!empty($custom_languages)) {
            foreach ($custom_languages as $index => $language): 
                $name = isset($language['name']) ? esc_attr($language['name']) : '';
                $code = isset($language['code']) ? esc_attr($language['code']) : '';
                $icon = isset($language['icon']) ? esc_attr($language['icon']) : '';
            ?>
            <div class="custom-language-row" style="margin-bottom: 10px;">
                <input type="text" name="wp_translate_plugin_custom_languages[<?php echo $index; ?>][name]" value="<?php echo $name; ?>" placeholder="语言名称 (例如: 简体中文)" />
                <input type="text" name="wp_translate_plugin_custom_languages[<?php echo $index; ?>][code]" value="<?php echo $code; ?>" placeholder="语言简码 (例如: zh-CN)" />
                <input type="text" name="wp_translate_plugin_custom_languages[<?php echo $index; ?>][icon]" value="<?php echo $icon; ?>" placeholder="图标 URL (例如: https://img.xxxx.com/cn.png)" />
                <button type="button" class="button remove-language-button">删除</button>
            </div>
            <?php endforeach; 
        }
        ?>
    </div>
    <button type="button" id="add-language-button" class="button button-primary">添加语言</button>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var container = document.getElementById('custom-languages-container');
            var addButton = document.getElementById('add-language-button');

            function addRemoveListener(button) {
                button.addEventListener('click', function() {
                    this.parentElement.remove();
                    updateIndexes();
                });
            }

            function updateIndexes() {
                 var rows = container.querySelectorAll('.custom-language-row');
                 rows.forEach(function(row, index) {
                    row.querySelectorAll('input').forEach(function(input) {
                        var nameAttr = input.getAttribute('name');
                        if (nameAttr) {
                            input.setAttribute('name', nameAttr.replace(/\[\d+\]/, '[' + index + ']'));
                        }
                    });
                 });
            }


            addButton.addEventListener('click', function() {
                var index = container.children.length;
                var newRow = document.createElement('div');
                newRow.classList.add('custom-language-row');
                newRow.style.marginBottom = '10px';
                newRow.innerHTML = '<input type="text" name="wp_translate_plugin_custom_languages[' + index + '][name]" placeholder="语言名称" /> ' +
                                    '<input type="text" name="wp_translate_plugin_custom_languages[' + index + '][code]" placeholder="语言简码" /> ' +
                                    '<input type="text" name="wp_translate_plugin_custom_languages[' + index + '][icon]" placeholder="图标 URL" /> ' +
                                    '<button type="button" class="button remove-language-button">删除</button>';
                container.appendChild(newRow);
                addRemoveListener(newRow.querySelector('.remove-language-button'));
            });

            document.querySelectorAll('.remove-language-button').forEach(addRemoveListener);
        });
    </script>
    <?php
}

// 加载translate.js
function wp_translate_plugin_enqueue_scripts() {
    wp_enqueue_script(
        'translate-js',
        plugin_dir_url(__FILE__) . 'translate.js',
        array(),
        '1.4', // 变下防止缓存
        true
    );

    wp_add_inline_script(
        'translate-js',
        'document.addEventListener("DOMContentLoaded", function() {
            translate.setAutoDiscriminateLocalLanguage();
            translate.selectLanguageTag.show = false;
            translate.service.use("client.edge");
            translate.execute();
        });'
    );
}
add_action('wp_enqueue_scripts', 'wp_translate_plugin_enqueue_scripts');

// 翻译按钮位置选项
function wp_translate_plugin_position_render() {
    $options = get_option('wp_translate_plugin_position');
    ?>
    <select name="wp_translate_plugin_position">
        <option value="top" <?php selected($options, 'top'); ?>>页面顶部</option>
        <option value="bottom" <?php selected($options, 'bottom'); ?>>页面底部</option>
        <option value="menu" <?php selected($options, 'menu'); ?>>菜单中 (弹窗)</option>
        <option value="menu_integrated" <?php selected($options, 'menu_integrated'); ?>>菜单一体 (下拉)</option>
        <option value="widget" <?php selected($options, 'widget'); ?>>小工具</option>
    </select>
    <?php
}

// 在前端头部加载翻译按钮
function wp_translate_plugin_add_translate_buttons_top() {
    $position = get_option('wp_translate_plugin_position');
    if ($position === 'top') {
        echo '<div id="translate-button-top" style="text-align: center; padding: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">';
        echo '<div style="display: flex; flex-wrap: wrap; justify-content: center;">';
        echo wp_translate_plugin_render_buttons('default');
        echo '</div></div>';
    }
}

// 在前端底部加载翻译按钮
function wp_translate_plugin_add_translate_buttons_bottom() {
    $position = get_option('wp_translate_plugin_position');
    if ($position === 'bottom') {
        // 移除静态定位的 'position:fixed'
        echo '<div id="translate-button-bottom" style="background-color: #f1f1f1; text-align: center; padding: 5px; z-index: 999; box-shadow: 0 -2px 5px rgba(0,0,0,0.1);">';
        echo '<div style="display: flex; flex-wrap: wrap; justify-content: center;">';
        echo wp_translate_plugin_render_buttons('default');
        echo '</div></div>';
    }
}

// 插入到头部或底部
function wp_translate_plugin_insert_into_header_or_footer() {
    $position = get_option('wp_translate_plugin_position', 'top');

    if ($position === 'top') {
        add_action('wp_body_open', 'wp_translate_plugin_add_translate_buttons_top');
    } elseif ($position === 'bottom') {
        add_action('wp_footer', 'wp_translate_plugin_add_translate_buttons_bottom', 5);
    }
}
add_action('init', 'wp_translate_plugin_insert_into_header_or_footer');


// 翻译语言切换按钮
function wp_translate_plugin_render_buttons($type = 'default') {
    $options = get_option('wp_translate_plugin_custom_languages', []);
    $buttons = '';

    foreach ($options as $language) {
        $name = esc_attr($language['name']);
        $code = esc_attr($language['code']);
        $icon = esc_url($language['icon']);
        $icon_html = $icon ? '<img src="' . $icon . '" alt="' . $name . '" style="width:20px; height:15px; vertical-align:middle; margin-right:8px; border: 1px solid #ddd;" class="ignore" />' : '';

        if ($type === 'dropdown') {
            // 下拉样式
            $buttons .= '<li class="ignore">
                <a href="javascript:translate.changeLanguage(\'' . $code . '\');" class="ignore">
                    ' . $icon_html . $name . '
                </a>
            </li>';
        } else {
            // 默认
             $buttons .= '<li style="display: flex; align-items: center; list-style: none; padding: 0 5px;; margin: 0;">
                <a href="javascript:translate.changeLanguage(\'' . $code . '\');" style="display: flex; align-items: center; padding: 3px 8px; background-color:#0073aa; color:white; border-radius:5px; text-decoration: none;" class="ignore">
                    ' . $icon_html . $name . '
                </a>
            </li>';
        }
    }

    if ($type === 'dropdown') {
        return $buttons;
    } else {
        // 模态框和其他窗口的间隙
        return '<ul style="list-style:none; padding:0; margin:0; display:flex; gap:15px; flex-wrap:wrap; justify-content:center;">' . $buttons . '</ul>';
    }
}


// 在菜单中添加翻译按钮
function wp_translate_plugin_add_to_menu($items, $args) {
    $position = get_option('wp_translate_plugin_position');

    static $modal_added = false;
    if ($position === 'menu' && !$modal_added) {
        $items .= '<li class="menu-item ignore"><a href="#" id="translate-menu-button">&#x1F310; Language</a></li>';
        $items .= '<div id="translate-menu-options" style="display:none; background-color:rgba(119, 119, 119, 0.8); padding:15px; border-radius:5px; position: fixed; z-index: 9999; max-width: 600px; top: 50%; left: 50%; transform: translate(-50%, -50%);">';
        $items .= '<div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 15px;">';
        $items .= wp_translate_plugin_render_buttons('default');
        $items .= '</div></div>';

        $items .= '
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                var menuButton = document.getElementById("translate-menu-button");
                if(menuButton) {
                    menuButton.addEventListener("click", function(e) {
                        e.preventDefault();
                        var options = document.getElementById("translate-menu-options");
                        options.style.display = options.style.display === "none" ? "block" : "none";
                    });
                     document.addEventListener("click", function(e) {
                        var options = document.getElementById("translate-menu-options");
                        var button = document.getElementById("translate-menu-button");
                        if (options && button && options.style.display === "block" && !options.contains(e.target) && e.target !== button) {
                           options.style.display = "none";
                        }
                     }, true);
                }
            });
        </script>';
        $modal_added = true;
    }

    static $dropdown_added = false;
    if ($position === 'menu_integrated' && !$dropdown_added) {
        $language_buttons = wp_translate_plugin_render_buttons('dropdown');
        $items .= '<li class="menu-item menu-item-language-dropdown ignore has-submenu">';
        $items .= '<a href="#" class="ignore">&#x1F310; Language</a>';
        $items .= '<ul class="sub-menu language-dropdown-list">';
        $items .= $language_buttons;
        $items .= '</ul></li>';
        $dropdown_added = true;
        add_action('wp_footer', 'wp_translate_plugin_dropdown_script_css', 99);
    }

    return $items;
}
add_filter('wp_nav_menu_items', 'wp_translate_plugin_add_to_menu', 10, 2);

// 下拉菜单
function wp_translate_plugin_dropdown_script_css() {
    $position = get_option('wp_translate_plugin_position');
    if ($position !== 'menu_integrated') {
        return;
    }
    static $added = false;
    if ($added) {
        return;
    }
    $added = true;
    ?>
    <style>
        .menu-item-language-dropdown { position: relative; }
        .menu-item-language-dropdown > a::after { content: ' ▼'; font-size: 0.7em; margin-left: 5px; display: inline-block; }
        .language-dropdown-list { display: none; position: absolute; top: 100%; left: 0; background-color: #fff; border: 1px solid #ccc; list-style: none; padding: 5px 0; margin: 5px 0 0 0; z-index: 1000; min-width: 160px; box-shadow: 0 4px 8px rgba(0,0,0,0.15); border-radius: 4px; }
        .menu-item-language-dropdown.open .language-dropdown-list { display: block; }
        .language-dropdown-list li { margin: 0 !important; padding: 0 !important; list-style: none !important; }
        .language-dropdown-list li a { display: flex !important; align-items: center !important; padding: 8px 15px !important; text-decoration: none !important; color: #333 !important; white-space: nowrap !important; background-color: transparent !important; border: none !important; line-height: 1.5 !important; transition: background-color 0.2s ease; }
        .language-dropdown-list li a:hover { background-color: #f0f0f0 !important; color: #000 !important; }
        .language-dropdown-list li img { width: 20px !important; height: 15px !important; margin-right: 10px !important; vertical-align: middle !important; border: 1px solid #ddd !important; }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var dropdownToggle = document.querySelector('.menu-item-language-dropdown > a');
            if (dropdownToggle) {
                dropdownToggle.addEventListener('click', function(e) {
                    e.preventDefault(); e.stopPropagation();
                    this.parentElement.classList.toggle('open');
                });
            }
            document.addEventListener('click', function(e) {
                var openDropdown = document.querySelector('.menu-item-language-dropdown.open');
                if (openDropdown && !openDropdown.contains(e.target)) {
                    openDropdown.classList.remove('open');
                }
            });
            document.querySelectorAll('.language-dropdown-list a').forEach(function(langLink) {
                 langLink.addEventListener('click', function() {
                    var dropdown = this.closest('.menu-item-language-dropdown');
                    if (dropdown) { dropdown.classList.remove('open'); }
                 });
            });
        });
    </script>
    <?php
}


// 小工具翻译按钮
class WP_Translate_Plugin_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'wp_translate_plugin_widget',
            '翻译按钮小工具',
            array('description' => __('在小工具区域显示翻译按钮 (请确保后台设置为小工具模式)', 'wp_translate_plugin'))
        );
    }

    public function widget($args, $instance) {
        $position = get_option('wp_translate_plugin_position');
        
        if ($position === 'widget') {
            echo $args['before_widget'];
            $widget_id = $args['widget_id'];
            echo '<a href="#" id="translate-widget-button-' . $widget_id . '" class="ignore">&#x1F310; Language</a>';
            echo '<div id="translate-widget-options-' . $widget_id . '" style="display:none; background-color:rgba(119, 119, 119, 0.8); padding:15px; border-radius:5px; position: fixed; z-index: 9999; max-width: 600px; top: 50%; left: 50%; transform: translate(-50%, -50%);">';
            echo '<div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 15px;">';
            echo wp_translate_plugin_render_buttons('default');
            echo '</div></div>';

            echo '
            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    var widgetButton = document.getElementById("translate-widget-button-' . $widget_id . '");
                    if (widgetButton) {
                        widgetButton.addEventListener("click", function(e) {
                            e.preventDefault();
                            var options = document.getElementById("translate-widget-options-' . $widget_id . '");
                            options.style.display = options.style.display === "none" ? "block" : "none";
                        });
                    }
                });
            </script>';
            echo $args['after_widget'];
        }
    }

    public function form($instance) {
        echo '<p>此小工具将在前台显示翻译按钮 (仅当插件设置为 "小工具" 模式时).</p>';
    }

    public function update($new_instance, $old_instance) {
        return $new_instance;
    }
}

// 注册小工具
function wp_translate_plugin_register_widget() {
    register_widget('WP_Translate_Plugin_Widget');
}
add_action('widgets_init', 'wp_translate_plugin_register_widget');


// 防止缓存
function wp_translate_plugin_prevent_cache($headers) {
    $headers['Cache-Control'] = 'no-cache, no-store, must-revalidate';
    $headers['Pragma'] = 'no-cache';
    $headers['Expires'] = '0';
    return $headers;
}
add_filter('wp_headers', 'wp_translate_plugin_prevent_cache');

?>