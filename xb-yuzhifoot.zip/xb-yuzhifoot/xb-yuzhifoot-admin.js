/**
 * 预制菜查询插件后台管理JavaScript
 * 注意：此文件仅用于前端页面，后台管理页面的JS直接内联在PHP中
 */

(function($) {
    'use strict';
    
    // 前端管理功能初始化
    $(document).ready(function() {
        initFrontendAdmin();
    });
    
    /**
     * 前端管理功能初始化
     */
    function initFrontendAdmin() {
        // 如果当前页面不是插件前端页面，直接返回
        if (!$('.xb-yuzhifoot-container').length) {
            return;
        }
        
        // 初始化前端管理功能
        initQuickActions();
        initDataValidation();
        initUserInteraction();
    }
    
    /**
     * 初始化快速操作功能
     */
    function initQuickActions() {
        // 快速筛选按钮
        addQuickFilterButtons();
        
        // 快速搜索历史
        initSearchHistory();
        
        // 收藏功能
        initFavorites();
    }
    
    /**
     * 添加快速筛选按钮
     */
    function addQuickFilterButtons() {
        var quickFilters = [
            { name: '热门推荐', params: { xb_demand: '1' } },
            { name: '新品上市', params: { xb_scene: '1' } },
            { name: '特价优惠', params: { xb_price: '1' } }
        ];
        
        var $quickFilterContainer = $('<div class="xb-yuzhifoot-quick-filters"></div>');
        
        quickFilters.forEach(function(filter) {
            var $btn = $('<button type="button" class="xb-yuzhifoot-quick-btn">' + filter.name + '</button>');
            $btn.on('click', function() {
                applyQuickFilter(filter.params);
            });
            $quickFilterContainer.append($btn);
        });
        
        $('.xb-yuzhifoot-search-section').append($quickFilterContainer);
    }
    
    /**
     * 应用快速筛选
     */
    function applyQuickFilter(params) {
        Object.keys(params).forEach(function(key) {
            $('select[name="' + key + '"]').val(params[key]);
        });
        
        $('#xb-yuzhifoot-search-form').submit();
    }
    
    /**
     * 初始化搜索历史
     */
    function initSearchHistory() {
        var $searchInput = $('.xb-yuzhifoot-search-input');
        
        // 保存搜索历史
        $('#xb-yuzhifoot-search-form').on('submit', function() {
            var searchTerm = $searchInput.val().trim();
            if (searchTerm) {
                saveSearchHistory(searchTerm);
            }
        });
        
        // 显示搜索建议
        $searchInput.on('focus', function() {
            showSearchSuggestions();
        });
        
        // 隐藏搜索建议
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.xb-yuzhifoot-search-suggestions').length && 
                !$(e.target).is('.xb-yuzhifoot-search-input')) {
                hideSearchSuggestions();
            }
        });
    }
    
    /**
     * 保存搜索历史
     */
    function saveSearchHistory(term) {
        var history = getSearchHistory();
        
        // 移除重复项
        history = history.filter(function(item) {
            return item !== term;
        });
        
        // 添加到开头
        history.unshift(term);
        
        // 限制历史记录数量
        if (history.length > 10) {
            history = history.slice(0, 10);
        }
        
        localStorage.setItem('xb_yuzhifoot_search_history', JSON.stringify(history));
    }
    
    /**
     * 获取搜索历史
     */
    function getSearchHistory() {
        var history = localStorage.getItem('xb_yuzhifoot_search_history');
        return history ? JSON.parse(history) : [];
    }
    
    /**
     * 显示搜索建议
     */
    function showSearchSuggestions() {
        var history = getSearchHistory();
        if (history.length === 0) return;
        
        var $suggestions = $('.xb-yuzhifoot-search-suggestions');
        if ($suggestions.length === 0) {
            $suggestions = $('<div class="xb-yuzhifoot-search-suggestions"></div>');
            $('.xb-yuzhifoot-search-input').after($suggestions);
        }
        
        var html = '<div class="xb-yuzhifoot-suggestions-title">搜索历史</div>';
        history.forEach(function(term) {
            html += '<div class="xb-yuzhifoot-suggestion-item" data-term="' + term + '">' + term + '</div>';
        });
        
        $suggestions.html(html).show();
        
        // 绑定点击事件
        $('.xb-yuzhifoot-suggestion-item').on('click', function() {
            var term = $(this).data('term');
            $('.xb-yuzhifoot-search-input').val(term);
            $('#xb-yuzhifoot-search-form').submit();
        });
    }
    
    /**
     * 隐藏搜索建议
     */
    function hideSearchSuggestions() {
        $('.xb-yuzhifoot-search-suggestions').hide();
    }
    
    /**
     * 初始化收藏功能
     */
    function initFavorites() {
        // 为每个食材卡片添加收藏按钮
        $('.xb-yuzhifoot-food-card').each(function() {
            var $card = $(this);
            var foodId = $card.data('food-id') || Math.random().toString(36).substr(2, 9);
            
            var $favoriteBtn = $('<button class="xb-yuzhifoot-favorite-btn" data-food-id="' + foodId + '">♡</button>');
            
            // 检查是否已收藏
            if (isFavorite(foodId)) {
                $favoriteBtn.addClass('favorited').text('♥');
            }
            
            $favoriteBtn.on('click', function(e) {
                e.preventDefault();
                toggleFavorite(foodId, $favoriteBtn);
            });
            
            $card.find('.xb-yuzhifoot-food-content').prepend($favoriteBtn);
        });
    }
    
    /**
     * 检查是否已收藏
     */
    function isFavorite(foodId) {
        var favorites = getFavorites();
        return favorites.includes(foodId);
    }
    
    /**
     * 获取收藏列表
     */
    function getFavorites() {
        var favorites = localStorage.getItem('xb_yuzhifoot_favorites');
        return favorites ? JSON.parse(favorites) : [];
    }
    
    /**
     * 切换收藏状态
     */
    function toggleFavorite(foodId, $btn) {
        var favorites = getFavorites();
        var index = favorites.indexOf(foodId);
        
        if (index > -1) {
            // 取消收藏
            favorites.splice(index, 1);
            $btn.removeClass('favorited').text('♡');
            showMessage('已取消收藏', 'info');
        } else {
            // 添加收藏
            favorites.push(foodId);
            $btn.addClass('favorited').text('♥');
            showMessage('已添加到收藏', 'success');
        }
        
        localStorage.setItem('xb_yuzhifoot_favorites', JSON.stringify(favorites));
    }
    
    /**
     * 初始化数据验证
     */
    function initDataValidation() {
        // 表单验证
        $('#xb-yuzhifoot-search-form').on('submit', function(e) {
            var isValid = validateSearchForm();
            if (!isValid) {
                e.preventDefault();
                return false;
            }
        });
    }
    
    /**
     * 验证搜索表单
     */
    function validateSearchForm() {
        var $searchInput = $('.xb-yuzhifoot-search-input');
        var searchValue = $searchInput.val().trim();
        
        // 检查搜索关键词长度
        if (searchValue.length > 0 && searchValue.length < 2) {
            showMessage('搜索关键词至少需要2个字符', 'warning');
            $searchInput.focus();
            return false;
        }
        
        // 检查是否包含特殊字符
        var specialChars = /[<>'"&]/;
        if (specialChars.test(searchValue)) {
            showMessage('搜索关键词不能包含特殊字符', 'warning');
            $searchInput.focus();
            return false;
        }
        
        return true;
    }
    
    /**
     * 初始化用户交互功能
     */
    function initUserInteraction() {
        // 添加键盘快捷键支持
        initKeyboardShortcuts();
        
        // 添加触摸手势支持
        initTouchGestures();
        
        // 添加无障碍支持
        initAccessibility();
    }
    
    /**
     * 初始化键盘快捷键
     */
    function initKeyboardShortcuts() {
        $(document).on('keydown', function(e) {
            // Ctrl + K 或 Cmd + K 聚焦搜索框
            if ((e.ctrlKey || e.metaKey) && e.keyCode === 75) {
                e.preventDefault();
                $('.xb-yuzhifoot-search-input').focus();
            }
            
            // ESC 清空搜索框
            if (e.keyCode === 27) {
                $('.xb-yuzhifoot-search-input').val('').blur();
                hideSearchSuggestions();
            }
        });
    }
    
    /**
     * 初始化触摸手势
     */
    function initTouchGestures() {
        // 为移动设备添加滑动刷新功能
        var startY = 0;
        var $container = $('.xb-yuzhifoot-container');
        
        $container.on('touchstart', function(e) {
            startY = e.originalEvent.touches[0].clientY;
        });
        
        $container.on('touchmove', function(e) {
            var currentY = e.originalEvent.touches[0].clientY;
            var diff = currentY - startY;
            
            // 如果向下滑动超过100px且在页面顶部
            if (diff > 100 && $(window).scrollTop() === 0) {
                // 可以添加下拉刷新功能
                // refreshData();
            }
        });
    }
    
    /**
     * 初始化无障碍支持
     */
    function initAccessibility() {
        // 为搜索输入框添加ARIA标签
        $('.xb-yuzhifoot-search-input').attr({
            'aria-label': '搜索预制菜品',
            'role': 'searchbox'
        });
        
        // 为筛选器添加ARIA标签
        $('.xb-yuzhifoot-select').each(function() {
            var $this = $(this);
            var label = $this.prev('label').text() || '筛选选项';
            $this.attr('aria-label', label);
        });
        
        // 为食材卡片添加键盘导航支持
        $('.xb-yuzhifoot-food-card').attr('tabindex', '0').on('keydown', function(e) {
            if (e.keyCode === 13 || e.keyCode === 32) { // Enter或空格键
                var $purchaseBtn = $(this).find('.xb-yuzhifoot-purchase-btn');
                if ($purchaseBtn.length) {
                    $purchaseBtn[0].click();
                }
            }
        });
    }
    
    /**
     * 显示消息提示
     */
    function showMessage(message, type) {
        type = type || 'info';
        
        var $messageContainer = $('.xb-yuzhifoot-message-container');
        if ($messageContainer.length === 0) {
            $messageContainer = $('<div class="xb-yuzhifoot-message-container"></div>');
            $('.xb-yuzhifoot-container').prepend($messageContainer);
        }
        
        var $message = $('<div class="xb-yuzhifoot-message xb-yuzhifoot-message-' + type + '">' + message + '</div>');
        $messageContainer.append($message);
        
        $message.fadeIn(300);
        
        setTimeout(function() {
            $message.fadeOut(300, function() {
                $(this).remove();
            });
        }, 3000);
    }
    
    /**
     * 数据统计和分析
     */
    function trackUserBehavior(action, data) {
        // 记录用户行为用于分析
        var behaviorData = {
            action: action,
            data: data,
            timestamp: new Date().getTime(),
            url: window.location.href
        };
        
        // 保存到本地存储
        var behaviors = JSON.parse(localStorage.getItem('xb_yuzhifoot_behaviors') || '[]');
        behaviors.push(behaviorData);
        
        // 限制存储数量
        if (behaviors.length > 100) {
            behaviors = behaviors.slice(-50);
        }
        
        localStorage.setItem('xb_yuzhifoot_behaviors', JSON.stringify(behaviors));
    }
    
    // 绑定用户行为追踪
    $('.xb-yuzhifoot-search-btn').on('click', function() {
        trackUserBehavior('search', {
            keyword: $('.xb-yuzhifoot-search-input').val()
        });
    });
    
    $('.xb-yuzhifoot-select').on('change', function() {
        trackUserBehavior('filter', {
            type: $(this).attr('name'),
            value: $(this).val()
        });
    });
    
    $('.xb-yuzhifoot-purchase-btn').on('click', function() {
        trackUserBehavior('purchase_click', {
            food_name: $(this).closest('.xb-yuzhifoot-food-card').find('.xb-yuzhifoot-food-title').text()
        });
    });
    
})(jQuery);