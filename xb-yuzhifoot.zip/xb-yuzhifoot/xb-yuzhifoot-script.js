/**
 * 预制菜查询插件前端JavaScript
 */

(function($) {
    'use strict';
    
    // 插件初始化
    $(document).ready(function() {
        xbYuzhifootInit();
    });
    
    /**
     * 插件初始化函数
     */
    function xbYuzhifootInit() {
        // 绑定搜索表单事件
        bindSearchFormEvents();
        
        // 绑定筛选器事件
        bindFilterEvents();
        
        // 初始化懒加载
        initLazyLoading();
        
        // 初始化工具提示
        initTooltips();
        
        // 防止重复提交
        preventDuplicateSubmission();
    }
    
    /**
     * 绑定搜索表单事件
     */
    function bindSearchFormEvents() {
        var $searchForm = $('#xb-yuzhifoot-search-form');
        var $searchInput = $('.xb-yuzhifoot-search-input');
        
        // 搜索表单提交事件
        $searchForm.on('submit', function(e) {
            // 验证表单
            if (!validateSearchForm()) {
                e.preventDefault();
                return false;
            }
            
            // 显示加载状态
            showLoadingState();
        });
        
        // 搜索输入框回车事件
        $searchInput.on('keypress', function(e) {
            if (e.which === 13) {
                $searchForm.submit();
            }
        });
        
        // 实时搜索建议（可选功能）
        var searchTimeout;
        $searchInput.on('input', function() {
            clearTimeout(searchTimeout);
            var query = $(this).val().trim();
            
            if (query.length >= 2) {
                searchTimeout = setTimeout(function() {
                    // 这里可以添加实时搜索建议功能
                    // showSearchSuggestions(query);
                }, 300);
            }
        });
    }
    
    /**
     * 绑定筛选器事件
     */
    function bindFilterEvents() {
        var $filterSelects = $('.xb-yuzhifoot-select');
        
        // 筛选器变化事件
        $filterSelects.on('change', function() {
            var $this = $(this);
            var hasValue = $this.val() !== '';
            
            // 添加视觉反馈
            if (hasValue) {
                $this.addClass('xb-yuzhifoot-select-active');
            } else {
                $this.removeClass('xb-yuzhifoot-select-active');
            }
            
            // 自动提交表单（可选）
            // setTimeout(function() {
            //     $('#xb-yuzhifoot-search-form').submit();
            // }, 100);
        });
        
        // 初始化已选择的筛选器样式
        $filterSelects.each(function() {
            var $this = $(this);
            if ($this.val() !== '') {
                $this.addClass('xb-yuzhifoot-select-active');
            }
        });
    }
    
    /**
     * 初始化懒加载
     */
    function initLazyLoading() {
        var $images = $('.xb-yuzhifoot-food-image img');
        
        // 如果浏览器支持Intersection Observer
        if ('IntersectionObserver' in window) {
            var imageObserver = new IntersectionObserver(function(entries, observer) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        var img = entry.target;
                        img.src = img.dataset.src || img.src;
                        img.classList.remove('xb-yuzhifoot-lazy');
                        imageObserver.unobserve(img);
                    }
                });
            });
            
            $images.each(function() {
                imageObserver.observe(this);
            });
        }
        
        // 图片加载错误处理
        $images.on('error', function() {
            var $this = $(this);
            if (!$this.hasClass('xb-yuzhifoot-error-handled')) {
                $this.addClass('xb-yuzhifoot-error-handled');
                $this.attr('src', 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPuaXoOazleWKoOi9veWbvueJhzwvdGV4dD48L3N2Zz4=');
            }
        });
    }
    
    /**
     * 初始化工具提示
     */
    function initTooltips() {
        // 为购买按钮添加工具提示
        $('.xb-yuzhifoot-purchase-btn').on('mouseenter', function() {
            var $this = $(this);
            if (!$this.attr('title')) {
                $this.attr('title', '点击前往购买页面');
            }
        });
        
        // 为品牌标签添加工具提示
        $('.xb-yuzhifoot-food-brand').on('mouseenter', function() {
            var $this = $(this);
            if (!$this.attr('title')) {
                $this.attr('title', '点击查看该品牌的所有产品');
            }
        });
    }
    
    /**
     * 防止重复提交
     */
    function preventDuplicateSubmission() {
        // 监听页面刷新事件
        $(window).on('beforeunload', function() {
            // 如果URL中包含搜索参数，清除它们
            if (window.location.search.includes('xb_search') || 
                window.location.search.includes('xb_brand') ||
                window.location.search.includes('xb_scene')) {
                
                // 使用replaceState清除搜索参数
                var cleanUrl = window.location.pathname;
                window.history.replaceState({}, document.title, cleanUrl);
            }
        });
        
        // 监听浏览器后退按钮
        $(window).on('popstate', function() {
            // 刷新页面以确保状态正确
            window.location.reload();
        });
    }
    
    /**
     * 显示加载状态
     */
    function showLoadingState() {
        var $searchBtn = $('.xb-yuzhifoot-search-btn');
        var originalText = $searchBtn.text();
        
        $searchBtn.text('搜索中...').prop('disabled', true);
        
        // 3秒后恢复按钮状态（防止卡住）
        setTimeout(function() {
            $searchBtn.text(originalText).prop('disabled', false);
        }, 3000);
    }
    
    /**
     * 显示消息提示
     */
    function showMessage(message, type) {
        type = type || 'info';
        
        // 创建消息容器
        var $messageContainer = $('.xb-yuzhifoot-message-container');
        if ($messageContainer.length === 0) {
            $messageContainer = $('<div class="xb-yuzhifoot-message-container"></div>');
            $('.xb-yuzhifoot-container').prepend($messageContainer);
        }
        
        // 创建消息元素
        var $message = $('<div class="xb-yuzhifoot-message xb-yuzhifoot-message-' + type + '">' + message + '</div>');
        
        // 添加到容器
        $messageContainer.append($message);
        
        // 显示动画
        $message.fadeIn(300);
        
        // 3秒后自动隐藏
        setTimeout(function() {
            $message.fadeOut(300, function() {
                $(this).remove();
            });
        }, 3000);
    }
    
    /**
     * 显示居中模态框
     */
    function showCenterModal(message, type) {
        type = type || 'info';
        
        // 移除已存在的模态框
        $('.xb-yuzhifoot-modal').remove();
        
        // 创建模态框
        var $modal = $('<div class="xb-yuzhifoot-modal xb-yuzhifoot-modal-' + type + '">' +
                      '<div class="xb-yuzhifoot-modal-content">' +
                      '<div class="xb-yuzhifoot-modal-message">' + message + '</div>' +
                      '</div>' +
                      '</div>');
        
        // 添加到页面
        $('body').append($modal);
        
        // 显示动画
        $modal.addClass('show');
        
        // 2秒后自动隐藏
        setTimeout(function() {
            $modal.removeClass('show');
            setTimeout(function() {
                $modal.remove();
            }, 300);
        }, 2000);
        
        // 点击模态框背景关闭
        $modal.on('click', function(e) {
            if (e.target === this) {
                $modal.removeClass('show');
                setTimeout(function() {
                    $modal.remove();
                }, 300);
            }
        });
    }
    
    /**
     * 验证搜索表单
     */
    function validateSearchForm() {
        var $searchInput = $('.xb-yuzhifoot-search-input');
        var searchValue = $searchInput.val().trim();
        
        // 检查是否有搜索关键词或筛选条件
        var hasFilters = false;
        $('.xb-yuzhifoot-select').each(function() {
            if ($(this).val() !== '') {
                hasFilters = true;
                return false;
            }
        });
        
        // 如果没有搜索关键词且没有筛选条件
        if (searchValue === '' && !hasFilters) {
            showCenterModal('请输入搜索关键词或选择筛选条件', 'warning');
            $searchInput.focus();
            return false;
        }
        
        // 检查搜索关键词长度
        if (searchValue.length > 0 && searchValue.length < 2) {
            showCenterModal('搜索关键词至少需要2个字符', 'warning');
            $searchInput.focus();
            return false;
        }
        
        // 检查是否包含特殊字符
        var specialChars = /[<>'"&]/;
        if (specialChars.test(searchValue)) {
            showCenterModal('搜索关键词不能包含特殊字符', 'warning');
            $searchInput.focus();
            return false;
        }
        
        return true;
    }
    
    /**
     * AJAX搜索功能（可选）
     */
    function performAjaxSearch(params) {
        $.ajax({
            url: xb_yuzhifoot_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_yuzhifoot_search',
                nonce: xb_yuzhifoot_ajax.nonce,
                search_params: params
            },
            beforeSend: function() {
                showLoadingState();
            },
            success: function(response) {
                if (response.success) {
                    updateSearchResults(response.data);
                } else {
                    showMessage('搜索失败，请重试', 'error');
                }
            },
            error: function() {
                showMessage('网络错误，请检查连接', 'error');
            },
            complete: function() {
                hideLoadingState();
            }
        });
    }
    
    /**
     * 更新搜索结果
     */
    function updateSearchResults(data) {
        var $resultsContainer = $('.xb-yuzhifoot-foods-grid');
        var $resultInfo = $('.xb-yuzhifoot-result-info');
        var $pagination = $('.xb-yuzhifoot-pagination');
        
        // 更新结果信息
        $resultInfo.html('共找到 <span class="xb-yuzhifoot-count">' + data.total + '</span> 个预制菜品');
        
        // 更新结果列表
        $resultsContainer.html(data.html);
        
        // 更新分页
        if (data.pagination) {
            $pagination.html(data.pagination);
        }
        
        // 重新初始化懒加载
        initLazyLoading();
        
        // 滚动到结果区域
        $('html, body').animate({
            scrollTop: $resultInfo.offset().top - 20
        }, 500);
    }
    
    /**
     * 隐藏加载状态
     */
    function hideLoadingState() {
        var $searchBtn = $('.xb-yuzhifoot-search-btn');
        $searchBtn.text('搜索').prop('disabled', false);
    }
    
    /**
     * 品牌筛选功能
     */
    function filterByBrand(brandId) {
        var $brandSelect = $('select[name="xb_brand"]');
        $brandSelect.val(brandId);
        $('#xb-yuzhifoot-search-form').submit();
    }
    
    /**
     * 分类筛选功能
     */
    function filterByCategory(categoryType, categoryId) {
        var $categorySelect = $('select[name="xb_' + categoryType + '"]');
        $categorySelect.val(categoryId);
        $('#xb-yuzhifoot-search-form').submit();
    }
    
    /**
     * 重置所有筛选器
     */
    function resetAllFilters() {
        $('.xb-yuzhifoot-select').val('').removeClass('xb-yuzhifoot-select-active');
        $('.xb-yuzhifoot-search-input').val('');
    }
    
    /**
     * 获取当前筛选参数
     */
    function getCurrentFilters() {
        var filters = {};
        
        $('.xb-yuzhifoot-select').each(function() {
            var $this = $(this);
            var name = $this.attr('name');
            var value = $this.val();
            
            if (value !== '') {
                filters[name] = value;
            }
        });
        
        var searchValue = $('.xb-yuzhifoot-search-input').val().trim();
        if (searchValue !== '') {
            filters.xb_search = searchValue;
        }
        
        return filters;
    }
    
    /**
     * 保存筛选状态到本地存储
     */
    function saveFilterState() {
        var filters = getCurrentFilters();
        localStorage.setItem('xb_yuzhifoot_filters', JSON.stringify(filters));
    }
    
    /**
     * 从本地存储恢复筛选状态
     */
    function restoreFilterState() {
        var savedFilters = localStorage.getItem('xb_yuzhifoot_filters');
        if (savedFilters) {
            try {
                var filters = JSON.parse(savedFilters);
                
                Object.keys(filters).forEach(function(key) {
                    if (key === 'xb_search') {
                        $('.xb-yuzhifoot-search-input').val(filters[key]);
                    } else {
                        $('select[name="' + key + '"]').val(filters[key]).addClass('xb-yuzhifoot-select-active');
                    }
                });
            } catch (e) {
                console.log('恢复筛选状态失败:', e);
            }
        }
    }
    
    // 全局函数，供外部调用
    window.xbYuzhifootReset = function() {
        resetAllFilters();
        localStorage.removeItem('xb_yuzhifoot_filters');
        window.location.href = window.location.pathname;
    };
    
    window.xbYuzhifootFilterByBrand = filterByBrand;
    window.xbYuzhifootFilterByCategory = filterByCategory;
    
    // 切换详细信息显示
    window.xbYuzhifootToggleDetails = function(btn) {
        var $btn = $(btn);
        var $card = $btn.closest('.xb-yuzhifoot-food-card');
        var $details = $card.find('.xb-yuzhifoot-food-details-section');
        
        if ($details.is(':visible')) {
            $details.slideUp(300);
            $btn.text('查看详细');
        } else {
            $details.slideDown(300);
            $btn.text('收起详细');
        }
    };
    
    // 显示品牌信息
    window.xbYuzhifootShowBrandInfo = function(brandId) {
        var currentUrl = new URL(window.location.href);
        currentUrl.searchParams.set('xb_brand', brandId);
        window.location.href = currentUrl.toString();
    };
    
    // 关闭品牌信息
    window.xbYuzhifootCloseBrandInfo = function() {
        var currentUrl = new URL(window.location.href);
        currentUrl.searchParams.delete('xb_brand');
        window.location.href = currentUrl.toString();
    };
    
})(jQuery);