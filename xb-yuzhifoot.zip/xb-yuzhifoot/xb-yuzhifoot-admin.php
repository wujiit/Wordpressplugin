<?php
// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 主设置页面
 */
function xb_yuzhifoot_admin_main_page() {
    global $wpdb;
    
    // 处理表单提交
    if (isset($_POST['xb_yuzhifoot_save_settings'])) {
        $announcement = wp_kses_post($_POST['announcement']);
        
        $table_settings = $wpdb->prefix . 'xb_yuzhifoot_settings';
        $wpdb->replace(
            $table_settings,
            array(
                'setting_key' => 'announcement',
                'setting_value' => $announcement
            )
        );
        
        echo '<div class="notice notice-success is-dismissible" id="xb-yuzhifoot-notice"><p>设置已保存！</p></div>';
    }
    
    // 处理分类管理
    if (isset($_POST['xb_yuzhifoot_add_category'])) {
        $category_name = sanitize_text_field($_POST['category_name']);
        $category_type = sanitize_text_field($_POST['category_type']);
        
        if (!empty($category_name) && !empty($category_type)) {
            $table_categories = $wpdb->prefix . 'xb_yuzhifoot_categories';
            $wpdb->insert(
                $table_categories,
                array(
                    'category_name' => $category_name,
                    'category_type' => $category_type,
                    'sort_order' => 999
                )
            );
            echo '<div class="notice notice-success is-dismissible" id="xb-yuzhifoot-notice"><p>分类添加成功！</p></div>';
        }
    }
    
    if (isset($_POST['xb_yuzhifoot_delete_category'])) {
        $category_id = intval($_POST['category_id']);
        $table_categories = $wpdb->prefix . 'xb_yuzhifoot_categories';
        $wpdb->delete($table_categories, array('id' => $category_id));
        echo '<div class="notice notice-success is-dismissible" id="xb-yuzhifoot-notice"><p>分类删除成功！</p></div>';
    }
    
    if (isset($_POST['xb_yuzhifoot_edit_category'])) {
        $category_id = intval($_POST['category_id']);
        $category_name = sanitize_text_field($_POST['category_name']);
        
        if (!empty($category_name)) {
            $table_categories = $wpdb->prefix . 'xb_yuzhifoot_categories';
            $wpdb->update(
                $table_categories,
                array('category_name' => $category_name),
                array('id' => $category_id)
            );
            echo '<div class="notice notice-success is-dismissible" id="xb-yuzhifoot-notice"><p>分类更新成功！</p></div>';
        }
    }
    
    // 获取统计数据
    $table_brands = $wpdb->prefix . 'xb_yuzhifoot_brands';
    $table_foods = $wpdb->prefix . 'xb_yuzhifoot_foods';
    $table_categories = $wpdb->prefix . 'xb_yuzhifoot_categories';
    $table_settings = $wpdb->prefix . 'xb_yuzhifoot_settings';
    
    $brands_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_brands");
    $foods_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_foods");
    
    // 获取当前设置
    $announcement = $wpdb->get_var($wpdb->prepare("SELECT setting_value FROM $table_settings WHERE setting_key = %s", 'announcement'));
    
    // 获取分类数据
    $categories = $wpdb->get_results("SELECT * FROM $table_categories ORDER BY category_type, sort_order");
    $categories_by_type = array();
    foreach ($categories as $category) {
        $categories_by_type[$category->category_type][] = $category;
    }
    
    ?>
    <div class="wrap">
        <h1>预制菜管理 - 主设置</h1>
        
        <!-- 数据统计 -->
        <div class="card">
            <h2>数据统计</h2>
            <table class="form-table">
                <tr>
                    <th>已添加品牌数量</th>
                    <td><strong><?php echo $brands_count; ?></strong> 个</td>
                </tr>
                <tr>
                    <th>已添加食材数量</th>
                    <td><strong><?php echo $foods_count; ?></strong> 个</td>
                </tr>
            </table>
        </div>
        
        <!-- 公告设置 -->
        <div class="card">
            <h2>公告设置</h2>
            <form method="post">
                <table class="form-table">
                    <tr>
                        <th><label for="announcement">前台公告内容</label></th>
                        <td>
                            <textarea name="announcement" id="announcement" rows="5" cols="50" class="large-text"><?php echo esc_textarea($announcement); ?></textarea>
                            <p class="description">支持HTML格式，将在前台页面底部显示</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('保存设置', 'primary', 'xb_yuzhifoot_save_settings'); ?>
            </form>
        </div>
        
        <!-- 分类管理 -->
        <div class="card">
            <h2>分类管理</h2>
            
            <!-- 添加分类 -->
            <h3>添加新分类</h3>
            <form method="post">
                <table class="form-table">
                    <tr>
                        <th><label for="category_name">分类名称</label></th>
                        <td><input type="text" name="category_name" id="category_name" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="category_type">分类类型</label></th>
                        <td>
                            <select name="category_type" id="category_type" required>
                                <option value="">请选择分类类型</option>
                                <option value="scene">场景化分类</option>
                                <option value="demand">需求分类</option>
                                <option value="ingredient">食材类型分类</option>
                                <option value="price">价格区间</option>
                                <option value="taste">口味</option>
                                <option value="shelf_life">保质期</option>
                            </select>
                        </td>
                    </tr>
                </table>
                <?php submit_button('添加分类', 'secondary', 'xb_yuzhifoot_add_category'); ?>
            </form>
            
            <!-- 分类列表 -->
            <?php 
            $type_labels = array(
                'scene' => '场景化分类',
                'demand' => '需求分类',
                'ingredient' => '食材类型分类',
                'price' => '价格区间',
                'taste' => '口味',
                'shelf_life' => '保质期'
            );
            
            foreach ($type_labels as $type => $label):
                if (isset($categories_by_type[$type])):
            ?>
                <h3><?php echo $label; ?></h3>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>分类名称</th>
                            <th>创建时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories_by_type[$type] as $category): ?>
                            <tr>
                                <td><?php echo $category->id; ?></td>
                                <td>
                                    <span id="category-name-<?php echo $category->id; ?>"><?php echo esc_html($category->category_name); ?></span>
                                    <input type="text" id="category-edit-<?php echo $category->id; ?>" value="<?php echo esc_attr($category->category_name); ?>" style="display:none;">
                                </td>
                                <td><?php echo $category->created_time; ?></td>
                                <td>
                                    <button type="button" class="button" onclick="xbYuzhifootEditCategory(<?php echo $category->id; ?>)">编辑</button>
                                    <button type="button" class="button" onclick="xbYuzhifootSaveCategory(<?php echo $category->id; ?>)" style="display:none;" id="save-btn-<?php echo $category->id; ?>">保存</button>
                                    <button type="button" class="button" onclick="xbYuzhifootCancelEdit(<?php echo $category->id; ?>)" style="display:none;" id="cancel-btn-<?php echo $category->id; ?>">取消</button>
                                    <form method="post" style="display:inline;" onsubmit="return confirm('确定要删除这个分类吗？');">
                                        <input type="hidden" name="category_id" value="<?php echo $category->id; ?>">
                                        <input type="submit" name="xb_yuzhifoot_delete_category" value="删除" class="button button-link-delete">
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php 
                endif;
            endforeach; 
            ?>
        </div>
        
        <!-- 使用说明 -->
        <div class="card">
            <h2>使用说明</h2>
            <p>在页面或文章中使用短代码 <code>[yuzhifoot_list]</code> 来显示预制菜查询界面。</p>
            <p>可选参数：</p>
            <ul>
                <li><code>per_page</code> - 每页显示数量，默认20个</li>
            </ul>
            <p>示例：<code>[yuzhifoot_list per_page="30"]</code></p>
        </div>
    </div>
    
    <script>
    // 自动隐藏通知
    setTimeout(function() {
        var notice = document.getElementById('xb-yuzhifoot-notice');
        if (notice) {
            notice.style.display = 'none';
        }
    }, 3000);
    
    // 分类编辑功能
    function xbYuzhifootEditCategory(id) {
        document.getElementById('category-name-' + id).style.display = 'none';
        document.getElementById('category-edit-' + id).style.display = 'inline';
        document.getElementById('save-btn-' + id).style.display = 'inline';
        document.getElementById('cancel-btn-' + id).style.display = 'inline';
    }
    
    function xbYuzhifootCancelEdit(id) {
        document.getElementById('category-name-' + id).style.display = 'inline';
        document.getElementById('category-edit-' + id).style.display = 'none';
        document.getElementById('save-btn-' + id).style.display = 'none';
        document.getElementById('cancel-btn-' + id).style.display = 'none';
    }
    
    function xbYuzhifootSaveCategory(id) {
        var newName = document.getElementById('category-edit-' + id).value;
        if (newName.trim() === '') {
            alert('分类名称不能为空');
            return;
        }
        
        var form = document.createElement('form');
        form.method = 'post';
        form.innerHTML = '<input type="hidden" name="category_id" value="' + id + '">' +
                        '<input type="hidden" name="category_name" value="' + newName + '">' +
                        '<input type="hidden" name="xb_yuzhifoot_edit_category" value="1">';
        document.body.appendChild(form);
        form.submit();
    }
    </script>
    
    <style>
    .card {
        background: #fff;
        border: 1px solid #ccd0d4;
        border-radius: 4px;
        margin: 20px 0;
        padding: 20px;
    }
    .card h2 {
        margin-top: 0;
    }
    </style>
    <?php
}

/**
 * 品牌管理页面
 */
function xb_yuzhifoot_admin_brands_page() {
    global $wpdb;
    
    $table_brands = $wpdb->prefix . 'xb_yuzhifoot_brands';
    
    // 处理表单提交
    if (isset($_POST['xb_yuzhifoot_add_brand'])) {
        $brand_data = array(
            'brand_name' => sanitize_text_field($_POST['brand_name']),
            'brand_logo' => esc_url_raw($_POST['brand_logo']),
            'establish_time' => sanitize_text_field($_POST['establish_time']),
            'company_name' => sanitize_text_field($_POST['company_name']),
            'headquarters' => sanitize_text_field($_POST['headquarters']),
            'brand_intro' => wp_kses_post($_POST['brand_intro']),
            'official_website' => esc_url_raw($_POST['official_website']),
            'tmall_link' => esc_url_raw($_POST['tmall_link']),
            'link_1688' => esc_url_raw($_POST['link_1688']),
            'jd_link' => esc_url_raw($_POST['jd_link']),
            'pdd_link' => esc_url_raw($_POST['pdd_link']),
            'sort_order' => intval($_POST['sort_order'])
        );
        
        if (!empty($brand_data['brand_name'])) {
            $wpdb->insert($table_brands, $brand_data);
            echo '<div class="notice notice-success is-dismissible" id="xb-yuzhifoot-notice"><p>品牌添加成功！</p></div>';
        }
    }
    
    if (isset($_POST['xb_yuzhifoot_edit_brand'])) {
        $brand_id = intval($_POST['brand_id']);
        $brand_data = array(
            'brand_name' => sanitize_text_field($_POST['brand_name']),
            'brand_logo' => esc_url_raw($_POST['brand_logo']),
            'establish_time' => sanitize_text_field($_POST['establish_time']),
            'company_name' => sanitize_text_field($_POST['company_name']),
            'headquarters' => sanitize_text_field($_POST['headquarters']),
            'brand_intro' => wp_kses_post($_POST['brand_intro']),
            'official_website' => esc_url_raw($_POST['official_website']),
            'tmall_link' => esc_url_raw($_POST['tmall_link']),
            'link_1688' => esc_url_raw($_POST['link_1688']),
            'jd_link' => esc_url_raw($_POST['jd_link']),
            'pdd_link' => esc_url_raw($_POST['pdd_link']),
            'sort_order' => intval($_POST['sort_order'])
        );
        
        if (!empty($brand_data['brand_name'])) {
            $wpdb->update($table_brands, $brand_data, array('id' => $brand_id));
            echo '<div class="notice notice-success is-dismissible" id="xb-yuzhifoot-notice"><p>品牌更新成功！</p></div>';
        }
    }
    
    if (isset($_POST['xb_yuzhifoot_delete_brand'])) {
        $brand_id = intval($_POST['brand_id']);
        $wpdb->delete($table_brands, array('id' => $brand_id));
        echo '<div class="notice notice-success is-dismissible" id="xb-yuzhifoot-notice"><p>品牌删除成功！</p></div>';
    }
    
    // 分页处理
    $per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;
    
    $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table_brands");
    $total_pages = ceil($total_items / $per_page);
    
    $brands = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_brands ORDER BY sort_order, brand_name LIMIT %d OFFSET %d", $per_page, $offset));
    
    // 编辑模式
    $edit_brand = null;
    if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['brand_id'])) {
        $brand_id = intval($_GET['brand_id']);
        $edit_brand = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_brands WHERE id = %d", $brand_id));
    }
    
    ?>
    <div class="wrap">
        <h1>品牌资料库管理</h1>
        
        <!-- 添加/编辑品牌表单 -->
        <div class="card">
            <h2><?php echo $edit_brand ? '编辑品牌' : '添加新品牌'; ?></h2>
            <form method="post">
                <?php if ($edit_brand): ?>
                    <input type="hidden" name="brand_id" value="<?php echo $edit_brand->id; ?>">
                <?php endif; ?>
                
                <table class="form-table">
                    <tr>
                        <th><label for="brand_name">品牌名称 *</label></th>
                        <td><input type="text" name="brand_name" id="brand_name" value="<?php echo $edit_brand ? esc_attr($edit_brand->brand_name) : ''; ?>" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="brand_logo">品牌Logo链接</label></th>
                        <td><input type="url" name="brand_logo" id="brand_logo" value="<?php echo $edit_brand ? esc_attr($edit_brand->brand_logo) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="establish_time">品牌成立时间</label></th>
                        <td><input type="text" name="establish_time" id="establish_time" value="<?php echo $edit_brand ? esc_attr($edit_brand->establish_time) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="company_name">品牌公司名称</label></th>
                        <td><input type="text" name="company_name" id="company_name" value="<?php echo $edit_brand ? esc_attr($edit_brand->company_name) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="headquarters">品牌总部</label></th>
                        <td><input type="text" name="headquarters" id="headquarters" value="<?php echo $edit_brand ? esc_attr($edit_brand->headquarters) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="brand_intro">品牌简介</label></th>
                        <td>
                            <textarea name="brand_intro" id="brand_intro" rows="5" cols="50" class="large-text"><?php echo $edit_brand ? esc_textarea($edit_brand->brand_intro) : ''; ?></textarea>
                            <p class="description">支持HTML格式</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="official_website">品牌官网</label></th>
                        <td><input type="url" name="official_website" id="official_website" value="<?php echo $edit_brand ? esc_attr($edit_brand->official_website) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="tmall_link">品牌天猫店链接</label></th>
                        <td><input type="url" name="tmall_link" id="tmall_link" value="<?php echo $edit_brand ? esc_attr($edit_brand->tmall_link) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="link_1688">品牌1688店链接</label></th>
                        <td><input type="url" name="link_1688" id="link_1688" value="<?php echo $edit_brand ? esc_attr($edit_brand->link_1688) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="jd_link">品牌京东店链接</label></th>
                        <td><input type="url" name="jd_link" id="jd_link" value="<?php echo $edit_brand ? esc_attr($edit_brand->jd_link) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="pdd_link">品牌拼多多店链接</label></th>
                        <td><input type="url" name="pdd_link" id="pdd_link" value="<?php echo $edit_brand ? esc_attr($edit_brand->pdd_link) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="sort_order">排序</label></th>
                        <td><input type="number" name="sort_order" id="sort_order" value="<?php echo $edit_brand ? esc_attr($edit_brand->sort_order) : '0'; ?>" class="small-text"></td>
                    </tr>
                </table>
                
                <?php if ($edit_brand): ?>
                    <?php submit_button('更新品牌', 'primary', 'xb_yuzhifoot_edit_brand'); ?>
                    <a href="<?php echo admin_url('admin.php?page=xb-yuzhifoot-brands'); ?>" class="button">取消编辑</a>
                <?php else: ?>
                    <?php submit_button('添加品牌', 'primary', 'xb_yuzhifoot_add_brand'); ?>
                <?php endif; ?>
            </form>
        </div>
        
        <!-- 品牌列表 -->
        <div class="card">
            <h2>品牌列表</h2>
            <?php if ($brands): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>品牌名称</th>
                            <th>公司名称</th>
                            <th>成立时间</th>
                            <th>总部</th>
                            <th>排序</th>
                            <th>创建时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($brands as $brand): ?>
                            <tr>
                                <td><?php echo $brand->id; ?></td>
                                <td><strong><?php echo esc_html($brand->brand_name); ?></strong></td>
                                <td><?php echo esc_html($brand->company_name); ?></td>
                                <td><?php echo esc_html($brand->establish_time); ?></td>
                                <td><?php echo esc_html($brand->headquarters); ?></td>
                                <td><?php echo $brand->sort_order; ?></td>
                                <td><?php echo $brand->created_time; ?></td>
                                <td>
                                    <a href="<?php echo admin_url('admin.php?page=xb-yuzhifoot-brands&action=edit&brand_id=' . $brand->id); ?>" class="button">编辑</a>
                                    <form method="post" style="display:inline;" onsubmit="return confirm('确定要删除这个品牌吗？');">
                                        <input type="hidden" name="brand_id" value="<?php echo $brand->id; ?>">
                                        <input type="submit" name="xb_yuzhifoot_delete_brand" value="删除" class="button button-link-delete">
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <!-- 分页 -->
                <?php if ($total_pages > 1): ?>
                    <div class="tablenav">
                        <div class="tablenav-pages">
                            <?php
                            $page_links = paginate_links(array(
                                'base' => add_query_arg('paged', '%#%'),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $current_page
                            ));
                            echo $page_links;
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <p>暂无品牌数据</p>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    // 自动隐藏通知
    setTimeout(function() {
        var notice = document.getElementById('xb-yuzhifoot-notice');
        if (notice) {
            notice.style.display = 'none';
        }
    }, 3000);
    </script>
    
    <style>
    .card {
        background: #fff;
        border: 1px solid #ccd0d4;
        border-radius: 4px;
        margin: 20px 0;
        padding: 20px;
    }
    .card h2 {
        margin-top: 0;
    }
    </style>
    <?php
}

/**
 * 食材管理页面
 */
function xb_yuzhifoot_admin_foods_page() {
    global $wpdb;
    
    $table_foods = $wpdb->prefix . 'xb_yuzhifoot_foods';
    $table_brands = $wpdb->prefix . 'xb_yuzhifoot_brands';
    $table_categories = $wpdb->prefix . 'xb_yuzhifoot_categories';
    
    // 处理表单提交
    if (isset($_POST['xb_yuzhifoot_add_food'])) {
        $food_data = array(
            'food_name' => sanitize_text_field($_POST['food_name']),
            'brand_id' => intval($_POST['brand_id']),
            'food_image' => esc_url_raw($_POST['food_image']),
            'net_weight' => sanitize_text_field($_POST['net_weight']),
            'price' => sanitize_text_field($_POST['price']),
            'storage_condition' => sanitize_text_field($_POST['storage_condition']),
            'ingredients' => sanitize_textarea_field($_POST['ingredients']),
            'nutrition_info' => sanitize_textarea_field($_POST['nutrition_info']),
            'update_date' => sanitize_text_field($_POST['update_date']),
            'purchase_link' => esc_url_raw($_POST['purchase_link']),
            'advanced_tips' => sanitize_textarea_field($_POST['advanced_tips']),
            'ingredient_analysis' => sanitize_textarea_field($_POST['ingredient_analysis']),
            'allergen_warning' => sanitize_textarea_field($_POST['allergen_warning']),
            'nutrition_analysis' => sanitize_textarea_field($_POST['nutrition_analysis']),
            'scene_categories' => isset($_POST['scene_categories']) ? implode(',', array_map('intval', $_POST['scene_categories'])) : '',
            'demand_categories' => isset($_POST['demand_categories']) ? implode(',', array_map('intval', $_POST['demand_categories'])) : '',
            'ingredient_categories' => isset($_POST['ingredient_categories']) ? implode(',', array_map('intval', $_POST['ingredient_categories'])) : '',
            'price_categories' => isset($_POST['price_categories']) ? implode(',', array_map('intval', $_POST['price_categories'])) : '',
            'taste_categories' => isset($_POST['taste_categories']) ? implode(',', array_map('intval', $_POST['taste_categories'])) : '',
            'shelf_life_categories' => isset($_POST['shelf_life_categories']) ? implode(',', array_map('intval', $_POST['shelf_life_categories'])) : ''
        );
        
        if (!empty($food_data['food_name'])) {
            $wpdb->insert($table_foods, $food_data);
            echo '<div class="notice notice-success is-dismissible" id="xb-yuzhifoot-notice"><p>食材添加成功！</p></div>';
        }
    }
    
    if (isset($_POST['xb_yuzhifoot_edit_food'])) {
        $food_id = intval($_POST['food_id']);
        $food_data = array(
            'food_name' => sanitize_text_field($_POST['food_name']),
            'brand_id' => intval($_POST['brand_id']),
            'food_image' => esc_url_raw($_POST['food_image']),
            'net_weight' => sanitize_text_field($_POST['net_weight']),
            'price' => sanitize_text_field($_POST['price']),
            'storage_condition' => sanitize_text_field($_POST['storage_condition']),
            'ingredients' => sanitize_textarea_field($_POST['ingredients']),
            'nutrition_info' => sanitize_textarea_field($_POST['nutrition_info']),
            'update_date' => sanitize_text_field($_POST['update_date']),
            'purchase_link' => esc_url_raw($_POST['purchase_link']),
            'advanced_tips' => sanitize_textarea_field($_POST['advanced_tips']),
            'ingredient_analysis' => sanitize_textarea_field($_POST['ingredient_analysis']),
            'allergen_warning' => sanitize_textarea_field($_POST['allergen_warning']),
            'nutrition_analysis' => sanitize_textarea_field($_POST['nutrition_analysis']),
            'scene_categories' => isset($_POST['scene_categories']) ? implode(',', array_map('intval', $_POST['scene_categories'])) : '',
            'demand_categories' => isset($_POST['demand_categories']) ? implode(',', array_map('intval', $_POST['demand_categories'])) : '',
            'ingredient_categories' => isset($_POST['ingredient_categories']) ? implode(',', array_map('intval', $_POST['ingredient_categories'])) : '',
            'price_categories' => isset($_POST['price_categories']) ? implode(',', array_map('intval', $_POST['price_categories'])) : '',
            'taste_categories' => isset($_POST['taste_categories']) ? implode(',', array_map('intval', $_POST['taste_categories'])) : '',
            'shelf_life_categories' => isset($_POST['shelf_life_categories']) ? implode(',', array_map('intval', $_POST['shelf_life_categories'])) : ''
        );
        
        if (!empty($food_data['food_name'])) {
            $wpdb->update($table_foods, $food_data, array('id' => $food_id));
            echo '<div class="notice notice-success is-dismissible" id="xb-yuzhifoot-notice"><p>食材更新成功！</p></div>';
        }
    }
    
    if (isset($_POST['xb_yuzhifoot_delete_food'])) {
        $food_id = intval($_POST['food_id']);
        $wpdb->delete($table_foods, array('id' => $food_id));
        echo '<div class="notice notice-success is-dismissible" id="xb-yuzhifoot-notice"><p>食材删除成功！</p></div>';
    }
    
    // 获取品牌和分类数据
    $brands = $wpdb->get_results("SELECT * FROM $table_brands ORDER BY sort_order, brand_name");
    $categories = $wpdb->get_results("SELECT * FROM $table_categories ORDER BY category_type, sort_order");
    
    $categories_by_type = array();
    foreach ($categories as $category) {
        $categories_by_type[$category->category_type][] = $category;
    }
    
    // 分页处理
    $per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;
    
    $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table_foods");
    $total_pages = ceil($total_items / $per_page);
    
    $foods = $wpdb->get_results($wpdb->prepare("
        SELECT f.*, b.brand_name 
        FROM $table_foods f 
        LEFT JOIN $table_brands b ON f.brand_id = b.id 
        ORDER BY f.created_time DESC 
        LIMIT %d OFFSET %d", $per_page, $offset));
    
    // 编辑模式
    $edit_food = null;
    if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['food_id'])) {
        $food_id = intval($_GET['food_id']);
        $edit_food = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_foods WHERE id = %d", $food_id));
    }
    
    ?>
    <div class="wrap">
        <h1>食材编辑管理</h1>
        
        <!-- 添加/编辑食材表单 -->
        <div class="card">
            <h2><?php echo $edit_food ? '编辑食材' : '添加新食材'; ?></h2>
            <form method="post">
                <?php if ($edit_food): ?>
                    <input type="hidden" name="food_id" value="<?php echo $edit_food->id; ?>">
                <?php endif; ?>
                
                <table class="form-table">
                    <tr>
                        <th><label for="food_name">菜品名称 *</label></th>
                        <td><input type="text" name="food_name" id="food_name" value="<?php echo $edit_food ? esc_attr($edit_food->food_name) : ''; ?>" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="brand_id">品牌</label></th>
                        <td>
                            <select name="brand_id" id="brand_id">
                                <option value="0">请选择品牌</option>
                                <?php foreach ($brands as $brand): ?>
                                    <option value="<?php echo $brand->id; ?>" <?php selected($edit_food ? $edit_food->brand_id : 0, $brand->id); ?>>
                                        <?php echo esc_html($brand->brand_name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="food_image">菜品图片链接</label></th>
                        <td><input type="url" name="food_image" id="food_image" value="<?php echo $edit_food ? esc_attr($edit_food->food_image) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="net_weight">净含量</label></th>
                        <td><input type="text" name="net_weight" id="net_weight" value="<?php echo $edit_food ? esc_attr($edit_food->net_weight) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="price">价格</label></th>
                        <td><input type="text" name="price" id="price" value="<?php echo $edit_food ? esc_attr($edit_food->price) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="storage_condition">储存条件</label></th>
                        <td><input type="text" name="storage_condition" id="storage_condition" value="<?php echo $edit_food ? esc_attr($edit_food->storage_condition) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="ingredients">配料表</label></th>
                        <td><textarea name="ingredients" id="ingredients" rows="3" cols="50" class="large-text"><?php echo $edit_food ? esc_textarea($edit_food->ingredients) : ''; ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="nutrition_info">营养成分表</label></th>
                        <td><textarea name="nutrition_info" id="nutrition_info" rows="3" cols="50" class="large-text"><?php echo $edit_food ? esc_textarea($edit_food->nutrition_info) : ''; ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="update_date">更新日期</label></th>
                        <td>
                            <input type="date" name="update_date" id="update_date" value="<?php echo $edit_food ? esc_attr($edit_food->update_date) : ''; ?>" class="regular-text">
                            <button type="button" onclick="document.getElementById('update_date').value = new Date().toISOString().split('T')[0];" class="button">今天</button>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="purchase_link">购买链接</label></th>
                        <td><input type="url" name="purchase_link" id="purchase_link" value="<?php echo $edit_food ? esc_attr($edit_food->purchase_link) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="advanced_tips">进阶攻略</label></th>
                        <td><textarea name="advanced_tips" id="advanced_tips" rows="3" cols="50" class="large-text"><?php echo $edit_food ? esc_textarea($edit_food->advanced_tips) : ''; ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="ingredient_analysis">配料表解读</label></th>
                        <td><textarea name="ingredient_analysis" id="ingredient_analysis" rows="3" cols="50" class="large-text"><?php echo $edit_food ? esc_textarea($edit_food->ingredient_analysis) : ''; ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="allergen_warning">过敏原提示</label></th>
                        <td><textarea name="allergen_warning" id="allergen_warning" rows="2" cols="50" class="large-text"><?php echo $edit_food ? esc_textarea($edit_food->allergen_warning) : ''; ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="nutrition_analysis">营养分析</label></th>
                        <td><textarea name="nutrition_analysis" id="nutrition_analysis" rows="3" cols="50" class="large-text"><?php echo $edit_food ? esc_textarea($edit_food->nutrition_analysis) : ''; ?></textarea></td>
                    </tr>
                    
                    <!-- 分类选择 -->
                    <?php 
                    $category_fields = array(
                        'scene' => '场景化分类',
                        'demand' => '需求分类',
                        'ingredient' => '食材类型分类',
                        'price' => '价格区间',
                        'taste' => '口味',
                        'shelf_life' => '保质期'
                    );
                    
                    foreach ($category_fields as $type => $label):
                        if (isset($categories_by_type[$type])):
                            $selected_categories = $edit_food ? explode(',', $edit_food->{$type . '_categories'}) : array();
                    ?>
                        <tr>
                            <th><label><?php echo $label; ?></label></th>
                            <td>
                                <?php foreach ($categories_by_type[$type] as $category): ?>
                                    <label>
                                        <input type="checkbox" name="<?php echo $type; ?>_categories[]" value="<?php echo $category->id; ?>" 
                                               <?php checked(in_array($category->id, $selected_categories)); ?>>
                                        <?php echo esc_html($category->category_name); ?>
                                    </label><br>
                                <?php endforeach; ?>
                            </td>
                        </tr>
                    <?php 
                        endif;
                    endforeach; 
                    ?>
                </table>
                
                <?php if ($edit_food): ?>
                    <?php submit_button('更新食材', 'primary', 'xb_yuzhifoot_edit_food'); ?>
                    <a href="<?php echo admin_url('admin.php?page=xb-yuzhifoot-foods'); ?>" class="button">取消编辑</a>
                <?php else: ?>
                    <?php submit_button('添加食材', 'primary', 'xb_yuzhifoot_add_food'); ?>
                <?php endif; ?>
            </form>
        </div>
        
        <!-- 食材列表 -->
        <div class="card">
            <h2>食材列表</h2>
            <?php if ($foods): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>菜品名称</th>
                            <th>品牌</th>
                            <th>价格</th>
                            <th>净含量</th>
                            <th>更新日期</th>
                            <th>创建时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($foods as $food): ?>
                            <tr>
                                <td><?php echo $food->id; ?></td>
                                <td><strong><?php echo esc_html($food->food_name); ?></strong></td>
                                <td><?php echo esc_html($food->brand_name); ?></td>
                                <td><?php echo esc_html($food->price); ?></td>
                                <td><?php echo esc_html($food->net_weight); ?></td>
                                <td><?php echo $food->update_date; ?></td>
                                <td><?php echo $food->created_time; ?></td>
                                <td>
                                    <a href="<?php echo admin_url('admin.php?page=xb-yuzhifoot-foods&action=edit&food_id=' . $food->id); ?>" class="button">编辑</a>
                                    <form method="post" style="display:inline;" onsubmit="return confirm('确定要删除这个食材吗？');">
                                        <input type="hidden" name="food_id" value="<?php echo $food->id; ?>">
                                        <input type="submit" name="xb_yuzhifoot_delete_food" value="删除" class="button button-link-delete">
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <!-- 分页 -->
                <?php if ($total_pages > 1): ?>
                    <div class="tablenav">
                        <div class="tablenav-pages">
                            <?php
                            $page_links = paginate_links(array(
                                'base' => add_query_arg('paged', '%#%'),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $current_page
                            ));
                            echo $page_links;
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <p>暂无食材数据</p>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    // 自动隐藏通知
    setTimeout(function() {
        var notice = document.getElementById('xb-yuzhifoot-notice');
        if (notice) {
            notice.style.display = 'none';
        }
    }, 3000);
    </script>
    
    <style>
    .card {
        background: #fff;
        border: 1px solid #ccd0d4;
        border-radius: 4px;
        margin: 20px 0;
        padding: 20px;
    }
    .card h2 {
        margin-top: 0;
    }
    </style>
    <?php
}