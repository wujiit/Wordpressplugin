<?php
/**
 * Plugin Name: 预制菜查询插件
 * Plugin URI: https://www.jingxialai.com
 * Description: 一个功能完整的预制菜查询和管理插件
 * Version: 1.0.0
 * Author: summer
 */

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('XB_YUZHIFOOT_VERSION', '1.0.0');
define('XB_YUZHIFOOT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('XB_YUZHIFOOT_PLUGIN_PATH', plugin_dir_path(__FILE__));

class XB_YuzhiFood_Plugin {
    
    public function __construct() {
        // 插件激活和停用钩子
        register_activation_hook(__FILE__, array($this, 'xb_yuzhifoot_activate'));
        register_deactivation_hook(__FILE__, array($this, 'xb_yuzhifoot_deactivate'));
        
        // 初始化插件
        add_action('init', array($this, 'xb_yuzhifoot_init'));
        
        // 添加管理菜单
        add_action('admin_menu', array($this, 'xb_yuzhifoot_admin_menu'));
        
        // 注册短代码
        add_shortcode('yuzhifoot_list', array($this, 'xb_yuzhifoot_shortcode'));
        
        // 前端资源加载
        add_action('wp_enqueue_scripts', array($this, 'xb_yuzhifoot_enqueue_scripts'));
        
        // AJAX处理
        add_action('wp_ajax_xb_yuzhifoot_search', array($this, 'xb_yuzhifoot_ajax_search'));
        add_action('wp_ajax_nopriv_xb_yuzhifoot_search', array($this, 'xb_yuzhifoot_ajax_search'));
        add_action('wp_ajax_xb_yuzhifoot_get_brand_info', array($this, 'xb_yuzhifoot_ajax_get_brand_info'));
        add_action('wp_ajax_nopriv_xb_yuzhifoot_get_brand_info', array($this, 'xb_yuzhifoot_ajax_get_brand_info'));
    }
    
    /**
     * 插件激活时创建数据表
     */
    public function xb_yuzhifoot_activate() {
        $this->xb_yuzhifoot_create_tables();
        $this->xb_yuzhifoot_insert_default_data();
    }
    
    /**
     * 插件停用时的清理工作
     */
    public function xb_yuzhifoot_deactivate() {
        // 可以在这里添加停用时的清理工作
    }
    
    /**
     * 创建数据库表
     */
    private function xb_yuzhifoot_create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // 品牌表
        $table_brands = $wpdb->prefix . 'xb_yuzhifoot_brands';
        $sql_brands = "CREATE TABLE $table_brands (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            brand_name varchar(255) NOT NULL,
            brand_logo varchar(500) DEFAULT '',
            establish_time varchar(100) DEFAULT '',
            company_name varchar(255) DEFAULT '',
            headquarters varchar(255) DEFAULT '',
            brand_intro text DEFAULT '',
            official_website varchar(500) DEFAULT '',
            tmall_link varchar(500) DEFAULT '',
            link_1688 varchar(500) DEFAULT '',
            jd_link varchar(500) DEFAULT '',
            pdd_link varchar(500) DEFAULT '',
            sort_order int(11) DEFAULT 0,
            created_time datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // 分类表
        $table_categories = $wpdb->prefix . 'xb_yuzhifoot_categories';
        $sql_categories = "CREATE TABLE $table_categories (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            category_name varchar(255) NOT NULL,
            category_type varchar(50) NOT NULL COMMENT '分类类型：scene场景化，demand需求，ingredient食材类型，price价格区间，taste口味，shelf_life保质期',
            sort_order int(11) DEFAULT 0,
            created_time datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // 菜品表
        $table_foods = $wpdb->prefix . 'xb_yuzhifoot_foods';
        $sql_foods = "CREATE TABLE $table_foods (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            food_name varchar(255) NOT NULL,
            brand_id int(11) DEFAULT 0,
            food_image varchar(500) DEFAULT '',
            net_weight varchar(100) DEFAULT '',
            price varchar(100) DEFAULT '',
            storage_condition varchar(255) DEFAULT '',
            ingredients text DEFAULT '',
            nutrition_info text DEFAULT '',
            update_date date DEFAULT NULL,
            purchase_link varchar(500) DEFAULT '',
            advanced_tips text DEFAULT '' COMMENT '进阶攻略',
            ingredient_analysis text DEFAULT '' COMMENT '配料表解读',
            allergen_warning text DEFAULT '' COMMENT '过敏原提示',
            nutrition_analysis text DEFAULT '' COMMENT '营养分析',
            scene_categories varchar(255) DEFAULT '' COMMENT '场景化分类ID，逗号分隔',
            demand_categories varchar(255) DEFAULT '' COMMENT '需求分类ID，逗号分隔',
            ingredient_categories varchar(255) DEFAULT '' COMMENT '食材类型分类ID，逗号分隔',
            price_categories varchar(255) DEFAULT '' COMMENT '价格区间分类ID，逗号分隔',
            taste_categories varchar(255) DEFAULT '' COMMENT '口味分类ID，逗号分隔',
            shelf_life_categories varchar(255) DEFAULT '' COMMENT '保质期分类ID，逗号分隔',
            created_time datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // 插件设置表
        $table_settings = $wpdb->prefix . 'xb_yuzhifoot_settings';
        $sql_settings = "CREATE TABLE $table_settings (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            setting_key varchar(100) NOT NULL,
            setting_value text DEFAULT '',
            PRIMARY KEY (id),
            UNIQUE KEY setting_key (setting_key)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_brands);
        dbDelta($sql_categories);
        dbDelta($sql_foods);
        dbDelta($sql_settings);
    }
    
    /**
     * 插入默认数据
     */
    private function xb_yuzhifoot_insert_default_data() {
        global $wpdb;
        
        $table_categories = $wpdb->prefix . 'xb_yuzhifoot_categories';
        $table_settings = $wpdb->prefix . 'xb_yuzhifoot_settings';
        
        // 插入默认分类数据
        $default_categories = array(
            // 场景化分类
            array('早餐速食', 'scene'),
            array('午餐便当', 'scene'),
            array('晚餐硬菜', 'scene'),
            array('夜宵烧烤', 'scene'),
            
            // 需求分类
            array('健身减脂餐', 'demand'),
            array('儿童营养餐', 'demand'),
            array('宝妈宝爸专区', 'demand'),
            array('一人食专区', 'demand'),
            array('素食专区', 'demand'),
            
            // 食材类型
            array('肉类', 'ingredient'),
            array('水产', 'ingredient'),
            array('面点', 'ingredient'),
            array('汤羹', 'ingredient'),
            array('甜品', 'ingredient'),
            
            // 价格区间
            array('5元以内', 'price'),
            array('5-20元', 'price'),
            array('20-50元', 'price'),
            array('50元以上', 'price'),
            
            // 口味
            array('辣', 'taste'),
            array('咸', 'taste'),
            array('甜', 'taste'),
            array('酸', 'taste'),
            
            // 保质期
            array('3个月', 'shelf_life'),
            array('6个月', 'shelf_life'),
            array('12个月', 'shelf_life'),
        );
        
        foreach ($default_categories as $index => $category) {
            $wpdb->insert(
                $table_categories,
                array(
                    'category_name' => $category[0],
                    'category_type' => $category[1],
                    'sort_order' => $index + 1
                )
            );
        }
        
        // 插入默认设置
        $wpdb->insert(
            $table_settings,
            array(
                'setting_key' => 'announcement',
                'setting_value' => '欢迎使用预制菜查询插件！'
            )
        );
    }
    
    /**
     * 插件初始化
     */
    public function xb_yuzhifoot_init() {
        // 可以在这里添加初始化代码
    }
    
    /**
     * 添加管理菜单
     */
    public function xb_yuzhifoot_admin_menu() {
        add_menu_page(
            '预制菜管理',
            '预制菜管理',
            'manage_options',
            'xb-yuzhifoot-main',
            array($this, 'xb_yuzhifoot_admin_page_main'),
            'dashicons-carrot',
            30
        );
        
        add_submenu_page(
            'xb-yuzhifoot-main',
            '品牌资料库',
            '品牌资料库',
            'manage_options',
            'xb-yuzhifoot-brands',
            array($this, 'xb_yuzhifoot_admin_page_brands')
        );
        
        add_submenu_page(
            'xb-yuzhifoot-main',
            '食材编辑',
            '食材编辑',
            'manage_options',
            'xb-yuzhifoot-foods',
            array($this, 'xb_yuzhifoot_admin_page_foods')
        );
    }
    
    /**
     * 主设置页面
     */
    public function xb_yuzhifoot_admin_page_main() {
        include_once XB_YUZHIFOOT_PLUGIN_PATH . 'xb-yuzhifoot-admin.php';
        xb_yuzhifoot_admin_main_page();
    }
    
    /**
     * 品牌管理页面
     */
    public function xb_yuzhifoot_admin_page_brands() {
        include_once XB_YUZHIFOOT_PLUGIN_PATH . 'xb-yuzhifoot-admin.php';
        xb_yuzhifoot_admin_brands_page();
    }
    
    /**
     * 食材管理页面
     */
    public function xb_yuzhifoot_admin_page_foods() {
        include_once XB_YUZHIFOOT_PLUGIN_PATH . 'xb-yuzhifoot-admin.php';
        xb_yuzhifoot_admin_foods_page();
    }
    
    /**
     * 前端资源加载
     */
    public function xb_yuzhifoot_enqueue_scripts() {
        global $post;
        
        // 只在包含短代码的页面加载资源
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'yuzhifoot_list')) {
            wp_enqueue_style('xb-yuzhifoot-style', XB_YUZHIFOOT_PLUGIN_URL . 'xb-yuzhifoot-style.css', array(), XB_YUZHIFOOT_VERSION);
            wp_enqueue_script('xb-yuzhifoot-script', XB_YUZHIFOOT_PLUGIN_URL . 'xb-yuzhifoot-script.js', array('jquery'), XB_YUZHIFOOT_VERSION, true);
            
            // 传递AJAX URL到前端
            wp_localize_script('xb-yuzhifoot-script', 'xb_yuzhifoot_ajax', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('xb_yuzhifoot_nonce')
            ));
        }
    }
    
    /**
     * 短代码处理
     */
    public function xb_yuzhifoot_shortcode($atts) {
        $atts = shortcode_atts(array(
            'per_page' => 20,
        ), $atts);
        
        return $this->xb_yuzhifoot_render_frontend($atts);
    }
    
    /**
     * 渲染前端页面
     */
    private function xb_yuzhifoot_render_frontend($atts) {
        global $wpdb;
        
        $per_page = intval($atts['per_page']);
        $current_page = isset($_GET['xb_page']) ? max(1, intval($_GET['xb_page'])) : 1;
        $offset = ($current_page - 1) * $per_page;
        
        // 获取分类数据
        $table_categories = $wpdb->prefix . 'xb_yuzhifoot_categories';
        $categories = $wpdb->get_results("SELECT * FROM $table_categories ORDER BY category_type, sort_order");
        
        $categories_by_type = array();
        foreach ($categories as $category) {
            $categories_by_type[$category->category_type][] = $category;
        }
        
        // 获取品牌数据
        $table_brands = $wpdb->prefix . 'xb_yuzhifoot_brands';
        $brands = $wpdb->get_results("SELECT * FROM $table_brands ORDER BY sort_order, brand_name");
        
        // 构建查询条件
        $where_conditions = array('1=1');
        $search_keyword = '';
        
        if (isset($_GET['xb_search']) && !empty($_GET['xb_search'])) {
            $search_keyword = sanitize_text_field($_GET['xb_search']);
            $where_conditions[] = $wpdb->prepare("food_name LIKE %s", '%' . $search_keyword . '%');
        }
        
        // 分类筛选
        $filter_params = array('scene', 'demand', 'ingredient', 'price', 'taste', 'shelf_life');
        foreach ($filter_params as $param) {
            if (isset($_GET['xb_' . $param]) && !empty($_GET['xb_' . $param])) {
                $category_id = intval($_GET['xb_' . $param]);
                $where_conditions[] = $wpdb->prepare("FIND_IN_SET(%d, {$param}_categories)", $category_id);
            }
        }
        
        if (isset($_GET['xb_brand']) && !empty($_GET['xb_brand'])) {
            $brand_id = intval($_GET['xb_brand']);
            $where_conditions[] = $wpdb->prepare("brand_id = %d", $brand_id);
        }
        
        $where_clause = implode(' AND ', $where_conditions);
        
        // 获取食材数据
        $table_foods = $wpdb->prefix . 'xb_yuzhifoot_foods';
        $total_query = "SELECT COUNT(*) FROM $table_foods WHERE $where_clause";
        $total_items = $wpdb->get_var($total_query);
        
        $foods_query = "SELECT f.*, b.brand_name FROM $table_foods f 
                       LEFT JOIN $table_brands b ON f.brand_id = b.id 
                       WHERE $where_clause 
                       ORDER BY f.created_time DESC 
                       LIMIT $offset, $per_page";
        $foods = $wpdb->get_results($foods_query);
        
        // 获取公告
        $table_settings = $wpdb->prefix . 'xb_yuzhifoot_settings';
        $announcement = $wpdb->get_var($wpdb->prepare("SELECT setting_value FROM $table_settings WHERE setting_key = %s", 'announcement'));
        
        // 计算分页
        $total_pages = ceil($total_items / $per_page);
        
        ob_start();
        ?>
        <div class="xb-yuzhifoot-container">
            <!-- 搜索和筛选区域 -->
            <div class="xb-yuzhifoot-search-section">
                <div class="xb-yuzhifoot-search-title">预制菜查询系统</div>
                
                <form method="get" class="xb-yuzhifoot-search-form" id="xb-yuzhifoot-search-form">
                    <div class="xb-yuzhifoot-search-row">
                        <input type="text" name="xb_search" value="<?php echo esc_attr($search_keyword); ?>" 
                               placeholder="输入菜品名称搜索..." class="xb-yuzhifoot-search-input">
                        <button type="submit" class="xb-yuzhifoot-search-btn">搜索</button>
                        <button type="button" class="xb-yuzhifoot-reset-btn" onclick="xbYuzhifootReset()">重置</button>
                    </div>
                    
                    <div class="xb-yuzhifoot-filter-section">
                        <div class="xb-yuzhifoot-filter-row">
                            <label>品牌：</label>
                            <select name="xb_brand" class="xb-yuzhifoot-select">
                                <option value="">全部品牌</option>
                                <?php foreach ($brands as $brand): ?>
                                    <option value="<?php echo $brand->id; ?>" <?php selected(isset($_GET['xb_brand']) ? $_GET['xb_brand'] : '', $brand->id); ?>>
                                        <?php echo esc_html($brand->brand_name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <?php 
                        $filter_labels = array(
                            'scene' => '场景分类',
                            'demand' => '需求分类', 
                            'ingredient' => '食材类型',
                            'price' => '价格区间',
                            'taste' => '口味',
                            'shelf_life' => '保质期'
                        );
                        
                        foreach ($filter_labels as $type => $label): 
                            if (isset($categories_by_type[$type])):
                        ?>
                            <div class="xb-yuzhifoot-filter-row">
                                <label><?php echo $label; ?>：</label>
                                <select name="xb_<?php echo $type; ?>" class="xb-yuzhifoot-select">
                                    <option value="">全部<?php echo $label; ?></option>
                                    <?php foreach ($categories_by_type[$type] as $category): ?>
                                        <option value="<?php echo $category->id; ?>" <?php selected(isset($_GET['xb_' . $type]) ? $_GET['xb_' . $type] : '', $category->id); ?>>
                                            <?php echo esc_html($category->category_name); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php 
                            endif;
                        endforeach; 
                        ?>
                        

                    </div>
                </form>
            </div>
            
            <!-- 品牌信息展示区域 -->
            <?php if (isset($_GET['xb_brand']) && !empty($_GET['xb_brand'])): 
                $selected_brand_id = intval($_GET['xb_brand']);
                $selected_brand = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_brands WHERE id = %d", $selected_brand_id));
                if ($selected_brand):
            ?>
                <div class="xb-yuzhifoot-brand-info" id="xb-yuzhifoot-brand-info">
                    <div class="xb-yuzhifoot-brand-header">
                        <?php if ($selected_brand->brand_logo): ?>
                            <img src="<?php echo esc_url($selected_brand->brand_logo); ?>" alt="<?php echo esc_attr($selected_brand->brand_name); ?>" class="xb-yuzhifoot-brand-logo">
                        <?php endif; ?>
                        <div class="xb-yuzhifoot-brand-title">
                            <div class="xb-yuzhifoot-brand-name"><?php echo esc_html($selected_brand->brand_name); ?></div>
                            <?php if ($selected_brand->company_name): ?>
                                <div class="xb-yuzhifoot-brand-company"><?php echo esc_html($selected_brand->company_name); ?></div>
                            <?php endif; ?>
                        </div>
                        <button class="xb-yuzhifoot-brand-close" onclick="xbYuzhifootCloseBrandInfo()">×</button>
                    </div>
                    <div class="xb-yuzhifoot-brand-details">
                        <?php if ($selected_brand->establish_time): ?>
                            <div class="xb-yuzhifoot-brand-detail"><strong>成立时间：</strong><?php echo esc_html($selected_brand->establish_time); ?></div>
                        <?php endif; ?>
                        <?php if ($selected_brand->headquarters): ?>
                            <div class="xb-yuzhifoot-brand-detail"><strong>总部：</strong><?php echo esc_html($selected_brand->headquarters); ?></div>
                        <?php endif; ?>
                        <?php if ($selected_brand->brand_intro): ?>
                            <div class="xb-yuzhifoot-brand-intro"><strong>品牌简介：</strong><?php echo wp_kses_post($selected_brand->brand_intro); ?></div>
                        <?php endif; ?>
                        <?php if ($selected_brand->official_website || $selected_brand->tmall_link || $selected_brand->jd_link || $selected_brand->pdd_link || $selected_brand->link_1688): ?>
                            <div class="xb-yuzhifoot-brand-links">
                                <strong>官方链接：</strong>
                                <?php if ($selected_brand->official_website): ?>
                                    <a href="<?php echo esc_url($selected_brand->official_website); ?>" target="_blank" class="xb-yuzhifoot-brand-link">官网</a>
                                <?php endif; ?>
                                <?php if ($selected_brand->tmall_link): ?>
                                    <a href="<?php echo esc_url($selected_brand->tmall_link); ?>" target="_blank" class="xb-yuzhifoot-brand-link">天猫</a>
                                <?php endif; ?>
                                <?php if ($selected_brand->jd_link): ?>
                                    <a href="<?php echo esc_url($selected_brand->jd_link); ?>" target="_blank" class="xb-yuzhifoot-brand-link">京东</a>
                                <?php endif; ?>
                                <?php if ($selected_brand->pdd_link): ?>
                                    <a href="<?php echo esc_url($selected_brand->pdd_link); ?>" target="_blank" class="xb-yuzhifoot-brand-link">拼多多</a>
                                <?php endif; ?>
                                <?php if ($selected_brand->link_1688): ?>
                                    <a href="<?php echo esc_url($selected_brand->link_1688); ?>" target="_blank" class="xb-yuzhifoot-brand-link">1688</a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; endif; ?>
            
            <!-- 结果统计 -->
            <div class="xb-yuzhifoot-result-info">
                共找到 <span class="xb-yuzhifoot-count"><?php echo $total_items; ?></span> 个预制菜品
            </div>
            
            <!-- 食材列表 -->
            <div class="xb-yuzhifoot-foods-grid">
                <?php if ($foods): ?>
                    <?php foreach ($foods as $food): ?>
                        <div class="xb-yuzhifoot-food-card">
                            <?php if ($food->food_image): ?>
                                <div class="xb-yuzhifoot-food-image">
                                    <img src="<?php echo esc_url($food->food_image); ?>" alt="<?php echo esc_attr($food->food_name); ?>">
                                </div>
                            <?php endif; ?>
                            
                            <div class="xb-yuzhifoot-food-content">
                                <div class="xb-yuzhifoot-food-title"><?php echo esc_html($food->food_name); ?></div>
                                
                                <?php if ($food->brand_name): ?>
                                    <div class="xb-yuzhifoot-food-brand" data-brand-id="<?php echo $food->brand_id; ?>" onclick="xbYuzhifootShowBrandInfo(<?php echo $food->brand_id; ?>)">品牌：<?php echo esc_html($food->brand_name); ?></div>
                                <?php endif; ?>
                                
                                <div class="xb-yuzhifoot-food-details">
                                    <?php if ($food->net_weight): ?>
                                        <div class="xb-yuzhifoot-food-detail">净含量：<?php echo esc_html($food->net_weight); ?></div>
                                    <?php endif; ?>
                                    
                                    <?php if ($food->price): ?>
                                        <div class="xb-yuzhifoot-food-price">价格：<?php echo esc_html($food->price); ?></div>
                                    <?php endif; ?>
                                    
                                    <?php if ($food->storage_condition): ?>
                                        <div class="xb-yuzhifoot-food-detail">储存条件：<?php echo esc_html($food->storage_condition); ?></div>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- 详细信息区域，默认隐藏 -->
                                <div class="xb-yuzhifoot-food-details-section" style="display: none;">
                                    <?php if ($food->ingredients): ?>
                                        <div class="xb-yuzhifoot-food-ingredients">
                                            <strong>配料表：</strong><?php echo esc_html($food->ingredients); ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($food->nutrition_info): ?>
                                        <div class="xb-yuzhifoot-food-nutrition">
                                            <strong>营养成分：</strong><?php echo esc_html($food->nutrition_info); ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($food->advanced_tips): ?>
                                        <div class="xb-yuzhifoot-food-tips">
                                            <strong>进阶攻略：</strong><?php echo esc_html($food->advanced_tips); ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($food->ingredient_analysis): ?>
                                        <div class="xb-yuzhifoot-food-analysis">
                                            <strong>配料解读：</strong><?php echo esc_html($food->ingredient_analysis); ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($food->allergen_warning): ?>
                                        <div class="xb-yuzhifoot-food-allergen">
                                            <strong>过敏原提示：</strong><?php echo esc_html($food->allergen_warning); ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($food->nutrition_analysis): ?>
                                        <div class="xb-yuzhifoot-food-health">
                                            <strong>营养分析：</strong><?php echo esc_html($food->nutrition_analysis); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- 操作按钮区域 -->
                                <div class="xb-yuzhifoot-food-actions">
                                    <button class="xb-yuzhifoot-detail-btn" onclick="xbYuzhifootToggleDetails(this)">查看详细</button>
                                    <?php if ($food->purchase_link): ?>
                                        <a href="<?php echo esc_url($food->purchase_link); ?>" target="_blank" class="xb-yuzhifoot-purchase-btn">立即购买</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="xb-yuzhifoot-no-results">
                        <div class="xb-yuzhifoot-no-results-text">暂无符合条件的预制菜品</div>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- 分页 -->
            <?php if ($total_pages > 1): ?>
                <div class="xb-yuzhifoot-pagination">
                    <?php
                    $base_url = remove_query_arg('xb_page');
                    
                    if ($current_page > 1): ?>
                        <a href="<?php echo add_query_arg('xb_page', $current_page - 1, $base_url); ?>" class="xb-yuzhifoot-page-btn">上一页</a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <?php if ($i == $current_page): ?>
                            <span class="xb-yuzhifoot-page-btn xb-yuzhifoot-page-current"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="<?php echo add_query_arg('xb_page', $i, $base_url); ?>" class="xb-yuzhifoot-page-btn"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($current_page < $total_pages): ?>
                        <a href="<?php echo add_query_arg('xb_page', $current_page + 1, $base_url); ?>" class="xb-yuzhifoot-page-btn">下一页</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <!-- 公告区域 -->
            <?php if ($announcement): ?>
                <div class="xb-yuzhifoot-announcement">
                    <?php echo wp_kses_post($announcement); ?>
                </div>
            <?php endif; ?>
        </div>
        
        <script>
        function xbYuzhifootReset() {
            window.location.href = window.location.pathname;
        }
        
        function xbYuzhifootToggleDetails(btn) {
            var $btn = jQuery(btn);
            var $card = $btn.closest('.xb-yuzhifoot-food-card');
            var $details = $card.find('.xb-yuzhifoot-food-details-section');
            
            if ($details.is(':visible')) {
                $details.slideUp(300);
                $btn.text('查看详细');
            } else {
                $details.slideDown(300);
                $btn.text('收起详细');
            }
        }
        
        function xbYuzhifootShowBrandInfo(brandId) {
            // 滚动到品牌信息区域或显示品牌信息
            var currentUrl = new URL(window.location.href);
            currentUrl.searchParams.set('xb_brand', brandId);
            window.location.href = currentUrl.toString();
        }
        
        function xbYuzhifootCloseBrandInfo() {
            var currentUrl = new URL(window.location.href);
            currentUrl.searchParams.delete('xb_brand');
            window.location.href = currentUrl.toString();
        }
        </script>
        <?php
        
        return ob_get_clean();
    }
    
    /**
     * AJAX搜索处理
     */
    public function xb_yuzhifoot_ajax_search() {
        // 验证nonce
        if (!wp_verify_nonce($_POST['nonce'], 'xb_yuzhifoot_nonce')) {
            wp_die('安全验证失败');
        }
        
        // 这里可以添加AJAX搜索逻辑
        wp_die();
    }
    
    /**
     * AJAX获取品牌信息
     */
    public function xb_yuzhifoot_ajax_get_brand_info() {
        // 验证nonce
        if (!wp_verify_nonce($_POST['nonce'], 'xb_yuzhifoot_nonce')) {
            wp_die('安全验证失败');
        }
        
        $brand_id = intval($_POST['brand_id']);
        if (!$brand_id) {
            wp_send_json_error('品牌ID无效');
        }
        
        global $wpdb;
        $table_brands = $wpdb->prefix . 'xb_yuzhifoot_brands';
        $brand = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_brands WHERE id = %d", $brand_id));
        
        if (!$brand) {
            wp_send_json_error('品牌不存在');
        }
        
        wp_send_json_success($brand);
    }
}

// 初始化插件
new XB_YuzhiFood_Plugin();