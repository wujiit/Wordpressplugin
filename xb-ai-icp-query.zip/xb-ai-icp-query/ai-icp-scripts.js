jQuery(document).ready(function ($) {
    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('AI ICP Query: jQuery 未加载！');
        $('#ai_icp_result').html('<div class="ai_icp_message">脚本加载失败，请刷新页面！</div>');
        return;
    }

    // 确保 ai_icp_ajax 配置
    if (typeof ai_icp_ajax === 'undefined') {
        console.error('AI ICP Query: ai_icp_ajax 未定义！');
        $('#ai_icp_result').html('<div class="ai_icp_message">脚本配置失败，请检查插件设置！</div>');
        return;
    }

    // 生成随机验证码
    function generateCaptcha() {
        const operators = ['+', '-'];
        const num1 = Math.floor(Math.random() * 10) + 1;
        const num2 = Math.floor(Math.random() * 10) + 1;
        const operator = operators[Math.floor(Math.random() * operators.length)];
        let question, value;

        if (operator === '+') {
            question = `${num1} + ${num2} = `;
            value = num1 + num2;
        } else {
            // 确保减法结果非负且在10以内
            const maxNum = Math.max(num1, num2);
            const minNum = Math.min(num1, num2);
            question = `${maxNum} - ${minNum} = `;
            value = maxNum - minNum;
        }

        $('#ai_icp_captcha_question').text(question);
        $('#ai_icp_captcha_value').val(value);
    }

    // 检查是否需要显示验证码
    if ($('#ai_icp_captcha_question').length) {
        generateCaptcha();
    }

    // 查询表单提交
    $('#ai_icp_query_form').on('submit', function (e) {
        e.preventDefault();

        var $form = $(this);
        var domain = $('#ai_icp_domain').val().trim();
        var nonce = $('#ai_icp_nonce').val();
        var captchaAnswer = $('#ai_icp_captcha_answer').val();
        var captchaValue = $('#ai_icp_captcha_value').val();

        if (!domain) {
            $('#ai_icp_result').html('<div class="ai_icp_message">请输入域名！</div>');
            return;
        }

        if (!nonce) {
            $('#ai_icp_result').html('<div class="ai_icp_message">安全验证参数丢失，请刷新页面！</div>');
            return;
        }

        $.ajax({
            url: ai_icp_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'ai_icp_query',
                domain: domain,
                nonce: nonce,
                captcha_answer: captchaAnswer || '',
                captcha_value: captchaValue || ''
            },
            beforeSend: function () {
                $('.ai_icp_submit_button').prop('disabled', true).text('查询中...');
            },
            success: function (response) {
                if (response.success) {
                    $('#ai_icp_result').html(response.data.result);
                    if ($('.ai_icp_usage_info').length) {
                        $('.ai_icp_usage_info').text('今日剩余查询次数：' + response.data.remaining + '/' + response.data.limit);
                    }

                    if (response.data.remaining <= 0 && !response.data.captcha) {
                        $form.hide();
                        $('#ai_icp_result').append('<div class="ai_icp_message">今日查询次数已用尽，请明天再试！</div>');
                    } else if (response.data.captcha) {
                        // 显示验证码
                        if (!$('#ai_icp_captcha_question').length) {
                            $form.find('#ai_icp_domain').after(
                                '<div class="ai_icp_captcha_section">' +
                                '<span id="ai_icp_captcha_question"></span>' +
                                '<input type="number" name="ai_icp_captcha_answer" id="ai_icp_captcha_answer" placeholder="请输入验证码答案" required>' +
                                '<input type="hidden" name="ai_icp_captcha_value" id="ai_icp_captcha_value">' +
                                '</div>'
                            );
                            generateCaptcha();
                        } else {
                            generateCaptcha();
                        }
                    }
                } else {
                    $('#ai_icp_result').html('<div class="ai_icp_message">' + response.data.message + '</div>');
                    if ($('#ai_icp_captcha_question').length) {
                        generateCaptcha();
                        $('#ai_icp_captcha_answer').val('');
                    }
                }
            },
            error: function (xhr, status, error) {
                console.error('AI ICP Query: AJAX 错误：' + error);
                $('#ai_icp_result').html('<div class="ai_icp_message">请求失败：' + error + '。请检查网络或刷新页面。</div>');
            },
            complete: function () {
                $('.ai_icp_submit_button').prop('disabled', false).text('查询');
            }
        });
    });
});