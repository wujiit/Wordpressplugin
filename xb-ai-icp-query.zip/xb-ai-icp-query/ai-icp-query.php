<?php
/*
Plugin Name: 小半ICP备案查询
Description: 一个用于查询网站备案信息的WordPress插件，支持游客查询、查询次数限制及隐藏统计。
Version: 1.0.3
Author: Summr
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'ai_icp_activate');
function ai_icp_activate() {
    ai_icp_create_database();
    ai_icp_create_front_page();
}

// 创建数据库表
function ai_icp_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 用户/游客查询次数表
    $usage_table = $wpdb->prefix . 'ai_icp_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL DEFAULT 0,
        query_date date NOT NULL,
        query_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_date (user_id, query_date)
    ) $charset_collate;";

    // 查询记录表
    $queries_table = $wpdb->prefix . 'ai_icp_queries';
    $queries_sql = "CREATE TABLE $queries_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL DEFAULT 0,
        domain varchar(255) NOT NULL,
        query_status varchar(255) NOT NULL,
        query_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $result_usage = dbDelta($usage_sql);
    $result_queries = dbDelta($queries_sql);

    error_log('AI ICP Query: Database tables created or updated. Usage table: ' . print_r($result_usage, true) . ', Queries table: ' . print_r($result_queries, true));
}

// 检查并创建前台页面
function ai_icp_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[ai_icp_query_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => '备案信息查询',
            'post_content' => '[ai_icp_query_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'ai_icp_enqueue_scripts');
function ai_icp_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'ai_icp_query_form')) {
        wp_enqueue_style('ai_icp_styles', plugins_url('ai-icp-styles.css', __FILE__), array(), '1.0.3');
        wp_enqueue_script('ai_icp_scripts', plugins_url('ai-icp-scripts.js', __FILE__), array('jquery'), '1.0.3', true);
        
        wp_localize_script('ai_icp_scripts', 'ai_icp_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('ai_icp_query_nonce'),
            'login_url' => wp_login_url(get_permalink())
        ));
    }
}

// 创建短代码
add_shortcode('ai_icp_query_form', 'ai_icp_query_form_shortcode');
function ai_icp_query_form_shortcode() {
    $ad_content = get_option('ai_icp_ad_content', '');
    $default_limit = absint(get_option('ai_icp_default_limit', 5));
    $guest_limit = absint(get_option('ai_icp_guest_limit', 10));
    $hide_stats = get_option('ai_icp_hide_stats', '0') === '1';
    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $today = current_time('Y-m-d');
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'ai_icp_usage';
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT query_count, custom_limit FROM $table_name WHERE user_id = %d AND query_date = %s",
            $user_id,
            $today
        )
    );

    $query_count = $row ? absint($row->query_count) : 0;
    $user_limit = $user_id ? (($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit) : $guest_limit;
    $remaining = max(0, $user_limit - $query_count);
    $show_captcha = $user_id === 0 && $query_count >= $guest_limit;

    error_log("AI ICP Query: User ID $user_id, Limit: $user_limit, Count: $query_count, Remaining: $remaining");
    
    ob_start();
    ?>
    <div class="ai_icp_container">
        <div class="ai_icp_title">域名ICP备案信息查询助手</div>
        
        <div class="ai_icp_query_section">
            <?php if ($query_count >= $user_limit && !$show_captcha): ?>
                <div class="ai_icp_message">今日查询次数已用完，请明天再试！</div>
            <?php else: ?>
                <form id="ai_icp_query_form" method="post">
                    <input type="text" name="ai_icp_domain" id="ai_icp_domain" placeholder="请输入域名（如：baidu.com）" required>
                    <?php if ($show_captcha): ?>
                        <div class="ai_icp_captcha_section">
                            <span id="ai_icp_captcha_question"></span>
                            <input type="number" name="ai_icp_captcha_answer" id="ai_icp_captcha_answer" placeholder="请输入验证码答案" required>
                            <input type="hidden" name="ai_icp_captcha_value" id="ai_icp_captcha_value">
                        </div>
                    <?php endif; ?>
                    <button type="submit" class="ai_icp_submit_button">查询</button>
                    <input type="hidden" name="ai_icp_nonce" id="ai_icp_nonce" value="<?php echo wp_create_nonce('ai_icp_query_nonce'); ?>">
                </form>
                <div class="ai_icp_result_section">
                    <div id="ai_icp_result"></div>
                    <?php if (!$hide_stats): ?>
                        <div class="ai_icp_usage_info">今日剩余查询次数：<?php echo esc_html($remaining); ?>/<?php echo esc_html($user_limit); ?></div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="ai_icp_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
    </div>
    <?php
    return ob_get_clean();
}

// 处理 AJAX 查询请求
add_action('wp_ajax_ai_icp_query', 'ai_icp_handle_query');
add_action('wp_ajax_nopriv_ai_icp_query', 'ai_icp_handle_query');
function ai_icp_handle_query() {
    // 验证 nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ai_icp_query_nonce')) {
        $nonce_received = isset($_POST['nonce']) ? $_POST['nonce'] : 'none';
        error_log('AI ICP Query: Nonce verification failed. Received nonce: ' . $nonce_received);
        wp_send_json_error(array('message' => '安全验证失败，请稍后重试！', 'debug' => 'Nonce verification failed.'));
        return;
    }

    $domain = sanitize_text_field($_POST['domain']);
    if (empty($domain)) {
        wp_send_json_error(array('message' => '请输入有效域名！'));
        return;
    }

    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $today = current_time('Y-m-d');
    global $wpdb;
    $usage_table = $wpdb->prefix . 'ai_icp_usage';
    $queries_table = $wpdb->prefix . 'ai_icp_queries';
    
    // 检查查询限制
    $default_limit = absint(get_option('ai_icp_default_limit', 5));
    $guest_limit = absint(get_option('ai_icp_guest_limit', 10));
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT query_count, custom_limit FROM $usage_table WHERE user_id = %d AND query_date = %s",
            $user_id,
            $today
        )
    );

    $query_count = $row ? absint($row->query_count) : 0;
    $user_limit = $user_id ? (($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit) : $guest_limit;

    // 游客验证码验证
    if ($user_id === 0 && $query_count >= $guest_limit) {
        if (!isset($_POST['captcha_answer']) || !isset($_POST['captcha_value']) || absint($_POST['captcha_answer']) !== absint($_POST['captcha_value'])) {
            wp_send_json_error(array('message' => '验证码错误，请重新输入！'));
            return;
        }
    }

    if ($query_count >= $user_limit && $user_id !== 0) {
        wp_send_json_error(array('message' => '今日查询次数已用完，请明天再试！'));
        return;
    }

    // 调用 API
    $api_url = get_option('ai_icp_api_url', 'https://apis.tianapi.com/icp/index');
    $api_key = get_option('ai_icp_api_key');
    
    $args = array(
        'body' => array(
            'key' => $api_key,
            'domain' => $domain
        ),
        'timeout' => 10,
        'sslverify' => false
    );

    $response = wp_remote_post($api_url, $args);
    $query_status = 'failed';

    // 准备插入记录
    $insert_data = array(
        'user_id' => $user_id,
        'domain' => $domain,
        'query_status' => $query_status,
        'query_time' => current_time('mysql')
    );

    if (is_wp_error($response)) {
        $query_status = $response->get_error_message();
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s'));
        error_log('AI ICP Query: Inserted error record. ID: ' . $wpdb->insert_id . ', Error: ' . $query_status);
        wp_send_json_error(array('message' => '请稍后重试！'));
        return;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['code']) && $data['code'] == 200) {
        $query_status = 'success';
        $insert_data['query_status'] = $query_status;
        
        // 更新查询次数
        if ($row) {
            $new_count = $query_count + 1;
            $wpdb->update(
                $usage_table,
                array('query_count' => $new_count),
                array('user_id' => $user_id, 'query_date' => $today),
                array('%d'),
                array('%d', '%s')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'query_date' => $today,
                    'query_count' => 1,
                    'custom_limit' => null
                ),
                array('%d', '%s', '%d', '%d')
            );
        }

        // 插入查询记录
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s'));
        error_log('AI ICP Query: Inserted success record. ID: ' . $wpdb->insert_id . ', Domain: ' . $domain);

        // 格式化结果
        $result = $data['result'];
        $output = '<table class="ai_icp_result_table">';
        $output .= '<tr><th>备案状态</th><td>' . esc_html($result['icp_state']) . '</td></tr>';
        $output .= '<tr><th>主体名称</th><td>' . esc_html($result['main_name']) . '</td></tr>';
        $output .= '<tr><th>主体类型</th><td>' . esc_html($result['icp_type']) . '</td></tr>';
        $output .= '<tr><th>备案编号</th><td>' . esc_html($result['icp_number']) . '</td></tr>';
        $output .= '<tr><th>备案名称</th><td>' . esc_html($result['icp_name']) . '</td></tr>';
        $output .= '<tr><th>域名</th><td>' . esc_html($result['domain']) . '</td></tr>';
        $output .= '<tr><th>更新时间</th><td>' . esc_html($result['update_time']) . '</td></tr>';
        $output .= '</table>';

        wp_send_json_success(array(
            'result' => $output,
            'remaining' => $user_limit - ($query_count + 1),
            'limit' => $user_limit,
            'captcha' => $user_id === 0 && ($query_count + 1) >= $guest_limit
        ));
    } else {
        $query_status = isset($data['msg']) ? $data['msg'] : '未知错误';
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s'));
        error_log('AI ICP Query: Inserted failed record. ID: ' . $wpdb->insert_id . ', Status: ' . $query_status);
        wp_send_json_error(array('message' => '请稍后重试！'));
    }
}

// 添加管理菜单
add_action('admin_menu', 'ai_icp_admin_menu');
function ai_icp_admin_menu() {
    add_menu_page(
        'ICP备案设置',
        'ICP备案设置',
        'manage_options',
        'ai_icp_settings',
        'ai_icp_settings_page',
        'dashicons-admin-network',
        80
    );
    add_submenu_page(
        'ai_icp_settings',
        '查询记录',
        '查询记录',
        'manage_options',
        'ai_icp_all_records',
        'ai_icp_all_records_page'
    );
}

// 插件设置页面
function ai_icp_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['ai_icp_save_settings'])) {
        check_admin_referer('ai_icp_settings_nonce');
        
        update_option('ai_icp_api_url', sanitize_text_field($_POST['ai_icp_api_url']));
        update_option('ai_icp_api_key', sanitize_text_field($_POST['ai_icp_api_key']));
        $new_limit = absint($_POST['ai_icp_default_limit']);
        if ($new_limit > 0) {
            update_option('ai_icp_default_limit', $new_limit);
        }
        $new_guest_limit = absint($_POST['ai_icp_guest_limit']);
        if ($new_guest_limit >= 0) {
            update_option('ai_icp_guest_limit', $new_guest_limit);
        }
        update_option('ai_icp_ad_content', wp_kses_post($_POST['ai_icp_ad_content']));
        update_option('ai_icp_hide_stats', isset($_POST['ai_icp_hide_stats']) ? '1' : '0');
        
        echo '<div id="ai_icp_settings_notice" class="updated"><p>设置已保存！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("ai_icp_settings_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    ?>
    <div class="wrap">
        <div class="ai_icp_admin_title">ICP备案查询设置</div>
        <form method="post">
            <?php wp_nonce_field('ai_icp_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="ai_icp_api_url">API 接口地址</label></th>
                    <td><input type="text" name="ai_icp_api_url" id="ai_icp_api_url" value="<?php echo esc_attr(get_option('ai_icp_api_url', 'https://apis.tianapi.com/icp/index')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="ai_icp_api_key">API 密钥</label></th>
                    <td><input type="text" name="ai_icp_api_key" id="ai_icp_api_key" value="<?php echo esc_attr(get_option('ai_icp_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="ai_icp_default_limit">默认每日查询次数（登录用户）</label></th>
                    <td><input type="number" name="ai_icp_default_limit" id="ai_icp_default_limit" value="<?php echo esc_attr(get_option('ai_icp_default_limit', 5)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="ai_icp_guest_limit">默认每日查询次数（游客）</label></th>
                    <td><input type="number" name="ai_icp_guest_limit" id="ai_icp_guest_limit" value="<?php echo esc_attr(get_option('ai_icp_guest_limit', 10)); ?>" min="0"></td>
                </tr>
                <tr>
                    <th><label for="ai_icp_ad_content">广告内容</label></th>
                    <td><textarea name="ai_icp_ad_content" id="ai_icp_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('ai_icp_ad_content')); ?></textarea></td>
                </tr>
                <tr>
                    <th><label for="ai_icp_hide_stats">隐藏前台统计</label></th>
                    <td><input type="checkbox" name="ai_icp_hide_stats" id="ai_icp_hide_stats" value="1" <?php checked(get_option('ai_icp_hide_stats', '0'), '1'); ?>> 隐藏今日剩余查询次数</td>
                </tr>
            </table>
            <p><input type="submit" name="ai_icp_save_settings" class="button-primary" value="保存设置"></p>
        </form>
    </div>
    <?php
}

// 所有查询记录页面
function ai_icp_all_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $usage_table = $wpdb->prefix . 'ai_icp_usage';
    $queries_table = $wpdb->prefix . 'ai_icp_queries';
    $user_id = isset($_POST['ai_icp_user_id']) ? (int)$_POST['ai_icp_user_id'] : null;
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    // 删除单条记录
    if (isset($_POST['ai_icp_delete_record']) && isset($_POST['record_id'])) {
        check_admin_referer('ai_icp_delete_record_nonce');
        $wpdb->delete($queries_table, array('id' => absint($_POST['record_id'])), array('%d'));
        echo '<div id="ai_icp_delete_notice" class="updated"><p>记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("ai_icp_delete_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 删除用户/游客全部记录
    if (isset($_POST['ai_icp_delete_all_records']) && $user_id !== null) {
        check_admin_referer('ai_icp_delete_all_records_nonce');
        $wpdb->delete($queries_table, array('user_id' => $user_id), array('%d'));
        $wpdb->delete($usage_table, array('user_id' => $user_id), array('%d'));
        echo '<div id="ai_icp_delete_all_notice" class="updated"><p>所有记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("ai_icp_delete_all_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 保存用户/游客自定义限制
    if (isset($_POST['ai_icp_save_user_limit']) && $user_id !== null) {
        check_admin_referer('ai_icp_user_limit_nonce');
        $custom_limit = isset($_POST['ai_icp_custom_limit']) ? absint($_POST['ai_icp_custom_limit']) : null;
        
        // 检查是否已有记录
        $existing = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id FROM $usage_table WHERE user_id = %d AND query_date = %s",
                $user_id,
                current_time('Y-m-d')
            )
        );

        if ($existing) {
            $wpdb->update(
                $usage_table,
                array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
                array('user_id' => $user_id, 'query_date' => current_time('Y-m-d')),
                array('%d'),
                array('%d', '%s')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'query_date' => current_time('Y-m-d'),
                    'query_count' => 0,
                    'custom_limit' => $custom_limit === 0 ? null : $custom_limit
                ),
                array('%d', '%s', '%d', '%d')
            );
        }
        
        echo '<div id="ai_icp_limit_notice" class="updated"><p>查询限制已更新！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("ai_icp_limit_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 统计数据
    $stats = array();
    $where_clause = $user_id !== null ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : '';
    $stats['total_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table $where_clause");
    $stats['success_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table WHERE query_status = 'success' " . ($user_id !== null ? $wpdb->prepare('AND user_id = %d', $user_id) : ''));
    $stats['failed_queries'] = $stats['total_queries'] - $stats['success_queries'];
    $stats['today_queries'] = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $queries_table WHERE DATE(query_time) = %s " . ($user_id !== null ? 'AND user_id = %d' : ''), current_time('Y-m-d'), $user_id)
    );

    // 获取记录
    $offset = ($paged - 1) * $per_page;
    $query = $user_id !== null
        ? $wpdb->prepare("SELECT id, user_id, domain, query_status, query_time FROM $queries_table WHERE user_id = %d ORDER BY query_time DESC LIMIT %d, %d", $user_id, $offset, $per_page)
        : $wpdb->prepare("SELECT id, user_id, domain, query_status, query_time FROM $queries_table ORDER BY query_time DESC LIMIT %d, %d", $offset, $per_page);
    $records = $wpdb->get_results($query);
    $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table" . ($user_id !== null ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : ''));
    $total_pages = ceil($total_records / $per_page);

    error_log('AI ICP Query: Fetched records. User ID: ' . ($user_id !== null ? $user_id : 'All') . ', Total records: ' . $total_records);

    $user_info = $user_id && $user_id !== 0 ? get_userdata($user_id) : null;
    ?>
    <div class="wrap">
        <div class="ai_icp_admin_title">所有查询记录</div>
        <form method="post">
            <p>
                <label for="ai_icp_user_id">输入用户 ID（留空显示所有记录，0 为游客）：</label>
                <input type="number" name="ai_icp_user_id" id="ai_icp_user_id" value="<?php echo esc_attr($user_id !== null ? $user_id : ''); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <?php if ($user_id !== null && ($user_id === 0 || $user_info)): ?>
            <h2><?php echo $user_id === 0 ? '游客' : '用户：' . esc_html($user_info->user_login); ?> (ID: <?php echo $user_id; ?>)</h2>
            <form method="post">
                <?php wp_nonce_field('ai_icp_user_limit_nonce'); ?>
                <p>
                    <label for="ai_icp_custom_limit">设置自定义每日查询次数（0 表示使用默认值）：</label>
                    <input type="number" name="ai_icp_custom_limit" id="ai_icp_custom_limit" min="0">
                    <input type="hidden" name="ai_icp_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="ai_icp_save_user_limit" class="button-primary" value="保存">
                </p>
            </form>
            <form method="post">
                <?php wp_nonce_field('ai_icp_delete_all_records_nonce'); ?>
                <input type="hidden" name="ai_icp_user_id" value="<?php echo esc_attr($user_id); ?>">
                <p><input type="submit" name="ai_icp_delete_all_records" class="button-secondary" value="删除所有记录" onclick="return confirm('确定删除所有记录吗？');"></p>
            </form>
        <?php endif; ?>

        <div class="ai_icp_stats">
            <p>总查询次数：<?php echo esc_html($stats['total_queries']); ?></p>
            <p>成功查询次数：<?php echo esc_html($stats['success_queries']); ?></p>
            <p>失败查询次数：<?php echo esc_html($stats['failed_queries']); ?></p>
            <p>今日查询次数：<?php echo esc_html($stats['today_queries']); ?></p>
        </div>

        <table class="widefat">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>查询时间</th>
                    <th>域名</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="5">暂无查询记录。</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td><?php echo $record->user_id === 0 ? '游客' : esc_html($record->user_id); ?></td>
                            <td><?php echo esc_html($record->query_time); ?></td>
                            <td><?php echo esc_html($record->domain); ?></td>
                            <td><?php echo esc_html($record->query_status); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('ai_icp_delete_record_nonce'); ?>
                                    <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>">
                                    <input type="submit" name="ai_icp_delete_record" class="button-link" value="删除" onclick="return confirm('确定删除此记录？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}
?>