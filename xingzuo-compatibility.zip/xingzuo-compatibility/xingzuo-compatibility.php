<?php
/*
Plugin Name: 星座配对查询
Description: 一个用于查询星座配对的WordPress插件，支持单人模式和双人模式，基于天行数据API。
Version: 1.0.2
Author: summer
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 设置页面编码
header('Content-Type: text/html; charset=utf-8');

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xingzuo_activate');
function xingzuo_activate() {
    xingzuo_create_database();
    xingzuo_create_front_page();
}

// 创建数据库表
function xingzuo_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 用户查询次数表
    $usage_table = $wpdb->prefix . 'xingzuo_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        query_date date NOT NULL,
        query_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_date (user_id, query_date)
    ) $charset_collate;";

    // 查询记录表
    $queries_table = $wpdb->prefix . 'xingzuo_queries';
    $queries_sql = "CREATE TABLE $queries_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        me_zodiac varchar(50) NOT NULL,
        he_zodiac varchar(50) DEFAULT NULL,
        query_status varchar(255) NOT NULL,
        query_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $result_usage = dbDelta($usage_sql);
    $result_queries = dbDelta($queries_sql);

    error_log('Xingzuo Query: Database tables created or updated. Usage table: ' . print_r($result_usage, true) . ', Queries table: ' . print_r($result_queries, true));
}

// 检查并创建前台页面
function xingzuo_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xingzuo_query_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => '星座配对查询',
            'post_content' => '[xingzuo_query_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
        error_log('Xingzuo Query: Front page created.');
    }
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xingzuo_enqueue_scripts');
function xingzuo_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xingzuo_query_form')) {
        wp_enqueue_style('xingzuo_styles', plugins_url('xingzuo-styles.css', __FILE__), array(), '1.0.2');
        wp_enqueue_script('jquery');
        wp_enqueue_script('xingzuo_scripts', plugins_url('xingzuo-scripts.js', __FILE__), array('jquery'), '1.0.2', true);
        
        wp_localize_script('xingzuo_scripts', 'xingzuo_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('xingzuo_query_nonce'),
            'login_url' => wp_login_url(get_permalink())
        ));
        error_log('Xingzuo Query: Enqueued styles and scripts for page ID ' . $post->ID);
    }
}

// 创建短代码
add_shortcode('xingzuo_query_form', 'xingzuo_query_form_shortcode');
function xingzuo_query_form_shortcode() {
    $ad_content = get_option('xingzuo_ad_content', '');
    $default_limit = absint(get_option('xingzuo_default_limit', 5)); // 默认5次
    
    // 星座选项
    $zodiacs = array('白羊', '金牛', '双子', '巨蟹', '狮子', '处女', '天秤', '天蝎', '射手', '摩羯', '水瓶', '双鱼');
    
    ob_start();
    error_log('Xingzuo Query: Rendering shortcode [xingzuo_query_form]');
    ?>
    <div class="xingzuo_container">
        <div class="xingzuo_title">星座配对查询</div>
        
        <?php if (!is_user_logged_in()): ?>
            <div class="xingzuo_message">
                请先登录以使用星座配对查询功能。
                <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xingzuo_login_button">快速登录</a>
            </div>
        <?php else: ?>
            <?php
            $user_id = get_current_user_id();
            $today = current_time('Y-m-d');
            global $wpdb;
            $table_name = $wpdb->prefix . 'xingzuo_usage';
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT query_count, custom_limit FROM $table_name WHERE user_id = %d AND query_date = %s",
                    $user_id,
                    $today
                )
            );

            $query_count = $row ? absint($row->query_count) : 0;
            $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;
            $remaining = max(0, $user_limit - $query_count);
            error_log("Xingzuo Query: User ID $user_id, Limit: $user_limit, Count: $query_count, Remaining: $remaining");
            ?>
            <div class="xingzuo_query_section">
                <?php if ($query_count >= $user_limit): ?>
                    <div class="xingzuo_message">今日查询次数已用完，请明天再试！</div>
                <?php else: ?>
                    <form id="xingzuo_query_form" method="post">
                        <select name="xingzuo_me" id="xingzuo_me" required>
                            <option value="">选择你的星座</option>
                            <?php foreach ($zodiacs as $zodiac): ?>
                                <option value="<?php echo esc_attr($zodiac); ?>"><?php echo esc_html($zodiac); ?>座</option>
                            <?php endforeach; ?>
                        </select>
                        <select name="xingzuo_he" id="xingzuo_he">
                            <option value="">选择对方的星座</option>
                            <?php foreach ($zodiacs as $zodiac): ?>
                                <option value="<?php echo esc_attr($zodiac); ?>"><?php echo esc_html($zodiac); ?>座</option>
                            <?php endforeach; ?>
                        </select>
                        <label class="xingzuo_all_label">
                            <input type="checkbox" name="xingzuo_all" id="xingzuo_all" value="1"> 直接查询全部星座配对
                        </label>
                        <button type="submit" class="xingzuo_submit_button">查询</button>
                        <input type="hidden" name="xingzuo_nonce" id="xingzuo_nonce" value="<?php echo wp_create_nonce('xingzuo_query_nonce'); ?>">
                    </form>
                <?php endif; ?>
                <div class="xingzuo_result_section">
                    <div id="xingzuo_result"></div>
                    <div class="xingzuo_usage_info">今日剩余查询次数：<?php echo esc_html($remaining); ?>/<?php echo esc_html($user_limit); ?></div>
                </div>
            </div>
        <?php endif; ?>
        <div class="xingzuo_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
    </div>
    <?php
    $output = ob_get_clean();
    error_log('Xingzuo Query: Shortcode output generated');
    return $output;
}

// 处理 AJAX 查询请求
add_action('wp_ajax_xingzuo_query', 'xingzuo_handle_query');
function xingzuo_handle_query() {
    // 验证 nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'xingzuo_query_nonce')) {
        $nonce_received = isset($_POST['nonce']) ? $_POST['nonce'] : 'none';
        error_log('Xingzuo Query: Nonce verification failed. Received nonce: ' . $nonce_received);
        wp_send_json_error(array('message' => '安全验证失败，请刷新页面重试！', 'debug' => 'Nonce verification failed.'));
        return;
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => '请先登录！'));
        return;
    }

    $me_zodiac = sanitize_text_field($_POST['me_zodiac']);
    $he_zodiac = sanitize_text_field($_POST['he_zodiac']);
    $all_mode = isset($_POST['all_mode']) && $_POST['all_mode'] === '1' ? 1 : 0;

    if (empty($me_zodiac)) {
        wp_send_json_error(array('message' => '请选择你的星座！'));
        return;
    }

    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xingzuo_usage';
    $queries_table = $wpdb->prefix . 'xingzuo_queries';
    
    // 检查查询限制
    $default_limit = absint(get_option('xingzuo_default_limit', 5)); // 默认5次
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT query_count, custom_limit FROM $usage_table WHERE user_id = %d AND query_date = %s",
            $user_id,
            $today
        )
    );

    $query_count = $row ? absint($row->query_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;

    error_log("Xingzuo Query: User ID $user_id, Limit: $user_limit, Count: $query_count");

    if ($query_count >= $user_limit) {
        wp_send_json_error(array('message' => '今日查询次数已用完，请明天再试！'));
        return;
    }

    // 调用 API
    $api_url = get_option('xingzuo_api_url', 'https://apis.tianapi.com/xingzuo/index');
    $api_key = get_option('xingzuo_api_key');
    
    $args = array(
        'body' => array(
            'key' => $api_key,
            'me' => $me_zodiac,
        ),
        'timeout' => 10,
        'sslverify' => false
    );

    if (!empty($he_zodiac) && !$all_mode) {
        $args['body']['he'] = $he_zodiac;
    }
    if ($all_mode) {
        $args['body']['all'] = 1;
    }

    $response = wp_remote_post($api_url, $args);
    $query_status = 'failed';

    // 准备插入记录
    $insert_data = array(
        'user_id' => $user_id,
        'me_zodiac' => $me_zodiac,
        'he_zodiac' => $he_zodiac ?: ($all_mode ? 'all' : null),
        'query_status' => $query_status,
        'query_time' => current_time('mysql')
    );

    if (is_wp_error($response)) {
        $query_status = $response->get_error_message();
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s'));
        error_log('Xingzuo Query: Inserted error record. ID: ' . $wpdb->insert_id . ', Error: ' . $query_status);
        wp_send_json_error(array('message' => 'API 请求失败：' . esc_html($query_status)));
        return;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['code']) && $data['code'] == 200) {
        $query_status = 'success';
        $insert_data['query_status'] = $query_status;
        
        // 更新查询次数
        if ($row) {
            $new_count = $query_count + 1;
            $wpdb->update(
                $usage_table,
                array('query_count' => $new_count),
                array('user_id' => $user_id, 'query_date' => $today),
                array('%d'),
                array('%d', '%s')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'query_date' => $today,
                    'query_count' => 1,
                    'custom_limit' => null
                ),
                array('%d', '%s', '%d', '%d')
            );
        }

        // 插入查询记录
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s'));
        error_log('Xingzuo Query: Inserted success record. ID: ' . $wpdb->insert_id . ', Me: ' . $me_zodiac . ', He: ' . ($he_zodiac ?: ($all_mode ? 'all' : 'none')));

        // 格式化结果
        $result = $data['result'];
        $output = '';
        if ($all_mode && isset($result['list']) && is_array($result['list'])) {
            $output .= '<div class="xingzuo_result_grid">';
            foreach ($result['list'] as $item) {
                $output .= '<div class="xingzuo_result_item">';
                $output .= '<h3>' . esc_html($item['title']) . '</h3>';
                $output .= '<p><strong>评分：</strong>' . esc_html($item['grade']) . '</p>';
                $output .= '<p>' . wp_kses_post($item['content']) . '</p>';
                $output .= '</div>';
            }
            $output .= '</div>';
        } else {
            $output .= '<div class="xingzuo_result_item">';
            $output .= '<h3>' . esc_html($result['title']) . '</h3>';
            $output .= '<p><strong>评分：</strong>' . esc_html($result['grade']) . '</p>';
            $output .= '<p>' . wp_kses_post($result['content']) . '</p>';
            $output .= '</div>';
        }

        wp_send_json_success(array(
            'result' => $output,
            'remaining' => $user_limit - ($query_count + 1),
            'limit' => $user_limit
        ));
    } else {
        $query_status = isset($data['msg']) ? $data['msg'] : '未知错误';
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s'));
        error_log('Xingzuo Query: Inserted failed record. ID: ' . $wpdb->insert_id . ', Status: ' . $query_status);
        wp_send_json_error(array('message' => '查询失败：' . esc_html($query_status)));
    }
}

// 添加管理菜单
add_action('admin_menu', 'xingzuo_admin_menu');
function xingzuo_admin_menu() {
    add_menu_page(
        '星座配对设置',
        '星座配对设置',
        'manage_options',
        'xingzuo_settings',
        'xingzuo_settings_page',
        'dashicons-star-filled',
        80
    );
    add_submenu_page(
        'xingzuo_settings',
        '查询记录',
        '查询记录',
        'manage_options',
        'xingzuo_all_records',
        'xingzuo_all_records_page'
    );
}

// 插件设置页面
function xingzuo_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['xingzuo_save_settings'])) {
        check_admin_referer('xingzuo_settings_nonce');
        
        update_option('xingzuo_api_url', sanitize_text_field($_POST['xingzuo_api_url']));
        update_option('xingzuo_api_key', sanitize_text_field($_POST['xingzuo_api_key']));
        $new_limit = absint($_POST['xingzuo_default_limit']);
        if ($new_limit > 0) {
            update_option('xingzuo_default_limit', $new_limit);
        }
        update_option('xingzuo_ad_content', wp_kses_post($_POST['xingzuo_ad_content']));
        
        echo '<div id="xingzuo_settings_notice" class="updated"><p>设置已保存！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xingzuo_settings_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    ?>
    <div class="wrap">
        <div class="xingzuo_admin_title">星座配对查询设置</div>
        <form method="post">
            <?php wp_nonce_field('xingzuo_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xingzuo_api_url">API 接口地址</label></th>
                    <td><input type="text" name="xingzuo_api_url" id="xingzuo_api_url" value="<?php echo esc_attr(get_option('xingzuo_api_url', 'https://apis.tianapi.com/xingzuo/index')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xingzuo_api_key">API 密钥</label></th>
                    <td><input type="text" name="xingzuo_api_key" id="xingzuo_api_key" value="<?php echo esc_attr(get_option('xingzuo_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xingzuo_default_limit">默认每日查询次数</label></th>
                    <td><input type="number" name="xingzuo_default_limit" id="xingzuo_default_limit" value="<?php echo esc_attr(get_option('xingzuo_default_limit', 5)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xingzuo_ad_content">广告内容</label></th>
                    <td><textarea name="xingzuo_ad_content" id="xingzuo_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('xingzuo_ad_content')); ?></textarea></td>
                </tr>
            </table>
            <p><input type="submit" name="xingzuo_save_settings" class="button-primary" value="保存设置"></p>
        </form>
    </div>
    <?php
}

// 所有查询记录页面
function xingzuo_all_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xingzuo_usage';
    $queries_table = $wpdb->prefix . 'xingzuo_queries';
    $user_id = isset($_POST['xingzuo_user_id']) ? absint($_POST['xingzuo_user_id']) : 0;
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    // 删除单条记录
    if (isset($_POST['xingzuo_delete_record']) && isset($_POST['record_id'])) {
        check_admin_referer('xingzuo_delete_record_nonce');
        $wpdb->delete($queries_table, array('id' => absint($_POST['record_id'])), array('%d'));
        echo '<div id="xingzuo_delete_notice" class="updated"><p>记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xingzuo_delete_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 删除用户全部记录
    if (isset($_POST['xingzuo_delete_all_records']) && $user_id) {
        check_admin_referer('xingzuo_delete_all_records_nonce');
        $wpdb->delete($queries_table, array('user_id' => $user_id), array('%d'));
        $wpdb->delete($usage_table, array('user_id' => $user_id), array('%d'));
        echo '<div id="xingzuo_delete_all_notice" class="updated"><p>所有记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xingzuo_delete_all_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 保存用户自定义限制
    if (isset($_POST['xingzuo_save_user_limit']) && $user_id) {
        check_admin_referer('xingzuo_user_limit_nonce');
        $custom_limit = isset($_POST['xingzuo_custom_limit']) ? absint($_POST['xingzuo_custom_limit']) : null;
        
        $wpdb->update(
            $usage_table,
            array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
            array('user_id' => $user_id, 'query_date' => current_time('Y-m-d')),
            array('%d'),
            array('%d', '%s')
        );
        
        echo '<div id="xingzuo_limit_notice" class="updated"><p>用户查询限制已更新！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xingzuo_limit_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 统计数据
    $stats = array();
    $where_clause = $user_id ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : '';
    $stats['total_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table $where_clause");
    $stats['success_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table WHERE query_status = 'success' " . ($user_id ? $wpdb->prepare('AND user_id = %d', $user_id) : ''));
    $stats['failed_queries'] = $stats['total_queries'] - $stats['success_queries'];
    $stats['today_queries'] = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $queries_table WHERE DATE(query_time) = %s " . ($user_id ? 'AND user_id = %d' : ''), current_time('Y-m-d'), $user_id)
    );

    // 获取记录
    $offset = ($paged - 1) * $per_page;
    $query = $user_id
        ? $wpdb->prepare("SELECT id, user_id, me_zodiac, he_zodiac, query_status, query_time FROM $queries_table WHERE user_id = %d ORDER BY query_time DESC LIMIT %d, %d", $user_id, $offset, $per_page)
        : $wpdb->prepare("SELECT id, user_id, me_zodiac, he_zodiac, query_status, query_time FROM $queries_table ORDER BY query_time DESC LIMIT %d, %d", $offset, $per_page);
    $records = $wpdb->get_results($query);
    $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table" . ($user_id ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : ''));
    $total_pages = ceil($total_records / $per_page);

    error_log('Xingzuo Query: Fetched records. User ID: ' . ($user_id ?: 'All') . ', Total records: ' . $total_records);

    $user_info = $user_id ? get_userdata($user_id) : null;
    ?>
    <div class="wrap">
        <div class="xingzuo_admin_title">所有查询记录</div>
        <form method="post">
            <p>
                <label for="xingzuo_user_id">输入用户 ID（留空显示所有记录）：</label>
                <input type="number" name="xingzuo_user_id" id="xingzuo_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <?php if ($user_id && $user_info): ?>
            <h2>用户：<?php echo esc_html($user_info->user_login); ?> (ID: <?php echo $user_id; ?>)</h2>
            <form method="post">
                <?php wp_nonce_field('xingzuo_user_limit_nonce'); ?>
                <p>
                    <label for="xingzuo_custom_limit">设置自定义每日查询次数（0 表示使用默认值）：</label>
                    <input type="number" name="xingzuo_custom_limit" id="xingzuo_custom_limit" min="0">
                    <input type="hidden" name="xingzuo_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xingzuo_save_user_limit" class="button-primary" value="保存">
                </p>
            </form>
            <form method="post">
                <?php wp_nonce_field('xingzuo_delete_all_records_nonce'); ?>
                <input type="hidden" name="xingzuo_user_id" value="<?php echo esc_attr($user_id); ?>">
                <p><input type="submit" name="xingzuo_delete_all_records" class="button-secondary" value="删除所有记录" onclick="return confirm('确定删除所有记录吗？');"></p>
            </form>
        <?php endif; ?>

        <div class="xingzuo_stats">
            <p>总查询次数：<?php echo esc_html($stats['total_queries']); ?></p>
            <p>成功查询次数：<?php echo esc_html($stats['success_queries']); ?></p>
            <p>失败查询次数：<?php echo esc_html($stats['failed_queries']); ?></p>
            <p>今日查询次数：<?php echo esc_html($stats['today_queries']); ?></p>
        </div>

        <table class="widefat">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>查询时间</th>
                    <th>我的星座</th>
                    <th>对方星座</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="6">暂无查询记录。</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td><?php echo esc_html($record->user_id); ?></td>
                            <td><?php echo esc_html($record->query_time); ?></td>
                            <td><?php echo esc_html($record->me_zodiac); ?>座</td>
                            <td><?php echo esc_html($record->he_zodiac ?: '无'); ?></td>
                            <td><?php echo esc_html($record->query_status); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xingzuo_delete_record_nonce'); ?>
                                    <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>">
                                    <input type="submit" name="xingzuo_delete_record" class="button-link" value="删除" onclick="return confirm('确定删除此记录？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}
?>