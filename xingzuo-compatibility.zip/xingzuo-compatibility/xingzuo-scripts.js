jQuery(document).ready(function ($) {
    console.log('Xingzuo Query: jQuery loaded, initializing script');

    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('Xingzuo Query: jQuery 未加载！');
        $('#xingzuo_result').html('<div class="xingzuo_message">脚本加载失败，请刷新页面！</div>');
        return;
    }

    // 确保 xingzuo_ajax 配置
    if (typeof xingzuo_ajax === 'undefined') {
        console.error('Xingzuo Query: xingzuo_ajax 未定义！');
        $('#xingzuo_result').html('<div class="xingzuo_message">脚本配置失败，请检查插件设置！</div>');
        return;
    }

    console.log('Xingzuo Query: AJAX config loaded', xingzuo_ajax);

    // 查询表单提交
    $('#xingzuo_query_form').on('submit', function (e) {
        e.preventDefault();
        console.log('Xingzuo Query: Form submitted');

        var $form = $(this);
        var me_zodiac = $('#xingzuo_me').val();
        var he_zodiac = $('#xingzuo_he').val();
        var all_mode = $('#xingzuo_all').is(':checked') ? 1 : 0;
        var nonce = $('#xingzuo_nonce').val();

        console.log('Xingzuo Query: Form data', { me_zodiac, he_zodiac, all_mode, nonce });

        if (!me_zodiac) {
            console.warn('Xingzuo Query: No zodiac selected');
            $('#xingzuo_result').html('<div class="xingzuo_message">请选择你的星座！</div>');
            return;
        }

        if (!nonce) {
            console.warn('Xingzuo Query: Nonce missing');
            $('#xingzuo_result').html('<div class="xingzuo_message">安全验证参数丢失，请刷新页面！</div>');
            return;
        }

        $.ajax({
            url: xingzuo_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xingzuo_query',
                me_zodiac: me_zodiac,
                he_zodiac: he_zodiac,
                all_mode: all_mode,
                nonce: nonce
            },
            beforeSend: function () {
                console.log('Xingzuo Query: Sending AJAX request');
                $('.xingzuo_submit_button').prop('disabled', true).text('查询中...');
            },
            success: function (response) {
                console.log('Xingzuo Query: AJAX success', response);
                if (response.success) {
                    $('#xingzuo_result').html(response.data.result);
                    $('.xingzuo_usage_info').text('今日剩余查询次数：' + response.data.remaining + '/' + response.data.limit);

                    if (response.data.remaining <= 0) {
                        console.log('Xingzuo Query: Query limit reached');
                        $form.hide();
                        $('#xingzuo_result').append('<div class="xingzuo_message">今日查询次数已用尽，请明天再试！</div>');
                    }
                } else {
                    console.warn('Xingzuo Query: AJAX response error', response.data.message);
                    $('#xingzuo_result').html('<div class="xingzuo_message">' + response.data.message + '</div>');
                }
            },
            error: function (xhr, status, error) {
                console.error('Xingzuo Query: AJAX error', { status, error });
                $('#xingzuo_result').html('<div class="xingzuo_message">请求失败：' + error + '。请检查网络或刷新页面。</div>');
            },
            complete: function () {
                console.log('Xingzuo Query: AJAX request completed');
                $('.xingzuo_submit_button').prop('disabled', false).text('查询');
            }
        });
    });

    // “快速登录”按钮点击事件
    $('.xingzuo_login_button').on('click', function (e) {
        e.preventDefault();
        console.log('Xingzuo Query: Login button clicked');
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            console.log('Xingzuo Query: Triggering theme login button');
            $themeLoginBtn.trigger('click');
        } else {
            console.log('Xingzuo Query: Redirecting to login URL');
            window.location.href = $(this).attr('href');
        }
    });

    // 测试交互性
    $('#xingzuo_me, #xingzuo_he').on('change', function () {
        console.log('Xingzuo Query: Select changed', $(this).attr('id'), $(this).val());
    });

    $('#xingzuo_all').on('change', function () {
        console.log('Xingzuo Query: All zodiacs checkbox changed', $(this).is(':checked'));
    });

    $('.xingzuo_submit_button').on('click', function () {
        console.log('Xingzuo Query: Submit button clicked');
    });
});