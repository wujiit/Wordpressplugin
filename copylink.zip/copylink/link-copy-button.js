(function() {
    tinymce.PluginManager.add('link_copy', function(editor, url) {
        editor.addButton('link_copy', {
            text: '自动复制',
            icon: false,
            onclick: function() {
                editor.insertContent('[link_copy url="your-url"]复制[/link_copy]');
            }
        });
    });
})();
