<?php
/**
 * Plugin Name: 小半自定义广告
 * Plugin URI: https://www.jingxialai.com
 * Description: 自定义广告插件，支持多种广告类型、位置设置、数据统计等功能
 * Version: 1.1.0
 * Author: Summer
 * License: GPL v2 or later
 */

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('XB_ADCUSTOM_VERSION', '1.1.0');
define('XB_ADCUSTOM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('XB_ADCUSTOM_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('XB_ADCUSTOM_TABLE_PREFIX', 'xb_adcustom_');

/**
 * 主插件类
 */
class XB_AdCustom_Plugin {
    
    /**
     * 构造函数
     */
    public function __construct() {
        // 注册激活和停用钩子
        register_activation_hook(__FILE__, array($this, 'xb_adcustom_activate'));
        register_deactivation_hook(__FILE__, array($this, 'xb_adcustom_deactivate'));
        
        // 初始化插件
        add_action('init', array($this, 'xb_adcustom_init'));
        add_action('admin_menu', array($this, 'xb_adcustom_admin_menu'));
        add_action('wp_enqueue_scripts', array($this, 'xb_adcustom_enqueue_frontend_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'xb_adcustom_enqueue_admin_scripts'));
        
        // 添加插件快捷设置链接
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'xb_adcustom_plugin_action_links'));
        
        // 注册短代码
        add_shortcode('xb_adcustom', array($this, 'xb_adcustom_shortcode'));
        
        // 前台广告显示钩子
        add_action('wp_head', array($this, 'xb_adcustom_display_ads'));
        add_action('the_content', array($this, 'xb_adcustom_content_ads'));
        
        // AJAX处理
        add_action('wp_ajax_xb_adcustom_save_ad', array($this, 'xb_adcustom_save_ad'));
        add_action('wp_ajax_xb_adcustom_delete_ad', array($this, 'xb_adcustom_delete_ad'));
        add_action('wp_ajax_xb_adcustom_toggle_ad', array($this, 'xb_adcustom_toggle_ad'));
        add_action('wp_ajax_xb_adcustom_clear_stats', array($this, 'xb_adcustom_clear_stats'));
        add_action('wp_ajax_nopriv_xb_adcustom_track_click', array($this, 'xb_adcustom_track_click'));
        add_action('wp_ajax_xb_adcustom_track_click', array($this, 'xb_adcustom_track_click'));
    }
    
    /**
     * 插件激活时执行
     */
    public function xb_adcustom_activate() {
        $this->xb_adcustom_create_tables();
        $this->xb_adcustom_create_frontend_page();
        flush_rewrite_rules();
    }
    
    /**
     * 插件停用时执行
     */
    public function xb_adcustom_deactivate() {
        flush_rewrite_rules();
    }
    
    /**
     * 创建数据库表
     */
    private function xb_adcustom_create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // 广告表
        $ads_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'ads';
        $ads_sql = "CREATE TABLE $ads_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            content longtext NOT NULL,
            ad_type varchar(50) NOT NULL DEFAULT 'popup',
            position_type varchar(50) NOT NULL DEFAULT 'all',
            position_value text,
            width int(11) DEFAULT 300,
            height int(11) DEFAULT 250,
            device_type varchar(20) DEFAULT 'all',
            is_active tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // 统计表
        $stats_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'stats';
        $stats_sql = "CREATE TABLE $stats_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            ad_id mediumint(9) NOT NULL,
            impressions int(11) DEFAULT 0,
            clicks int(11) DEFAULT 0,
            date_recorded date NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY ad_date (ad_id, date_recorded)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($ads_sql);
        dbDelta($stats_sql);
    }
    
    /**
     * 创建前台页面
     */
    private function xb_adcustom_create_frontend_page() {
        // 检查是否已存在包含短代码的页面
        $existing_page = get_posts(array(
            'post_type' => 'page',
            'post_status' => 'publish',
            's' => '[xb_adcustom]',
            'meta_query' => array(
                array(
                    'key' => '_xb_adcustom_page',
                    'value' => '1',
                    'compare' => '='
                )
            )
        ));
        
        if (empty($existing_page)) {
            // 创建新页面
            $page_data = array(
                'post_title' => 'XB 广告管理',
                'post_content' => '[xb_adcustom]',
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_author' => 1
            );
            
            $page_id = wp_insert_post($page_data);
            if ($page_id) {
                update_post_meta($page_id, '_xb_adcustom_page', '1');
            }
        }
    }
    
    /**
     * 初始化插件
     */
    public function xb_adcustom_init() {
        // 插件初始化逻辑（如需要可在此添加）
    }
    
    /**
     * 添加管理菜单
     */
    public function xb_adcustom_admin_menu() {
        add_menu_page(
            '小半广告管理',
            '小半广告',
            'manage_options',
            'xb-adcustom',
            array($this, 'xb_adcustom_admin_page'),
            'dashicons-megaphone',
            30
        );
        
        add_submenu_page(
            'xb-adcustom',
            '广告列表',
            '广告列表',
            'manage_options',
            'xb-adcustom',
            array($this, 'xb_adcustom_admin_page')
        );
        
        add_submenu_page(
            'xb-adcustom',
            '添加广告',
            '添加广告',
            'manage_options',
            'xb-adcustom-add',
            array($this, 'xb_adcustom_add_page')
        );
        
        add_submenu_page(
            'xb-adcustom',
            '数据统计',
            '数据统计',
            'manage_options',
            'xb-adcustom-stats',
            array($this, 'xb_adcustom_stats_page')
        );
    }
    
    /**
     * 添加插件快捷设置链接
     */
    public function xb_adcustom_plugin_action_links($links) {
        $settings_link = '<a href="' . admin_url('admin.php?page=xb-adcustom') . '">设置</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
    
    /**
     * 加载前端脚本和样式
     */
    public function xb_adcustom_enqueue_frontend_scripts() {
        wp_enqueue_style('xb-adcustom-frontend', XB_ADCUSTOM_PLUGIN_URL . 'assets/css/frontend.css', array(), XB_ADCUSTOM_VERSION);
        wp_enqueue_script('xb-adcustom-frontend', XB_ADCUSTOM_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), XB_ADCUSTOM_VERSION, true);
        
        // 传递AJAX URL和nonce
        wp_localize_script('xb-adcustom-frontend', 'xb_adcustom_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('xb_adcustom_nonce')
        ));
    }
    
    /**
     * 加载后台脚本和样式 - 仅用于传递AJAX参数
     */
    public function xb_adcustom_enqueue_admin_scripts($hook) {
        if (strpos($hook, 'xb-adcustom') !== false) {
            // 只加载jQuery和传递AJAX参数
            wp_enqueue_script('jquery');
        }
    }
    
    /**
     * 短代码处理
     */
    public function xb_adcustom_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id' => '',
            'type' => 'all'
        ), $atts);
        
        return $this->xb_adcustom_render_frontend_page();
    }
    
    /**
     * 渲染前台页面
     */
    private function xb_adcustom_render_frontend_page() {
        ob_start();
        ?>
        <div class="xb-adcustom-frontend-container">
            <div class="xb-adcustom-header">
                <h1 class="xb-adcustom-title">广告管理中心</h1>
                <p class="xb-adcustom-description">管理和查看您的广告设置</p>
            </div>
            <div class="xb-adcustom-content">
                <p>前台广告展示功能已启用。</p>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * 后台主页面
     */
    public function xb_adcustom_admin_page() {
        include XB_ADCUSTOM_PLUGIN_PATH . 'includes/admin-page.php';
    }
    
    /**
     * 添加广告页面
     */
    public function xb_adcustom_add_page() {
        include XB_ADCUSTOM_PLUGIN_PATH . 'includes/add-ad-page.php';
    }
    
    /**
     * 统计页面
     */
    public function xb_adcustom_stats_page() {
        include XB_ADCUSTOM_PLUGIN_PATH . 'includes/stats-page.php';
    }
    
    /**
     * 显示广告
     */
    public function xb_adcustom_display_ads() {
        $this->xb_adcustom_show_popup_ads();
    }
    
    /**
     * 内容中的广告
     */
    public function xb_adcustom_content_ads($content) {
        return $this->xb_adcustom_insert_content_ads($content);
    }
    
    /**
     * 显示弹窗广告
     */
    private function xb_adcustom_show_popup_ads() {
        global $wpdb;
        
        $ads_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'ads';
        $ads = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $ads_table WHERE is_active = 1 AND ad_type = %s",
            'popup'
        ));
        
        foreach ($ads as $ad) {
            if ($this->xb_adcustom_should_show_ad($ad)) {
                $this->xb_adcustom_render_popup_ad($ad);
                $this->xb_adcustom_track_impression($ad->id);
            }
        }
    }
    
    /**
     * 插入内容广告
     */
    private function xb_adcustom_insert_content_ads($content) {
        global $wpdb;
        
        $ads_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'ads';
        $ads = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $ads_table WHERE is_active = 1 AND ad_type = %s",
            'embed'
        ));
        
        foreach ($ads as $ad) {
            if ($this->xb_adcustom_should_show_ad($ad)) {
                $ad_html = $this->xb_adcustom_render_embed_ad($ad);
                
                // 确定嵌入位置
                $embed_position = 'content_end'; // 默认位置
                
                if ($ad->position_type === 'single') {
                    // 指定文章：从JSON数据中获取嵌入位置
                    $position_data = json_decode($ad->position_value, true);
                    if (is_array($position_data) && isset($position_data['embed_position'])) {
                        $embed_position = $position_data['embed_position'];
                    } else {
                        // 兼容旧数据，默认文章结尾
                        $embed_position = 'content_end';
                    }
                } elseif ($ad->position_type === 'all_single') {
                    // 全部文章页面：position_value直接存储嵌入位置
                    $embed_position = $ad->position_value ?: 'content_end';
                }
                
                if ($embed_position === 'content_start') {
                    $content = $ad_html . $content;
                } else {
                    $content = $content . $ad_html;
                }
                
                $this->xb_adcustom_track_impression($ad->id);
            }
        }
        
        return $content;
    }
    
    /**
     * 判断是否应该显示广告
     */
    private function xb_adcustom_should_show_ad($ad) {
        // 检查设备类型
        if (!$this->xb_adcustom_check_device_type($ad->device_type)) {
            return false;
        }
        
        // 检查位置类型
        return $this->xb_adcustom_check_position($ad);
    }
    
    /**
     * 检查设备类型
     */
    private function xb_adcustom_check_device_type($device_type) {
        if ($device_type === 'all') {
            return true;
        }
        
        $is_mobile = wp_is_mobile();
        
        if ($device_type === 'mobile' && $is_mobile) {
            return true;
        }
        
        if ($device_type === 'desktop' && !$is_mobile) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 检查位置 - 优化支持多个ID
     */
    private function xb_adcustom_check_position($ad) {
        switch ($ad->position_type) {
            case 'all':
                return true;
            case 'home':
                return is_home() || is_front_page();
            case 'all_single':
                // 全部文章页面
                return is_single();
            case 'single':
                if ($ad->position_value) {
                    // 检查是否是JSON格式（嵌入式广告）
                    $position_data = json_decode($ad->position_value, true);
                    if (is_array($position_data) && isset($position_data['article_ids'])) {
                        // 嵌入式广告的JSON格式
                        $article_ids = $position_data['article_ids'];
                    } else {
                        // 普通格式（弹窗广告或旧数据）
                        $article_ids = $ad->position_value;
                    }
                    
                    // 支持多个文章ID，用逗号分隔
                    $post_ids = array_map('intval', array_map('trim', explode(',', $article_ids)));
                    $post_ids = array_filter($post_ids); // 移除空值
                    if (!empty($post_ids)) {
                        global $post;
                        return is_single() && in_array($post->ID, $post_ids);
                    }
                }
                return is_single();
            case 'page':
                if ($ad->position_value) {
                    // 支持多个页面ID，用逗号分隔
                    $page_ids = array_map('intval', array_map('trim', explode(',', $ad->position_value)));
                    $page_ids = array_filter($page_ids); // 移除空值
                    if (!empty($page_ids)) {
                        global $post;
                        return is_page() && in_array($post->ID, $page_ids);
                    }
                }
                return is_page();
            case 'category':
                if ($ad->position_value) {
                    // 支持多个分类ID，用逗号分隔
                    $category_ids = array_map('intval', array_map('trim', explode(',', $ad->position_value)));
                    $category_ids = array_filter($category_ids); // 移除空值
                    if (!empty($category_ids)) {
                        foreach ($category_ids as $cat_id) {
                            if (is_category($cat_id)) {
                                return true;
                            }
                        }
                        return false;
                    }
                }
                return is_category();
            default:
                return false;
        }
    }
    

    
    /**
     * 渲染弹窗广告
     */
    private function xb_adcustom_render_popup_ad($ad) {
        ?>
        <div class="xb-adcustom-popup-overlay" id="xb-adcustom-popup-<?php echo $ad->id; ?>">
            <div class="xb-adcustom-popup-container" style="width: <?php echo $ad->width; ?>px; height: <?php echo $ad->height; ?>px;">
                <div class="xb-adcustom-popup-close" onclick="xbAdCustomClosePopup(<?php echo $ad->id; ?>)">×</div>
                <div class="xb-adcustom-popup-content" onclick="xbAdCustomTrackClick(<?php echo $ad->id; ?>)">
                    <?php echo wp_kses_post($ad->content); ?>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * 渲染嵌入广告
     */
    private function xb_adcustom_render_embed_ad($ad) {
        ob_start();
        ?>
        <div class="xb-adcustom-embed-container" style="width: <?php echo $ad->width; ?>px; height: <?php echo $ad->height; ?>px;">
            <div class="xb-adcustom-embed-content" onclick="xbAdCustomTrackClick(<?php echo $ad->id; ?>)">
                <?php echo wp_kses_post($ad->content); ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * 记录展示次数
     */
    private function xb_adcustom_track_impression($ad_id) {
        global $wpdb;
        
        $stats_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'stats';
        $today = date('Y-m-d');
        
        $wpdb->query($wpdb->prepare(
            "INSERT INTO $stats_table (ad_id, impressions, date_recorded) 
             VALUES (%d, 1, %s) 
             ON DUPLICATE KEY UPDATE impressions = impressions + 1",
            $ad_id, $today
        ));
    }
    
    /**
     * AJAX: 保存广告
     */
    public function xb_adcustom_save_ad() {
        check_ajax_referer('xb_adcustom_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('权限不足');
        }
        
        global $wpdb;
        $ads_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'ads';
        
        // 处理位置值
        $position_value = '';
        $ad_type = sanitize_text_field($_POST['ad_type']);
        $position_type = sanitize_text_field($_POST['position_type']);
        
        if ($ad_type === 'embed' && $position_type === 'single') {
            // 指定文章的嵌入式广告：同时保存文章ID和嵌入位置
            $article_ids = sanitize_text_field($_POST['position_value']);
            $embed_position = isset($_POST['embed_position']) ? sanitize_text_field($_POST['embed_position']) : 'content_end';
            
            // 使用JSON格式存储文章ID和嵌入位置
            $position_value = json_encode(array(
                'article_ids' => $article_ids,
                'embed_position' => $embed_position
            ));
        } elseif ($ad_type === 'embed' && $position_type === 'all_single') {
            // 全部文章页面的嵌入式广告：只保存嵌入位置
            $embed_position = isset($_POST['embed_position']) ? sanitize_text_field($_POST['embed_position']) : 'content_end';
            $position_value = $embed_position;
        } else {
            // 其他情况正常保存
            $position_value = sanitize_text_field($_POST['position_value']);
        }
        
        $data = array(
            'name' => sanitize_text_field($_POST['name']),
            'content' => wp_kses_post($_POST['content']),
            'ad_type' => $ad_type,
            'position_type' => $position_type,
            'position_value' => $position_value,
            'width' => intval($_POST['width']),
            'height' => intval($_POST['height']),
            'device_type' => sanitize_text_field($_POST['device_type']),
            'is_active' => intval($_POST['is_active'])
        );
        
        if (isset($_POST['ad_id']) && $_POST['ad_id']) {
            $wpdb->update($ads_table, $data, array('id' => intval($_POST['ad_id'])));
        } else {
            $wpdb->insert($ads_table, $data);
        }
        
        wp_send_json_success('广告保存成功');
    }
    
    /**
     * AJAX: 删除广告
     */
    public function xb_adcustom_delete_ad() {
        check_ajax_referer('xb_adcustom_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('权限不足');
        }
        
        global $wpdb;
        $ads_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'ads';
        $stats_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'stats';
        
        $ad_id = intval($_POST['ad_id']);
        
        // 删除广告和相关统计数据
        $wpdb->delete($ads_table, array('id' => $ad_id));
        $wpdb->delete($stats_table, array('ad_id' => $ad_id));
        
        wp_send_json_success('广告删除成功');
    }
    
    /**
     * AJAX: 切换广告状态
     */
    public function xb_adcustom_toggle_ad() {
        check_ajax_referer('xb_adcustom_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('权限不足');
        }
        
        global $wpdb;
        $ads_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'ads';
        
        $ad_id = intval($_POST['ad_id']);
        $is_active = intval($_POST['is_active']);
        
        $wpdb->update($ads_table, array('is_active' => $is_active), array('id' => $ad_id));
        
        wp_send_json_success('状态更新成功');
    }
    
    /**
     * AJAX: 清除统计数据
     */
    public function xb_adcustom_clear_stats() {
        check_ajax_referer('xb_adcustom_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('权限不足');
        }
        
        global $wpdb;
        $stats_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'stats';
        
        $clear_type = sanitize_text_field($_POST['clear_type']);
        $clear_date = sanitize_text_field($_POST['clear_date']);
        
        switch ($clear_type) {
            case 'all':
                $wpdb->query("TRUNCATE TABLE $stats_table");
                $message = '所有统计数据已清除';
                break;
            case 'before_date':
                if ($clear_date) {
                    $wpdb->delete($stats_table, array('date_recorded <' => $clear_date));
                    $message = '指定日期前的统计数据已清除';
                } else {
                    wp_send_json_error('请选择日期');
                    return;
                }
                break;
            case 'older_than_days':
                $days = intval($_POST['clear_days']);
                if ($days > 0) {
                    $cutoff_date = date('Y-m-d', strtotime("-{$days} days"));
                    $wpdb->query($wpdb->prepare("DELETE FROM $stats_table WHERE date_recorded < %s", $cutoff_date));
                    $message = "超过 {$days} 天的统计数据已清除";
                } else {
                    wp_send_json_error('请输入有效天数');
                    return;
                }
                break;
            default:
                wp_send_json_error('无效的清除类型');
                return;
        }
        
        wp_send_json_success($message);
    }
    
    /**
     * AJAX: 记录点击
     */
    public function xb_adcustom_track_click() {
        check_ajax_referer('xb_adcustom_nonce', 'nonce');
        
        global $wpdb;
        $stats_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'stats';
        
        $ad_id = intval($_POST['ad_id']);
        $today = date('Y-m-d');
        
        $wpdb->query($wpdb->prepare(
            "INSERT INTO $stats_table (ad_id, clicks, date_recorded) 
             VALUES (%d, 1, %s) 
             ON DUPLICATE KEY UPDATE clicks = clicks + 1",
            $ad_id, $today
        ));
        
        wp_send_json_success('点击记录成功');
    }
}

// 初始化插件
new XB_AdCustom_Plugin();