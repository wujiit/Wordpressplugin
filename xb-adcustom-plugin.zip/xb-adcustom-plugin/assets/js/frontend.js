/**
 * 前端 JavaScript
 */

jQuery(document).ready(function($) {
    
    // 初始化前端功能
    xbAdCustomInitFrontend();
    
    /**
     * 初始化前端功能
     */
    function xbAdCustomInitFrontend() {
        // 显示弹窗广告
        setTimeout(function() {
            $('.xb-adcustom-popup-overlay').addClass('show');
        }, 1000); // 1秒后显示弹窗
        
        // 绑定点击事件
        $('.xb-adcustom-popup-content, .xb-adcustom-embed-content').on('click', function(e) {
            // 如果点击的是关闭按钮，不触发点击统计
            if ($(e.target).hasClass('xb-adcustom-popup-close')) {
                return;
            }
            
            const adId = $(this).closest('[id*="xb-adcustom-popup-"], .xb-adcustom-embed-container').attr('id');
            if (adId) {
                const id = adId.replace('xb-adcustom-popup-', '');
                xbAdCustomTrackClick(id);
            }
        });
    }
    
    /**
     * 关闭弹窗广告
     */
    window.xbAdCustomClosePopup = function(adId) {
        $('#xb-adcustom-popup-' + adId).removeClass('show');
        
        // 延迟移除，等待动画完成
        setTimeout(function() {
            $('#xb-adcustom-popup-' + adId).remove();
        }, 300);
    };
    
    /**
     * 记录点击
     */
    window.xbAdCustomTrackClick = function(adId) {
        $.ajax({
            url: xb_adcustom_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_adcustom_track_click',
                nonce: xb_adcustom_ajax.nonce,
                ad_id: adId
            },
            success: function(response) {
                // 点击记录成功，可以在这里添加其他逻辑
                console.log('广告点击已记录');
            },
            error: function() {
                console.log('点击记录失败');
            }
        });
    };
    
    /**
     * 显示通知
     */
    function xbAdCustomShowNotification(icon, message, type) {
        // 创建通知元素（如果不存在）
        let $notification = $('#xb-adcustom-notification');
        if ($notification.length === 0) {
            $notification = $('<div id="xb-adcustom-notification" class="xb-adcustom-notification">' +
                '<div class="xb-adcustom-notification-content">' +
                '<span class="xb-adcustom-notification-icon"></span>' +
                '<span class="xb-adcustom-notification-message"></span>' +
                '<button class="xb-adcustom-notification-close" onclick="xbAdCustomCloseNotification()">×</button>' +
                '</div>' +
                '</div>');
            $('body').append($notification);
        }
        
        const $content = $notification.find('.xb-adcustom-notification-content');
        const $icon = $content.find('.xb-adcustom-notification-icon');
        const $message = $content.find('.xb-adcustom-notification-message');
        
        // 设置内容
        $icon.text(icon);
        $message.text(message);
        
        // 设置类型
        $notification.removeClass('success error warning info').addClass(type || 'info');
        
        // 显示通知
        $notification.addClass('show');
        
        // 3秒后自动隐藏
        setTimeout(function() {
            $notification.removeClass('show');
        }, 3000);
    }
    
    /**
     * 关闭通知
     */
    window.xbAdCustomCloseNotification = function() {
        $('#xb-adcustom-notification').removeClass('show');
    };
    
    /**
     * 响应式处理
     */
    function xbAdCustomHandleResize() {
        const $popups = $('.xb-adcustom-popup-container');
        const windowWidth = $(window).width();
        const windowHeight = $(window).height();
        
        $popups.each(function() {
            const $popup = $(this);
            const originalWidth = parseInt($popup.data('original-width') || $popup.width());
            const originalHeight = parseInt($popup.data('original-height') || $popup.height());
            
            // 保存原始尺寸
            if (!$popup.data('original-width')) {
                $popup.data('original-width', originalWidth);
                $popup.data('original-height', originalHeight);
            }
            
            // 计算适应屏幕的尺寸
            let newWidth = originalWidth;
            let newHeight = originalHeight;
            
            if (originalWidth > windowWidth * 0.9) {
                newWidth = windowWidth * 0.9;
                newHeight = (newWidth / originalWidth) * originalHeight;
            }
            
            if (newHeight > windowHeight * 0.9) {
                newHeight = windowHeight * 0.9;
                newWidth = (newHeight / originalHeight) * originalWidth;
            }
            
            $popup.css({
                'width': newWidth + 'px',
                'height': newHeight + 'px'
            });
        });
    }
    
    // 绑定窗口大小改变事件
    $(window).on('resize', xbAdCustomHandleResize);
    
    // 初始化时执行一次
    xbAdCustomHandleResize();
    
    /**
     * 键盘事件处理
     */
    $(document).on('keydown', function(e) {
        // ESC键关闭弹窗
        if (e.keyCode === 27) {
            $('.xb-adcustom-popup-overlay.show').each(function() {
                const adId = $(this).attr('id').replace('xb-adcustom-popup-', '');
                xbAdCustomClosePopup(adId);
            });
        }
    });
    
    /**
     * 点击遮罩关闭弹窗
     */
    $(document).on('click', '.xb-adcustom-popup-overlay', function(e) {
        if (e.target === this) {
            const adId = $(this).attr('id').replace('xb-adcustom-popup-', '');
            xbAdCustomClosePopup(adId);
        }
    });
    
    /**
     * 防止弹窗内容区域点击时关闭弹窗
     */
    $(document).on('click', '.xb-adcustom-popup-container', function(e) {
        e.stopPropagation();
    });
    
    /**
     * 滚动时的处理
     */
    let scrollTimer = null;
    $(window).on('scroll', function() {
        // 清除之前的定时器
        if (scrollTimer) {
            clearTimeout(scrollTimer);
        }
        
        // 设置新的定时器
        scrollTimer = setTimeout(function() {
            // 可以在这里添加滚动相关的广告逻辑
            // 比如滚动到特定位置时显示广告
        }, 100);
    });
    
    /**
     * 设备检测
     */
    function xbAdCustomDetectDevice() {
        const userAgent = navigator.userAgent.toLowerCase();
        const isMobile = /mobile|android|iphone|ipad|phone/i.test(userAgent);
        const isTablet = /tablet|ipad/i.test(userAgent);
        
        $('body').addClass(isMobile ? 'xb-adcustom-mobile' : 'xb-adcustom-desktop');
        
        if (isTablet) {
            $('body').addClass('xb-adcustom-tablet');
        }
        
        return {
            isMobile: isMobile,
            isTablet: isTablet,
            isDesktop: !isMobile && !isTablet
        };
    }
    
    // 执行设备检测
    const deviceInfo = xbAdCustomDetectDevice();
    
    /**
     * 广告可见性检测
     */
    function xbAdCustomCheckVisibility() {
        $('.xb-adcustom-embed-container').each(function() {
            const $ad = $(this);
            const adTop = $ad.offset().top;
            const adBottom = adTop + $ad.height();
            const windowTop = $(window).scrollTop();
            const windowBottom = windowTop + $(window).height();
            
            // 检查广告是否在可视区域内
            if (adBottom > windowTop && adTop < windowBottom) {
                if (!$ad.hasClass('xb-adcustom-visible')) {
                    $ad.addClass('xb-adcustom-visible');
                    // 可以在这里记录展示次数
                }
            }
        });
    }
    
    // 绑定滚动事件检测可见性
    $(window).on('scroll resize', xbAdCustomCheckVisibility);
    
    // 初始化时检测一次
    xbAdCustomCheckVisibility();
    
});