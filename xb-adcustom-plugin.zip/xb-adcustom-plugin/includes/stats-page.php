<?php
// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$ads_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'ads';
$stats_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'stats';

// 获取日期范围
$start_date = isset($_GET['start_date']) ? sanitize_text_field($_GET['start_date']) : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? sanitize_text_field($_GET['end_date']) : date('Y-m-d');

// 获取统计数据
$stats_query = $wpdb->prepare("
    SELECT 
        a.id,
        a.name,
        a.ad_type,
        SUM(s.impressions) as total_impressions,
        SUM(s.clicks) as total_clicks,
        CASE 
            WHEN SUM(s.impressions) > 0 
            THEN ROUND((SUM(s.clicks) / SUM(s.impressions)) * 100, 2)
            ELSE 0 
        END as ctr
    FROM {$ads_table} a
    LEFT JOIN {$stats_table} s ON a.id = s.ad_id 
        AND s.date_recorded BETWEEN %s AND %s
    GROUP BY a.id, a.name, a.ad_type
    ORDER BY total_impressions DESC
", $start_date, $end_date);

$stats = $wpdb->get_results($stats_query);

// 获取总体统计
$total_stats = $wpdb->get_row($wpdb->prepare("
    SELECT 
        SUM(impressions) as total_impressions,
        SUM(clicks) as total_clicks,
        CASE 
            WHEN SUM(impressions) > 0 
            THEN ROUND((SUM(clicks) / SUM(impressions)) * 100, 2)
            ELSE 0 
        END as avg_ctr
    FROM {$stats_table}
    WHERE date_recorded BETWEEN %s AND %s
", $start_date, $end_date));

// 获取每日统计数据（用于图表）
$daily_stats = $wpdb->get_results($wpdb->prepare("
    SELECT 
        date_recorded,
        SUM(impressions) as impressions,
        SUM(clicks) as clicks
    FROM {$stats_table}
    WHERE date_recorded BETWEEN %s AND %s
    GROUP BY date_recorded
    ORDER BY date_recorded ASC
", $start_date, $end_date));
?>

<style>
/* 后台统计页面样式 - 内联CSS */
.xb-adcustom-admin-wrap * {
    box-sizing: border-box;
}

.xb-adcustom-admin-wrap {
    max-width: 1200px;
    margin: 20px 0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

.xb-adcustom-admin-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 30px;
    border-radius: 12px;
    margin-bottom: 30px;
    box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3);
}

.xb-adcustom-admin-title {
    font-size: 28px;
    font-weight: 700;
    margin: 0 0 8px 0;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.xb-adcustom-admin-subtitle {
    font-size: 16px;
    margin: 0;
    opacity: 0.9;
}

.xb-adcustom-admin-content {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.xb-adcustom-stats-filter {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    padding: 20px 30px;
    margin-bottom: 30px;
}

.xb-adcustom-filter-form {
    display: flex;
    align-items: end;
    gap: 20px;
    flex-wrap: wrap;
}

.xb-adcustom-filter-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.xb-adcustom-label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: #495057;
    font-size: 14px;
}

.xb-adcustom-input {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid #e9ecef;
    border-radius: 8px;
    font-size: 14px;
    transition: border-color 0.2s ease;
    font-family: inherit;
}

.xb-adcustom-input:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.xb-adcustom-input-small {
    width: 150px;
}

.xb-adcustom-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s ease;
    line-height: 1.4;
}

.xb-adcustom-btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.xb-adcustom-btn-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    color: white;
}

.xb-adcustom-btn-secondary {
    background: #6c757d;
    color: white;
}

.xb-adcustom-btn-secondary:hover {
    background: #5a6268;
    color: white;
}

.xb-adcustom-btn-danger {
    background: #dc3545;
    color: white;
}

.xb-adcustom-btn-danger:hover {
    background: #c82333;
    color: white;
}

.xb-adcustom-btn-small {
    padding: 6px 12px;
    font-size: 12px;
}

.xb-adcustom-quick-filters {
    display: flex;
    gap: 10px;
    margin-left: auto;
}

.xb-adcustom-quick-filter {
    padding: 8px 12px;
    background: #f8f9fa;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    text-decoration: none;
    color: #495057;
    font-size: 12px;
    transition: all 0.2s ease;
}

.xb-adcustom-quick-filter:hover {
    background: #e9ecef;
    color: #495057;
}

.xb-adcustom-stats-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.xb-adcustom-stats-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    padding: 25px;
    display: flex;
    align-items: center;
    gap: 20px;
    transition: transform 0.2s ease;
}

.xb-adcustom-stats-card:hover {
    transform: translateY(-2px);
}

.xb-adcustom-stats-card-icon {
    font-size: 32px;
    width: 60px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 12px;
    color: white;
}

.xb-adcustom-stats-card-content {
    flex: 1;
}

.xb-adcustom-stats-card-title {
    font-size: 14px;
    color: #6c757d;
    margin: 0 0 8px 0;
    font-weight: 500;
}

.xb-adcustom-stats-card-value {
    font-size: 28px;
    font-weight: 700;
    color: #495057;
    margin: 0;
}

.xb-adcustom-chart-container {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    padding: 30px;
    margin-bottom: 30px;
}

.xb-adcustom-section-title {
    font-size: 20px;
    font-weight: 600;
    color: #495057;
    margin: 0 0 20px 0;
    padding-bottom: 10px;
    border-bottom: 2px solid #667eea;
    display: inline-block;
}

.xb-adcustom-stats-table-container {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    padding: 30px;
}

.xb-adcustom-admin-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
}

.xb-adcustom-admin-table th {
    background: #f8f9fa;
    padding: 15px 12px;
    text-align: left;
    font-weight: 600;
    color: #495057;
    border-bottom: 2px solid #dee2e6;
}

.xb-adcustom-admin-table td {
    padding: 15px 12px;
    border-bottom: 1px solid #dee2e6;
    vertical-align: middle;
}

.xb-adcustom-admin-table tr:hover {
    background: #f8f9fa;
}

.xb-adcustom-badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.xb-adcustom-badge-popup {
    background: #e3f2fd;
    color: #1976d2;
}

.xb-adcustom-badge-embed {
    background: #f3e5f5;
    color: #7b1fa2;
}

.xb-adcustom-stats-number {
    font-weight: 600;
    color: #495057;
}

.xb-adcustom-stats-ctr {
    font-weight: 600;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 12px;
}

.xb-adcustom-stats-ctr-good {
    background: #d4edda;
    color: #155724;
}

.xb-adcustom-stats-ctr-medium {
    background: #fff3cd;
    color: #856404;
}

.xb-adcustom-stats-ctr-low {
    background: #f8d7da;
    color: #721c24;
}

.xb-adcustom-no-data {
    text-align: center;
    padding: 60px 20px;
}

.xb-adcustom-empty-state {
    color: #6c757d;
}

.xb-adcustom-empty-icon {
    font-size: 48px;
    display: block;
    margin-bottom: 16px;
}

.xb-adcustom-empty-state h3 {
    margin: 0 0 8px 0;
    font-size: 18px;
    color: #495057;
}

.xb-adcustom-empty-state p {
    margin: 0;
    font-size: 14px;
}

.xb-adcustom-clear-stats-section {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    padding: 30px;
    margin-bottom: 30px;
    border-left: 4px solid #dc3545;
}

.xb-adcustom-clear-stats-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}

.xb-adcustom-clear-stats-info h3 {
    margin: 0 0 8px 0;
    color: #495057;
    font-size: 18px;
}

.xb-adcustom-clear-stats-info p {
    margin: 0;
    color: #6c757d;
    font-size: 14px;
}

.xb-adcustom-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    z-index: 10000;
    display: none;
    align-items: center;
    justify-content: center;
}

.xb-adcustom-modal.show {
    display: flex;
}

.xb-adcustom-modal-content {
    background: white;
    border-radius: 16px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
    max-width: 500px;
    width: 90%;
    padding: 30px;
    text-align: center;
}

.xb-adcustom-modal-title {
    font-size: 20px;
    font-weight: 600;
    color: #495057;
    margin: 0 0 15px 0;
}

.xb-adcustom-modal-text {
    color: #6c757d;
    margin: 0 0 25px 0;
    line-height: 1.5;
}

.xb-adcustom-modal-actions {
    display: flex;
    gap: 15px;
    justify-content: center;
}

.xb-adcustom-notification {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 10001;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.xb-adcustom-notification.show {
    opacity: 1;
    visibility: visible;
}

.xb-adcustom-notification-content {
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    padding: 20px 25px;
    display: flex;
    align-items: center;
    gap: 15px;
    min-width: 300px;
    max-width: 500px;
}

.xb-adcustom-notification-icon {
    font-size: 24px;
}

.xb-adcustom-notification-message {
    flex: 1;
    font-size: 14px;
    color: #495057;
}

.xb-adcustom-notification-close {
    background: none;
    border: none;
    font-size: 20px;
    color: #6c757d;
    cursor: pointer;
    padding: 0;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.xb-adcustom-notification.success .xb-adcustom-notification-icon {
    color: #28a745;
}

.xb-adcustom-notification.error .xb-adcustom-notification-icon {
    color: #dc3545;
}

@media (max-width: 768px) {
    .xb-adcustom-filter-form {
        flex-direction: column;
        align-items: stretch;
    }
    
    .xb-adcustom-quick-filters {
        margin-left: 0;
        margin-top: 15px;
    }
    
    .xb-adcustom-stats-cards {
        grid-template-columns: 1fr;
    }
    
    .xb-adcustom-clear-stats-content {
        flex-direction: column;
        text-align: center;
    }
    
    .xb-adcustom-modal-actions {
        flex-direction: column;
    }
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.xb-adcustom-admin-wrap {
    animation: fadeInUp 0.5s ease;
}
</style>

<div class="xb-adcustom-admin-wrap">
    <div class="xb-adcustom-admin-header">
        <h1 class="xb-adcustom-admin-title">数据统计</h1>
        <p class="xb-adcustom-admin-subtitle">查看广告展示和点击数据</p>
    </div>

    <div class="xb-adcustom-admin-content">
        <!-- 日期筛选 -->
        <div class="xb-adcustom-stats-filter">
            <form method="get" class="xb-adcustom-filter-form">
                <input type="hidden" name="page" value="xb-adcustom-stats">
                
                <div class="xb-adcustom-filter-group">
                    <label class="xb-adcustom-label">开始日期：</label>
                    <input type="date" name="start_date" value="<?php echo esc_attr($start_date); ?>" 
                           class="xb-adcustom-input xb-adcustom-input-small">
                </div>
                
                <div class="xb-adcustom-filter-group">
                    <label class="xb-adcustom-label">结束日期：</label>
                    <input type="date" name="end_date" value="<?php echo esc_attr($end_date); ?>" 
                           class="xb-adcustom-input xb-adcustom-input-small">
                </div>
                
                <button type="submit" class="xb-adcustom-btn xb-adcustom-btn-primary">筛选</button>
                
                <div class="xb-adcustom-quick-filters">
                    <a href="?page=xb-adcustom-stats&start_date=<?php echo date('Y-m-d'); ?>&end_date=<?php echo date('Y-m-d'); ?>" 
                       class="xb-adcustom-quick-filter">今天</a>
                    <a href="?page=xb-adcustom-stats&start_date=<?php echo date('Y-m-d', strtotime('-7 days')); ?>&end_date=<?php echo date('Y-m-d'); ?>" 
                       class="xb-adcustom-quick-filter">最近7天</a>
                    <a href="?page=xb-adcustom-stats&start_date=<?php echo date('Y-m-d', strtotime('-30 days')); ?>&end_date=<?php echo date('Y-m-d'); ?>" 
                       class="xb-adcustom-quick-filter">最近30天</a>
                </div>
            </form>
        </div>

        <!-- 清除统计数据功能 -->
        <div class="xb-adcustom-clear-stats-section">
            <div class="xb-adcustom-clear-stats-content">
                <div class="xb-adcustom-clear-stats-info">
                    <h3>清除统计数据</h3>
                    <p>删除所有历史统计数据以释放数据库空间。此操作不可撤销，请谨慎操作。</p>
                </div>
                <button onclick="xbAdCustomShowClearModal()" class="xb-adcustom-btn xb-adcustom-btn-danger">
                    清除所有数据
                </button>
            </div>
        </div>

        <!-- 总体统计卡片 -->
        <div class="xb-adcustom-stats-cards">
            <div class="xb-adcustom-stats-card">
                <div class="xb-adcustom-stats-card-icon">👁️</div>
                <div class="xb-adcustom-stats-card-content">
                    <h3 class="xb-adcustom-stats-card-title">总展示次数</h3>
                    <p class="xb-adcustom-stats-card-value"><?php echo number_format($total_stats->total_impressions ?? 0); ?></p>
                </div>
            </div>
            
            <div class="xb-adcustom-stats-card">
                <div class="xb-adcustom-stats-card-icon">👆</div>
                <div class="xb-adcustom-stats-card-content">
                    <h3 class="xb-adcustom-stats-card-title">总点击次数</h3>
                    <p class="xb-adcustom-stats-card-value"><?php echo number_format($total_stats->total_clicks ?? 0); ?></p>
                </div>
            </div>
            
            <div class="xb-adcustom-stats-card">
                <div class="xb-adcustom-stats-card-icon">📊</div>
                <div class="xb-adcustom-stats-card-content">
                    <h3 class="xb-adcustom-stats-card-title">平均点击率</h3>
                    <p class="xb-adcustom-stats-card-value"><?php echo ($total_stats->avg_ctr ?? 0) . '%'; ?></p>
                </div>
            </div>
            
            <div class="xb-adcustom-stats-card">
                <div class="xb-adcustom-stats-card-icon">📢</div>
                <div class="xb-adcustom-stats-card-content">
                    <h3 class="xb-adcustom-stats-card-title">活跃广告</h3>
                    <p class="xb-adcustom-stats-card-value"><?php echo count($stats); ?></p>
                </div>
            </div>
        </div>

        <!-- 趋势图表 -->
        <div class="xb-adcustom-chart-container">
            <h3 class="xb-adcustom-section-title">数据趋势</h3>
            <canvas id="xb-adcustom-chart" width="800" height="300"></canvas>
        </div>

        <!-- 详细统计表格 -->
        <div class="xb-adcustom-stats-table-container">
            <h3 class="xb-adcustom-section-title">广告详细统计</h3>
            
            <table class="xb-adcustom-admin-table">
                <thead>
                    <tr>
                        <th>广告名称</th>
                        <th>类型</th>
                        <th>展示次数</th>
                        <th>点击次数</th>
                        <th>点击率</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($stats)): ?>
                        <tr>
                            <td colspan="6" class="xb-adcustom-no-data">
                                <div class="xb-adcustom-empty-state">
                                    <span class="xb-adcustom-empty-icon">📊</span>
                                    <h3>暂无统计数据</h3>
                                    <p>在选定的日期范围内没有找到统计数据</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($stats as $stat): ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($stat->name); ?></strong>
                                </td>
                                <td>
                                    <span class="xb-adcustom-badge xb-adcustom-badge-<?php echo $stat->ad_type; ?>">
                                        <?php echo $stat->ad_type === 'popup' ? '弹窗' : '嵌入'; ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="xb-adcustom-stats-number">
                                        <?php echo number_format($stat->total_impressions ?? 0); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="xb-adcustom-stats-number">
                                        <?php echo number_format($stat->total_clicks ?? 0); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="xb-adcustom-stats-ctr xb-adcustom-stats-ctr-<?php echo $stat->ctr >= 1 ? 'good' : ($stat->ctr >= 0.5 ? 'medium' : 'low'); ?>">
                                        <?php echo $stat->ctr . '%'; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="<?php echo admin_url('admin.php?page=xb-adcustom-add&edit=' . $stat->id); ?>" 
                                       class="xb-adcustom-btn xb-adcustom-btn-small xb-adcustom-btn-secondary">
                                        编辑
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- 清除数据确认模态框 -->
<div id="xb-adcustom-clear-modal" class="xb-adcustom-modal">
    <div class="xb-adcustom-modal-content">
        <h3 class="xb-adcustom-modal-title">确认清除统计数据</h3>
        <p class="xb-adcustom-modal-text">
            您确定要清除所有统计数据吗？<br>
            此操作将永久删除所有广告的展示和点击记录，且无法恢复。
        </p>
        <div class="xb-adcustom-modal-actions">
            <button onclick="xbAdCustomClearStats()" class="xb-adcustom-btn xb-adcustom-btn-danger">
                确认清除
            </button>
            <button onclick="xbAdCustomHideClearModal()" class="xb-adcustom-btn xb-adcustom-btn-secondary">
                取消
            </button>
        </div>
    </div>
</div>

<!-- 自定义提示框 -->
<div id="xb-adcustom-notification" class="xb-adcustom-notification">
    <div class="xb-adcustom-notification-content">
        <span class="xb-adcustom-notification-icon"></span>
        <span class="xb-adcustom-notification-message"></span>
        <button class="xb-adcustom-notification-close" onclick="xbAdCustomCloseNotification()">×</button>
    </div>
</div>

<script>
// 图表数据
var chartData = {
    labels: [<?php 
        foreach ($daily_stats as $day) {
            echo "'" . date('m/d', strtotime($day->date_recorded)) . "',";
        }
    ?>],
    impressions: [<?php 
        foreach ($daily_stats as $day) {
            echo $day->impressions . ',';
        }
    ?>],
    clicks: [<?php 
        foreach ($daily_stats as $day) {
            echo $day->clicks . ',';
        }
    ?>]
};

// 初始化图表
document.addEventListener('DOMContentLoaded', function() {
    xbAdCustomInitChart(chartData);
});

/**
 * 初始化图表
 */
function xbAdCustomInitChart(data) {
    var canvas = document.getElementById('xb-adcustom-chart');
    if (!canvas) return;
    
    var ctx = canvas.getContext('2d');
    var width = canvas.width;
    var height = canvas.height;
    
    // 清空画布
    ctx.clearRect(0, 0, width, height);
    
    // 设置样式
    ctx.strokeStyle = '#667eea';
    ctx.fillStyle = '#667eea';
    ctx.lineWidth = 2;
    
    // 绘制简单的折线图
    if (data.impressions && data.impressions.length > 0) {
        var maxValue = Math.max.apply(Math, data.impressions.concat(data.clicks));
        var stepX = width / (data.labels.length - 1 || 1);
        var stepY = (height - 60) / (maxValue || 1);
        
        // 绘制展示次数线
        ctx.beginPath();
        ctx.strokeStyle = '#667eea';
        for (var i = 0; i < data.impressions.length; i++) {
            var x = i * stepX;
            var y = height - 30 - (data.impressions[i] * stepY);
            if (i === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        }
        ctx.stroke();
        
        // 绘制点击次数线
        ctx.beginPath();
        ctx.strokeStyle = '#764ba2';
        for (var i = 0; i < data.clicks.length; i++) {
            var x = i * stepX;
            var y = height - 30 - (data.clicks[i] * stepY);
            if (i === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        }
        ctx.stroke();
        
        // 绘制标签
        ctx.fillStyle = '#666';
        ctx.font = '12px Arial';
        ctx.textAlign = 'center';
        for (var i = 0; i < data.labels.length; i++) {
            var x = i * stepX;
            ctx.fillText(data.labels[i], x, height - 5);
        }
    }
}

/**
 * 显示清除数据模态框
 */
function xbAdCustomShowClearModal() {
    document.getElementById('xb-adcustom-clear-modal').classList.add('show');
}

/**
 * 隐藏清除数据模态框
 */
function xbAdCustomHideClearModal() {
    document.getElementById('xb-adcustom-clear-modal').classList.remove('show');
}

/**
 * 清除统计数据
 */
function xbAdCustomClearStats() {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '<?php echo admin_url('admin-ajax.php'); ?>', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        xbAdCustomShowNotification('✅', response.data, 'success');
                        xbAdCustomHideClearModal();
                        
                        // 2秒后刷新页面
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } else {
                        xbAdCustomShowNotification('❌', response.data || '清除失败', 'error');
                        xbAdCustomHideClearModal();
                    }
                } catch (e) {
                    xbAdCustomShowNotification('❌', '响应解析失败', 'error');
                    xbAdCustomHideClearModal();
                }
            } else {
                xbAdCustomShowNotification('❌', '网络错误，请重试', 'error');
                xbAdCustomHideClearModal();
            }
        }
    };
    
    var data = 'action=xb_adcustom_clear_stats&nonce=<?php echo wp_create_nonce('xb_adcustom_admin_nonce'); ?>';
    xhr.send(data);
}

/**
 * 显示通知
 */
function xbAdCustomShowNotification(icon, message, type) {
    var notification = document.getElementById('xb-adcustom-notification');
    var content = notification.querySelector('.xb-adcustom-notification-content');
    var iconEl = content.querySelector('.xb-adcustom-notification-icon');
    var messageEl = content.querySelector('.xb-adcustom-notification-message');
    
    // 设置内容
    iconEl.textContent = icon;
    messageEl.textContent = message;
    
    // 设置类型
    notification.className = 'xb-adcustom-notification ' + type;
    
    // 显示通知
    notification.classList.add('show');
    
    // 3秒后自动隐藏
    setTimeout(function() {
        notification.classList.remove('show');
    }, 3000);
}

/**
 * 关闭通知
 */
function xbAdCustomCloseNotification() {
    document.getElementById('xb-adcustom-notification').classList.remove('show');
}

// 点击模态框外部关闭
document.addEventListener('click', function(e) {
    var modal = document.getElementById('xb-adcustom-clear-modal');
    if (e.target === modal) {
        xbAdCustomHideClearModal();
    }
});

// ESC键关闭模态框
document.addEventListener('keydown', function(e) {
    if (e.keyCode === 27) {
        xbAdCustomHideClearModal();
    }
});
</script>