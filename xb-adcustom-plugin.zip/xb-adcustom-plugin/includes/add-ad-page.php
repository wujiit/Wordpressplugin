<?php
// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$ads_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'ads';

// 检查是否是编辑模式
$edit_mode = false;
$ad_data = null;
$edit_article_ids = '';
$edit_embed_position = 'content_end';

if (isset($_GET['edit']) && $_GET['edit']) {
    $edit_mode = true;
    $ad_id = intval($_GET['edit']);
    $ad_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $ads_table WHERE id = %d", $ad_id));
    
    if (!$ad_data) {
        wp_die('广告不存在');
    }
    
    // 解析位置数据
    if ($ad_data->ad_type === 'embed' && $ad_data->position_type === 'single') {
        // 指定文章的嵌入式广告：解析JSON数据
        $position_data = json_decode($ad_data->position_value, true);
        if (is_array($position_data)) {
            $edit_article_ids = $position_data['article_ids'] ?? '';
            $edit_embed_position = $position_data['embed_position'] ?? 'content_end';
        } else {
            // 兼容旧数据
            $edit_article_ids = $ad_data->position_value;
            $edit_embed_position = 'content_end';
        }
    } elseif ($ad_data->ad_type === 'embed' && $ad_data->position_type === 'all_single') {
        // 全部文章页面的嵌入式广告：position_value就是嵌入位置
        $edit_embed_position = $ad_data->position_value ?: 'content_end';
    } else {
        // 其他类型广告
        $edit_article_ids = $ad_data->position_value;
    }
}

// 获取所有页面和文章用于选择
$pages = get_pages();
$posts = get_posts(array('numberposts' => 100));
$categories = get_categories(array('hide_empty' => false));
?>

<style>
/* 后台管理样式 - 内联CSS */
.xb-adcustom-admin-wrap * {
    box-sizing: border-box;
}

.xb-adcustom-admin-wrap {
    max-width: 1200px;
    margin: 20px 0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

.xb-adcustom-admin-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 30px;
    border-radius: 12px;
    margin-bottom: 30px;
    box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3);
}

.xb-adcustom-admin-title {
    font-size: 28px;
    font-weight: 700;
    margin: 0 0 8px 0;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.xb-adcustom-admin-subtitle {
    font-size: 16px;
    margin: 0;
    opacity: 0.9;
}

.xb-adcustom-admin-content {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.xb-adcustom-form {
    padding: 30px;
}

.xb-adcustom-form-section {
    margin-bottom: 40px;
    padding-bottom: 30px;
    border-bottom: 1px solid #e9ecef;
}

.xb-adcustom-form-section:last-child {
    border-bottom: none;
    margin-bottom: 0;
}

.xb-adcustom-section-title {
    font-size: 20px;
    font-weight: 600;
    color: #495057;
    margin: 0 0 20px 0;
    padding-bottom: 10px;
    border-bottom: 2px solid #667eea;
    display: inline-block;
}

.xb-adcustom-form-row {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
}

.xb-adcustom-form-group {
    flex: 1;
}

.xb-adcustom-label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: #495057;
    font-size: 14px;
}

.xb-adcustom-input,
.xb-adcustom-select,
.xb-adcustom-textarea {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid #e9ecef;
    border-radius: 8px;
    font-size: 14px;
    transition: border-color 0.2s ease;
    font-family: inherit;
}

.xb-adcustom-input:focus,
.xb-adcustom-select:focus,
.xb-adcustom-textarea:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.xb-adcustom-textarea {
    resize: vertical;
    min-height: 120px;
}

.xb-adcustom-help-text {
    margin: 8px 0 0 0;
    font-size: 12px;
    color: #6c757d;
}

.xb-adcustom-checkbox-label {
    display: flex;
    align-items: center;
    gap: 12px;
    cursor: pointer;
    font-weight: normal;
}

.xb-adcustom-checkbox-label input[type="checkbox"] {
    width: auto;
    margin: 0;
}

.xb-adcustom-checkmark {
    position: relative;
    width: 20px;
    height: 20px;
    border: 2px solid #e9ecef;
    border-radius: 4px;
    transition: all 0.2s ease;
}

.xb-adcustom-checkbox-label input:checked + .xb-adcustom-checkmark {
    background: #667eea;
    border-color: #667eea;
}

.xb-adcustom-checkbox-label input:checked + .xb-adcustom-checkmark:after {
    content: "✓";
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
    font-size: 12px;
    font-weight: bold;
}

.xb-adcustom-size-presets {
    margin-top: 15px;
}

.xb-adcustom-size-btn {
    background: #f8f9fa;
    border: 1px solid #dee2e6;
    padding: 8px 12px;
    margin-right: 8px;
    margin-bottom: 8px;
    border-radius: 6px;
    font-size: 12px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.xb-adcustom-size-btn:hover {
    background: #e9ecef;
    border-color: #adb5bd;
}

.xb-adcustom-size-btn.active {
    background: #667eea;
    color: white;
    border-color: #667eea;
    transform: scale(1.05);
}

.xb-adcustom-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s ease;
    line-height: 1.4;
}

.xb-adcustom-btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.xb-adcustom-btn-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    color: white;
}

.xb-adcustom-btn-secondary {
    background: #6c757d;
    color: white;
}

.xb-adcustom-btn-secondary:hover {
    background: #5a6268;
    color: white;
}

.xb-adcustom-btn-large {
    padding: 14px 28px;
    font-size: 16px;
}

.xb-adcustom-form-actions {
    display: flex;
    gap: 15px;
    padding-top: 30px;
    border-top: 1px solid #e9ecef;
    margin-top: 30px;
}

.xb-adcustom-category-container {
    border: 2px solid #e9ecef;
    border-radius: 8px;
    padding: 15px;
    background: #f8f9fa;
}

.xb-adcustom-selected-categories {
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 1px solid #dee2e6;
}

.xb-adcustom-selected-categories p {
    margin: 0 0 10px 0;
    font-weight: 500;
    color: #495057;
}

.xb-adcustom-selected-cats {
    min-height: 40px;
    padding: 10px;
    background: white;
    border-radius: 6px;
    border: 1px solid #dee2e6;
}

.xb-adcustom-selected-cat {
    display: inline-block;
    background: #667eea;
    color: white;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 12px;
    margin: 2px;
}

.xb-adcustom-selected-cat button {
    background: none;
    border: none;
    color: white;
    margin-left: 5px;
    cursor: pointer;
    font-weight: bold;
}

.xb-adcustom-category-list p {
    margin: 0 0 10px 0;
    font-weight: 500;
    color: #495057;
}

.xb-adcustom-category-scroll {
    max-height: 200px;
    overflow-y: auto;
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    padding: 10px;
}

.xb-adcustom-category-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 0;
    border-bottom: 1px solid #f8f9fa;
    cursor: pointer;
}

.xb-adcustom-category-item:last-child {
    border-bottom: none;
}

.xb-adcustom-category-item:hover {
    background: #f8f9fa;
}

.xb-adcustom-category-item input[type="checkbox"] {
    margin: 0;
}

.xb-adcustom-page-list {
    margin-top: 10px;
    padding: 10px;
    background: #f8f9fa;
    border-radius: 6px;
    max-height: 150px;
    overflow-y: auto;
}

.xb-adcustom-page-list p {
    margin: 0 0 10px 0;
    font-weight: 500;
    color: #495057;
}

.xb-adcustom-id-tag {
    display: inline-block;
    background: #e9ecef;
    color: #495057;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    margin: 2px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.xb-adcustom-id-tag:hover {
    background: #667eea;
    color: white;
}

.xb-adcustom-notification {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 10000;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.xb-adcustom-notification.show {
    opacity: 1;
    visibility: visible;
}

.xb-adcustom-notification-content {
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    padding: 20px 25px;
    display: flex;
    align-items: center;
    gap: 15px;
    min-width: 300px;
    max-width: 500px;
}

.xb-adcustom-notification-icon {
    font-size: 24px;
}

.xb-adcustom-notification-message {
    flex: 1;
    font-size: 14px;
    color: #495057;
}

.xb-adcustom-notification-close {
    background: none;
    border: none;
    font-size: 20px;
    color: #6c757d;
    cursor: pointer;
    padding: 0;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.xb-adcustom-notification.success .xb-adcustom-notification-icon {
    color: #28a745;
}

.xb-adcustom-notification.error .xb-adcustom-notification-icon {
    color: #dc3545;
}

@media (max-width: 768px) {
    .xb-adcustom-form-row {
        flex-direction: column;
        gap: 15px;
    }
    
    .xb-adcustom-form-actions {
        flex-direction: column;
    }
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.xb-adcustom-admin-wrap {
    animation: fadeInUp 0.5s ease;
}
</style>

<div class="xb-adcustom-admin-wrap">
    <div class="xb-adcustom-admin-header">
        <h1 class="xb-adcustom-admin-title">
            <?php echo $edit_mode ? '编辑广告' : '添加新广告'; ?>
        </h1>
        <p class="xb-adcustom-admin-subtitle">
            <?php echo $edit_mode ? '修改广告设置和内容' : '创建一个新的自定义广告'; ?>
        </p>
    </div>

    <div class="xb-adcustom-admin-content">
        <form id="xb-adcustom-form" class="xb-adcustom-form">
            <?php if ($edit_mode): ?>
                <input type="hidden" name="ad_id" value="<?php echo $ad_data->id; ?>">
            <?php endif; ?>
            
            <div class="xb-adcustom-form-section">
                <h3 class="xb-adcustom-section-title">基本信息</h3>
                
                <div class="xb-adcustom-form-row">
                    <div class="xb-adcustom-form-group">
                        <label class="xb-adcustom-label">广告名称 *</label>
                        <input type="text" name="name" class="xb-adcustom-input" 
                               value="<?php echo $edit_mode ? esc_attr($ad_data->name) : ''; ?>" 
                               placeholder="请输入广告名称" required>
                    </div>
                </div>

                <div class="xb-adcustom-form-row">
                    <div class="xb-adcustom-form-group">
                        <label class="xb-adcustom-label">广告内容 *</label>
                        <textarea name="content" class="xb-adcustom-textarea" rows="10" 
                                  placeholder="请输入HTML格式的广告内容，支持第三方广告代码如Google AdSense" required><?php echo $edit_mode ? esc_textarea($ad_data->content) : ''; ?></textarea>
                        <p class="xb-adcustom-help-text">
                            支持HTML格式，可以插入图片、链接、第三方广告代码等
                        </p>
                    </div>
                </div>
            </div>

            <div class="xb-adcustom-form-section">
                <h3 class="xb-adcustom-section-title">显示设置</h3>
                
                <div class="xb-adcustom-form-row">
                    <div class="xb-adcustom-form-group">
                        <label class="xb-adcustom-label">广告类型 *</label>
                        <select name="ad_type" class="xb-adcustom-select" onchange="xbAdCustomToggleAdType(this.value)">
                            <option value="popup" <?php echo ($edit_mode && $ad_data->ad_type === 'popup') ? 'selected' : ''; ?>>
                                弹窗广告（可关闭）
                            </option>
                            <option value="embed" <?php echo ($edit_mode && $ad_data->ad_type === 'embed') ? 'selected' : ''; ?>>
                                嵌入广告（不可关闭）
                            </option>
                        </select>
                    </div>
                    
                    <div class="xb-adcustom-form-group">
                        <label class="xb-adcustom-label">设备类型</label>
                        <select name="device_type" class="xb-adcustom-select">
                            <option value="all" <?php echo ($edit_mode && $ad_data->device_type === 'all') ? 'selected' : ''; ?>>
                                全部设备
                            </option>
                            <option value="desktop" <?php echo ($edit_mode && $ad_data->device_type === 'desktop') ? 'selected' : ''; ?>>
                                仅电脑端
                            </option>
                            <option value="mobile" <?php echo ($edit_mode && $ad_data->device_type === 'mobile') ? 'selected' : ''; ?>>
                                仅手机端
                            </option>
                        </select>
                    </div>
                </div>

                <div class="xb-adcustom-form-row">
                    <div class="xb-adcustom-form-group">
                        <label class="xb-adcustom-label">显示位置 *</label>
                        <select name="position_type" class="xb-adcustom-select" onchange="xbAdCustomTogglePosition(this.value)">
                            <option value="all" <?php echo ($edit_mode && $ad_data->position_type === 'all') ? 'selected' : ''; ?>>
                                全站显示
                            </option>
                            <option value="home" <?php echo ($edit_mode && $ad_data->position_type === 'home') ? 'selected' : ''; ?>>
                                首页
                            </option>
                            <option value="all_single" <?php echo ($edit_mode && $ad_data->position_type === 'all_single') ? 'selected' : ''; ?>>
                                全部文章页面
                            </option>
                            <option value="single" <?php echo ($edit_mode && $ad_data->position_type === 'single') ? 'selected' : ''; ?>>
                                指定文章
                            </option>
                            <option value="page" <?php echo ($edit_mode && $ad_data->position_type === 'page') ? 'selected' : ''; ?>>
                                指定页面
                            </option>
                            <option value="category" <?php echo ($edit_mode && $ad_data->position_type === 'category') ? 'selected' : ''; ?>>
                                指定分类
                            </option>
                        </select>
                    </div>
                </div>

                <!-- 具体位置选择 -->
                <div id="xb-adcustom-position-details" class="xb-adcustom-form-row" style="display: none;">
                    <div class="xb-adcustom-form-group">
                        <label class="xb-adcustom-label">选择具体位置</label>
                        
                        <!-- 文章选择 -->
                        <div class="xb-adcustom-position-select" id="xb-adcustom-single-select" style="display: none;">
                            <input type="text" name="position_value_single" class="xb-adcustom-input" 
                                   value="<?php echo ($edit_mode && $ad_data->position_type === 'single') ? esc_attr($edit_article_ids) : ''; ?>"
                                   placeholder="输入文章ID，多个用英文逗号分隔，如：1,2,3">
                            <p class="xb-adcustom-help-text">输入文章ID，多个文章用英文逗号分隔，如：1,2,3</p>
                        </div>
                        
                        <!-- 页面选择 -->
                        <div class="xb-adcustom-position-select" id="xb-adcustom-page-select" style="display: none;">
                            <input type="text" name="position_value_page" class="xb-adcustom-input" 
                                   value="<?php echo ($edit_mode && $ad_data->position_type === 'page') ? esc_attr($ad_data->position_value) : ''; ?>"
                                   placeholder="输入页面ID，多个用英文逗号分隔，如：1,2,3">
                            <p class="xb-adcustom-help-text">输入页面ID，多个页面用英文逗号分隔，如：1,2,3</p>
                            <div class="xb-adcustom-page-list">
                                <p><strong>可用页面：</strong></p>
                                <?php foreach ($pages as $page): ?>
                                    <span class="xb-adcustom-id-tag" onclick="xbAdCustomAddId('page', <?php echo $page->ID; ?>)">
                                        <?php echo esc_html($page->post_title); ?> (ID: <?php echo $page->ID; ?>)
                                    </span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <!-- 分类选择 -->
                        <div class="xb-adcustom-position-select" id="xb-adcustom-category-select" style="display: none;">
                            <input type="hidden" name="position_value_category" 
                                   value="<?php echo ($edit_mode && $ad_data->position_type === 'category') ? esc_attr($ad_data->position_value) : ''; ?>">
                            <div class="xb-adcustom-category-container">
                                <div class="xb-adcustom-selected-categories">
                                    <p><strong>已选择的分类：</strong></p>
                                    <div id="xb-adcustom-selected-cats" class="xb-adcustom-selected-cats"></div>
                                </div>
                                <div class="xb-adcustom-category-list">
                                    <p><strong>选择分类：</strong></p>
                                    <div class="xb-adcustom-category-scroll">
                                        <?php foreach ($categories as $category): ?>
                                            <label class="xb-adcustom-category-item">
                                                <input type="checkbox" value="<?php echo $category->term_id; ?>" 
                                                       onchange="xbAdCustomToggleCategory(<?php echo $category->term_id; ?>, '<?php echo esc_js($category->name); ?>', this.checked)">
                                                <span><?php echo esc_html($category->name); ?> (<?php echo $category->count; ?>)</span>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 嵌入位置选择（仅嵌入广告显示） -->
                <div id="xb-adcustom-embed-position" class="xb-adcustom-form-row" style="display: none;">
                    <div class="xb-adcustom-form-group">
                        <label class="xb-adcustom-label">嵌入位置</label>
                        <select name="embed_position" class="xb-adcustom-select">
                            <option value="content_start" <?php echo ($edit_mode && $edit_embed_position === 'content_start') ? 'selected' : ''; ?>>
                                文章开头
                            </option>
                            <option value="content_end" <?php echo ($edit_mode && $edit_embed_position === 'content_end') ? 'selected' : ''; ?>>
                                文章结尾
                            </option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="xb-adcustom-form-section">
                <h3 class="xb-adcustom-section-title">尺寸设置</h3>
                
                <div class="xb-adcustom-form-row">
                    <div class="xb-adcustom-form-group">
                        <label class="xb-adcustom-label">宽度 (px)</label>
                        <input type="number" name="width" id="xb-adcustom-width" class="xb-adcustom-input" 
                               value="<?php echo $edit_mode ? $ad_data->width : '300'; ?>" 
                               min="50" max="2000" placeholder="300">
                    </div>
                    
                    <div class="xb-adcustom-form-group">
                        <label class="xb-adcustom-label">高度 (px)</label>
                        <input type="number" name="height" id="xb-adcustom-height" class="xb-adcustom-input" 
                               value="<?php echo $edit_mode ? $ad_data->height : '250'; ?>" 
                               min="50" max="2000" placeholder="250">
                    </div>
                </div>
                
                <div class="xb-adcustom-size-presets">
                    <p class="xb-adcustom-label">常用尺寸：</p>
                    <button type="button" class="xb-adcustom-size-btn" data-width="300" data-height="250">300×250</button>
                    <button type="button" class="xb-adcustom-size-btn" data-width="728" data-height="90">728×90</button>
                    <button type="button" class="xb-adcustom-size-btn" data-width="320" data-height="50">320×50</button>
                    <button type="button" class="xb-adcustom-size-btn" data-width="160" data-height="600">160×600</button>
                    <button type="button" class="xb-adcustom-size-btn" data-width="336" data-height="280">336×280</button>
                    <button type="button" class="xb-adcustom-size-btn" data-width="970" data-height="250">970×250</button>
                </div>
            </div>

            <div class="xb-adcustom-form-section">
                <h3 class="xb-adcustom-section-title">状态设置</h3>
                
                <div class="xb-adcustom-form-row">
                    <div class="xb-adcustom-form-group">
                        <label class="xb-adcustom-checkbox-label">
                            <input type="checkbox" name="is_active" value="1" 
                                   <?php echo ($edit_mode && $ad_data->is_active) ? 'checked' : 'checked'; ?>>
                            <span class="xb-adcustom-checkmark"></span>
                            启用广告显示
                        </label>
                    </div>
                </div>
            </div>

            <div class="xb-adcustom-form-actions">
                <button type="submit" class="xb-adcustom-btn xb-adcustom-btn-primary xb-adcustom-btn-large">
                    <?php echo $edit_mode ? '更新广告' : '创建广告'; ?>
                </button>
                <a href="<?php echo admin_url('admin.php?page=xb-adcustom'); ?>" 
                   class="xb-adcustom-btn xb-adcustom-btn-secondary xb-adcustom-btn-large">
                    取消
                </a>
            </div>
        </form>
    </div>
</div>

<!-- 自定义提示框 -->
<div id="xb-adcustom-notification" class="xb-adcustom-notification">
    <div class="xb-adcustom-notification-content">
        <span class="xb-adcustom-notification-icon"></span>
        <span class="xb-adcustom-notification-message"></span>
        <button class="xb-adcustom-notification-close" onclick="xbAdCustomCloseNotification()">×</button>
    </div>
</div>

<script>
// 初始化编辑模式的分类选择
<?php if ($edit_mode && $ad_data->position_type === 'category' && $ad_data->position_value): ?>
document.addEventListener('DOMContentLoaded', function() {
    var selectedCats = '<?php echo esc_js($ad_data->position_value); ?>'.split(',');
    selectedCats.forEach(function(catId) {
        var checkbox = document.querySelector('input[type="checkbox"][value="' + catId.trim() + '"]');
        if (checkbox) {
            checkbox.checked = true;
            var categoryName = checkbox.nextElementSibling.textContent.split(' (')[0];
            xbAdCustomToggleCategory(catId.trim(), categoryName, true);
        }
    });
});
<?php endif; ?>

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    xbAdCustomInitAdmin();
});

/**
 * 初始化后台管理功能
 */
function xbAdCustomInitAdmin() {
    // 绑定表单提交事件
    var form = document.getElementById('xb-adcustom-form');
    if (form) {
        form.addEventListener('submit', xbAdCustomSaveAd);
    }
    
    // 绑定常用尺寸按钮点击事件
    var sizeButtons = document.querySelectorAll('.xb-adcustom-size-btn');
    sizeButtons.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            var width = this.getAttribute('data-width');
            var height = this.getAttribute('data-height');
            xbAdCustomSetSize(width, height);
        });
    });
    
    // 初始化位置选择
    var positionSelect = document.querySelector('select[name="position_type"]');
    var adTypeSelect = document.querySelector('select[name="ad_type"]');
    
    if (positionSelect) {
        xbAdCustomTogglePosition(positionSelect.value);
    }
    if (adTypeSelect) {
        xbAdCustomToggleAdType(adTypeSelect.value);
    }
}

/**
 * 保存广告
 */
function xbAdCustomSaveAd(e) {
    e.preventDefault();
    
    var form = e.target;
    var submitBtn = form.querySelector('button[type="submit"]');
    var originalText = submitBtn.textContent;
    
    // 显示加载状态
    submitBtn.textContent = '保存中...';
    submitBtn.disabled = true;
    
    // 收集表单数据
    var formData = new FormData();
    formData.append('action', 'xb_adcustom_save_ad');
    formData.append('nonce', '<?php echo wp_create_nonce('xb_adcustom_admin_nonce'); ?>');
    
    var adIdInput = form.querySelector('input[name="ad_id"]');
    if (adIdInput) {
        formData.append('ad_id', adIdInput.value);
    }
    
    formData.append('name', form.querySelector('input[name="name"]').value);
    formData.append('content', form.querySelector('textarea[name="content"]').value);
    formData.append('ad_type', form.querySelector('select[name="ad_type"]').value);
    formData.append('position_type', form.querySelector('select[name="position_type"]').value);
    formData.append('position_value', xbAdCustomGetPositionValue());
    formData.append('embed_position', xbAdCustomGetEmbedPosition());
    formData.append('width', form.querySelector('input[name="width"]').value);
    formData.append('height', form.querySelector('input[name="height"]').value);
    formData.append('device_type', form.querySelector('select[name="device_type"]').value);
    formData.append('is_active', form.querySelector('input[name="is_active"]').checked ? 1 : 0);
    
    // 发送AJAX请求
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '<?php echo admin_url('admin-ajax.php'); ?>', true);
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            // 恢复按钮状态
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            
            if (xhr.status === 200) {
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        xbAdCustomShowNotification('✅', response.data, 'success');
                        
                        // 如果是新建广告，跳转到列表页
                        if (!adIdInput || !adIdInput.value) {
                            setTimeout(function() {
                                window.location.href = '<?php echo admin_url('admin.php?page=xb-adcustom'); ?>';
                            }, 1500);
                        }
                    } else {
                        xbAdCustomShowNotification('❌', response.data || '保存失败', 'error');
                    }
                } catch (e) {
                    xbAdCustomShowNotification('❌', '响应解析失败', 'error');
                }
            } else {
                xbAdCustomShowNotification('❌', '网络错误，请重试', 'error');
            }
        }
    };
    
    xhr.send(formData);
}

/**
 * 获取位置值
 */
function xbAdCustomGetPositionValue() {
    var positionType = document.querySelector('select[name="position_type"]').value;
    
    switch (positionType) {
        case 'single':
            return document.querySelector('input[name="position_value_single"]').value;
        case 'page':
            return document.querySelector('input[name="position_value_page"]').value;
        case 'category':
            return document.querySelector('input[name="position_value_category"]').value;
        case 'all_single':
        case 'all':
        case 'home':
        default:
            return '';
    }
}

/**
 * 获取嵌入位置值
 */
function xbAdCustomGetEmbedPosition() {
    var adType = document.querySelector('select[name="ad_type"]').value;
    if (adType === 'embed') {
        return document.querySelector('select[name="embed_position"]').value;
    }
    return '';
}

/**
 * 切换广告类型
 */
function xbAdCustomToggleAdType(adType) {
    var embedPosition = document.getElementById('xb-adcustom-embed-position');
    var positionTypeSelect = document.querySelector('select[name="position_type"]');
    
    if (adType === 'embed') {
        embedPosition.style.display = 'flex';
        
        // 限制嵌入式广告只能选择文章相关位置
        var options = positionTypeSelect.querySelectorAll('option');
        options.forEach(function(option) {
            var value = option.value;
            if (value === 'all_single' || value === 'single') {
                option.style.display = 'block';
                option.disabled = false;
            } else {
                option.style.display = 'none';
                option.disabled = true;
            }
        });
        
        // 如果当前选择的不是文章相关位置，自动切换到全部文章页面
        var currentValue = positionTypeSelect.value;
        if (currentValue !== 'all_single' && currentValue !== 'single') {
            positionTypeSelect.value = 'all_single';
            xbAdCustomTogglePosition('all_single');
        }
    } else {
        embedPosition.style.display = 'none';
        
        // 恢复所有位置选项
        var options = positionTypeSelect.querySelectorAll('option');
        options.forEach(function(option) {
            option.style.display = 'block';
            option.disabled = false;
        });
    }
}

/**
 * 切换位置选择 - 优化显示逻辑
 */
function xbAdCustomTogglePosition(positionType) {
    var positionDetails = document.getElementById('xb-adcustom-position-details');
    var selects = document.querySelectorAll('.xb-adcustom-position-select');
    
    // 隐藏所有选择框
    selects.forEach(function(select) {
        select.style.display = 'none';
    });
    
    if (positionType === 'all' || positionType === 'home' || positionType === 'all_single') {
        positionDetails.style.display = 'none';
    } else {
        positionDetails.style.display = 'flex';
        var targetSelect = document.getElementById('xb-adcustom-' + positionType + '-select');
        if (targetSelect) {
            targetSelect.style.display = 'block';
        }
    }
}

/**
 * 设置尺寸
 */
function xbAdCustomSetSize(width, height) {
    var widthInput = document.getElementById('xb-adcustom-width');
    var heightInput = document.getElementById('xb-adcustom-height');
    
    if (widthInput) widthInput.value = width;
    if (heightInput) heightInput.value = height;
    
    // 添加视觉反馈
    var buttons = document.querySelectorAll('.xb-adcustom-size-btn');
    buttons.forEach(function(btn) {
        btn.classList.remove('active');
    });
    
    var activeBtn = document.querySelector('.xb-adcustom-size-btn[data-width="' + width + '"][data-height="' + height + '"]');
    if (activeBtn) {
        activeBtn.classList.add('active');
        setTimeout(function() {
            activeBtn.classList.remove('active');
        }, 1000);
    }
}

/**
 * 添加ID到输入框 - 新功能
 */
function xbAdCustomAddId(type, id) {
    var input = document.querySelector('input[name="position_value_' + type + '"]');
    if (input) {
        var currentValue = input.value.trim();
        var ids = currentValue ? currentValue.split(',') : [];
        
        // 检查是否已存在
        if (ids.indexOf(id.toString()) === -1) {
            ids.push(id.toString());
            input.value = ids.join(',');
        }
    }
}

/**
 * 切换分类选择 - 新功能
 */
function xbAdCustomToggleCategory(catId, catName, isChecked) {
    var hiddenInput = document.querySelector('input[name="position_value_category"]');
    var selectedContainer = document.getElementById('xb-adcustom-selected-cats');
    
    var selectedCats = hiddenInput.value ? hiddenInput.value.split(',') : [];
    
    if (isChecked) {
        // 添加分类
        if (selectedCats.indexOf(catId.toString()) === -1) {
            selectedCats.push(catId.toString());
            
            // 添加到显示区域
            var tag = document.createElement('span');
            tag.className = 'xb-adcustom-selected-cat';
            tag.setAttribute('data-id', catId);
            tag.innerHTML = catName + ' <button type="button" onclick="xbAdCustomRemoveCategory(' + catId + ')">×</button>';
            selectedContainer.appendChild(tag);
        }
    } else {
        // 移除分类
        selectedCats = selectedCats.filter(function(id) {
            return id !== catId.toString();
        });
        
        // 从显示区域移除
        var existingTag = selectedContainer.querySelector('[data-id="' + catId + '"]');
        if (existingTag) {
            existingTag.remove();
        }
    }
    
    hiddenInput.value = selectedCats.join(',');
}

/**
 * 移除分类 - 新功能
 */
function xbAdCustomRemoveCategory(catId) {
    // 取消复选框选中状态
    var checkbox = document.querySelector('input[type="checkbox"][value="' + catId + '"]');
    if (checkbox) {
        checkbox.checked = false;
    }
    
    // 触发切换事件
    xbAdCustomToggleCategory(catId, '', false);
}

/**
 * 显示通知
 */
function xbAdCustomShowNotification(icon, message, type) {
    var notification = document.getElementById('xb-adcustom-notification');
    var content = notification.querySelector('.xb-adcustom-notification-content');
    var iconEl = content.querySelector('.xb-adcustom-notification-icon');
    var messageEl = content.querySelector('.xb-adcustom-notification-message');
    
    // 设置内容
    iconEl.textContent = icon;
    messageEl.textContent = message;
    
    // 设置类型
    notification.className = 'xb-adcustom-notification ' + type;
    
    // 显示通知
    notification.classList.add('show');
    
    // 3秒后自动隐藏
    setTimeout(function() {
        notification.classList.remove('show');
    }, 3000);
}

/**
 * 关闭通知
 */
function xbAdCustomCloseNotification() {
    document.getElementById('xb-adcustom-notification').classList.remove('show');
}
</script>