<?php
// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$ads_table = $wpdb->prefix . XB_ADCUSTOM_TABLE_PREFIX . 'ads';

// 获取广告列表
$ads = $wpdb->get_results("SELECT * FROM $ads_table ORDER BY created_at DESC");
?>

<style>
/* 后台管理样式 - 内联CSS */
.xb-adcustom-admin-wrap * {
    box-sizing: border-box;
}

.xb-adcustom-admin-wrap {
    max-width: 1200px;
    margin: 20px 0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

.xb-adcustom-admin-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 30px;
    border-radius: 12px;
    margin-bottom: 30px;
    box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3);
}

.xb-adcustom-admin-title {
    font-size: 28px;
    font-weight: 700;
    margin: 0 0 8px 0;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.xb-adcustom-admin-subtitle {
    font-size: 16px;
    margin: 0;
    opacity: 0.9;
}

.xb-adcustom-admin-content {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.xb-adcustom-admin-toolbar {
    padding: 20px 30px;
    background: #f8f9fa;
    border-bottom: 1px solid #e9ecef;
}

.xb-adcustom-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s ease;
    line-height: 1.4;
}

.xb-adcustom-btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.xb-adcustom-btn-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    color: white;
}

.xb-adcustom-btn-secondary {
    background: #6c757d;
    color: white;
}

.xb-adcustom-btn-secondary:hover {
    background: #5a6268;
    color: white;
}

.xb-adcustom-btn-danger {
    background: #dc3545;
    color: white;
}

.xb-adcustom-btn-danger:hover {
    background: #c82333;
    color: white;
}

.xb-adcustom-btn-small {
    padding: 6px 12px;
    font-size: 12px;
}

.xb-adcustom-icon {
    font-size: 16px;
}

.xb-adcustom-admin-table-container {
    overflow-x: auto;
}

.xb-adcustom-admin-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
}

.xb-adcustom-admin-table th {
    background: #f8f9fa;
    padding: 15px 12px;
    text-align: left;
    font-weight: 600;
    color: #495057;
    border-bottom: 2px solid #dee2e6;
}

.xb-adcustom-admin-table td {
    padding: 15px 12px;
    border-bottom: 1px solid #dee2e6;
    vertical-align: middle;
}

.xb-adcustom-admin-table tr:hover {
    background: #f8f9fa;
}

.xb-adcustom-badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.xb-adcustom-badge-popup {
    background: #e3f2fd;
    color: #1976d2;
}

.xb-adcustom-badge-embed {
    background: #f3e5f5;
    color: #7b1fa2;
}

.xb-adcustom-switch {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 24px;
}

.xb-adcustom-switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.xb-adcustom-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: 0.3s;
    border-radius: 24px;
}

.xb-adcustom-slider:before {
    position: absolute;
    content: "";
    height: 18px;
    width: 18px;
    left: 3px;
    bottom: 3px;
    background-color: white;
    transition: 0.3s;
    border-radius: 50%;
}

input:checked + .xb-adcustom-slider {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

input:checked + .xb-adcustom-slider:before {
    transform: translateX(26px);
}

.xb-adcustom-actions {
    display: flex;
    gap: 8px;
}

.xb-adcustom-no-data {
    text-align: center;
    padding: 60px 20px;
}

.xb-adcustom-empty-state {
    color: #6c757d;
}

.xb-adcustom-empty-icon {
    font-size: 48px;
    display: block;
    margin-bottom: 16px;
}

.xb-adcustom-empty-state h3 {
    margin: 0 0 8px 0;
    font-size: 18px;
    color: #495057;
}

.xb-adcustom-empty-state p {
    margin: 0;
    font-size: 14px;
}

.xb-adcustom-notification {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 10000;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.xb-adcustom-notification.show {
    opacity: 1;
    visibility: visible;
}

.xb-adcustom-notification-content {
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    padding: 20px 25px;
    display: flex;
    align-items: center;
    gap: 15px;
    min-width: 300px;
    max-width: 500px;
}

.xb-adcustom-notification-icon {
    font-size: 24px;
}

.xb-adcustom-notification-message {
    flex: 1;
    font-size: 14px;
    color: #495057;
}

.xb-adcustom-notification-close {
    background: none;
    border: none;
    font-size: 20px;
    color: #6c757d;
    cursor: pointer;
    padding: 0;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.xb-adcustom-notification.success .xb-adcustom-notification-icon {
    color: #28a745;
}

.xb-adcustom-notification.error .xb-adcustom-notification-icon {
    color: #dc3545;
}

@media (max-width: 768px) {
    .xb-adcustom-admin-wrap {
        margin: 10px;
    }
    
    .xb-adcustom-admin-header {
        padding: 20px;
    }
    
    .xb-adcustom-admin-title {
        font-size: 24px;
    }
    
    .xb-adcustom-admin-table-container {
        overflow-x: scroll;
    }
    
    .xb-adcustom-actions {
        flex-direction: column;
    }
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.xb-adcustom-admin-wrap {
    animation: fadeInUp 0.5s ease;
}
</style>

<div class="xb-adcustom-admin-wrap">
    <div class="xb-adcustom-admin-header">
        <h1 class="xb-adcustom-admin-title">小半自定义广告</h1>
        <p class="xb-adcustom-admin-subtitle">管理您的自定义广告内容</p>
    </div>

    <div class="xb-adcustom-admin-content">
        <div class="xb-adcustom-admin-toolbar">
            <a href="<?php echo admin_url('admin.php?page=xb-adcustom-add'); ?>" class="xb-adcustom-btn xb-adcustom-btn-primary">
                <span class="xb-adcustom-icon">+</span>
                添加新广告
            </a>
        </div>

        <div class="xb-adcustom-admin-table-container">
            <table class="xb-adcustom-admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>广告名称</th>
                        <th>类型</th>
                        <th>位置</th>
                        <th>设备</th>
                        <th>尺寸</th>
                        <th>状态</th>
                        <th>创建时间</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($ads)): ?>
                        <tr>
                            <td colspan="9" class="xb-adcustom-no-data">
                                <div class="xb-adcustom-empty-state">
                                    <span class="xb-adcustom-empty-icon">📢</span>
                                    <h3>暂无广告</h3>
                                    <p>您还没有创建任何广告，点击上方按钮开始创建吧！</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($ads as $ad): ?>
                            <tr>
                                <td><?php echo $ad->id; ?></td>
                                <td>
                                    <strong><?php echo esc_html($ad->name); ?></strong>
                                </td>
                                <td>
                                    <span class="xb-adcustom-badge xb-adcustom-badge-<?php echo $ad->ad_type; ?>">
                                        <?php echo $ad->ad_type === 'popup' ? '弹窗' : '嵌入'; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php
                                    $position_labels = array(
                                        'all' => '全站',
                                        'home' => '首页',
                                        'all_single' => '全部文章页面',
                                        'single' => '指定文章',
                                        'page' => '指定页面',
                                        'category' => '指定分类'
                                    );
                                    echo $position_labels[$ad->position_type] ?? $ad->position_type;
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    $device_labels = array(
                                        'all' => '全部',
                                        'desktop' => '电脑',
                                        'mobile' => '手机'
                                    );
                                    echo $device_labels[$ad->device_type] ?? $ad->device_type;
                                    ?>
                                </td>
                                <td><?php echo $ad->width; ?>×<?php echo $ad->height; ?></td>
                                <td>
                                    <label class="xb-adcustom-switch">
                                        <input type="checkbox" <?php checked($ad->is_active, 1); ?> 
                                               onchange="xbAdCustomToggleAd(<?php echo $ad->id; ?>, this.checked)">
                                        <span class="xb-adcustom-slider"></span>
                                    </label>
                                </td>
                                <td><?php echo date('Y-m-d H:i', strtotime($ad->created_at)); ?></td>
                                <td>
                                    <div class="xb-adcustom-actions">
                                        <a href="<?php echo admin_url('admin.php?page=xb-adcustom-add&edit=' . $ad->id); ?>" 
                                           class="xb-adcustom-btn xb-adcustom-btn-small xb-adcustom-btn-secondary">
                                            编辑
                                        </a>
                                        <button onclick="xbAdCustomDeleteAd(<?php echo $ad->id; ?>)" 
                                                class="xb-adcustom-btn xb-adcustom-btn-small xb-adcustom-btn-danger">
                                            删除
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- 自定义提示框 -->
<div id="xb-adcustom-notification" class="xb-adcustom-notification">
    <div class="xb-adcustom-notification-content">
        <span class="xb-adcustom-notification-icon"></span>
        <span class="xb-adcustom-notification-message"></span>
        <button class="xb-adcustom-notification-close" onclick="xbAdCustomCloseNotification()">×</button>
    </div>
</div>

<script>
/**
 * 删除广告
 */
function xbAdCustomDeleteAd(adId) {
    if (!confirm('确定要删除这个广告吗？此操作不可撤销。')) {
        return;
    }
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '<?php echo admin_url('admin-ajax.php'); ?>', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        xbAdCustomShowNotification('✅', response.data, 'success');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        xbAdCustomShowNotification('❌', response.data || '删除失败', 'error');
                    }
                } catch (e) {
                    xbAdCustomShowNotification('❌', '响应解析失败', 'error');
                }
            } else {
                xbAdCustomShowNotification('❌', '网络错误，请重试', 'error');
            }
        }
    };
    
    var data = 'action=xb_adcustom_delete_ad&nonce=<?php echo wp_create_nonce('xb_adcustom_admin_nonce'); ?>&ad_id=' + adId;
    xhr.send(data);
}

/**
 * 切换广告状态
 */
function xbAdCustomToggleAd(adId, isActive) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '<?php echo admin_url('admin-ajax.php'); ?>', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        xbAdCustomShowNotification('✅', response.data, 'success');
                    } else {
                        xbAdCustomShowNotification('❌', response.data || '状态更新失败', 'error');
                        // 恢复开关状态
                        var checkbox = document.querySelector('input[onchange*="' + adId + '"]');
                        if (checkbox) {
                            checkbox.checked = !isActive;
                        }
                    }
                } catch (e) {
                    xbAdCustomShowNotification('❌', '响应解析失败', 'error');
                    // 恢复开关状态
                    var checkbox = document.querySelector('input[onchange*="' + adId + '"]');
                    if (checkbox) {
                        checkbox.checked = !isActive;
                    }
                }
            } else {
                xbAdCustomShowNotification('❌', '网络错误，请重试', 'error');
                // 恢复开关状态
                var checkbox = document.querySelector('input[onchange*="' + adId + '"]');
                if (checkbox) {
                    checkbox.checked = !isActive;
                }
            }
        }
    };
    
    var data = 'action=xb_adcustom_toggle_ad&nonce=<?php echo wp_create_nonce('xb_adcustom_admin_nonce'); ?>&ad_id=' + adId + '&is_active=' + (isActive ? 1 : 0);
    xhr.send(data);
}

/**
 * 显示通知
 */
function xbAdCustomShowNotification(icon, message, type) {
    var notification = document.getElementById('xb-adcustom-notification');
    var content = notification.querySelector('.xb-adcustom-notification-content');
    var iconEl = content.querySelector('.xb-adcustom-notification-icon');
    var messageEl = content.querySelector('.xb-adcustom-notification-message');
    
    // 设置内容
    iconEl.textContent = icon;
    messageEl.textContent = message;
    
    // 设置类型
    notification.className = 'xb-adcustom-notification ' + type;
    
    // 显示通知
    notification.classList.add('show');
    
    // 3秒后自动隐藏
    setTimeout(function() {
        notification.classList.remove('show');
    }, 3000);
}

/**
 * 关闭通知
 */
function xbAdCustomCloseNotification() {
    document.getElementById('xb-adcustom-notification').classList.remove('show');
}
</script>