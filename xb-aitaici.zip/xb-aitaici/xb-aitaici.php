<?php
/*
Plugin Name: AI经典台词出处
Description: 基于第三方API的WordPress插件，用于查询经典台词的影视剧出处
Version: 1.0.0
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 创建数据库表
 */
function xb_aitaici_create_database(): void {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_aitaici_records';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        usage_date date NOT NULL,
        total_count int DEFAULT 0,
        success_count int DEFAULT 0,
        custom_limit int DEFAULT NULL,
        input_content text NOT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        INDEX user_date_index (user_id, usage_date)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

/**
 * 创建前台页面
 */
function xb_aitaici_create_frontend_page(): void {
    $pages = get_posts([
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_aitaici_shortcode]',
        'numberposts' => 1,
    ]);

    if (empty($pages)) {
        wp_insert_post([
            'post_title'    => 'AI经典台词出处',
            'post_name'     => 'ai-taici-origin',
            'post_content'  => '[xb_aitaici_shortcode]',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        ]);
    }
}

/**
 * 加载前台资源
 */
function xb_aitaici_load_resources(): void {
    wp_enqueue_script('jquery');

    $css_path = plugin_dir_path(__FILE__) . 'xb-aitaici.css';
    if (file_exists($css_path)) {
        wp_enqueue_style(
            'xb_aitaici_styles',
            plugin_dir_url(__FILE__) . 'xb-aitaici.css',
            [],
            '1.0.0'
        );
    }

    $js_path = plugin_dir_path(__FILE__) . 'xb-aitaici.js';
    if (file_exists($js_path)) {
        wp_enqueue_script(
            'xb_aitaici_script',
            plugin_dir_url(__FILE__) . 'xb-aitaici.js',
            ['jquery'],
            '1.0.0',
            true
        );
    }

    $models = array_map('trim', explode(',', get_option('xb_aitaici_models', 'qwen-plus')));
    wp_localize_script('xb_aitaici_script', 'XBAitaiciData', [
        'rest_url' => esc_url_raw(rest_url('xb_aitaici/v1/query')),
        'nonce' => wp_create_nonce('wp_rest'),
        'ajax_url' => admin_url('admin-ajax.php'),
        'forbidden_words' => array_filter(array_map('trim', explode(',', get_option('xb_aitaici_forbidden_words', '')))),
        'default_model' => !empty($models) ? $models[0] : 'qwen-plus',
    ]);
}

add_action('wp_enqueue_scripts', function (): void {
    global $post;
    if (is_a($post, 'WP_Post') && (has_shortcode($post->post_content, 'xb_aitaici_shortcode') || is_page('ai-taici-origin'))) {
        xb_aitaici_load_resources();
    }
});

register_activation_hook(__FILE__, 'xb_aitaici_create_database');
register_activation_hook(__FILE__, 'xb_aitaici_create_frontend_page');

/**
 * 处理台词查询请求
 */
function xb_aitaici_query_handler(WP_REST_Request $request): void {
    global $wpdb;
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = (int) get_option('xb_aitaici_daily_limit', 10);

    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT total_count, success_count, custom_limit FROM {$wpdb->prefix}xb_aitaici_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));

    $total_count = $usage_data ? (int) $usage_data->total_count : 0;
    $success_count = $usage_data ? (int) $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? (int) $usage_data->custom_limit : $default_limit;

    if ($success_count >= $user_limit) {
        echo "data: " . wp_json_encode(['error' => '今日使用次数已达上限']) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    $forbidden_words = array_filter(array_map('trim', explode(',', get_option('xb_aitaici_forbidden_words', ''))));
    $input_data = sanitize_text_field($request->get_param('data') ?? '');

    if (strlen($input_data) > 1000) {
        echo "data: " . wp_json_encode(['error' => '输入内容过长，请限制在1000字以内']) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    if (!empty($forbidden_words)) {
        foreach ($forbidden_words as $word) {
            if (stripos($input_data, $word) !== false) {
                echo "data: " . wp_json_encode(['error' => '输入内容包含违规词“' . esc_html($word) . '”，请重新输入']) . "\n\n";
                ob_flush();
                flush();
                exit;
            }
        }
    }

    $enable_search = filter_var($request->get_param('enable_search'), FILTER_VALIDATE_BOOLEAN);
    $prompt = "你是一个专业的影视台词查询助手，任务是根据用户提供的台词，准确指出其出处（影视剧名称）并提供简短介绍。请严格遵循以下要求：\n";
    $prompt .= "1. 针对用户输入的台词：'{$input_data}'，明确指出其出处（电影、电视剧或其他影视作品的名称）。\n";
    $prompt .= "2. 如果台词出处未知，返回‘未找到该台词的出处’。\n";
    $prompt .= "3. 回复格式为：\n";
    $prompt .= "出处：影视剧名称\n";
    $prompt .= "介绍：简短介绍该影视剧（50-100字）\n\n";
    $prompt .= "4. 确保信息准确，语言简洁。\n";
    if ($enable_search) {
        $prompt .= "5. 通过全网搜索确认台词出处，确保结果准确。\n";
    }
    $prompt .= "用户输入的台词：{$input_data}\n";
    $prompt .= "请按照指定格式返回结果，仅返回出处和介绍，其他内容不要输出。";

    $models = array_map('trim', explode(',', get_option('xb_aitaici_models', 'qwen-plus')));
    $enable_model_select = get_option('xb_aitaici_enable_model_select', '0');
    $model = sanitize_text_field($request->get_param('model') ?? '');

    if (!$enable_model_select || empty($model) || !in_array($model, $models)) {
        $model = !empty($models) ? $models[0] : 'qwen-plus';
    }

    $api_url = get_option('xb_aitaici_api_url', '');
    $api_key = get_option('xb_aitaici_api_key', '');

    if (empty($api_url) || empty($api_key)) {
        echo "data: " . wp_json_encode(['error' => 'API地址或密钥未配置']) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    if ($usage_data) {
        $wpdb->update(
            $wpdb->prefix . 'xb_aitaici_records',
            [
                'total_count' => $total_count + 1,
                'input_content' => $input_data,
                'created_at' => current_time('mysql'),
            ],
            ['user_id' => $user_id, 'usage_date' => $today]
        );
    } else {
        $wpdb->insert(
            $wpdb->prefix . 'xb_aitaici_records',
            [
                'user_id' => $user_id,
                'usage_date' => $today,
                'total_count' => 1,
                'success_count' => 0,
                'input_content' => $input_data,
                'created_at' => current_time('mysql'),
            ]
        );
    }

    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no');

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $api_url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HEADER => false,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $api_key,
            'Content-Type: application/json',
            'Accept: text/event-stream',
        ],
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => wp_json_encode([
            'model' => $model,
            'messages' => [
                ['role' => 'system', 'content' => 'You are a helpful assistant.'],
                ['role' => 'user', 'content' => $prompt],
            ],
            'stream' => true,
            'enable_search' => $enable_search,
        ]),
        CURLOPT_WRITEFUNCTION => function ($ch, string $data) use ($user_id, $today, $success_count): int {
            global $wpdb;
            static $has_content = false;

            $lines = explode("\n", $data);
            foreach ($lines as $line) {
                $line = trim($line);
                if (empty($line)) {
                    continue;
                }

                if (strpos($line, 'data: ') === 0) {
                    $json_data = trim(substr($line, 6));
                    if ($json_data === '[DONE]') {
                        if ($has_content) {
                            $wpdb->update(
                                $wpdb->prefix . 'xb_aitaici_records',
                                ['success_count' => $success_count + 1],
                                ['user_id' => $user_id, 'usage_date' => $today]
                            );
                        }
                        echo "data: [DONE]\n\n";
                        ob_flush();
                        flush();
                        return strlen($data);
                    }

                    $parsed_data = json_decode($json_data, true);
                    if (json_last_error() !== JSON_ERROR_NONE) {
                        error_log('JSON 解析错误: ' . json_last_error_msg() . ' - 数据: ' . $json_data);
                        continue;
                    }

                    if (isset($parsed_data['choices'][0]['delta']['content'])) {
                        $has_content = true;
                        echo "data: " . wp_json_encode(['content' => $parsed_data['choices'][0]['delta']['content']]) . "\n\n";
                        ob_flush();
                        flush();
                    } elseif (isset($parsed_data['error'])) {
                        echo "data: " . wp_json_encode(['error' => $parsed_data['error']['message']]) . "\n\n";
                        ob_flush();
                        flush();
                        return strlen($data);
                    }
                }
            }
            return strlen($data);
        }
    ]);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        echo "data: " . wp_json_encode(['error' => 'API请求失败: ' . $error]) . "\n\n";
        ob_flush();
        flush();
    } elseif (!$has_content) {
        echo "data: " . wp_json_encode(['error' => '查询失败，未收到有效内容']) . "\n\n";
        ob_flush();
        flush();
    }

    curl_close($ch);
    exit;
}

add_action('rest_api_init', function (): void {
    $namespace = 'xb_aitaici/v1';
    register_rest_route($namespace, '/query', [
        'methods' => 'POST',
        'callback' => 'xb_aitaici_query_handler',
        'permission_callback' => function (WP_REST_Request $request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_not_logged_in', '请先登录', ['status' => 401]);
            }
            $nonce = $request->get_header('X-WP-Nonce');
            if (!wp_verify_nonce($nonce, 'wp_rest')) {
                return new WP_Error('rest_forbidden', 'Nonce验证失败', ['status' => 403]);
            }
            return true;
        },
    ]);

    register_rest_route($namespace, '/usage', [
        'methods' => 'GET',
        'callback' => 'xb_aitaici_get_usage',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ]);
});

/**
 * 获取用户使用情况
 */
function xb_aitaici_get_usage(WP_REST_Request $request): array {
    global $wpdb;
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = (int) get_option('xb_aitaici_daily_limit', 10);

    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT total_count, success_count, custom_limit FROM {$wpdb->prefix}xb_aitaici_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));

    $total_count = $usage_data ? (int) $usage_data->total_count : 0;
    $success_count = $usage_data ? (int) $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? (int) $usage_data->custom_limit : $default_limit;

    return [
        'remaining' => max(0, $user_limit - $success_count),
        'limit' => $user_limit,
        'total_count' => $total_count,
        'success_count' => $success_count,
    ];
}

/**
 * 添加后台菜单
 */
function xb_aitaici_admin_menu(): void {
    add_menu_page(
        'AI经典台词出处',
        'AI台词出处',
        'manage_options',
        'xb-aitaici',
        'xb_aitaici_settings_page',
        'dashicons-format-quote'
    );
    add_submenu_page(
        'xb-aitaici',
        '用户记录',
        '用户记录',
        'manage_options',
        'xb-aitaici-user-records',
        'xb_aitaici_user_records_page'
    );
}
add_action('admin_menu', 'xb_aitaici_admin_menu');

/**
 * 注册设置
 */
function xb_aitaici_register_settings(): void {
    register_setting('xb_aitaici_settings', 'xb_aitaici_api_url');
    register_setting('xb_aitaici_settings', 'xb_aitaici_models');
    register_setting('xb_aitaici_settings', 'xb_aitaici_api_key');
    register_setting('xb_aitaici_settings', 'xb_aitaici_daily_limit');
    register_setting('xb_aitaici_settings', 'xb_aitaici_forbidden_words');
    register_setting('xb_aitaici_settings', 'xb_aitaici_ad_content');
    register_setting('xb_aitaici_settings', 'xb_aitaici_enable_search');
    register_setting('xb_aitaici_settings', 'xb_aitaici_enable_model_select');
    register_setting('xb_aitaici_settings', 'xb_aitaici_enable_usage_display');

    add_settings_section(
        'xb_aitaici_main_section',
        'API设置',
        null,
        'xb_aitaici_settings'
    );

    add_settings_section(
        'xb_aitaici_content_section',
        '内容设置',
        null,
        'xb_aitaici_settings'
    );

    add_settings_field(
        'xb_aitaici_api_url',
        'API地址',
        'xb_aitaici_api_url_field',
        'xb_aitaici_settings',
        'xb_aitaici_main_section'
    );

    add_settings_field(
        'xb_aitaici_models',
        'AI模型',
        'xb_aitaici_models_field',
        'xb_aitaici_settings',
        'xb_aitaici_main_section'
    );

    add_settings_field(
        'xb_aitaici_api_key',
        'API密钥',
        'xb_aitaici_api_key_field',
        'xb_aitaici_settings',
        'xb_aitaici_main_section'
    );

    add_settings_field(
        'xb_aitaici_daily_limit',
        '每日使用限制',
        'xb_aitaici_daily_limit_field',
        'xb_aitaici_settings',
        'xb_aitaici_main_section'
    );

    add_settings_field(
        'xb_aitaici_enable_search',
        '启用联网搜索',
        'xb_aitaici_enable_search_field',
        'xb_aitaici_settings',
        'xb_aitaici_main_section'
    );

    add_settings_field(
        'xb_aitaici_enable_model_select',
        '启用前台模型选择',
        'xb_aitaici_enable_model_select_field',
        'xb_aitaici_settings',
        'xb_aitaici_main_section'
    );

    add_settings_field(
        'xb_aitaici_enable_usage_display',
        '启用前台使用次数显示',
        'xb_aitaici_enable_usage_display_field',
        'xb_aitaici_settings',
        'xb_aitaici_main_section'
    );

    add_settings_field(
        'xb_aitaici_forbidden_words',
        '违规词',
        'xb_aitaici_forbidden_words_field',
        'xb_aitaici_settings',
        'xb_aitaici_content_section'
    );

    add_settings_field(
        'xb_aitaici_ad_content',
        '广告内容 (HTML)',
        'xb_aitaici_ad_content_field',
        'xb_aitaici_settings',
        'xb_aitaici_content_section'
    );
}
add_action('admin_init', 'xb_aitaici_register_settings');

/**
 * 设置字段回调函数
 */
function xb_aitaici_api_url_field(): void {
    $value = get_option('xb_aitaici_api_url', '');
    echo '<input type="text" name="xb_aitaici_api_url" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入API地址 (如 https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions)</p>';
}

function xb_aitaici_models_field(): void {
    $value = get_option('xb_aitaici_models', 'qwen-plus');
    echo '<input type="text" name="xb_aitaici_models" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入AI模型，用逗号分隔 (如 qwen-plus,qwen-turbo)</p>';
}

function xb_aitaici_api_key_field(): void {
    $value = get_option('xb_aitaici_api_key', '');
    echo '<input type="text" name="xb_aitaici_api_key" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入您的API密钥</p>';
}

function xb_aitaici_daily_limit_field(): void {
    $value = get_option('xb_aitaici_daily_limit', '10');
    echo '<input type="number" name="xb_aitaici_daily_limit" value="' . esc_attr($value) . '" min="1" />';
    echo '<p class="description">设置用户默认每日使用限制</p>';
}

function xb_aitaici_enable_search_field(): void {
    $value = get_option('xb_aitaici_enable_search', '0');
    echo '<input type="checkbox" name="xb_aitaici_enable_search" value="1"' . checked(1, $value, false) . ' />';
    echo '<p class="description">启用后，前台将显示联网搜索开关，用户可选择是否联网搜索</p>';
}

function xb_aitaici_enable_model_select_field(): void {
    $value = get_option('xb_aitaici_enable_model_select', '0');
    echo '<input type="checkbox" name="xb_aitaici_enable_model_select" value="1"' . checked(1, $value, false) . ' />';
    echo '<p class="description">启用后，前台将显示模型选择下拉框</p>';
}

function xb_aitaici_enable_usage_display_field(): void {
    $value = get_option('xb_aitaici_enable_usage_display', '0');
    echo '<input type="checkbox" name="xb_aitaici_enable_usage_display" value="1"' . checked(1, $value, false) . ' />';
    echo '<p class="description">启用后，前台将显示实时使用次数</p>';
}

function xb_aitaici_forbidden_words_field(): void {
    $value = get_option('xb_aitaici_forbidden_words', '');
    echo '<textarea name="xb_aitaici_forbidden_words" rows="5" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">输入违规词，用逗号分隔</p>';
}

function xb_aitaici_ad_content_field(): void {
    $value = get_option('xb_aitaici_ad_content', '');
    echo '<textarea name="xb_aitaici_ad_content" rows="5" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">输入广告内容 (支持HTML，图片建议尺寸：宽度不超过600px，高度不超过400px)</p>';
}

/**
 * 设置页面
 */
function xb_aitaici_settings_page(): void {
    ?>
    <div class="wrap">
        <h1>AI经典台词出处设置</h1>
        <?php
        if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {
            echo '<div id="setting-saved-notice" class="notice notice-success is-dismissible"><p>设置保存成功！</p></div>';
            echo '<script>
                setTimeout(function() {
                    jQuery("#setting-saved-notice").fadeOut();
                }, 3000);
            </script>';
        }
        ?>
        <form method="post" action="options.php">
            <?php
            settings_fields('xb_aitaici_settings');
            do_settings_sections('xb_aitaici_settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

/**
 * 用户记录页面
 */
function xb_aitaici_user_records_page(): void {
    global $wpdb;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : (isset($_GET['user_id']) ? intval($_GET['user_id']) : 0);
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $per_page = 20;

    $total_usage = $wpdb->get_var("SELECT SUM(total_count) FROM {$wpdb->prefix}xb_aitaici_records");
    $total_success = $wpdb->get_var("SELECT SUM(success_count) FROM {$wpdb->prefix}xb_aitaici_records");

    $today = current_time('Y-m-d');
    $today_total_usage = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(total_count) FROM {$wpdb->prefix}xb_aitaici_records WHERE usage_date = %s",
        $today
    ));
    $today_total_success = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(success_count) FROM {$wpdb->prefix}xb_aitaici_records WHERE usage_date = %s",
        $today
    ));

    $total_all_records = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}xb_aitaici_records");
    $all_records = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}xb_aitaici_records 
        ORDER BY created_at DESC 
        LIMIT %d OFFSET %d",
        $per_page,
        ($paged - 1) * $per_page
    ));

    ?>
    <div class="wrap">
        <h1>用户记录</h1>
        <h2>使用统计</h2>
        <p>网站总共尝试次数：<?php echo esc_html($total_usage ?: 0); ?> 次，成功次数：<?php echo esc_html($total_success ?: 0); ?> 次</p>
        <p>今日总共尝试次数：<?php echo esc_html($today_total_usage ?: 0); ?> 次，成功次数：<?php echo esc_html($today_total_success ?: 0); ?> 次</p>

        <h2>所有用户记录</h2>
        <?php
        if ($all_records) {
            echo '<table class="wp-list-table widefat fixed striped" id="all-records-table">';
            echo '<thead><tr><th>用户ID</th><th>日期</th><th>尝试次数</th><th>成功次数</th><th>自定义限制</th><th>输入内容</th><th>创建时间</th><th>操作</th></tr></thead>';
            echo '<tbody>';
            foreach ($all_records as $record) {
                echo '<tr>';
                echo '<td>' . esc_html($record->user_id) . '</td>';
                echo '<td>' . esc_html($record->usage_date) . '</td>';
                echo '<td>' . esc_html($record->total_count) . '</td>';
                echo '<td>' . esc_html($record->success_count) . '</td>';
                echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
                echo '<td>' . esc_html($record->input_content ?: '无记录') . '</td>';
                echo '<td>' . esc_html($record->created_at) . '</td>';
                echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
            echo '<button id="delete-all-records">删除全部记录</button>';

            $total_pages = ceil($total_all_records / $per_page);
            if ($total_pages > 1) {
                echo '<div id="all-pagination">';
                for ($i = 1; $i <= $total_pages; $i++) {
                    printf('<a href="#" class="page-number%s" data-page="%d">%d</a>', $i === $paged ? ' active' : '', $i, $i);
                }
                echo '</div>';
            }
        } else {
            echo '<p>暂无用户记录。</p>';
        }
        ?>
        
        <h2>查询指定用户</h2>
        <form method="post">
            <input type="number" name="user_id" placeholder="输入用户ID" value="<?php echo esc_attr($user_id); ?>">
            <input type=" simultaneously="submit" value="搜索" class="button">
        </form>
        <?php
        if ($user_id) {
            $user_total_usage = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(total_count) FROM {$wpdb->prefix}xb_aitaici_records WHERE user_id = %d",
                $user_id
            ));
            $user_total_success = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(success_count) FROM {$wpdb->prefix}xb_aitaici_records WHERE user_id = %d",
                $user_id
            ));

            $user_today_usage = $wpdb->get_var($wpdb->prepare(
                "SELECT total_count FROM {$wpdb->prefix}xb_aitaici_records WHERE user_id = %d AND usage_date = %s",
                $user_id,
                $today
            ));
            $user_today_success = $wpdb->get_var($wpdb->prepare(
                "SELECT success_count FROM {$wpdb->prefix}xb_aitaici_records WHERE user_id = %d AND usage_date = %s",
                $user_id,
                $today
            ));

            $total_records = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}xb_aitaici_records WHERE user_id = %d",
                $user_id
            ));

            $records = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}xb_aitaici_records 
                WHERE user_id = %d 
                ORDER BY created_at DESC 
                LIMIT %d OFFSET %d",
                $user_id,
                $per_page,
                ($paged - 1) * $per_page
            ));

            echo '<h2>用户记录 (ID: ' . esc_html($user_id) . ')</h2>';
            echo '<p>用户总共尝试次数：' . esc_html($user_total_usage ?: 0) . ' 次，成功次数：' . esc_html($user_total_success ?: 0) . ' 次</p>';
            echo '<p>用户今日尝试次数：' . esc_html($user_today_usage ?: 0) . ' 次，成功次数：' . esc_html($user_today_success ?: 0) . ' 次</p>';

            if ($records) {
                echo '<table class="wp-list-table widefat fixed striped" id="user-records-table">';
                echo '<thead><tr><th>日期</th><th>尝试次数</th><th>成功次数</th><th>自定义限制</th><th>输入内容</th><th>操作</th></tr></thead>';
                echo '<tbody>';
                foreach ($records as $record) {
                    echo '<tr>';
                    echo '<td>' . esc_html($record->usage_date) . '</td>';
                    echo '<td>' . esc_html($record->total_count) . '</td>';
                    echo '<td>' . esc_html($record->success_count) . '</td>';
                    echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
                    echo '<td>' . esc_html($record->input_content ?: '无记录') . '</td>';
                    echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
                echo '<button id="delete-all-user-records" data-user-id="' . esc_attr($user_id) . '">删除全部用户记录</button>';

                $total_pages = ceil($total_records / $per_page);
                if ($total_pages > 1) {
                    echo '<div id="pagination">';
                    for ($i = 1; $i <= $total_pages; $i++) {
                        printf('<a href="#" class="page-number%s" data-page="%d">%d</a>', $i === $paged ? ' active' : '', $i, $i);
                    }
                    echo '</div>';
                }
            } else {
                echo '<p>未找到该用户记录。</p>';
            }
            
            ?>
            <form method="post">
                <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="number" name="custom_limit" placeholder="自定义每日限制">
                <input type="submit" name="set_limit" value="设置自定义限制" class="button">
                <input type="submit" name="reset_limit" value="恢复默认" class="button">
            </form>
            <?php
        }
        ?>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $('#pagination .page-number').on('click', function(e) {
            e.preventDefault();
            if (!$(this).hasClass('active')) {
                var user_id = $('input[name="user_id"]').val();
                var page = $(this).data('page');
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_aitaici_load_user_records',
                        user_id: user_id,
                        paged: page
                    },
                    success: function(response) {
                        $('#user-records-table tbody').html(response.data.records);
                        $('#pagination .page-number').removeClass('active');
                        $('#pagination .page-number[data-page="' + page + '"]').addClass('active');
                    }
                });
            }
        });

        $('#all-pagination .page-number').on('click', function(e) {
            e.preventDefault();
            if (!$(this).hasClass('active')) {
                var page = $(this).data('page');
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_aitaici_load_all_records',
                        paged: page
                    },
                    success: function(response) {
                        $('#all-records-table tbody').html(response.data.records);
                        $('#all-pagination .page-number').removeClass('active');
                        $('#all-pagination .page-number[data-page="' + page + '"]').addClass('active');
                    }
                });
            }
        });

        $('.delete-record').on('click', function(e) {
            e.preventDefault();
            var record_id = $(this).data('id');
            if (confirm('确定删除此记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_aitaici_delete_record',
                        record_id: record_id
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#all-records-table tr').each(function() {
                                if ($(this).find('.delete-record').data('id') === record_id) {
                                    $(this).remove();
                                }
                            });
                            $('#user-records-table tr').each(function() {
                                if ($(this).find('.delete-record').data('id') === record_id) {
                                    $(this).remove();
                                }
                            });
                        }
                    }
                });
            }
        });

        $('#delete-all-records').on('click', function(e) {
            e.preventDefault();
            if (confirm('确定删除所有记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_aitaici_delete_all_records'
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#all-records-table tbody').empty();
                        }
                    }
                });
            }
        });

        $('#delete-all-user-records').on('click', function(e) {
            e.preventDefault();
            var user_id = $(this).data('user-id');
            if (confirm('确定删除该用户的所有记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_aitaici_delete_user_records',
                        user_id: user_id
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#user-records-table tbody').empty();
                        }
                    }
                });
            }
        });
    });
    </script>
    <?php
}

/**
 * AJAX 获取用户记录
 */
add_action('wp_ajax_xb_aitaici_load_user_records', function (): void {
    global $wpdb;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $paged = isset($_POST['paged']) ? max(1, intval($_POST['paged'])) : 1;
    $per_page = 20;

    if ($user_id) {
        $records = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}xb_aitaici_records 
            WHERE user_id = %d 
            ORDER BY created_at DESC 
            LIMIT %d OFFSET %d",
            $user_id,
            $per_page,
            ($paged - 1) * $per_page
        ));

        ob_start();
        foreach ($records as $record) {
            echo '<tr>';
            echo '<td>' . esc_html($record->usage_date) . '</td>';
            echo '<td>' . esc_html($record->total_count) . '</td>';
            echo '<td>' . esc_html($record->success_count) . '</td>';
            echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
            echo '<td>' . esc_html($record->input_content ?: '无记录') . '</td>';
            echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
            echo '</tr>';
        }
        $html = ob_get_clean();

        wp_send_json_success(['records' => $html]);
    }
    wp_die();
});

/**
 * AJAX 获取所有用户记录
 */
add_action('wp_ajax_xb_aitaici_load_all_records', function (): void {
    global $wpdb;
    $paged = isset($_POST['paged']) ? max(1, intval($_POST['paged'])) : 1;
    $per_page = 20;

    $records = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}xb_aitaici_records 
        ORDER BY created_at DESC 
        LIMIT %d OFFSET %d",
        $per_page,
        ($paged - 1) * $per_page
    ));

    ob_start();
    foreach ($records as $record) {
        echo '<tr>';
        echo '<td>' . esc_html($record->user_id) . '</td>';
        echo '<td>' . esc_html($record->usage_date) . '</td>';
        echo '<td>' . esc_html($record->total_count) . '</td>';
        echo '<td>' . esc_html($record->success_count) . '</td>';
        echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
        echo '<td>' . esc_html($record->input_content ?: '无记录') . '</td>';
        echo '<td>' . esc_html($record->created_at) . '</td>';
        echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
        echo '</tr>';
    }
    $html = ob_get_clean();

    wp_send_json_success(['records' => $html]);
    wp_die();
});

/**
 * AJAX 删除单条记录
 */
function xb_aitaici_delete_record(): void {
    global $wpdb;
    $record_id = isset($_POST['record_id']) ? intval($_POST['record_id']) : 0;

    if ($record_id) {
        $wpdb->delete($wpdb->prefix . 'xb_aitaici_records', ['id' => $record_id]);
        wp_send_json_success();
    }

    wp_send_json_error();
}
add_action('wp_ajax_xb_aitaici_delete_record', 'xb_aitaici_delete_record');

/**
 * AJAX 删除所有记录
 */
function xb_aitaici_delete_all_records(): void {
    global $wpdb;

    $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}xb_aitaici_records");
    wp_send_json_success();
}
add_action('wp_ajax_xb_aitaici_delete_all_records', 'xb_aitaici_delete_all_records');

/**
 * AJAX 删除用户所有记录
 */
function xb_aitaici_delete_user_records(): void {
    global $wpdb;

    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;

    if ($user_id) {
        $wpdb->delete($wpdb->prefix . 'xb_aitaici_records', ['user_id' => $user_id]);
        wp_send_json_success();
    }

    wp_send_json_error();
}
add_action('wp_ajax_xb_aitaici_delete_user_records', 'xb_aitaici_delete_user_records');

/**
 * 前台短代码
 */
function xb_aitaici_shortcode(): string {
    global $wpdb;
    $ad_content = get_option('xb_aitaici_ad_content', '');
    $enable_search = get_option('xb_aitaici_enable_search', '0');
    $enable_model_select = get_option('xb_aitaici_enable_model_select', '0');
    $enable_usage_display = get_option('xb_aitaici_enable_usage_display', '0');

    if (!is_user_logged_in()) {
        ob_start();
        ?>
        <div class="xb_aitaici_container">
            <div class="xb_aitaici_page_title">AI经典台词出处</div>
            <div class="xb_aitaici_login_notice">
                请先登录才能使用台词查询助手。
                <button class="xb_aitaici_quick_login_button">快速登录</button>
            </div>
            <?php if ($ad_content): ?>
            <div class="xb_aitaici_ad">
                <?php echo wp_kses_post($ad_content); ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = (int) get_option('xb_aitaici_daily_limit', 10);
    
    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT total_count, success_count, custom_limit FROM {$wpdb->prefix}xb_aitaici_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));
    
    $success_count = $usage_data ? (int) $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? (int) $usage_data->custom_limit : $default_limit;
    $remaining_usage = $user_limit - $success_count;
    
    if ($remaining_usage <= 0) {
        return '<div class="xb_aitaici_container"><div class="xb_aitaici_limit_notice">今日使用次数已达上限，请明天再来。</div></div>';
    }

    $models = array_map('trim', explode(',', get_option('xb_aitaici_models', 'qwen-plus')));

    ob_start();
    ?>
    <div class="xb_aitaici_container">
        <div class="xb_aitaici_page_title">AI经典台词出处</div>
        
        <div class="xb_aitaici_config">
            <div class="xb_aitaici_page_mintitle">查询配置</div>
            
            <div class="xb_aitaici_input_wrapper">
                <label for="xb_aitaici_input">台词内容</label>
                <textarea id="xb_aitaici_input" name="xb_aitaici_input" placeholder="请输入台词内容，例如：假如再也见不到你，就再祝你下午好，晚上好，晚安"></textarea>
            </div>
            
            <div class="xb_aitaici_model_wrapper">
                <?php if ($enable_model_select): ?>
                <div class="xb_aitaici_model_select">
                    <label for="xb_aitaici_model">AI模型选择</label>
                    <select id="xb_aitaici_model" name="xb_aitaici_model">
                        <?php foreach ($models as $model): ?>
                            <option value="<?php echo esc_attr($model); ?>"><?php echo esc_html($model); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                <?php if ($enable_search): ?>
                <div class="xb_aitaici_search_toggle">
                    <span class="xb_aitaici_search_label">启用联网搜索</span>
                    <label class="xb_aitaici_search_slider">
                        <input type="checkbox" id="xb_aitaici_enable_search" name="xb_aitaici_enable_search">
                        <span class="slider"></span>
                    </label>
                </div>
                <?php endif; ?>
            </div>
            
            <button class="xb_aitaici_generate_button">开始查询</button>
        </div>
        
        <div class="xb_aitaici_results">
            <div class="xb_aitaici_page_mintitle">查询结果</div>
            <div class="xb_aitaici_result_content">AI查询结果将显示在这里...</div>
            <div class="xb_aitaici_result_buttons">
                <button class="xb_aitaici_copy_button">一键复制</button>
                <button class="xb_aitaici_clear_button">清空</button>
            </div>
            <div class="xb_aitaici_copy_success"></div>
            <?php if ($enable_usage_display): ?>
            <div class="xb_aitaici_usage">今日可用次数：<?php echo esc_html($user_limit . '/' . $remaining_usage); ?></div>
            <?php endif; ?>
        </div>
        
        <?php if ($ad_content): ?>
        <div class="xb_aitaici_ad">
            <?php echo wp_kses_post($ad_content); ?>
        </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('xb_aitaici_shortcode', 'xb_aitaici_shortcode');

/**
 * 处理自定义限制更新
 */
add_action('admin_post', function (): void {
    if (isset($_POST['user_id']) && (isset($_POST['set_limit']) || isset($_POST['reset_limit']))) {
        global $wpdb;
        $user_id = intval($_POST['user_id']);
        
        if (isset($_POST['set_limit']) && !empty($_POST['custom_limit'])) {
            $custom_limit = intval($_POST['custom_limit']);
            $wpdb->update(
                $wpdb->prefix . 'xb_aitaici_records',
                ['custom_limit' => $custom_limit],
                ['user_id' => $user_id]
            );
        } elseif (isset($_POST['reset_limit'])) {
            $wpdb->update(
                $wpdb->prefix . 'xb_aitaici_records',
                ['custom_limit' => null],
                ['user_id' => $user_id]
            );
        }
        
        wp_redirect(admin_url('admin.php?page=xb-aitaici-user-records&user_id=' . $user_id));
        exit;
    }
});

/**
 * 增强 REST API 权限检查
 */
add_filter('rest_authentication_errors', function ($result) {
    if (is_wp_error($result)) {
        return $result;
    }
    if (!is_user_logged_in()) {
        return new WP_Error(
            'rest_not_logged_in',
            '您必须登录才能访问此资源。',
            ['status' => 401]
        );
    }
    return $result;
});
?>