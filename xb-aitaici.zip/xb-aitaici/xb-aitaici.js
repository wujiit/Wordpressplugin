(function ($) {
    console.log('XBAitaici Plugin: JavaScript initialized.');

    $(document).on('click', '.xb_aitaici_generate_button', async function (e) {
        e.preventDefault();
        console.log('Generate button clicked.');

        const $resultContent = $('.xb_aitaici_result_content');
        const inputData = $('#xb_aitaici_input').val().trim();
        const $generateButton = $(this);

        if (!inputData) {
            console.log('Input data is empty.');
            $resultContent.html('<p class="xb_aitaici_error">请输入台词内容。</p>');
            return;
        }

        if (inputData.length > 1000) {
            console.log('Input data too long.');
            $resultContent.html('<p class="xb_aitaici_error">输入内容过长，请限制在1000字以内。</p>');
            return;
        }

        const forbiddenWords = XBAitaiciData.forbidden_words || [];
        const foundForbiddenWord = forbiddenWords.find(word => 
            typeof word === 'string' && typeof inputData === 'string' && 
            inputData.toLowerCase().includes(word.toLowerCase())
        );

        if (foundForbiddenWord) {
            console.log('Forbidden word detected:', foundForbiddenWord);
            $resultContent.html('<p class="xb_aitaici_error">输入内容包含违规词“' + foundForbiddenWord + '”，请重新输入</p>');
            return;
        }

        $resultContent.html('<span class="loading">正在查询中...</span>');

        if (!XBAitaiciData.nonce) {
            console.log('Nonce not found, user not logged in.');
            $resultContent.html('<p class="xb_aitaici_error">请先登录以使用台词查询助手。</p>');
            return;
        }

        const data = {
            model: $('#xb_aitaici_model').val() || XBAitaiciData.default_model || 'qwen-plus',
            data: inputData,
            enable_search: $('#xb_aitaici_enable_search').is(':checked')
        };
        console.log('Sending API request with data:', data);

        $generateButton.prop('disabled', true);

        try {
            const response = await fetch(XBAitaiciData.rest_url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': XBAitaiciData.nonce,
                    'Accept': 'text/event-stream'
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || '未知错误');
            }

            console.log('API request successful, processing stream...');
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let hasContent = false;

            async function readStream() {
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) {
                        if (hasContent) {
                            console.log('Stream completed, updating usage count.');
                            updateUsageCount();
                        } else {
                            console.log('No content received.');
                            $resultContent.html('<p class="xb_aitaici_error">查询失败，未收到有效内容。</p>');
                        }
                        $generateButton.prop('disabled', false);
                        break;
                    }

                    const chunk = decoder.decode(value, { stream: true });
                    const lines = chunk.split('\n');
                    for (const line of lines) {
                        if (line.trim().startsWith('data: ')) {
                            const jsonData = line.trim().substring(6);
                            if (jsonData === '[DONE]') {
                                if (hasContent) {
                                    console.log('Stream done, updating usage count.');
                                    updateUsageCount();
                                } else {
                                    console.log('No content received at stream end.');
                                    $resultContent.html('<p class="xb_aitaici_error">查询失败，未收到有效内容。</p>');
                                }
                                $generateButton.prop('disabled', false);
                                return;
                            }

                            try {
                                const data = JSON.parse(jsonData);
                                if (data.error) {
                                    console.log('API error:', data.error);
                                    $resultContent.html('<p class="xb_aitaici_error">' + data.error + '</p>');
                                    $generateButton.prop('disabled', false);
                                    return;
                                }
                                if ($resultContent.text() === '正在查询中...') {
                                    $resultContent.empty();
                                }
                                if (data.content) {
                                    hasContent = true;
                                    $resultContent.append(data.content);
                                    console.log('Received content chunk:', data.content);
                                }
                            } catch (e) {
                                console.error('解析流数据出错:', e, ' - 原始数据:', jsonData);
                                $resultContent.html('<p class="xb_aitaici_error">查询过程中发生错误，请检查日志。</p>');
                                $generateButton.prop('disabled', false);
                            }
                        }
                    }
                }
            }

            await readStream();
        } catch (error) {
            console.error('API 请求失败:', error);
            $resultContent.html('<p class="xb_aitaici_error">' + error.message + '</p>');
            $generateButton.prop('disabled', false);
        }
    });

    $(document).on('click', '.xb_aitaici_copy_button', function (e) {
        e.preventDefault();
        console.log('Copy button clicked.');
        const $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val($('.xb_aitaici_result_content').text()).select();
        document.execCommand('copy');
        $temp.remove();

        $('.xb_aitaici_copy_success').html('<p class="copy-success">复制成功！</p>');
        setTimeout(() => $('.xb_aitaici_copy_success').empty(), 2000);
    });

    $(document).on('click', '.xb_aitaici_clear_button', function (e) {
        e.preventDefault();
        console.log('Clear button clicked.');
        $('.xb_aitaici_result_content').empty();
    });

    $(document).on('click', '.xb_aitaici_quick_login_button', function (e) {
        e.preventDefault();
        console.log('Quick login button clicked.');
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.click();
        } else {
            window.location.href = '<?php echo esc_url(wp_login_url(get_permalink())); ?>';
        }
    });

    async function updateUsageCount() {
        console.log('Updating usage count via AJAX.');
        try {
            const response = await $.ajax({
                url: XBAitaiciData.rest_url.replace('/query', '/usage'),
                method: 'GET',
                headers: {
                    'X-WP-Nonce': XBAitaiciData.nonce
                }
            });
            console.log('Usage count updated:', response);
            const $usageDisplay = $('.xb_aitaici_usage');
            const $generateButton = $('.xb_aitaici_generate_button');
            if (response.remaining <= 0) {
                $usageDisplay.text('今日已用完，请明天再来');
                $generateButton.hide();
            } else {
                $usageDisplay.text('今日可用次数：' + response.limit + '/' + response.remaining);
                $generateButton.show();
            }
        } catch (error) {
            console.error('Failed to update usage count:', error);
            $('.xb_aitaici_usage').text('今日可用次数：无法加载');
            $('.xb_aitaici_generate_button').hide();
        }
    }

    $(document).on('click', '.xb_aitaici_search_toggle .slider', function (e) {
        e.preventDefault();
        const $checkbox = $(this).siblings('input[type="checkbox"]');
        $checkbox.prop('checked', !$checkbox.prop('checked'));
        console.log('Search toggle clicked, new state:', $checkbox.prop('checked'));
    });

    $(document).on('click', '.xb_aitaici_search_toggle', function (e) {
        if (!$(e.target).hasClass('slider')) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Clicked on search toggle label or surrounding area, no toggle action.');
        }
    });

    $(document).ready(() => {
        updateUsageCount();
    });

    console.log('XBAitaiciData:', XBAitaiciData);
})(jQuery);