<?php
$image = esc_url($atts['image']);
$device = get_option('wp_wallpaper_device', $atts['device']);
$phone_style = get_option('wp_wallpaper_phone_style', 'notch');

// 获取当前文章的标题
$post_title = get_the_title();

// 生成 alt 文本
$phone_alt = esc_attr($post_title . '手机壁纸');
$desktop_alt = esc_attr($post_title . '电脑壁纸');
?>

<div class="wallpaper-container">
    <?php if ($device === 'phone' || $device === 'both'): ?>
        <div class="phone-wallpaper <?php echo esc_attr($phone_style); ?>">
            <img src="<?php echo $image; ?>" alt="<?php echo $phone_alt; ?>">
        </div>
    <?php endif; ?>
    <?php if ($device === 'desktop' || $device === 'both'): ?>
        <div class="desktop-wallpaper">
            <img src="<?php echo $image; ?>" alt="<?php echo $desktop_alt; ?>">
        </div>
    <?php endif; ?>
</div>
