<?php
/**
 * Plugin Name: 小半壁纸样机
 * Description: 在前端以壁纸形式展示图片，支持手机和电脑样式的动态生成。
 * Plugin URI: https://www.jingxialai.com/4865.html
 * Version: 1.0
 * Author: Summer
 * License: GPL License
 * Author URI: https://www.jingxialai.com/
 */

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 加载必要文件
include_once plugin_dir_path(__FILE__) . 'admin/settings-page.php';

// 注册插件所需的资源
function wp_wallpaper_enqueue_assets() {
    // 检测当前页面是否包含壁纸短代码
global $post;
    if (isset($post->post_content) && has_shortcode($post->post_content, 'wallpaper')) {
        wp_enqueue_style('wp-wallpaper-styles', plugin_dir_url(__FILE__) . 'assets/css/styles.css');
        // wp_enqueue_script('wp-wallpaper-scripts', plugin_dir_url(__FILE__) . 'assets/js/scripts.js', array('jquery'), null, true);
    }
}
add_action('wp_enqueue_scripts', 'wp_wallpaper_enqueue_assets');


// 注册壁纸的短代码
function wp_wallpaper_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'image' => '',
            'device' => 'both', // 可选值：'phone', 'desktop', 'both'
        ),
        $atts,
        'wallpaper'
    );

    if (empty($atts['image'])) {
        return '<p>Please provide an image URL.</p>';
    }

    ob_start();
    include plugin_dir_path(__FILE__) . 'templates/wallpaper-template.php';
    return ob_get_clean();
}
add_shortcode('wallpaper', 'wp_wallpaper_shortcode');

// 保存文章时自动设置特色封面图
function wp_wallpaper_set_featured_image($post_id) {
    // 检查是否为自动保存
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // 检查是否为有效的post类型
    $post_type = get_post_type($post_id);
    if (!in_array($post_type, ['post', 'page'])) {
        return;
    }

    // 获取文章内容
    $post_content = get_post_field('post_content', $post_id);

    // 检查是否包含短代码[wallpaper image=""]
    if (has_shortcode($post_content, 'wallpaper')) {
        // 使用正则表达式提取image参数
        if (preg_match('/\[wallpaper[^\]]*image="([^"]+)"[^\]]*\]/', $post_content, $matches)) {
            $image_url = $matches[1];

            // 将URL转换为附件ID
            $attachment_id = attachment_url_to_postid($image_url);
            if ($attachment_id) {
                set_post_thumbnail($post_id, $attachment_id);
            } else {
                // 如果附件ID无法获取，可以尝试下载图片并附加到媒体库
                $upload_dir = wp_upload_dir();
                $image_data = file_get_contents($image_url);
                if ($image_data) {
                    $filename = basename($image_url);
                    $file_path = $upload_dir['path'] . '/' . $filename;
                    file_put_contents($file_path, $image_data);

                    $filetype = wp_check_filetype($filename, null);
                    $attachment = array(
                        'guid'           => $upload_dir['url'] . '/' . $filename,
                        'post_mime_type' => $filetype['type'],
                        'post_title'     => sanitize_file_name($filename),
                        'post_content'   => '',
                        'post_status'    => 'inherit',
                    );

                    $attachment_id = wp_insert_attachment($attachment, $file_path, $post_id);
                    require_once(ABSPATH . 'wp-admin/includes/image.php');
                    $attach_data = wp_generate_attachment_metadata($attachment_id, $file_path);
                    wp_update_attachment_metadata($attachment_id, $attach_data);
                    set_post_thumbnail($post_id, $attachment_id);
                }
            }
        }
    }
}
add_action('save_post', 'wp_wallpaper_set_featured_image');

// 添加经典编辑器的快捷输入框
function wp_wallpaper_editor_button() {
    echo '<a href="#" id="insert-wallpaper" class="button">插入壁纸</a>';
}
add_action('media_buttons', 'wp_wallpaper_editor_button', 20);

function wp_wallpaper_enqueue_editor_script($hook) {
    if ('post.php' === $hook || 'post-new.php' === $hook) {
        wp_enqueue_script('wp-wallpaper-editor-script', plugin_dir_url(__FILE__) . 'assets/js/editor.js', array('jquery'), null, true);
    }
}
add_action('admin_enqueue_scripts', 'wp_wallpaper_enqueue_editor_script');
