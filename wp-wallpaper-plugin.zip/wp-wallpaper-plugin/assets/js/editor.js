jQuery(document).ready(function ($) {
    $('#insert-wallpaper').on('click', function (e) {
        e.preventDefault();
        const imageUrl = prompt('请输入图片地址:');
        if (imageUrl) {
            wp.media.editor.insert(`[wallpaper image="${imageUrl}"]`);
        }
    });
});
