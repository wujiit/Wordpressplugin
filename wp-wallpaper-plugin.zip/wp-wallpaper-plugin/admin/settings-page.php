<?php
function wp_wallpaper_settings_page() {
    add_options_page(
        '壁纸样机',
        '小半壁纸样机设置',
        'manage_options',
        'wp-wallpaper-settings',
        'wp_wallpaper_render_settings_page'
    );
}
add_action('admin_menu', 'wp_wallpaper_settings_page');

function wp_wallpaper_render_settings_page() {
    // 处理表单提交
    if (isset($_POST['wp_wallpaper_settings'])) {
        check_admin_referer('wp_wallpaper_save_settings'); // CSRF验证
        update_option('wp_wallpaper_device', sanitize_text_field($_POST['wp_wallpaper_device']));
        update_option('wp_wallpaper_phone_style', sanitize_text_field($_POST['wp_wallpaper_phone_style']));
    }

    // 获取当前选项值
    $device = get_option('wp_wallpaper_device', 'both');
    $phone_style = get_option('wp_wallpaper_phone_style', 'notch');
    ?>
    <div class="wrap">
        <h1>壁纸样机设置</h1>
        <form method="post" action="">
            <?php wp_nonce_field('wp_wallpaper_save_settings'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">设备显示</th>
                    <td>
                        <select name="wp_wallpaper_device">
                            <option value="both" <?php selected($device, 'both'); ?>>手机和电脑</option>
                            <option value="phone" <?php selected($device, 'phone'); ?>>仅手机</option>
                            <option value="desktop" <?php selected($device, 'desktop'); ?>>仅电脑</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">手机样式</th>
                    <td>
                        <select name="wp_wallpaper_phone_style">
                            <option value="notch" <?php selected($phone_style, 'notch'); ?>>刘海屏</option>
                            <option value="island" <?php selected($phone_style, 'island'); ?>>灵动岛</option>
                            <option value="fullscreen" <?php selected($phone_style, 'fullscreen'); ?>>全面屏</option>
                        </select>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <button type="submit" name="wp_wallpaper_settings" class="button-primary">保存设置</button>
            </p>
        </form>
    </div>
    <?php
}
