jQuery(document).ready(function($) {
    // 刷新每日英语按钮点击事件
    $('.everyday_ai_refresh').on('click', function() {
        var $button = $(this);
        $button.prop('disabled', true); // 禁用按钮防止重复点击
        $('#everyday_ai_content, #everyday_ai_note, #everyday_ai_source, #everyday_ai_date, #everyday_ai_image').css('opacity', '0'); // 淡出内容

        $.ajax({
            url: everyday_ai_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'everyday_ai_refresh',
                nonce: everyday_ai_vars.nonce,
                _t: new Date().getTime() // 添加时间戳以防止浏览器缓存并传递给后端
            },
            cache: false, // 禁用 AJAX 缓存
            success: function(response) {
                if (response.success) {
                    // 更新内容并淡入显示
                    $('#everyday_ai_content').text(response.data.content).css('opacity', '1');
                    if (response.data.note) {
                        $('#everyday_ai_note').text(response.data.note).css('opacity', '1').show();
                    } else {
                        $('#everyday_ai_note').empty().hide();
                    }
                    if (response.data.source) {
                        $('#everyday_ai_source').text('来源: ' + response.data.source).css('opacity', '1').show();
                    } else {
                        $('#everyday_ai_source').empty().hide();
                    }
                    if (response.data.date) {
                        $('#everyday_ai_date').text('日期: ' + response.data.date).css('opacity', '1').show();
                    } else {
                        $('#everyday_ai_date').empty().hide();
                    }
                    if (response.data.image_url) {
                        $('#everyday_ai_image').html('<img src="' + response.data.image_url + '" alt="每日英语图片">').css('opacity', '1');
                    } else {
                        $('#everyday_ai_image').empty().css('opacity', '1');
                    }
                    // 更新复制按钮的 data-content 和 data-note
                    $('.everyday_ai_copy').data('content', response.data.content).data('note', response.data.note);
                } else {
                    // 处理服务器返回的失败情况
                    $('#everyday_ai_notice').text('刷新失败：' + (response.data.message || '未知错误')).show();
                    setTimeout(function() {
                        $('#everyday_ai_notice').fadeOut('slow', function() {
                            $(this).empty();
                        });
                    }, 3000);
                }
                $button.prop('disabled', false); // 恢复按钮
            },
            error: function() {
                // 处理 AJAX 请求失败
                $('#everyday_ai_content, #everyday_ai_note, #everyday_ai_source, #everyday_ai_date, #everyday_ai_image').css('opacity', '1');
                $button.prop('disabled', false);
                $('#everyday_ai_notice').text('网络错误，请稍后再试！').show();
                setTimeout(function() {
                    $('#everyday_ai_notice').fadeOut('slow', function() {
                        $(this).empty();
                    });
                }, 3000);
            }
        });
    });

    // 复制英语句子和释义按钮点击事件
    $('.everyday_ai_copy').on('click', function() {
        var content = $(this).data('content');
        var note = $(this).data('note');
        var $button = $(this);
        var $notice = $('#everyday_ai_notice');

        // 组合句子和释义，中间加换行符
        var textToCopy = note ? content + '\n' + note : content;

        navigator.clipboard.writeText(textToCopy).then(function() {
            // 复制成功提示
            $button.addClass('copied').text('已复制');
            $notice.empty();
            setTimeout(function() {
                $button.removeClass('copied').text('复制句子');
            }, 2000);
        }).catch(function() {
            // 复制失败提示
            $notice.text('复制失败，请手动复制！').show();
            setTimeout(function() {
                $notice.fadeOut('slow', function() {
                    $notice.empty();
                });
            }, 3000);
        });
    });
});