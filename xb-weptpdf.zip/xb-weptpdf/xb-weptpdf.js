jQuery(document).ready(function ($) {
    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('XB WEPTPDF: jQuery 未加载！');
        $('#xb_weptpdf_result').html('<div class="xb_weptpdf_message">脚本加载失败，请刷新页面！</div>');
        return;
    }

    // 确保 xb_weptpdf_ajax 配置
    if (typeof xb_weptpdf_ajax === 'undefined') {
        console.error('XB WEPTPDF: xb_weptpdf_ajax 未定义！');
        $('#xb_weptpdf_result').html('<div class="xb_weptpdf_message">脚本配置失败，请检查插件设置！</div>');
        return;
    }

    // 拖拽上传区域相关元素
    const dropArea = $('#xb_weptpdf_drop_area');
    const fileInput = $('#xb_weptpdf_file');
    const fileInfo = $('#xb_weptpdf_file_info');
    const fileName = $('#xb_weptpdf_file_name');
    const fileSize = $('#xb_weptpdf_file_size');
    const submitButton = $('#xb_weptpdf_submit_button');
    let fileUrl = '';
    let taskId = '';

    // 修复：防止点击事件递归 - 使用标志位防止重复触发
    let isClicking = false;

    // 拖拽上传区域点击事件
    dropArea.off('click').on('click', function (e) {
        e.preventDefault(); // 阻止默认行为
        e.stopPropagation(); // 阻止事件冒泡
        if (!isClicking) {
            isClicking = true;
            fileInput[0].click(); // 触发文件输入框点击
            setTimeout(() => {
                isClicking = false; // 延迟重置标志位，避免立即重复触发
            }, 100);
        }
    });

    // 文件输入框点击事件 - 防止冒泡回 dropArea
    fileInput.off('click').on('click', function (e) {
        e.stopPropagation(); // 阻止事件冒泡到 dropArea
    });

    // 拖拽相关事件
    dropArea.on('dragover', function (e) {
        e.preventDefault();
        $(this).addClass('xb_weptpdf_drop_active');
    });

    dropArea.on('dragleave', function () {
        $(this).removeClass('xb_weptpdf_drop_active');
    });

    dropArea.on('drop', function (e) {
        e.preventDefault();
        $(this).removeClass('xb_weptpdf_drop_active');
        const files = e.originalEvent.dataTransfer.files; // 修复：将 ee 改为 e
        if (files.length > 0) {
            fileInput[0].files = files;
            handleFile(files[0]);
        }
    });

    // 文件选择事件
    fileInput.on('change', function () {
        if (this.files.length > 0) {
            handleFile(this.files[0]);
        }
    });

    // 文件处理函数
    function handleFile(file) {
        const allowedExtensions = fileInput.attr('accept').split(',').map(ext => ext.replace('.', '').toLowerCase());
        const fileExt = file.name.split('.').pop().toLowerCase();
        const maxSizes = {
            'doc': 10 * 1024 * 1024,
            'docx': 10 * 1024 * 1024,
            'xls': 10 * 1024 * 1024,
            'xlsx': 10 * 1024 * 1024,
            'ppt': 80 * 1024 * 1024,
            'pptx': 80 * 1024 * 1024,
            'txt': 2 * 1024 * 1024
        };

        if (!allowedExtensions.includes(fileExt)) {
            showError('不支持的文件格式！');
            return;
        }

        if (file.size > maxSizes[fileExt]) {
            showError('文件大小超出限制！');
            return;
        }

        // 上传文件
        const formData = new FormData();
        formData.append('file', file);
        formData.append('action', 'xb_weptpdf_upload');
        formData.append('_wpnonce', xb_weptpdf_ajax.upload_nonce);

        $.ajax({
            url: xb_weptpdf_ajax.upload_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function () {
                submitButton.prop('disabled', true).html('<span class="xb_weptpdf_button_icon">⏳</span>上传中...');
                dropArea.addClass('xb_weptpdf_uploading');
            },
            success: function (response) {
                if (response.success) {
                    fileUrl = response.data.url;
                    fileName.text(file.name);
                    fileSize.text((file.size / (1024 * 1024)).toFixed(2) + ' MB');
                    fileInfo.show();
                    dropArea.hide();
                    submitButton.prop('disabled', false).html('<span class="xb_weptpdf_button_icon">🚀</span>开始转换');
                } else {
                    showError('文件上传失败：' + (response.data && response.data.message || '未知错误'));
                    resetUploadButton();
                }
            },
            error: function (xhr) {
                const message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ?
                    xhr.responseJSON.data.message : '文件上传失败，请重试！';
                showError(message);
                resetUploadButton();
            }
        });
    }

    // 重置上传按钮状态
    function resetUploadButton() {
        submitButton.prop('disabled', true).html('<span class="xb_weptpdf_button_icon">📤</span>开始转换');
        dropArea.removeClass('xb_weptpdf_uploading');
    }

    // 显示错误信息
    function showError(message) {
        $('#xb_weptpdf_result').html('<div class="xb_weptpdf_message xb_weptpdf_message_error">' +
            '<span class="xb_weptpdf_message_icon">❌</span>' + message + '</div>');
        $('#xb_weptpdf_clear_button').show();
        $('.xb_weptpdf_loading').remove();
    }

    // 显示加载信息
    function showLoadingMessage() {
        $('#xb_weptpdf_result').html(
            '<div class="xb_weptpdf_loading">' +
            '<div class="xb_weptpdf_spinner"></div>' +
            '<div class="xb_weptpdf_ts_title">🔄 正在转换中</div>' +
            '<p>请稍候，我们正在为您转换文档...</p>' +
            '</div>'
        );
    }

    // 隐藏上传区域并显示相应消息
    function hideUploadAreaAndShowMessage(remaining, isGuest) {
        if (remaining <= 0) {
            $('#xb_weptpdf_convert_form_logged, #xb_weptpdf_convert_form_guest').fadeOut(300, function () {
                if (isGuest) {
                    const loginMessage =
                        '<div class="xb_weptpdf_message xb_weptpdf_message_info">' +
                        '<div class="xb_weptpdf_message_icon">🔐</div>' +
                        '<div class="xb_weptpdf_message_content">' +
                        '<h3>游客使用次数已用完</h3>' +
                        '<p>您今日的免费转换次数已用完，登录后可获得更多转换次数！</p>' +
                        '<a href="' + xb_weptpdf_ajax.login_url + '" class="xb_weptpdf_login_btn">' +
                        '<span class="xb_weptpdf_button_icon">🚀</span>立即登录' +
                        '</a>' +
                        '</div>' +
                        '</div>';
                    $('.xb_weptpdf_upload_section').append(loginMessage);
                } else {
                    const limitMessage =
                        '<div class="xb_weptpdf_message xb_weptpdf_message_info">' +
                        '<div class="xb_weptpdf_message_icon">⏰</div>' +
                        '<div class="xb_weptpdf_message_content">' +
                        '<h3>今日转换次数已用完</h3>' +
                        '<p>您今日的转换次数已用完，请明天再来使用！</p>' +
                        '</div>' +
                        '</div>';
                    $('.xb_weptpdf_upload_section').append(limitMessage);
                }
            });
        }
    }

    // 游客表单提交处理
    $('#xb_weptpdf_convert_form_guest').on('submit', function (e) {
        e.preventDefault();

        if (!fileUrl) {
            showError('请先上传文件！');
            return;
        }

        $.ajax({
            url: xb_weptpdf_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_weptpdf_guest_convert',
                file_url: fileUrl,
                file_name: fileName.text(),
                file_size: fileSize.text(),
                _wpnonce: xb_weptpdf_ajax.upload_nonce
            },
            beforeSend: function () {
                submitButton.prop('disabled', true).html('<span class="xb_weptpdf_button_icon">⏳</span>转换中...');
                showLoadingMessage();
                $('#xb_weptpdf_clear_button').hide();
            },
            success: function (response) {
                if (response.success) {
                    taskId = response.data.task_id;
                    if (taskId) {
                        setTimeout(function () {
                            checkCallbackStatus(taskId);
                        }, 10000);
                    } else {
                        showError('任务提交失败，请重试！');
                        resetForm();
                    }
                } else {
                    const message = response.data && response.data.message ? response.data.message : '转换失败，请重试！';
                    showError(message);
                    resetForm();
                }
            },
            error: function (xhr) {
                const message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ?
                    xhr.responseJSON.data.message : '暂时无法转换请联系客服';
                showError(message);
                resetForm();
            }
        });
    });

    // 登录用户表单提交
    $('#xb_weptpdf_convert_form_logged').on('submit', function (e) {
        e.preventDefault();

        if (!fileUrl) {
            showError('请先上传文件！');
            return;
        }

        const nonce = $('#xb_weptpdf_nonce').val();
        if (!nonce) {
            showError('安全验证参数丢失，请刷新页面！');
            return;
        }

        $.ajax({
            url: xb_weptpdf_ajax.rest_url,
            type: 'POST',
            data: JSON.stringify({
                file_url: fileUrl,
                file_name: fileName.text(),
                file_size: fileSize.text()
            }),
            contentType: 'application/json',
            headers: { 'X-WP-Nonce': xb_weptpdf_ajax.nonce },
            beforeSend: function () {
                submitButton.prop('disabled', true).html('<span class="xb_weptpdf_button_icon">⏳</span>转换中...');
                showLoadingMessage();
                $('#xb_weptpdf_clear_button').hide();
            },
            success: function (response) {
                taskId = response.task_id;
                if (taskId) {
                    setTimeout(function () {
                        checkCallbackStatus(taskId);
                    }, 10000);
                } else {
                    showError('任务提交失败，请重试！');
                    resetForm();
                }
            },
            error: function (xhr) {
                const message = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : '暂时无法转换请联系客服';
                showError(message);
                $('.xb_weptpdf_loading').remove();
                resetForm();
            }
        });
    });

    // 检查回调是否已完成
    function checkCallbackStatus(task_id) {
        $.ajax({
            url: xb_weptpdf_ajax.check_result_url,
            type: 'POST',
            data: JSON.stringify({ task_id: task_id }),
            contentType: 'application/json',
            headers: { 'X-WP-Nonce': xb_weptpdf_ajax.nonce },
            success: function (response) {
                if (response.status === 'success' && response.result) {
                    $('#xb_weptpdf_result').html(response.result);
                    $('.xb_weptpdf_usage_info').html('<span class="xb_weptpdf_usage_icon">📊</span>今日剩余转换次数：' + response.remaining + '/' + response.limit);
                    resetForm();
                    $('#xb_weptpdf_clear_button').show();
                    const isGuest = xb_weptpdf_ajax.is_logged_in == 0;
                    hideUploadAreaAndShowMessage(response.remaining, isGuest);
                } else {
                    startPolling(task_id);
                }
            },
            error: function () {
                startPolling(task_id);
            }
        });
    }

    // 轮询检查转换结果
    function startPolling(task_id) {
        const maxAttempts = 24; // 120秒 / 5秒
        let attempts = 0;

        const poll = setInterval(function () {
            if (attempts >= maxAttempts) {
                clearInterval(poll);
                showError('转换超时，请稍后重试');
                resetForm();
                return;
            }

            $.ajax({
                url: xb_weptpdf_ajax.check_result_url,
                type: 'POST',
                data: JSON.stringify({ task_id: task_id }),
                contentType: 'application/json',
                headers: { 'X-WP-Nonce': xb_weptpdf_ajax.nonce },
                success: function (response) {
                    if (response.status === 'success' && response.result) {
                        clearInterval(poll);
                        $('#xb_weptpdf_result').html(response.result);
                        $('.xb_weptpdf_usage_info').html('<span class="xb_weptpdf_usage_icon">📊</span>今日剩余转换次数：' + response.remaining + '/' + response.limit);
                        resetForm();
                        $('#xb_weptpdf_clear_button').show();
                        const isGuest = xb_weptpdf_ajax.is_logged_in == 0;
                        hideUploadAreaAndShowMessage(response.remaining, isGuest);
                    } else if (response.status === 'pending') {
                        attempts++;
                    } else {
                        clearInterval(poll);
                        showError(response.message || '转换失败，请稍后重试');
                        resetForm();
                    }
                },
                error: function (xhr) {
                    clearInterval(poll);
                    const message = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : '查询转换结果失败，请稍后重试';
                    showError(message);
                    resetForm();
                }
            });
        }, 5000);
    }

    // 重置表单
    function resetForm() {
        fileInput.val('');
        fileInfo.hide();
        dropArea.show().removeClass('xb_weptpdf_uploading');
        submitButton.prop('disabled', true).html('<span class="xb_weptpdf_button_icon">📤</span>开始转换');
        fileUrl = '';
        taskId = '';
    }

    // 移除文件
    $('.xb_weptpdf_remove_file').on('click', function () {
        resetForm();
    });

    // 快速登录
    $(document).on('click', '.xb_weptpdf_login_btn', function (e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });

    // 清空按钮
    $('#xb_weptpdf_clear_button').on('click', function (e) {
        e.preventDefault();
        $('#xb_weptpdf_result').empty();
        $(this).hide();
        $('.xb_weptpdf_loading').remove();
        const hasUsageLimitMessage = $('.xb_weptpdf_upload_section .xb_weptpdf_message').length > 0;
        if (!hasUsageLimitMessage) {
            resetForm();
        } else {
            fileInput.val('');
            fileUrl = '';
            taskId = '';
        }
    });

    // 处理下载按钮点击
    $(document).on('click', '.xb_weptpdf_download_button', function (e) {
        e.preventDefault();
        const url = $(this).data('url');
        const fileName = 'converted_document.pdf';

        fetch(url, {
            method: 'GET',
            headers: {
                'Accept': 'application/pdf'
            }
        })
            .then(response => response.blob())
            .then(blob => {
                const blobUrl = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = blobUrl;
                link.download = fileName;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                window.URL.revokeObjectURL(blobUrl);
            })
            .catch(error => {
                console.error('Download failed:', error);
                showError('下载失败，请稍后重试！');
            });
    });
});