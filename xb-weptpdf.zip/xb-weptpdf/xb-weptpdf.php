<?php
/*
Plugin Name: 文档转PDF
Description: 将Word、Excel、PPT、txt文件转换为PDF，支持回调和轮询获取结果，仅转换成功计费。
Version: 1.0.7
Author: Summer
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xb_weptpdf_activate');
function xb_weptpdf_activate() {
    xb_weptpdf_create_database();
    xb_weptpdf_create_front_page();
}

// 创建数据库表
function xb_weptpdf_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 使用次数表 - 结构不变，保持与原插件一致
    $usage_table = $wpdb->prefix . 'xb_weptpdf_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL DEFAULT 0,
        device_id varchar(255) NOT NULL DEFAULT '',
        convert_date date NOT NULL,
        convert_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_device_date (user_id, device_id, convert_date)
    ) $charset_collate;";

    // 转换记录表 - 结构不变，保持与原插件一致
    $records_table = $wpdb->prefix . 'xb_weptpdf_records';
    $records_sql = "CREATE TABLE $records_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL DEFAULT 0,
        device_id varchar(255) NOT NULL DEFAULT '',
        file_url varchar(255) NOT NULL,
        convert_status varchar(20) NOT NULL,
        convert_time datetime NOT NULL,
        task_id varchar(100) DEFAULT NULL,
        pdf_url varchar(255) DEFAULT NULL,
        error_message varchar(255) DEFAULT NULL,
        ip_address varchar(45) NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($usage_sql);
    dbDelta($records_sql);
}

// 获取设备指纹 - 保持原逻辑，用于游客
function xb_weptpdf_get_device_id() {
    // 获取设备指纹的关键信息
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $accept_language = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
    
    // 构建设备指纹数组
    $device_fingerprint = array(
        'user_agent' => $user_agent,
        'ip_address' => $ip_address,
        'accept_language' => $accept_language,
    );
    
    // 生成唯一的设备ID
    $device_id = md5(json_encode($device_fingerprint));
    
    error_log('XB WEPTPDF: Generated device_id: ' . $device_id . ' for IP: ' . $ip_address);
    return $device_id;
}

// 设置设备Cookie - 保持原逻辑，用于游客
function xb_weptpdf_set_device_cookie($device_id) {
    if (!headers_sent()) {
        setcookie('xb_weptpdf_device_id', $device_id, time() + (365 * 24 * 60 * 60), '/');
    }
}

// 获取设备ID（优先使用Cookie，失效时使用设备指纹） - 保持原逻辑，用于游客
function xb_weptpdf_get_final_device_id() {
    // 首先尝试从Cookie获取
    $cookie_device_id = isset($_COOKIE['xb_weptpdf_device_id']) ? sanitize_text_field($_COOKIE['xb_weptpdf_device_id']) : '';
    
    // 生成当前设备指纹
    $fingerprint_device_id = xb_weptpdf_get_device_id();
    
    // 如果Cookie存在且有效，使用Cookie中的设备ID
    if (!empty($cookie_device_id)) {
        // 设置Cookie以延长有效期
        xb_weptpdf_set_device_cookie($cookie_device_id);
        return $cookie_device_id;
    }
    
    // Cookie不存在或失效，使用设备指纹生成的ID，并设置Cookie
    xb_weptpdf_set_device_cookie($fingerprint_device_id);
    return $fingerprint_device_id;
}

// 创建前台页面
function xb_weptpdf_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_weptpdf_convert_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => '文档转PDF',
            'post_content' => '[xb_weptpdf_convert_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_weptpdf_enqueue_scripts');
function xb_weptpdf_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_weptpdf_convert_form')) {
        wp_enqueue_style('xb_weptpdf_styles', plugins_url('xb-weptpdf.css', __FILE__), array(), '1.0.7');
        wp_enqueue_script('xb_weptpdf_scripts', plugins_url('xb-weptpdf.js', __FILE__), array('jquery'), '1.0.7', true);

        wp_localize_script('xb_weptpdf_scripts', 'xb_weptpdf_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => rest_url('xb_weptpdf/v1/convert'),
            'nonce'    => wp_create_nonce('wp_rest'),
            'login_url' => wp_login_url(get_permalink()),
            'is_logged_in' => is_user_logged_in() ? 1 : 0,
            'upload_url' => admin_url('admin-ajax.php'),
            'upload_nonce' => wp_create_nonce('xb_weptpdf_upload_nonce'),
            'check_result_url' => rest_url('xb_weptpdf/v1/check_result'),
            'guest_enabled' => get_option('xb_weptpdf_guest_enabled', 1),
        ));
    }
}

// 短代码 - 修改使用次数统计逻辑
add_shortcode('xb_weptpdf_convert_form', 'xb_weptpdf_convert_form_shortcode');
function xb_weptpdf_convert_form_shortcode() {
    $ad_content = get_option('xb_weptpdf_ad_content', '');
    $default_limit = absint(get_option('xb_weptpdf_default_limit', 10));
    $guest_limit = absint(get_option('xb_weptpdf_guest_limit', 5));
    $show_stats = get_option('xb_weptpdf_show_stats', 1);
    $guest_enabled = get_option('xb_weptpdf_guest_enabled', 1);
    $allowed_formats = array_map('strtolower', array_map('trim', explode(',', get_option('xb_weptpdf_allowed_formats', 'Word,Excel,PPT,txt'))));

    $display_result = '';
    $display_message = '';
    $show_clear = false;

    // 处理游客消息和结果显示
    if (!is_user_logged_in()) {
        $guest_message = get_transient('xb_weptpdf_guest_message');
        if ($guest_message) {
            $display_message = $guest_message;
            $show_clear = true;
            delete_transient('xb_weptpdf_guest_message');
        }

        if (isset($_GET['task_id'])) {
            $task_id = sanitize_text_field($_GET['task_id']);
            $transient_result = get_transient('xb_weptpdf_result_' . $task_id);
            if ($transient_result) {
                if (isset($transient_result['message'])) {
                    $display_message = $transient_result['message'];
                } else {
                    $display_result = $transient_result['result'];
                }
                $show_clear = true;
                delete_transient('xb_weptpdf_result_' . $task_id);
            }
        }
    }

    ob_start();
    ?>
    <div class="xb_weptpdf_container">
        <div class="xb_weptpdf_header">
            <div class="xb_weptpdf_title">文档转PDF</div>
            <p class="xb_weptpdf_subtitle">Word、Excel、PPT转PDF</p>
        </div>

        <?php
        $user_id = is_user_logged_in() ? get_current_user_id() : 0;
        $today = current_time('Y-m-d');
        
        // 获取设备ID，仅用于游客
        $device_id = xb_weptpdf_get_final_device_id();

        global $wpdb;
        $usage_table = $wpdb->prefix . 'xb_weptpdf_usage';

        // 修改：优化使用次数统计逻辑
        if (is_user_logged_in()) {
            // 已登录用户：按 user_id 汇总所有设备的使用次数
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT SUM(convert_count) as total_count, MAX(custom_limit) as custom_limit 
                     FROM $usage_table 
                     WHERE user_id = %d AND convert_date = %s",
                    $user_id, $today
                )
            );
            $convert_count = $row && $row->total_count !== null ? absint($row->total_count) : 0;
            $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;
        } else {
            // 游客：按 device_id 统计
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT convert_count, custom_limit 
                     FROM $usage_table 
                     WHERE user_id = 0 AND device_id = %s AND convert_date = %s",
                    $device_id, $today
                )
            );
            $convert_count = $row ? absint($row->convert_count) : 0;
            $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $guest_limit;
        }

        $remaining = max(0, $user_limit - $convert_count);
        $stats_text = "今日剩余转换次数：{$remaining}/{$user_limit}";
        $form_id = is_user_logged_in() ? 'xb_weptpdf_convert_form_logged' : 'xb_weptpdf_convert_form_guest';
        $action = is_user_logged_in() ? '' : get_permalink();
        $method = is_user_logged_in() ? 'post' : 'post';
        
        // 构建允许的文件扩展名
        $allowed_extensions = array();
        if (in_array('word', $allowed_formats)) {
            $allowed_extensions = array_merge($allowed_extensions, array('doc', 'docx'));
        }
        if (in_array('excel', $allowed_formats)) {
            $allowed_extensions = array_merge($allowed_extensions, array('xls', 'xlsx'));
        }
        if (in_array('ppt', $allowed_formats)) {
            $allowed_extensions = array_merge($allowed_extensions, array('ppt', 'pptx'));
        }
        if (in_array('txt', $allowed_formats)) {
            $allowed_extensions[] = 'txt';
        }
        $accept = '.' . implode(',.', $allowed_extensions);

        // 判断是否显示文件拖拽区域的逻辑
        $show_upload_area = true;
        $disable_reason = '';

        // 1. 游客不允许使用时，不显示文件拖拽区域
        if (!is_user_logged_in() && !$guest_enabled) {
            $show_upload_area = false;
            $disable_reason = 'guest_disabled';
        }
        // 2. 游客使用次数用完了，不显示文件拖拽区域
        elseif (!is_user_logged_in() && $convert_count >= $user_limit) {
            $show_upload_area = false;
            $disable_reason = 'guest_limit_exceeded';
        }
        // 3. 已登录用户使用次数用完了，不显示文件拖拽区域
        elseif (is_user_logged_in() && $convert_count >= $user_limit) {
            $show_upload_area = false;
            $disable_reason = 'user_limit_exceeded';
        }
        ?>

        <div class="xb_weptpdf_content">
            <div class="xb_weptpdf_upload_section">
                <div class="xb_weptpdf_section_title">📤 文件上传区域</div>
                <?php if (!$show_upload_area): ?>
                    <div class="xb_weptpdf_message xb_weptpdf_message_info">
                        <?php if ($disable_reason === 'guest_disabled'): ?>
                            <div class="xb_weptpdf_message_icon">🚫</div>
                            <div class="xb_weptpdf_message_content">
                                <div class="xb_weptpdf_ts_title">游客功能已关闭</div>
                                <p>管理员已关闭游客使用功能，请登录后继续使用。</p>
                                <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xb_weptpdf_login_btn">立即登录</a>
                            </div>
                        <?php elseif ($disable_reason === 'guest_limit_exceeded'): ?>
                            <div class="xb_weptpdf_message_icon">⏰</div>
                            <div class="xb_weptpdf_message_content">
                                <div class="xb_weptpdf_ts_title">游客使用次数已用完</div>
                                <p>今日游客转换次数已达上限，请登录获取更多使用次数。</p>
                                <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xb_weptpdf_login_btn">立即登录</a>
                            </div>
                        <?php elseif ($disable_reason === 'user_limit_exceeded'): ?>
                            <div class="xb_weptpdf_message_icon">📅</div>
                            <div class="xb_weptpdf_message_content">
                                <div class="xb_weptpdf_ts_title">今日使用次数已用完</div>
                                <p>您今日的转换次数已达上限，请明天再来。</p>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <form id="<?php echo $form_id; ?>" action="<?php echo $action; ?>" method="<?php echo $method; ?>" enctype="multipart/form-data">
                        <div class="xb_weptpdf_drop_area" id="xb_weptpdf_drop_area">
                            <div class="xb_weptpdf_drop_icon">📄</div>
                            <div class="xb_weptpdf_ts_title">拖拽文件到此处或点击上传</div>
                            <p class="xb_weptpdf_drop_text">支持格式：<?php echo esc_html(implode(', ', $allowed_formats)); ?></p>
                            <input type="file" name="xb_weptpdf_file" id="xb_weptpdf_file" accept="<?php echo esc_attr($accept); ?>" style="display:none;">
                        </div>
                        <div class="xb_weptpdf_file_info" id="xb_weptpdf_file_info" style="display:none;">
                            <div class="xb_weptpdf_file_preview">
                                <div class="xb_weptpdf_file_icon">📄</div>
                                <div class="xb_weptpdf_file_details">
                                    <p class="xb_weptpdf_file_name_label">文件名：<span id="xb_weptpdf_file_name"></span></p>
                                    <p class="xb_weptpdf_file_size_label">文件大小：<span id="xb_weptpdf_file_size"></span></p>
                                </div>
                                <button type="button" class="xb_weptpdf_remove_file">✕</button>
                            </div>
                        </div>
                        <button type="submit" class="xb_weptpdf_submit_button" id="xb_weptpdf_submit_button" disabled>
                            <span class="xb_weptpdf_button_icon">🚀</span>
                            开始转换
                        </button>
                        <?php if (is_user_logged_in()): ?>
                            <input type="hidden" name="xb_weptpdf_nonce" id="xb_weptpdf_nonce" value="<?php echo wp_create_nonce('xb_weptpdf_convert_nonce'); ?>">
                        <?php endif; ?>
                        <input type="hidden" name="xb_weptpdf_device_id" id="xb_weptpdf_device_id" value="<?php echo esc_attr($device_id); ?>">
                    </form>
                <?php endif; ?>
            </div>
            
            <div class="xb_weptpdf_result_section">
                <div class="xb_weptpdf_section_title">📋 转换结果区域</div>
                <?php if ($show_upload_area || $show_clear): ?>
                    <button id="xb_weptpdf_clear_button" class="xb_weptpdf_clear_button" style="<?php echo $show_clear ? 'display:block;' : 'display:none;'; ?>">
                        <span class="xb_weptpdf_button_icon">🗑️</span>
                        清空结果
                    </button>
                <?php endif; ?>
                <div id="xb_weptpdf_result">
                    <?php 
                    if ($display_result) {
                        echo $display_result;
                    }
                    if ($display_message) {
                        echo '<div class="xb_weptpdf_message">' . esc_html($display_message) . '</div>';
                    }
                    ?>
                </div>
                <?php if ($show_stats && $show_upload_area): ?>
                    <div class="xb_weptpdf_usage_info">
                        <span class="xb_weptpdf_usage_icon">📊</span>
                        <?php echo esc_html($stats_text); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if (!empty($ad_content)): ?>
            <div class="xb_weptpdf_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

// 处理游客表单提交 - 修改使用次数检查逻辑
add_action('template_redirect', 'xb_weptpdf_handle_guest_convert');
function xb_weptpdf_handle_guest_convert() {
    // 检查是否是游客提交的转换请求
    if (!is_user_logged_in() && (isset($_POST['xb_weptpdf_file']) || (isset($_FILES['xb_weptpdf_file']) && !empty($_FILES['xb_weptpdf_file']['name'])))) {
        // 检查游客是否被允许使用
        $guest_enabled = get_option('xb_weptpdf_guest_enabled', 1);
        if (!$guest_enabled) {
            set_transient('xb_weptpdf_guest_message', '游客功能已关闭，请登录后使用。', 10);
            wp_redirect(get_permalink());
            exit;
        }

        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        // 检查是否通过AJAX上传获得了文件URL
        if (isset($_POST['xb_weptpdf_file_url']) && !empty($_POST['xb_weptpdf_file_url'])) {
            // 使用已上传的文件URL
            $file_url = sanitize_url($_POST['xb_weptpdf_file_url']);
            $file_name = sanitize_text_field($_POST['xb_weptpdf_file_name']);
            $file_size = sanitize_text_field($_POST['xb_weptpdf_file_size']);
        } else {
            // 传统文件上传方式
            if (!isset($_FILES['xb_weptpdf_file']) || empty($_FILES['xb_weptpdf_file']['name'])) {
                set_transient('xb_weptpdf_guest_message', '未选择文件，请选择文件后重试！', 10);
                wp_redirect(get_permalink());
                exit;
            }

            $file = $_FILES['xb_weptpdf_file'];
            if ($file['error'] !== UPLOAD_ERR_OK) {
                set_transient('xb_weptpdf_guest_message', '文件上传失败，请重试！', 10);
                wp_redirect(get_permalink());
                exit;
            }

            $allowed_formats = array_map('strtolower', array_map('trim', explode(',', get_option('xb_weptpdf_allowed_formats', 'Word,Excel,PPT,txt'))));
            $allowed_extensions = array();
            $max_sizes = array(
                'doc' => 10 * 1024 * 1024,
                'docx' => 10 * 1024 * 1024,
                'xls' => 10 * 1024 * 1024,
                'xlsx' => 10 * 1024 * 1024,
                'ppt' => 80 * 1024 * 1024,
                'pptx' => 80 * 1024 * 1024,
                'txt' => 2 * 1024 * 1024
            );
            if (in_array('word', $allowed_formats)) {
                $allowed_extensions = array_merge($allowed_extensions, array('doc', 'docx'));
            }
            if (in_array('excel', $allowed_formats)) {
                $allowed_extensions = array_merge($allowed_extensions, array('xls', 'xlsx'));
            }
            if (in_array('ppt', $allowed_formats)) {
                $allowed_extensions = array_merge($allowed_extensions, array('ppt', 'pptx'));
            }
            if (in_array('txt', $allowed_formats)) {
                $allowed_extensions[] = 'txt';
            }

            $file_ext = strtolower(pathinfo($file['name'] ?? '', PATHINFO_EXTENSION));
            if (!in_array($file_ext, $allowed_extensions)) {
                set_transient('xb_weptpdf_guest_message', '不支持的文件格式！', 10);
                wp_redirect(get_permalink());
                exit;
            }

            if ($file['size'] > $max_sizes[$file_ext]) {
                set_transient('xb_weptpdf_guest_message', '文件大小超出限制！', 10);
                wp_redirect(get_permalink());
                exit;
            }

            $file_type = wp_check_filetype_and_ext($file['tmp_name'] ?? '', $file['name']);
            if ($file_type['ext'] !== $file_ext || !in_array($file_type['type'], array(
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'application/vnd.ms-excel',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/vnd.ms-powerpoint',
                'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                'text/plain'
            ))) {
                set_transient('xb_weptpdf_guest_message', '文件类型验证失败，请上传真实的文件！', 10);
                wp_redirect(get_permalink());
                exit;
            }

            $attachment_id = media_handle_upload('xb_weptpdf_file', 0);
            if (is_wp_error($attachment_id)) {
                set_transient('xb_weptpdf_guest_message', '文件上传失败：' . $attachment_id->get_error_message(), 10);
                wp_redirect(get_permalink());
                exit;
            }

            $file_url = wp_get_attachment_url($attachment_id);
            $file_size = size_format($file['size'], 2);
            $file_name = $file['name'];
        }

        $user_id = 0;
        $today = current_time('Y-m-d');
        $ip_address = $_SERVER['REMOTE_ADDR'];
        
        // 获取设备ID，用于游客
        $device_id = xb_weptpdf_get_final_device_id();

        global $wpdb;
        $usage_table = $wpdb->prefix . 'xb_weptpdf_usage';
        $guest_limit = absint(get_option('xb_weptpdf_guest_limit', 5));
        
        // 修改：游客使用次数检查，保持按 device_id 统计
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT convert_count, custom_limit 
                 FROM $usage_table 
                 WHERE user_id = 0 AND device_id = %s AND convert_date = %s",
                $device_id, $today
            )
        );

        $convert_count = $row ? absint($row->convert_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $guest_limit;

        if ($convert_count >= $user_limit) {
            set_transient('xb_weptpdf_guest_message', '游客的使用次数已经用完，请登录之后继续。', 10);
            if (isset($attachment_id)) {
                wp_delete_attachment($attachment_id, true);
            }
            wp_redirect(get_permalink());
            exit;
        }

        $result = xb_weptpdf_call_api($file_url, $file_name, $file_size, $user_id, $ip_address, $device_id, $today);
        
        // 为游客保存转换结果到transient，包含完整的文件信息
        $transient_data = array(
            'message' => $result['message'],
            'file_info' => array(
                'name' => $file_name,
                'size' => $file_size
            ),
            'task_id' => $result['task_id']
        );
        
        set_transient('xb_weptpdf_result_' . $result['task_id'], $transient_data, 3600);
        wp_redirect(add_query_arg('task_id', urlencode($result['task_id']), get_permalink()));
        exit;
    }
}

// 注册 REST API 端点
add_action('rest_api_init', 'xb_weptpdf_register_rest_routes');
function xb_weptpdf_register_rest_routes() {
    register_rest_route('xb_weptpdf/v1', '/convert', array(
        'methods' => 'POST',
        'callback' => 'xb_weptpdf_handle_logged_convert',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
        'args' => array(
            'file_url' => array('required' => true, 'validate_callback' => function ($param) {
                return filter_var($param, FILTER_VALIDATE_URL);
            }),
            'file_name' => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
            'file_size' => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
        )
    ));

    register_rest_route('xb_weptpdf/v1', '/callback', array(
        'methods' => 'POST',
        'callback' => 'xb_weptpdf_handle_callback',
        'permission_callback' => '__return_true',
    ));

    register_rest_route('xb_weptpdf/v1', '/check_result', array(
        'methods' => 'POST',
        'callback' => 'xb_weptpdf_check_result',
        'permission_callback' => '__return_true',
        'args' => array(
            'task_id' => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
        )
    ));
}

// 处理登录用户转换 - 修改使用次数检查和更新逻辑
function xb_weptpdf_handle_logged_convert(WP_REST_Request $request) {
    $file_url = $request->get_param('file_url');
    $file_name = $request->get_param('file_name');
    $file_size = $request->get_param('file_size');
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    
    // 获取设备ID，仅用于记录，不影响使用次数统计
    $device_id = xb_weptpdf_get_final_device_id();

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_weptpdf_usage';
    $default_limit = absint(get_option('xb_weptpdf_default_limit', 10));
    
    // 修改：已登录用户按 user_id 汇总使用次数
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT SUM(convert_count) as total_count, MAX(custom_limit) as custom_limit 
             FROM $usage_table 
             WHERE user_id = %d AND convert_date = %s",
            $user_id, $today
        )
    );
    
    $convert_count = $row && $row->total_count !== null ? absint($row->total_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;

    if ($convert_count >= $user_limit) {
        return new WP_REST_Response(array('message' => '今日使用次数已经用完，请明天再来。'), 403);
    }

    $result = xb_weptpdf_call_api($file_url, $file_name, $file_size, $user_id, $ip_address, $device_id, $today);
    return new WP_REST_Response($result, 200);
}

// 处理回调 - 修改使用次数更新逻辑
function xb_weptpdf_handle_callback(WP_REST_Request $request) {
    $data = $request->get_body();
    $sign_header = $request->get_header('sign');
    $app_secret = get_option('xb_weptpdf_app_secret');

    $computed_sign = hash('sha256', $app_secret . $data);
    if ($computed_sign !== $sign_header) {
        return new WP_REST_Response(array('success' => false, 'msg' => '签名验证失败'), 400);
    }

    $response = json_decode($data, true);
    if (!$response || !isset($response['convertTaskId'])) {
        return new WP_REST_Response(array('success' => false, 'msg' => '无效的回调数据'), 400);
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_weptpdf_records';
    $convert_task_id = sanitize_text_field($response['convertTaskId']);
    $record = $wpdb->get_row(
        $wpdb->prepare("SELECT id, user_id, device_id, file_url FROM $records_table WHERE task_id = %s", $convert_task_id)
    );

    if (!$record) {
        return new WP_REST_Response(array('success' => false, 'msg' => '任务ID不存在'), 404);
    }

    $update_data = array('convert_status' => $response['code']);
    $transient_key = 'xb_weptpdf_result_' . $convert_task_id;
    $transient_data = get_transient($transient_key);
    if (!$transient_data) {
        $transient_data = array('file_info' => array('name' => '未知文件', 'size' => '未知大小'));
    }

    if ($response['code'] == '200' && !empty($response['urls'])) {
        $update_data['pdf_url'] = esc_url_raw($response['urls'][0]);
        $update_data['convert_status'] = 'success';
        $transient_data['result'] = xb_weptpdf_format_result($response['urls'][0]);

        // 修改：仅在转换成功时更新使用次数
        $user_id = $record->user_id;
        $device_id = $record->device_id;
        $today = current_time('Y-m-d');
        $usage_table = $wpdb->prefix . 'xb_weptpdf_usage';
        $user_limit = $user_id ? absint(get_option('xb_weptpdf_default_limit', 10)) : absint(get_option('xb_weptpdf_guest_limit', 5));

        if ($user_id) {
            // 已登录用户：按 user_id 汇总使用次数
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT SUM(convert_count) as total_count, MAX(custom_limit) as custom_limit 
                     FROM $usage_table 
                     WHERE user_id = %d AND convert_date = %s",
                    $user_id, $today
                )
            );
            $convert_count = $row && $row->total_count !== null ? absint($row->total_count) : 0;
            $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $user_limit;

            // 更新或插入使用次数记录（保留 device_id 用于记录，但不影响统计）
            $existing_row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT id FROM $usage_table 
                     WHERE user_id = %d AND device_id = %s AND convert_date = %s",
                    $user_id, $device_id, $today
                )
            );
            if ($existing_row) {
                $wpdb->update(
                    $usage_table,
                    array('convert_count' => $convert_count + 1),
                    array('user_id' => $user_id, 'device_id' => $device_id, 'convert_date' => $today)
                );
            } else {
                $wpdb->insert(
                    $usage_table,
                    array(
                        'user_id' => $user_id,
                        'device_id' => $device_id,
                        'convert_date' => $today,
                        'convert_count' => 1,
                        'custom_limit' => null,
                    )
                );
            }
        } else {
            // 游客：按 device_id 更新使用次数
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT convert_count, custom_limit 
                     FROM $usage_table 
                     WHERE user_id = 0 AND device_id = %s AND convert_date = %s",
                    $device_id, $today
                )
            );
            $convert_count = $row ? absint($row->convert_count) : 0;
            $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $user_limit;

            if ($convert_count > 0) {
                $wpdb->update(
                    $usage_table,
                    array('convert_count' => $convert_count + 1),
                    array('user_id' => 0, 'device_id' => $device_id, 'convert_date' => $today)
                );
            } else {
                $wpdb->insert(
                    $usage_table,
                    array(
                        'user_id' => 0,
                        'device_id' => $device_id,
                        'convert_date' => $today,
                        'convert_count' => 1,
                        'custom_limit' => null,
                    )
                );
            }
        }
        
        $transient_data['remaining'] = $user_limit - ($convert_count + 1);
        $transient_data['limit'] = $user_limit;
        set_transient('xb_weptpdf_usage_' . $user_id . '_' . md5($device_id . $today), array($convert_count + 1, $user_limit), 300);
    } else {
        $update_data['error_message'] = '转换失败';
        $transient_data['message'] = '转换失败，请稍后重试';
    }

    $wpdb->update(
        $records_table,
        $update_data,
        array('task_id' => $convert_task_id),
        array('%s', '%s'),
        array('%s')
    );

    set_transient($transient_key, $transient_data, 3600);
    return new WP_REST_Response(array('success' => true), 200);
}

// 查询转换结果 - 修改使用次数更新逻辑
function xb_weptpdf_check_result(WP_REST_Request $request) {
    $convert_task_id = $request->get_param('task_id');
    $app_id = get_option('xb_weptpdf_app_id');
    $app_secret = get_option('xb_weptpdf_app_secret');

    $api_url = 'https://api.jumdata.com/file-convert/result';
    $timestamp = sprintf('%.0f', (floatval(microtime(true)) * 1000));
    $sign = hash('sha256', $app_id . $app_secret . $timestamp);

    $body = array(
        'appId' => $app_id,
        'timestamp' => $timestamp,
        'sign' => $sign,
        'productCode' => 'file_convert',
        'convertTaskId' => $convert_task_id,
    );

    $args = array(
        'method' => 'POST',
        'timeout' => 5,
        'sslverify' => false,
        'headers' => array(
            'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8',
        ),
        'body' => http_build_query($body),
    );

    $response = wp_remote_request($api_url, $args);
    if (is_wp_error($response)) {
        return new WP_REST_Response(array('message' => $response->get_error_message()), 500);
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_weptpdf_records';
    $transient_key = 'xb_weptpdf_result_' . $convert_task_id;
    $transient_data = get_transient($transient_key);
    if (!$transient_data) {
        $transient_data = array('file_info' => array('name' => '未知文件', 'size' => '未知大小'));
    }

    if (isset($data['code']) && $data['code'] == 200 && !empty($data['data']['urls'])) {
        $record = $wpdb->get_row(
            $wpdb->prepare("SELECT user_id, device_id FROM $records_table WHERE task_id = %s", $convert_task_id)
        );
        if ($record) {
            $user_id = $record->user_id;
            $device_id = $record->device_id;
            $today = current_time('Y-m-d');
            $usage_table = $wpdb->prefix . 'xb_weptpdf_usage';
            $user_limit = $user_id ? absint(get_option('xb_weptpdf_default_limit', 10)) : absint(get_option('xb_weptpdf_guest_limit', 5));

            // 修改：更新使用次数逻辑
            if ($user_id) {
                // 已登录用户：按 user_id 汇总
                $row = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT SUM(convert_count) as total_count, MAX(custom_limit) as custom_limit 
                         FROM $usage_table 
                         WHERE user_id = %d AND convert_date = %s",
                        $user_id, $today
                    )
                );
                $convert_count = $row && $row->total_count !== null ? absint($row->total_count) : 0;
                $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $user_limit;

                // 更新或插入记录（保留 device_id 用于记录）
                $existing_row = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT id FROM $usage_table 
                         WHERE user_id = %d AND device_id = %s AND convert_date = %s",
                        $user_id, $device_id, $today
                    )
                );
                if ($existing_row) {
                    $wpdb->update(
                        $usage_table,
                        array('convert_count' => $convert_count + 1),
                        array('user_id' => $user_id, 'device_id' => $device_id, 'convert_date' => $today)
                    );
                } else {
                    $wpdb->insert(
                        $usage_table,
                        array(
                            'user_id' => $user_id,
                            'device_id' => $device_id,
                            'convert_date' => $today,
                            'convert_count' => 1,
                            'custom_limit' => null,
                        )
                    );
                }
            } else {
                // 游客：按 device_id 更新
                $row = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT convert_count, custom_limit 
                         FROM $usage_table 
                         WHERE user_id = 0 AND device_id = %s AND convert_date = %s",
                        $device_id, $today
                    )
                );
                $convert_count = $row ? absint($row->convert_count) : 0;
                $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $user_limit;

                if ($convert_count > 0) {
                    $wpdb->update(
                        $usage_table,
                        array('convert_count' => $convert_count + 1),
                        array('user_id' => 0, 'device_id' => $device_id, 'convert_date' => $today)
                    );
                } else {
                    $wpdb->insert(
                        $usage_table,
                        array(
                            'user_id' => 0,
                            'device_id' => $device_id,
                            'convert_date' => $today,
                            'convert_count' => 1,
                            'custom_limit' => null,
                        )
                    );
                }
            }

            $transient_data['remaining'] = $user_limit - ($convert_count + 1);
            $transient_data['limit'] = $user_limit;
            set_transient('xb_weptpdf_usage_' . $user_id . '_' . md5($device_id . $today), array($convert_count + 1, $user_limit), 300);
        }

        $wpdb->update(
            $records_table,
            array('convert_status' => 'success', 'pdf_url' => esc_url_raw($data['data']['urls'][0])),
            array('task_id' => $convert_task_id),
            array('%s', '%s'),
            array('%s')
        );

        $transient_data['result'] = xb_weptpdf_format_result($data['data']['urls'][0]);
        set_transient($transient_key, $transient_data, 3600);

        return new WP_REST_Response(array(
            'status' => 'success',
            'result' => $transient_data['result'],
            'remaining' => $transient_data['remaining'],
            'limit' => $transient_data['limit']
        ), 200);
    } elseif ($data['code'] == 201) {
        return new WP_REST_Response(array('status' => 'pending'), 202);
    } else {
        $error_message = isset($data['msg']) ? $data['msg'] : '未知错误';
        $wpdb->update(
            $records_table,
            array('convert_status' => 'failed', 'error_message' => $error_message),
            array('task_id' => $convert_task_id),
            array('%s', '%s'),
            array('%s')
        );

        $transient_data['message'] = $error_message;
        set_transient($transient_key, $transient_data, 3600);
        return new WP_REST_Response(array('message' => $error_message), 400);
    }
}

// API 调用 - 未修改，保持原逻辑
function xb_weptpdf_call_api($file_url, $file_name, $file_size, $user_id, $ip_address, $device_id, $today) {
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_weptpdf_records';

    $api_url = get_option('xb_weptpdf_api_url', 'https://api.jumdata.com/file-convert/word2pdf');
    $app_id = get_option('xb_weptpdf_app_id');
    $app_secret = get_option('xb_weptpdf_app_secret');
    $callback_url = rest_url('xb_weptpdf/v1/callback');
    $timestamp = sprintf('%.0f', (floatval(microtime(true)) * 1000));
    $sign = hash('sha256', $app_id . $app_secret . $timestamp);

    $body = array(
        'appId' => $app_id,
        'timestamp' => $timestamp,
        'sign' => $sign,
        'productCode' => 'file_convert',
        'fileUrl' => $file_url,
        'callBackUrl' => $callback_url,
    );

    $args = array(
        'method' => 'POST',
        'timeout' => 10,
        'sslverify' => false,
        'headers' => array(
            'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8',
        ),
        'body' => http_build_query($body),
    );

    $insert_data = array(
        'user_id' => $user_id,
        'device_id' => $device_id,
        'file_url' => $file_url,
        'convert_status' => 'pending',
        'convert_time' => current_time('mysql'),
        'ip_address' => $ip_address,
    );

    $response = wp_remote_request($api_url, $args);
    if (is_wp_error($response)) {
        $insert_data['convert_status'] = 'failed';
        $insert_data['error_message'] = $response->get_error_message();
        $wpdb->insert($records_table, $insert_data);
        return array(
            'message' => '提交失败：' . $insert_data['error_message'],
            'file_info' => array('name' => $file_name, 'size' => $file_size),
            'task_id' => md5($file_url . $timestamp),
        );
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if ($status_code >= 400 || !isset($data['code']) || $data['code'] != 200) {
        $error_message = isset($data['msg']) ? $data['msg'] : 'API 请求错误：HTTP ' . $status_code;
        $insert_data['convert_status'] = 'failed';
        $insert_data['error_message'] = $error_message;
        $wpdb->insert($records_table, $insert_data);
        return array(
            'message' => $error_message,
            'file_info' => array('name' => $file_name, 'size' => $file_size),
            'task_id' => md5($file_url . $timestamp),
        );
    }

    $insert_data['task_id'] = sanitize_text_field($data['data']['convertTaskId']);
    $wpdb->insert($records_table, $insert_data);

    return array(
        'message' => '转换任务已提交，请稍后查看结果。',
        'file_info' => array('name' => $file_name, 'size' => $file_size),
        'task_id' => $data['data']['convertTaskId'],
    );
}

// 格式化转换结果 - 未修改，保持原逻辑
function xb_weptpdf_format_result($pdf_url) {
    $output = '<div class="xb_weptpdf_result_wrapper">';
    $output .= '<div class="xb_weptpdf_success_message">';
    $output .= '<div class="xb_weptpdf_success_icon">✅</div>';
    $output .= '<div class="xb_weptpdf_ts_title">转换成功！</div>';
    $output .= '<p>您的文档已成功转换为PDF格式</p>';
    $output .= '</div>';
    $output .= '<iframe src="' . esc_url($pdf_url) . '" class="xb_weptpdf_preview" width="100%" height="400px" frameborder="0"></iframe>';
    $output .= '<div class="xb_weptpdf_actions">';
    $output .= '<button class="xb_weptpdf_download_button" data-url="' . esc_url($pdf_url) . '">';
    $output .= '<span class="xb_weptpdf_button_icon">📥</span>下载PDF';
    $output .= '</button>';
    $output .= '</div>';
    $output .= '</div>';
    return $output;
}

// 游客AJAX转换处理 - 修改使用次数检查逻辑
add_action('wp_ajax_nopriv_xb_weptpdf_guest_convert', 'xb_weptpdf_handle_guest_ajax_convert');
function xb_weptpdf_handle_guest_ajax_convert() {
    check_ajax_referer('xb_weptpdf_upload_nonce', '_wpnonce');

    $file_url = sanitize_url($_POST['file_url']);
    $file_name = sanitize_text_field($_POST['file_name']);
    $file_size = sanitize_text_field($_POST['file_size']);
    
    if (empty($file_url)) {
        wp_send_json_error(array('message' => '文件URL不能为空！'));
    }

    $user_id = 0; // 游客用户ID为0
    $today = current_time('Y-m-d');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    
    // 获取设备ID
    $device_id = xb_weptpdf_get_final_device_id();

    // 检查游客是否允许使用
    $guest_enabled = get_option('xb_weptpdf_guest_enabled', 1);
    if (!$guest_enabled) {
        wp_send_json_error(array('message' => '游客功能已关闭，请登录后使用！'));
    }

    // 检查游客使用次数
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_weptpdf_usage';
    $guest_limit = absint(get_option('xb_weptpdf_guest_limit', 5));
    
    // 修改：游客按 device_id 统计
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT convert_count, custom_limit 
             FROM $usage_table 
             WHERE user_id = 0 AND device_id = %s AND convert_date = %s",
            $device_id, $today
        )
    );

    $convert_count = $row ? absint($row->convert_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $guest_limit;

    if ($convert_count >= $user_limit) {
        wp_send_json_error(array('message' => '游客的使用次数已经用完，请登录之后继续。'));
    }

    // 调用API进行转换
    $result = xb_weptpdf_call_api($file_url, $file_name, $file_size, $user_id, $ip_address, $device_id, $today);
    
    // 保存转换结果到transient，供前端轮询使用
    $transient_data = array(
        'message' => $result['message'],
        'file_info' => array(
            'name' => $file_name,
            'size' => $file_size
        ),
        'task_id' => $result['task_id']
    );
    set_transient('xb_weptpdf_result_' . $result['task_id'], $transient_data, 3600);

    wp_send_json_success($result);
}

// AJAX 上传功能 - 未修改，保持原逻辑
add_action('wp_ajax_xb_weptpdf_upload', 'xb_weptpdf_handle_ajax_upload');
add_action('wp_ajax_nopriv_xb_weptpdf_upload', 'xb_weptpdf_handle_ajax_upload');
function xb_weptpdf_handle_ajax_upload() {
    check_ajax_referer('xb_weptpdf_upload_nonce', '_wpnonce');

    // 检查游客是否被允许使用
    if (!is_user_logged_in()) {
        $guest_enabled = get_option('xb_weptpdf_guest_enabled', 1);
        if (!$guest_enabled) {
            wp_send_json_error(array('message' => '游客功能已关闭，请登录后使用。'));
        }
    }

    if (!isset($_FILES['file']) || empty($_FILES['file']['name'])) {
        wp_send_json_error(array('message' => '未选择文件，请选择文件后重试！'));
    }

    $file = $_FILES['file'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error(array('message' => '文件上传失败，请重试！'));
    }

    $allowed_formats = array_map('strtolower', array_map('trim', explode(',', get_option('xb_weptpdf_allowed_formats', 'Word,Excel,PPT,txt'))));
    $allowed_extensions = array();
    $max_sizes = array(
        'doc' => 10 * 1024 * 1024,
        'docx' => 10 * 1024 * 1024,
        'xls' => 10 * 1024 * 1024,
        'xlsx' => 10 * 1024 * 1024,
        'ppt' => 80 * 1024 * 1024,
        'pptx' => 80 * 1024 * 1024,
        'txt' => 2 * 1024 * 1024
    );
    if (in_array('word', $allowed_formats)) {
        $allowed_extensions = array_merge($allowed_extensions, array('doc', 'docx'));
    }
    if (in_array('excel', $allowed_formats)) {
        $allowed_extensions = array_merge($allowed_extensions, array('xls', 'xlsx'));
    }
    if (in_array('ppt', $allowed_formats)) {
        $allowed_extensions = array_merge($allowed_extensions, array('ppt', 'pptx'));
    }
    if (in_array('txt', $allowed_formats)) {
        $allowed_extensions[] = 'txt';
    }

    $file_ext = strtolower(pathinfo($file['name'] ?? '', PATHINFO_EXTENSION));
    if (!in_array($file_ext, $allowed_extensions)) {
        wp_send_json_error(array('message' => '不支持的文件格式！'));
    }

    if ($file['size'] > $max_sizes[$file_ext]) {
        wp_send_json_error(array('message' => '文件大小超出限制！'));
    }

    $file_type = wp_check_filetype_and_ext($file['tmp_name'] ?? '', $file['name']);
    if ($file_type['ext'] !== $file_ext || !in_array($file_type['type'], array(
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'text/plain'
    ))) {
        wp_send_json_error(array('message' => '文件类型验证失败，请上传真实的文件！'));
    }

    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attachment_id = media_handle_upload('file', 0);
    if (is_wp_error($attachment_id)) {
        wp_send_json_error(array('message' => '文件上传失败：' . $attachment_id->get_error_message()));
    }

    $file_url = wp_get_attachment_url($attachment_id);
    wp_send_json_success(array('url' => $file_url));
}

// 添加管理菜单 - 未修改，保持原逻辑
add_action('admin_menu', 'xb_weptpdf_admin_menu');
function xb_weptpdf_admin_menu() {
    add_menu_page(
        '文档转PDF设置',
        '文档转PDF',
        'manage_options',
        'xb_weptpdf_settings',
        'xb_weptpdf_settings_page',
        'dashicons-pdf',
        80
    );
    add_submenu_page(
        'xb_weptpdf_settings',
        '转换记录',
        '转换记录',
        'manage_options',
        'xb_weptpdf_all_records',
        'xb_weptpdf_all_records_page'
    );
}

// 插件设置页面 - 未修改，保持原逻辑
function xb_weptpdf_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['xb_weptpdf_save_settings'])) {
        check_admin_referer('xb_weptpdf_settings_nonce');
        update_option('xb_weptpdf_api_url', sanitize_text_field($_POST['xb_weptpdf_api_url']));
        update_option('xb_weptpdf_app_id', sanitize_text_field($_POST['xb_weptpdf_app_id']));
        update_option('xb_weptpdf_app_secret', sanitize_text_field($_POST['xb_weptpdf_app_secret']));
        $new_limit = absint($_POST['xb_weptpdf_default_limit']);
        $new_guest_limit = absint($_POST['xb_weptpdf_guest_limit']);
        if ($new_limit > 0) {
            update_option('xb_weptpdf_default_limit', $new_limit);
        }
        if ($new_guest_limit > 0) {
            update_option('xb_weptpdf_guest_limit', $new_guest_limit);
        }
        update_option('xb_weptpdf_show_stats', isset($_POST['xb_weptpdf_show_stats']) ? 1 : 0);
        update_option('xb_weptpdf_guest_enabled', isset($_POST['xb_weptpdf_guest_enabled']) ? 1 : 0);
        update_option('xb_weptpdf_allowed_formats', sanitize_text_field($_POST['xb_weptpdf_allowed_formats']));
        $allowed_html = array(
            'a' => array('href' => array(), 'title' => array(), 'target' => array()),
            'img' => array('src' => array(), 'alt' => array(), 'width' => array(), 'height' => array()),
            'p' => array(),
            'div' => array('class' => array(), 'style' => array()),
            'span' => array('class' => array(), 'style' => array()),
            'strong' => array(),
            'em' => array(),
            'br' => array()
        );
        update_option('xb_weptpdf_ad_content', wp_kses($_POST['xb_weptpdf_ad_content'], $allowed_html));
        echo '<div class="updated xb_weptpdf_auto_hide_message"><p>设置已保存！</p></div>';
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_weptpdf_records';
    $stats = array(
        'total_converts' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table"),
        'success_converts' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE convert_status = 'success'"),
        'failed_converts' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE convert_status = 'failed'"),
        'today_converts' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE DATE(convert_time) = %s", current_time('Y-m-d')))
    );

    ?>
    <div class="wrap">
        <h1>文档转PDF设置</h1>
        <form method="post">
            <?php wp_nonce_field('xb_weptpdf_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_weptpdf_api_url">API 接口地址</label></th>
                    <td><input type="text" name="xb_weptpdf_api_url" id="xb_weptpdf_api_url" value="<?php echo esc_attr(get_option('xb_weptpdf_api_url', 'https://api.jumdata.com/file-convert/word2pdf')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_weptpdf_app_id">App ID</label></th>
                    <td><input type="text" name="xb_weptpdf_app_id" id="xb_weptpdf_app_id" value="<?php echo esc_attr(get_option('xb_weptpdf_app_id')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_weptpdf_app_secret">App 密钥</label></th>
                    <td><input type="text" name="xb_weptpdf_app_secret" id="xb_weptpdf_app_secret" value="<?php echo esc_attr(get_option('xb_weptpdf_app_secret')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_weptpdf_default_limit">登录用户每日转换次数</label></th>
                    <td><input type="number" name="xb_weptpdf_default_limit" id="xb_weptpdf_default_limit" value="<?php echo esc_attr(get_option('xb_weptpdf_default_limit', 10)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_weptpdf_guest_limit">游客每日转换次数</label></th>
                    <td><input type="number" name="xb_weptpdf_guest_limit" id="xb_weptpdf_guest_limit" value="<?php echo esc_attr(get_option('xb_weptpdf_guest_limit', 5)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_weptpdf_guest_enabled">允许游客使用</label></th>
                    <td>
                        <input type="checkbox" name="xb_weptpdf_guest_enabled" id="xb_weptpdf_guest_enabled" <?php checked(get_option('xb_weptpdf_guest_enabled', 1), 1); ?> value="1">
                        <label for="xb_weptpdf_guest_enabled">允许游客使用转换功能</label>
                        <p class="description">关闭后，游客将无法使用转换功能，需要登录后才能使用。</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_weptpdf_allowed_formats">支持的文件格式</label></th>
                    <td>
                        <input type="text" name="xb_weptpdf_allowed_formats" id="xb_weptpdf_allowed_formats" value="<?php echo esc_attr(get_option('xb_weptpdf_allowed_formats', 'Word,Excel,PPT,txt')); ?>" class="regular-text">
                        <p class="description">多个格式用英文逗号分隔，例如：Word,Excel,PPT,txt</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_weptpdf_show_stats">显示统计</label></th>
                    <td><input type="checkbox" name="xb_weptpdf_show_stats" id="xb_weptpdf_show_stats" <?php checked(get_option('xb_weptpdf_show_stats', 1), 1); ?> value="1"> 显示剩余转换次数</td>
                </tr>
                <tr>
                    <th><label for="xb_weptpdf_ad_content">公告内容</label></th>
                    <td>
                        <textarea name="xb_weptpdf_ad_content" id="xb_weptpdf_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_weptpdf_ad_content')); ?></textarea>
                        <p class="description">支持 HTML 格式。</p>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="xb_weptpdf_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        <div class="xb_weptpdf_stats">
            <p>总转换次数：<?php echo esc_html($stats['total_converts'] ?: 0); ?></p>
            <p>成功转换次数：<?php echo esc_html($stats['success_converts'] ?: 0); ?></p>
            <p>失败转换次数：<?php echo esc_html($stats['failed_converts'] ?: 0); ?></p>
            <p>今日转换次数：<?php echo esc_html($stats['today_converts'] ?: 0); ?></p>
        </div>
    </div>
    
    <!-- 自动隐藏消息的JavaScript代码 -->
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        // 3秒后自动隐藏带有 xb_weptpdf_auto_hide_message 类的消息
        $('.xb_weptpdf_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}

// 转换记录页面 - 修改用户限制显示逻辑
function xb_weptpdf_all_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_weptpdf_records';
    $usage_table = $wpdb->prefix . 'xb_weptpdf_usage';
    $user_id = isset($_POST['xb_weptpdf_user_id']) ? absint($_POST['xb_weptpdf_user_id']) : 0;
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    // 一键删除所有记录
    if (isset($_POST['xb_weptpdf_delete_all_global'])) {
        check_admin_referer('xb_weptpdf_delete_all_global_nonce');
        $wpdb->query("TRUNCATE TABLE $records_table");
        echo '<div class="updated xb_weptpdf_auto_hide_message"><p>所有记录已删除！</p></div>';
    }

    // 一键重置所有用户使用次数
    if (isset($_POST['xb_weptpdf_reset_all_usage'])) {
        check_admin_referer('xb_weptpdf_reset_all_usage_nonce');
        $wpdb->query("TRUNCATE TABLE $usage_table");
        echo '<div class="updated xb_weptpdf_auto_hide_message"><p>所有用户使用次数已重置！</p></div>';
    }

    // 删除单条记录
    if (isset($_POST['xb_weptpdf_delete_record']) && isset($_POST['record_id'])) {
        check_admin_referer('xb_weptpdf_delete_record_nonce');
        $wpdb->delete($records_table, array('id' => absint($_POST['record_id'])), array('%d'));
        echo '<div class="updated xb_weptpdf_auto_hide_message"><p>记录已删除！</p></div>';
    }

    // 删除用户所有记录
    if (isset($_POST['xb_weptpdf_delete_all_records']) && $user_id) {
        check_admin_referer('xb_weptpdf_delete_all_records_nonce');
        $wpdb->delete($records_table, array('user_id' => $user_id), array('%d'));
        echo '<div class="updated xb_weptpdf_auto_hide_message"><p>用户记录已删除！</p></div>';
    }

    // 重置用户使用次数
    if (isset($_POST['xb_weptpdf_reset_user_usage']) && $user_id) {
        check_admin_referer('xb_weptpdf_reset_user_usage_nonce');
        $wpdb->delete($usage_table, array('user_id' => $user_id), array('%d'));
        echo '<div class="updated xb_weptpdf_auto_hide_message"><p>用户使用次数已重置！</p></div>';
    }

    // 更新用户自定义限制
    if (isset($_POST['xb_weptpdf_save_user_limit']) && $user_id) {
        check_admin_referer('xb_weptpdf_user_limit_nonce');
        $custom_limit = isset($_POST['xb_weptpdf_custom_limit']) ? absint($_POST['xb_weptpdf_custom_limit']) : null;
        $wpdb->update(
            $usage_table,
            array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
            array('user_id' => $user_id, 'convert_date' => current_time('Y-m-d')),
            array('%d'),
            array('%d', '%s')
        );
        echo '<div class="updated xb_weptpdf_auto_hide_message"><p>用户转换限制已更新！</p></div>';
    }

    $default_limit = absint(get_option('xb_weptpdf_default_limit', 10));
    $guest_limit = absint(get_option('xb_weptpdf_guest_limit', 5));
    $user_limit = $user_id ? $default_limit : $guest_limit;
    if ($user_id || $user_id === 0) {
        // 修改：获取用户限制时考虑汇总
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT MAX(custom_limit) as custom_limit 
                 FROM $usage_table 
                 WHERE user_id = %d AND convert_date = %s",
                $user_id, current_time('Y-m-d')
            )
        );
        if ($row && $row->custom_limit !== null) {
            $user_limit = absint($row->custom_limit);
        }
    }

    $stats = array(
        'total_converts' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE user_id = %d", $user_id)),
        'success_converts' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE convert_status = 'success' AND user_id = %d", $user_id)),
        'failed_converts' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE convert_status = 'failed' AND user_id = %d", $user_id)),
        'today_converts' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE DATE(convert_time) = %s AND user_id = %d", current_time('Y-m-d'), $user_id))
    );

    $offset = ($paged - 1) * $per_page;
    $query = $user_id
        ? $wpdb->prepare("SELECT * FROM $records_table WHERE user_id = %d ORDER BY convert_time DESC LIMIT %d, %d", $user_id, $offset, $per_page)
        : $wpdb->prepare("SELECT * FROM $records_table ORDER BY convert_time DESC LIMIT %d, %d", $offset, $per_page);
    $records = $wpdb->get_results($query);
    $total_records = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE user_id = %d", $user_id));
    $total_pages = ceil($total_records / $per_page);

    $user_info = $user_id && $user_id != 0 ? get_userdata($user_id) : null;
    $user_display = $user_id == 0 ? '游客' : ($user_info ? $user_info->user_login : '未知用户');
    ?>
    <div class="wrap">
        <h1>所有转换记录</h1>
        <div style="margin-bottom: 20px;">
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('xb_weptpdf_delete_all_global_nonce'); ?>
                <input type="submit" name="xb_weptpdf_delete_all_global" class="button-secondary" value="一键删除所有记录" onclick="return confirm('确定删除所有记录吗？这不会重置用户使用次数。');">
            </form>
            <form method="post" style="display:inline; margin-left: 10px;">
                <?php wp_nonce_field('xb_weptpdf_reset_all_usage_nonce'); ?>
                <input type="submit" name="xb_weptpdf_reset_all_usage" class="button-secondary" value="一键重置所有使用次数" onclick="return confirm('确定重置所有用户的使用次数吗？');">
            </form>
        </div>
        <form method="post">
            <p>
                <label for="xb_weptpdf_user_id">用户 ID（0 表示游客，留空显示所有记录）：</label>
                <input type="number" name="xb_weptpdf_user_id" id="xb_weptpdf_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <?php if ($user_id || $user_id === 0): ?>
            <h2>用户：<?php echo esc_html($user_display); ?> (ID: <?php echo $user_id; ?>)</h2>
            <p>每日转换次数：<?php echo esc_html($user_limit); ?> 次</p>
            <form method="post">
                <?php wp_nonce_field('xb_weptpdf_user_limit_nonce'); ?>
                <p>
                    <label for="xb_weptpdf_custom_limit">自定义每日转换次数（0 表示默认值）：</label>
                    <input type="number" name="xb_weptpdf_custom_limit" id="xb_weptpdf_custom_limit" min="0">
                    <input type="hidden" name="xb_weptpdf_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_weptpdf_save_user_limit" class="button-primary" value="保存">
                </p>
            </form>
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('xb_weptpdf_delete_all_records_nonce'); ?>
                <input type="hidden" name="xb_weptpdf_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" name="xb_weptpdf_delete_all_records" class="button-secondary" value="删除当前用户记录" onclick="return confirm('确定删除当前用户所有记录吗？这不会重置使用次数。');">
            </form>
            <form method="post" style="display:inline; margin-left: 10px;">
                <?php wp_nonce_field('xb_weptpdf_reset_user_usage_nonce'); ?>
                <input type="hidden" name="xb_weptpdf_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" name="xb_weptpdf_reset_user_usage" class="button-secondary" value="重置使用次数" onclick="return confirm('确定重置当前用户的使用次数吗？');">
            </form>
        <?php endif; ?>

        <div class="xb_weptpdf_stats">
            <p>总转换次数：<?php echo esc_html($stats['total_converts'] ?: 0); ?></p>
            <p>成功转换次数：<?php echo esc_html($stats['success_converts'] ?: 0); ?></p>
            <p>失败转换次数：<?php echo esc_html($stats['failed_converts'] ?: 0); ?></p>
            <p>今日转换次数：<?php echo esc_html($stats['today_converts'] ?: 0); ?></p>
        </div>

        <table class="widefat">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>设备 ID</th>
                    <th>转换时间</th>
                    <th>文件 URL</th>
                    <th>状态</th>
                    <th>PDF URL</th>
                    <th>错误信息</th>
                    <th>IP 地址</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="9">暂无转换记录。</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td><?php echo esc_html($record->user_id == 0 ? '游客' : $record->user_id); ?></td>
                            <td><?php echo esc_html($record->device_id ?: '-'); ?></td>
                            <td><?php echo esc_html($record->convert_time); ?></td>
                            <td><a href="<?php echo esc_url($record->file_url); ?>" target="_blank">查看</a></td>
                            <td><?php echo esc_html($record->convert_status); ?></td>
                            <td><?php echo $record->pdf_url ? '<a href="' . esc_url($record->pdf_url) . '" target="_blank">查看</a>' : '-'; ?></td>
                            <td><?php echo esc_html($record->error_message ?: '-'); ?></td>
                            <td><?php echo esc_html($record->ip_address); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_weptpdf_delete_record_nonce'); ?>
                                    <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>">
                                    <input type="submit" name="xb_weptpdf_delete_record" class="button-link" value="删除" onclick="return confirm('确定删除此记录？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    
    <!-- 自动隐藏消息的JavaScript代码 -->
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        // 3秒后自动隐藏带有 xb_weptpdf_auto_hide_message 类的消息
        $('.xb_weptpdf_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}
?>