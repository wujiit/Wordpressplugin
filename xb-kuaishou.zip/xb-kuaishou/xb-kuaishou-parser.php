<?php
/*
Plugin Name: 启灵快手解析
Plugin URI: https://www.wujiit.com
Description: 一个用于解析快手视频链接的WordPress插件，支持视频内容获取及下载链接生成。
Version: 1.0.3
Author: Summer
Author URI: https://www.wujiit.com
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xb_aiksjiexi_activate');
function xb_aiksjiexi_activate() {
    xb_aiksjiexi_create_database();
    xb_aiksjiexi_create_front_page();
}

// 创建数据库表
function xb_aiksjiexi_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 用户/游客查询次数表
    $usage_table = $wpdb->prefix . 'xb_aiksjiexi_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL DEFAULT 0,
        device_id varchar(255) NOT NULL DEFAULT '',
        query_date date NOT NULL,
        query_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_device_date (user_id, device_id, query_date)
    ) $charset_collate;";

    // 查询记录表
    $queries_table = $wpdb->prefix . 'xb_aiksjiexi_queries';
    $queries_sql = "CREATE TABLE $queries_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL DEFAULT 0,
        device_id varchar(255) NOT NULL DEFAULT '',
        video_url varchar(255) NOT NULL,
        query_status varchar(255) NOT NULL,
        query_time datetime NOT NULL,
        ip_address varchar(45) NOT NULL,
        content_type varchar(20) NOT NULL DEFAULT 'video',
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($usage_sql);
    dbDelta($queries_sql);

    error_log('XB Kuaishou Parser: Database tables created or updated.');
}

// 检查并创建前台页面
function xb_aiksjiexi_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_aiksjiexi_query_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => '快手视频解析',
            'post_content' => '[xb_aiksjiexi_query_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_aiksjiexi_enqueue_scripts');
function xb_aiksjiexi_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_aiksjiexi_query_form')) {
        wp_enqueue_style('xb_aiksjiexi_styles', plugins_url('xb-kuaishou-styles.css', __FILE__), array(), '1.0.0');
        wp_enqueue_script('xb_aiksjiexi_scripts', plugins_url('xb-kuaishou-scripts.js', __FILE__), array('jquery'), '1.0.0', true);

        wp_localize_script('xb_aiksjiexi_scripts', 'xb_aiksjiexi_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('xb_aiksjiexi_query_nonce'),
            'login_url' => wp_login_url(get_permalink())
        ));
    }
}

// 生成设备指纹，加入 Cookie 机制
function xb_aiksjiexi_get_device_id() {
    // 检查 Cookie 是否存在
    $device_id = isset($_COOKIE['xb_aiksjiexi_device_id']) ? sanitize_text_field($_COOKIE['xb_aiksjiexi_device_id']) : '';

    if (empty($device_id)) {
        // 如果 Cookie 不存在，基于 user_agent、ip_address、accept_language 生成设备指纹
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $accept_language = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
        $headers = array(
            'user_agent' => $user_agent,
            'ip_address' => $ip_address,
            'accept_language' => $accept_language,
        );
        $device_id = md5(json_encode($headers) . wp_salt('nonce')); // 使用 wp_salt 增加安全性
        // 设置 Cookie，365 天有效期
        setcookie('xb_aiksjiexi_device_id', $device_id, time() + 365 * DAY_IN_SECONDS, '/', '', is_ssl(), true);
        error_log('XB Kuaishou Parser: Generated and set new device_id in Cookie: ' . $device_id);
    } else {
        error_log('XB Kuaishou Parser: Retrieved device_id from Cookie: ' . $device_id);
    }

    return $device_id;
}

// 创建短代码 - 优化剩余次数计算
add_shortcode('xb_aiksjiexi_query_form', 'xb_aiksjiexi_query_form_shortcode');
function xb_aiksjiexi_query_form_shortcode() {
    $ad_content = get_option('xb_aiksjiexi_ad_content', '');
    $default_limit = absint(get_option('xb_aiksjiexi_default_limit', 10));
    $guest_limit = absint(get_option('xb_aiksjiexi_guest_limit', 5));
    $hide_stats = get_option('xb_aiksjiexi_hide_stats', '0') === '1';
    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $today = current_time('Y-m-d');

    // 获取设备指纹，仅用于游客
    $device_id = xb_aiksjiexi_get_device_id();

    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_aiksjiexi_usage';

    // 已登录用户：按 user_id 汇总所有设备的使用次数
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(query_count) as total_count, MAX(custom_limit) as custom_limit 
                 FROM $table_name 
                 WHERE user_id = %d AND query_date = %s",
                $user_id, $today
            )
        );
        $query_count = $row ? absint($row->total_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;
    } else {
        // 游客：按 device_id 统计
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT query_count, custom_limit FROM $table_name WHERE user_id = 0 AND device_id = %s AND query_date = %s",
                $device_id, $today
            )
        );
        $query_count = $row ? absint($row->query_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $guest_limit;
    }

    $remaining = max(0, $user_limit - $query_count);

    error_log("XB Kuaishou Parser: User ID $user_id, Device ID: $device_id, Limit: $user_limit, Count: $query_count, Remaining: $remaining");

    ob_start();
    ?>
    <div class="xb_aiksjiexi_container">
        <div class="xb_aiksjiexi_title">快手视频解析</div>

        <div class="xb_aiksjiexi_query_section">
            <?php if ($query_count >= $user_limit): ?>
                <div class="xb_aiksjiexi_message"><?php echo $user_id ? '今日使用次数已经用完，请明天再来。' : '游客的使用次数已经用完，请登录之后继续。'; ?></div>
                <?php if (!$user_id): ?>
                    <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xb_aiksjiexi_login_button">快速登录</a>
                <?php endif; ?>
            <?php else: ?>
                <form id="xb_aiksjiexi_query_form" method="post">
                    <input type="text" name="xb_aiksjiexi_url" id="xb_aiksjiexi_url" placeholder="请输入快手视频链接" required>
                    <div class="xb_aiksjiexi_cookies_section">
                        <input type="text" name="xb_aiksjiexi_cookies" id="xb_aiksjiexi_cookies" placeholder="可选：输入您的cookies值（提升解析成功率）">
                        <div class="xb_aiksjiexi_cookies_buttons">
                            <button type="button" class="xb_aiksjiexi_save_cookies_button" title="保存cookies到本地">保存</button>
                            <button type="button" class="xb_aiksjiexi_load_cookies_button" title="载入本地cookies">载入</button>
                            <button type="button" class="xb_aiksjiexi_delete_cookies_button" title="删除本地cookies">删除</button>
                        </div>
                    </div>
                    <div class="xb_aiksjiexi_button_group">
                        <button type="submit" class="xb_aiksjiexi_submit_button">开始解析</button>
                        <button type="button" class="xb_aiksjiexi_clear_button">清空</button>
                    </div>
                    <input type="hidden" name="xb_aiksjiexi_nonce" id="xb_aiksjiexi_nonce" value="<?php echo wp_create_nonce('xb_aiksjiexi_query_nonce'); ?>">
                    <input type="hidden" name="xb_aiksjiexi_device_id" id="xb_aiksjiexi_device_id" value="">
                </form>
            <?php endif; ?>
            <div class="xb_aiksjiexi_result_section">
                <div id="xb_aiksjiexi_result"></div>
                <?php if (!$hide_stats): ?>
                    <div class="xb_aiksjiexi_usage_info" style="display: none;"></div>
                <?php endif; ?>
            </div>
        </div>
        <div class="xb_aiksjiexi_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
    </div>
    <?php
    return ob_get_clean();
}

// 获取当前使用情况
add_action('wp_ajax_xb_aiksjiexi_get_usage', 'xb_aiksjiexi_get_usage');
add_action('wp_ajax_nopriv_xb_aiksjiexi_get_usage', 'xb_aiksjiexi_get_usage');
function xb_aiksjiexi_get_usage() {
    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $device_id = xb_aiksjiexi_get_device_id();
    if (empty($device_id)) {
        wp_send_json_error(array('message' => '无法获取设备指纹，请刷新页面重试！'));
        return;
    }
    $today = current_time('Y-m-d');

    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_aiksjiexi_usage';

    // 已登录用户：按 user_id 汇总所有设备的使用次数
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(query_count) as total_count, MAX(custom_limit) as custom_limit 
                 FROM $table_name 
                 WHERE user_id = %d AND query_date = %s",
                $user_id, $today
            )
        );
        $query_count = $row ? absint($row->total_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : absint(get_option('xb_aiksjiexi_default_limit', 10));
    } else {
        // 游客：按 device_id 统计
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT query_count, custom_limit FROM $table_name WHERE user_id = 0 AND device_id = %s AND query_date = %s",
                $device_id, $today
            )
        );
        $query_count = $row ? absint($row->query_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : absint(get_option('xb_aiksjiexi_guest_limit', 5));
    }

    $remaining = max(0, $user_limit - $query_count);

    wp_send_json_success(array(
        'remaining' => $remaining,
        'limit' => $user_limit,
        'is_guest' => !$user_id,
        'hide_stats' => get_option('xb_aiksjiexi_hide_stats', '0') === '1'
    ));
}

// 处理 AJAX 解析请求
add_action('wp_ajax_xb_aiksjiexi_query', 'xb_aiksjiexi_handle_query');
add_action('wp_ajax_nopriv_xb_aiksjiexi_query', 'xb_aiksjiexi_handle_query');
function xb_aiksjiexi_handle_query() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (is_user_logged_in() && (!isset($_POST['nonce']) || !wp_verify_nonce($nonce, 'xb_aiksjiexi_query_nonce'))) {
        wp_send_json_error(array('message' => '安全验证失败，请刷新页面重试！', 'is_guest' => false, 'hide_stats' => get_option('xb_aiksjiexi_hide_stats', '0') === '1'));
        return;
    }

    $url = sanitize_text_field($_POST['url']);
    $cookies = sanitize_text_field($_POST['cookies']);
    
    if (empty($url)) {
        wp_send_json_error(array('message' => '请输入有效的快手视频链接！', 'is_guest' => !is_user_logged_in(), 'hide_stats' => get_option('xb_aiksjiexi_hide_stats', '0') === '1'));
        return;
    }

    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $device_id = xb_aiksjiexi_get_device_id();
    if (empty($device_id)) {
        wp_send_json_error(array('message' => '无法获取设备指纹，请刷新页面重试！', 'is_guest' => !is_user_logged_in(), 'hide_stats' => get_option('xb_aiksjiexi_hide_stats', '0') === '1'));
        return;
    }
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $today = current_time('Y-m-d');
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aiksjiexi_usage';
    $queries_table = $wpdb->prefix . 'xb_aiksjiexi_queries';

    // 检查使用次数限制
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(query_count) as total_count, MAX(custom_limit) as custom_limit 
                 FROM $usage_table 
                 WHERE user_id = %d AND query_date = %s",
                $user_id, $today
            )
        );
        $query_count = $row ? absint($row->total_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : absint(get_option('xb_aiksjiexi_default_limit', 10));
    } else {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT query_count, custom_limit FROM $usage_table WHERE user_id = 0 AND device_id = %s AND query_date = %s",
                $device_id, $today
            )
        );
        $query_count = $row ? absint($row->query_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : absint(get_option('xb_aiksjiexi_guest_limit', 5));
    }

    if ($query_count >= $user_limit) {
        $message = $user_id ? '今日使用次数已经用完，请明天再来。' : '游客的使用次数已经用完，请登录之后继续。';
        wp_send_json_error(array(
            'message' => $message,
            'is_guest' => !$user_id,
            'hide_stats' => get_option('xb_aiksjiexi_hide_stats', '0') === '1',
            'remaining' => 0,
            'limit' => $user_limit
        ));
        return;
    }

    // 验证快手链接格式
    if (!preg_match('/https?:\/\/(v\.kuaishou\.com|www\.kuaishou\.com)/', $url)) {
        wp_send_json_error(array(
            'message' => '请输入有效的快手视频链接！',
            'is_guest' => !$user_id,
            'hide_stats' => get_option('xb_aiksjiexi_hide_stats', '0') === '1',
            'remaining' => $user_limit - $query_count,
            'limit' => $user_limit
        ));
        return;
    }

    // 检查缓存
    $transient_key = 'xb_aiksjiexi_' . md5($url . $user_id . $cookies);
    $cached_result = is_user_logged_in() ? get_transient($transient_key) : false;

    if ($cached_result !== false) {
        // 更新使用次数
        xb_aiksjiexi_update_usage_count($user_id, $device_id, $today, $usage_table);
        
        $wpdb->insert(
            $queries_table,
            array(
                'user_id' => $user_id,
                'device_id' => $device_id,
                'video_url' => $url,
                'query_status' => 'success (cached)',
                'query_time' => current_time('mysql'),
                'ip_address' => $ip_address,
                'content_type' => 'video'
            )
        );

        wp_send_json_success(array(
            'result' => $cached_result,
            'remaining' => $user_limit - ($query_count + 1),
            'limit' => $user_limit,
            'is_guest' => !$user_id,
            'hide_stats' => get_option('xb_aiksjiexi_hide_stats', '0') === '1'
        ));
        return;
    }

    // 选择API接口
    $api_url = !empty($cookies) ? 'https://www.mxnzp.com/api/ks/video/v2' : 'https://www.mxnzp.com/api/ks/video';
    $app_id = get_option('xb_aiksjiexi_app_id');
    $api_key = get_option('xb_aiksjiexi_api_key');
    $encoded_url = base64_encode($url);
    $user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36';

    $args = array(
        'body' => array(
            'url' => $encoded_url,
            'app_id' => $app_id,
            'app_secret' => $api_key
        ),
        'headers' => array(
            'User-Agent' => $user_agent,
            'Referer' => 'https://www.kuaishou.com/',
            'Origin' => 'https://www.kuaishou.com'
        ),
        'timeout' => 15,
        'sslverify' => false
    );

    // 如果有cookies，添加到请求参数中
    if (!empty($cookies)) {
        $args['body']['cookie'] = $cookies;
    }

    $response = wp_remote_get($api_url, $args);
    $query_status = 'failed';
    $content_type = 'video';

    $insert_data = array(
        'user_id' => $user_id,
        'device_id' => $device_id,
        'video_url' => $url,
        'query_status' => $query_status,
        'query_time' => current_time('mysql'),
        'ip_address' => $ip_address,
        'content_type' => $content_type
    );

    if (is_wp_error($response)) {
        $query_status = $response->get_error_message();
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data);
        error_log('XB Kuaishou Parser: Inserted error record. ID: ' . $wpdb->insert_id . ', Error: ' . $query_status);
        wp_send_json_error(array(
            'message' => '暂时无法解析，请联系客服',
            'is_guest' => !$user_id,
            'hide_stats' => get_option('xb_aiksjiexi_hide_stats', '0') === '1',
            'remaining' => $user_limit - $query_count,
            'limit' => $user_limit
        ));
        return;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    error_log('XB Kuaishou Parser: Raw API Response: ' . print_r($data, true));

    if (isset($data['code']) && $data['code'] == 1) {
        $query_status = 'success';
        $result_data = $data['data'];
        
        $insert_data['query_status'] = $query_status;
        $insert_data['content_type'] = 'video';

        // 更新使用次数
        xb_aiksjiexi_update_usage_count($user_id, $device_id, $today, $usage_table);

        $wpdb->insert($queries_table, $insert_data);
        error_log('XB Kuaishou Parser: Inserted success record. ID: ' . $wpdb->insert_id . ', URL: ' . $url);

        // 生成结果HTML
        $output = xb_aiksjiexi_generate_result_html($result_data);

        if ($user_id) {
            set_transient($transient_key, $output, 12 * HOUR_IN_SECONDS);
        }

        wp_send_json_success(array(
            'result' => $output,
            'remaining' => $user_limit - ($query_count + 1),
            'limit' => $user_limit,
            'is_guest' => !$user_id,
            'hide_stats' => get_option('xb_aiksjiexi_hide_stats', '0') === '1'
        ));
    } else {
        $query_status = isset($data['msg']) ? $data['msg'] : '未知错误';
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data);
        error_log('XB Kuaishou Parser: Inserted failed record. ID: ' . $wpdb->insert_id . ', Status: ' . $query_status);
        wp_send_json_error(array(
            'message' => '暂时无法解析，请联系客服',
            'is_guest' => !$user_id,
            'hide_stats' => get_option('xb_aiksjiexi_hide_stats', '0') === '1',
            'remaining' => $user_limit - $query_count,
            'limit' => $user_limit
        ));
    }
}

// 更新使用次数的辅助函数
function xb_aiksjiexi_update_usage_count($user_id, $device_id, $today, $usage_table) {
    global $wpdb;
    
    if ($user_id) {
        // 已登录用户：查找当前 device_id 的记录，如果不存在则插入
        $existing_row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, query_count FROM $usage_table WHERE user_id = %d AND device_id = %s AND query_date = %s",
                $user_id, $device_id, $today
            )
        );
        if ($existing_row) {
            $wpdb->update(
                $usage_table,
                array('query_count' => $existing_row->query_count + 1),
                array('id' => $existing_row->id)
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'device_id' => $device_id,
                    'query_date' => $today,
                    'query_count' => 1,
                    'custom_limit' => null
                )
            );
        }
    } else {
        // 游客：按 device_id 更新
        $existing_row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT query_count FROM $usage_table WHERE user_id = 0 AND device_id = %s AND query_date = %s",
                $device_id, $today
            )
        );
        if ($existing_row) {
            $new_count = $existing_row->query_count + 1;
            $wpdb->update(
                $usage_table,
                array('query_count' => $new_count),
                array('user_id' => 0, 'device_id' => $device_id, 'query_date' => $today)
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => 0,
                    'device_id' => $device_id,
                    'query_date' => $today,
                    'query_count' => 1,
                    'custom_limit' => null
                )
            );
        }
    }
}

// 生成结果HTML的辅助函数
function xb_aiksjiexi_generate_result_html($data) {
    $output = '<div class="xb_aiksjiexi_highlight_result">';
    $output .= '<div class="xb_aiksjiexi_title_result">视频标题：<span>' . esc_html($data['title']) . '</span></div>';
    
    // 快手视频内容
    $output .= '<div class="xb_aiksjiexi_video_content">';
    $output .= '<div class="xb_aiksjiexi_cover_image">';
    $output .= '<img src="' . esc_url($data['cover']) . '" alt="视频封面" class="xb_aiksjiexi_cover" referrerpolicy="no-referrer" crossorigin="anonymous">';
    $output .= '</div>';
    $output .= '<div class="xb_aiksjiexi_video_details">';
    $output .= '<div class="xb_aiksjiexi_duration">视频时长：' . xb_aiksjiexi_format_duration($data['duration']) . '</div>';
    $output .= '<div class="xb_aiksjiexi_dimensions">视频尺寸：' . esc_html($data['width']) . 'x' . esc_html($data['height']) . '</div>';
    $output .= '<div class="xb_aiksjiexi_quality">视频质量：<span>' . esc_html($data['quality']) . '</span></div>';
    $output .= '</div>';
    $output .= '<div class="xb_aiksjiexi_download_section">';
    $output .= '<a href="' . esc_url($data['url']) . '" class="xb_aiksjiexi_download_button" target="_blank" download="kuaishou_video.mp4" rel="noreferrer">下载视频</a>';
    $output .= '</div>';
    $output .= '</div>';
    
    $output .= '</div>';
    return $output;
}

// 格式化视频时长的辅助函数
function xb_aiksjiexi_format_duration($milliseconds) {
    $seconds = floor($milliseconds / 1000);
    $minutes = floor($seconds / 60);
    $seconds = $seconds % 60;
    return sprintf('%02d:%02d', $minutes, $seconds);
}

// 添加管理菜单
add_action('admin_menu', 'xb_aiksjiexi_admin_menu');
function xb_aiksjiexi_admin_menu() {
    add_menu_page(
        '快手视频解析设置',
        '快手视频解析',
        'manage_options',
        'xb_aiksjiexi_settings',
        'xb_aiksjiexi_settings_page',
        'dashicons-video-alt3',
        80
    );
    add_submenu_page(
        'xb_aiksjiexi_settings',
        '解析记录',
        '解析记录',
        'manage_options',
        'xb_aiksjiexi_all_records',
        'xb_aiksjiexi_all_records_page'
    );
}

// 插件设置页面
function xb_aiksjiexi_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['xb_aiksjiexi_save_settings'])) {
        check_admin_referer('xb_aiksjiexi_settings_nonce');
        
        update_option('xb_aiksjiexi_app_id', sanitize_text_field($_POST['xb_aiksjiexi_app_id']));
        update_option('xb_aiksjiexi_api_key', sanitize_text_field($_POST['xb_aiksjiexi_api_key']));
        $new_limit = absint($_POST['xb_aiksjiexi_default_limit']);
        if ($new_limit > 0) {
            update_option('xb_aiksjiexi_default_limit', $new_limit);
        }
        $new_guest_limit = absint($_POST['xb_aiksjiexi_guest_limit']);
        if ($new_guest_limit >= 0) {
            update_option('xb_aiksjiexi_guest_limit', $new_guest_limit);
        }
        update_option('xb_aiksjiexi_ad_content', wp_kses_post($_POST['xb_aiksjiexi_ad_content']));
        update_option('xb_aiksjiexi_hide_stats', isset($_POST['xb_aiksjiexi_hide_stats']) ? '1' : '0');
        
        echo '<div id="xb_aiksjiexi_settings_notice" class="updated"><p>设置已保存！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_aiksjiexi_settings_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    ?>
    <div class="wrap">
        <div class="xb_aiksjiexi_admin_title">快手视频解析设置</div>
        <form method="post">
            <?php wp_nonce_field('xb_aiksjiexi_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_aiksjiexi_app_id">API App ID</label></th>
                    <td><input type="text" name="xb_aiksjiexi_app_id" id="xb_aiksjiexi_app_id" value="<?php echo esc_attr(get_option('xb_aiksjiexi_app_id')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_aiksjiexi_api_key">API 密钥</label></th>
                    <td><input type="text" name="xb_aiksjiexi_api_key" id="xb_aiksjiexi_api_key" value="<?php echo esc_attr(get_option('xb_aiksjiexi_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_aiksjiexi_default_limit">默认每日解析次数（登录用户）</label></th>
                    <td><input type="number" name="xb_aiksjiexi_default_limit" id="xb_aiksjiexi_default_limit" value="<?php echo esc_attr(get_option('xb_aiksjiexi_default_limit', 10)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_aiksjiexi_guest_limit">默认每日解析次数（游客）</label></th>
                    <td><input type="number" name="xb_aiksjiexi_guest_limit" id="xb_aiksjiexi_guest_limit" value="<?php echo esc_attr(get_option('xb_aiksjiexi_guest_limit', 5)); ?>" min="0"></td>
                </tr>
                <tr>
                    <th><label for="xb_aiksjiexi_ad_content">公告内容</label></th>
                    <td><textarea name="xb_aiksjiexi_ad_content" id="xb_aiksjiexi_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_aiksjiexi_ad_content')); ?></textarea></td>
                </tr>
                <tr>
                    <th><label for="xb_aiksjiexi_hide_stats">隐藏前台统计</label></th>
                    <td><input type="checkbox" name="xb_aiksjiexi_hide_stats" id="xb_aiksjiexi_hide_stats" value="1" <?php checked(get_option('xb_aiksjiexi_hide_stats', '0'), '1'); ?>> 隐藏今日剩余解析次数</td>
                </tr>
            </table>
            <p><input type="submit" name="xb_aiksjiexi_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        
        <div style="margin-top: 30px; padding: 15px; background: #fff; border-left: 4px solid #ff5000; box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);">
            <p style="margin: 0; font-size: 14px; color: #666;">
                这是免费开源的插件，基于第三方接口，请考虑使用。 联系方式QQ群：16966111
            </p>
        </div>
    </div>
    <?php
}

// 所有解析记录页面
function xb_aiksjiexi_all_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aiksjiexi_usage';
    $queries_table = $wpdb->prefix . 'xb_aiksjiexi_queries';
    $user_id = isset($_POST['xb_aiksjiexi_user_id']) ? (int)$_POST['xb_aiksjiexi_user_id'] : null;
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    // 删除单条记录
    if (isset($_POST['xb_aiksjiexi_delete_record']) && isset($_POST['record_id'])) {
        check_admin_referer('xb_aiksjiexi_delete_record_nonce');
        $record_id = absint($_POST['record_id']);
        
        $wpdb->delete($queries_table, array('id' => $record_id), array('%d'));
        error_log('XB Kuaishou Parser: Deleted single record ID: ' . $record_id);

        echo '<div id="xb_aiksjiexi_delete_notice" class="updated"><p>记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_aiksjiexi_delete_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 删除用户/游客全部记录
    if (isset($_POST['xb_aiksjiexi_delete_all_records']) && $user_id !== null) {
        check_admin_referer('xb_aiksjiexi_delete_all_records_nonce');
        
        $wpdb->delete($queries_table, array('user_id' => $user_id), array('%d'));
        error_log('XB Kuaishou Parser: Deleted all records for user_id: ' . $user_id);

        echo '<div id="xb_aiksjiexi_delete_all_notice" class="updated"><p>所有查询记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_aiksjiexi_delete_all_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 删除所有记录
    if (isset($_POST['xb_aiksjiexi_delete_all_global_records'])) {
        check_admin_referer('xb_aiksjiexi_delete_all_global_records_nonce');
        
        $wpdb->query("TRUNCATE TABLE $queries_table");
        error_log('XB Kuaishou Parser: Truncated queries table.');

        echo '<div id="xb_aiksjiexi_delete_all_global_notice" class="updated"><p>所有用户记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_aiksjiexi_delete_all_global_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 保存用户/游客自定义限制
    if (isset($_POST['xb_aiksjiexi_save_user_limit']) && $user_id !== null) {
        check_admin_referer('xb_aiksjiexi_user_limit_nonce');
        $custom_limit = isset($_POST['xb_aiksjiexi_custom_limit']) ? absint($_POST['xb_aiksjiexi_custom_limit']) : null;

        $existing = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id FROM $usage_table WHERE user_id = %d AND query_date = %s LIMIT 1",
                $user_id,
                current_time('Y-m-d')
            )
        );

        if ($existing) {
            $wpdb->update(
                $usage_table,
                array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
                array('id' => $existing->id)
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'device_id' => '',
                    'query_date' => current_time('Y-m-d'),
                    'query_count' => 0,
                    'custom_limit' => $custom_limit === 0 ? null : $custom_limit
                )
            );
        }

        echo '<div id="xb_aiksjiexi_limit_notice" class="updated"><p>解析限制已更新！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_aiksjiexi_limit_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    $stats = array();
    $where_clause = $user_id !== null ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : '';
    $stats['total_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table $where_clause");
    $stats['success_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table WHERE query_status LIKE 'success%' " . ($user_id !== null ? $wpdb->prepare('AND user_id = %d', $user_id) : ''));
    $stats['failed_queries'] = $stats['total_queries'] - $stats['success_queries'];
    $stats['today_queries'] = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $queries_table WHERE DATE(query_time) = %s " . ($user_id !== null ? 'AND user_id = %d' : ''), current_time('Y-m-d'), $user_id)
    );

    $offset = ($paged - 1) * $per_page;
    $query = $user_id !== null
        ? $wpdb->prepare("SELECT id, user_id, device_id, video_url, query_status, query_time, ip_address, content_type FROM $queries_table WHERE user_id = %d ORDER BY query_time DESC LIMIT %d, %d", $user_id, $offset, $per_page)
        : $wpdb->prepare("SELECT id, user_id, device_id, video_url, query_status, query_time, ip_address, content_type FROM $queries_table ORDER BY query_time DESC LIMIT %d, %d", $offset, $per_page);
    $records = $wpdb->get_results($query);
    $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table" . ($user_id !== null ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : ''));
    $total_pages = ceil($total_records / $per_page);

    error_log('XB Kuaishou Parser: Fetched records. User ID: ' . ($user_id !== null ? $user_id : 'All') . ', Total records: ' . $total_records);

    $user_info = $user_id && $user_id !== 0 ? get_userdata($user_id) : null;
    ?>
    <div class="wrap">
        <div class="xb_aiksjiexi_admin_title">所有解析记录</div>
        <form method="post">
            <p>
                <label for="xb_aiksjiexi_user_id">输入用户 ID（留空显示所有记录，0 为游客）：</label>
                <input type="number" name="xb_aiksjiexi_user_id" id="xb_aiksjiexi_user_id" value="<?php echo esc_attr($user_id !== null ? $user_id : ''); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <form method="post">
            <?php wp_nonce_field('xb_aiksjiexi_delete_all_global_records_nonce'); ?>
            <p><input type="submit" name="xb_aiksjiexi_delete_all_global_records" class="button-secondary" value="删除所有记录" onclick="return confirm('确定删除所有用户的记录吗？此操作仅删除记录，不影响使用次数！');"></p>
        </form>

        <?php if ($user_id !== null && ($user_id === 0 || $user_info)): ?>
            <div class="xb_aiksjiexi_subtitle"><?php echo $user_id === 0 ? '游客' : '用户：' . esc_html($user_info->user_login); ?> (ID: <?php echo $user_id; ?>)</div>
            <form method="post">
                <?php wp_nonce_field('xb_aiksjiexi_user_limit_nonce'); ?>
                <p>
                    <label for="xb_aiksjiexi_custom_limit">设置自定义每日解析次数（0 表示使用默认值）：</label>
                    <input type="number" name="xb_aiksjiexi_custom_limit" id="xb_aiksjiexi_custom_limit" min="0">
                    <input type="hidden" name="xb_aiksjiexi_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_aiksjiexi_save_user_limit" class="button-primary" value="保存">
                </p>
            </form>
            <form method="post">
                <?php wp_nonce_field('xb_aiksjiexi_delete_all_records_nonce'); ?>
                <input type="hidden" name="xb_aiksjiexi_user_id" value="<?php echo esc_attr($user_id); ?>">
                <p><input type="submit" name="xb_aiksjiexi_delete_all_records" class="button-secondary" value="删除当前用户记录" onclick="return confirm('确定删除此用户的所有记录吗？此操作仅删除记录，不影响使用次数！');"></p>
            </form>
        <?php endif; ?>

        <div class="xb_aiksjiexi_stats">
            <p>总解析次数：<?php echo esc_html($stats['total_queries']); ?></p>
            <p>成功解析次数：<?php echo esc_html($stats['success_queries']); ?></p>
            <p>失败解析次数：<?php echo esc_html($stats['failed_queries']); ?></p>
            <p>今日解析次数：<?php echo esc_html($stats['today_queries']); ?></p>
        </div>

        <table class="widefat">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>设备 ID</th>
                    <th>解析时间</th>
                    <th>视频链接</th>
                    <th>内容类型</th>
                    <th>状态</th>
                    <th>IP 地址</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="8">暂无解析记录。</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td><?php echo $record->user_id === 0 ? '游客' : esc_html($record->user_id); ?></td>
                            <td><?php echo esc_html($record->device_id); ?></td>
                            <td><?php echo esc_html($record->query_time); ?></td>
                            <td><?php echo esc_html($record->video_url); ?></td>
                            <td><?php echo esc_html($record->content_type); ?></td>
                            <td><?php echo esc_html($record->query_status); ?></td>
                            <td><?php echo esc_html($record->ip_address); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_aiksjiexi_delete_record_nonce'); ?>
                                    <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>">
                                    <input type="submit" name="xb_aiksjiexi_delete_record" class="button-link" value="删除" onclick="return confirm('确定删除此记录吗？此操作仅删除记录，不影响使用次数！');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}
?>