<?php
/*
Plugin Name: 违禁词查询插件
Description: 广告法违禁词查询，支持通用、平台和广告违规词分类管理与检测
Version: 2.4
Author: summer
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Create custom tables on plugin activation
register_activation_hook(__FILE__, 'forbidden_words_install');

function forbidden_words_install() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    
    $tables = [
        'general' => "CREATE TABLE {$wpdb->prefix}forbidden_words_general (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            word VARCHAR(255) NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY word (word)
        ) $charset_collate;",
        'platform' => "CREATE TABLE {$wpdb->prefix}forbidden_words_platform (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            word VARCHAR(255) NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY word (word)
        ) $charset_collate;",
        'advertising' => "CREATE TABLE {$wpdb->prefix}forbidden_words_advertising (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            word VARCHAR(255) NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY word (word)
        ) $charset_collate;",
        'keywords' => "CREATE TABLE {$wpdb->prefix}forbidden_words_keywords (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            word VARCHAR(255) NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY word (word)
        ) $charset_collate;"
    ];

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    foreach ($tables as $table) {
        dbDelta($table);
    }

    // Create frontend page with shortcode if it doesn't exist
    $page_title = '违规词检测';
    $shortcode = '[forbidden_words_form]';
    $page_exists = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status = 'publish' AND post_content LIKE %s",
            '%' . $wpdb->esc_like($shortcode) . '%'
        )
    );

    if (!$page_exists) {
        $page_args = [
            'post_title'    => $page_title,
            'post_content'  => $shortcode,
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        ];
        wp_insert_post($page_args);
    }
}

// Add admin menu
add_action('admin_menu', 'forbidden_words_menu');

function forbidden_words_menu() {
    add_menu_page('违禁词查询', '违禁词查询', 'manage_options', 'forbidden-words', 'forbidden_words_admin_page', 'dashicons-shield');
}

// Admin page for managing forbidden words and keywords
function forbidden_words_admin_page() {
    if (!current_user_can('manage_options')) {
        wp_die('您无权访问此页面');
    }

    global $wpdb;
    $tables = [
        'general' => $wpdb->prefix . 'forbidden_words_general',
        'platform' => $wpdb->prefix . 'forbidden_words_platform',
        'advertising' => $wpdb->prefix . 'forbidden_words_advertising',
        'keywords' => $wpdb->prefix . 'forbidden_words_keywords'
    ];

    // Handle form submissions
    foreach (['general', 'platform', 'advertising', 'keywords'] as $type) {
        if (isset($_POST["forbidden_words_{$type}"])) {
            $words = explode(',', sanitize_text_field($_POST["forbidden_words_{$type}"]));
            $wpdb->query("TRUNCATE TABLE {$tables[$type]}");
            foreach (array_filter(array_map('trim', $words)) as $word) {
                $wpdb->insert($tables[$type], ['word' => $word]);
            }
            echo "<div class='fw-updated'><p>" . esc_html(ucfirst($type)) . " 已保存</p></div>";
        }
    }

    // Fetch word counts
    $counts = [];
    foreach ($tables as $type => $table) {
        $counts[$type] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
    }
    ?>
    <div class="fw-wrap">
        <h2>违禁词与关键词管理</h2>
        <style>
            .fw-wrap { max-width: 800px; margin: 20px auto; font-family: Arial, sans-serif; }
            .fw-form-group { margin-bottom: 20px; }
            .fw-form-group label { display: block; font-weight: bold; margin-bottom: 5px; color: #333; }
            .fw-form-group textarea { width: 100%; height: 150px; padding: 10px; border: 1px solid #ddd; border-radius: 5px; resize: vertical; }
            .fw-button-primary { background-color: #007cba; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
            .fw-button-primary:hover { background-color: #005a87; }
            .fw-updated { background-color: #dff0d8; color: #3c763d; padding: 10px; margin-bottom: 20px; border-radius: 5px; }
            .fw-count { color: #666; margin-bottom: 10px; }
        </style>
        
        <div class="fw-form-group">
            <label for="fw-general">通用违禁词（用逗号分隔）：</label>
            <p class="fw-count">当前数量：<?php echo esc_html($counts['general']); ?></p>
            <form method="post" action="">
                <textarea id="fw-general" name="forbidden_words_general"><?php
                    $words = $wpdb->get_col("SELECT word FROM {$tables['general']}");
                    echo esc_textarea(implode(',', $words));
                ?></textarea>
                <input type="submit" class="fw-button-primary" value="保存通用违禁词" />
            </form>
        </div>

        <div class="fw-form-group">
            <label for="fw-platform">平台违禁词（用逗号分隔）：</label>
            <p class="fw-count">当前数量：<?php echo esc_html($counts['platform']); ?></p>
            <form method="post" action="">
                <textarea id="fw-platform" name="forbidden_words_platform"><?php
                    $words = $wpdb->get_col("SELECT word FROM {$tables['platform']}");
                    echo esc_textarea(implode(',', $words));
                ?></textarea>
                <input type="submit" class="fw-button-primary" value="保存平台违禁词" />
            </form>
        </div>

        <div class="fw-form-group">
            <label for="fw-advertising">广告违禁词（用逗号分隔）：</label>
            <p class="fw-count">当前数量：<?php echo esc_html($counts['advertising']); ?></p>
            <form method="post" action="">
                <textarea id="fw-advertising" name="forbidden_words_advertising"><?php
                    $words = $wpdb->get_col("SELECT word FROM {$tables['advertising']}");
                    echo esc_textarea(implode(',', $words));
                ?></textarea>
                <input type="submit" class="fw-button-primary" value="保存广告违禁词" />
            </form>
        </div>

        <div class="fw-form-group">
            <label for="fw-keywords">关键词（用逗号分隔，触发即阻止检测）：</label>
            <p class="fw-count">当前数量：<?php echo esc_html($counts['keywords']); ?></p>
            <form method="post" action="">
                <textarea id="fw-keywords" name="forbidden_words_keywords"><?php
                    $words = $wpdb->get_col("SELECT word FROM {$tables['keywords']}");
                    echo esc_textarea(implode(',', $words));
                ?></textarea>
                <input type="submit" class="fw-button-primary" value="保存关键词" />
            </form>
        </div>
    </div>
    <?php
}

// Shortcode for frontend form
add_shortcode('forbidden_words_form', 'forbidden_words_form_handler');

function forbidden_words_form_handler() {
    global $wpdb;
    $tables = [
        'general' => $wpdb->prefix . 'forbidden_words_general',
        'platform' => $wpdb->prefix . 'forbidden_words_platform',
        'advertising' => $wpdb->prefix . 'forbidden_words_advertising',
        'keywords' => $wpdb->prefix . 'forbidden_words_keywords'
    ];
    
    $counts = [];
    foreach ($tables as $type => $table) {
        $counts[$type] = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table");
    }
    
    ob_start();
    ?>
    <div class="fw-container">
        <div class="fw-title">违规禁用词检测工具</div>
        <p class="fw-subtitle">请输入文本，选择检测类型，快速识别违规词</p>
        
        <div class="fw-type-toggle">
            <button class="fw-toggle-btn active" data-type="general">通用</button>
            <button class="fw-toggle-btn" data-type="platform">平台</button>
            <button class="fw-toggle-btn" data-type="advertising">广告</button>
        </div>
        
        <textarea id="fw-sentence" name="sentence" placeholder="在此输入文本，例如产品描述、广告文案等..."></textarea>
        
        <div class="fw-info">
            <p class="fw-stats">当前禁用词数量 - 通用：<?php echo esc_html($counts['general']); ?> | 平台：<?php echo esc_html($counts['platform']); ?> | 广告：<?php echo esc_html($counts['advertising']); ?></p>
            <p class="fw-note">部分词语使用需视具体场景而定，并不是一定不能用，通用(包括大部分场景可能都不支持的词汇)，平台(各社交、电商平台)，广告(广告法)。<br><span style="color: #ff0000; font-size: 18px;">如果你想更全面的检测，请用我们的<a href="https://www.wujiit.com/wenbenanquan" target="_blank">AI文本安全审查</a>工具</span>。</p>
        </div>
        
        <div class="fw-button-wrapper">
            <button class="fw-submit-button">查询</button>
            <button class="fw-clear-button">清空</button>
        </div>
        
        <div class="fw-result"></div>
        
        <style>
            :root {
                --primary: #2563eb;
                --primary-dark: #1d4ed8;
                --secondary: #6b7280;
                --secondary-dark: #4b5563;
                --danger: #ef4444;
                --background: #f8fafc;
                --card: #ffffff;
                --text: #1e293b;
                --text-light: #64748b;
            }
            
            .fw-container {
                max-width: 1000px;
                margin: auto;
                padding: 30px;
                background: var(--background);
                border-radius: 16px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            }
            
            .fw-title {
                font-size: 2.2rem;
                color: var(--text);
                text-align: center;
                margin-bottom: 10px;
                font-weight: 600;
                letter-spacing: -0.025em;
            }
            
            .fw-subtitle {
                font-size: 1.1rem;
                color: var(--text-light);
                text-align: center;
                margin-bottom: 30px;
                line-height: 1.5;
            }
            
            .fw-type-toggle {
                display: flex;
                gap: 12px;
                justify-content: center;
                margin-bottom: 30px;
                flex-wrap: wrap;
            }
            
            .fw-toggle-btn {
                padding: 12px 24px;
                border: 2px solid var(--primary);
                border-radius: 12px;
                background: var(--card);
                color: var(--primary);
                cursor: pointer;
                font-size: 1rem;
                font-weight: 500;
                transition: all 0.3s ease;
                position: relative;
                overflow: hidden;
            }
            
            .fw-toggle-btn.active {
                background: var(--primary);
                color: #fff;
                box-shadow: 0 2px 10px rgba(37, 99, 235, 0.3);
            }
            
            .fw-toggle-btn:hover {
                background: var(--primary);
                color: #fff;
                transform: translateY(-2px);
            }
            
            #fw-sentence {
                width: 100%;
                min-height: 180px;
                padding: 15px;
                border: 1px solid #e2e8f0;
                border-radius: 12px;
                background: var(--card);
                color: var(--text);
                resize: vertical;
                margin-bottom: 20px;
                box-sizing: border-box;
                font-size: 1rem;
                font-family: inherit;
                transition: border-color 0.3s ease, box-shadow 0.3s ease;
            }
            
            #fw-sentence:focus {
                outline: none;
                border-color: var(--primary);
                box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.2);
            }
            
            .fw-info {
                margin-bottom: 25px;
                text-align: center;
            }
            
            .fw-stats {
                color: var(--text-light);
                font-size: 0.95rem;
                margin-bottom: 10px;
            }
            
            .fw-note {
                color: var(--text-light);
                font-size: 0.9rem;
                line-height: 1.6;
            }
            
            .fw-note a {
                color: var(--primary);
                text-decoration: none;
                transition: color 0.3s ease;
            }
            
            .fw-note a:hover {
                color: var(--primary-dark);
                text-decoration: underline;
            }
            
            .fw-button-wrapper {
                display: flex;
                gap: 15px;
                justify-content: center;
                flex-wrap: wrap;
            }
            
            .fw-submit-button, .fw-clear-button {
                padding: 14px 35px;
                border: none;
                border-radius: 12px;
                color: #fff;
                cursor: pointer;
                font-size: 1.1rem;
                font-weight: 500;
                transition: all 0.3s ease;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
                min-width: 140px;
            }
            
            .fw-submit-button {
                background: var(--primary);
            }
            
            .fw-submit-button:hover {
                background: var(--primary-dark);
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(37, 99, 235, 0.25);
            }
            
            .fw-clear-button {
                background: var(--secondary);
            }
            
            .fw-clear-button:hover {
                background: var(--secondary-dark);
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(107, 114, 128, 0.25);
            }
            
            .fw-result {
                margin-top: 30px;
                padding: 20px;
                border-radius: 12px;
                background: var(--card);
                min-height: 60px;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
                line-height: 1.6;
            }
            
            .fw-result h3 {
                color: var(--text);
                font-size: 1.5rem;
                margin-top: 0;
                margin-bottom: 15px;
            }
            
            .forbidden-word {
                color: var(--danger);
                font-weight: 600;
                background: #fee2e2;
                padding: 3px 8px;
                border-radius: 6px;
                display: inline-block;
            }
            
            @media (max-width: 768px) {
                .fw-container {
                    margin: 20px;
                    padding: 20px;
                }
                .fw-title {
                    font-size: 1.8rem;
                }
                .fw-subtitle {
                    font-size: 1rem;
                }
                .fw-type-toggle {
                    flex-direction: column;
                    gap: 10px;
                }
                .fw-toggle-btn {
                    width: 100%;
                    padding: 12px;
                }
                .fw-button-wrapper {
                    flex-direction: column;
                    gap: 10px;
                }
                .fw-submit-button, .fw-clear-button {
                    width: 100%;
                    padding: 12px;
                }
            }
            
            @media (max-width: 480px) {
                .fw-container {
                    margin: 10px;
                    padding: 15px;
                }
                .fw-title {
                    font-size: 1.5rem;
                }
                .fw-subtitle {
                    font-size: 0.9rem;
                }
                #fw-sentence {
                    min-height: 140px;
                    font-size: 0.95rem;
                }
                .fw-result h3 {
                    font-size: 1.3rem;
                }
            }
        </style>
        
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                let currentType = 'general';
                
                function forbidden_words_set_type(type) {
                    currentType = type;
                    document.querySelectorAll('.fw-toggle-btn').forEach(btn => {
                        btn.classList.remove('active');
                        if (btn.dataset.type === type) {
                            btn.classList.add('active');
                        }
                    });
                }
                
                document.querySelectorAll('.fw-toggle-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        forbidden_words_set_type(this.dataset.type);
                    });
                });
                
                document.querySelector('.fw-submit-button').addEventListener('click', function() {
                    forbidden_words_query();
                });
                
                document.querySelector('.fw-clear-button').addEventListener('click', function() {
                    forbidden_words_clear();
                });
                
                function forbidden_words_query() {
                    const sentence = document.getElementById('fw-sentence').value;
                    if (!sentence.trim()) {
                        document.querySelector('.fw-result').innerHTML = '<p style="color: var(--danger)">请输入要检测的文本</p>';
                        return;
                    }
                    
                    const hasCode = /<\?php|<\/?style>|<script|function\s|<a\s|<\/?[^>]+>/.test(sentence);
                    if (hasCode) {
                        document.querySelector('.fw-result').innerHTML = 
                            '<h3>查询结果</h3><p><span style="color: var(--danger)">文中含有代码或特殊符号，不支持检测</span><br>' + 
                            forbidden_words_escape_html(sentence) + '</p>';
                        return;
                    }
                    
                    fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: 'action=forbidden_words_check&sentence=' + encodeURIComponent(sentence) + '&type=' + encodeURIComponent(currentType)
                    })
                    .then(response => response.json())
                    .then(data => {
                        document.querySelector('.fw-result').innerHTML = 
                            '<h3>查询结果（违禁词红色标注）</h3><p>' + data.result + '</p>';
                    })
                    .catch(error => {
                        document.querySelector('.fw-result').innerHTML = 
                            '<p style="color: var(--danger)">检测失败，请稍后再试</p>';
                    });
                }
                
                function forbidden_words_clear() {
                    document.getElementById('fw-sentence').value = '';
                    document.querySelector('.fw-result').innerHTML = '';
                }
                
                function forbidden_words_escape_html(str) {
                    return str.replace(/&/g, '&amp;')
                              .replace(/</g, '&lt;')
                              .replace(/>/g, '&gt;')
                              .replace(/"/g, '&quot;')
                              .replace(/'/g, '&#039;');
                }
            });
        </script>
    </div>
    <?php
    return ob_get_clean();
}

// AJAX handler for forbidden words and keywords check
add_action('wp_ajax_forbidden_words_check', 'forbidden_words_ajax_check');
add_action('wp_ajax_nopriv_forbidden_words_check', 'forbidden_words_ajax_check');

function forbidden_words_ajax_check() {
    global $wpdb;
    $sentence = sanitize_text_field($_POST['sentence']);
    $type = sanitize_text_field($_POST['type']);
    
    $tables = [
        'general' => $wpdb->prefix . 'forbidden_words_general',
        'platform' => $wpdb->prefix . 'forbidden_words_platform',
        'advertising' => $wpdb->prefix . 'forbidden_words_advertising',
        'keywords' => $wpdb->prefix . 'forbidden_words_keywords'
    ];
    
    // Check for keywords first
    $keywords = $wpdb->get_col("SELECT word FROM {$tables['keywords']}");
    foreach ($keywords as $word) {
        if (stripos($sentence, $word) !== false) {
            wp_send_json(['result' => '<span style="color: #ef4444;">文中含有关键词，不支持检查，请重新编辑。</span>']);
            return;
        }
    }
    
    // Check forbidden words
    $table = isset($tables[$type]) ? $tables[$type] : $tables['general'];
    $words = $wpdb->get_col("SELECT word FROM $table");
    
    $result = $sentence;
    foreach ($words as $word) {
        $result = preg_replace('/' . preg_quote(trim($word), '/') . '/i', 
            '<span class="forbidden-word">' . esc_html($word) . '</span>', $result);
    }
    
    wp_send_json(['result' => $result]);
}
?>