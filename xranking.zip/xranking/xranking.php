<?php
/*
Plugin Name: 点赞排行榜
Description: 一个用于显示选手资料并实现点赞排行榜的WordPress插件。
Version: 1.2
Author: summer
Author URI: https://www.jingxialai.com/
*/

if (!defined('ABSPATH')) {
    exit;
}

// 在插件激活时创建对应的前台页面
function xszl_create_contestant_page_on_activation() {
    ob_start(); // 开启输出缓冲
    // 检查页面是否已经存在，如果不存在则创建页面
    $page = get_page_by_title( '点赞排行榜' );

    if ( ! $page ) {
        // 创建页面数组
        $page = array(
            'post_title'    => '点赞排行榜',
            'post_content'  => '[xszl_all_contestants]',
            'post_status'   => 'publish',
            'post_author'   => 1, // 设置为你想要作为页面作者的用户ID
            'post_type'     => 'page',
        );

        // 插入页面并获取其ID
        $page_id = wp_insert_post( $page );

        // 为了防止生成的页面被移动到回收站，将其设置为永久状态
        update_post_meta( $page_id, '_wp_page_template', 'default' );
    }
    
    ob_get_clean(); // 清空输出缓冲

    // 返回结果
    return;
}

register_activation_hook( __FILE__, 'xszl_create_contestant_page_on_activation' );


// 创建选手自定义文章类型
function xszl_create_contestant_post_type() {
    $labels = array(
        'name'               => '选手',
        'singular_name'      => '选手',
        'menu_name'          => '选手',
        'name_admin_bar'     => '选手',
        'add_new'            => '添加新选手',
        'add_new_item'       => '添加新选手',
        'new_item'           => '新选手',
        'edit_item'          => '编辑选手',
        'view_item'          => '查看选手',
        'all_items'          => '所有选手',
        'search_items'       => '搜索选手',
        'parent_item_colon'  => '父级选手',
        'not_found'          => '未找到选手',
        'not_found_in_trash' => '回收站中未找到选手'
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'contestant' ),
        //'rewrite'            => false, // 设置为 false
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'thumbnail' )
    );

    register_post_type( 'xszl_contestant', $args );
}
add_action( 'init', 'xszl_create_contestant_post_type' );



function xszl_add_contestant_custom_fields() {
    add_meta_box(
        'xszl_contestant_fields',
        '选手信息',
        'xszl_display_contestant_custom_fields',
        'xszl_contestant',
        'normal',
        'default'
    );
}
add_action( 'add_meta_boxes', 'xszl_add_contestant_custom_fields' );

function xszl_display_contestant_custom_fields( $post ) {
    // 添加 nonce 字段以验证表单提交
    wp_nonce_field( basename( __FILE__ ), 'xszl_contestant_fields_nonce' );

    // 获取已保存的字段值
    $age = get_post_meta( $post->ID, 'xszl_age', true );
    $address = get_post_meta( $post->ID, 'xszl_address', true );
    $works = get_post_meta( $post->ID, 'xszl_works', true );
    $bio = get_post_meta( $post->ID, 'xszl_bio', true );
    $likes = get_post_meta( $post->ID, 'xszl_likes', true ); // 获取点赞数量

    // 表单
    ?>
    <p>
        <label for="xszl_age">年龄：</label>
        <input type="text" id="xszl_age" name="xszl_age" value="<?php echo $age; ?>">
    </p>
    <p>
        <label for="xszl_address">地址：</label>
        <input type="text" id="xszl_address" name="xszl_address" value="<?php echo $address; ?>">
    </p>
    <p>
        <label for="xszl_works">作品：</label><br>
        <?php
            $works_editor_settings = array(
                'textarea_name' => 'xszl_works',
                'textarea_rows' => 5,
                'wpautop'       => false
            );
            wp_editor( $works, 'xszl_works_editor', $works_editor_settings );
        ?>
    </p>
    <p>
        <label for="xszl_bio">简介：</label><br>
        <?php
            $bio_editor_settings = array(
                'textarea_name' => 'xszl_bio',
                'textarea_rows' => 5,
                'wpautop'       => false
            );
            wp_editor( $bio, 'xszl_bio_editor', $bio_editor_settings );
        ?>
    </p>
    <p>
        <label for="xszl_likes">点赞数量：</label>
        <input type="text" id="xszl_likes" name="xszl_likes" value="<?php echo $likes ? $likes : 0; ?>" readonly> <!-- 显示点赞数量 -->
    </p>
    <?php
}
// 保存选手的自定义字段
function xszl_save_contestant_custom_fields( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    // 检查是否为新增选手
    $is_new_contestant = false;
    if ( isset( $_POST['post_type'] ) && 'xszl_contestant' == $_POST['post_type'] ) {
        if ( ! isset( $_POST['xszl_contestant_fields_nonce'] ) || ! wp_verify_nonce( $_POST['xszl_contestant_fields_nonce'], basename( __FILE__ ) ) ) {
            return $post_id;
        }
        // 如果是新增选手，并且点赞数量未设置，则将点赞数量设置为 0
        if ( ! get_post_meta( $post_id, 'xszl_likes', true ) ) {
            update_post_meta( $post_id, 'xszl_likes', 0 );
        }
        $is_new_contestant = true;
    }

    // 仅在新增选手或更新选手时才保存字段值
    if ( isset( $_POST['xszl_age'] ) ) {
        update_post_meta( $post_id, 'xszl_age', sanitize_text_field( $_POST['xszl_age'] ) );
    }
    if ( isset( $_POST['xszl_address'] ) ) {
        update_post_meta( $post_id, 'xszl_address', sanitize_text_field( $_POST['xszl_address'] ) );
    }
    if ( isset( $_POST['xszl_works'] ) ) {
        update_post_meta( $post_id, 'xszl_works', wp_kses_post( $_POST['xszl_works'] ) );
    }
    if ( isset( $_POST['xszl_bio'] ) ) {
        update_post_meta( $post_id, 'xszl_bio', wp_kses_post( $_POST['xszl_bio'] ) );
    }

    // 如果是新增选手，则需要刷新文章缓存以确保显示在前台页面
    if ( $is_new_contestant ) {
        wp_cache_delete( $post_id, 'posts' );
    }
}

add_action( 'save_post', 'xszl_save_contestant_custom_fields' );





function xszl_display_all_contestants() {
    ob_start(); ?>
 <div class="xszl-plugin-container">
       <style>
.xszl-plugin-container {
}

/* 标题样式 */
.xszl-plugin-container .all-contestants h2 {
    font-size: 18px;
    margin-bottom: 10px;
    text-align: center;
}

/* 表格样式 */
.xszl-plugin-container .contestants-table {
    width: 100%;
    border-collapse: collapse;
    text-align: center;
}

.xszl-plugin-container .contestants-table th,
.xszl-plugin-container .contestants-table td {
    padding: 10px;
    border: 1px solid #ccc;
}

.xszl-plugin-container .contestants-table th {
    background-color: #6454ef;
    color: #fff;
    font-weight: bold;
}

.xszl-plugin-container .contestants-table td {
    text-align: center;
    vertical-align: middle;
}

/* 表格斑马线样式 */
.xszl-plugin-container .contestants-table tbody tr:nth-child(even) {
    background-color: #f9f9f9;
}

/* 头像样式 */
.xszl-plugin-container .contestants-table img {
    max-width: 100px;
    height: auto;
    border-radius: 10%;
    display: block;
    margin: 0 auto;
}

/* 点赞按钮样式 */
.xszl-plugin-container .like-btn {
    display: inline-block;
    padding: 5px 10px;
    background-color: rgba(15,138,8,80%);
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s ease, color 0.3s ease;
}

.xszl-plugin-container .like-btn:hover {
    background-color: rgba(0, 123, 255, 1);
    color: #fff;
}

/* 修复通知样式 */
.like-notification {
    margin-top: 20px;
    font-size: 16px;
    font-weight: bold;
    text-align: center; /* 居中对齐 */
    display: block; /* 确保通知文字显示为块级元素 */
    width: 100%; /* 设置通知元素宽度为 100% */
}

/* 简介栏样式 */
.xszl-plugin-container .contestants-table td:nth-child(6) {
    max-width: 200px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: normal;
}

/* 去除超链接文字下划线 */
.xszl-plugin-container .like-btn {
    text-decoration: none !important;
}
</style>
    <div class="all-contestants">
        <div id="like-notification"></div>
        <h2>按点赞数量排名(同一天可以给每一位选手各点赞一次)</h2>
        <table class="contestants-table">
            <thead>
                <tr>
                    <th>排名</th>
                    <th>头像</th>
                    <th>姓名</th>
                    <th>年龄</th>
                    <th>地址</th>
                    <th>简介</th>
                    <th>作品</th>
                    <th>点赞</th>
                    <th>点赞数量</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $args = array(
                    'post_type' => 'xszl_contestant',
                    'posts_per_page' => -1,
                    'meta_key' => 'xszl_likes',
                    'orderby' => 'meta_value_num',
                    'order' => 'DESC'
                );

                $contestants = new WP_Query( $args );
                $rank = 1;

                if ( $contestants->have_posts() ) :
                    while ( $contestants->have_posts() ) : $contestants->the_post();
                        $age = get_post_meta( get_the_ID(), 'xszl_age', true );
                        $address = get_post_meta( get_the_ID(), 'xszl_address', true );
                        $bio = get_post_meta( get_the_ID(), 'xszl_bio', true );
                        $works = get_post_meta( get_the_ID(), 'xszl_works', true );
                        $likes = get_post_meta( get_the_ID(), 'xszl_likes', true ); // 获取点赞数量
                        ?>
                        <tr>
                            <td><?php echo $rank++; ?></td>
                            <td><?php the_post_thumbnail( 'thumbnail' ); ?></td>
                            <td><?php the_title(); ?></td>
                            <td><?php echo $age; ?></td>
                            <td><?php echo $address; ?></td>
                            <td><?php echo wpautop( $bio ); ?></td>
                            <td><?php echo wpautop( $works); ?></td>
                            <td>
                                <?php if ( is_user_logged_in() ) : ?>
                                    <a href="#" class="like-btn" data-postid="<?php the_ID(); ?>">点赞</a>
                                <?php else : ?>
                                    请登录
                                <?php endif; ?>
                            </td>
                            <td><?php echo $likes ? $likes : 0; ?></td>
                        </tr>
                    <?php endwhile;
                endif;
                wp_reset_postdata();
                ?>
            </tbody>
        </table>
    </div>
    <script>
jQuery(document).ready(function($) {
    $('.like-btn').click(function(e) {
        e.preventDefault();
        <?php if ( is_user_logged_in() ) : ?>
            var post_id = $(this).data('postid');
            $.ajax({
                type: 'post',
                url: '<?php echo admin_url("admin-ajax.php"); ?>',
                data: {
                    action: 'xszl_like_post',
                    post_id: post_id
                },
/*success: function(response) {
    if (response.success) {
        $('#like-notification').html(response.data); // 将成功消息显示在标题旁边
        location.reload(); // 刷新页面以更新点赞数量
    } else {
        $('#like-notification').html(response.data); // 将失败消息显示在标题旁边
    }
}*/
// 在点赞按钮点击事件的成功回调函数中添加以下代码
success: function(response) {
    if (response.success) {
        $('#like-notification').html(response.data); // 将成功消息显示在标题旁边
        setTimeout(function() {
            $('#like-notification').fadeOut('slow'); // 5秒后渐隐消失
        }, 5000); // 5000毫秒 = 5秒
        location.reload(); // 刷新页面以更新点赞数量
    } else {
        $('#like-notification').html(response.data); // 将失败消息显示在标题旁边
        setTimeout(function() {
            $('#like-notification').fadeOut('slow'); // 5秒后渐隐消失
        }, 5000); // 5000毫秒 = 5秒
        location.reload(); // 刷新页面以更新点赞数量
    }
}
            });
        <?php else : ?>
            alert('请先登录');
        <?php endif; ?>
    });
});


    </script>
</div>
    <?php
    return ob_get_clean();
}

add_shortcode( 'xszl_all_contestants', 'xszl_display_all_contestants' );


// 处理点赞功能
function xszl_like_post() {
    // 获取当前用户ID
    $user_id = get_current_user_id();

    // 获取要点赞的选手ID
    $post_id = $_POST['post_id'];

    // 获取当前日期
    $current_date = date('Y-m-d');

    // 构造存储用户点赞记录的 Transient 名称，包括选手ID和当前日期以确保每位选手每天只能被点赞一次
    $transient_name = 'xszl_user_like_' . $user_id . '_post_' . $post_id . '_' . $current_date;

    // 检查该用户是否已经点赞过该选手
    $has_liked = get_transient($transient_name);

    if ($has_liked) {
        // 如果用户已经点赞过该选手，则返回错误消息
        wp_send_json_error('您今天已经给这位选手点过赞了！');
    }

    // 更新选手的点赞数量
    $likes = get_post_meta($post_id, 'xszl_likes', true);
    $likes = (empty($likes)) ? 1 : $likes + 1;
    update_post_meta($post_id, 'xszl_likes', $likes);

    // 设置用户对该选手的点赞记录，有效期为一天
    set_transient($transient_name, true, strtotime('tomorrow') - time());

    // 返回消息提示
    wp_send_json_success('点赞成功！');
}

add_action('wp_ajax_xszl_like_post', 'xszl_like_post');
add_action('wp_ajax_nopriv_xszl_like_post', 'xszl_like_post');

// 注册卸载插件时的清理操作
register_uninstall_hook( __FILE__, 'xszl_uninstall_contestant_plugin' );

// 在卸载插件时删除插件相关数据
function xszl_uninstall_contestant_plugin() {
    // 删除选手自定义文章类型及其相关数据
    $args = array(
        'post_type' => 'xszl_contestant',
        'posts_per_page' => -1,
        'post_status' => 'any'
    );
    $contestants = get_posts( $args );
    if ( $contestants ) {
        foreach ( $contestants as $contestant ) {
            wp_delete_post( $contestant->ID, true ); // 删除选手文章及其相关数据
        }
    }

    // 删除选手相关的用户meta数据
    $users = get_users();
    foreach ( $users as $user ) {
        delete_user_meta( $user->ID, 'xszl_liked_posts' ); // 删除用户点赞记录
    }
}

// 加载单个选手页面模板文件
function xszl_load_contestant_template( $template ) {
    // 检查是否为单个选手页面
    if ( is_singular( 'xszl_contestant' ) ) {
        // 检查插件文件夹中是否存在模板文件
        $plugin_template = plugin_dir_path( __FILE__ ) . 'single-xszl_contestant.php';
        if ( file_exists( $plugin_template ) ) {
            return $plugin_template;
        }
    }
    // 如果不是单个选手页面或模板文件不存在，则返回原始模板
    return $template;
}
add_filter( 'template_include', 'xszl_load_contestant_template' );


?>