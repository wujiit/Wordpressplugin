<?php
// 在single-xszl_contestant.php模板文件中
get_header(); // 获取页眉
?>
<div class="contestant-page">
    
<style>
/* 单个选手页面样式 */
.contestant-page {
    display: flex;
    justify-content: center;
}

.xs_contestant-details {
    max-width: 760px;
    margin: 20px;
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.xs_contestant-header {
    text-align: center;
    margin-bottom: 20px;
}

.xs_contestant-header h1 {
    font-size: 24px;
    margin-top: 10px;
}

.xs_contestant-info p {
    margin-bottom: 10px;
}

/* 响应式布局 */
@media screen and (max-width: 660px) {
    .xs_contestant-details {
        max-width: 100%;
        width: 100%; /* 宽度改为100% */
    }
}
</style>


    <div class="main">
        <?php
        // 获取当前选手的ID
        $contestant_id = get_the_ID();

        // 获取选手的自定义字段值
        $age = get_post_meta($contestant_id, 'xszl_age', true);
        $address = get_post_meta($contestant_id, 'xszl_address', true);
        $works = get_post_meta($contestant_id, 'xszl_works', true);
        $bio = get_post_meta($contestant_id, 'xszl_bio', true);
        $likes = get_post_meta($contestant_id, 'xszl_likes', true);

        // 获取选手头像
        $thumbnail = get_the_post_thumbnail($contestant_id, 'thumbnail');
        ?>

        <div class="xs_contestant-details">
            
            <div class="xs_contestant-header">
                 <h1>选手资料</h1>
                <?php echo $thumbnail; ?>
                <h1><?php the_title(); ?></h1>
            </div>
            <div class="xs_contestant-info">
                <p><strong>年龄:</strong> <?php echo $age; ?></p>
                <p><strong>地址:</strong> <?php echo $address; ?></p>
                <p><strong>作品:</strong> <?php echo $works; ?></p>
                <p><strong>简介:</strong> <?php echo $bio; ?></p>
                <p><strong>点赞数量:</strong> <?php echo $likes; ?></p>
            </div>
        </div>
    </div>

</div><!-- #primary -->
   
<?php

get_footer(); // 获取页脚
?>
