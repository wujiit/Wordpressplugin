<?php
/*
Plugin Name: 阿里云语音合成插件
Description: 基于阿里云长文本语音合成（TTS）服务的 WordPress 插件，仅支持异步模式，音频保存到媒体库
Version: 1.0.1
Author: Summer
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('ALIYUN_TTS_VERSION', '1.0.1');
define('ALIYUN_TTS_TABLE', 'xb_aliyun_tts');
define('ALIYUN_TTS_PLUGIN_DIR', plugin_dir_path(__FILE__));

// 加载依赖
require_once ALIYUN_TTS_PLUGIN_DIR . 'vendor/autoload.php';
use AlibabaCloud\Client\AlibabaCloud;
use AlibabaCloud\Client\Exception\ClientException;
use AlibabaCloud\Client\Exception\ServerException;

// 插件激活时创建数据库表并设置默认回调 URL
register_activation_hook(__FILE__, 'aliyun_tts_install');
function aliyun_tts_install() {
    global $wpdb;
    $table_name = $wpdb->prefix . ALIYUN_TTS_TABLE;
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        text text NOT NULL,
        audio_url varchar(255) DEFAULT '',
        attachment_id bigint(20) DEFAULT 0,
        task_id varchar(100) DEFAULT '',
        request_id varchar(100) DEFAULT '',
        status varchar(50) DEFAULT '',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);

    // 设置默认选项
    add_option('aliyun_tts_access_key_id', '');
    add_option('aliyun_tts_access_key_secret', '');
    add_option('aliyun_tts_appkey', '');
    add_option('aliyun_tts_region', 'cn-shanghai');
    add_option('aliyun_tts_format', 'mp3');
    add_option('aliyun_tts_sample_rate', 16000);
    add_option('aliyun_tts_voice', 'xiaoyun');
    add_option('aliyun_tts_volume', 50);
    add_option('aliyun_tts_speech_rate', 0);
    add_option('aliyun_tts_pitch_rate', 0);
    add_option('aliyun_tts_enable_subtitle', false);
    add_option('aliyun_tts_enable_notify', false);
    add_option('aliyun_tts_api_key', wp_generate_password(32, false));

    // 自动设置回调 URL
    $current_notify_url = get_option('aliyun_tts_notify_url');
    if (empty($current_notify_url)) {
        $callback_url = home_url('/wp-json/aliyun-tts/v1/callback');
        update_option('aliyun_tts_notify_url', $callback_url);
        error_log('阿里云 TTS 插件激活：回调 URL 设置为 ' . $callback_url);
    } else {
        error_log('阿里云 TTS 插件激活：回调 URL 已存在，未覆盖，当前值：' . $current_notify_url);
    }
}

// 添加后台菜单
add_action('admin_menu', 'aliyun_tts_admin_menu');
function aliyun_tts_admin_menu() {
    add_options_page(
        '阿里云语音合成设置',
        '阿里云 TTS',
        'manage_options',
        'aliyun-tts-settings',
        'aliyun_tts_settings_page'
    );
}

// 获取记录总数
function aliyun_tts_get_record_count() {
    global $wpdb;
    $table_name = $wpdb->prefix . ALIYUN_TTS_TABLE;
    return $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
}

// 清空所有记录
function aliyun_tts_clear_records() {
    global $wpdb;
    $table_name = $wpdb->prefix . ALIYUN_TTS_TABLE;
    
    // 获取所有附件 ID
    $attachment_ids = $wpdb->get_col("SELECT attachment_id FROM $table_name WHERE attachment_id != 0");
    
    // 删除媒体库中的附件
    foreach ($attachment_ids as $attachment_id) {
        wp_delete_attachment($attachment_id, true);
    }
    
    // 清空数据库表
    $result = $wpdb->query("TRUNCATE TABLE $table_name");
    
    if ($result === false) {
        error_log('阿里云 TTS 清空记录失败');
        return false;
    }
    
    error_log('阿里云 TTS 成功清空所有记录');
    return true;
}

// 后台设置页面
function aliyun_tts_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问');
    }

    // 保存设置
    if (isset($_POST['aliyun_tts_save_settings']) && check_admin_referer('aliyun_tts_settings')) {
        update_option('aliyun_tts_access_key_id', sanitize_text_field($_POST['aliyun_tts_access_key_id']));
        update_option('aliyun_tts_access_key_secret', sanitize_text_field($_POST['aliyun_tts_access_key_secret']));
        update_option('aliyun_tts_appkey', sanitize_text_field($_POST['aliyun_tts_appkey']));
        update_option('aliyun_tts_region', sanitize_text_field($_POST['aliyun_tts_region']));
        update_option('aliyun_tts_format', sanitize_text_field($_POST['aliyun_tts_format']));
        update_option('aliyun_tts_sample_rate', intval($_POST['aliyun_tts_sample_rate']));
        update_option('aliyun_tts_voice', sanitize_text_field($_POST['aliyun_tts_voice']));
        update_option('aliyun_tts_volume', intval($_POST['aliyun_tts_volume']));
        update_option('aliyun_tts_speech_rate', intval($_POST['aliyun_tts_speech_rate']));
        update_option('aliyun_tts_pitch_rate', intval($_POST['aliyun_tts_pitch_rate']));
        update_option('aliyun_tts_enable_subtitle', isset($_POST['aliyun_tts_enable_subtitle']));
        update_option('aliyun_tts_enable_notify', isset($_POST['aliyun_tts_enable_notify']));
        update_option('aliyun_tts_notify_url', esc_url_raw($_POST['aliyun_tts_notify_url']));
        update_option('aliyun_tts_api_key', sanitize_text_field($_POST['aliyun_tts_api_key']));
        echo '<div class="updated"><p>设置已保存。</p></div>';
    }

    // 处理清空记录请求
    if (isset($_POST['aliyun_tts_clear_records']) && check_admin_referer('aliyun_tts_clear_records')) {
        if (aliyun_tts_clear_records()) {
            echo '<div class="updated"><p>所有记录已成功清空。</p></div>';
        } else {
            echo '<div class="error"><p>清空记录失败，请重试。</p></div>';
        }
    }

    // 获取记录总数
    $record_count = aliyun_tts_get_record_count();
    ?>
    <div class="wrap">
        <h1>阿里云语音合成设置</h1>
        <div class="card">
            <h2>记录统计</h2>
            <p>当前总记录数：<?php echo esc_html($record_count); ?> 条</p>
            <form method="post" action="" onsubmit="return confirm('确定要清空所有记录吗？此操作不可恢复！');">
                <?php wp_nonce_field('aliyun_tts_clear_records'); ?>
                <input type="submit" name="aliyun_tts_clear_records" class="button button-danger" value="清空所有记录">
            </form>
        </div>
        <form method="post" action="">
            <?php wp_nonce_field('aliyun_tts_settings'); ?>
            <table class="form-table aliyun_tts_form-table">
                <tr>
                    <th>AccessKey ID</th>
                    <td><input type="text" name="aliyun_tts_access_key_id" value="<?php echo esc_attr(get_option('aliyun_tts_access_key_id')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>AccessKey Secret</th>
                    <td><input type="password" name="aliyun_tts_access_key_secret" value="<?php echo esc_attr(get_option('aliyun_tts_access_key_secret')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>项目 Appkey</th>
                    <td><input type="text" name="aliyun_tts_appkey" value="<?php echo esc_attr(get_option('aliyun_tts_appkey')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>服务地域</th>
                    <td>
                        <select name="aliyun_tts_region">
                            <option value="cn-shanghai" <?php selected(get_option('aliyun_tts_region'), 'cn-shanghai'); ?>>上海</option>
                            <option value="cn-beijing" <?php selected(get_option('aliyun_tts_region'), 'cn-beijing'); ?>>北京</option>
                            <option value="cn-shenzhen" <?php selected(get_option('aliyun_tts_region'), 'cn-shenzhen'); ?>>深圳</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>音频格式</th>
                    <td>
                        <select name="aliyun_tts_format">
                            <option value="wav" <?php selected(get_option('aliyun_tts_format'), 'wav'); ?>>WAV</option>
                            <option value="mp3" <?php selected(get_option('aliyun_tts_format'), 'mp3'); ?>>MP3</option>
                            <option value="pcm" <?php selected(get_option('aliyun_tts_format'), 'pcm'); ?>>PCM</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>采样率</th>
                    <td>
                        <select name="aliyun_tts_sample_rate">
                            <option value="8000" <?php selected(get_option('aliyun_tts_sample_rate'), 8000); ?>>8000 Hz</option>
                            <option value="16000" <?php selected(get_option('aliyun_tts_sample_rate'), 16000); ?>>16000 Hz</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>发音人</th>
                    <td><input type="text" name="aliyun_tts_voice" value="<?php echo esc_attr(get_option('aliyun_tts_voice')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>音量 (0-100)</th>
                    <td><input type="number" name="aliyun_tts_volume" value="<?php echo esc_attr(get_option('aliyun_tts_volume')); ?>" min="0" max="100"></td>
                </tr>
                <tr>
                    <th>语速 (-500 to 500)</th>
                    <td><input type="number" name="aliyun_tts_speech_rate" value="<?php echo esc_attr(get_option('aliyun_tts_speech_rate')); ?>" min="-500" max="500"></td>
                </tr>
                <tr>
                    <th>语调 (-500 to 500)</th>
                    <td><input type="number" name="aliyun_tts_pitch_rate" value="<?php echo esc_attr(get_option('aliyun_tts_pitch_rate')); ?>" min="-500" max="500"></td>
                </tr>
                <tr>
                    <th>启用句级时间戳</th>
                    <td><input type="checkbox" name="aliyun_tts_enable_subtitle" <?php checked(get_option('aliyun_tts_enable_subtitle')); ?>></td>
                </tr>
                <tr>
                    <th>启用回调</th>
                    <td><input type="checkbox" name="aliyun_tts_enable_notify" <?php checked(get_option('aliyun_tts_enable_notify')); ?>></td>
                </tr>
                <tr>
                    <th>回调 URL</th>
                    <td><input type="url" name="aliyun_tts_notify_url" value="<?php echo esc_attr(get_option('aliyun_tts_notify_url')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>API 密钥</th>
                    <td><input type="text" name="aliyun_tts_api_key" value="<?php echo esc_attr(get_option('aliyun_tts_api_key')); ?>" class="regular-text"></td>
                </tr>
            </table>
            <p><input type="submit" name="aliyun_tts_save_settings" class="button-primary" value="保存设置"></p>
        </form>
    </div>
    <?php
}

// 注册 REST API 端点
add_action('rest_api_init', function () {
    register_rest_route('aliyun-tts/v1', '/callback', [
        'methods' => 'POST',
        'callback' => 'aliyun_tts_handle_callback',
        'permission_callback' => 'aliyun_tts_callback_permission_check',
    ]);
});

// 回调权限检查
function aliyun_tts_callback_permission_check(WP_REST_Request $request) {
    $api_key = $request->get_header('x-aliyun-api-key');
    if (!$api_key || $api_key !== get_option('aliyun_tts_api_key')) {
        error_log('阿里云 TTS 回调权限验证失败: 无效的 API 密钥');
        return false;
    }
    return true;
}

// 保存音频到 WordPress 媒体库
function aliyun_tts_save_to_media_library($audio_url, $task_id) {
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    // 验证 URL
    if (!filter_var($audio_url, FILTER_VALIDATE_URL)) {
        error_log('阿里云 TTS 保存媒体库失败: 无效的音频 URL ' . $audio_url);
        return false;
    }

    // 确定文件扩展名
    $file_extension = pathinfo(parse_url($audio_url, PHP_URL_PATH), PATHINFO_EXTENSION);
    if (!$file_extension) {
        $file_extension = 'mp3';
    }
    $filename = 'tts_' . sanitize_file_name($task_id) . '.' . $file_extension;

    // 下载文件到临时目录
    $temp_file = download_url($audio_url);
    if (is_wp_error($temp_file)) {
        error_log('阿里云 TTS 下载音频失败: ' . $temp_file->get_error_message() . ' URL: ' . $audio_url);
        return false;
    }

    // 检查文件是否有效
    if (!filesize($temp_file)) {
        error_log('阿里云 TTS 下载音频失败: 文件为空 ' . $temp_file);
        @unlink($temp_file);
        return false;
    }

    // 准备文件数组
    $file_array = [
        'name' => $filename,
        'tmp_name' => $temp_file,
    ];

    // 上传到媒体库
    $attachment_id = media_handle_sideload($file_array, 0, 'TTS Audio ' . $task_id);
    if (is_wp_error($attachment_id)) {
        error_log('阿里云 TTS 上传媒体库失败: ' . $attachment_id->get_error_message());
        @unlink($temp_file);
        return false;
    }

    // 获取媒体库中的文件 URL
    $media_url = wp_get_attachment_url($attachment_id);
    if (!$media_url) {
        error_log('阿里云 TTS 获取媒体库 URL 失败: 附件 ID ' . $attachment_id);
        @unlink($temp_file);
        return false;
    }

    @unlink($temp_file);
    error_log('阿里云 TTS 成功保存到媒体库: 附件 ID ' . $attachment_id . ', URL ' . $media_url);

    return [
        'attachment_id' => $attachment_id,
        'audio_url' => $media_url
    ];
}

// 处理异步模式回调
function aliyun_tts_handle_callback(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . ALIYUN_TTS_TABLE;
    $data = $request->get_json_params();

    error_log('阿里云 TTS 回调数据: ' . print_r($data, true));

    if (isset($data['error_code']) && $data['error_code'] == 20000000 && isset($data['data']['task_id'])) {
        $task_id = sanitize_text_field($data['data']['task_id']);
        $audio_url = isset($data['data']['audio_address']) ? esc_url_raw($data['data']['audio_address']) : '';
        $status = $audio_url ? 'completed' : 'failed';
        $attachment_id = 0;

        if ($audio_url) {
            $media_result = aliyun_tts_save_to_media_library($audio_url, $task_id);
            if ($media_result) {
                $audio_url = $media_result['audio_url'];
                $attachment_id = $media_result['attachment_id'];
                $status = 'completed';
            } else {
                $status = 'failed';
                error_log('阿里云 TTS 回调保存媒体库失败: 任务 ID ' . $task_id);
            }
        }

        $updated = $wpdb->update(
            $table_name,
            [
                'audio_url' => $audio_url,
                'attachment_id' => $attachment_id,
                'status' => $status
            ],
            ['task_id' => $task_id],
            ['%s', '%d', '%s'],
            ['%s']
        );

        if ($updated === false) {
            error_log('阿里云 TTS 回调数据库更新失败: 任务 ID ' . $task_id);
            return new WP_REST_Response(['status' => 'error', 'message' => '数据库更新失败'], 500);
        }

        return new WP_REST_Response(['status' => 'success', 'message' => '回调处理成功'], 200);
    }

    error_log('阿里云 TTS 回调无效数据: ' . print_r($data, true));
    return new WP_REST_Response(['status' => 'error', 'message' => '无效的回调数据'], 400);
}

// 获取服务鉴权 Token
function aliyun_tts_get_token() {
    try {
        AlibabaCloud::accessKeyClient(
            get_option('aliyun_tts_access_key_id'),
            get_option('aliyun_tts_access_key_secret')
        )
        ->regionId('cn-shanghai')
        ->asDefaultClient();

        $response = AlibabaCloud::nlsCloudMeta()
            ->v20180518()
            ->createToken()
            ->request();

        $token = $response['Token'];
        if ($token && isset($token['Id'], $token['ExpireTime'])) {
            return [
                'id' => $token['Id'],
                'expire_time' => $token['ExpireTime']
            ];
        }
        error_log('阿里云 TTS 获取 Token 失败: 无效响应');
        return false;
    } catch (ClientException $e) {
        error_log('阿里云 TTS 客户端错误: ' . $e->getErrorMessage());
        return false;
    } catch (ServerException $e) {
        error_log('阿里云 TTS 服务器错误: ' . $e->getErrorMessage());
        return false;
    }
}

// 发起异步语音合成请求
function aliyun_tts_request($text, $params = []) {
    global $wpdb;
    $table_name = $wpdb->prefix . ALIYUN_TTS_TABLE;

    if (empty($text)) {
        return ['error' => '文本不能为空'];
    }

    $token_data = aliyun_tts_get_token();
    if (!$token_data) {
        return ['error' => '获取 Token 失败'];
    }

    $appkey = get_option('aliyun_tts_appkey');
    $region = get_option('aliyun_tts_region');

    $default_params = [
        'format' => get_option('aliyun_tts_format'),
        'sample_rate' => get_option('aliyun_tts_sample_rate'),
        'voice' => get_option('aliyun_tts_voice'),
        'volume' => get_option('aliyun_tts_volume'),
        'speech_rate' => get_option('aliyun_tts_speech_rate'),
        'pitch_rate' => get_option('aliyun_tts_pitch_rate'),
        'enable_subtitle' => get_option('aliyun_tts_enable_subtitle'),
        'enable_notify' => get_option('aliyun_tts_enable_notify'),
        'notify_url' => get_option('aliyun_tts_notify_url')
    ];
    $params = wp_parse_args($params, $default_params);

    $url = "https://nls-gateway-$region.aliyuncs.com/rest/v1/tts/async";

    $header = [
        'appkey' => $appkey,
        'token' => $token_data['id'],
        'x-aliyun-api-key' => get_option('aliyun_tts_api_key')
    ];
    $context = ['device_id' => 'wp_' . uniqid()];
    $tts_request = [
        'text' => $text,
        'format' => $params['format'],
        'voice' => $params['voice'],
        'sample_rate' => $params['sample_rate'],
        'volume' => $params['volume'],
        'speech_rate' => $params['speech_rate'],
        'pitch_rate' => $params['pitch_rate'],
        'enable_subtitle' => $params['enable_subtitle']
    ];
    $payload = [
        'enable_notify' => $params['enable_notify'],
        'notify_url' => $params['notify_url'],
        'tts_request' => $tts_request
    ];
    $body = json_encode([
        'context' => $context,
        'header' => $header,
        'payload' => $payload
    ]);

    $http_headers = [
        'Content-Type: application/json',
        'x-aliyun-api-key: ' . get_option('aliyun_tts_api_key')
    ];
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_URL => $url,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => $http_headers,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HEADER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false
    ]);

    $response = curl_exec($curl);
    if ($response === false) {
        $error = curl_error($curl);
        curl_close($curl);
        error_log('阿里云 TTS CURL 请求失败: ' . $error);
        return ['error' => 'CURL 请求失败: ' . $error];
    }

    $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
    $body_content = substr($response, $header_size);
    $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

    if ($http_code != 200) {
        error_log('阿里云 TTS 请求失败: HTTP ' . $http_code . ', 响应: ' . $body_content);
        return ['error' => '语音合成请求失败', 'code' => $http_code, 'response' => $body_content];
    }

    $data = json_decode($body_content, true);
    if (isset($data['error_code']) && $data['error_code'] == 20000000 && isset($data['data']['task_id'])) {
        $task_id = sanitize_text_field($data['data']['task_id']);
        $request_id = sanitize_text_field($data['request_id']);

        // 存入数据库
        $inserted = $wpdb->insert($table_name, [
            'text' => $text,
            'task_id' => $task_id,
            'request_id' => $request_id,
            'status' => 'queued'
        ]);

        if ($inserted === false) {
            error_log('阿里云 TTS 数据库插入失败: 任务 ID ' . $task_id);
            return ['error' => '数据库插入失败'];
        }

        // 如果未启用回调，立即触发轮询
        if (!$params['enable_notify']) {
            aliyun_tts_poll_status($url, $appkey, $token_data['id'], $task_id, $request_id);
        }

        return [
            'task_id' => $task_id,
            'request_id' => $request_id,
            'status' => 'queued'
        ];
    }

    error_log('阿里云 TTS 请求失败: ' . print_r($data, true));
    return ['error' => '请求失败', 'data' => $data];
}

// 轮询合成状态
function aliyun_tts_poll_status($url, $appkey, $token, $task_id, $request_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . ALIYUN_TTS_TABLE;

    $full_url = "$url?appkey=$appkey&task_id=$task_id&token=$token&request_id=$request_id";

    aliyun_tts_check_status_callback($full_url, $appkey, $token, $task_id, $request_id);
}

// 检查合成状态
function aliyun_tts_check_status_callback($url, $appkey, $token, $task_id, $request_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . ALIYUN_TTS_TABLE;

    $http_headers = ['x-aliyun-api-key: ' . get_option('aliyun_tts_api_key')];
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_URL => $url,
        CURLOPT_HTTPHEADER => $http_headers,
        CURLOPT_HEADER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false
    ]);

    $response = curl_exec($curl);
    if ($response === false) {
        $error = curl_error($curl);
        curl_close($curl);
        error_log('阿里云 TTS 轮询失败: ' . $error);
        $wpdb->update($table_name, ['status' => 'failed'], ['task_id' => $task_id]);
        return;
    }

    $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
    $body_content = substr($response, $header_size);
    $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

    if ($http_code != 200) {
        error_log('阿里云 TTS 轮询失败: HTTP ' . $http_code . ', 响应: ' . $body_content);
        $wpdb->update($table_name, ['status' => 'failed'], ['task_id' => $task_id]);
        return;
    }

    $data = json_decode($body_content, true);
    if (isset($data['error_code']) && $data['error_code'] == 20000000) {
        if (isset($data['data']['audio_address']) && $data['data']['audio_address'] != '') {
            $audio_url = esc_url_raw($data['data']['audio_address']);
            $attachment_id = 0;

            $media_result = aliyun_tts_save_to_media_library($audio_url, $task_id);
            if ($media_result) {
                $audio_url = $media_result['audio_url'];
                $attachment_id = $media_result['attachment_id'];
                $status = 'completed';
            } else {
                $status = 'failed';
                error_log('阿里云 TTS 轮询保存媒体库失败: 任务 ID ' . $task_id);
            }

            $updated = $wpdb->update($table_name, [
                'audio_url' => $audio_url,
                'attachment_id' => $attachment_id,
                'status' => $status
            ], ['task_id' => $task_id]);

            if ($updated === false) {
                error_log('阿里云 TTS 轮询数据库更新失败: 任务 ID ' . $task_id);
            }
        } else {
            // 最多轮询 10 次（约 100 秒）
            $task = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE task_id = %s", $task_id));
            if ($task && $task->status == 'queued') {
                static $poll_count = 0;
                if ($poll_count < 10) {
                    $poll_count++;
                    sleep(10);
                    aliyun_tts_check_status_callback($url, $appkey, $token, $task_id, $request_id);
                } else {
                    $wpdb->update($table_name, ['status' => 'failed'], ['task_id' => $task_id]);
                    error_log('阿里云 TTS 轮询超时: 任务 ID ' . $task_id);
                }
            }
        }
    } else {
        error_log('阿里云 TTS 轮询失败: ' . print_r($data, true));
        $wpdb->update($table_name, ['status' => 'failed'], ['task_id' => $task_id]);
    }
}

// 公共 API：文本转语音
function aliyun_tts_convert_text($text, $params = []) {
    return aliyun_tts_request($text, $params);
}

// 公共 API：获取任务状态
function aliyun_tts_get_status($task_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . ALIYUN_TTS_TABLE;

    $result = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE task_id = %s",
        $task_id
    ));

    if ($result) {
        return [
            'task_id' => $result->task_id,
            'request_id' => $result->request_id,
            'status' => $result->status,
            'audio_url' => $result->audio_url,
            'attachment_id' => $result->attachment_id,
            'created_at' => $result->created_at
        ];
    }
    return ['error' => '任务未找到'];
}

// 后台样式
add_action('admin_head', 'aliyun_tts_admin_styles');
function aliyun_tts_admin_styles() {
    ?>
    <style>
        .aliyun_tts_form-table th {
            width: 200px;
        }
        .aliyun_tts_form-table input[type="text"],
        .aliyun_tts_form-table input[type="password"],
        .aliyun_tts_form-table input[type="url"],
        .aliyun_tts_form-table select {
            width: 300px;
        }
        .button-danger {
            background: #d63638;
            border-color: #d63638;
            color: #fff;
        }
        .button-danger:hover {
            background: #c32f31;
            border-color: #c32f31;
        }
    </style>
    <?php
}


?>