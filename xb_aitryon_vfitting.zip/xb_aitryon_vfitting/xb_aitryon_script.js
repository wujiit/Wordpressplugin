document.addEventListener('DOMContentLoaded', function () {
    // 存储上传的图片URL
    let uploadedImages = {};

    // 切换模特类型显示
    window.xb_aitryon_toggle_model = function () {
        const type = document.getElementById('xb_aitryon_model_type')?.value;
        if (type) {
            document.getElementById('xb_aitryon_builtin_models').style.display = type === 'builtin' ? 'block' : 'none';
            document.getElementById('xb_aitryon_custom_model').style.display = type === 'custom' ? 'block' : 'none';
            updateProcessButtonState();
        }
    };

    // 切换服装类型显示
    window.xb_aitryon_toggle_cloth = function () {
        const type = document.getElementById('xb_aitryon_cloth_type')?.value;
        if (type) {
            document.getElementById('xb_aitryon_separate_cloth').style.display = type === 'separate' ? 'block' : 'none';
            document.getElementById('xb_aitryon_onepiece_cloth').style.display = type === 'onepiece' ? 'block' : 'none';
            updateProcessButtonState();
        }
    };

    // 预览内置模特图片
    window.xb_aitryon_preview_model = function (select) {
        const previewUrl = select.options[select.selectedIndex].getAttribute('data-preview');
        const previewDiv = document.getElementById('xb_aitryon_model_preview');
        if (previewUrl && previewDiv) {
            previewDiv.innerHTML = `<img src="${previewUrl}" class="xb_aitryon_preview_img" alt="Selected Model">`;
            updateProcessButtonState();
        } else if (previewDiv) {
            previewDiv.innerHTML = '';
        }
    };

    // 初始化内置模特预览
    const builtinSelect = document.getElementById('xb_aitryon_builtin_select');
    if (builtinSelect) {
        xb_aitryon_preview_model(builtinSelect);
    }

    // 获取后台设置的允许图片格式
    const allowedFormats = xb_aitryon_vars.allowed_formats || ['jpg', 'jpeg', 'png', 'bmp'];
    const allowedMimeTypes = {
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'png': 'image/png',
        'bmp': 'image/bmp'
    };
    const validMimeTypes = allowedFormats.map(ext => allowedMimeTypes[ext]).filter(Boolean);

    // 为每个拖拽区域绑定事件
    document.querySelectorAll('.xb_aitryon_dropzone').forEach(dropzone => {
        dropzone.addEventListener('click', function () {
            const type = this.dataset.type;
            document.getElementById(`xb_aitryon_${type}_input`)?.click();
        });

        dropzone.addEventListener('dragover', function (e) {
            e.preventDefault();
            this.classList.add('dragover');
        });

        dropzone.addEventListener('dragleave', function () {
            this.classList.remove('dragover');
        });

        dropzone.addEventListener('drop', function (e) {
            e.preventDefault();
            this.classList.remove('dragover');
            const type = this.dataset.type;
            const file = e.dataTransfer.files[0];
            validateAndUploadImage(type, file);
        });
    });

    // 文件输入变化处理（前端验证）
    document.querySelectorAll('input[type="file"]').forEach(input => {
        input.addEventListener('change', function () {
            const type = this.id.replace('xb_aitryon_', '').replace('_input', '');
            if (this.files[0]) {
                validateAndUploadImage(type, this.files[0], this);
            }
        });
    });

    // 验证并上传图片
    function validateAndUploadImage(type, file, inputElement = null) {
        if (!file) {
            showErrorMessage('请上传图片');
            return;
        }

        // 检查文件扩展名
        const fileExt = file.name.split('.').pop().toLowerCase();
        if (!allowedFormats.includes(fileExt)) {
            showErrorMessage('不支持的格式，请使用支持的图片格式：' + allowedFormats.join(', '));
            if (inputElement) inputElement.value = '';
            return;
        }

        // 检查MIME类型
        if (!validMimeTypes.includes(file.type)) {
            showErrorMessage('文件不正确，请更换图片上传');
            if (inputElement) inputElement.value = '';
            return;
        }

        // 检查文件大小（5KB到5MB）
        const maxSize = 5 * 1024 * 1024; // 5MB
        const minSize = 5 * 1024; // 5KB
        if (file.size > maxSize || file.size < minSize) {
            showErrorMessage('文件大小必须在5KB到5MB之间');
            if (inputElement) inputElement.value = '';
            return;
        }

        // 上传图片
        const formData = new FormData();
        formData.append('image', file);

        fetch(xb_aitryon_vars.rest_url + 'upload-image', {
            method: 'POST',
            headers: {
                'X-WP-Nonce': xb_aitryon_vars.nonce
            },
            body: formData
        })
        .then(response => response.json()) // 直接解析JSON，不检查response.ok
        .then(data => {
            if (data.success && data.data && data.data.url) {
                uploadedImages[type] = data.data.url;
                const dropzone = document.querySelector(`.xb_aitryon_dropzone[data-type="${type}"]`);
                dropzone.innerHTML = `<img src="${data.data.url}" class="xb_aitryon_preview_img" alt="Uploaded Image">`;
                updateProcessButtonState();
            } else {
                showErrorMessage(data.message || '上传失败');
                if (inputElement) inputElement.value = '';
            }
        })
        .catch(error => {
            console.error('Upload error:', error);
            showErrorMessage('上传失败：' + error.message);
            if (inputElement) inputElement.value = '';
        });
    }

    // 更新“开始试衣”按钮状态
    function updateProcessButtonState() {
        const processBtn = document.getElementById('xb_aitryon_process_btn');
        if (!processBtn) return;
        const modelType = document.getElementById('xb_aitryon_model_type')?.value;
        const clothType = document.getElementById('xb_aitryon_cloth_type')?.value;
        const modelUrl = modelType === 'builtin' ? document.getElementById('xb_aitryon_builtin_select')?.value : uploadedImages['model'];
        let clothUploaded = false;

        if (clothType === 'separate') {
            clothUploaded = uploadedImages['top'] || uploadedImages['bottom'];
        } else if (clothType === 'onepiece') {
            clothUploaded = uploadedImages['onepiece'];
        }

        processBtn.disabled = !(modelUrl && clothUploaded);
    }

    // 开始试衣按钮点击事件
    const processBtn = document.getElementById('xb_aitryon_process_btn');
    if (processBtn) {
        processBtn.addEventListener('click', function () {
            const modelType = document.getElementById('xb_aitryon_model_type').value;
            const clothType = document.getElementById('xb_aitryon_cloth_type').value;
            const modelUrl = modelType === 'builtin' ? document.getElementById('xb_aitryon_builtin_select').value : uploadedImages['model'];

            let topUrl = '';
            let bottomUrl = '';
            if (clothType === 'separate') {
                topUrl = uploadedImages['top'] || '';
                bottomUrl = uploadedImages['bottom'] || '';
            } else {
                topUrl = uploadedImages['onepiece'] || '';
                bottomUrl = '';
            }

            document.getElementById('xb_aitryon_result').innerHTML = '<span class="xb_aitryon_loading">正在处理中...</span>';

            fetch(xb_aitryon_vars.rest_url + 'process-tryon', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': xb_aitryon_vars.nonce
                },
                body: JSON.stringify({
                    model_url: modelUrl,
                    top_url: topUrl,
                    bottom_url: bottomUrl
                })
            })
            .then(response => {
                if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    pollResult(data.data.task_id);
                } else {
                    document.getElementById('xb_aitryon_result').innerHTML = '';
                    showErrorMessage(data.message || '处理失败');
                }
            })
            .catch(error => {
                document.getElementById('xb_aitryon_result').innerHTML = '';
                showErrorMessage('处理失败：' + error.message);
            });
        });
    }

    // 轮询任务结果
    function pollResult(taskId) {
        const interval = setInterval(() => {
            fetch(xb_aitryon_vars.rest_url + 'poll-task/' + taskId, {
                method: 'GET',
                headers: {
                    'X-WP-Nonce': xb_aitryon_vars.nonce
                }
            })
            .then(response => {
                if (!response.ok) throw new Error('Failed to fetch task status');
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    const status = data.data.task_status;
                    if (status === 'SUCCEEDED') {
                        clearInterval(interval);
                        const imageUrl = data.data.image_url;
                        if (imageUrl) {
                            document.getElementById('xb_aitryon_result').innerHTML = `
                                <div class="xb_aitryon_result_content">
                                    <img src="${imageUrl}" alt="试衣结果" class="xb_aitryon_result_img">
                                    <button class="xb_aitryon_download_btn" onclick="xb_aitryon_download('${imageUrl}')">快速下载</button>
                                </div>
                            `;
                            updateUsageCount();
                        } else {
                            document.getElementById('xb_aitryon_result').innerHTML = '';
                            showErrorMessage('生成成功，但未返回图片URL');
                        }
                    } else if (status === 'FAILED') {
                        clearInterval(interval);
                        document.getElementById('xb_aitryon_result').innerHTML = '';
                        showErrorMessage('处理失败：' + (data.data.message || '未知错误'));
                    }
                } else {
                    clearInterval(interval);
                    document.getElementById('xb_aitryon_result').innerHTML = '';
                    showErrorMessage('获取结果失败：' + data.message);
                }
            })
            .catch(error => {
                clearInterval(interval);
                document.getElementById('xb_aitryon_result').innerHTML = '';
                showErrorMessage('获取结果失败：' + error.message);
            });
        }, 2000);
    }

    // 下载结果图片
    window.xb_aitryon_download = function (url) {
        try {
            let secureUrl = url.startsWith('http://') ? url.replace('http://', 'https://') : url;
            const link = document.createElement('a');
            link.href = secureUrl;
            link.download = 'tryon_result_' + Date.now() + '.jpg';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (error) {
            console.error('Download error:', error);
            showErrorMessage('下载失败：' + error.message);
        }
    };

    // 更新剩余次数显示
    function updateUsageCount() {
        const usageElement = document.querySelector('.xb_aitryon_usage');
        if (!usageElement) return;
        const currentText = usageElement.textContent;
        const [current, total] = currentText.match(/\d+/g).map(Number);
        const remaining = total - (total - current + 1);
        if (remaining >= 0) {
            usageElement.textContent = `今日剩余试衣次数：${remaining}/${total}`;
        } else {
            usageElement.textContent = '今日使用次数已经用完了，请明天再来';
        }
    }

    // 显示错误提示消息
    function showErrorMessage(message) {
        const existing = document.querySelector('.xb_aitryon_message');
        if (existing) existing.remove();

        const div = document.createElement('div');
        div.className = 'xb_aitryon_message error';
        div.textContent = message;
        document.body.appendChild(div);

        setTimeout(() => div.remove(), 3000);
    }

    // 快速登录按钮事件
    const loginBtn = document.querySelector('.xb_aitryon_login_btn');
    if (loginBtn) {
        loginBtn.addEventListener('click', function (e) {
            e.preventDefault();
            const $themeLoginBtn = jQuery('.nav-login .signin-loader');
            if ($themeLoginBtn.length) {
                $themeLoginBtn.trigger('click');
            } else {
                window.location.href = xb_aitryon_vars.login_url;
            }
        });
    }

    // 初始化按钮状态
    if (document.getElementById('xb_aitryon_process_btn')) {
        updateProcessButtonState();
    }
});