<?php
/*
Plugin Name: 小半模特试衣
Description: 基于阿里通义千问AI模型的WordPress虚拟试衣插件
Version: 1.0.1
Author: Summer
*/

if (!defined('ABSPATH')) {
    exit;
}

define('XB_AITRYON_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('XB_AITRYON_PLUGIN_URL', plugin_dir_url(__FILE__));

// 插件激活时创建表和前端页面
register_activation_hook(__FILE__, 'xb_aitryon_activate');
function xb_aitryon_activate() {
    xb_aitryon_create_tables();
    xb_aitryon_create_frontend_page();
}

// 创建用户试衣记录表
function xb_aitryon_create_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'xb_aitryon_records';

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        result_image_url VARCHAR(255) NOT NULL,
        process_time DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

// 创建前端试衣页面（优化为检查短代码）
function xb_aitryon_create_frontend_page() {
    $pages = get_posts([
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_aitryon_vfitting]',
        'numberposts' => 1,
    ]);

    if (empty($pages)) {
        $page_id = wp_insert_post([
            'post_title'   => '模特试衣',
            'post_content' => '[xb_aitryon_vfitting]',
            'post_status'  => 'publish',
            'post_author'  => 1,
            'post_type'    => 'page',
        ]);
    }
}

// 加载前端资源（动态传递允许的图片格式）
add_action('wp_enqueue_scripts', 'xb_aitryon_enqueue_frontend_assets');
function xb_aitryon_enqueue_frontend_assets() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_aitryon_vfitting')) {
        //wp_enqueue_style('xb_aitryon_style', XB_AITRYON_PLUGIN_URL . 'xb_aitryon_style.css', [], '1.9');
        //wp_enqueue_script('xb_aitryon_script', XB_AITRYON_PLUGIN_URL . 'xb_aitryon_script.js', ['jquery'], '1.9', true);

        wp_enqueue_style('xb_aitryon_style', 'https://img.qiyucloud.com/cloud/xb_aitryon_vfitting/xb_aitryon_style.css', [], '1.9');
        wp_enqueue_script('xb_aitryon_script', 'https://img.qiyucloud.com/cloud/xb_aitryon_vfitting/xb_aitryon_script.js', ['jquery'], '1.9', true);

        // 获取后台设置的允许格式
        $options = get_option('xb_aitryon_settings', ['allowed_formats' => 'jpg,png,jpeg,bmp']);
        $allowed_formats = array_map('strtolower', explode(',', $options['allowed_formats']));

        wp_localize_script('xb_aitryon_script', 'xb_aitryon_vars', [
            'rest_url'        => rest_url('xb_aitryon/v1/'),
            'nonce'           => wp_create_nonce('wp_rest'),
            'login_url'       => wp_login_url(),
            'allowed_formats' => $allowed_formats, // 传递允许的图片格式给前端
        ]);
    }
}

// 注册REST API路由
add_action('rest_api_init', 'xb_aitryon_register_rest_routes');
function xb_aitryon_register_rest_routes() {
    register_rest_route('xb_aitryon/v1', '/upload-image', [
        'methods'  => 'POST',
        'callback' => 'xb_aitryon_handle_image_upload',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ]);

    register_rest_route('xb_aitryon/v1', '/process-tryon', [
        'methods'  => 'POST',
        'callback' => 'xb_aitryon_process_tryon',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ]);

    register_rest_route('xb_aitryon/v1', '/poll-task/(?P<task_id>[a-zA-Z0-9-]+)', [
        'methods'  => 'GET',
        'callback' => 'xb_aitryon_poll_task',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ]);
}

// 处理图片上传（修复语法错误并强化真实性验证）
function xb_aitryon_handle_image_upload($request) {
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';

    // 获取后台设置的选项
    $options = get_option('xb_aitryon_settings', [
        'allowed_formats' => 'jpg,png,jpeg,bmp',
        'max_size'        => 5,
    ]);

    // 定义允许的图片格式和对应的MIME类型
    $allowed_formats = array_map('strtolower', explode(',', $options['allowed_formats']));
    $allowed_mime_types = [
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png'  => 'image/png',
        'bmp'  => 'image/bmp',
    ];
    $max_size = $options['max_size'] * 1024 * 1024; // MB转换为字节
    $min_size = 5 * 1024; // 最小5KB

    // 检查是否上传了文件
    if (!isset($_FILES['image'])) {
        return new WP_REST_Response(['success' => false, 'message' => '请上传图片'], 400);
    }

    $file = $_FILES['image'];
    $file_size = $file['size'];
    $file_name = sanitize_file_name($file['name']);
    $file_type = strtolower(wp_check_filetype($file_name)['ext']);
    $mime_type = $file['type'];

    // 检查文件大小
    if ($file_size > $max_size || $file_size < $min_size) {
        return new WP_REST_Response(['success' => false, 'message' => "文件大小必须在5KB到{$options['max_size']}MB之间"], 400);
    }

    // 检查文件扩展名是否在允许的格式中
    if (!in_array($file_type, $allowed_formats)) {
        return new WP_REST_Response(['success' => false, 'message' => '不支持的格式，请使用支持的图片格式：' . implode(', ', $allowed_formats)], 400);
    }

    // 检查MIME类型是否匹配预期，防止伪装文件
    $expected_mime = $allowed_mime_types[$file_type] ?? '';
    if (!$expected_mime || $mime_type !== $expected_mime) {
        error_log("[" . date('Y-m-d H:i:s') . "] Invalid MIME type detected: $mime_type for file $file_name\n", 3, WP_CONTENT_DIR . '/debug.log');
        return new WP_REST_Response(['success' => false, 'message' => '文件不正确，请更换图片上传'], 400);
    }

    // 使用exif_imagetype验证图片真实性，防止伪装（如uploads.php改成uploads.jpg）
    $image_type = exif_imagetype($file['tmp_name']);
    $valid_image_types = [
        IMAGETYPE_JPEG => ['jpg', 'jpeg'],
        IMAGETYPE_PNG  => ['png'],
        IMAGETYPE_BMP  => ['bmp'],
    ];
    $is_valid_type = false;
    foreach ($valid_image_types as $type => $exts) {
        if ($image_type === $type && in_array($file_type, $exts)) {
            $is_valid_type = true;
            break;
        }
    }
    if (!$is_valid_type) {
        error_log("[" . date('Y-m-d H:i:s') . "] Invalid image type detected for file $file_name\n", 3, WP_CONTENT_DIR . '/debug.log');
        return new WP_REST_Response(['success' => false, 'message' => '文件不正确，请更换图片上传'], 400);
    }

    // 检查图片分辨率
    $image_info = getimagesize($file['tmp_name']);
    if (!$image_info) {
        error_log("[" . date('Y-m-d H:i:s') . "] Failed to get image info for file $file_name\n", 3, WP_CONTENT_DIR . '/debug.log');
        return new WP_REST_Response(['success' => false, 'message' => '文件不正确，请更换图片上传'], 400);
    }
    if ($image_info[0] < 150 || $image_info[1] < 150 || $image_info[0] > 4096 || $image_info[1] > 4096) {
        return new WP_REST_Response(['success' => false, 'message' => '图片分辨率必须在150px到4096px之间'], 400);
    }

    // 处理文件上传
    $upload = wp_handle_upload($file, ['test_form' => false]);
    if (isset($upload['error'])) {
        return new WP_REST_Response(['success' => false, 'message' => $upload['error']], 500);
    }

    // 创建附件
    $attachment_id = wp_insert_attachment([
        'guid'           => $upload['url'],
        'post_mime_type' => $upload['type'],
        'post_title'     => $file_name,
        'post_content'   => '',
        'post_status'    => 'inherit',
    ], $upload['file']);

    if (is_wp_error($attachment_id)) {
        return new WP_REST_Response(['success' => false, 'message' => '无法创建媒体库附件'], 500);
    }

    $metadata = wp_generate_attachment_metadata($attachment_id, $upload['file']);
    wp_update_attachment_metadata($attachment_id, $metadata);

    return new WP_REST_Response(['success' => true, 'data' => ['url' => $upload['url']]], 200);
}

// 处理试衣请求
function xb_aitryon_process_tryon($request) {
    $params = $request->get_json_params();
    $user_id = get_current_user_id();
    $daily_limit = xb_aitryon_get_user_daily_limit($user_id);
    $today_usage = xb_aitryon_get_user_today_usage($user_id);

    if ($today_usage >= $daily_limit) {
        return new WP_REST_Response(['success' => false, 'message' => '今日使用次数已用完'], 403);
    }

    $api_key = get_option('xb_aitryon_api_key');
    if (!$api_key) {
        return new WP_REST_Response(['success' => false, 'message' => 'API Key未设置'], 500);
    }

    $model_url = $params['model_url'];
    $top_url = $params['top_url'] ?? '';
    $bottom_url = $params['bottom_url'] ?? '';

    if (!$model_url) {
        return new WP_REST_Response(['success' => false, 'message' => '模特图片URL不能为空'], 400);
    }

    if (!$top_url && !$bottom_url) {
        return new WP_REST_Response(['success' => false, 'message' => '上装或下装图片URL至少提供一个'], 400);
    }

    $payload = [
        'model' => 'aitryon',
        'input' => [
            'person_image_url'   => $model_url,
            'top_garment_url'    => $top_url,
            'bottom_garment_url' => $bottom_url,
        ],
        'parameters' => [
            'resolution'  => -1,
            'restore_face' => true,
        ],
    ];

    $response = wp_remote_post('https://dashscope.aliyuncs.com/api/v1/services/aigc/image2image/image-synthesis/', [
        'headers' => [
            'Authorization'     => "Bearer $api_key",
            'X-DashScope-Async' => 'enable',
            'Content-Type'      => 'application/json',
        ],
        'body'    => json_encode($payload),
        'timeout' => 30,
    ]);

    error_log("[" . date('Y-m-d H:i:s') . "] Process Try-On Request:\n" .
              "Payload: " . json_encode($payload) . "\n" .
              "Response: " . (is_wp_error($response) ? $response->get_error_message() : wp_remote_retrieve_body($response)) . "\n",
              3, WP_CONTENT_DIR . '/debug.log');

    if (is_wp_error($response)) {
        return new WP_REST_Response(['success' => false, 'message' => $response->get_error_message()], 500);
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    if (isset($body['output']['task_status']) && $body['output']['task_status'] === 'PENDING') {
        return new WP_REST_Response(['success' => true, 'data' => ['task_id' => $body['output']['task_id']]], 200);
    }

    return new WP_REST_Response(['success' => false, 'message' => $body['message'] ?? '任务提交失败'], 500);
}

// 轮询任务状态
function xb_aitryon_poll_task($request) {
    $task_id = $request['task_id'];
    $api_key = get_option('xb_aitryon_api_key');

    if (!$api_key) {
        return new WP_REST_Response(['success' => false, 'message' => 'API Key未设置'], 500);
    }

    $response = wp_remote_get("https://dashscope.aliyuncs.com/api/v1/tasks/{$task_id}", [
        'headers' => [
            'Authorization' => "Bearer $api_key",
        ],
        'timeout' => 30,
    ]);

    error_log("[" . date('Y-m-d H:i:s') . "] Poll Task Request:\n" .
              "Task ID: $task_id\n" .
              "Response: " . (is_wp_error($response) ? $response->get_error_message() : wp_remote_retrieve_body($response)) . "\n",
              3, WP_CONTENT_DIR . '/debug.log');

    if (is_wp_error($response)) {
        return new WP_REST_Response(['success' => false, 'message' => $response->get_error_message()], 500);
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    if (isset($body['output']['task_status'])) {
        if ($body['output']['task_status'] === 'SUCCEEDED') {
            $image_url = $body['output']['image_url'] ?? '';
            if ($image_url) {
                xb_aitryon_save_record(get_current_user_id(), $image_url);
            }
        }
        return new WP_REST_Response(['success' => true, 'data' => $body['output']], 200);
    }

    return new WP_REST_Response(['success' => false, 'message' => $body['message'] ?? '任务状态查询失败'], 500);
}

// 前端短代码（动态设置accept属性）
add_shortcode('xb_aitryon_vfitting', 'xb_aitryon_frontend_page');
function xb_aitryon_frontend_page() {
    if (!is_user_logged_in()) {
        ob_start();
        ?>
        <div class="xb_aitryon_container">
            <div class="xb_aitryon_page_title">AI模特试衣</div>
            <div class="xb_aitryon_notice xb_aitryon_guest_login">
                请先登录
                <button class="xb_aitryon_login_btn">快速登录</button>
            </div>
            <?php xb_aitryon_display_announcement(); ?>
            <?php xb_aitryon_display_examples(); ?>
        </div>
        <?php
        return ob_get_clean();
    }

    $user_id = get_current_user_id();
    $daily_limit = xb_aitryon_get_user_daily_limit($user_id);
    $today_usage = xb_aitryon_get_user_today_usage($user_id);
    $remaining = $daily_limit - $today_usage;

    // 获取允许的图片格式
    $options = get_option('xb_aitryon_settings', ['allowed_formats' => 'jpg,png,jpeg,bmp']);
    $allowed_formats = array_map('strtolower', explode(',', $options['allowed_formats']));
    $accept_value = implode(',', array_map(function($ext) { return '.' . $ext; }, $allowed_formats));

    ob_start();
    ?>
    <div class="xb_aitryon_container">
        <div class="xb_aitryon_page_title">AI模特试衣</div>
        <?php if ($remaining > 0) : ?>
        <div class="xb_aitryon_layout">
            <div class="xb_aitryon_left">
                <div class="xb_aitryon_section">
                    <label class="xb_aitryon_label">模特选择</label>
                    <select id="xb_aitryon_model_type" onchange="xb_aitryon_toggle_model()" class="xb_aitryon_select">
                        <option value="builtin">内置模特</option>
                        <option value="custom">自定义模特</option>
                    </select>
                    <div id="xb_aitryon_builtin_models">
                        <div class="xb_aitryon_subtitle">模特名称</div>
                        <?php xb_aitryon_display_builtin_models(); ?>
                    </div>
                    <div id="xb_aitryon_custom_model" style="display:none;">
                        <div class="xb_aitryon_dropzone" data-type="model">拖拽图片到此处或点击上传模特图片</div>
                        <input type="file" id="xb_aitryon_model_input" style="display:none;" accept="<?php echo esc_attr($accept_value); ?>">
                    </div>
                </div>
                <div class="xb_aitryon_section">
                    <label class="xb_aitryon_label">服装类型</label>
                    <select id="xb_aitryon_cloth_type" onchange="xb_aitryon_toggle_cloth()" class="xb_aitryon_select">
                        <option value="separate">上下装</option>
                        <option value="onepiece">连体衣</option>
                    </select>
                    <div id="xb_aitryon_separate_cloth">
                        <div class="xb_aitryon_dropzone" data-type="top">拖拽图片到此处或点击上传上装图片</div>
                        <input type="file" id="xb_aitryon_top_input" style="display:none;" accept="<?php echo esc_attr($accept_value); ?>">
                        <div class="xb_aitryon_dropzone" data-type="bottom">拖拽图片到此处或点击上传下装图片</div>
                        <input type="file" id="xb_aitryon_bottom_input" style="display:none;" accept="<?php echo esc_attr($accept_value); ?>">
                    </div>
                    <div id="xb_aitryon_onepiece_cloth" style="display:none;">
                        <div class="xb_aitryon_dropzone" data-type="onepiece">拖拽图片到此处或点击上传连体衣图片</div>
                        <input type="file" id="xb_aitryon_onepiece_input" style="display:none;" accept="<?php echo esc_attr($accept_value); ?>">
                    </div>
                </div>
            </div>
            <div class="xb_aitryon_right">
                <div class="xb_aitryon_process_section">
                    <button id="xb_aitryon_process_btn" disabled>开始试衣</button>
                </div>
                <div id="xb_aitryon_result" class="xb_aitryon_result_section"></div>
            </div>
        </div>
        <?php endif; ?>
        <div class="xb_aitryon_usage">
            <?php if ($remaining > 0) : ?>
                今日剩余试衣次数：<?php echo $remaining; ?>/<?php echo $daily_limit; ?>
            <?php else : ?>
                今日使用次数已经用完了，请明天再来
            <?php endif; ?>
        </div>
        <?php xb_aitryon_display_announcement(); ?>
        <?php xb_aitryon_display_examples(); ?>
    </div>
    <?php
    return ob_get_clean();
}

// 显示内置模特
function xb_aitryon_display_builtin_models() {
    $models = get_option('xb_aitryon_builtin_models', []);
    if (empty($models)) {
        return;
    }
    echo '<select id="xb_aitryon_builtin_select" onchange="xb_aitryon_preview_model(this)" class="xb_aitryon_select">';
    foreach ($models as $model) {
        echo '<option value="' . esc_url($model['url']) . '" data-preview="' . esc_url($model['url']) . '">' . esc_html($model['name']) . '</option>';
    }
    echo '</select>';
    echo '<div id="xb_aitryon_model_preview" class="xb_aitryon_model_preview"></div>';
}

// 显示公告
function xb_aitryon_display_announcement() {
    $announcement = get_option('xb_aitryon_announcement');
    if ($announcement) {
        echo '<div class="xb_aitryon_announcement">' . wp_kses_post($announcement) . '</div>';
    }
}

// 显示示例
function xb_aitryon_display_examples() {
    $examples = [
        ['name' => '模特要无遮挡的个人正脸照', 'url' => 'https://aiimg.qiyucloud.com/htai/2025/04/20250410082754711.png', 'type' => 'correct'],
        ['name' => '服装要无遮挡的单件正面照', 'url' => 'https://aiimg.qiyucloud.com/htai/2025/04/20250410145620623.jpeg', 'type' => 'correct'],
        ['name' => '模特错误演示', 'url' => 'https://aiimg.qiyucloud.com/htai/2025/04/20250410145828518.png', 'type' => 'error'],
        ['name' => '服装错误演示', 'url' => 'https://aiimg.qiyucloud.com/htai/2025/04/20250410145829208.png', 'type' => 'error'],
    ];
    ?>
    <div class="xb_aitryon_examples">
        <div class="xb_aitryon_title">示例图说明</div>
        <div class="xb_aitryon_example_grid">
            <?php foreach ($examples as $example) : ?>
                <div class="xb_aitryon_example_item">
                    <div class="xb_aitryon_example_name <?php echo $example['type'] === 'correct' ? 'correct-text' : 'error-text'; ?>">
                        <?php echo esc_html($example['name']); ?>
                    </div>
                    <img src="<?php echo esc_url($example['url']); ?>" alt="<?php echo esc_attr($example['name']); ?>" class="xb_aitryon_example_img">
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
}

// 获取用户每日限制
function xb_aitryon_get_user_daily_limit($user_id) {
    $custom_limit = get_user_meta($user_id, 'xb_aitryon_daily_limit', true);
    return $custom_limit !== '' ? (int)$custom_limit : (int)(get_option('xb_aitryon_settings')['daily_limit'] ?? 10);
}

// 获取用户今日使用次数
function xb_aitryon_get_user_today_usage($user_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'xb_aitryon_records';
    $today = date('Y-m-d');
    return $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table WHERE user_id = %d AND DATE(process_time) = %s",
        $user_id,
        $today
    ));
}

// 保存试衣记录
function xb_aitryon_save_record($user_id, $image_url) {
    global $wpdb;
    $table = $wpdb->prefix . 'xb_aitryon_records';
    $result = $wpdb->insert($table, [
        'user_id'         => $user_id,
        'result_image_url' => $image_url,
        'process_time'    => current_time('mysql'),
    ], ['%d', '%s', '%s']);

    if ($result === false) {
        error_log("[" . date('Y-m-d H:i:s') . "] Failed to save record for user $user_id with image $image_url\n", 3, WP_CONTENT_DIR . '/debug.log');
    }
}

// 添加管理菜单
add_action('admin_menu', 'xb_aitryon_admin_menu');
function xb_aitryon_admin_menu() {
    add_menu_page('模特试衣', '模特试衣', 'manage_options', 'xb_aitryon_settings', 'xb_aitryon_settings_page', 'dashicons-admin-generic');
    add_submenu_page('xb_aitryon_settings', '设置', '设置', 'manage_options', 'xb_aitryon_settings', 'xb_aitryon_settings_page');
    add_submenu_page('xb_aitryon_settings', '用户试衣记录', '用户试衣记录', 'manage_options', 'xb_aitryon_records', 'xb_aitryon_records_page');
}

// 设置页面
function xb_aitryon_settings_page() {
    if (isset($_POST['xb_aitryon_save'])) {
        update_option('xb_aitryon_api_key', sanitize_text_field($_POST['api_key']));
        update_option('xb_aitryon_settings', [
            'allowed_formats' => sanitize_text_field($_POST['allowed_formats']),
            'max_size'        => (int)$_POST['max_size'],
            'daily_limit'     => (int)$_POST['daily_limit'],
        ]);
        update_option('xb_aitryon_announcement', wp_kses_post($_POST['announcement']));
        update_option('xb_aitryon_models_param', sanitize_text_field($_POST['models_param']));
        $models = [];
        if (!empty($_POST['model_names'])) {
            foreach ($_POST['model_names'] as $i => $name) {
                if ($name && $_POST['model_urls'][$i]) {
                    $models[] = [
                        'name' => sanitize_text_field($name),
                        'url'  => esc_url_raw($_POST['model_urls'][$i]),
                    ];
                }
            }
        }
        update_option('xb_aitryon_builtin_models', $models);
        echo '<div class="updated xb_aitryon_notice"><p>设置已保存</p></div>';
    }

    $options = get_option('xb_aitryon_settings', ['allowed_formats' => 'jpg,png,jpeg,bmp', 'max_size' => 5, 'daily_limit' => 10]);
    $api_key = get_option('xb_aitryon_api_key', '');
    $announcement = get_option('xb_aitryon_announcement', '');
    $models_param = get_option('xb_aitryon_models_param', 'aitryon');
    $models = get_option('xb_aitryon_builtin_models', []);
    ?>
    <div class="wrap">
        <h1>模特试衣设置</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>通义千问API Key</th>
                    <td><input type="text" name="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>支持的图片格式</th>
                    <td><input type="text" name="allowed_formats" value="<?php echo esc_attr($options['allowed_formats']); ?>" class="regular-text"> 用逗号分隔</td>
                </tr>
                <tr>
                    <th>最大图片大小 (MB)</th>
                    <td><input type="number" name="max_size" value="<?php echo esc_attr($options['max_size']); ?>" min="1"></td>
                </tr>
                <tr>
                    <th>每日使用次数限制</th>
                    <td><input type="number" name="daily_limit" value="<?php echo esc_attr($options['daily_limit']); ?>" min="1"></td>
                </tr>
                <tr>
                    <th>模型参数</th>
                    <td><input type="text" name="models_param" value="<?php echo esc_attr($models_param); ?>" class="regular-text"> 用逗号分隔，默认使用第一个</td>
                </tr>
                <tr>
                    <th>公告内容</th>
                    <td><textarea name="announcement" rows="5" cols="50"><?php echo esc_textarea($announcement); ?></textarea></td>
                </tr>
                <tr>
                    <th>内置模特</th>
                    <td>
                        <div id="xb_aitryon_models">
                            <?php foreach ($models as $i => $model) : ?>
                                <div>
                                    <input type="text" name="model_names[]" value="<?php echo esc_attr($model['name']); ?>" placeholder="模特名称">
                                    <input type="url" name="model_urls[]" value="<?php echo esc_attr($model['url']); ?>" placeholder="图片URL">
                                    <button type="button" onclick="this.parentElement.remove();">删除</button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" onclick="xb_aitryon_add_model()">添加模特</button>
                    </td>
                </tr>
            </table>
            <input type="submit" name="xb_aitryon_save" class="button-primary" value="保存设置">
        </form>
        <script>
            function xb_aitryon_add_model() {
                const div = document.createElement('div');
                div.innerHTML = '<input type="text" name="model_names[]" placeholder="模特名称"> <input type="url" name="model_urls[]" placeholder="图片URL"> <button type="button" onclick="this.parentElement.remove();">删除</button>';
                document.getElementById('xb_aitryon_models').appendChild(div);
            }
        </script>
    </div>
    由阿里通义千问提供：https://help.aliyun.com/zh/model-studio/outfitanyone-api#27f42e56f7vmr <br>
    单价：0.20元一张
    <?php
}

// 用户试衣记录页面
function xb_aitryon_records_page() {
    global $wpdb;
    $table = $wpdb->prefix . 'xb_aitryon_records';
    $per_page = 20;
    $paged = isset($_GET['paged']) ? (int)$_GET['paged'] : 1;
    $offset = ($paged - 1) * $per_page;
    $user_id_filter = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;

    if (isset($_POST['xb_aitryon_set_limit'])) {
        $limit = (int)$_POST['custom_limit'];
        if ($limit > 0) {
            update_user_meta($user_id_filter, 'xb_aitryon_daily_limit', $limit);
        } else {
            delete_user_meta($user_id_filter, 'xb_aitryon_daily_limit');
        }
        echo '<div class="updated xb_aitryon_notice"><p>使用次数设置已更新</p></div>';
    }

    if (isset($_GET['delete_id'])) {
        $wpdb->delete($table, ['id' => (int)$_GET['delete_id']], ['%d']);
        echo '<div class="updated xb_aitryon_notice"><p>记录已删除</p></div>';
    }

    $where = $user_id_filter ? $wpdb->prepare('WHERE user_id = %d', $user_id_filter) : '';
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table $where");
    $records = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table $where ORDER BY process_time DESC LIMIT %d OFFSET %d", $per_page, $offset));

    $today_usage = $user_id_filter ? xb_aitryon_get_user_today_usage($user_id_filter) : 0;
    $daily_limit = $user_id_filter ? xb_aitryon_get_user_daily_limit($user_id_filter) : 0;
    $user_total = $user_id_filter ? $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE user_id = %d", $user_id_filter)) : 0;
    ?>
    <div class="wrap">
        <h1>用户试衣记录</h1>
        <p>网站总处理次数：<?php echo $total; ?></p>
        <form method="get">
            <input type="hidden" name="page" value="xb_aitryon_records">
            <label>查询用户ID: <input type="number" name="user_id" value="<?php echo $user_id_filter; ?>"></label>
            <input type="submit" class="button" value="查询">
            <?php if ($user_id_filter) : ?>
                <a href="?page=xb_aitryon_records" class="button">返回全部记录</a>
            <?php endif; ?>
        </form>
        <?php if ($user_id_filter) : ?>
            <p>当前用户今日使用次数：<?php echo $today_usage; ?> / 每日限额：<?php echo $daily_limit; ?> / 总处理次数：<?php echo $user_total; ?></p>
            <form method="post">
                <label>设置每日使用次数: <input type="number" name="custom_limit" min="0" placeholder="留空恢复默认"></label>
                <input type="submit" name="xb_aitryon_set_limit" class="button" value="保存">
            </form>
        <?php endif; ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户ID</th>
                    <th>用户名</th>
                    <th>试衣结果</th>
                    <th>处理时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record) : ?>
                    <tr>
                        <td><?php echo $record->user_id; ?></td>
                        <td><?php echo get_userdata($record->user_id)->user_login; ?></td>
                        <td><img src="<?php echo esc_url($record->result_image_url); ?>" style="width:100px;height:100px;object-fit:cover;"></td>
                        <td><?php echo $record->process_time; ?></td>
                        <td><a href="?page=xb_aitryon_records&delete_id=<?php echo $record->id; ?>" class="button">删除</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        $pagination = paginate_links([
            'base'    => add_query_arg('paged', '%#%'),
            'format'  => '',
            'total'   => ceil($total / $per_page),
            'current' => $paged,
        ]);
        echo '<div class="tablenav"><div class="tablenav-pages">' . $pagination . '</div></div>';
        ?>
        <script>
            document.querySelectorAll('.xb_aitryon_notice').forEach(function(notice) {
                setTimeout(function() { notice.remove(); }, 3000);
            });
        </script>
    </div>
    <?php
}