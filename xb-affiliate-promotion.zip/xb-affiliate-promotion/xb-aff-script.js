/* 前台AJAX加载和复制链接功能 */
jQuery(document).ready(function($) {
    // 加载邀请记录
    function loadInvites(page = 1) {
        $.ajax({
            url: xbAffAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_aff_load_invites',
                nonce: xbAffAjax.nonce,
                page: page
            },
            success: function(response) {
                if (response.success) {
                    $('#xb-aff-invites-table').html(response.data.table);
                    $('#xb-aff-pagination').html(response.data.pagination);
                }
            }
        });
    }

    // 初始加载
    loadInvites();

    // 分页点击
    $(document).on('click', '#xb-aff-pagination a', function(e) {
        e.preventDefault();
        var page = $(this).attr('href').split('page=')[1];
        loadInvites(page);
    });
});

// 复制默认链接功能
function copyLink() {
    var link = document.getElementById('xb-aff-link');
    link.select();
    document.execCommand('copy');
    
    var message = document.getElementById('xb-aff-copy-message');
    message.textContent = '链接已复制到剪贴板！';
    message.classList.add('show');
    
    setTimeout(function() {
        message.classList.remove('show');
    }, 3000);
}

// 复制指定页面链接功能
function copySpecificLink() {
    var link = document.getElementById('xb-aff-specific-link');
    link.select();
    document.execCommand('copy');
    
    var message = document.getElementById('xb-aff-specific-copy-message');
    message.textContent = '活动链接已复制到剪贴板！';
    message.classList.add('show');
    
    setTimeout(function() {
        message.classList.remove('show');
    }, 3000);
}