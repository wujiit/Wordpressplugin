<?php
/*
Plugin Name: 小半推广邀请好友
Description: 一个用于用户邀请推广的WordPress插件，支持专属推广链接和邀请数据统计
Plugin URI: https://www.jingxialai.com/4989.html
Version: 1.0.1
Author: Summer
License: GPL License
Author URI: https://www.jingxialai.com/
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件列表页面添加设置入口
function xb_aff_promotion_add_settings_link($links) {
    $settings_link = '<a href="admin.php?page=xb-aff-stats">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'xb_aff_promotion_add_settings_link');

// 插件主类
class XB_Affiliate_Promotion {
    private $db_version = '1.1';

    // 构造函数
    public function __construct() {
        register_activation_hook(__FILE__, array($this, 'xb_aff_activate'));
        register_deactivation_hook(__FILE__, array($this, 'xb_aff_deactivate'));
        add_action('init', array($this, 'xb_aff_init'));
        add_action('wp_enqueue_scripts', array($this, 'xb_aff_enqueue_frontend_assets'));
        add_action('admin_menu', array($this, 'xb_aff_admin_menu'));
        add_action('wp', array($this, 'xb_aff_handle_registration'));
        add_action('template_redirect', array($this, 'xb_aff_handle_referral_redirect'));
        add_action('admin_enqueue_scripts', array($this, 'xb_aff_enqueue_admin_assets'));
        add_shortcode('xb_aff_promotion_page', array($this, 'xb_aff_promotion_page_shortcode'));
    }

    // 插件激活时执行

    public function xb_aff_activate() {
        $this->xb_aff_create_database();
        $this->xb_aff_create_promotion_page();
    }

     // 插件停用时执行
    public function xb_aff_deactivate() {
        // 保留数据表和页面
    }

    // 初始化插件
    public function xb_aff_init() {
        add_action('wp_ajax_xb_aff_load_invites', array($this, 'xb_aff_load_invites'));
        add_action('wp_ajax_nopriv_xb_aff_load_invites', array($this, 'xb_aff_load_invites'));
        // 处理推广说明保存
        if (isset($_POST['xb_aff_save_description']) && check_admin_referer('xb_aff_save_description_nonce')) {
            $description = wp_kses_post($_POST['xb_aff_description']);
            update_option('xb_aff_promotion_description', $description);
            
            // 处理推广指定页面保存
            $specific_page_title = sanitize_text_field($_POST['xb_aff_specific_page_title'] ?? '');
            $specific_page_url = esc_url_raw($_POST['xb_aff_specific_page_url'] ?? '');
            update_option('xb_aff_specific_page_title', $specific_page_title);
            update_option('xb_aff_specific_page_url', $specific_page_url);
            
            // 重定向并添加查询参数
            wp_redirect(add_query_arg('settings-updated', 'true', wp_get_referer()));
            exit;
        }
    }

    // 创建数据库表
    public function xb_aff_create_database() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'xb_affiliate_records';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            referrer_id bigint(20) NOT NULL,
            invited_user_id bigint(20) NOT NULL,
            registration_time datetime DEFAULT CURRENT_TIMESTAMP,
            registration_ip varchar(45) NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        update_option('xb_aff_db_version', $this->db_version);
    }

    // 创建推广页面
    public function xb_aff_create_promotion_page() {
        // 查询是否已有包含短代码 [xb_aff_promotion_page] 的页面
        $pages = get_posts(array(
            'post_type'   => 'page',
            'post_status' => 'publish',
            's'           => '[xb_aff_promotion_page]',
            'numberposts' => 1,
        ));

        // 如果没有找到包含短代码的页面
        if (empty($pages)) {
            wp_insert_post(array(
                'post_title'    => '推广邀请好友',
                'post_content'  => '[xb_aff_promotion_page]',
                'post_status'   => 'publish',
                'post_type'     => 'page',
                'post_name'     => 'affiliate-promotion'
            ));
        }
    }


    // 加载前端资源
    public function xb_aff_enqueue_frontend_assets() {
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_aff_promotion_page')) {
            wp_enqueue_style('xb-aff-style', plugin_dir_url(__FILE__) . 'xb-aff-style.css', array(), '1.3.14');
            wp_enqueue_script('xb-aff-script', plugin_dir_url(__FILE__) . 'xb-aff-script.js', array('jquery'), '1.3.14', true);
            wp_localize_script('xb-aff-script', 'xbAffAjax', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('xb_aff_nonce')
            ));
        }
    }

    // 加载后台资源
    public function xb_aff_enqueue_admin_assets($hook) {
        // 仅在 xb-aff-stats 页面加载样式
        if ($hook !== 'toplevel_page_xb-aff-stats') {
            return;
        }

        // 注册并加载一个自定义样式句柄
        wp_enqueue_style('xb-aff-admin-style', plugin_dir_url(__FILE__) . 'xb-aff-admin.css', array(), '1.3.14');
        
        // 内联 CSS
        $admin_css = '
            .aff-wrap {
                margin: 20px auto;
                padding: 20px;
                background: #f9f9f9;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            }
            .aff-wrap h1 {
                color: #2c3e50;
                font-size: 24px;
                margin-bottom: 20px;
                text-align: center;
            }
            .xb-aff-stats {
                background: #fff;
                padding: 20px;
                margin-bottom: 20px;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .xb-aff-stats p {
                margin: 10px 0;
                font-size: 16px;
                color: #333;
            }
            .xb-aff-description-form {
                background: #fff;
                padding: 20px;
                margin-bottom: 20px;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .xb-aff-description-form textarea,
            .xb-aff-description-form input[type="text"] {
                padding: 12px;
                border: 1px solid #ddd;
                border-radius: 4px;
                resize: vertical;
                font-size: 14px;
                box-sizing: border-box;
                width: 100%;
                max-width: 600px;
            }
            .xb-aff-search-form {
                margin-bottom: 20px;
            }
            .xb-aff-search-form input[type="text"] {
                padding: 8px;
                width: 200px;
                margin-right: 10px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
            .xb-aff-search-form input[type="submit"],
            .xb-aff-description-form input[type="submit"] {
                padding: 8px 20px;
                background: #0073aa;
                color: #fff;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                transition: background 0.3s;
            }
            .xb-aff-search-form input[type="submit"]:hover,
            .xb-aff-description-form input[type="submit"]:hover {
                background: #005177;
            }
            #xb-aff-save-success {
                background-color: #46b450;
                color: #fff;
                padding: 12px 20px;
                margin: 15px 0;
                border: 1px solid #3d9d44;
                border-radius: 4px;
                display: inline-block;
                box-shadow: 0 1px 3px rgba(0,0,0,0.2);
                font-size: 14px;
            }
            .xb-aff-description-form .form-field {
                margin-bottom: 15px;
            }
            .xb-aff-description-form label {
                display: block;
                margin-bottom: 5px;
                font-weight: 600;
            }
        ';
        wp_add_inline_style('xb-aff-admin-style', $admin_css);
    }

    // 处理推广链接重定向
    public function xb_aff_handle_referral_redirect() {
        if (isset($_GET['ref']) && !is_user_logged_in()) {
            $referrer_id = absint($_GET['ref']);
            $specific_page_url = get_option('xb_aff_specific_page_url', '');
            
            // 如果有推广指定页面，优先跳转到指定页面（去掉ref参数）
            if ($specific_page_url && strpos($_SERVER['REQUEST_URI'], parse_url($specific_page_url, PHP_URL_PATH)) !== false) {
                setcookie('xb_aff_referrer', $referrer_id, time() + 3600 * 24 * 30, '/');
                $clean_url = remove_query_arg('ref', $specific_page_url);
                wp_safe_redirect($clean_url);
            } else {
                setcookie('xb_aff_referrer', $referrer_id, time() + 3600 * 24 * 30, '/');
                wp_safe_redirect(home_url('/'));
            }
            exit;
        }
    }

    // 处理用户注册时的推荐记录
    public function xb_aff_handle_registration() {
        if (is_user_logged_in() && isset($_COOKIE['xb_aff_referrer'])) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'xb_affiliate_records';
            $referrer_id = absint($_COOKIE['xb_aff_referrer']);
            $user_id = get_current_user_id();
            $ip = $_SERVER['REMOTE_ADDR'];

            $wpdb->insert(
                $table_name,
                array(
                    'referrer_id' => $referrer_id,
                    'invited_user_id' => $user_id,
                    'registration_time' => current_time('mysql'),
                    'registration_ip' => $ip
                )
            );

            setcookie('xb_aff_referrer', '', time() - 3600, '/');
        }
    }

    /**
     * 前台推广页面短代码
     * 显示页面标题和推广说明给游客，并确保主标题居中
     */
    public function xb_aff_promotion_page_shortcode() {
        $description = get_option('xb_aff_promotion_description', '');

        ob_start();
        ?>
        <div class="xb-aff-promotion-container">
            <!-- 使用自定义样式类显示居中的页面主标题 -->
            <div class="xb-aff-main-title">推广邀请好友</div>
            
            <!-- 使用自定义样式类显示推广说明标题 -->
            <?php if ($description) : ?>
                <div class="xb-aff-section-title">推广邀请说明</div>
                <div class="xb-aff-description"><?php echo wp_kses_post($description); ?></div>
            <?php endif; ?>

            <?php if (!is_user_logged_in()) : ?>
                <p class="xb-aff-login-prompt">请先登录查看您的专属推广链接和邀请记录</p>
            <?php else : ?>
                <?php
                $user_id = get_current_user_id();
                $promotion_url = add_query_arg('ref', $user_id, home_url('/register'));
                $specific_page_title = get_option('xb_aff_specific_page_title', '');
                $specific_page_url = get_option('xb_aff_specific_page_url', '');
                $specific_promotion_url = $specific_page_url ? add_query_arg('ref', $user_id, $specific_page_url) : '';
                ?>
                <div class="xb-aff-link-section">
                    <div class="xb-aff-section-title">您的专属推广链接</div>
                    <div class="xb-aff-link-wrapper">
                        <input type="text" id="xb-aff-link" value="<?php echo esc_url($promotion_url); ?>" readonly>
                        <button class="xb-aff-copy-btn" onclick="copyLink()">复制链接</button>
                    </div>
                    <p id="xb-aff-copy-message" class="xb-aff-copy-message"></p>
                </div>

                <?php if ($specific_page_title && $specific_page_url) : ?>
                <div class="xb-aff-specific-link-section">
                    <div class="xb-aff-section-title"><?php echo esc_html($specific_page_title); ?></div>
                    <div class="xb-aff-link-wrapper">
                        <input type="text" id="xb-aff-specific-link" value="<?php echo esc_attr($specific_page_title . ' ' . $specific_promotion_url); ?>" readonly>
                        <button class="xb-aff-copy-btn" onclick="copySpecificLink()">复制活动链接</button>
                    </div>
                    <p id="xb-aff-specific-copy-message" class="xb-aff-copy-message"></p>
                </div>
                <?php endif; ?>

                <div class="xb-aff-invites-section">
                    <div class="xb-aff-section-title">您的邀请记录</div>
                    <div id="xb-aff-invites-table"></div>
                    <div id="xb-aff-pagination"></div>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    // AJAX加载邀请记录
    public function xb_aff_load_invites() {
        check_ajax_referer('xb_aff_nonce', 'nonce');
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'xb_affiliate_records';
        $page = isset($_POST['page']) ? absint($_POST['page']) : 1;
        $per_page = 20;
        $offset = ($page - 1) * $per_page;
        $user_id = get_current_user_id();

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT u.user_login, r.registration_time 
                FROM $table_name r 
                JOIN {$wpdb->users} u ON r.invited_user_id = u.ID 
                WHERE r.referrer_id = %d 
                ORDER BY r.registration_time DESC 
                LIMIT %d OFFSET %d",
                $user_id,
                $per_page,
                $offset
            )
        );

        $total = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE referrer_id = %d",
                $user_id
            )
        );

        ob_start();
        ?>
        <table class="xb-aff-table">
            <thead>
                <tr>
                    <th>用户名</th>
                    <th>注册时间</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $row) : ?>
                    <tr>
                        <td><?php echo esc_html($row->user_login); ?></td>
                        <td><?php echo esc_html($row->registration_time); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        $table_html = ob_get_clean();

        $pagination = paginate_links(array(
            'base' => '#%#%',
            'format' => '?page=%#%',
            'current' => $page,
            'total' => ceil($total / $per_page),
            'type' => 'plain'
        ));

        wp_send_json_success(array(
            'table' => $table_html,
            'pagination' => $pagination
        ));
    }


    // 后台统计页面
    public function xb_aff_admin_menu() {
        add_menu_page(
            '推广统计',
            '推广统计',
            'manage_options',
            'xb-aff-stats',
            array($this, 'xb_aff_admin_page'),
            'dashicons-groups',
            80
        );
    }

    // 后台统计页面内容
    public function xb_aff_admin_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'xb_affiliate_records';

        // 统计数据
        $total_invites = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        $today_invites = $wpdb->get_var(
            "SELECT COUNT(*) FROM $table_name WHERE DATE(registration_time) = CURDATE()"
        );

        // 用户查询
        $search_user_id = isset($_GET['search_user_id']) ? absint($_GET['search_user_id']) : 0;
        $page = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
        $per_page = 20;
        $offset = ($page - 1) * $per_page;

        $where = $search_user_id ? $wpdb->prepare("WHERE r.referrer_id = %d", $search_user_id) : '';
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT r.referrer_id, r.invited_user_id, u.user_login, r.registration_time, r.registration_ip 
                FROM $table_name r 
                JOIN {$wpdb->users} u ON r.invited_user_id = u.ID 
                $where 
                ORDER BY r.registration_time DESC 
                LIMIT %d OFFSET %d",
                $per_page,
                $offset
            )
        );

        $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
        ?>
        <div class="aff-wrap">
            <h1>推广统计</h1>
            
            <!-- 保存成功通知 -->
            <?php if (isset($_GET['settings-updated']) && $_GET['settings-updated'] === 'true'): ?>
                <div id="xb-aff-save-success">设置已保存！</div>
                <script>
                    setTimeout(function() {
                        document.getElementById('xb-aff-save-success').style.display = 'none';
                    }, 3000);
                </script>
            <?php endif; ?>

            <!-- 推广说明设置 -->
            <div class="xb-aff-description-form">
                <h2>推广设置</h2>
                <form method="post" action="">
                    <?php wp_nonce_field('xb_aff_save_description_nonce'); ?>
                    <div class="form-field">
                        <label for="xb_aff_description">推广说明</label>
                        <textarea name="xb_aff_description" id="xb_aff_description" rows="5" cols="100"><?php echo esc_textarea(get_option('xb_aff_promotion_description', '')); ?></textarea>
                    </div>
                    <div class="form-field">
                        <label for="xb_aff_specific_page_title">推广指定页面标题</label>
                        <input type="text" name="xb_aff_specific_page_title" id="xb_aff_specific_page_title" value="<?php echo esc_attr(get_option('xb_aff_specific_page_title', '')); ?>">
                    </div>
                    <div class="form-field">
                        <label for="xb_aff_specific_page_url">推广指定页面链接</label>
                        <input type="text" name="xb_aff_specific_page_url" id="xb_aff_specific_page_url" value="<?php echo esc_attr(get_option('xb_aff_specific_page_url', '')); ?>">
                    </div>
                    <p><input type="submit" name="xb_aff_save_description" value="保存设置" class="button"></p>
                </form>
            </div>

            <!-- 统计数据 -->
            <div class="xb-aff-stats">
                <p>总邀请人数: <?php echo $total_invites; ?></p>
                <p>今日邀请人数: <?php echo $today_invites; ?></p>
            </div>
            
            <!-- 用户查询 -->
            <form method="get" class="xb-aff-search-form">
                <input type="hidden" name="page" value="xb-aff-stats">
                <input type="text" name="search_user_id" placeholder="输入用户ID查询" value="<?php echo $search_user_id; ?>">
                <input type="submit" value="查询" class="button">
            </form>

            <!-- 邀请记录表格 -->
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>邀请者ID</th>
                        <th>被邀请用户ID</th>
                        <th>被邀请用户名</th>
                        <th>注册时间</th>
                        <th>注册IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $row) : ?>
                        <tr>
                            <td><?php echo $row->referrer_id; ?></td>
                            <td><?php echo $row->invited_user_id; ?></td>
                            <td><?php echo esc_html($row->user_login); ?></td>
                            <td><?php echo $row->registration_time; ?></td>
                            <td><?php echo esc_html($row->registration_ip); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <?php
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '&paged=%#%',
                'current' => $page,
                'total' => ceil($total / $per_page)
            ));
            ?>
        </div>
        <?php
    }
}

// 实例化插件
new XB_Affiliate_Promotion();
?>