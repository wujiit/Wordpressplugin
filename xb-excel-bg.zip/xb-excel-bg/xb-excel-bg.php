<?php
/*
Plugin Name: 小半AI表格
Description: 基于AI的WordPress表格生成助手，支持生成适合Excel或WPS的表格
Version: 1.0.0
Author: summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 创建数据库表
function xb_excel_bg_create_database() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'excel_bg_records';
    $theme_table = $wpdb->prefix . 'excel_bg_themes';
    $charset_collate = $wpdb->get_charset_collate();

    // 创建记录表
    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        usage_date date NOT NULL,
        total_count int DEFAULT 0,
        success_count int DEFAULT 0,
        custom_limit int DEFAULT NULL,
        PRIMARY KEY (id),
        INDEX user_date_index (user_id, usage_date)
    ) $charset_collate;";

    // 创建主题表
    $theme_sql = "CREATE TABLE $theme_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        record_id bigint(20) NOT NULL,
        user_id bigint(20) NOT NULL,
        theme_content text NOT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        INDEX record_user_index (record_id, user_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    dbDelta($theme_sql);
}

// 创建前台页面
function xb_excel_bg_create_frontend_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_excel_bg_shortcode]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        wp_insert_post(array(
            'post_title'    => 'AI表格助手',
            'post_name'     => 'excel-bg-creation',
            'post_content'  => '[xb_excel_bg_shortcode]',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        ));
    }
}

// 加载前台资源
function xb_excel_bg_load_resources() {
    wp_enqueue_script('jquery');

    $css_path = plugin_dir_path(__FILE__) . 'xb-excel-bg.css';
    if (file_exists($css_path)) {
        wp_enqueue_style(
            'xb_excel_bg_styles',
            plugin_dir_url(__FILE__) . 'xb-excel-bg.css',
            array(),
            '1.0.0'
        );
        error_log('Excel BG CSS 已加载: ' . plugin_dir_url(__FILE__) . 'xb-excel-bg.css');
    } else {
        error_log('Excel BG CSS 文件未找到: ' . $css_path);
    }

    $js_path = plugin_dir_path(__FILE__) . 'xb-excel-bg.js';
    if (file_exists($js_path)) {
        wp_enqueue_script(
            'xb_excel_bg_script',
            plugin_dir_url(__FILE__) . 'xb-excel-bg.js',
            array('jquery'),
            '1.0.0',
            true
        );
        error_log('Excel BG JS 已加载: ' . plugin_dir_url(__FILE__) . 'xb-excel-bg.js');
    } else {
        error_log('Excel BG JS 文件未找到: ' . $js_path);
    }

    wp_localize_script('xb_excel_bg_script', 'XBExcelBGData', array(
        'rest_url' => esc_url_raw(rest_url('xb_excel_bg/v1/generate')),
        'nonce' => wp_create_nonce('wp_rest'),
        'ajax_url' => admin_url('admin-ajax.php'),
        'forbidden_words' => array_filter(array_map('trim', explode(',', get_option('xb_excel_bg_forbidden_words', ''))))
    ));
}

// 动态加载前端资源
add_action('wp_enqueue_scripts', function() {
    global $post;
    if (is_a($post, 'WP_Post') && (has_shortcode($post->post_content, 'xb_excel_bg_shortcode') || is_page('excel-bg-creation'))) {
        xb_excel_bg_load_resources();
    }
});

// 处理表格生成请求
function xb_excel_bg_generate_handler(WP_REST_Request $request) {
    global $wpdb;
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = get_option('xb_excel_bg_daily_limit', 10);

    error_log("处理生成表格请求 - 用户ID: $user_id, 日期: $today");

    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT total_count, success_count, custom_limit FROM {$wpdb->prefix}excel_bg_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));

    $total_count = $usage_data ? $usage_data->total_count : 0;
    $success_count = $usage_data ? $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? $usage_data->custom_limit : $default_limit;

    if ($success_count >= $user_limit) {
        error_log("使用限制超出 - 用户ID: $user_id, 成功次数: $success_count, 限制: $user_limit");
        echo "data: " . json_encode(array('error' => '今日使用次数已达上限')) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    $forbidden_words = array_filter(array_map('trim', explode(',', get_option('xb_excel_bg_forbidden_words', ''))));
    $input_data = $request->get_param('data') ?? '';

    if (!empty($forbidden_words)) {
        foreach ($forbidden_words as $word) {
            if (stripos($input_data, $word) !== false) {
                error_log("检测到违规词 - 用户ID: $user_id, 违规词: $word");
                echo "data: " . json_encode(array('error' => '输入内容包含违规词“' . esc_html($word) . '”，请重新编辑内容')) . "\n\n";
                ob_flush();
                flush();
                exit;
            }
        }
    }

    $platform = $request->get_param('platform') ?? '';
    $table_type = $request->get_param('table_type') ?? 'Markdown表格';
    $enable_search = filter_var($request->get_param('enable_search'), FILTER_VALIDATE_BOOLEAN);

    $prompt = "你是一个专业的表格整理助手，任务是将用户输入的内容整理成适合 Excel 或 WPS 的表格。严格遵循以下要求：\n";
    $prompt .= "1. 输入内容：'{$input_data}'，将其整理为清晰的表格，包含合理的表头和数据行。\n";
    $prompt .= "2. 目标平台：{$platform}，确保表格格式适合直接复制到 {$platform}。\n";
        if ($table_type === 'Markdown表格') {
    $prompt .= "3. 输出格式：使用 Markdown 表格语法（| 列1 | 列2 | ...），列对齐，易于复制到 Excel 或 WPS。\n";
        } else {
    $prompt .= "3. 输出格式：使用普通文本表格，格式清晰，易于复制到 Excel 或 WPS。\n";
        }
    $prompt .= "4. 仅基于用户输入内容生成表格，自动分配信息，生成合理表头和数据行，禁止生成任何与用户输入无关的内容、符号或说明。\n";
        if ($enable_search) {
    $prompt .= "5. 在生成表格前，整理用户输入内容，确保结构合理、准确、实用，仅输出表格。\n";
        }
    $prompt .= "用户输入：{$input_data}\n";
    $prompt .= "输出：仅返回适合 {$platform} 的 {$table_type}，无其他内容。";

    $api_url = get_option('xb_excel_bg_api_url', '');
    $api_key = get_option('xb_excel_bg_api_key', '');
    $model = $request->get_param('model') ?? array_map('trim', explode(',', get_option('xb_excel_bg_models', 'qwen-plus')))[0];

    if (empty($api_url) || empty($api_key)) {
        error_log("API 配置错误 - URL: $api_url, Key: " . (empty($api_key) ? '未设置' : '已设置'));
        echo "data: " . json_encode(array('error' => 'API地址或密钥未配置')) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    if ($usage_data) {
        $wpdb->update(
            $wpdb->prefix . 'excel_bg_records',
            array('total_count' => $total_count + 1),
            array('user_id' => $user_id, 'usage_date' => $today)
        );
    } else {
        $wpdb->insert(
            $wpdb->prefix . 'excel_bg_records',
            array('user_id' => $user_id, 'usage_date' => $today, 'total_count' => 1, 'success_count' => 0)
        );
    }

    $record_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}excel_bg_records WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));
    if ($input_data) {
        $wpdb->insert(
            $wpdb->prefix . 'excel_bg_themes',
            array(
                'record_id' => $record_id,
                'user_id' => $user_id,
                'theme_content' => $input_data,
                'created_at' => current_time('mysql')
            )
        );
    }

    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no');

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Bearer ' . $api_key,
        'Content-Type: application/json',
        'Accept: text/event-stream'
    ));
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
        'model' => $model,
        'messages' => array(
            array('role' => 'system', 'content' => 'You are a helpful assistant.'),
            array('role' => 'user', 'content' => $prompt)
        ),
        'stream' => true,
        'enable_search' => $enable_search
    )));

    $has_content = false;
    curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $data) use ($user_id, $today, $success_count, &$has_content) {
        global $wpdb;

        $lines = explode("\n", $data);
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;

            if (strpos($line, 'data: ') === 0) {
                $json_data = trim(substr($line, 6));
                if ($json_data === '[DONE]') {
                    if ($has_content) {
                        $wpdb->update(
                            $wpdb->prefix . 'excel_bg_records',
                            array('success_count' => $success_count + 1),
                            array('user_id' => $user_id, 'usage_date' => $today)
                        );
                    }
                    echo "data: [DONE]\n\n";
                    ob_flush();
                    flush();
                    return strlen($data);
                }

                $parsed_data = json_decode($json_data, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    error_log('JSON 解析错误: ' . json_last_error_msg() . ' - 数据: ' . $json_data);
                    continue;
                }

                if (isset($parsed_data['choices'][0]['delta']['content'])) {
                    $has_content = true;
                    echo "data: " . json_encode(array('content' => $parsed_data['choices'][0]['delta']['content'])) . "\n\n";
                    ob_flush();
                    flush();
                } elseif (isset($parsed_data['error'])) {
                    echo "data: " . json_encode(array('error' => $parsed_data['error']['message'])) . "\n\n";
                    ob_flush();
                    flush();
                    return strlen($data);
                }
            }
        }
        return strlen($data);
    });

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        error_log('cURL 请求失败: ' . $error);
        echo "data: " . json_encode(array('error' => 'API请求失败: ' . $error)) . "\n\n";
        ob_flush();
        flush();
    } elseif (!$has_content) {
        error_log('未收到有效内容 - cURL 响应状态: ' . curl_getinfo($ch, CURLINFO_HTTP_CODE));
        echo "data: " . json_encode(array('error' => '生成失败，未收到有效内容')) . "\n\n";
        ob_flush();
        flush();
    }

    curl_close($ch);
    exit;
}

// 注册激活钩子
register_activation_hook(__FILE__, 'xb_excel_bg_create_database');
register_activation_hook(__FILE__, 'xb_excel_bg_create_frontend_page');

// 注册 REST API 端点
add_action('rest_api_init', function() {
    $namespace = 'xb_excel_bg/v1';
    $endpoint = '/generate';
    $full_endpoint = rest_url($namespace . $endpoint);
    error_log("注册 REST API 端点: $full_endpoint");

    register_rest_route($namespace, $endpoint, array(
        'methods' => 'POST',
        'callback' => 'xb_excel_bg_generate_handler',
        'permission_callback' => function(WP_REST_Request $request) {
            $is_logged_in = is_user_logged_in();
            error_log("权限检查: 用户登录状态 - " . ($is_logged_in ? '已登录' : '未登录'));
            if (!$is_logged_in) {
                return new WP_Error('rest_not_logged_in', '请先登录', array('status' => 401));
    }
            $nonce = $request->get_header('X-WP-Nonce');
            if (!wp_verify_nonce($nonce, 'wp_rest')) {
                error_log("Nonce 验证失败 - 接收到的 nonce: $nonce");
                return new WP_Error('rest_forbidden', 'Nonce 验证失败', array('status' => 403));
            }
            return true;
        }
    ));

    register_rest_route($namespace, '/usage', array(
        'methods' => 'GET',
        'callback' => 'xb_excel_bg_get_usage',
        'permission_callback' => function() {
            return is_user_logged_in();
        }
    ));
});

// 获取使用情况
function xb_excel_bg_get_usage(WP_REST_Request $request) {
    global $wpdb;
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = get_option('xb_excel_bg_daily_limit', 10);

    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT total_count, success_count, custom_limit FROM {$wpdb->prefix}excel_bg_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));

    $total_count = $usage_data ? $usage_data->total_count : 0;
    $success_count = $usage_data ? $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? $usage_data->custom_limit : $default_limit;

    return array(
        'remaining' => max(0, $user_limit - $success_count),
        'limit' => $user_limit,
        'total_count' => $total_count,
        'success_count' => $success_count
    );
}

// 后台菜单
function xb_excel_bg_admin_menu() {
    add_menu_page(
        '表格整理',
        '表格整理',
        'manage_options',
        'xb-excel-bg',
        'xb_excel_bg_settings_page',
        'dashicons-grid-view'
    );
    add_submenu_page(
        'xb-excel-bg',
        '用户记录',
        '用户记录',
        'manage_options',
        'xb-excel-bg-user-records',
        'xb_excel_bg_user_records_page'
    );
}
add_action('admin_menu', 'xb_excel_bg_admin_menu');

// 注册设置
function xb_excel_bg_register_settings() {
    register_setting('xb_excel_bg_settings', 'xb_excel_bg_api_url');
    register_setting('xb_excel_bg_settings', 'xb_excel_bg_models');
    register_setting('xb_excel_bg_settings', 'xb_excel_bg_api_key');
    register_setting('xb_excel_bg_settings', 'xb_excel_bg_daily_limit');
    register_setting('xb_excel_bg_settings', 'xb_excel_bg_forbidden_words');
    register_setting('xb_excel_bg_settings', 'xb_excel_bg_ad_content');
    register_setting('xb_excel_bg_settings', 'xb_excel_bg_platforms');
    register_setting('xb_excel_bg_settings', 'xb_excel_bg_table_types');
    register_setting('xb_excel_bg_settings', 'xb_excel_bg_example');
    register_setting('xb_excel_bg_settings', 'xb_excel_bg_enable_search');

    add_settings_section(
        'xb_excel_bg_main_section',
        'API设置',
        null,
        'xb_excel_bg_settings'
    );

    add_settings_section(
        'xb_excel_bg_content_section',
        '内容设置',
        null,
        'xb_excel_bg_settings'
    );

    add_settings_field(
        'xb_excel_bg_api_url',
        'API地址',
        'xb_excel_bg_api_url_field',
        'xb_excel_bg_settings',
        'xb_excel_bg_main_section'
    );

    add_settings_field(
        'xb_excel_bg_models',
        'AI模型',
        'xb_excel_bg_models_field',
        'xb_excel_bg_settings',
        'xb_excel_bg_main_section'
    );

    add_settings_field(
        'xb_excel_bg_api_key',
        'API密钥',
        'xb_excel_bg_api_key_field',
        'xb_excel_bg_settings',
        'xb_excel_bg_main_section'
    );

    add_settings_field(
        'xb_excel_bg_daily_limit',
        '每日使用限制',
        'xb_excel_bg_daily_limit_field',
        'xb_excel_bg_settings',
        'xb_excel_bg_main_section'
    );

    add_settings_field(
        'xb_excel_bg_enable_search',
        '启用联网搜索',
        'xb_excel_bg_enable_search_field',
        'xb_excel_bg_settings',
        'xb_excel_bg_main_section'
    );

    add_settings_field(
        'xb_excel_bg_forbidden_words',
        '违规词',
        'xb_excel_bg_forbidden_words_field',
        'xb_excel_bg_settings',
        'xb_excel_bg_content_section'
    );

    add_settings_field(
        'xb_excel_bg_ad_content',
        '广告内容 (HTML)',
        'xb_excel_bg_ad_content_field',
        'xb_excel_bg_settings',
        'xb_excel_bg_content_section'
    );

    add_settings_field(
        'xb_excel_bg_platforms',
        '目标平台',
        'xb_excel_bg_platforms_field',
        'xb_excel_bg_settings',
        'xb_excel_bg_content_section'
    );

    add_settings_field(
        'xb_excel_bg_table_types',
        '表格类型',
        'xb_excel_bg_table_types_field',
        'xb_excel_bg_settings',
        'xb_excel_bg_content_section'
    );

    add_settings_field(
        'xb_excel_bg_example',
        '示例内容',
        'xb_excel_bg_example_field',
        'xb_excel_bg_settings',
        'xb_excel_bg_content_section'
    );
}
add_action('admin_init', 'xb_excel_bg_register_settings');

// 设置字段回调函数
function xb_excel_bg_api_url_field() {
    $value = get_option('xb_excel_bg_api_url', '');
    echo '<input type="text" name="xb_excel_bg_api_url" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入API地址 (如 https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions)</p>';
}

function xb_excel_bg_models_field() {
    $value = get_option('xb_excel_bg_models', 'qwen-plus');
    echo '<input type="text" name="xb_excel_bg_models" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入AI模型，用逗号分隔 (如 qwen-plus,qwen-turbo)</p>';
}

function xb_excel_bg_api_key_field() {
    $value = get_option('xb_excel_bg_api_key', '');
    echo '<input type="text" name="xb_excel_bg_api_key" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入您的API密钥</p>';
}

function xb_excel_bg_daily_limit_field() {
    $value = get_option('xb_excel_bg_daily_limit', '10');
    echo '<input type="number" name="xb_excel_bg_daily_limit" value="' . esc_attr($value) . '" min="1" />';
    echo '<p class="description">设置用户默认每日使用限制</p>';
}

function xb_excel_bg_enable_search_field() {
    $value = get_option('xb_excel_bg_enable_search', '0');
    echo '<input type="checkbox" name="xb_excel_bg_enable_search" value="1"' . checked(1, $value, false) . ' />';
    echo '<p class="description">启用后，前台将显示联网搜索开关，用户可选择是否联网搜索</p>';
}

function xb_excel_bg_forbidden_words_field() {
    $value = get_option('xb_excel_bg_forbidden_words', '');
    echo '<textarea name="xb_excel_bg_forbidden_words" rows="5" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">输入违规词，用逗号分隔</p>';
}

function xb_excel_bg_ad_content_field() {
    $value = get_option('xb_excel_bg_ad_content', '');
    echo '<textarea name="xb_excel_bg_ad_content" rows="5" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">输入广告内容 (支持HTML，图片建议尺寸：宽度不超过600px，高度不超过400px)</p>';
}

function xb_excel_bg_platforms_field() {
    $value = get_option('xb_excel_bg_platforms', 'Excel,WPS表格');
    echo '<input type="text" name="xb_excel_bg_platforms" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入目标平台，用逗号分隔 (如 Excel,WPS表格)</p>';
}

function xb_excel_bg_table_types_field() {
    $value = get_option('xb_excel_bg_table_types', 'Markdown表格,普通文本表格');
    echo '<input type="text" name="xb_excel_bg_table_types" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入表格类型，用逗号分隔 (如 Markdown表格,普通文本表格)</p>';
}

function xb_excel_bg_example_field() {
    $value = get_option('xb_excel_bg_example', "商品名称,数量,单价\n手机,2,3000\n电脑,1,5000");
    echo '<textarea name="xb_excel_bg_example" rows="6" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">输入示例内容，每行一个，格式为：列1,列2,列3</p>';
}

// 设置页面
function xb_excel_bg_settings_page() {
    ?>
    <div class="wrap">
        <h1>小半AI表格整理设置</h1>
        <?php
        if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {
            echo '<div id="setting-saved-notice" class="notice notice-success is-dismissible"><p>设置保存成功！</p></div>';
            echo '<script>
                setTimeout(function() {
                    jQuery("#setting-saved-notice").fadeOut();
                }, 3000);
            </script>';
        }
        ?>
        <form method="post" action="options.php">
            <?php
            settings_fields('xb_excel_bg_settings');
            do_settings_sections('xb_excel_bg_settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// 用户记录页面
function xb_excel_bg_user_records_page() {
    global $wpdb;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : (isset($_GET['user_id']) ? intval($_GET['user_id']) : 0);
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $per_page = 20;

    $total_usage = $wpdb->get_var("SELECT SUM(total_count) FROM {$wpdb->prefix}excel_bg_records");
    $total_success = $wpdb->get_var("SELECT SUM(success_count) FROM {$wpdb->prefix}excel_bg_records");

    $today = current_time('Y-m-d');
    $today_total_usage = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(total_count) FROM {$wpdb->prefix}excel_bg_records WHERE usage_date = %s",
        $today
    ));
    $today_total_success = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(success_count) FROM {$wpdb->prefix}excel_bg_records WHERE usage_date = %s",
        $today
    ));

    $total_all_records = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}excel_bg_themes");
    $all_records = $wpdb->get_results($wpdb->prepare(
        "SELECT t.*, r.usage_date, r.total_count, r.success_count, r.custom_limit 
        FROM {$wpdb->prefix}excel_bg_themes t 
        LEFT JOIN {$wpdb->prefix}excel_bg_records r ON t.record_id = r.id 
        ORDER BY t.created_at DESC 
        LIMIT %d OFFSET %d",
        $per_page,
        ($paged - 1) * $per_page
    ));

    ?>
    <div class="wrap">
        <h1>用户记录</h1>
        <h2>使用统计</h2>
        <p>网站总共尝试次数：<?php echo esc_html($total_usage ?: 0); ?> 次，成功次数：<?php echo esc_html($total_success ?: 0); ?> 次</p>
        <p>今日总共尝试次数：<?php echo esc_html($today_total_usage ?: 0); ?> 次，成功次数：<?php echo esc_html($today_total_success ?: 0); ?> 次</p>

        <h2>所有用户表格记录</h2>
        <?php
        if ($all_records) {
            echo '<table class="wp-list-table widefat fixed striped" id="all-records-table">';
            echo '<thead><tr><th>用户ID</th><th>日期</th><th>尝试次数</th><th>成功次数</th><th>自定义限制</th><th>输入内容</th><th>创建时间</th><th>操作</th></tr></thead>';
            echo '<tbody>';
            foreach ($all_records as $record) {
                echo '<tr>';
                echo '<td>' . esc_html($record->user_id) . '</td>';
                echo '<td>' . esc_html($record->usage_date) . '</td>';
                echo '<td>' . esc_html($record->total_count) . '</td>';
                echo '<td>' . esc_html($record->success_count) . '</td>';
                echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
                echo '<td>' . esc_html($record->theme_content ?: '无记录') . '</td>';
                echo '<td>' . esc_html($record->created_at) . '</td>';
                echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
            echo '<button id="delete-all-records">删除全部记录</button>';

            $total_pages = ceil($total_all_records / $per_page);
            if ($total_pages > 1) {
                echo '<div id="all-pagination">';
                for ($i = 1; $i <= $total_pages; $i++) {
                    printf('<a href="#" class="page-number%s" data-page="%d">%d</a>', $i === $paged ? ' active' : '', $i, $i);
                }
                echo '</div>';
            }
        } else {
            echo '<p>暂无用户记录。</p>';
        }
        ?>

        <h2>查询指定用户</h2>
        <form method="post">
            <input type="number" name="user_id" placeholder="输入用户ID" value="<?php echo esc_attr($user_id); ?>">
            <input type="submit" value="搜索" class="button">
        </form>
        <?php
        if ($user_id) {
            $user_total_usage = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(total_count) FROM {$wpdb->prefix}excel_bg_records WHERE user_id = %d",
                $user_id
            ));
            $user_total_success = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(success_count) FROM {$wpdb->prefix}excel_bg_records WHERE user_id = %d",
                $user_id
            ));

            $user_today_usage = $wpdb->get_var($wpdb->prepare(
                "SELECT total_count FROM {$wpdb->prefix}excel_bg_records WHERE user_id = %d AND usage_date = %s",
                $user_id,
                $today
            ));
            $user_today_success = $wpdb->get_var($wpdb->prepare(
                "SELECT success_count FROM {$wpdb->prefix}excel_bg_records WHERE user_id = %d AND usage_date = %s",
                $user_id,
                $today
            ));

            $total_records = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}excel_bg_records WHERE user_id = %d",
                $user_id
            ));

            $records = $wpdb->get_results($wpdb->prepare(
                "SELECT r.*, t.theme_content 
                FROM {$wpdb->prefix}excel_bg_records r 
                LEFT JOIN {$wpdb->prefix}excel_bg_themes t ON r.id = t.record_id 
                WHERE r.user_id = %d 
                ORDER BY r.usage_date DESC 
                LIMIT %d OFFSET %d",
                $user_id,
                $per_page,
                ($paged - 1) * $per_page
            ));

            echo '<h2>用户记录 (ID: ' . esc_html($user_id) . ')</h2>';
            echo '<p>用户总共尝试次数：' . esc_html($user_total_usage ?: 0) . ' 次，成功次数：' . esc_html($user_total_success ?: 0) . ' 次</p>';
            echo '<p>用户今日尝试次数：' . esc_html($user_today_usage ?: 0) . ' 次，成功次数：' . esc_html($user_today_success ?: 0) . ' 次</p>';

            if ($records) {
                echo '<table class="wp-list-table widefat fixed striped" id="user-records-table">';
                echo '<thead><tr><th>日期</th><th>尝试次数</th><th>成功次数</th><th>自定义限制</th><th>输入内容</th><th>操作</th></tr></thead>';
                echo '<tbody>';
                foreach ($records as $record) {
                    echo '<tr>';
                    echo '<td>' . esc_html($record->usage_date) . '</td>';
                    echo '<td>' . esc_html($record->total_count) . '</td>';
                    echo '<td>' . esc_html($record->success_count) . '</td>';
                    echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
                    echo '<td>' . esc_html($record->theme_content ?: '无记录') . '</td>';
                    echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
                echo '<button id="delete-all-user-records" data-user-id="' . esc_attr($user_id) . '">删除全部用户记录</button>';

                $total_pages = ceil($total_records / $per_page);
                if ($total_pages > 1) {
                    echo '<div id="pagination">';
                    for ($i = 1; $i <= $total_pages; $i++) {
                        printf('<a href="#" class="page-number%s" data-page="%d">%d</a>', $i === $paged ? ' active' : '', $i, $i);
                    }
                    echo '</div>';
                }
            } else {
                echo '<p>未找到该用户记录。</p>';
            }

            ?>
            <form method="post">
                <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="number" name="custom_limit" placeholder="自定义每日限制">
                <input type="submit" name="set_limit" value="设置自定义限制" class="button">
                <input type="submit" name="reset_limit" value="恢复默认" class="button">
            </form>
            <?php
        }
        ?>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $('#pagination .page-number').on('click', function(e) {
            e.preventDefault();
            if (!$(this).hasClass('active')) {
                var user_id = $('input[name="user_id"]').val();
                var page = $(this).data('page');
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_excel_bg_load_user_records',
                        user_id: user_id,
                        paged: page
                    },
                    success: function(response) {
                        $('#user-records-table tbody').html(response.data.records);
                        $('#pagination .page-number').removeClass('active');
                        $('#pagination .page-number[data-page="' + page + '"]').addClass('active');
                    }
                });
            }
        });

        $('#all-pagination .page-number').on('click', function(e) {
            e.preventDefault();
            if (!$(this).hasClass('active')) {
                var page = $(this).data('page');
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_excel_bg_load_all_records',
                        paged: page
                    },
                    success: function(response) {
                        $('#all-records-table tbody').html(response.data.records);
                        $('#all-pagination .page-number').removeClass('active');
                        $('#all-pagination .page-number[data-page="' + page + '"]').addClass('active');
                    }
                });
            }
        });

        $('.delete-record').on('click', function(e) {
            e.preventDefault();
            var theme_id = $(this).data('id');
            if (confirm('确定删除此记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_excel_bg_delete_record',
                        theme_id: theme_id
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#all-records-table tr').each(function() {
                                if ($(this).find('.delete-record').data('id') === theme_id) {
                                    $(this).remove();
                                }
                            });
                            $('#user-records-table tr').each(function() {
                                if ($(this).find('.delete-record').data('id') === theme_id) {
                                    $(this).remove();
                                }
                            });
                        }
                    }
                });
            }
        });

        $('#delete-all-records').on('click', function(e) {
            e.preventDefault();
            if (confirm('确定删除所有记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_excel_bg_delete_all_records'
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#all-records-table tbody').empty();
                        }
                    }
                });
            }
        });

        $('#delete-all-user-records').on('click', function(e) {
            e.preventDefault();
            var user_id = $(this).data('user-id');
            if (confirm('确定删除该用户的所有记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_excel_bg_delete_user_records',
                        user_id: user_id
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#user-records-table tbody').empty();
                        }
                    }
                });
            }
        });
    });
    </script>
    <?php
}

// AJAX 获取用户记录
add_action('wp_ajax_xb_excel_bg_load_user_records', function() {
    global $wpdb;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $paged = isset($_POST['paged']) ? max(1, intval($_POST['paged'])) : 1;
    $per_page = 20;

    if ($user_id) {
        $records = $wpdb->get_results($wpdb->prepare(
            "SELECT r.*, t.theme_content 
            FROM {$wpdb->prefix}excel_bg_records r 
            LEFT JOIN {$wpdb->prefix}excel_bg_themes t ON r.id = t.record_id 
            WHERE r.user_id = %d 
            ORDER BY r.usage_date DESC 
            LIMIT %d OFFSET %d",
            $user_id,
            $per_page,
            ($paged - 1) * $per_page
        ));

        ob_start();
        foreach ($records as $record) {
            echo '<tr>';
            echo '<td>' . esc_html($record->usage_date) . '</td>';
            echo '<td>' . esc_html($record->total_count) . '</td>';
            echo '<td>' . esc_html($record->success_count) . '</td>';
            echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
            echo '<td>' . esc_html($record->theme_content ?: '无记录') . '</td>';
            echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
            echo '</tr>';
        }
        $html = ob_get_clean();

        wp_send_json_success(array('records' => $html));
    }
    wp_die();
});

// AJAX 获取所有用户记录
add_action('wp_ajax_xb_excel_bg_load_all_records', function() {
    global $wpdb;
    $paged = isset($_POST['paged']) ? max(1, intval($_POST['paged'])) : 1;
    $per_page = 20;

    $records = $wpdb->get_results($wpdb->prepare(
        "SELECT t.*, r.usage_date, r.total_count, r.success_count, r.custom_limit 
        FROM {$wpdb->prefix}excel_bg_themes t 
        LEFT JOIN {$wpdb->prefix}excel_bg_records r ON t.record_id = r.id 
        ORDER BY t.created_at DESC 
        LIMIT %d OFFSET %d",
        $per_page,
        ($paged - 1) * $per_page
    ));

    ob_start();
    foreach ($records as $record) {
        echo '<tr>';
        echo '<td>' . esc_html($record->user_id) . '</td>';
        echo '<td>' . esc_html($record->usage_date) . '</td>';
        echo '<td>' . esc_html($record->total_count) . '</td>';
        echo '<td>' . esc_html($record->success_count) . '</td>';
        echo '<td>' . esc_html($record->custom_limit ?: '') . '</td>';
        echo '<td>' . esc_html($record->theme_content ?: '') . '</td>';
        echo '<td>' . esc_html($record->created_at) . '</td>';
        echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
        echo '</tr>';
    }
    $html = ob_get_clean();

    wp_send_json_success(array('records' => $html));
    wp_die();
});

// AJAX 删除单条记录
add_action('wp_ajax_xb_excel_bg_delete_record', function() {
    global $wpdb;
    $theme_id = isset($_POST['theme_id']) ? intval($_POST['theme_id']) : 0;
    if ($theme_id) {
        $wpdb->delete($wpdb->prefix . 'excel_bg_themes', array('id' => $theme_id));
        wp_send_json_success();
    }
    wp_send_json_error();
});

// AJAX 删除所有记录
add_action('wp_ajax_xb_excel_bg_delete_all_records', function() {
    global $wpdb;
    $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}excel_bg_themes");
    $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}excel_bg_records");
    wp_send_json_success();
});

// AJAX 删除用户所有记录
add_action('wp_ajax_xb_excel_bg_delete_user_records', function() {
    global $wpdb;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    if ($user_id) {
        $record_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}excel_bg_records WHERE user_id = %d",
            $user_id
        ));
        if ($record_ids) {
            $wpdb->delete($wpdb->prefix . 'excel_bg_themes', array('record_id' => $record_ids));
            $wpdb->delete($wpdb->prefix . 'excel_bg_records', array('user_id' => $user_id));
        }
        wp_send_json_success();
    }
    wp_send_json_error();
});

// 前台短代码
function xb_excel_bg_shortcode() {
    global $wpdb;
    $ad_content = get_option('xb_excel_bg_ad_content', '');
    $enable_search = get_option('xb_excel_bg_enable_search', '0');

    if (!is_user_logged_in()) {
        ob_start();
        ?>
        <div class="xb_excel_bg_container">
            <div class="xb_excel_bg_page_title">AI智能表格整理助手</div>
            <div class="xb_excel_bg_login_notice">
                请先登录才能使用AI智能表格整理助手。
                <button class="xb_excel_bg_quick_login_button">快速登录</button>
            </div>
            <?php if ($ad_content): ?>
            <div class="xb_excel_bg_ad">
                <?php echo wp_kses_post($ad_content); ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = get_option('xb_excel_bg_daily_limit', 10);

    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT total_count, success_count, custom_limit FROM {$wpdb->prefix}excel_bg_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));

    $success_count = $usage_data ? $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? $usage_data->custom_limit : $default_limit;
    $remaining_usage = $user_limit - $success_count;

    if ($remaining_usage < 0) {
        return '<div class="xb_excel_bg_container"><div class="xb_excel_bg_limit_notice">今日使用次数已达上限，请明天再来。</div></div>';
    }

    $models = array_map('trim', explode(',', get_option('xb_excel_bg_models', 'qwen-plus')));
    $platforms = array_map('trim', explode(',', get_option('xb_excel_bg_platforms', 'Excel,WPS表格')));
    $table_types = array_map('trim', explode(',', get_option('xb_excel_bg_table_types', 'Markdown表格,普通文本表格')));
    $example = get_option('xb_excel_bg_example', '');

    ob_start();
    ?>
    <div class="xb_excel_bg_container">
        <div class="xb_excel_bg_page_title">AI智能表格整理助手</div>

        <div class="xb_excel_bg_config">
            <div class="xb_excel_bg_page_mintitle">表格配置</div>

            <div class="xb_excel_bg_input_wrapper">
                <label for="xb_excel_bg_input">表格内容描述
                    <?php if ($example): ?>
                    <button class="xb_excel_bg_example_button" title="填入示例">
                        <span class="dashicons dashicons-admin-page"></span> 填入示例
                    </button>
                    <?php endif; ?>
                </label>
                <textarea id="xb_excel_bg_input" name="xb_excel_bg_input" placeholder="请输入表格内容描述，例如：商品名称,数量,单价 手机,2,3000 电脑,1,5000"></textarea>
            </div>

            <div class="xb_excel_bg_model_wrapper">
                <label for="xb_excel_bg_model">AI模型选择</label>
                <select id="xb_excel_bg_model" name="xb_excel_bg_model">
                    <?php foreach ($models as $model): ?>
                        <option value="<?php echo esc_attr($model); ?>"><?php echo esc_html($model); ?></option>
                    <?php endforeach; ?>
                </select>
                <?php if ($enable_search): ?>
                <div class="xb_excel_bg_search_toggle">
                    <span class="xb_excel_bg_search_label">启用联网搜索</span>
                    <label class="xb_excel_bg_search_slider">
                        <input type="checkbox" id="xb_excel_bg_enable_search" name="xb_excel_bg_enable_search">
                        <span class="slider"></span>
                    </label>
                </div>
                <?php endif; ?>
            </div>

            <?php if ($platforms): ?>
            <div class="xb_excel_bg_platforms">
                <label>目标平台</label>
                <div class="xb_excel_bg_platform_buttons">
                    <?php foreach ($platforms as $platform): ?>
                        <button class="xb_excel_bg_platform_button" data-platform="<?php echo esc_attr($platform); ?>">
                            <?php echo esc_html($platform); ?>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($table_types): ?>
            <div class="xb_excel_bg_table_types">
                <label>表格类型</label>
                <div class="xb_excel_bg_table_type_buttons">
                    <?php foreach ($table_types as $type): ?>
                        <button class="xb_excel_bg_table_type_button" data-table-type="<?php echo esc_attr($type); ?>">
                            <?php echo esc_html($type); ?>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <button class="xb_excel_bg_generate_button">开始整理表格</button>
        </div>

        <div class="xb_excel_bg_results">
            <div class="xb_excel_bg_page_mintitle">整理结果</div>
            <div class="xb_excel_bg_result_content">AI整理表格将显示在这里...</div>
            <div class="xb_excel_bg_result_buttons">
                <button class="xb_excel_bg_copy_button">一键复制</button>
                <button class="xb_excel_bg_clear_button">清空</button>
            </div>
            <div class="xb_excel_bg_copy_success"></div>
            <div class="xb_excel_bg_usage">今日可用次数：<?php echo esc_html($user_limit . '/' . $remaining_usage); ?></div>
        </div>

        <?php if ($ad_content): ?>
        <div class="xb_excel_bg_ad">
            <?php echo wp_kses_post($ad_content); ?>
        </div>
        <?php endif; ?>
    </div>

    <script>
        var xb_excel_bg_example_data = <?php echo json_encode($example ? implode('\n', array_map('trim', explode('\n', $example))) : ''); ?>;
        console.log('Excel BG Plugin: Shortcode rendered successfully.');
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('xb_excel_bg_shortcode', 'xb_excel_bg_shortcode');

// 处理自定义限制更新
add_action('admin_post', function() {
    if (isset($_POST['user_id']) && (isset($_POST['set_limit']) || isset($_POST['reset_limit']))) {
        global $wpdb;
        $user_id = intval($_POST['user_id']);

        if (isset($_POST['set_limit']) && !empty($_POST['custom_limit'])) {
            $custom_limit = intval($_POST['custom_limit']);
            $wpdb->update(
                $wpdb->prefix . 'excel_bg_records',
                array('custom_limit' => $custom_limit),
                array('user_id' => $user_id)
            );
        } elseif (isset($_POST['reset_limit'])) {
            $wpdb->update(
                $wpdb->prefix . 'excel_bg_records',
                array('custom_limit' => null),
                array('user_id' => $user_id)
            );
        }

        wp_redirect(admin_url('admin.php?page=xb-excel-bg-user-records&user_id=' . $user_id));
        exit;
    }
});

// 增强 REST API 权限检查
add_filter('rest_authentication_errors', function($result) {
    if (is_wp_error($result)) {
        return $result;
    }
    if (!is_user_logged_in()) {
        return new WP_Error(
            'rest_not_logged_in',
            '您必须登录才能访问此资源。',
            array('status' => 401)
        );
    }
    return $result;
});
?>