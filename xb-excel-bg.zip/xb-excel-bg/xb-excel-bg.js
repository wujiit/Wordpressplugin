(function($) {
    console.log('Excel BG Plugin: JavaScript initialized.');

    // 平台按钮处理
    $(document).on('click', '.xb_excel_bg_platform_button', function() {
        console.log('Platform button clicked:', $(this).data('platform'));
        $('.xb_excel_bg_platform_button').removeClass('active');
        $(this).addClass('active');
    });

    // 表格类型按钮处理
    $(document).on('click', '.xb_excel_bg_table_type_button', function() {
        console.log('Table type button clicked:', $(this).data('table-type'));
        $('.xb_excel_bg_table_type_button').removeClass('active');
        $(this).addClass('active');
    });

    // 示例按钮
    $(document).on('click', '.xb_excel_bg_example_button', function(e) {
        e.preventDefault();
        console.log('Example button clicked.');
        var $textarea = $('#xb_excel_bg_input');
        var exampleLines = xb_excel_bg_example_data.split('\n');
        var newValue = exampleLines.join('\n');
        $textarea.val(newValue);
    });

    // 解析普通文本表格为HTML表格
    function parseTextTableToHtml(text, tableType) {
        if (tableType !== '普通文本表格') {
            return $('<div>').text(text).html(); // 对于Markdown表格，直接显示原始文本
        }

        // 按行分割
        const lines = text.trim().split('\n').filter(line => line.trim());
        if (lines.length === 0) return '<p>无有效表格内容</p>';

        // 创建表格元素
        const $table = $('<table class="xb_excel_bg_table">');
        let isFirstRow = true;

        lines.forEach(line => {
            // 按制表符或多个空格分割
            const cells = line.split(/\t| {2,}/).map(cell => cell.trim()).filter(cell => cell);
            if (cells.length === 0) return;

            const $row = $('<tr>');
            cells.forEach(cell => {
                const $cell = isFirstRow ? $('<th>') : $('<td>');
                $cell.text(cell);
                $row.append($cell);
            });
            $table.append($row);
            isFirstRow = false;
        });

        return $table.prop('outerHTML');
    }

    // 获取HTML表格内容用于复制
    function getTableForCopy() {
        const $resultContent = $('.xb_excel_bg_result_content');
        const tableType = $('.xb_excel_bg_table_type_button.active').data('table-type') || 'Markdown表格';
        
        if (tableType === '普通文本表格') {
            // 复制HTML表格的纯文本表示
            const $table = $resultContent.find('table');
            if ($table.length) {
                let text = '';
                $table.find('tr').each(function() {
                    const cells = $(this).find('th, td').map(function() {
                        return $(this).text().trim();
                    }).get();
                    text += cells.join('\t') + '\n';
                });
                return text;
            }
        }
        // 对于Markdown表格，直接返回原始文本
        return rawTableContent;
    }

    // 存储原始文本内容，用于复制
    let rawTableContent = '';

    // 生成按钮
    $(document).on('click', '.xb_excel_bg_generate_button', function(e) {
        e.preventDefault();
        console.log('Generate button clicked.');

        var $resultContent = $('.xb_excel_bg_result_content');
        var inputData = $('#xb_excel_bg_input').val();
        var $generateButton = $(this);
        var tableType = $('.xb_excel_bg_table_type_button.active').data('table-type') || 'Markdown表格';

        // 前端验证违规词
        var forbiddenWords = XBExcelBGData.forbidden_words || [];
        var foundForbiddenWord = null;
        if (forbiddenWords.length > 0) {
            forbiddenWords.forEach(function(word) {
                if (inputData.toLowerCase().indexOf(word.toLowerCase()) !== -1) {
                    foundForbiddenWord = word;
                }
            });
        }

        if (foundForbiddenWord) {
            console.log('Forbidden word detected: ', foundForbiddenWord);
            $resultContent.html('<p class="xb_excel_bg_error">输入内容包含违规词“' + $('<div>').text(foundForbiddenWord).html() + '”，请重新编辑内容</p>');
            return;
        }

        // 显示加载中状态
        $resultContent.html('<span class="loading">正在整理中...</span>');

        // 确保用户登录
        if (!XBExcelBGData.nonce) {
            console.log('Nonce not found, user not logged in.');
            $resultContent.html('<p class="xb_excel_bg_error">请先登录以使用表格整理助手。</p>');
            return;
        }

        var data = {
            model: $('#xb_excel_bg_model').val(),
            data: inputData,
            platform: $('.xb_excel_bg_platform_button.active').data('platform') || '',
            table_type: tableType,
            enable_search: $('#xb_excel_bg_enable_search').is(':checked')
        };

        console.log('Sending API request with data:', data);

        // 禁用生成按钮，防止重复点击
        $generateButton.prop('disabled', true);

        // 使用 fetch 发起 REST API 请求
        fetch(XBExcelBGData.rest_url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': XBExcelBGData.nonce,
                'Accept': 'text/event-stream'
            },
            body: JSON.stringify(data)
        }).then(response => {
            if (!response.ok) {
                return response.json().then(json => {
                    throw new Error(json.message || '未知错误');
                });
            }

            console.log('API request successful, processing stream...');
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let done = false;
            let hasContent = false;
            rawTableContent = ''; // 重置原始内容

            function readStream() {
                reader.read().then(({ done: streamDone, value }) => {
                    if (streamDone) {
                        done = true;
                        if (hasContent) {
                            console.log('Stream completed, updating usage count.');
                            updateUsageCount();
                            // 渲染最终内容
                            $resultContent.html(parseTextTableToHtml(rawTableContent, tableType));
                        } else {
                            console.log('No content received.');
                            $resultContent.html('<p class="xb_excel_bg_error">生成失败，未收到有效内容。</p>');
                        }
                        $generateButton.prop('disabled', false);
                        return;
                    }

                    const chunk = decoder.decode(value, { stream: true });
                    const lines = chunk.split('\n');
                    lines.forEach(line => {
                        if (line.trim().startsWith('data: ')) {
                            const jsonData = line.trim().substring(6);
                            if (jsonData === '[DONE]') {
                                done = true;
                                if (hasContent) {
                                    console.log('Stream done, updating usage count.');
                                    updateUsageCount();
                                    // 渲染最终内容
                                    $resultContent.html(parseTextTableToHtml(rawTableContent, tableType));
                                } else {
                                    console.log('No content received at stream end.');
                                    $resultContent.html('<p class="xb_excel_bg_error">生成失败，未收到有效内容。</p>');
                                }
                                $generateButton.prop('disabled', false);
                                return;
                            }

                            try {
                                const data = JSON.parse(jsonData);
                                if (data.error) {
                                    console.log('API error:', data.error);
                                    $resultContent.html('<p class="xb_excel_bg_error">' + $('<div>').text(data.error).html() + '</p>');
                                    $generateButton.prop('disabled', false);
                                    return;
                                }
                                if (data.content) {
                                    hasContent = true;
                                    rawTableContent += data.content; // 累积原始内容
                                    if ($resultContent.text() === '正在生成中...') {
                                        $resultContent.empty();
                                    }
                                    // 实时渲染（仅为流式效果，完成后重渲染）
                                    $resultContent.append($('<div>').text(data.content).html());
                                    console.log('Received content chunk:', data.content);
                                }
                            } catch (e) {
                                console.error('解析流数据出错:', e, ' - 原始数据:', jsonData);
                                $resultContent.html('<p class="xb_excel_bg_error">生成过程中发生错误，请检查日志。</p>');
                                $generateButton.prop('disabled', false);
                            }
                        }
                    });

                    if (!done) {
                        readStream();
                    }
                }).catch(error => {
                    console.error('Stream reading failed:', error);
                    $resultContent.html('<p class="xb_excel_bg_error">生成过程中发生错误。</p>');
                    $generateButton.prop('disabled', false);
                });
            }

            readStream();
        }).catch(error => {
            console.error('API request failed:', error);
            $resultContent.html('<p class="xb_excel_bg_error">' + $('<div>').text(error.message).html() + '</p>');
            $generateButton.prop('disabled', false);
        });
    });

    // 复制按钮
    $(document).on('click', '.xb_excel_bg_copy_button', function(e) {
        e.preventDefault();
        console.log('Copy button clicked.');
        var $temp = $('<textarea>');
        $('body').append($temp);
        // 使用 getTableForCopy 获取适合复制的内容
        $temp.val(getTableForCopy()).select();
        try {
            document.execCommand('copy');
            $('.xb_excel_bg_copy_success').html('<p class="copy-success">复制成功！</p>');
            setTimeout(function() {
                $('.xb_excel_bg_copy_success').empty();
            }, 2000);
        } catch (err) {
            console.error('Copy failed:', err);
            $('.xb_excel_bg_copy_success').html('<p class="copy-error">复制失败，请手动复制。</p>');
        }
        $temp.remove();
    });

    // 清空按钮
    $(document).on('click', '.xb_excel_bg_clear_button', function(e) {
        e.preventDefault();
        console.log('Clear button clicked.');
        $('.xb_excel_bg_result_content').empty();
        rawTableContent = ''; // 清空原始内容
    });

    // 快速登录按钮
    $(document).on('click', '.xb_excel_bg_quick_login_button', function(e) {
        e.preventDefault();
        console.log('Quick login button clicked.');
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.click();
        } else {
            window.location.href = '<?php echo esc_url(wp_login_url(get_permalink())); ?>';
        }
    });

    // 更新使用次数显示
    function updateUsageCount() {
        console.log('Updating usage count via AJAX.');
        $.ajax({
            url: XBExcelBGData.rest_url.replace('/generate', '/usage'),
            method: 'GET',
            headers: {
                'X-WP-Nonce': XBExcelBGData.nonce
            },
            success: function(response) {
                console.log('Usage count updated:', response);
                var $usageDisplay = $('.xb_excel_bg_usage');
                var $generateButton = $('.xb_excel_bg_generate_button');
                if (response.remaining <= 0) {
                    $usageDisplay.text('今日已用尽可用次数，请明天再来');
                    $generateButton.hide();
                } else {
                    $usageDisplay.text('今日可用次数：' + response.limit + '/' + response.remaining);
                    $generateButton.show();
                }
            },
            error: function(error) {
                console.error('Failed to update usage count:', error);
                $('.xb_excel_bg_usage').text('今日可用次数：无法加载');
                $('.xb_excel_bg_generate_button').hide();
            }
        });
    }

    // 启用联网搜索开关的点击处理
    $(document).on('click', '.xb_excel_bg_search_toggle .slider', function(e) {
        e.preventDefault();
        var $checkbox = $(this).siblings('input[type="checkbox"]');
        $checkbox.prop('checked', !$checkbox.prop('checked'));
        console.log('Search switch clicked, new state:', $checkbox.prop('checked'));
    });

    // 防止点击文字触发开关
    $(document).on('click', '.xb_excel_bg_search_toggle', function(e) {
        if (!$(e.target).hasClass('slider')) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Clicked search toggle label or surrounding area, no toggle action.');
        }
    });

    // 页面加载时初始化使用次数
    $(document).ready(function() {
        updateUsageCount();
    });

    // 初始化检查
    console.log('XBExcelBGData:', XBExcelBGData);
})(jQuery);