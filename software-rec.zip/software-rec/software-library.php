<?php
/*
 * Plugin Name: 软件库插件
 * Description: 一个用于管理和显示软件信息的插件
 * Plugin URI: https://www.jingxialai.com/4865.html
 * Version: 1.0
 * Author: Summer
 * License: GPL License
 * Author URI: https://www.jingxialai.com/
*/

if (!defined('ABSPATH')) {
    exit; // 防止直接访问
}

class MySoftwareLibraryPlugin {
    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'software_library';

        // 注册激活/停用钩子
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);

        // 使用静态方法注册卸载钩子
        register_uninstall_hook(__FILE__, ['MySoftwareLibraryPlugin', 'uninstall']);

        // 后台菜单
        add_action('admin_menu', [$this, 'add_admin_menu']);
        
        // 前台短代码
        add_shortcode('software_library', [$this, 'render_frontend_page']);
    }

    // 插件激活时创建数据表
    public function activate() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$this->table_name} (
            id MEDIUMINT NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            version VARCHAR(50) NOT NULL,
            environment VARCHAR(255),
            release_date DATE,
            description TEXT,
            link VARCHAR(255),
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // 创建一个默认前台页面
        if (!get_page_by_path('software-library')) {
            wp_insert_post([
                'post_title'   => '软件库',
                'post_content' => '[software_library]',
                'post_status'  => 'publish',
                'post_type'    => 'page',
            ]);
        }
    }

    // 插件停用时不删除数据表
    public function deactivate() {
        // 不执行任何操作，避免删除数据表
    }

    // 静态方法：插件卸载时删除数据表和数据
    public static function uninstall() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'software_library';
        $wpdb->query("DROP TABLE IF EXISTS {$table_name}");
    }

    // 添加后台菜单
    public function add_admin_menu() {
        add_menu_page(
            '软件库管理',
            '软件库',
            'manage_options',
            'software-library',
            [$this, 'render_admin_page'],
            'dashicons-admin-generic'
        );
    }

    // 后台页面内容
    public function render_admin_page() {
        global $wpdb;
        $action = $_GET['action'] ?? '';
        $id = $_GET['id'] ?? 0;

        // 添加或编辑软件信息
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $name = sanitize_text_field($_POST['name']);
            $version = sanitize_text_field($_POST['version']);
            $environment = sanitize_text_field($_POST['environment']);
            $release_date = sanitize_text_field($_POST['release_date']);
            $description = sanitize_textarea_field($_POST['description']);
            $link = esc_url_raw($_POST['link']);

            if ($action === 'edit' && $id) {
                $wpdb->update($this->table_name, compact('name', 'version', 'environment', 'release_date', 'description', 'link'), ['id' => $id]);
            } else {
                $wpdb->insert($this->table_name, compact('name', 'version', 'environment', 'release_date', 'description', 'link'));
            }

            // 使用输出缓冲避免 headers already sent
            ob_start(); // 开始输出缓冲
            wp_redirect(admin_url('admin.php?page=software-library')); // 重定向
            exit; // 确保没有其他输出
        }

        // 删除软件信息
        if ($action === 'delete' && $id) {
            $wpdb->delete($this->table_name, ['id' => $id]);
            ob_start(); // 开始输出缓冲
            wp_redirect(admin_url('admin.php?page=software-library'));
            exit;
        }

        // 显示表单
        if ($action === 'add' || ($action === 'edit' && $id)) {
            $software = $id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table_name} WHERE id = %d", $id)) : null;
            ?>
            <div class="wrap">
                <h1><?php echo $id ? '编辑软件信息' : '添加软件信息'; ?></h1>
                <form method="post">
                    <table class="form-table">
                        <tr>
                            <th><label for="name">名称</label></th>
                            <td><input name="name" id="name" type="text" value="<?php echo esc_attr($software->name ?? ''); ?>" required></td>
                        </tr>
                        <tr>
                            <th><label for="version">版本</label></th>
                            <td><input name="version" id="version" type="text" value="<?php echo esc_attr($software->version ?? ''); ?>" required></td>
                        </tr>
                        <tr>
                            <th><label for="environment">环境</label></th>
                            <td><input name="environment" id="environment" type="text" value="<?php echo esc_attr($software->environment ?? ''); ?>"></td>
                        </tr>
                        <tr>
                            <th><label for="release_date">发布日期</label></th>
                            <td><input name="release_date" id="release_date" type="date" value="<?php echo esc_attr($software->release_date ?? ''); ?>"></td>
                        </tr>
                        <tr>
                            <th><label for="description">说明</label></th>
                            <td><textarea name="description" id="description"><?php echo esc_textarea($software->description ?? ''); ?></textarea></td>
                        </tr>
                        <tr>
                            <th><label for="link">链接</label></th>
                            <td><input name="link" id="link" type="url" value="<?php echo esc_url($software->link ?? ''); ?>"></td>
                        </tr>
                    </table>
                    <p><input type="submit" class="button button-primary" value="保存"></p>
                </form>
            </div>
            <?php
            return;
        }

        // 显示软件列表
        $softwares = $wpdb->get_results("SELECT * FROM {$this->table_name}");
        ?>
        <div class="wrap">
            <h1>软件库管理 <a href="?page=software-library&action=add" class="page-title-action">添加新软件</a></h1>
            <table class="widefat">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>名称</th>
                        <th>版本</th>
                        <th>环境</th>
                        <th>发布日期</th>
                        <th>说明</th>
                        <th>链接</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($softwares as $software) : ?>
                        <tr>
                            <td><?php echo $software->id; ?></td>
                            <td><?php echo esc_html($software->name); ?></td>
                            <td><?php echo esc_html($software->version); ?></td>
                            <td><?php echo esc_html($software->environment); ?></td>
                            <td><?php echo esc_html($software->release_date); ?></td>
                            <td><?php echo esc_html($software->description); ?></td>
                            <td><a href="<?php echo esc_url($software->link); ?>" target="_blank">链接</a></td>
                            <td>
                                <a href="?page=software-library&action=edit&id=<?php echo $software->id; ?>">编辑</a> |
                                <a href="?page=software-library&action=delete&id=<?php echo $software->id; ?>" onclick="return confirm('确定删除吗？')">删除</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    // 前台页面内容
    public function render_frontend_page() {
        global $wpdb;
        $softwares = $wpdb->get_results("SELECT * FROM {$this->table_name} ORDER BY release_date DESC LIMIT 10");
        ob_start();
        ?>
        <style>
            table {
                width: 100%;
                border-collapse: collapse;
            }
            .software-library th, .software-library td {
                border: 1px solid #ddd;
                padding: 10px;
                text-align: left;
            }
            .software-library th {
                background-color: #007cba;
            }
            .software-library tr:nth-child(even) {
                background-color: #f2f2f2;
            }
            .software-library a {
                color: #007cba;
                text-decoration: none;
            }
            .software-library a:hover {
                text-decoration: underline;
            }
        </style>
        <div class="software-library">
            <h1>近期更新的10款软件 - 同类优先推荐列表</h1>
            <table>
                <thead>
                    <tr>
                        <th>名称</th>
                        <th>版本</th>
                        <th>环境</th>
                        <th>发布日期</th>
                        <th>说明</th>
                        <th>链接</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($softwares as $software) : ?>
                        <tr>
                            <td><?php echo esc_html($software->name); ?></td>
                            <td><?php echo esc_html($software->version); ?></td>
                            <td><?php echo esc_html($software->environment); ?></td>
                            <td><?php echo esc_html($software->release_date); ?></td>
                            <td><?php echo esc_html($software->description); ?></td>
                            <td><a href="<?php echo esc_url($software->link); ?>" target="_blank">查看</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <p>有时候，同一天会有多款相关软件更新，但并非所有软件我都特别推荐。因此，这里只列出近期更新中我优先推荐的软件.<br>
        比如，同为图片查重软件，如果我一天更新了A、B、C三款，但更推荐A，那么这里就会优先展示A.</p>
        <?php
        return ob_get_clean();
    }
}

// 初始化插件
new MySoftwareLibraryPlugin();
