<?php
// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 创建插件设置页面
function crd_add_settings_page() {
    add_options_page(
        '小半自定义资源设置页面',
        '小半资源设置',
        'manage_options',
        'crd-settings',
        'crd_render_settings_page'
    );
}
add_action('admin_menu', 'crd_add_settings_page');

// 渲染设置页面
function crd_render_settings_page() {
    ?>
    <div class="crdwrap">
        <h1>小半自定义资源设置页面</h1>
        <div class="crd-settings-info">
            <p>如果保存之后没有生效，请清除网站的缓存。</p>
        </div>
        <form method="post" action="options.php">
            <?php
            settings_fields('crd_settings_group');
            do_settings_sections('crd-settings');
            submit_button();
            ?>
        </form>
        <style>
            .crdwrap {
                
            }
            .crd-settings-info {
                margin-bottom: 20px;
                padding: 10px;
                background-color: #f7f7f7;
                border-left: 4px solid #0073aa;
            }
            .crd-settings-info p {
                margin: 0;
                color: #ff0000;
                font-size: 14px;
            }
            .form-table th {
                padding: 10px 15px;
                text-align: left;
                background-color: #f1f1f1;
                border-bottom: 1px solid #ddd;
            }
            .form-table td {
                padding: 10px 15px;
                border-bottom: 1px solid #ddd;
            }
            .button-primary {
                background: #0073aa;
                border: none;
                color: #fff;
                padding: 10px 15px;
                text-decoration: none;
                border-radius: 3px;
                font-size: 14px;
            }
            .button-primary:hover {
                background: #005177;
            }
        </style>
    </div>
    <?php
}

// 注册设置
function crd_register_settings() {
    // 注册设置
    register_setting('crd_settings_group', 'crd_lockout_software_info'); // 隐藏文章中的信息
    register_setting('crd_settings_group', 'crd_delete_data_on_uninstall'); // 卸载字段
    register_setting('crd_settings_group', 'crd_visitors_download'); // 游客下载
    register_setting('crd_settings_group', 'crd_download_agreement'); // 下载协议
    register_setting('crd_settings_group', 'crd_enable_password_protection'); // 验证
    register_setting('crd_settings_group', 'crd_password_answer'); // 验证密码
    register_setting('crd_settings_group', 'crd_password_image'); // 验证图片
    register_setting('crd_settings_group', 'crd_password_prompt'); // 验证提示
    
    // 设置部分
    add_settings_section(
        'crd_settings_section',
        '设置选项',
        null,
        'crd-settings'
    );

    // 隐藏文章中的软件信息
    add_settings_field(
        'crd_lockout_software_info',
        '隐藏文章中的软件信息',
        'crd_lockout_software_info_callback',
        'crd-settings',
        'crd_settings_section'
    );

    // 卸载时删掉插件数据
    add_settings_field(
        'crd_delete_data_on_uninstall',
        '卸载时删掉插件数据',
        'crd_delete_data_on_uninstall_callback',
        'crd-settings',
        'crd_settings_section'
    );

    // 允许游客下载
    add_settings_field(
        'crd_visitors_download',
        '允许未登录的游客下载',
        'crd_visitors_download_callback',
        'crd-settings',
        'crd_settings_section'
    );

    // 下载协议
    add_settings_field(
        'crd_download_agreement',
        '下载协议',
        'crd_download_agreement_callback',
        'crd-settings',
        'crd_settings_section'
    );

    // 开启验证密码
    add_settings_field(
        'crd_enable_password_protection',
        '开启验证密码',
        'crd_enable_password_protection_callback',
        'crd-settings',
        'crd_settings_section'
    );

    // 验证答案
    add_settings_field(
        'crd_password_answer',
        '验证答案',
        'crd_password_answer_callback',
        'crd-settings',
        'crd_settings_section'
    );

    // 验证图片
    add_settings_field(
        'crd_password_image',
        '验证图片',
        'crd_password_image_callback',
        'crd-settings',
        'crd_settings_section'
    );

    // 验证提示
    add_settings_field(
        'crd_password_prompt',
        '验证提示',
        'crd_password_prompt_callback',
        'crd-settings',
        'crd_settings_section'
    );
add_action('updated_option', 'crd_flush_cache_on_update', 10, 3);
}
add_action('admin_init', 'crd_register_settings');



// 不显示软件信息的回调函数
function crd_lockout_software_info_callback() {
    $option = get_option('crd_lockout_software_info');
    ?>
    <input type="checkbox" name="crd_lockout_software_info" value="1" <?php checked(1, $option, true); ?> />
    <label for="crd_lockout_software_info">勾选之后文章中不显示软件信息.</label>
    <?php
}

// 删掉插件的数据的回调函数
function crd_delete_data_on_uninstall_callback() {
    $option = get_option('crd_delete_data_on_uninstall');
    ?>
    <input type="checkbox" name="crd_delete_data_on_uninstall" value="1" <?php checked(1, $option, true); ?> />
    <label for="crd_delete_data_on_uninstall">勾选之后卸载插件的时候会删掉插件的数据（请先备份数据库）.</label>
    <?php
}

// 游客也能下载的回调函数
function crd_visitors_download_callback() {
    $option = get_option('crd_visitors_download');
    ?>
    <input type="checkbox" name="crd_visitors_download" value="1" <?php checked(1, $option, true); ?> />
    <label for="crd_visitors_download">勾选之后没有登录的游客也能下载.</label>
    <?php
}

// 下载协议内容的回调函数
function crd_download_agreement_callback() {
    $option = get_option('crd_download_agreement');
    ?>
    <textarea name="crd_download_agreement" rows="3" cols="50" ><?php echo esc_textarea($option); ?></textarea>
    <p class="description">请输入下载协议内容，然后下载链接使用“协议下载”，用户点击协议下载按钮时显示这个内容。</p>
    <?php
}

// 开启验证密码的回调函数
function crd_enable_password_protection_callback() {
    $option = get_option('crd_enable_password_protection');
    ?>
    <input type="checkbox" name="crd_enable_password_protection" value="1" <?php checked(1, $option, true); ?> />
    <label for="crd_enable_password_protection">勾选开启密码验证功能.</label>
    <?php
}

// 验证答案的回调函数
function crd_password_answer_callback() {
    $option = get_option('crd_password_answer');
    ?>
    <input type="text" name="crd_password_answer" value="<?php echo esc_attr($option); ?>" />
    <p class="description">请输入用于验证的答案.</p>
    <?php
}

function crd_password_prompt_callback() {
    $option = get_option('crd_password_prompt');
    ?>
    <textarea name="crd_password_prompt" rows="2" cols="50" ><?php echo esc_textarea($option); ?></textarea>
    <p class="description">请输入验证框文字提示内容，在验证框会显示这行文字说明.</p>
    <?php
}

// 验证图片的回调函数
function crd_password_image_callback() {
    $option = get_option('crd_password_image');
    ?>
    <input type="text" name="crd_password_image" id="crd_password_image" value="<?php echo esc_url($option); ?>" />
    <input type="button" class="button button-secondary" value="选择图片" id="crd_upload_image_button" />
    <p class="description">选择在验证框会显示的图片(可以放公众号二维码，然后在公众号设置关键词回复你的验证答案).</p>
    <script>
    jQuery(document).ready(function($) {
        $('#crd_upload_image_button').click(function(e) {
            e.preventDefault();
            var custom_uploader = wp.media({
                title: '选择图片',
                button: {
                    text: '使用此图片'
                },
                multiple: false
            }).on('select', function() {
                var attachment = custom_uploader.state().get('selection').first().toJSON();
                $('#crd_password_image').val(attachment.url);
            }).open();
        });
    });
    </script>
    <?php
}

function crd_flush_cache_on_update($option, $old_value, $new_value) {
    // 仅在特定选项更新时清除缓存
    if (in_array($option, array('crd_lockout_software_info', 'crd_delete_data_on_uninstall', 'crd_visitors_download', 'crd_download_agreement', 'crd_enable_password_protection', 'crd_password_answer', 'crd_password_image', 'crd_password_prompt'))) {
        wp_cache_flush();
    }
}
