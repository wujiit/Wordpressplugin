<?php
/*
Plugin Name: 小半数字资源下载
Plugin URI: https://www.jingxialai.com/4827.html
Description: 一个简单的自定义资源下载工具，支持自动复制磁力链接，适合各类免费资源站使用。
Version: 1.9.1
Author: Summer
License: GPL License
Author URI: https://www.jingxialai.com/
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 注册自定义字段
function crd_add_custom_meta_box() {
    add_meta_box(
        'crd_software_info',
        '小半资源设置',
        'crd_meta_box_callback',
        'post',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'crd_add_custom_meta_box');

// 在插件中心添加设置链接
function crd_add_settings_link($links) {
    $settings_link = '<a href="options-general.php?page=crd-settings">设置</a>';
    array_push($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'crd_add_settings_link');

// 自定义字段的回调函数
function crd_meta_box_callback($post) {
    echo '<style>
            .crd-meta-box p {
                margin: 10px 0;
            }
            .crd-meta-box label {
                display: inline-block;
                width: 150px;
                margin-right: 10px;
            }
            .crd-meta-box input.crd-input {
                width: 50%;
                padding: 5px;
                box-sizing: border-box;
            }
            .required-star {
                color: red;
                margin-left: 5px;
            }
          </style>';

    wp_nonce_field('crd_save_meta_box_data', 'crd_meta_box_nonce');

    echo '<div class="crd-meta-box">';

    $fields = [
        'crd_software_name' => '资源名称',
        'crd_software_version' => '资源版本',
        'crd_software_environment' => '运行环境',
        'crd_software_fileformat' => '文件格式',
        'crd_software_size' => '文件大小',
        'crd_software_paid' => '收费情况',
        'crd_software_update' => '更新时间',
        'crd_demo_url' => '演示地址',
        'crd_download_name1' => '网盘名称(默认网盘下载)',
        'crd_download_url1' => '网盘链接',
        'crd_download_password1' => '网盘访问密码',
        'crd_download_name2' => '直连名称(默认直连下载)',
        'crd_download_url2' => '直连链接',
        'crd_download_name3' => 'BT名称(默认磁力链接)',
        'crd_download_url3' => '磁力链接',
        'crd_protocol_url' => '协议下载链接',
    ];

    foreach ($fields as $field => $label) {
        $value = get_post_meta($post->ID, '_' . $field, true);
        echo '<p>';
        echo '<label for="' . esc_attr($field) . '">' . esc_html($label) . ':';
        if ($field === 'crd_software_name') {
            echo '<span class="required-star">*</span>';
        }
        echo '</label>';
        echo '<input type="text" id="' . esc_attr($field) . '" name="' . esc_attr($field) . '" value="' . esc_attr($value) . '" class="crd-input" />';
        echo '</p>';
    }
    echo '</div>';
}

// 保存自定义字段
function crd_save_meta_box_data($post_id) {
    if (!isset($_POST['crd_meta_box_nonce']) || !wp_verify_nonce($_POST['crd_meta_box_nonce'], 'crd_save_meta_box_data')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $fields = [
        'crd_software_name',
        'crd_software_version',
        'crd_software_environment',
        'crd_software_fileformat',
        'crd_software_size',
        'crd_software_paid',
        'crd_software_update',
        'crd_demo_url',      
        'crd_download_name1',
        'crd_download_url1',
        'crd_download_password1',
        'crd_download_name2',
        'crd_download_url2',
        'crd_download_name3',
        'crd_download_url3',
        'crd_protocol_url',  
    ];

    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
        }
    }
}
add_action('save_post', 'crd_save_meta_box_data');

// 文章板块
function crd_display_software_info($content) {
    if (is_single()) {
        global $post;

        // 检查后台设置
        $hide_software_info = get_option('crd_lockout_software_info');
        
        // 如果开启就隐藏
        if ($hide_software_info) {
            return $content;
        }
        
        $fields = [
            'crd_software_name' => '名称',
            'crd_software_version' => '版本',
            'crd_software_environment' => '运行环境',
            'crd_software_fileformat' => '文件格式',
            'crd_software_size' => '文件大小',
            'crd_software_paid' => '收费情况',
            'crd_software_update' => '更新时间',
            'crd_download_password1' => '网盘访问密码',
        ];

        $has_software_info = false;
        $download_fields = ['crd_download_url1', 'crd_download_url2', 'crd_download_url3', 'crd_protocol_url'];
        foreach ($download_fields as $field) {
            $url = get_post_meta($post->ID, '_' . $field, true);
            if (!empty($url)) {
                $has_software_info = true;
                break;
            }
        }

        if ($has_software_info) {
            $software_info = '<div class="software-info">';
            $software_info .= '<h3>资源信息</h3>';

            foreach ($fields as $field => $label) {
                $value = get_post_meta($post->ID, '_' . $field, true);
                if (!empty($value)) {
                    $software_info .= '<p><strong>' . esc_html($label) . ':</strong> ' . esc_html($value) . '</p>';
                }
            }

            $software_info .= '<p><strong>下载地址：</strong></p>';

            $demo_url = get_post_meta($post->ID, '_crd_demo_url', true);
            if ($demo_url) {
                $software_info .= '<p><a href="' . esc_url($demo_url) . '" class="download-button download-demo" target="_blank">演示地址</a></p>';
            }

            $download_names_urls = [
                ['name' => 'crd_download_name1', 'url' => 'crd_download_url1', 'default' => '网盘下载', 'class' => 'download-address1'],
                ['name' => 'crd_download_name2', 'url' => 'crd_download_url2', 'default' => '直连下载', 'class' => 'download-address2'],
                ['name' => 'crd_download_name3', 'url' => 'crd_download_url3', 'default' => '磁力链接']
            ];

            foreach ($download_names_urls as $item) {
                $name = get_post_meta($post->ID, '_' . $item['name'], true);
                $url = get_post_meta($post->ID, '_' . $item['url'], true);
                $name = $name ?: $item['default'];

                if ($url) {
                    if (isset($item['class'])) {
                        $software_info .= '<p><a href="#" class="download-button ' . esc_attr($item['class']) . '" data-type="' . esc_attr($item['url']) . '">' . esc_html($name) . '</a></p>';
                    } else {
                        $software_info .= '<p><button class="download-button copy-magnet" data-magnet="' . esc_attr($url) . '">' . esc_html($name) . '</button></p>';
                        $software_info .= '<div id="crd-message" style="display:none; padding:10px; background-color:#dff0d8; border:1px solid #d0e9c6; color:#3c763d; margin-top:10px;">复制成功!</div>';
                        $software_info .= '<script type="text/javascript">
                            document.addEventListener("DOMContentLoaded", function() {
                                document.querySelectorAll(".copy-magnet").forEach(function(button) {
                                    button.addEventListener("click", function() {
                                        var magnetLink = button.getAttribute("data-magnet");
                                        var dummy = document.createElement("input");
                                        document.body.appendChild(dummy);
                                        dummy.value = magnetLink;
                                        dummy.select();
                                        document.execCommand("copy");
                                        document.body.removeChild(dummy);
                                        var message = document.getElementById("crd-message");
                                        message.style.display = "block";
                                        setTimeout(function() {
                                            message.style.display = "none";
                                        }, 3000);
                                    });
                                });
                            });
                        </script>';
                    }
                }
            }


            //协议下载，用a标签也可以，后面改成button是为了防止可能会造成的直接打开链接
            $protocol_url = get_post_meta($post->ID, '_crd_protocol_url', true);
            if ($protocol_url) {
                $software_info .= '<p><button class="download-button download-pact">协议下载</button></p>';
                //$software_info .= '<p><a href="#" class="download-button download-pact">协议下载</a></p>';
            }

            $software_info .= '</div>';
            $content .= $software_info;
        }
    }

    return $content;
}

add_filter('the_content', 'crd_display_software_info');


// 小工具板块
class CRD_Software_Widget extends WP_Widget {
    function __construct() {
        parent::__construct(
            'crd_software_widget',
            '小半自定义资源工具',
            ['description' => '显示小半自定义资源信息.']
        );
    }

public function widget($args, $instance) {
    global $post;

    // 获取自定义字段
    $fields = [
        'crd_software_name' => '名称',
        'crd_software_version' => '版本',
        'crd_software_environment' => '运行环境',
        'crd_software_fileformat' => '文件格式',
        'crd_software_size' => '文件大小',
        'crd_software_paid' => '收费情况',
        'crd_software_update' => '更新时间',
        'crd_download_password1' => '网盘访问密码',
    ];

    // 检查是否有软件信息
    $has_software_info = false;
    $download_fields = ['crd_download_url1', 'crd_download_url2', 'crd_download_url3', 'crd_protocol_url'];
    foreach ($download_fields as $field) {
        $url = get_post_meta($post->ID, '_' . $field, true);
        if (!empty($url)) {
            $has_software_info = true;
            break;
        }
    }

    if ($has_software_info) {
        $software_info = '<div class="crd-widget">'; // 添加小工具css
        $software_info .= '<h3>资源信息</h3>';

        foreach ($fields as $field => $label) {
            $value = get_post_meta($post->ID, '_' . $field, true);
            if (!empty($value)) {
                $software_info .= '<p><strong>' . esc_html($label) . ':</strong> ' . esc_html($value) . '</p>';
            }
        }

        // 添加下载地址
        $software_info .= '<p><strong>下载地址：</strong></p>';

        // 演示地址
        $demo_url = get_post_meta($post->ID, '_crd_demo_url', true);
        if ($demo_url) {
            $software_info .= '<p><a href="' . esc_url($demo_url) . '" class="download-button download-demo" target="_blank">演示地址</a></p>';
        }

        $download_names_urls = [
            ['name' => 'crd_download_name1', 'url' => 'crd_download_url1', 'default' => '网盘下载', 'class' => 'download-address1'],
            ['name' => 'crd_download_name2', 'url' => 'crd_download_url2', 'default' => '直连下载', 'class' => 'download-address2'],
            ['name' => 'crd_download_name3', 'url' => 'crd_download_url3', 'default' => '磁力链接']
        ];

        foreach ($download_names_urls as $item) {
            $name = get_post_meta($post->ID, '_' . $item['name'], true);
            $url = get_post_meta($post->ID, '_' . $item['url'], true);
            // 如果没有设置名称，则使用默认值
            $name = $name ?: $item['default'];
            if ($name && $url) {
                if (isset($item['class'])) {
                    $software_info .= '<p><a href="#" class="download-button ' . esc_attr($item['class']) . '" data-type="' . esc_attr($item['url']) . '">' . esc_html($name) . '</a></p>';
                } else {
                    $software_info .= '<p><button class="copy-magnet" data-magnet="' . esc_attr($url) . '">' . esc_html($name) . '</button></p>';
                }
            }
        }

        // 协议下载
        $protocol_url = get_post_meta($post->ID, '_crd_protocol_url', true);
        if ($protocol_url) {
            $software_info .= '<p><button class="download-button download-pact">协议下载</button></p>';
        }
        
            // 复制成功提示信息
            $software_info .= '<div id="crd-widget-message" style="display:none; padding:10px; background-color:#dff0d8; border:1px solid #d0e9c6; color:#3c763d; margin-top:10px;">复制成功!</div>';
            $software_info .= '<script type="text/javascript">
                document.addEventListener("DOMContentLoaded", function() {
                    document.querySelectorAll(".copy-magnet").forEach(function(button) {
                        button.addEventListener("click", function() {
                            var magnetLink = button.getAttribute("data-magnet");
                            var dummy = document.createElement("input");
                            document.body.appendChild(dummy);
                            dummy.value = magnetLink;
                            dummy.select();
                            document.execCommand("copy");
                            document.body.removeChild(dummy);
                            var message = document.getElementById("crd-widget-message");
                            message.style.display = "block";
                            setTimeout(function() {
                                message.style.display = "none";
                            }, 3000);
                        });
                    });
                });
            </script>';
        $software_info .= '</div>'; // 清除小工具
        echo $args['before_widget'];
        echo $software_info;
        echo $args['after_widget'];
    }
}
}

// 注册小工具
function crd_register_widget() {
    register_widget('CRD_Software_Widget');
}
add_action('widgets_init', 'crd_register_widget');

// AJAX请求处理获取下载链接
function crd_ajax_download_link() {
    nocache_headers(); // 防止缓存
    // 检查POST请求中是否包含type和post_id参数
    if (!isset($_POST['type']) || !isset($_POST['post_id'])) {
        wp_send_json_error('无效的请求'); // 如果没有参数，返回错误信息
    }

    // 清理输入数据，确保安全
    $type = sanitize_text_field($_POST['type']);
    $post_id = intval($_POST['post_id']);

    // 获取允许游客下载的设置
    $allow_visitors_download = get_option('crd_visitors_download');

    // 如果设置允许游客下载，跳过权限检查
    if (!$allow_visitors_download && !current_user_can('read_post', $post_id)) {
        wp_send_json_error('未经授权'); // 如果没有权限且不允许游客下载，返回错误信息
    }

    $response = []; // 初始化响应数组

    // 根据请求类型获取相应的下载链接
    switch ($type) {
        case 'crd_download_url1':
            $response['url'] = get_post_meta($post_id, '_crd_download_url1', true);
            break;
        case 'crd_download_url2':
            $response['url'] = get_post_meta($post_id, '_crd_download_url2', true);
            break;
        case 'crd_download_url3':
            $response['url'] = get_post_meta($post_id, '_crd_download_url3', true);
            break;
        case 'protocol':
            $response['url'] = get_post_meta($post_id, '_crd_protocol_url', true);
            $response['agreement'] = get_option('crd_download_agreement');
            break;
        default:
            wp_send_json_error('无效的类型'); // 如果类型不匹配，返回错误信息
    }

    // 检查响应中是否包含有效的URL
    if (!empty($response['url'])) {
        wp_send_json_success($response); // 如果有URL，返回成功响应
    } else {
        wp_send_json_error('未找到URL'); // 如果没有URL，返回错误信息
    }
}
add_action('wp_ajax_crd_get_download_link', 'crd_ajax_download_link');
add_action('wp_ajax_nopriv_crd_get_download_link', 'crd_ajax_download_link');

// AJAX请求处理密码验证
function crd_ajax_validate_password() {
    // 检查POST请求中是否包含密码参数
    if (!isset($_POST['password'])) {
        wp_send_json_error('无效的请求'); // 如果没有参数，返回错误信息
    }

    // 清理输入数据，确保安全
    $password = sanitize_text_field($_POST['password']);
    $correct_password = get_option('crd_password_answer');

    if ($password === $correct_password) {
        wp_send_json_success(); // 如果密码正确，返回成功响应
    } else {
        wp_send_json_error('密码错误'); // 如果密码错误，返回错误信息
    }
}
add_action('wp_ajax_crd_validate_password', 'crd_ajax_validate_password');
add_action('wp_ajax_nopriv_crd_validate_password', 'crd_ajax_validate_password');


// 实时获取验证图片和验证提示
function crd_get_settings() {
    wp_send_json_success([
        'password_prompt' => get_option('crd_password_prompt', ''),
        'password_image' => get_option('crd_password_image', ''),
    ]);
}
add_action('wp_ajax_crd_get_settings', 'crd_get_settings');
add_action('wp_ajax_nopriv_crd_get_settings', 'crd_get_settings');


// js处理
function crd_enqueue_scripts_and_styles() {
    if (is_single() && has_software_info()) {
        // 检查是否开启验证和协议下载地址
        $protocol_url = get_post_meta(get_the_ID(), '_crd_protocol_url', true);
        $crd_enable_password_protection = get_option('crd_enable_password_protection');
        ?>
        <script type="text/javascript">
        document.addEventListener("DOMContentLoaded", function() {
            function showCustomPopup(message) {
                var popup = document.getElementById("crd-custompoint-popup");
                var content = popup.querySelector(".popup-content");
                content.innerHTML = message;
                popup.style.display = "block";

                document.getElementById("close-popup").addEventListener("click", function() {
                    popup.style.display = "none";
                });
            }

            function downloadFile(url) {
                var xhr = new XMLHttpRequest();
                xhr.open("GET", url, true);
                xhr.responseType = "blob";
                xhr.onload = function() {
                    var blob = xhr.response;
                    var link = document.createElement("a");
                    link.href = window.URL.createObjectURL(blob);
                    link.download = url.substring(url.lastIndexOf("/") + 1);
                    link.click();
                };
                xhr.send();
            }

            function isImageUrl(url) {
                var imageExtensions = ['jpg', 'jpeg', 'png', 'svg', 'gif'];
                var extension = url.split('.').pop().toLowerCase();
                return imageExtensions.includes(extension);
            }

            <?php if ($crd_enable_password_protection) : ?>
            function loadSettings(callback) {
                fetch("<?php echo admin_url('admin-ajax.php'); ?>?action=crd_get_settings")
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            callback(data.data);
                        } else {
                            console.error('获取设置失败');
                        }
                    });
            }

            function showPasswordPopup(callback) {
                loadSettings(function(settings) {
                    var popup = document.createElement("div");
                    popup.className = "password-popup";
                    
                    popup.innerHTML = `
                        <div class="popup-title">请输入密码</div>
                        <div class="popup-content">
                            <p>${settings.password_prompt}</p>
                            <img src="${settings.password_image}" alt="验证码" style="display:block; margin: 0 auto;">
                            <input type="text" id="password-input" placeholder="请输入密码">
                            <button id="password-confirm" class="download-button">确认</button>
                            <button id="password-close" class="download-button">关闭</button>
                            <div id="password-message" style="color: red; display: none;">密码错误</div>
                        </div>
                    `;
                    document.body.appendChild(popup);
                    document.getElementById("password-confirm").addEventListener("click", function() {
                        var password = document.getElementById("password-input").value;

                        fetch("<?php echo admin_url('admin-ajax.php'); ?>", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/x-www-form-urlencoded",
                                "Cache-Control": "no-cache"
                            },
                            body: new URLSearchParams({
                                action: "crd_validate_password",
                                password: password
                            })
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                localStorage.setItem('crd_password_valid', 'true');
                                document.body.removeChild(popup);
                                callback();
                            } else {
                                document.getElementById("password-message").style.display = "block";
                            }
                        })
                        .catch(() => showCustomPopup('请求失败'));
                    });

                    document.getElementById("password-close").addEventListener("click", function() {
                        document.body.removeChild(popup);
                    });
                });
            }
            <?php endif; ?>

            document.querySelectorAll(".download-button.download-address1, .download-button.download-address2").forEach(function(button) {
                button.addEventListener("click", function(e) {
                    e.preventDefault();
                    var type = button.getAttribute("data-type");
                    var postId = <?php echo get_the_ID(); ?>;
                    var allow_visitors_download = <?php echo json_encode(get_option('crd_visitors_download')); ?>;

                    if (!allow_visitors_download && !<?php echo json_encode(current_user_can('administrator')); ?>) {
                        showCustomPopup('游客无法下载此资源，请登录以获取下载权限。');
                    } else {
                        <?php if ($crd_enable_password_protection) : ?>
                        if (localStorage.getItem('crd_password_valid') !== 'true') {
                            showPasswordPopup(function() {
                                fetch("<?php echo admin_url('admin-ajax.php'); ?>", {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/x-www-form-urlencoded",
                                        "Cache-Control": "no-cache"
                                    },
                                    body: new URLSearchParams({
                                        action: "crd_get_download_link",
                                        type: type,
                                        post_id: postId
                                    })
                                })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        var url = data.data.url;
                                        if (isImageUrl(url)) {
                                            downloadFile(url);
                                        } else {
                                            window.open(url, '_blank');
                                        }
                                    } else {
                                        showCustomPopup('下载链接未找到(您没有权限下载，请登录)');
                                    }
                                })
                                .catch(() => showCustomPopup('请求失败'));
                            });
                        } else {
                            fetch("<?php echo admin_url('admin-ajax.php'); ?>", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/x-www-form-urlencoded",
                                    "Cache-Control": "no-cache"
                                },
                                body: new URLSearchParams({
                                    action: "crd_get_download_link",
                                    type: type,
                                    post_id: postId
                                })
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    var url = data.data.url;
                                    if (isImageUrl(url)) {
                                        downloadFile(url);
                                    } else {
                                        window.open(url, '_blank');
                                    }
                                } else {
                                    showCustomPopup('下载链接未找到(您没有权限下载，请登录)');
                                }
                            })
                            .catch(() => showCustomPopup('请求失败'));
                        }
                        <?php else: ?>
                        fetch("<?php echo admin_url('admin-ajax.php'); ?>", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/x-www-form-urlencoded",
                                "Cache-Control": "no-cache"
                            },
                            body: new URLSearchParams({
                                action: "crd_get_download_link",
                                type: type,
                                post_id: postId
                            })
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                var url = data.data.url;
                                if (isImageUrl(url)) {
                                    downloadFile(url);
                                } else {
                                    window.open(url, '_blank');
                                }
                            } else {
                                showCustomPopup('下载链接未找到(您没有权限下载，请登录)');
                            }
                        })
                        .catch(() => showCustomPopup('请求失败'));
                        <?php endif; ?>
                    }
                });
            });

            <?php if (!empty($protocol_url)) : ?>
            document.querySelectorAll(".download-button.download-pact").forEach(function(button) {
                button.addEventListener("click", function(e) {
                    e.preventDefault();
                    var postId = <?php echo get_the_ID(); ?>;

                    fetch("<?php echo admin_url('admin-ajax.php'); ?>", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/x-www-form-urlencoded",
                            "Cache-Control": "no-cache"
                        },
                        body: new URLSearchParams({
                            action: "crd_get_download_link",
                            type: "protocol",
                            post_id: postId
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            var url = data.data.url;
                            var agreement = data.data.agreement;

                            var popup = document.createElement("div");
                            popup.className = "crd-popup";
                            var content = agreement ? agreement : "请到后台添加协议内容";
                            popup.innerHTML = '<div class="popup-title">免责协议</div>' +
                                '<div class="popup-content">' + content + '</div>' +
                                '<div class="popup-buttons">' +
                                '<button id="agree-btn" class="download-button">同意协议</button>' +
                                '<button id="disagree-btn" class="download-button">不同意</button>' +
                                '</div>';
                            document.body.appendChild(popup);

                            document.getElementById("agree-btn").addEventListener("click", function() {
                                window.open(url, '_blank');
                                document.body.removeChild(popup);
                            });

                            document.getElementById("disagree-btn").addEventListener("click", function() {
                                document.body.removeChild(popup);
                            });

                            popup.style.display = "block";
                        } else {
                            showCustomPopup('协议内容未找到(您没有权限下载，请登录)');
                        }
                    })
                    .catch(() => showCustomPopup('请求失败'));
                });
            });
            <?php endif; ?>
        });
        </script>
        <?php
    }
}
add_action('wp_enqueue_scripts', 'crd_enqueue_scripts_and_styles');


// 游客无法下载的提示框
function crd_insert_custompoint_popup() {
    // 确保是单篇文章页面且有软件信息
    if (is_single() && has_software_info()) {
        ?>
        <div id="crd-custompoint-popup" class="crd-custompoint-popup">
            <div class="popup-content"></div>
            <div class="popup-buttons">
                <button id="close-popup" class="close-btn">关闭</button>
            </div>
        </div>
        <?php
    }
}
add_action('wp_footer', 'crd_insert_custompoint_popup');

// 检查当前页面是否有软件信息
function has_software_info() {
    global $post;

    $fields = [
        'crd_software_name',
        'crd_software_version',
        'crd_software_environment',
        'crd_software_fileformat',
        'crd_software_size',
        'crd_software_paid',
        'crd_software_update',
        'crd_demo_url',
        'crd_download_name1',
        'crd_download_url1',
        'crd_download_password1',
        'crd_download_name2',
        'crd_download_url2',
        'crd_download_name3',
        'crd_download_url3',
        'crd_protocol_url',
    ];

    foreach ($fields as $field) {
        $value = get_post_meta($post->ID, '_' . $field, true);
        if (!empty($value)) {
            return true;
        }
    }
    return false;
}


// 添加插件的样式表
function crd_enqueue_styles() {
    if (is_single() && has_software_info()) { // 确保是单篇文章页面且有软件信息
        wp_enqueue_style('crd-styles', plugins_url('csdstyle.css', __FILE__));
    }
}
add_action('wp_enqueue_scripts', 'crd_enqueue_styles');


// 加载设置页面文件
include(plugin_dir_path(__FILE__) . 'crd-settings.php');

// 插件卸载时调用的函数
function crd_uninstall() {
    // 检查设置中是否勾选了“卸载插件时删除相关数据”
    $delete_data_on_uninstall = get_option('crd_delete_data_on_uninstall');

    if ($delete_data_on_uninstall == 1) {
        global $wpdb;

        // 要删除的自定义字段
        $fields_to_delete = [
            'crd_software_name',
            'crd_software_version',
            'crd_software_environment',
            'crd_software_fileformat',
            'crd_software_size',
            'crd_software_paid',
            'crd_software_update',
            'crd_download_name1',
            'crd_download_url1',
            'crd_download_password1',
            'crd_download_name2',
            'crd_download_url2',
            'crd_download_name3',
            'crd_download_url3',
            'crd_demo_url',
            'crd_protocol_url',
        ];

        foreach ($fields_to_delete as $field) {
            // 构建meta_key
            $meta_key = '_' . $field;

            // 执行删除操作，只删除指定的字段的meta数据
            $wpdb->delete(
                $wpdb->postmeta,
                ['meta_key' => $meta_key],
                ['%s']
            );
        }

        // 删除插件的所有选项
        delete_option('crd_display_software_info');
        delete_option('crd_delete_data_on_uninstall');
        delete_option('crd_download_agreement');
        delete_option('crd_visitors_download');
        delete_option('crd_enable_password_protection');
        delete_option('crd_password_answer');
        delete_option('crd_password_image');
        delete_option('crd_password_prompt');
    }
}
register_uninstall_hook(__FILE__, 'crd_uninstall');

?>