/* 前台交互脚本
*/
(function($){

    // 无侵入小工具：转义
    function esc(s){
        if(s===null || s===undefined) return '';
        return String(s)
          .replace(/&/g,'&amp;').replace(/</g,'&lt;')
          .replace(/>/g,'&gt;').replace(/"/g,'&quot;')
          .replace(/'/g,'&#39;');
    }

    // 简易消息条（非 alert）
    function toast(msg){
        var bar = $('<div class="xb_yaopin_toast" role="status" aria-live="polite"/>').html(esc(msg));
        $('.xb_yaopin_container').append(bar);
        setTimeout(function(){ bar.addClass('p show'); }, 10);
        setTimeout(function(){ bar.removeClass('show'); setTimeout(function(){ bar.remove(); }, 300); }, 3000);
    }

    var state = {
        category_id: 0,
        page: 1,
        pages: 1
    };

    // 加载公告
    function loadNotice(){
        $.post(xb_yaopin_cfg.ajax_url, {
            action: 'xb_yaopin_front_get_notice',
            nonce: xb_yaopin_cfg.nonce
        }, function(res){
            if(res && res.success){
                $('#xb_yaopin_notice_content').html(res.data.html || '');
            }
        });
    }

    // 加载分类按钮
    function loadCategories(){
        $.post(xb_yaopin_cfg.ajax_url, {
            action: 'xb_yaopin_front_get_categories',
            nonce: xb_yaopin_cfg.nonce
        }, function(res){
            var $wrap = $('#xb_yaopin_category_buttons').empty();
            if(res && res.success){
                var list = res.data.items || [];
                if(list.length === 0){
                    $wrap.append('<div class="xb_yaopin_empty">暂无分类</div>');
                    return;
                }
                // “全部”按钮
                var allBtn = $('<button type="button" class="xb_yaopin_btn xb_yaopin_btn_cat xb_yaopin_btn_active" data-id="0">全部</button>');
                $wrap.append(allBtn);
                list.forEach(function(it){
                    var btn = $('<button type="button" class="xb_yaopin_btn xb_yaopin_btn_cat" data-id="'+it.id+'"></button>');
                    btn.text(it.name);
                    $wrap.append(btn);
                });
            }else{
                $wrap.append('<div class="xb_yaopin_empty">分类加载失败</div>');
            }
        });
    }

    // 渲染药品表格
    function renderTable(items){
        var $table = $('#xb_yaopin_list_table').empty();
        if(!items || items.length===0){
            $table.append('<div class="xb_yaopin_empty">暂无药品信息</div>');
            return;
        }
        // 使用标准表格结构
        var $tableInner = $('<table class="xb_yaopin_table_inner"/>');
        var $thead = $('<thead><tr>' +
            '<th class="xb_yaopin_th">药名</th>' +
            '<th class="xb_yaopin_th">适应症</th>' +
            '<th class="xb_yaopin_th">使用方式</th>' +
            '<th class="xb_yaopin_th">用法用量</th>' +
            '<th class="xb_yaopin_th">药品类型</th>' +
            '<th class="xb_yaopin_th">批准号</th>' +
            '<th class="xb_yaopin_th">不良反应</th>' +
            '<th class="xb_yaopin_th">禁忌</th>' +
            '<th class="xb_yaopin_th">注意事项</th>' +
            '</tr></thead>');
        var $tbody = $('<tbody/>');

        items.forEach(function(it){
            var $tr = $('<tr/>');
            $tr.append('<td class="xb_yaopin_td">' + esc(it.name) + '</td>');
            $tr.append('<td class="xb_yaopin_td">' + (it.indications ? esc(it.indications) : '-') + '</td>');
            $tr.append('<td class="xb_yaopin_td">' + (it.usage_method ? esc(it.usage_method) : '-') + '</td>');
            $tr.append('<td class="xb_yaopin_td">' + (it.dosage ? esc(it.dosage) : '-') + '</td>');
            $tr.append('<td class="xb_yaopin_td">' + (it.type ? esc(it.type) : '-') + '</td>');
            $tr.append('<td class="xb_yaopin_td">' + (it.approval_no ? esc(it.approval_no) : '-') + '</td>');
            $tr.append('<td class="xb_yaopin_td">' + (it.adverse_reactions ? esc(it.adverse_reactions) : '-') + '</td>');
            $tr.append('<td class="xb_yaopin_td">' + (it.contraindications ? esc(it.contraindications) : '-') + '</td>');
            $tr.append('<td class="xb_yaopin_td">' + (it.precautions ? esc(it.precautions) : '-') + '</td>');
            $tbody.append($tr);

            // 添加备注行
            if (it.remark && String(it.remark).trim() !== '') {
                var $remarkTr = $('<tr/>');
                $remarkTr.append('<td class="xb_yaopin_remark_row" colspan="9">备注：' + esc(it.remark) + '</td>');
                $tbody.append($remarkTr);
            }
        });

        $tableInner.append($thead).append($tbody);
        $table.append($tableInner);
    }

    // 分页器
    function renderPager(page, pages){
        var $pager = $('#xb_yaopin_list_pager').empty();
        if(pages<=1) return;

        var $wrap = $('<div class="xb_yaopin_pager_inner"/>');
        for(var i=1;i<=pages;i++){
            var $btn = $('<button type="button" class="xb_yaopin_btn xb_yaopin_btn_page"></button>').text(i);
            if(i===page){ $btn.addClass('xb_yaopin_btn_active').attr('disabled', true); }
            (function(p){
                $btn.on('click', function(){ state.page = p; fetchMedicines(); });
            })(i);
            $wrap.append($btn);
        }
        $pager.append($wrap);
    }

    // 拉取药品数据
    function fetchMedicines(){
        $.post(xb_yaopin_cfg.ajax_url, {
            action: 'xb_yaopin_front_get_medicines',
            nonce: xb_yaopin_cfg.nonce,
            category_id: state.category_id,
            page: state.page
        }, function(res){
            if(res && res.success){
                renderTable(res.data.items);
                state.pages = res.data.pages||1;
                renderPager(res.data.page, state.pages);
            }else{
                toast('数据加载失败');
            }
        });
    }

    // 分类按钮点击
    $(document).on('click', '.xb_yaopin_btn_cat', function(){
        $('.xb_yaopin_btn_cat').removeClass('xb_yaopin_btn_active');
        $(this).addClass('xb_yaopin_btn_active');
        state.category_id = parseInt($(this).data('id'),10)||0;
        state.page = 1;
        fetchMedicines();
    });

    // 初始化
    $(function(){
        loadCategories();
        fetchMedicines();
        loadNotice();
    });

})(jQuery);