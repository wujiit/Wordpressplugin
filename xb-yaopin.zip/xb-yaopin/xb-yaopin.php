<?php
/*
Plugin Name: 家庭常备药品
Description: 独立数据表、后台公告与分类、药品管理。
Version: 1.0.0
Author: Summer
*/

// 统一安全退出
if ( ! defined( 'ABSPATH' ) ) exit;

// ---------------------------
// 全局常量与工具函数
// ---------------------------
define('XB_YAOPIN_VERSION', '1.0.0');
define('XB_YAOPIN_SHORTCODE', 'xb_yaopin_front'); // 前台短代码
define('XB_YAOPIN_OPTION_NOTICE', 'xb_yaopin_notice_html'); // 公告存储于 options
define('XB_YAOPIN_PER_PAGE', 20); // 每页 20

// 获取数据表名
function xb_yaopin_table_categories() {
    global $wpdb;
    return $wpdb->prefix . 'xb_yaopin_categories';
}
function xb_yaopin_table_medicines() {
    global $wpdb;
    return $wpdb->prefix . 'xb_yaopin_medicines';
}

// 简化 JSON 输出
function xb_yaopin_json_success($data = array(), $code = 200){
    wp_send_json(array('code'=>$code,'success'=>true,'data'=>$data));
}
function xb_yaopin_json_error($msg = '错误', $code = 400){
    wp_send_json(array('code'=>$code,'success'=>false,'message'=>$msg));
}

// ---------------------------
// 插件启用：创建数据表 + 创建包含短代码的前台页面（若不存在）
// ---------------------------
function xb_yaopin_activate(){
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset_collate = $wpdb->get_charset_collate();

    // 分类表
    $table1 = xb_yaopin_table_categories();
    $sql1 = "CREATE TABLE {$table1} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        sort_order INT DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_sort (sort_order)
    ) {$charset_collate};";

    // 药品表
    $table2 = xb_yaopin_table_medicines();
    $sql2 = "CREATE TABLE {$table2} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        category_id BIGINT UNSIGNED NOT NULL,
        name VARCHAR(255) NOT NULL,
        indications TEXT NULL,
        usage_method TEXT NULL,
        dosage TEXT NULL,
        type VARCHAR(255) NULL,
        approval_no VARCHAR(255) NULL,
        adverse_reactions TEXT NULL,
        contraindications TEXT NULL,
        precautions TEXT NULL,
        remark TEXT NULL,
        sort_order INT DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_cat (category_id),
        KEY idx_sort (sort_order)
    ) {$charset_collate};";

    dbDelta($sql1);
    dbDelta($sql2);

    // 若无公告，初始化为空
    if ( get_option(XB_YAOPIN_OPTION_NOTICE, null) === null ){
        add_option(XB_YAOPIN_OPTION_NOTICE, '');
    }

    // 创建含短代码页面：先查找是否已有包含 [xb_yaopin_front] 的页面
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '['.XB_YAOPIN_SHORTCODE.']',
        'numberposts' => 1,
    ));
    if ( empty($pages) ) {
        wp_insert_post(array(
            'post_title'   => '家庭常备药品',
            'post_content' => '['.XB_YAOPIN_SHORTCODE.']',
            'post_status'  => 'publish',
            'post_author'  => 1,
            'post_type'    => 'page',
        ));
    }
}
register_activation_hook(__FILE__, 'xb_yaopin_activate');

// ---------------------------
// 仅在包含短代码的页面加载前端资源（JS/CSS）
// ---------------------------
function xb_yaopin_enqueue_front_assets(){
    // 只在单页面并且内容包含短代码时加载
    if ( is_singular('page') ) {
        global $post;
        if ( $post && has_shortcode($post->post_content, XB_YAOPIN_SHORTCODE) ) {
            // 前端 CSS/JS
            $v = XB_YAOPIN_VERSION . '.' . (defined('WP_DEBUG') && WP_DEBUG ? time() : '');
            wp_enqueue_style('xb_yaopin_css', plugins_url('xb_yaopin.css', __FILE__), array(), $v);
            wp_enqueue_script('xb_yaopin_js', plugins_url('xb_yaopin.js', __FILE__), array('jquery'), $v, true);
            // 本地化参数
            wp_localize_script('xb_yaopin_js', 'xb_yaopin_cfg', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('xb_yaopin_front_nonce'),
                'per_page' => XB_YAOPIN_PER_PAGE,
            ));
        }
    }
}
add_action('wp_enqueue_scripts', 'xb_yaopin_enqueue_front_assets');

// ---------------------------
// 前台短代码输出（自定义容器 + 自定义标题块 + 分类按钮区 + 列表 + 公告在最底部）
// ---------------------------
function xb_yaopin_shortcode(){
    ob_start();
    ?>
    <div class="xb_yaopin_container">
        <div class="xb_yaopin_header_title">家庭常备药品</div>

        <div class="xb_yaopin_category_wrap">
            <div class="xb_yaopin_section_title">病情分类</div>
            <div id="xb_yaopin_category_buttons" class="xb_yaopin_category_buttons" role="group" aria-label="分类按钮"></div>
        </div>

        <div class="xb_yaopin_list_wrap">
            <div class="xb_yaopin_section_title">推荐药品</div>
            <div id="xb_yaopin_list_table" class="xb_yaopin_table"></div>
            <div id="xb_yaopin_list_pager" class="xb_yaopin_pager"></div>
        </div>

        <div class="xb_yaopin_notice_wrap">
            <div class="xb_yaopin_section_title">公告</div>
            <div id="xb_yaopin_notice_content" class="xb_yaopin_notice"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode(XB_YAOPIN_SHORTCODE, 'xb_yaopin_shortcode');

// ---------------------------
// 前台 AJAX：获取分类/药品/公告（仅对含短代码页面的前端 JS 使用）
// ---------------------------
function xb_yaopin_front_check(){
    // 安全校验：nonce
    if ( empty($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'], 'xb_yaopin_front_nonce') ) {
        xb_yaopin_json_error('非法请求');
    }
}

add_action('wp_ajax_xb_yaopin_front_get_categories', function(){
    xb_yaopin_front_check();
    global $wpdb;
    $table = xb_yaopin_table_categories();
    $rows = $wpdb->get_results("SELECT id, name FROM {$table} ORDER BY sort_order DESC, id DESC");
    xb_yaopin_json_success(array('items'=>$rows ?: array()));
});
add_action('wp_ajax_nopriv_xb_yaopin_front_get_categories', function(){
    do_action('wp_ajax_xb_yaopin_front_get_categories');
});

add_action('wp_ajax_xb_yaopin_front_get_medicines', function(){
    xb_yaopin_front_check();
    global $wpdb;
    $table = xb_yaopin_table_medicines();

    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
    $page = max(1, intval($_POST['page'] ?? 1));
    $per_page = XB_YAOPIN_PER_PAGE;
    $offset = ($page - 1) * $per_page;

    $where = "WHERE 1=1";
    $params = array();
    if ($category_id > 0){
        $where .= " AND category_id = %d";
        $params[] = $category_id;
    }

    // 统计总数
    $total = (int) $wpdb->get_var( $wpdb->prepare("SELECT COUNT(1) FROM {$table} {$where}", $params) );

    // 获取数据
    $sql = "SELECT id, category_id, name, indications, usage_method, dosage, type, approval_no, adverse_reactions, contraindications, precautions, remark
            FROM {$table} {$where}
            ORDER BY sort_order DESC, id DESC
            LIMIT %d OFFSET %d";
    $params2 = array_merge($params, array($per_page, $offset));
    $items = $wpdb->get_results( $wpdb->prepare($sql, $params2) );

    xb_yaopin_json_success(array(
        'items' => $items ?: array(),
        'total' => $total,
        'page'  => $page,
        'pages' => ceil($total / $per_page),
        'per_page' => $per_page,
    ));
});
add_action('wp_ajax_nopriv_xb_yaopin_front_get_medicines', function(){
    do_action('wp_ajax_xb_yaopin_front_get_medicines');
});

add_action('wp_ajax_xb_yaopin_front_get_notice', function(){
    xb_yaopin_front_check();
    $notice = get_option(XB_YAOPIN_OPTION_NOTICE, '');
    xb_yaopin_json_success(array('html'=>$notice));
});
add_action('wp_ajax_nopriv_xb_yaopin_front_get_notice', function(){
    do_action('wp_ajax_xb_yaopin_front_get_notice');
});

// ---------------------------
// 后台菜单（单页）：公告设置（最上）、分类（中间）、药品（最下）
// ---------------------------
function xb_yaopin_admin_menu(){
    add_menu_page(
        '家庭常备药品',
        '家庭常备药品',
        'manage_options',
        'xb_yaopin_admin',
        'xb_yaopin_admin_page_render',
        'dashicons-pressthis',
        58
    );
}
add_action('admin_menu', 'xb_yaopin_admin_menu');

// 后台页面渲染
function xb_yaopin_admin_page_render(){
    if ( ! current_user_can('manage_options') ) return;
    $nonce = wp_create_nonce('xb_yaopin_admin_nonce');
    $per_page = XB_YAOPIN_PER_PAGE;
    ?>
    <div class="wrap">
        <h1 style="display:none;"></h1>
        <div class="xb_yaopin_admin_container">

            <!-- 顶部：公告设置 -->
            <div class="xb_yaopin_admin_card">
                <div class="xb_yaopin_admin_card_title">公告设置（支持 HTML）</div>
                <form id="xb_yaopin_form_notice">
                    <?php
                    // 公告内容
                    $notice = get_option(XB_YAOPIN_OPTION_NOTICE, '');
                    ?>
                    <textarea name="notice" class="xb_yaopin_admin_textarea" rows="6"><?php echo esc_textarea($notice); ?></textarea>
                    <div class="xb_yaopin_admin_actions">
                        <button type="submit" class="button button-primary">保存公告</button>
                        <span class="xb_yaopin_msg" id="xb_yaopin_msg_notice" aria-live="polite"></span>
                    </div>
                    <input type="hidden" name="action" value="xb_yaopin_update_notice">
                    <input type="hidden" name="nonce" value="<?php echo esc_attr($nonce); ?>">
                </form>
            </div>

            <!-- 中部：分类管理 -->
            <div class="xb_yaopin_admin_card">
                <div class="xb_yaopin_admin_card_title">病情分类管理</div>

                <form id="xb_yaopin_form_cat">
                    <div class="xb_yaopin_grid2">
                        <input type="text" name="name" class="xb_yaopin_admin_input" placeholder="分类名称（必填）" required>
                        <input type="number" name="sort_order" class="xb_yaopin_admin_input" placeholder="排序（数字越大越靠前）" value="0">
                    </div>
                    <div class="xb_yaopin_admin_actions">
                        <button type="submit" class="button button-primary">保存分类</button>
                        <button type="button" id="xb_yaopin_cat_reset" class="button">清空</button>
                        <span class="xb_yaopin_msg" id="xb_yaopin_msg_cat" aria-live="polite"></span>
                    </div>
                    <input type="hidden" name="action" value="xb_yaopin_add_or_update_category">
                    <input type="hidden" name="id" value="">
                    <input type="hidden" name="nonce" value="<?php echo esc_attr($nonce); ?>">
                </form>

                <div class="xb_yaopin_list_box">
                    <table class="widefat striped">
                        <thead>
                            <tr><th>ID</th><th>分类名称</th><th>排序</th><th>操作</th></tr>
                        </thead>
                        <tbody id="xb_yaopin_cat_tbody"></tbody>
                    </table>
                    <div id="xb_yaopin_cat_pager" class="tablenav-pages"></div>
                </div>
            </div>

            <!-- 底部：药品管理 -->
            <div class="xb_yaopin_admin_card">
                <div class="xb_yaopin_admin_card_title">药品信息管理</div>

                <form id="xb_yaopin_form_med">
                    <div class="xb_yaopin_grid3">
                        <select name="category_id" class="xb_yaopin_admin_input" required aria-label="选择分类">
                            <option value="">请选择分类</option>
                        </select>
                        <input type="text" name="name" class="xb_yaopin_admin_input" placeholder="药名（必填）" required>
                        <input type="number" name="sort_order" class="xb_yaopin_admin_input" placeholder="排序（数字越大越靠前）" value="0">
                    </div>

                    <div class="xb_yaopin_grid2">
                        <input type="text" name="type" class="xb_yaopin_admin_input" placeholder="药品类型 例：化学药">
                        <input type="text" name="approval_no" class="xb_yaopin_admin_input" placeholder="批准号">
                    </div>

                    <div class="xb_yaopin_grid2">
                        <input type="text" name="dosage" class="xb_yaopin_admin_input" placeholder="用法用量 例：一天3次，一次一颗">
                        <input type="text" name="usage_method" class="xb_yaopin_admin_input" placeholder="使用方式 例：口服">
                    </div>

                    <textarea name="indications" class="xb_yaopin_admin_textarea" rows="3" placeholder="适应症"></textarea>
                    <textarea name="adverse_reactions" class="xb_yaopin_admin_textarea" rows="3" placeholder="不良反应"></textarea>
                    <textarea name="contraindications" class="xb_yaopin_admin_textarea" rows="3" placeholder="禁忌"></textarea>
                    <textarea name="precautions" class="xb_yaopin_admin_textarea" rows="3" placeholder="注意事项"></textarea>
                    <textarea name="remark" class="xb_yaopin_admin_textarea" rows="3" placeholder="备注"></textarea>

                    <div class="xb_yaopin_admin_actions">
                        <button type="submit" class="button button-primary">保存药品</button>
                        <button type="button" id="xb_yaopin_med_reset" class="button">清空</button>
                        <span class="xb_yaopin_msg" id="xb_yaopin_msg_med" aria-live="polite"></span>
                    </div>
                    <input type="hidden" name="action" value="xb_yaopin_add_or_update_medicine">
                    <input type="hidden" name="id" value="">
                    <input type="hidden" name="nonce" value="<?php echo esc_attr($nonce); ?>">
                </form>

                <div class="xb_yaopin_list_box">
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th>ID</th><th>分类</th><th>药名</th><th>类型</th><th>批准号</th><th>排序</th><th>操作</th>
                            </tr>
                        </thead>
                        <tbody id="xb_yaopin_med_tbody"></tbody>
                    </table>
                    <div id="xb_yaopin_med_pager" class="tablenav-pages"></div>
                </div>
            </div>
        </div>
    </div>

    <style>
        /* 后台简单美化*/
        .xb_yaopin_admin_container{max-width:1100px}
        .xb_yaopin_admin_card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px;margin-bottom:18px;box-shadow:0 2px 10px rgba(0,0,0,.03)}
        .xb_yaopin_admin_card_title{font-size:16px;font-weight:600;margin-bottom:12px}
        .xb_yaopin_admin_input{width:100%}
        .xb_yaopin_admin_textarea{width:100%}
        .xb_yaopin_admin_actions{display:flex;gap:12px;align-items:center;margin-top:10px}
        .xb_yaopin_msg{opacity:0;transition:opacity .3s}
        .xb_yaopin_msg.show{opacity:1}
        .xb_yaopin_grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
        .xb_yaopin_grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px}
        .xb_yaopin_btnlink{cursor:pointer;color:#2271b1}
        .xb_yaopin_btnlink:hover{color:#135e96}
        @media (max-width:782px){
            .xb_yaopin_grid2,.xb_yaopin_grid3{grid-template-columns:1fr}
        }
    </style>

    <script>
    (function($){
        // -----------------------------
        // 通用：消息提示（3 秒后自动消失）
        // -----------------------------
        function xb_yaopin_toast($el, text){
            $el.text(text).addClass('show');
            setTimeout(function(){ $el.removeClass('show').text(''); }, 3000);
        }

        // -----------------------------
        // 公告保存
        // -----------------------------
        $('#xb_yaopin_form_notice').on('submit', function(e){
            e.preventDefault();
            var form = $(this);
            $.post(ajaxurl, form.serialize(), function(res){
                if(res && res.success){
                    xb_yaopin_toast($('#xb_yaopin_msg_notice'), '保存成功');
                }else{
                    xb_yaopin_toast($('#xb_yaopin_msg_notice'), res && res.message ? res.message : '保存失败');
                }
            });
        });

        // -----------------------------
        // 分类：增改删 + 分页
        // -----------------------------
        var catPage = 1, catPerPage = <?php echo (int)$per_page; ?>;
        function loadCats(){
            $.post(ajaxurl, {action:'xb_yaopin_list_categories', page:catPage, per_page:catPerPage, nonce:'<?php echo esc_js($nonce); ?>'}, function(res){
                var $tbody = $('#xb_yaopin_cat_tbody').empty(), $pager = $('#xb_yaopin_cat_pager').empty();
                if(res.success){
                    (res.data.items || []).forEach(function(it){
                        var tr = $('<tr/>');
                        tr.append('<td>'+it.id+'</td>');
                        tr.append('<td>'+_.escape(it.name)+'</td>');
                        tr.append('<td>'+it.sort_order+'</td>');
                        tr.append('<td><span class="xb_yaopin_btnlink" data-id="'+it.id+'" data-type="edit">编辑</span> | <span class="xb_yaopin_btnlink" data-id="'+it.id+'" data-type="del">删除</span></td>');
                        $tbody.append(tr);
                    });
                    buildPager($pager, res.data.page, res.data.pages, function(p){ catPage=p; loadCats(); });
                }
            });
        }
        function buildPager($wrap, page, pages, go){
            if(pages<=1) return;
            var $ul = $('<div/>');
            for(let i=1;i<=pages;i++){
                var $a = $('<a class="button-secondary" style="margin-right:6px"/>').text(i);
                if(i===page){ $a.addClass('disabled').attr('disabled', true); }
                $a.on('click', function(){ if(i!==page) go(i); });
                $ul.append($a);
            }
            $wrap.append($ul);
        }

        // 保存分类
        $('#xb_yaopin_form_cat').on('submit', function(e){
            e.preventDefault();
            var form = $(this), msg = $('#xb_yaopin_msg_cat');
            $.post(ajaxurl, form.serialize(), function(res){
                if(res.success){
                    xb_yaopin_toast(msg, res.data && res.data.is_update ? '更新成功' : '保存成功');
                    // 重置表单（编辑完成后恢复新增状态）
                    form[0].reset();
                    form.find('input[name="id"]').val('');
                    loadCats();
                }else{
                    xb_yaopin_toast(msg, res.message || '操作失败');
                }
            });
        });
        $('#xb_yaopin_cat_reset').on('click', function(){
            var form = $('#xb_yaopin_form_cat')[0];
            form.reset();
            $('#xb_yaopin_form_cat').find('input[name="id"]').val('');
        });

        // 分类编辑/删除
        $('#xb_yaopin_cat_tbody').on('click', '.xb_yaopin_btnlink', function(){
            var id = $(this).data('id'), type = $(this).data('type');
            if(type==='edit'){
                $.post(ajaxurl, {action:'xb_yaopin_get_category', id:id, nonce:'<?php echo esc_js($nonce); ?>'}, function(res){
                    if(res.success){
                        var d = res.data;
                        var form = $('#xb_yaopin_form_cat');
                        form.find('input[name="name"]').val(d.name);
                        form.find('input[name="sort_order"]').val(d.sort_order);
                        form.find('input[name="id"]').val(d.id);
                    }
                });
            }else if(type==='del'){
                if(confirm('确定删除该分类？（会影响其下药品）')){ // 后台可用 confirm，不是前台 alert 要求
                    $.post(ajaxurl, {action:'xb_yaopin_delete_category', id:id, nonce:'<?php echo esc_js($nonce); ?>'}, function(res){
                        xb_yaopin_toast($('#xb_yaopin_msg_cat'), res.success?'删除成功':(res.message||'删除失败'));
                        loadCats(); loadCatOptions();
                    });
                }
            }
        });

        // -----------------------------
        // 药品：增改删 + 分页
        // -----------------------------
        var medPage = 1, medPerPage = <?php echo (int)$per_page; ?>;
        function loadMeds(){
            $.post(ajaxurl, {action:'xb_yaopin_list_medicines', page:medPage, per_page:medPerPage, nonce:'<?php echo esc_js($nonce); ?>'}, function(res){
                var $tbody = $('#xb_yaopin_med_tbody').empty(), $pager = $('#xb_yaopin_med_pager').empty();
                if(res.success){
                    (res.data.items || []).forEach(function(it){
                        var tr = $('<tr/>');
                        tr.append('<td>'+it.id+'</td>');
                        tr.append('<td>'+_.escape(it.category_name||"")+'</td>');
                        tr.append('<td>'+_.escape(it.name)+'</td>');
                        tr.append('<td>'+_.escape(it.type||"")+'</td>');
                        tr.append('<td>'+_.escape(it.approval_no||"")+'</td>');
                        tr.append('<td>'+it.sort_order+'</td>');
                        tr.append('<td><span class="xb_yaopin_btnlink" data-id="'+it.id+'" data-type="edit">编辑</span> | <span class="xb_yaopin_btnlink" data-id="'+it.id+'" data-type="del">删除</span></td>');
                        $tbody.append(tr);
                    });
                    buildPager($pager, res.data.page, res.data.pages, function(p){ medPage=p; loadMeds(); });
                }
            });
        }

        // 加载分类下拉
        function loadCatOptions(selectedId){
            $.post(ajaxurl, {action:'xb_yaopin_list_categories', page:1, per_page:9999, nonce:'<?php echo esc_js($nonce); ?>'}, function(res){
                var $sel = $('#xb_yaopin_form_med select[name="category_id"]');
                $sel.empty().append('<option value="">请选择分类</option>');
                if(res.success){
                    (res.data.items || []).forEach(function(it){
                        var opt = $('<option/>').val(it.id).text(it.name);
                        $sel.append(opt);
                    });
                    if(selectedId){ $sel.val(selectedId); }
                }
            });
        }

        // 保存药品
        $('#xb_yaopin_form_med').on('submit', function(e){
            e.preventDefault();
            var form = $(this), msg = $('#xb_yaopin_msg_med');
            $.post(ajaxurl, form.serialize(), function(res){
                if(res.success){
                    xb_yaopin_toast(msg, res.data && res.data.is_update ? '更新成功' : '保存成功');
                    // 重置表单（编辑完成后恢复新增状态）
                    form[0].reset();
                    form.find('input[name="id"]').val('');
                    loadMeds();
                }else{
                    xb_yaopin_toast(msg, res.message || '操作失败');
                }
            });
        });
        $('#xb_yaopin_med_reset').on('click', function(){
            var form = $('#xb_yaopin_form_med')[0];
            form.reset();
            $('#xb_yaopin_form_med').find('input[name="id"]').val('');
        });

        // 药品编辑/删除
        $('#xb_yaopin_med_tbody').on('click', '.xb_yaopin_btnlink', function(){
            var id = $(this).data('id'), type = $(this).data('type');
            if(type==='edit'){
                $.post(ajaxurl, {action:'xb_yaopin_get_medicine', id:id, nonce:'<?php echo esc_js($nonce); ?>'}, function(res){
                    if(res.success){
                        var d = res.data;
                        var form = $('#xb_yaopin_form_med');
                        loadCatOptions(d.category_id);
                        form.find('input[name="name"]').val(d.name);
                        form.find('input[name="type"]').val(d.type||'');
                        form.find('input[name="approval_no"]').val(d.approval_no||'');
                        form.find('input[name="dosage"]').val(d.dosage||'');
                        form.find('input[name="usage_method"]').val(d.usage_method||'');
                        form.find('textarea[name="indications"]').val(d.indications||'');
                        form.find('textarea[name="adverse_reactions"]').val(d.adverse_reactions||'');
                        form.find('textarea[name="contraindications"]').val(d.contraindications||'');
                        form.find('textarea[name="precautions"]').val(d.precautions||'');
                        form.find('textarea[name="remark"]').val(d.remark||'');
                        form.find('input[name="sort_order"]').val(d.sort_order||0);
                        form.find('input[name="id"]').val(d.id);
                    }
                });
            }else if(type==='del'){
                if(confirm('确定删除该药品？')){
                    $.post(ajaxurl, {action:'xb_yaopin_delete_medicine', id:id, nonce:'<?php echo esc_js($nonce); ?>'}, function(res){
                        xb_yaopin_toast($('#xb_yaopin_msg_med'), res.success?'删除成功':(res.message||'删除失败'));
                        loadMeds();
                    });
                }
            }
        });

        // 初始化
        loadCats();
        loadCatOptions();
        loadMeds();

    })(jQuery);
    </script>
    <script>
    // 简单 underscore 替代（防 XSS 转义）
    window._ = window._ || {
        escape: function(str){
            if(str===null || str===undefined) return '';
            return String(str)
                .replace(/&/g,'&amp;')
                .replace(/</g,'&lt;')
                .replace(/>/g,'&gt;')
                .replace(/"/g,'&quot;')
                .replace(/'/g,'&#39;');
        }
    };
    </script>
    <?php
}

// ---------------------------
// 后台 AJAX 处理
// ---------------------------
function xb_yaopin_admin_check(){
    if ( ! current_user_can('manage_options') ) xb_yaopin_json_error('无权限', 403);
    if ( empty($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'], 'xb_yaopin_admin_nonce') ) {
        xb_yaopin_json_error('非法请求', 401);
    }
}

// 公告更新
add_action('wp_ajax_xb_yaopin_update_notice', function(){
    xb_yaopin_admin_check();
    $html = wp_kses_post( wp_unslash($_POST['notice'] ?? '') ); // 允许安全 HTML
    update_option(XB_YAOPIN_OPTION_NOTICE, $html);
    xb_yaopin_json_success();
});

// 分类列表（分页）
add_action('wp_ajax_xb_yaopin_list_categories', function(){
    xb_yaopin_admin_check();
    global $wpdb;
    $table = xb_yaopin_table_categories();
    $page = max(1, intval($_POST['page'] ?? 1));
    $per_page = max(1, intval($_POST['per_page'] ?? XB_YAOPIN_PER_PAGE));
    $offset = ($page - 1) * $per_page;

    $total = (int) $wpdb->get_var("SELECT COUNT(1) FROM {$table}");
    $items = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, name, sort_order FROM {$table} ORDER BY sort_order DESC, id DESC LIMIT %d OFFSET %d",
        $per_page, $offset
    ) );

    xb_yaopin_json_success(array(
        'items'=>$items?:array(),
        'total'=>$total,
        'page'=>$page,
        'pages'=>ceil($total/$per_page)
    ));
});

// 分类新增/更新
add_action('wp_ajax_xb_yaopin_add_or_update_category', function(){
    xb_yaopin_admin_check();
    global $wpdb;
    $table = xb_yaopin_table_categories();
    $id = intval($_POST['id'] ?? 0);
    $name = sanitize_text_field($_POST['name'] ?? '');
    $sort = intval($_POST['sort_order'] ?? 0);
    if ($name === '') xb_yaopin_json_error('分类名称必填');

    if($id>0){
        $wpdb->update($table, array('name'=>$name,'sort_order'=>$sort), array('id'=>$id), array('%s','%d'), array('%d'));
        xb_yaopin_json_success(array('is_update'=>true));
    }else{
        $wpdb->insert($table, array('name'=>$name,'sort_order'=>$sort), array('%s','%d'));
        xb_yaopin_json_success(array('is_update'=>false,'id'=>$wpdb->insert_id));
    }
});

// 获取单个分类
add_action('wp_ajax_xb_yaopin_get_category', function(){
    xb_yaopin_admin_check();
    global $wpdb;
    $table = xb_yaopin_table_categories();
    $id = intval($_POST['id'] ?? 0);
    $row = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", $id) );
    if(!$row) xb_yaopin_json_error('不存在');
    xb_yaopin_json_success($row);
});

// 删除分类（不级联删除药品，只允许删除；前端已提示会影响其下药品）
add_action('wp_ajax_xb_yaopin_delete_category', function(){
    xb_yaopin_admin_check();
    global $wpdb;
    $table = xb_yaopin_table_categories();
    $id = intval($_POST['id'] ?? 0);
    $wpdb->delete($table, array('id'=>$id), array('%d'));
    xb_yaopin_json_success();
});

// 药品列表（分页），包含分类名
add_action('wp_ajax_xb_yaopin_list_medicines', function(){
    xb_yaopin_admin_check();
    global $wpdb;
    $tm = xb_yaopin_table_medicines();
    $tc = xb_yaopin_table_categories();
    $page = max(1, intval($_POST['page'] ?? 1));
    $per_page = max(1, intval($_POST['per_page'] ?? XB_YAOPIN_PER_PAGE));
    $offset = ($page - 1) * $per_page;

    $total = (int) $wpdb->get_var("SELECT COUNT(1) FROM {$tm}");
    $items = $wpdb->get_results( $wpdb->prepare(
        "SELECT m.*, c.name as category_name
         FROM {$tm} m LEFT JOIN {$tc} c ON m.category_id=c.id
         ORDER BY m.sort_order DESC, m.id DESC
         LIMIT %d OFFSET %d",
        $per_page, $offset
    ) );

    xb_yaopin_json_success(array(
        'items'=>$items?:array(),
        'total'=>$total,
        'page'=>$page,
        'pages'=>ceil($total/$per_page)
    ));
});

// 药品新增/更新
add_action('wp_ajax_xb_yaopin_add_or_update_medicine', function(){
    xb_yaopin_admin_check();
    global $wpdb;
    $tm = xb_yaopin_table_medicines();

    $id = intval($_POST['id'] ?? 0);
    $category_id = intval($_POST['category_id'] ?? 0);
    $name = sanitize_text_field($_POST['name'] ?? '');

    // 其他字段允许为空（不填则前台不显示）
    $type = sanitize_text_field($_POST['type'] ?? '');
    $approval_no = sanitize_text_field($_POST['approval_no'] ?? '');
    $dosage = sanitize_text_field($_POST['dosage'] ?? '');
    $usage_method = sanitize_text_field($_POST['usage_method'] ?? '');
    $indications = wp_kses_post($_POST['indications'] ?? '');
    $adverse_reactions = wp_kses_post($_POST['adverse_reactions'] ?? '');
    $contraindications = wp_kses_post($_POST['contraindications'] ?? '');
    $precautions = wp_kses_post($_POST['precautions'] ?? '');
    $remark = wp_kses_post($_POST['remark'] ?? '');
    $sort = intval($_POST['sort_order'] ?? 0);

    if ($category_id <= 0) xb_yaopin_json_error('请选择分类');
    if ($name === '') xb_yaopin_json_error('药名必填');

    $data = array(
        'category_id'=>$category_id,
        'name'=>$name,
        'type'=>$type,
        'approval_no'=>$approval_no,
        'dosage'=>$dosage,
        'usage_method'=>$usage_method,
        'indications'=>$indications,
        'adverse_reactions'=>$adverse_reactions,
        'contraindications'=>$contraindications,
        'precautions'=>$precautions,
        'remark'=>$remark,
        'sort_order'=>$sort,
    );
    $fmt = array('%d','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d');

    if($id>0){
        $wpdb->update($tm, $data, array('id'=>$id), $fmt, array('%d'));
        xb_yaopin_json_success(array('is_update'=>true));
    }else{
        $wpdb->insert($tm, $data, $fmt);
        xb_yaopin_json_success(array('is_update'=>false,'id'=>$wpdb->insert_id));
    }
});

// 获取单个药品
add_action('wp_ajax_xb_yaopin_get_medicine', function(){
    xb_yaopin_admin_check();
    global $wpdb;
    $tm = xb_yaopin_table_medicines();
    $id = intval($_POST['id'] ?? 0);
    $row = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$tm} WHERE id=%d", $id) );
    if(!$row) xb_yaopin_json_error('不存在');
    xb_yaopin_json_success($row);
});

// 删除药品
add_action('wp_ajax_xb_yaopin_delete_medicine', function(){
    xb_yaopin_admin_check();
    global $wpdb;
    $tm = xb_yaopin_table_medicines();
    $id = intval($_POST['id'] ?? 0);
    $wpdb->delete($tm, array('id'=>$id), array('%d'));
    xb_yaopin_json_success();
});
