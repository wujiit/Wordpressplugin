jQuery(document).ready(function($) {
    // 刷新古言按钮点击事件
    $('.guyan_ai_refresh').on('click', function() {
        var $button = $(this);
        $button.prop('disabled', true);
        $('#guyan_ai_saying, #guyan_ai_transl, #guyan_ai_source, #guyan_ai_image').css('opacity', '0');

        $.ajax({
            url: guyan_ai_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'guyan_ai_refresh',
                nonce: guyan_ai_vars.nonce,
                _t: new Date().getTime()
            },
            cache: false,
            success: function(response) {
                if (response.success) {
                    $('#guyan_ai_saying').text(response.data.saying).css('opacity', '1');
                    $('#guyan_ai_transl').text(response.data.transl).css('opacity', '1');
                    $('#guyan_ai_source').text(response.data.source).css('opacity', '1');
                    if (response.data.image_url) {
                        $('#guyan_ai_image').html('<img src="' + response.data.image_url + '" alt="古言图片">').css('opacity', '1');
                    } else {
                        $('#guyan_ai_image').empty().css('opacity', '1');
                    }
                    $('.guyan_ai_copy').data('content', response.data.saying + '\n' + response.data.transl + '\n—— ' + response.data.source);
                } else {
                    $('#guyan_ai_notice').text('刷新失败：' + (response.data.message || '未知错误')).show();
                    setTimeout(function() {
                        $('#guyan_ai_notice').fadeOut('slow', function() {
                            $(this).empty();
                        });
                    }, 3000);
                }
                $button.prop('disabled', false);
            },
            error: function() {
                $('#guyan_ai_saying, #guyan_ai_transl, #guyan_ai_source, #guyan_ai_image').css('opacity', '1');
                $button.prop('disabled', false);
                $('#guyan_ai_notice').text('网络错误，请稍后再试！').show();
                setTimeout(function() {
                    $('#guyan_ai_notice').fadeOut('slow', function() {
                        $(this).empty();
                    });
                }, 3000);
            }
        });
    });

    // 复制古言文字按钮点击事件
    $('.guyan_ai_copy').on('click', function() {
        var content = $(this).data('content');
        var $button = $(this);
        var $notice = $('#guyan_ai_notice');

        navigator.clipboard.writeText(content).then(function() {
            $button.addClass('copied').text('已复制');
            $notice.empty();
            setTimeout(function() {
                $button.removeClass('copied').text('复制');
            }, 2000);
        }).catch(function() {
            $notice.text('复制失败，请手动复制！').show();
            setTimeout(function() {
                $notice.fadeOut('slow', function() {
                    $notice.empty();
                });
            }, 3000);
        });
    });
});