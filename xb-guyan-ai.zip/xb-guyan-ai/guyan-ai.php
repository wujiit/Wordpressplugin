<?php
/*
Plugin Name: 小半励志古言
Description: 一个支持第三方接口和本地数据管理的励志古言插件，包含前台展示、后台设置和数据管理功能。
Version: 1.0
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('GUYAN_AI_VERSION', '1.0');
define('GUYAN_AI_DIR', plugin_dir_path(__FILE__));
define('GUYAN_AI_URL', plugin_dir_url(__FILE__));

// 激活插件时执行
register_activation_hook(__FILE__, 'guyan_ai_activate');
function guyan_ai_activate() {
    guyan_ai_create_table();
    guyan_ai_create_page();
}

// 创建数据库表
function guyan_ai_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'guyan_ai';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        saying TEXT NOT NULL,
        transl TEXT NOT NULL,
        source VARCHAR(255) DEFAULT '',
        image_url VARCHAR(255) DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // 初始化调用统计
    if (!get_option('guyan_ai_stats')) {
        update_option('guyan_ai_stats', [
            'total' => [
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ],
            'today' => [
                'date' => current_time('Y-m-d'),
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ]
        ]);
    }
}

// 创建前台页面
function guyan_ai_create_page() {
    $pages = get_posts([
        'post_type' => 'page',
        'post_status' => 'publish',
        's' => '[guyan_ai_display]',
        'numberposts' => 1,
    ]);

    if (empty($pages) && !get_option('guyan_ai_page_id')) {
        $page = [
            'post_title' => '励志古言',
            'post_content' => '[guyan_ai_display]',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        ];
        $page_id = wp_insert_post($page);
        update_option('guyan_ai_page_id', $page_id);
    }
}

// 加载前端资源
function guyan_ai_enqueue_assets() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'guyan_ai_display')) {
        wp_enqueue_style('guyan_ai_styles', GUYAN_AI_URL . 'guyan-ai.css', [], GUYAN_AI_VERSION);
        wp_enqueue_script('guyan_ai_scripts', GUYAN_AI_URL . 'guyan-ai.js', ['jquery'], GUYAN_AI_VERSION, true);
        wp_localize_script('guyan_ai_scripts', 'guyan_ai_vars', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('guyan_ai_refresh')
        ]);
    }
}
add_action('wp_enqueue_scripts', 'guyan_ai_enqueue_assets');

// 注册短代码
add_shortcode('guyan_ai_display', 'guyan_ai_display_page');
function guyan_ai_display_page() {
    $options = get_option('guyan_ai_settings', [
        'use_third_party' => 0,
        'api_url' => 'https://apis.tianapi.com/lzmy/index',
        'api_key' => '',
        'ad_content' => ''
    ]);

    $saying = '';
    $transl = '';
    $source = '';
    $image_url = '';

    if ($options['use_third_party']) {
        $data = guyan_ai_fetch_third_party();
        $saying = $data['saying'] ?? '';
        $transl = $data['transl'] ?? '';
        $source = $data['source'] ?? '';
    } else {
        $data = guyan_ai_fetch_local();
        $saying = $data['saying'] ?? '';
        $transl = $data['transl'] ?? '';
        $source = $data['source'] ?? '';
        $image_url = $data['image_url'] ?? '';
    }

    // 更新调用统计
    guyan_ai_update_stats($options['use_third_party'], !empty($saying));

    ob_start();
    ?>
    <div class="guyan_ai_container">
        <div class="guyan_ai_title">励志古言</div>
        <div class="guyan_ai_card">
            <div class="guyan_ai_saying" id="guyan_ai_saying"><?php echo esc_html($saying); ?></div>
            <div class="guyan_ai_transl" id="guyan_ai_transl"><?php echo esc_html($transl); ?></div>
            <div class="guyan_ai_source" id="guyan_ai_source"><?php echo esc_html($source); ?></div>
            <?php if ($image_url): ?>
                <div class="guyan_ai_image" id="guyan_ai_image">
                    <img src="<?php echo esc_url($image_url); ?>" alt="古言图片">
                </div>
            <?php else: ?>
                <div class="guyan_ai_image" id="guyan_ai_image"></div>
            <?php endif; ?>
        </div>
        <div class="guyan_ai_buttons">
            <button class="guyan_ai_refresh">换一个</button>
            <button class="guyan_ai_copy" data-content="<?php echo esc_attr($saying . "\n" . $transl . "\n—— " . $source); ?>">复制</button>
        </div>
        <div class="guyan_ai_notice" id="guyan_ai_notice"></div>
        <div class="guyan_ai_ad"><?php echo wp_kses_post($options['ad_content']); ?></div>
    </div>
    <?php
    return ob_get_clean();
}

// 更新调用统计
function guyan_ai_update_stats($use_third_party, $third_party_success) {
    $stats = get_option('guyan_ai_stats', [
        'total' => [
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ],
        'today' => [
            'date' => current_time('Y-m-d'),
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ]
    ]);

    if ($stats['today']['date'] !== current_time('Y-m-d')) {
        $stats['today'] = [
            'date' => current_time('Y-m-d'),
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ];
    }

    if ($use_third_party) {
        $stats['total']['third_party_total']++;
        $stats['today']['third_party_total']++;
        if ($third_party_success) {
            $stats['total']['third_party_success']++;
            $stats['today']['third_party_success']++;
        }
    } else {
        $stats['total']['local_total']++;
        $stats['today']['local_total']++;
    }

    update_option('guyan_ai_stats', $stats);
}

// AJAX 刷新古言
add_action('wp_ajax_guyan_ai_refresh', 'guyan_ai_refresh_callback');
function guyan_ai_refresh_callback() {
    check_ajax_referer('guyan_ai_refresh', 'nonce');
    $options = get_option('guyan_ai_settings', ['use_third_party' => 0]);
    $saying = '';
    $transl = '';
    $source = '';
    $image_url = '';

    if ($options['use_third_party']) {
        $data = guyan_ai_fetch_third_party();
        $saying = $data['saying'] ?? '';
        $transl = $data['transl'] ?? '';
        $source = $data['source'] ?? '';
    } else {
        $seed = isset($_POST['_t']) ? intval($_POST['_t']) : time();
        $data = guyan_ai_fetch_local($seed);
        $saying = $data['saying'] ?? '';
        $transl = $data['transl'] ?? '';
        $source = $data['source'] ?? '';
        $image_url = $data['image_url'] ?? '';
    }

    guyan_ai_update_stats($options['use_third_party'], !empty($saying));

    wp_send_json_success([
        'saying' => $saying,
        'transl' => $transl,
        'source' => $source,
        'image_url' => $image_url
    ]);
}

// 获取第三方接口数据
function guyan_ai_fetch_third_party() {
    $options = get_option('guyan_ai_settings', [
        'api_url' => 'https://apis.tianapi.com/lzmy/index',
        'api_key' => ''
    ]);

    $args = [
        'method' => 'POST',
        'body' => ['key' => $options['api_key']],
        'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
        'timeout' => 10,
    ];

    $response = wp_remote_request($options['api_url'], $args);
    if (is_wp_error($response)) {
        return [];
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['code']) && $data['code'] == 200 && isset($data['result'])) {
        return $data['result'];
    }
    return [];
}

// 获取本地数据
function guyan_ai_fetch_local($seed = null) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'guyan_ai';

    $ids = $wpdb->get_col("SELECT id FROM $table_name");
    if (empty($ids)) {
        return ['saying' => '暂无古言数据，请在后台添加！', 'transl' => '', 'source' => '', 'image_url' => ''];
    }

    $seed = $seed ?? time();
    mt_srand($seed);
    $random_id = $ids[mt_rand(0, count($ids) - 1)];

    $result = $wpdb->get_row(
        $wpdb->prepare("SELECT saying, transl, source, image_url FROM $table_name WHERE id = %d", $random_id),
        ARRAY_A
    );

    return $result ?? ['saying' => '暂无古言数据，请在后台添加！', 'transl' => '', 'source' => '', 'image_url' => ''];
}

// 后台菜单
add_action('admin_menu', 'guyan_ai_admin_menu');
function guyan_ai_admin_menu() {
    add_menu_page('励志古言设置', '励志古言', 'manage_options', 'guyan-ai-settings', 'guyan_ai_settings_page', 'dashicons-heart');
    add_submenu_page('guyan-ai-settings', '数据管理', '数据管理', 'manage_options', 'guyan-ai-data', 'guyan_ai_data_page');
}

// 设置页面
function guyan_ai_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['guyan_ai_save_settings']) && check_admin_referer('guyan_ai_settings_nonce')) {
        $settings = [
            'use_third_party' => isset($_POST['guyan_ai_use_third_party']) ? 1 : 0,
            'api_url' => sanitize_text_field($_POST['guyan_ai_api_url']),
            'api_key' => sanitize_text_field($_POST['guyan_ai_api_key']),
            'ad_content' => wp_kses_post($_POST['guyan_ai_ad_content'], [
                'a' => ['href' => [], 'title' => [], 'target' => []],
                'img' => ['src' => [], 'alt' => [], 'width' => [], 'height' => []],
                'p' => [],
                'br' => [],
                'strong' => [],
                'em' => []
            ])
        ];
        update_option('guyan_ai_settings', $settings);
        echo '<div class="notice notice-success is-dismissible guyan_ai_notice"><p>设置已保存。</p></div>';
    }

    if (isset($_POST['guyan_ai_clear_stats']) && check_admin_referer('guyan_ai_clear_stats_nonce')) {
        update_option('guyan_ai_stats', [
            'total' => [
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ],
            'today' => [
                'date' => current_time('Y-m-d'),
                'third_party_total' => 0,
                'third_party_success' => 0,
                'local_total' => 0
            ]
        ]);
        echo '<div class="notice notice-success is-dismissible guyan_ai_notice"><p>调用统计已清空。</p></div>';
    }

    $options = get_option('guyan_ai_settings', [
        'use_third_party' => 0,
        'api_url' => 'https://apis.tianapi.com/lzmy/index',
        'api_key' => '',
        'ad_content' => ''
    ]);

    $stats = get_option('guyan_ai_stats', [
        'total' => [
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ],
        'today' => [
            'date' => current_time('Y-m-d'),
            'third_party_total' => 0,
            'third_party_success' => 0,
            'local_total' => 0
        ]
    ]);

    ?>
    <div class="wrap">
        <h1>励志古言设置</h1>
        <form method="post" action="">
            <?php wp_nonce_field('guyan_ai_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="guyan_ai_use_third_party">使用第三方接口</label></th>
                    <td><input type="checkbox" name="guyan_ai_use_third_party" id="guyan_ai_use_third_party" <?php checked($options['use_third_party'], 1); ?>></td>
                </tr>
                <tr>
                    <th><label for="guyan_ai_api_url">API 接口地址</label></th>
                    <td><input type="text" name="guyan_ai_api_url" id="guyan_ai_api_url" value="<?php echo esc_attr($options['api_url']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="guyan_ai_api_key">API 密钥</label></th>
                    <td><input type="text" name="guyan_ai_api_key" id="guyan_ai_api_key" value="<?php echo esc_attr($options['api_key']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="guyan_ai_ad_content">广告内容</label></th>
                    <td><textarea name="guyan_ai_ad_content" id="guyan_ai_ad_content" rows="5" class="large-text"><?php echo esc_textarea($options['ad_content']); ?></textarea><p>图片尺寸将自动限制为最大宽度 300px，高度 100px。</p></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="guyan_ai_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        <p>第三方接口: https://www.tianapi.com/apiview/186 </p>
        <h2>调用统计</h2>
        <h3>总计</h3>
        <p>第三方接口总调用次数: <?php echo esc_html($stats['total']['third_party_total']); ?></p>
        <p>第三方接口成功调用次数: <?php echo esc_html($stats['total']['third_party_success']); ?></p>
        <p>本地接口调用次数: <?php echo esc_html($stats['total']['local_total']); ?></p>
        <h3>今日 (<?php echo esc_html($stats['today']['date']); ?>)</h3>
        <p>第三方接口总调用次数: <?php echo esc_html($stats['today']['third_party_total']); ?></p>
        <p>第三方接口成功调用次数: <?php echo esc_html($stats['today']['third_party_success']); ?></p>
        <p>本地接口调用次数: <?php echo esc_html($stats['today']['local_total']); ?></p>
        <form method="post" action="">
            <?php wp_nonce_field('guyan_ai_clear_stats_nonce'); ?>
            <p class="submit"><input type="submit" name="guyan_ai_clear_stats" class="button-secondary" value="清空统计" onclick="return confirm('确定清空所有调用统计？');"></p>
        </form>
    </div>
    <?php
}

// 数据管理页面
function guyan_ai_data_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'guyan_ai';

    // 处理添加
    if (isset($_POST['guyan_ai_add_data']) && check_admin_referer('guyan_ai_data_nonce')) {
        $saying = sanitize_text_field($_POST['guyan_ai_saying']);
        $transl = sanitize_text_field($_POST['guyan_ai_transl']);
        $source = sanitize_text_field($_POST['guyan_ai_source']);
        $image_url = esc_url_raw($_POST['guyan_ai_image_url']);
        $wpdb->insert($table_name, [
            'saying' => $saying,
            'transl' => $transl,
            'source' => $source,
            'image_url' => $image_url
        ]);
        echo '<div class="notice notice-success is-dismissible guyan_ai_notice"><p>数据已添加。</p></div>';
    }

    // 处理编辑
    if (isset($_POST['guyan_ai_edit_data']) && check_admin_referer('guyan_ai_edit_data_nonce')) {
        $id = intval($_POST['guyan_ai_edit_id']);
        $saying = sanitize_text_field($_POST['guyan_ai_saying']);
        $transl = sanitize_text_field($_POST['guyan_ai_transl']);
        $source = sanitize_text_field($_POST['guyan_ai_source']);
        $image_url = esc_url_raw($_POST['guyan_ai_image_url']);
        $wpdb->update($table_name, [
            'saying' => $saying,
            'transl' => $transl,
            'source' => $source,
            'image_url' => $image_url
        ], ['id' => $id]);
        echo '<div class="notice notice-success is-dismissible guyan_ai_notice"><p>数据已更新。</p></div>';
        // 重定向到默认添加状态
        wp_redirect(admin_url('admin.php?page=guyan-ai-data'));
        exit;
    }

    // 处理删除
    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id']) && check_admin_referer('guyan_ai_delete_' . $_GET['id'])) {
        $wpdb->delete($table_name, ['id' => intval($_GET['id'])]);
        echo '<div class="notice notice-success is-dismissible guyan_ai_notice"><p>数据已删除。</p></div>';
    }

    // 处理删除全部
    if (isset($_POST['guyan_ai_delete_all']) && check_admin_referer('guyan_ai_delete_all_nonce')) {
        $wpdb->query("TRUNCATE TABLE $table_name");
        echo '<div class="notice notice-success is-dismissible guyan_ai_notice"><p>所有数据已删除。</p></div>';
    }

    // 获取编辑数据
    $edit_item = null;
    if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id']) && check_admin_referer('guyan_ai_edit_' . $_GET['id'])) {
        $edit_item = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", intval($_GET['id'])), ARRAY_A);
    }

    // 分页
    $per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;
    $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $total_pages = ceil($total_items / $per_page);
    $items = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC LIMIT $offset, $per_page", ARRAY_A);

    ?>
    <div class="wrap">
        <h1>励志古言数据管理</h1>
        
        <!-- 添加数据表单 -->
        <h2>添加新数据</h2>
        <form method="post" action="">
            <?php wp_nonce_field('guyan_ai_data_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="guyan_ai_saying_add">古言名句</label></th>
                    <td><input type="text" name="guyan_ai_saying" id="guyan_ai_saying_add" value="" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="guyan_ai_transl_add">译文</label></th>
                    <td><textarea name="guyan_ai_transl" id="guyan_ai_transl_add" rows="3" class="large-text" required></textarea></td>
                </tr>
                <tr>
                    <th><label for="guyan_ai_source_add">出处</label></th>
                    <td><input type="text" name="guyan_ai_source" id="guyan_ai_source_add" value="" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="guyan_ai_image_url_add">图片 URL</label></th>
                    <td><input type="url" name="guyan_ai_image_url" id="guyan_ai_image_url_add" value="" class="regular-text"></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="guyan_ai_add_data" class="button-primary" value="添加数据"></p>
        </form>

        <!-- 编辑数据表单 -->
        <?php if ($edit_item): ?>
            <h2>编辑数据</h2>
            <form method="post" action="">
                <?php wp_nonce_field('guyan_ai_edit_data_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="guyan_ai_saying_edit">古言名句</label></th>
                        <td><input type="text" name="guyan_ai_saying" id="guyan_ai_saying_edit" value="<?php echo esc_attr($edit_item['saying']); ?>" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="guyan_ai_transl_edit">译文</label></th>
                        <td><textarea name="guyan_ai_transl" id="guyan_ai_transl_edit" rows="3" class="large-text" required><?php echo esc_textarea($edit_item['transl']); ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="guyan_ai_source_edit">出处</label></th>
                        <td><input type="text" name="guyan_ai_source" id="guyan_ai_source_edit" value="<?php echo esc_attr($edit_item['source']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="guyan_ai_image_url_edit">图片 URL</label></th>
                        <td><input type="url" name="guyan_ai_image_url" id="guyan_ai_image_url_edit" value="<?php echo esc_url($edit_item['image_url']); ?>" class="regular-text"></td>
                    </tr>
                </table>
                <input type="hidden" name="guyan_ai_edit_id" value="<?php echo esc_attr($edit_item['id']); ?>">
                <p class="submit"><input type="submit" name="guyan_ai_edit_data" class="button-primary" value="更新数据"></p>
            </form>
        <?php endif; ?>

        <!-- 删除所有数据 -->
        <form method="post" action="">
            <?php wp_nonce_field('guyan_ai_delete_all_nonce'); ?>
            <p class="submit"><input type="submit" name="guyan_ai_delete_all" class="button-secondary" value="删除所有数据" onclick="return confirm('确定删除所有数据？');"></p>
        </form>

        <!-- 数据列表 -->
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>名句</th>
                    <th>译文</th>
                    <th>出处</th>
                    <th>图片 URL</th>
                    <th>创建时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td><?php echo esc_html($item['saying']); ?></td>
                        <td><?php echo esc_html($item['transl']); ?></td>
                        <td><?php echo esc_html($item['source']); ?></td>
                        <td><?php echo esc_url($item['image_url']); ?></td>
                        <td><?php echo esc_html($item['created_at']); ?></td>
                        <td>
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=guyan-ai-data&action=edit&id=' . $item['id']), 'guyan_ai_edit_' . $item['id']); ?>">编辑</a> |
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=guyan-ai-data&action=delete&id=' . $item['id']), 'guyan_ai_delete_' . $item['id']); ?>" onclick="return confirm('确定删除？');">删除</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- 分页 -->
        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links([
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => '«',
                'next_text' => '»',
                'total' => $total_pages,
                'current' => $current_page
            ]);
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}

// 后台通知自动消失脚本
add_action('admin_footer', 'guyan_ai_admin_scripts');
function guyan_ai_admin_scripts() {
    ?>
    <script>
    jQuery(document).ready(function($) {
        setTimeout(function() {
            $('.guyan_ai_notice').fadeOut('slow');
        }, 3000);
    });
    </script>
    <?php
}
?>