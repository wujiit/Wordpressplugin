jQuery(document).ready(function($) {
    // 确保 AIGrammarCheckData 存在
    if (typeof AIGrammarCheckData === 'undefined') {
        console.error('AIGrammarCheckData 未定义。');
        $('.grammar_check_result_content').html('<p class="grammar_check_error">初始化失败，请刷新页面或联系管理员。</p>');
        return;
    }

    // 检查用户是否登录（即 textarea 是否存在）
    const $textarea = $('#grammar_check_input');
    const isLoggedIn = $textarea.length > 0;

    // 处理检查选项按钮（仅限登录用户）
    if (isLoggedIn) {
        $('.grammar_check_option_button').click(function() {
            $(this).toggleClass('active');
            console.log('检查选项按钮点击。激活选项:', $('.grammar_check_option_button.active').map(function() { return $(this).data('value'); }).get());
        });

        // 示例按钮
        $('.grammar_check_example_button').click(function(e) {
            e.preventDefault();
            const exampleData = window.grammar_check_example_data || '';
            $textarea.val(exampleData);
            console.log('示例按钮点击。输入:', exampleData);
            updateCharCount();
        });

        // 文章润色开关
        $('.grammar_check_polish_slider').click(function() {
            const $checkbox = $('#grammar_check_polish');
            $checkbox.prop('checked', !$checkbox.prop('checked'));
            console.log('文章润色开关点击。选中:', $checkbox.is(':checked'));
        });

        // 字数统计
        function updateCharCount() {
            const charCount = $textarea.val().length;
            const maxChars = AIGrammarCheckData.char_limit || 200;
            $('.grammar_check_char_count span').text(charCount);
            if (charCount > maxChars) {
                $('.grammar_check_char_count').addClass('grammar_check_char_exceed');
            } else {
                $('.grammar_check_char_count').removeClass('grammar_check_char_exceed');
            }
            console.log('字数更新。计数:', charCount, '最大:', maxChars);
        }

        // 绑定输入事件并初始化字数
        $textarea.on('input', updateCharCount);
        updateCharCount();

        // 开始检查按钮
        $('.grammar_check_generate_button').click(function(e) {
            e.preventDefault();
            
            const $resultContent = $('.grammar_check_result_content');
            const inputData = $textarea.val();
            const $generateButton = $(this);

            console.log('开始检查按钮点击。输入:', inputData, '选项:', $('.grammar_check_option_button.active').map(function() { return $(this).data('value'); }).get());

            // 验证输入
            if (!inputData) {
                $resultContent.html('<p class="grammar_check_error">请输入需要检查的文本</p>');
                console.log('错误: 输入为空');
                return;
            }

            // 验证字数限制
            if (inputData.length > AIGrammarCheckData.char_limit) {
                $resultContent.html('<p class="grammar_check_error">输入内容超过 ' + AIGrammarCheckData.char_limit + ' 字，请删减后重试</p>');
                console.log('错误: 输入超出字数限制');
                return;
            }

            // 验证违规词
            const forbiddenWords = AIGrammarCheckData.forbidden_words || [];
            let foundForbiddenWord = null;
            if (forbiddenWords.length > 0) {
                forbiddenWords.forEach(function(word) {
                    if (inputData.toLowerCase().indexOf(word.toLowerCase()) !== -1) {
                        foundForbiddenWord = word;
                    }
                });
            }

            if (foundForbiddenWord) {
                $resultContent.html('<p class="grammar_check_error">输入内容包含违规词“' + foundForbiddenWord + '”，请重新编辑内容</p>');
                console.log('错误: 包含违规词:', foundForbiddenWord);
                return;
            }

            // 验证选择的检查选项
            const selectedOptions = [];
            $('.grammar_check_option_button.active').each(function() {
                selectedOptions.push($(this).data('value'));
            });

            if (selectedOptions.length === 0) {
                $resultContent.html('<p class="grammar_check_error">请至少选择一种检查选项</p>');
                console.log('错误: 未选择检查选项');
                return;
            }

            // 显示加载状态
            $resultContent.html('<span class="loading">正在检查中...</span>');
            console.log('显示加载状态');
            
            if (!AIGrammarCheckData.nonce) {
                $resultContent.html('<p class="grammar_check_error">请先登录以使用检查助手。</p>');
                console.log('错误: 无 nonce，用户未登录');
                return;
            }

            const data = {
                model: $('#grammar_check_model').val() || 'deepseek-chat',
                data: inputData,
                options: selectedOptions,
                polish: $('#grammar_check_polish').is(':checked').toString()
            };

            $generateButton.prop('disabled', true);
            console.log('发送 API 请求:', data);

            fetch(AIGrammarCheckData.rest_url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': AIGrammarCheckData.nonce,
                    'Accept': 'text/event-stream'
                },
                body: JSON.stringify(data)
            }).then(response => {
                if (!response.ok) {
                    return response.json().then(error => {
                        throw new Error(error.message || '请求失败');
                    });
                }

                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let done = false;
                let hasContent = false;

                function readStream() {
                    reader.read().then(({ done: streamDone, value }) => {
                        if (streamDone) {
                            done = true;
                            if (hasContent) {
                                updateUsageCount();
                            } else {
                                $resultContent.html('<p class="grammar_check_error">检查失败，未收到有效内容。</p>');
                            }
                            $generateButton.prop('disabled', false);
                            console.log('流结束。是否有内容:', hasContent);
                            return;
                        }

                        const chunk = decoder.decode(value, { stream: true });
                        const lines = chunk.split('\n').filter(line => line.trim());
                        lines.forEach(line => {
                            if (line.startsWith('data: ')) {
                                const jsonData = line.substring(6);
                                if (jsonData === '[DONE]') {
                                    done = true;
                                    if (hasContent) {
                                        updateUsageCount();
                                    } else {
                                        $resultContent.html('<p class="grammar_check_error">检查失败，未收到有效内容。</p>');
                                    }
                                    $generateButton.prop('disabled', false);
                                    console.log('流 [DONE]');
                                    return;
                                }

                                try {
                                    const data = JSON.parse(jsonData);
                                    if (data.error) {
                                        $resultContent.html('<p class="grammar_check_error">' + (data.error || '未知错误') + '</p>');
                                        $generateButton.prop('disabled', false);
                                        console.log('API 错误:', data.error);
                                        return;
                                    }
                                    if ($resultContent.find('.loading').length) {
                                        $resultContent.empty();
                                    }
                                    if (data.content) {
                                        hasContent = true;
                                        $resultContent.append(document.createTextNode(data.content));
                                        console.log('收到内容:', data.content);
                                    }
                                } catch (e) {
                                    console.error('解析流数据出错:', e, '数据:', jsonData);
                                }
                            }
                        });

                        if (!done) {
                            readStream();
                        }
                    }).catch(error => {
                        console.error('流读取失败:', error);
                        $resultContent.html('<p class="grammar_check_error">检查失败，请稍后重试。</p>');
                        $generateButton.prop('disabled', false);
                    });
                }

                readStream();
            }).catch(error => {
                console.error('API 请求失败:', error);
                $resultContent.html('<p class="grammar_check_error">' + error.message + '</p>');
                $generateButton.prop('disabled', false);
            });
        });

        // 复制按钮
        $('.grammar_check_copy_button').click(function(e) {
            e.preventDefault();
            const $temp = $('<textarea>');
            $('body').append($temp);
            $temp.val($('.grammar_check_result_content').text()).select();
            document.execCommand('copy');
            $temp.remove();

            $('.grammar_check_copy_success').html('<p class="copy-success">复制成功！</p>');
            setTimeout(function() {
                $('.grammar_check_copy_success').empty();
            }, 2000);
            console.log('复制按钮点击');
        });

        // 清空按钮
        $('.grammar_check_clear_button').click(function(e) {
            e.preventDefault();
            $('.grammar_check_result_content').empty();
            console.log('清空按钮点击');
        });

        // 更新使用次数
        function updateUsageCount() {
            $.ajax({
                url: AIGrammarCheckData.rest_url.replace('/generate', '/usage'),
                method: 'GET',
                headers: {
                    'X-WP-Nonce': AIGrammarCheckData.nonce
                },
                success: function(response) {
                    if (response.remaining > 0) {
                        $('.grammar_check_usage').text('今日可用次数：' + response.remaining + '/' + response.limit);
                        $('.grammar_check_generate_button').show();
                        $('.grammar_check_generate_button').prop('disabled', false);
                    } else {
                        $('.grammar_check_usage').text('今日已经使用完，请明天再来');
                        $('.grammar_check_generate_button').hide();
                    }
                    console.log('使用次数更新。剩余:', response.remaining, '限制:', response.limit);
                },
                error: function() {
                    $('.grammar_check_usage').text('今日可用次数：无法加载');
                    $('.grammar_check_generate_button').hide();
                    console.log('使用次数获取失败');
                }
            });
        }

        updateUsageCount();
    }

    // 快速登录按钮（对未登录用户可用）
    $('.grammar_check_quick_login_button').on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = AIGrammarCheckData.login_url || '/wp-login.php';
        }
        console.log('登录按钮点击');
    });
});