(function ($) {
    console.log('XBAitravel Plugin: JavaScript initialized.');

    let lastInputData = '';
    let lastModel = '';
    let lastEnableSearch = false;

    // Helper function to decode HTML entities
    function decodeHTMLEntities(text) {
        const textArea = document.createElement('textarea');
        textArea.innerHTML = text;
        return textArea.value;
    }

    // Function to show dynamic loading animation
    function showLoadingAnimation($element) {
        const messages = [
            '正在分析您的旅游需求...',
            '正在搜索最新旅游信息...',
            '正在生成个性化攻略...',
            '即将完成，请稍候...'
        ];
        let currentIndex = 0;
        let intervalId = null;

        $element.html('<span class="loading"></span>');
        const $loadingSpan = $element.find('.loading');

        function updateMessage() {
            $loadingSpan.text(messages[currentIndex]);
            if (currentIndex === messages.length - 1) {
                // Stop cycling at the last message
                clearInterval(intervalId);
                $loadingSpan.text('正在完成攻略...');
            } else {
                currentIndex++;
            }
        }

        updateMessage();
        if (currentIndex < messages.length - 1) {
            intervalId = setInterval(updateMessage, 2000);
        }

        return intervalId;
    }

    // Function to stop loading animation
    function stopLoadingAnimation(intervalId) {
        if (intervalId) {
            clearInterval(intervalId);
        }
    }

    async function generateStrategy(e, isRegenerate = false) {
        e.preventDefault();
        console.log(isRegenerate ? 'Regenerate button clicked.' : 'Generate button clicked.');

        const $resultContent = $('.xb_aitravel_result_content');
        const inputData = $('#xb_aitravel_input').val().trim();
        const $generateButton = $('.xb_aitravel_generate_button');
        const $regenerateButton = $('.xb_aitravel_regenerate_button');

        if (!isRegenerate) {
            if (!inputData) {
                console.log('Input data is empty.');
                $resultContent.html('<p class="xb_aitravel_error">请输入旅游需求。</p>');
                return;
            }

            if (inputData.length > 1000) {
                console.log('Input data too long.');
                $resultContent.html('<p class="xb_aitravel_error">输入内容过长，请限制在1000字以内。</p>');
                return;
            }

            const forbiddenWords = XBAitravelData.forbidden_words || [];
            const foundForbiddenWord = forbiddenWords.find(word => 
                typeof word === 'string' && typeof inputData === 'string' && 
                inputData.toLowerCase().includes(word.toLowerCase())
            );

            if (foundForbiddenWord) {
                console.log('Forbidden word detected:', foundForbiddenWord);
                $resultContent.html('<p class="xb_aitravel_error">输入内容包含违规词“' + foundForbiddenWord + '”，请重新输入</p>');
                return;
            }

            lastInputData = inputData;
            lastModel = $('#xb_aitravel_model').val() || XBAitravelData.default_model || 'qwen-plus';
            lastEnableSearch = $('#xb_aitravel_enable_search').is(':checked');
        }

        const loadingInterval = showLoadingAnimation($resultContent);

        if (!XBAitravelData.nonce) {
            console.log('Nonce not found, user not logged in.');
            stopLoadingAnimation(loadingInterval);
            $resultContent.html('<p class="xb_aitravel_error">请先登录以使用旅游攻略助手。</p>');
            return;
        }

        const data = {
            model: isRegenerate ? lastModel : $('#xb_aitravel_model').val() || XBAitravelData.default_model || 'qwen-plus',
            data: isRegenerate ? lastInputData : inputData,
            enable_search: isRegenerate ? lastEnableSearch : $('#xb_aitravel_enable_search').is(':checked')
        };
        console.log('Sending API request with data:', data);

        $generateButton.prop('disabled', true);
        $regenerateButton.prop('disabled', true);

        try {
            // Add timeout to fetch request
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 30000);

            const response = await fetch(XBAitravelData.rest_url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': XBAitravelData.nonce,
                    'Accept': 'text/event-stream'
                },
                body: JSON.stringify(data),
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
            }

            console.log('API request successful, processing stream...');
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let fullContent = '';
            let hasContent = false;

            async function readStream() {
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) {
                        stopLoadingAnimation(loadingInterval);
                        if (hasContent) {
                            // Decode HTML entities
                            let decodedContent = decodeHTMLEntities(fullContent);
                            // Parse Markdown to HTML
                            let htmlContent = marked.parse(decodedContent);
                            // Sanitize the HTML content
                            const sanitizedContent = DOMPurify.sanitize(htmlContent, {
                                ALLOWED_TAGS: ['p', 'strong', 'em', 'ul', 'li', 'ol', 'b', 'i', 'table', 'tr', 'td', 'th', 'thead', 'tbody'],
                                ALLOWED_ATTR: ['style']
                            });
                            $resultContent.html(sanitizedContent);
                            console.log('Stream completed, rendered content:', sanitizedContent);
                            updateUsageCount();
                        } else {
                            console.log('No content received.');
                            $resultContent.html('<p class="xb_aitravel_error">生成失败，未收到有效内容。</p>');
                        }
                        $generateButton.prop('disabled', false);
                        $regenerateButton.prop('disabled', false);
                        break;
                    }

                    const chunk = decoder.decode(value, { stream: true });
                    const lines = chunk.split('\n');
                    for (const line of lines) {
                        if (line.trim().startsWith('data: ')) {
                            const jsonData = line.trim().substring(6);
                            if (jsonData === '[DONE]') {
                                stopLoadingAnimation(loadingInterval);
                                if (hasContent) {
                                    // Decode HTML entities
                                    let decodedContent = decodeHTMLEntities(fullContent);
                                    // Parse Markdown to HTML
                                    let htmlContent = marked.parse(decodedContent);
                                    // Sanitize the HTML content
                                    const sanitizedContent = DOMPurify.sanitize(htmlContent, {
                                        ALLOWED_TAGS: ['p', 'strong', 'em', 'ul', 'li', 'ol', 'b', 'i', 'table', 'tr', 'td', 'th', 'thead', 'tbody'],
                                        ALLOWED_ATTR: ['style']
                                    });
                                    $resultContent.html(sanitizedContent);
                                    console.log('Stream done, rendered content:', sanitizedContent);
                                    updateUsageCount();
                                } else {
                                    console.log('No content received at stream end.');
                                    $resultContent.html('<p class="xb_aitravel_error">生成失败，未收到有效内容。</p>');
                                }
                                $generateButton.prop('disabled', false);
                                $regenerateButton.prop('disabled', false);
                                return;
                            }

                            try {
                                const data = JSON.parse(jsonData);
                                if (data.error) {
                                    console.log('API error:', data.error);
                                    stopLoadingAnimation(loadingInterval);
                                    $resultContent.html('<p class="xb_aitravel_error">' + data.error + '</p>');
                                    $generateButton.prop('disabled', false);
                                    $regenerateButton.prop('disabled', false);
                                    return;
                                }
                                if (data.content) {
                                    hasContent = true;
                                    // Accumulate content
                                    fullContent += data.content;
                                    console.log('Received content chunk:', data.content);
                                }
                            } catch (e) {
                                console.error('解析流数据出错:', e, ' - 原始数据:', jsonData);
                                stopLoadingAnimation(loadingInterval);
                                $resultContent.html('<p class="xb_aitravel_error">生成过程中发生错误，请检查日志。</p>');
                                $generateButton.prop('disabled', false);
                                $regenerateButton.prop('disabled', false);
                                return;
                            }
                        }
                    }
                }
            }

            await readStream();
        } catch (error) {
            console.error('API 请求失败:', error, {
                message: error.message,
                name: error.name,
                stack: error.stack,
                url: XBAitravelData.rest_url
            });
            stopLoadingAnimation(loadingInterval);
            $resultContent.html('<p class="xb_aitravel_error">生成失败：' + (error.message.includes('aborted') ? '请求超时，请稍后重试' : error.message) + '</p>');
            $generateButton.prop('disabled', false);
            $regenerateButton.prop('disabled', false);

            // Fallback to non-streaming request
            console.log('Attempting fallback non-streaming request...');
            try {
                const fallbackResponse = await fetch(XBAitravelData.rest_url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': XBAitravelData.nonce,
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify(data)
                });

                if (!fallbackResponse.ok) {
                    const errorData = await fallbackResponse.json().catch(() => ({}));
                    throw new Error(errorData.message || `Fallback HTTP error! status: ${fallbackResponse.status}`);
                }

                const responseData = await fallbackResponse.json();
                if (responseData.content) {
                    let decodedContent = decodeHTMLEntities(responseData.content);
                    let htmlContent = marked.parse(decodedContent);
                    const sanitizedContent = DOMPurify.sanitize(htmlContent, {
                        ALLOWED_TAGS: ['p', 'strong', 'em', 'ul', 'li', 'ol', 'b', 'i', 'table', 'tr', 'td', 'th', 'thead', 'tbody'],
                        ALLOWED_ATTR: ['style']
                    });
                    $resultContent.html(sanitizedContent);
                    console.log('Fallback request successful, rendered content:', sanitizedContent);
                    updateUsageCount();
                } else {
                    $resultContent.html('<p class="xb_aitravel_error">生成失败：无有效内容返回。</p>');
                }
                $generateButton.prop('disabled', false);
                $regenerateButton.prop('disabled', false);
            } catch (fallbackError) {
                console.error('Fallback request failed:', fallbackError);
                $resultContent.html('<p class="xb_aitravel_error">生成失败：' + fallbackError.message + '</p>');
                $generateButton.prop('disabled', false);
                $regenerateButton.prop('disabled', false);
            }
        }
    }

    $(document).on('click', '.xb_aitravel_generate_button', generateStrategy);

    $(document).on('click', '.xb_aitravel_regenerate_button', function (e) {
        generateStrategy(e, true);
    });

    $(document).on('click', '.xb_aitravel_copy_button', function (e) {
        e.preventDefault();
        console.log('Copy button clicked.');
        const $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val($('.xb_aitravel_result_content').text()).select();
        document.execCommand('copy');
        $temp.remove();

        $('.xb_aitravel_copy_success').html('<p class="copy-success">复制成功！</p>');
        setTimeout(() => $('.xb_aitravel_copy_success').empty(), 2000);
    });

    $(document).on('click', '.xb_aitravel_clear_button', function (e) {
        e.preventDefault();
        console.log('Clear button clicked.');
        $('.xb_aitravel_result_content').empty();
    });

    $(document).on('click', '.xb_aitravel_quick_login_button', function (e) {
        e.preventDefault();
        console.log('Quick login button clicked.');
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.click();
        } else {
            window.location.href = '<?php echo esc_url(wp_login_url(get_permalink())); ?>';
        }
    });

    async function updateUsageCount() {
        console.log('Updating usage count via AJAX.');
        try {
            const response = await $.ajax({
                url: XBAitravelData.rest_url.replace('/query', '/usage'),
                method: 'GET',
                headers: {
                    'X-WP-Nonce': XBAitravelData.nonce
                }
            });
            console.log('Usage count updated:', response);
            const $usageDisplay = $('.xb_aitravel_usage');
            const $generateButton = $('.xb_aitravel_generate_button');
            const $regenerateButton = $('.xb_aitravel_regenerate_button');
            if (response.remaining <= 0) {
                $usageDisplay.text('今日已用完，请明天再来');
                $generateButton.hide();
                $regenerateButton.hide();
            } else {
                $usageDisplay.text('今日可用次数：' + response.limit + '/' + response.remaining);
                $generateButton.show();
                $regenerateButton.show();
            }
        } catch (error) {
            console.error('Failed to update usage count:', error);
            $('.xb_aitravel_usage').text('今日可用次数：无法加载');
            $('.xb_aitravel_generate_button').hide();
            $('.xb_aitravel_regenerate_button').hide();
        }
    }

    $(document).on('click', '.xb_aitravel_search_toggle .slider', function (e) {
        e.preventDefault();
        const $checkbox = $(this).siblings('input[type="checkbox"]');
        $checkbox.prop('checked', !$checkbox.prop('checked'));
        console.log('Search toggle clicked, new state:', $checkbox.prop('checked'));
    });

    $(document).on('click', '.xb_aitravel_search_toggle', function (e) {
        if (!$(e.target).hasClass('slider')) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Clicked on search toggle label or surrounding area, no toggle action.');
        }
    });

    $(document).ready(() => {
        updateUsageCount();
    });

    console.log('XBAitravelData:', XBAitravelData);
})(jQuery);