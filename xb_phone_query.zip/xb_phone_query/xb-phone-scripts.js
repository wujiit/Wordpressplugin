jQuery(document).ready(function ($) {
    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('XB Phone Query: jQuery 未加载！');
        $('#xb_phone_result').html('<div class="xb_phone_message">脚本加载失败，请刷新页面！</div>');
        return;
    }

    // 确保 xb_phone_ajax 配置
    if (typeof xb_phone_ajax === 'undefined') {
        console.error('XB Phone Query: xb_phone_ajax 未定义！');
        $('#xb_phone_result').html('<div class="xb_phone_message">脚本配置失败，请检查插件设置！</div>');
        return;
    }

    // 生成随机验证码
    function generateCaptcha() {
        const operators = ['+', '-'];
        const num1 = Math.floor(Math.random() * 10) + 1;
        const num2 = Math.floor(Math.random() * 10) + 1;
        const operator = operators[Math.floor(Math.random() * operators.length)];
        let question, value;

        if (operator === '+') {
            question = `${num1} + ${num2} = `;
            value = num1 + num2;
        } else {
            // 确保减法结果非负且在10以内
            const maxNum = Math.max(num1, num2);
            const minNum = Math.min(num1, num2);
            question = `${maxNum} - ${minNum} = `;
            value = maxNum - minNum;
        }

        $('#xb_phone_captcha_question').text(question);
        $('#xb_phone_captcha_value').val(value);
    }

    // 检查是否需要显示验证码
    if ($('#xb_phone_captcha_question').length) {
        generateCaptcha();
    }

    // 查询表单提交
    $('#xb_phone_query_form').on('submit', function (e) {
        e.preventDefault();

        var $form = $(this);
        var phone = $('#xb_phone_number').val().trim();
        var nonce = $('#xb_phone_nonce').val();
        var captchaAnswer = $('#xb_phone_captcha_answer').val();
        var captchaValue = $('#xb_phone_captcha_value').val();

        if (!phone) {
            $('#xb_phone_result').html('<div class="xb_phone_message">请输入手机号码！</div>');
            return;
        }

        if (!nonce) {
            $('#xb_phone_result').html('<div class="xb_phone_message">安全验证参数丢失，请刷新页面！</div>');
            return;
        }

        $.ajax({
            url: xb_phone_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_phone_query',
                phone: phone,
                nonce: nonce,
                captcha_answer: captchaAnswer || '',
                captcha_value: captchaValue || ''
            },
            beforeSend: function () {
                $('.xb_phone_submit_button').prop('disabled', true).text('查询中...');
            },
            success: function (response) {
                if (response.success) {
                    $('#xb_phone_result').html(response.data.result);
                    if ($('.xb_phone_usage_info').length) {
                        $('.xb_phone_usage_info').text('今日剩余查询次数：' + response.data.remaining + '/' + response.data.limit);
                    }

                    if (response.data.remaining <= 0 && !response.data.captcha) {
                        $form.hide();
                        $('#xb_phone_result').append('<div class="xb_phone_message">今日查询次数已用尽，请明天再试！</div>');
                    } else if (response.data.captcha) {
                        // 显示验证码
                        if (!$('#xb_phone_captcha_question').length) {
                            $form.find('#xb_phone_number').after(
                                '<div class="xb_phone_captcha_section">' +
                                '<span id="xb_phone_captcha_question"></span>' +
                                '<input type="number" name="xb_phone_captcha_answer" id="xb_phone_captcha_answer" placeholder="请输入验证码答案" required>' +
                                '<input type="hidden" name="xb_phone_captcha_value" id="xb_phone_captcha_value">' +
                                '</div>'
                            );
                            generateCaptcha();
                        } else {
                            generateCaptcha();
                        }
                    }
                } else {
                    $('#xb_phone_result').html('<div class="xb_phone_message">' + response.data.message + '</div>');
                    if ($('#xb_phone_captcha_question').length) {
                        generateCaptcha();
                        $('#xb_phone_captcha_answer').val('');
                    }
                }
            },
            error: function (xhr, status, error) {
                console.error('XB Phone Query: AJAX 错误：' + error);
                $('#xb_phone_result').html('<div class="xb_phone_message">请求失败：' + error + '。请检查网络或刷新页面。</div>');
            },
            complete: function () {
                $('.xb_phone_submit_button').prop('disabled', false).text('查询');
            }
        });
    });
});