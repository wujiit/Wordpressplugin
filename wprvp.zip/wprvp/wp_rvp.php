<?php
/*
Plugin Name: 小半游客权限
Description: 全站、菜单、分类、分类文章链接是否仅对登录用户可见。
Plugin URI: https://www.jingxialai.com/4529.html
Version: 1.3
Author: summer
Author URI: https://www.jingxialai.com/
License: GPL License
*/
if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_head', 'wp_rvp_custom_styles');
function wp_rvp_custom_styles() {
    if (isset($_GET['page']) && $_GET['page'] === 'wp_rvp_menu_permission_settings') {
        ?>
        <style>
            body {
                color: #333;
                background-color: #f5f5f5;
                margin: 0;
                padding: 0;
            }
            .wp_rvp_wrap {
                max-width: 95%;
                margin: 20px auto;
                background-color: #fff;
                padding: 20px;
                border-radius: 5px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }
            .wp_rvp_table {
                width: 50%;
                border-collapse: collapse;
                border-spacing: 0;
            }
            .wp_rvp_table th,
            .wp_rvp_table td {
                padding: 8px;
                border: 1px solid #ddd;
                text-align: left;
            }
            .wp_rvp_table th {
                background-color: #f2f2f2;
                font-weight: bold;
            }
            .wp-rvp-redirect-url-input {
                width: 350px;
            }
        </style>
        <?php
    }
}

// 添加后台菜单
add_action('admin_menu', 'wp_rvp_menu_permission_settings');
function wp_rvp_menu_permission_settings() {
    add_menu_page('游客权限设置', '游客权限设置', 'manage_options', 'wp_rvp_menu_permission_settings', 'wp_rvp_menu_permission_settings_page');
}

// 设置页快捷链接
function wp_rvp_mp_settings_link($links) {
    $settings_link = '<a href="admin.php?page=wp_rvp_menu_permission_settings">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wp_rvp_mp_settings_link');

// 为菜单项添加自定义选项
add_action('wp_nav_menu_item_custom_fields', 'wp_rvp_custom_menu_item_fields', 10, 4);
function wp_rvp_custom_menu_item_fields($id, $item, $depth, $args) {
    $is_logged_in = get_post_meta($id, '_menu_item_logged_in', true);
    ?>
    <p class="wp_rvp_field-visibility description description-wide">
        <label for="edit-menu-item-logged-in-<?php echo $id; ?>">
            <input type="checkbox" id="edit-menu-item-logged-in-<?php echo $id; ?>" name="menu-item-logged-in[<?php echo $id; ?>]" value="1" <?php checked($is_logged_in, '1'); ?> />
            仅对登录用户可见
        </label>
    </p>
    <?php
}

// 保存菜单项的自定义选项
add_action('wp_update_nav_menu_item', 'wp_rvp_save_custom_menu_item_fields', 10, 3);
function wp_rvp_save_custom_menu_item_fields($menu_id, $menu_item_db_id, $args) {
    if (isset($_POST['menu-item-logged-in'][$menu_item_db_id])) {
        update_post_meta($menu_item_db_id, '_menu_item_logged_in', '1');
    } else {
        delete_post_meta($menu_item_db_id, '_menu_item_logged_in');
    }
}

// 针对未登录用户过滤菜单项
add_filter('wp_nav_menu_objects', 'wp_rvp_filter_menu_for_logged_in_users', 10, 2);
function wp_rvp_filter_menu_for_logged_in_users($items, $args) {
    if (is_user_logged_in()) {
        return $items;
    }
    foreach ($items as $key => $item) {
        $is_logged_in = get_post_meta($item->ID, '_menu_item_logged_in', true);
        if ($is_logged_in == '1') {
            unset($items[$key]);
        }
    }
    return $items;
}

// 后台设置页面内容
function wp_rvp_menu_permission_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('你没有权限访问这个页面！');
    }

    // 获取已保存的设置
    $menu_permission_category      = get_option('menu_permission_category');
    $menu_permission_redirect_url  = get_option('menu_permission_redirect_url');
    $enable_redirect               = get_option('enable_redirect');
    $enable_text_hint              = get_option('enable_text_hint');
    $site_permission_enable        = get_option('site_permission_enable');
    $enable_frontend_password      = get_option('enable_frontend_password');
    $frontend_access_password      = get_option('frontend_access_password');

    $categories = get_categories(array(
        'hide_empty' => 0,
    ));

    if (isset($_POST['submit'])) {
        update_option('menu_permission_category', $_POST['menu_permission_category']);
        update_option('menu_permission_redirect_url', $_POST['menu_permission_redirect_url']);
        update_option('enable_redirect', isset($_POST['enable_redirect']) ? 1 : 0);
        update_option('enable_text_hint', isset($_POST['enable_text_hint']) ? 1 : 0);
        update_option('site_permission_enable', isset($_POST['site_permission_enable']) ? 1 : 0);
        update_option('enable_frontend_password', isset($_POST['enable_frontend_password']) ? 1 : 0);
        update_option('frontend_access_password', sanitize_text_field($_POST['frontend_access_password']));

        echo '<div class="updated"><p>设置已保存</p></div>';
        $menu_permission_category     = $_POST['menu_permission_category'];
        $menu_permission_redirect_url = $_POST['menu_permission_redirect_url'];
        $enable_redirect              = isset($_POST['enable_redirect']) ? 1 : 0;
        $enable_text_hint             = isset($_POST['enable_text_hint']) ? 1 : 0;
        $site_permission_enable       = isset($_POST['site_permission_enable']) ? 1 : 0;
        $enable_frontend_password     = isset($_POST['enable_frontend_password']) ? 1 : 0;
        $frontend_access_password     = sanitize_text_field($_POST['frontend_access_password']);
    }
    ?>
    <div class="wp_rvp_wrap">
        <h2>权限设置</h2>
        <form method="post" action="">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">全站仅登录可见</th>
                    <td><input type="checkbox" name="site_permission_enable" <?php checked($site_permission_enable, 1); ?> /></td>
                </tr>           
                <tr valign="top">
                    <th scope="row">游客访问跳转链接</th>
                    <td><input type="text" name="menu_permission_redirect_url" class="wp-rvp-redirect-url-input" value="<?php echo esc_attr($menu_permission_redirect_url); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">禁止游客访问的文章分类ID</th>
                    <td><input type="text" name="menu_permission_category" value="<?php echo esc_attr($menu_permission_category); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">分类文章一起跳转</th>
                    <td><input type="checkbox" name="enable_redirect" <?php checked($enable_redirect, 1); ?> /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">分类文章文本提示</th>
                    <td><input type="checkbox" name="enable_text_hint" <?php checked($enable_text_hint, 1); ?> /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">启用前台密码访问</th>
                    <td><input type="checkbox" name="enable_frontend_password" <?php checked($enable_frontend_password, 1); ?> /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">前台访问密码</th>
                    <td><input type="text" name="frontend_access_password" value="<?php echo esc_attr($frontend_access_password); ?>" /></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="submit" class="button-primary" value="保存设置" /></p>
        </form>
        <p>说明：<br>
           1、多个分类用英文逗号(半角符号)隔开。<br>
           2、分类文章链接跳转：游客无法访问分类链接以及这个分类下的所有文章链接。<br>
           3、分类文章文本提示：游客无法访问分类链接，但是可以访问分类下的文章，只能看见标题，内容提示先登录，不影响SEO。<br>
           <font color="red">4、跳转链接设置：跳转网站内部链接，只填写域名后面的就行，比如： /contact.html</font><br>
           <font color="blue">5、全站仅登录可见：跳转网站内部链接，只支持跳转登录页面，比如： /wp-login.php</font><br>
           6、跳转外部链接，就写完整，比如： https://www.baidu.com<br>
           7、菜单权限设置就在菜单管理处。<br>
           8、如果你的主题调用、改动之类的比较多，可能就会不兼容。
        </p>
        <h2>所有分类及其 ID</h2>
        <table class="wp_rvp_table">
            <thead>
                <tr>
                    <th>分类名称</th>
                    <th>分类 ID</th>
                    <th>是否受限</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $category) {
                    $is_limited = wp_rvp_is_category_limited($category->term_id, $menu_permission_category);
                    ?>
                    <tr>
                        <td><?php echo $category->name; ?></td>
                        <td><?php echo $category->term_id; ?></td>
                        <td><?php echo $is_limited ? '是' : ''; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <script>
        // JS 检查复选框（同组中只允许选中一个）
        document.addEventListener('DOMContentLoaded', function() {
            var checkboxes = document.querySelectorAll('input[type="checkbox"]');
            checkboxes.forEach(function(checkbox) {
                checkbox.addEventListener('change', function() {
                    if (this.checked) {
                        checkboxes.forEach(function(otherCheckbox) {
                            if (otherCheckbox !== checkbox) {
                                otherCheckbox.checked = false;
                            }
                        });
                    }
                });
            });
        });
    </script>
    <?php
}

// 根据分类 ID 判断该分类是否受限
function wp_rvp_is_category_limited($category_id, $limited_categories) {
    $limited_categories_array = explode(',', $limited_categories);
    return in_array($category_id, $limited_categories_array);
}

// --------------------- 文章分类和全站权限判断 ---------------------

// 根据菜单权限设置进行文章或分类跳转
add_action('template_redirect', 'wp_rvp_redirect_for_menu_permissions');
function wp_rvp_redirect_for_menu_permissions() {
    if (is_category() || is_single()) {
        $menu_permission_category     = get_option('menu_permission_category');
        $menu_permission_redirect_url = get_option('menu_permission_redirect_url');
        $enable_redirect              = get_option('enable_redirect');
        $enable_text_hint             = get_option('enable_text_hint');
        if (!$menu_permission_category || !$menu_permission_redirect_url) {
            return;
        }
        $current_categories = get_the_category();
        $current_category_ids = array();
        foreach ($current_categories as $category) {
            $current_category_ids[] = $category->term_id;
            $child_categories = get_categories(array('parent' => $category->term_id, 'hide_empty' => false));
            foreach ($child_categories as $child_category) {
                $current_category_ids[] = $child_category->term_id;
            }
        }
        $categories = explode(',', $menu_permission_category);
        if (array_intersect($current_category_ids, $categories)) {
            if ($enable_redirect && !is_user_logged_in()) {
                wp_redirect($menu_permission_redirect_url);
                exit;
            }
            if ($enable_text_hint && !is_user_logged_in() && is_single()) {
                add_filter('the_content', 'wp_rvp_show_login_hint');
            }
            if (!is_user_logged_in() && is_category()) {
                wp_redirect($menu_permission_redirect_url);
                exit;
            }
        }
    }
}

// 添加“请先登录”提示
function wp_rvp_show_login_hint($content) {
    return '<p>请先登录</p>';
}

// 根据全站权限设置进行跳转
add_action('template_redirect', 'wp_rvp_redirect_for_site_permissions');
function wp_rvp_redirect_for_site_permissions() {
    // 排除首页，确保首页正常访问
    if (is_front_page()) {
        return;
    }
    $site_permission_enable = get_option('site_permission_enable');
    $menu_permission_redirect_url = get_option('menu_permission_redirect_url');
    if ($site_permission_enable && !is_user_logged_in() && !is_admin()) {
        $redirect_to = esc_url($_SERVER['REQUEST_URI']);
        $login_url   = wp_login_url($redirect_to);
        wp_redirect($menu_permission_redirect_url);
        exit;
    }
}

// --------------------- 前台密码访问功能 ---------------------

// 定义前台密码相关常量
if (!defined('WP_RVP_ACCESS_COOKIE_NAME')) {
    define('WP_RVP_ACCESS_COOKIE_NAME', 'wp_rvp_site_access_token');
}
if (!defined('WP_RVP_ACCESS_COOKIE_EXPIRY')) {
    define('WP_RVP_ACCESS_COOKIE_EXPIRY', 7 * DAY_IN_SECONDS);
}
if (!defined('WP_RVP_ACCESS_MAX_ATTEMPTS')) {
    define('WP_RVP_ACCESS_MAX_ATTEMPTS', 5);
}
if (!defined('WP_RVP_ACCESS_LOCKOUT_TIME')) {
    define('WP_RVP_ACCESS_LOCKOUT_TIME', 10 * MINUTE_IN_SECONDS);
}

// 处理密码提交（仅在前台生效，且后台不受影响）
function wp_rvp_handle_password_submission() {
    // 如果是后台则不执行
    if ( is_admin() ) {
        return;
    }
    if ( ! get_option('enable_frontend_password') ) {
        return;
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['frontend_access_password'])) {
        $input_password  = sanitize_text_field($_POST['frontend_access_password']);
        $stored_password = get_option('frontend_access_password');
        $attempts        = get_transient('wp_rvp_access_attempts') ?: 0;

        if ($attempts >= WP_RVP_ACCESS_MAX_ATTEMPTS) {
            setcookie('wp_rvp_access_error', '尝试次数过多，请 10 分钟后再试。', time() + 60, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
            wp_safe_redirect($_SERVER['REQUEST_URI']);
            exit;
        }

        if ($input_password === $stored_password) {
            $token = hash_hmac('sha256', $stored_password, wp_salt());
            setcookie(WP_RVP_ACCESS_COOKIE_NAME, $token, time() + WP_RVP_ACCESS_COOKIE_EXPIRY, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
            setcookie('wp_rvp_access_error', '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
            delete_transient('wp_rvp_access_attempts');
            wp_safe_redirect(home_url());
            exit;
        } else {
            set_transient('wp_rvp_access_attempts', $attempts + 1, WP_RVP_ACCESS_LOCKOUT_TIME);
            setcookie('wp_rvp_access_error', '密码错误，请重试。', time() + 60, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
            wp_safe_redirect($_SERVER['REQUEST_URI']);
            exit;
        }
    }
}
add_action('init', 'wp_rvp_handle_password_submission');

// 保护前台页面（仅在启用前台密码访问时生效，且首页不受限制）
function wp_rvp_restrict_site_access() {
    if ( ! get_option('enable_frontend_password') ) {
        return;
    }
    if ( is_admin() || is_user_logged_in() || is_front_page() || isset($_COOKIE[WP_RVP_ACCESS_COOKIE_NAME]) ) {
        return;
    }
    $error_message = isset($_COOKIE['wp_rvp_access_error']) ? sanitize_text_field($_COOKIE['wp_rvp_access_error']) : '';
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>输入密码访问</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background: linear-gradient(135deg, #667eea, #764ba2);
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
            }
            .password-container {
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
                text-align: center;
                width: 100%;
                max-width: 350px;
            }
            h2 {
                color: #333;
                margin-bottom: 10px;
            }
            p {
                color: #666;
                font-size: 14px;
            }
            input {
                width: 100%;
                padding: 10px;
                margin: 10px 0;
                border: 1px solid #ccc;
                border-radius: 5px;
                font-size: 16px;
            }
            button {
                width: 100%;
                padding: 10px;
                background: #0073aa;
                color: white;
                border: none;
                border-radius: 5px;
                font-size: 16px;
                cursor: pointer;
                transition: background 0.3s ease;
            }
            button:hover {
                background: #005177;
            }
            .error {
                color: red;
                font-size: 14px;
                margin-top: 10px;
            }
        </style>
    </head>
    <body>
        <div class="password-container">
            <h2>访问受限</h2>
            <p>本页面需要输入密码才能访问。请输入密码以继续。</p>
            <form method="post">
                <input type="password" name="frontend_access_password" placeholder="输入访问密码" required>
                <button type="submit">提交</button>
                <?php if ($error_message): ?>
                    <p class="error"><?php echo $error_message; ?></p>
                <?php endif; ?>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}
add_action('template_redirect', 'wp_rvp_restrict_site_access', 0);

// 注册插件卸载钩子
register_uninstall_hook(__FILE__, 'wp_rvp_uninstall');
// 卸载插件时执行的回调函数
function wp_rvp_uninstall() {
    // 删除数据库中保存的设置
    delete_option('menu_permission_category');
    delete_option('menu_permission_redirect_url');
    delete_option('site_permission_enable');
    delete_option('enable_redirect');
    delete_option('enable_text_hint');
    delete_option('frontend_access_password');
    delete_option('enable_frontend_password');
}
?>