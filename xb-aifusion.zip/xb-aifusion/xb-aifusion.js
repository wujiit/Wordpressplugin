jQuery(document).ready(function ($) {
    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('XB AI Fusion: jQuery 未加载！');
        return;
    }

    // 确保配置存在
    if (typeof xb_aifusion_ajax === 'undefined') {
        console.error('XB AI Fusion: 配置未定义！');
        return;
    }

    // 全局变量
    let uploadedFiles = [];
    let taskId = '';
    let selectedStyle = null;
    let currentResultUrls = [];

    // DOM 元素选择器
    const dropArea = $('#xb_aifusion_drop_area');
    const fileInput = $('#xb_aifusion_files');
    const previewSection = $('#xb_aifusion_preview_section');
    const imagesPreview = $('#xb_aifusion_images_preview');
    const submitButton = $('#xb_aifusion_submit_button');
    const promptInput = $('#xb_aifusion_prompt');
    const modelSelect = $('#xb_aifusion_model');
    const sizeSelect = $('#xb_aifusion_size');
    const resolutionSelect = $('#xb_aifusion_resolution');
    const countSelect = $('#xb_aifusion_count');
    const watermarkCheckbox = $('#xb_aifusion_watermark');
    const resultSection = $('#xb_aifusion_result_section');
    const resultPreview = $('#xb_aifusion_result_preview');
    const regenerateBtn = $('#xb_aifusion_regenerate');
    const downloadBtn = $('#xb_aifusion_download');
    const clearAllBtn = $('#xb_aifusion_clear_all');
    const stylesGrid = $('#xb_aifusion_styles_grid');
    const resultArea = $('#xb_aifusion_result');
    const usageInfo = $('.xb_aifusion_usage_info');
    const allowTextOnly = $('input[name="xb_aifusion_allow_text_only"]').val() === '1';

    // 检查关键元素是否存在
    const isFormAvailable = promptInput.length > 0 && submitButton.length > 0;

    // 初始化图片对比滑块
    function initComparisonSliders() {
        $('.xb-aifusion-comparison').each(function () {
            const slider = this;
            const images = slider.querySelectorAll('img');
            images.forEach(img => {
                img.addEventListener('load', () => {
                    slider.dispatchEvent(new Event('resize'));
                });
            });
        });
    }

    initComparisonSliders();

    $(window).on('resize', function () {
        $('.xb-aifusion-comparison').each(function () {
            this.dispatchEvent(new Event('resize'));
        });
    });

    // 文件上传相关事件
    if (isFormAvailable && dropArea.length > 0 && fileInput.length > 0) {
        dropArea.on('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            fileInput.click();
        });

        fileInput.on('click', function (e) {
            e.stopPropagation();
        });

        dropArea.on('dragover', function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).addClass('xb_aifusion_drop_active');
        });

        dropArea.on('dragleave', function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('xb_aifusion_drop_active');
        });

        dropArea.on('drop', function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('xb_aifusion_drop_active');
            const files = e.originalEvent.dataTransfer.files;
            if (files.length > 0) {
                handleFiles(files);
            }
        });

        fileInput.on('change', function () {
            if (this.files && this.files.length > 0) {
                handleFiles(this.files);
            }
        });
    }

    // 处理多个文件上传
    function handleFiles(files) {
        const maxUploadCount = 6; // 从后台设置获取
        
        // 检查当前已上传数量 + 新文件数量是否超过限制
        if (uploadedFiles.length + files.length > maxUploadCount) {
            showToast('最多只能上传' + maxUploadCount + '张图片！当前已有' + uploadedFiles.length + '张', 'error');
            return;
        }

        // 验证文件
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/bmp', 'image/tiff', 'image/webp'];
        const maxSize = 10 * 1024 * 1024; // 10MB

        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            if (!allowedTypes.includes(file.type.toLowerCase())) {
                showToast('不支持的文件格式！', 'error');
                return;
            }
            if (file.size > maxSize) {
                showToast('文件大小超出限制！', 'error');
                return;
            }
        }

        // 上传文件
        const formData = new FormData();
        for (let i = 0; i < files.length; i++) {
            formData.append('files[]', files[i]);
        }
        formData.append('action', 'xb_aifusion_upload');
        formData.append('_wpnonce', xb_aifusion_ajax.upload_nonce);

        $.ajax({
            url: xb_aifusion_ajax.upload_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function () {
                if (submitButton.length > 0) {
                    submitButton.prop('disabled', true).html('<span class="xb_aifusion_button_icon">⏳</span>上传中...');
                }
                if (dropArea.length > 0) {
                    dropArea.addClass('xb_aifusion_uploading');
                }
            },
            success: function (response) {
                if (response.success && response.data.urls) {
                    // 将新上传的文件添加到现有数组中
                    uploadedFiles = uploadedFiles.concat(response.data.urls);
                    $('#xb_aifusion_file_urls').val(uploadedFiles.join(','));
                    showImagePreviews();
                    if (dropArea.length > 0) {
                        dropArea.hide();
                    }
                    
                    // 检查上传后的风格兼容性
                    checkUploadStyleCompatibility();
                    // 更新预设风格可用状态
                    updateStylesAvailability();
                    updateSubmitButton();
                    resetUploadButton();
                } else {
                    showToast('文件上传失败：' + (response.data && response.data.message || '未知错误'), 'error');
                    resetUploadButton();
                }
            },
            error: function (xhr) {
                const message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ?
                    xhr.responseJSON.data.message : '文件上传失败，请重试！';
                showToast(message, 'error');
                resetUploadButton();
            }
        });
    }

    // 显示图片预览
    function showImagePreviews() {
        if (imagesPreview.length === 0) return;
        
        imagesPreview.empty();
        uploadedFiles.forEach((url, index) => {
            const previewItem = $(`
                <div class="xb_aifusion_image_item" data-index="${index}">
                    <img src="${url}" alt="预览图片">
                    <button type="button" class="xb_aifusion_remove_single">✕</button>
                </div>
            `);
            imagesPreview.append(previewItem);
        });
        
        // 添加继续上传按钮（如果还没达到最大数量）
        const maxUploadCount = 6; // 从后台设置获取
        if (uploadedFiles.length < maxUploadCount) {
            const isDisabled = selectedStyle ? 'disabled' : '';
            const title = selectedStyle ? 'title="预设风格模式下无法上传多张图片"' : '';
            
            const continueUploadBtn = $(`
                <div class="xb_aifusion_continue_upload">
                    <button type="button" class="xb_aifusion_continue_btn" ${isDisabled} ${title}>
                        <span class="xb_aifusion_button_icon">📤</span>
                        继续上传 (${uploadedFiles.length}/${maxUploadCount})
                    </button>
                </div>
            `);
            imagesPreview.append(continueUploadBtn);
        }
        
        if (previewSection.length > 0) {
            previewSection.show();
        }
    }

    // 删除单张图片
    $(document).on('click', '.xb_aifusion_remove_single', function (e) {
        e.preventDefault();
        const index = parseInt($(this).parent().data('index'));
        uploadedFiles.splice(index, 1);
        $('#xb_aifusion_file_urls').val(uploadedFiles.join(','));
        
        if (uploadedFiles.length === 0) {
            if (previewSection.length > 0) {
                previewSection.hide();
            }
            if (dropArea.length > 0) {
                dropArea.show();
            }
            // 清除所有相关警告
            clearToast('style-warning');
            clearToast('style-limit-warning');
        } else {
            showImagePreviews();
        }
        
        // 更新预设风格可用状态
        updateStylesAvailability();
        // 更新继续上传按钮状态
        updateContinueUploadAvailability();
        
        // 当图片数量变为1张或0张时，清除多图警告
        if (uploadedFiles.length <= 1) {
            clearToast('style-warning');
            clearToast('style-limit-warning');
            clearToast('style-disabled');
        }
        
        updateSubmitButton();
    });

    // 继续上传按钮事件
    $(document).on('click', '.xb_aifusion_continue_btn', function (e) {
        e.preventDefault();
        
        // 检查是否已选择预设风格
        if (selectedStyle) {
            showToast('预设风格模式下无法上传多张图片，请先取消预设风格选择', 'warning', 'upload-blocked');
            return;
        }
        
        fileInput.click(); // 触发文件选择
    });

    // 更新提交按钮状态
    function updateSubmitButton() {
        if (submitButton.length === 0) return;

        const hasImage = uploadedFiles.length > 0;
        const hasPrompt = (promptInput.length > 0 && promptInput.val().trim() !== '') || selectedStyle !== null;
        
        if (allowTextOnly) {
            // 允许纯文字生成
            if (hasPrompt) {
                submitButton.prop('disabled', false).html('<span class="xb_aifusion_button_icon">🚀</span>开始创作');
            } else {
                submitButton.prop('disabled', true).html('<span class="xb_aifusion_button_icon">✏️</span>请输入提示词或选择风格');
            }
        } else {
            // 必须上传图片
            if (hasImage && hasPrompt) {
                submitButton.prop('disabled', false).html('<span class="xb_aifusion_button_icon">🚀</span>开始创作');
            } else if (!hasImage) {
                submitButton.prop('disabled', true).html('<span class="xb_aifusion_button_icon">📤</span>请先上传图片');
            } else {
                submitButton.prop('disabled', true).html('<span class="xb_aifusion_button_icon">✏️</span>请输入提示词或选择风格');
            }
        }
    }

    // 重置上传按钮状态
    function resetUploadButton() {
        if (submitButton.length > 0) {
            submitButton.prop('disabled', true).html('<span class="xb_aifusion_button_icon">🚀</span>开始创作');
        }
        if (dropArea.length > 0) {
            dropArea.removeClass('xb_aifusion_uploading');
        }
    }

    // 输入监听
    if (isFormAvailable) {
        promptInput.on('input', function () {
            if ($(this).val().trim() !== '') {
                clearStyleSelection();
            }
            updateSubmitButton();
        });
    }

    // 风格选择处理
    if (stylesGrid.length > 0) {
        stylesGrid.on('click', '.xb_aifusion_style_item', function () {
            const $this = $(this);
            const prompt = $this.data('prompt');
            const isCurrentlySelected = $this.hasClass('selected');
            const isDisabled = $this.hasClass('disabled');
            
            // 如果预设风格被禁用，不允许点击
            if (isDisabled) {
                showToast('预设风格只支持单张图片，请先删除多余图片', 'warning', 'style-disabled');
                return;
            }
            
            // 如果点击的是已选中的风格，取消选择
            if (isCurrentlySelected) {
                clearStyleSelection();
                showToast('已取消预设风格选择', 'info', 'style-cancelled');
                updateSubmitButton();
                return;
            }
            
            // 选择新风格
            selectedStyle = prompt;
            $('.xb_aifusion_style_item').removeClass('selected');
            $this.addClass('selected');
            
            // 清空手动输入的提示词
            if (promptInput.length > 0) {
                promptInput.val('');
            }
            
            // 更新继续上传按钮状态
            updateContinueUploadAvailability();
            
            showToast('已选择预设风格', 'info', 'style-selected');
            clearToast('style-warning');
            clearToast('style-limit-warning');
            updateSubmitButton();
        });
    }

    // 检查预设风格的图片数量限制
    function checkStyleImageLimit() {
        if (selectedStyle && uploadedFiles.length > 1) {
            // 如果已选择风格但图片过多，清除风格选择并显示警告
            clearStyleSelection();
            showToast('预设风格只支持1张图片，已自动取消风格选择', 'warning', 'style-limit-warning');
            return false;
        } else {
            // 如果图片数量符合要求，清除警告消息
            clearToast('style-limit-warning');
            clearToast('style-warning');
        }
        return true;
    }

    // 检查上传后的风格兼容性
    function checkUploadStyleCompatibility() {
        if (selectedStyle && uploadedFiles.length > 1) {
            // 如果已选择风格但新上传导致图片过多，自动取消风格选择
            clearStyleSelection();
            showToast('上传多张图片后已自动取消预设风格选择，预设风格仅支持单张图片', 'info', 'upload-style-info');
        } else if (uploadedFiles.length <= 1) {
            // 清除之前的警告消息
            clearToast('style-warning');
            clearToast('style-limit-warning');
            clearToast('upload-style-info');
        }
    }

    // 更新预设风格的可用状态
    function updateStylesAvailability() {
        if (stylesGrid.length === 0) return;
        
        const styleItems = $('.xb_aifusion_style_item');
        
        if (uploadedFiles.length > 1) {
            // 多张图片时禁用所有预设风格
            styleItems.addClass('disabled').attr('title', '预设风格只支持单张图片');
        } else {
            // 单张或无图片时启用所有预设风格
            styleItems.removeClass('disabled').removeAttr('title');
        }
    }

    // 更新继续上传按钮的可用状态
    function updateContinueUploadAvailability() {
        const continueBtn = $('.xb_aifusion_continue_btn');
        
        if (selectedStyle) {
            // 已选择预设风格时禁用继续上传
            continueBtn.prop('disabled', true).attr('title', '预设风格模式下无法上传多张图片');
        } else {
            // 未选择预设风格时启用继续上传
            continueBtn.prop('disabled', false).removeAttr('title');
        }
    }

    // 清除风格选择
    function clearStyleSelection() {
        selectedStyle = null;
        $('.xb_aifusion_style_item').removeClass('selected');
        // 清除所有相关的Toast消息
        clearToast('style-warning');
        clearToast('style-limit-warning');
        // 更新继续上传按钮状态
        updateContinueUploadAvailability();
    }

    // 表单提交处理
    if (isFormAvailable) {
        $('#xb_aifusion_form').on('submit', function (e) {
            e.preventDefault();
            
            // 检查预设风格的图片限制
            if (selectedStyle && !checkStyleImageLimit()) {
                return;
            }
            
            if (!allowTextOnly && uploadedFiles.length === 0) {
                showToast('请先上传图片！', 'error');
                return;
            }

            let prompt = selectedStyle || (promptInput.length > 0 ? promptInput.val().trim() : '');
            const aiModel = modelSelect.length > 0 ? modelSelect.val() || '' : '';
            const imageSize = sizeSelect.length > 0 ? sizeSelect.val() || '2K' : '2K';
            const imageResolution = resolutionSelect.length > 0 ? resolutionSelect.val() || '2K' : '2K';
            const imageCount = countSelect.length > 0 ? parseInt(countSelect.val()) || 1 : 1;
            const watermark = watermarkCheckbox.length > 0 ? (watermarkCheckbox.is(':checked') ? 1 : 0) : 0;

            if (!prompt) {
                showToast('请输入提示词或选择预设风格！', 'error');
                return;
            }

            $.ajax({
                url: xb_aifusion_ajax.rest_url,
                type: 'POST',
                data: JSON.stringify({
                    image_urls: uploadedFiles.join(','),
                    prompt: prompt,
                    ai_model: aiModel,
                    image_size: imageSize,
                    image_resolution: imageResolution,
                    image_count: imageCount,
                    watermark: watermark
                }),
                contentType: 'application/json',
                headers: { 'X-WP-Nonce': xb_aifusion_ajax.nonce },
                beforeSend: function () {
                    if (submitButton.length > 0) {
                        submitButton.prop('disabled', true).html('<span class="xb_aifusion_button_icon">⏳</span>创作中...');
                    }
                    showLoadingMessage();
                    hideActionButtons();
                },
                success: function (response) {
                    if (response.status === 'success' && response.result_urls) {
                        showResult(response.result_urls);
                        updateUsageInfo(response.remaining, response.limit);
                    } else if (response.task_id) {
                        taskId = response.task_id;
                        setTimeout(function () {
                            checkResult(taskId);
                        }, 3000);
                    } else {
                        showToast(response.message || '创作失败，请重试', 'error');
                        resetForm();
                    }
                },
                error: function (xhr) {
                    const message = xhr.responseJSON && xhr.responseJSON.message ?
                        xhr.responseJSON.message : '暂时无法创作请联系客服';
                    showToast(message, 'error');
                    resetForm();
                }
            });
        });
    }

    // 检查处理结果
    function checkResult(task_id) {
        const maxAttempts = 30;
        let attempts = 0;

        const poll = setInterval(function () {
            if (attempts >= maxAttempts) {
                clearInterval(poll);
                showToast('处理超时，请稍后重试', 'error');
                resetForm();
                return;
            }

            $.ajax({
                url: xb_aifusion_ajax.check_result_url,
                type: 'POST',
                data: JSON.stringify({ task_id: task_id }),
                contentType: 'application/json',
                headers: { 'X-WP-Nonce': xb_aifusion_ajax.nonce },
                success: function (response) {
                    if (response.status === 'success' && response.result_urls) {
                        clearInterval(poll);
                        showResult(response.result_urls);
                        updateUsageInfo(response.remaining, response.limit);
                    } else if (response.status === 'pending') {
                        attempts++;
                    } else {
                        clearInterval(poll);
                        showToast(response.message || '暂时无法创作请联系客服', 'error');
                        resetForm();
                    }
                },
                error: function (xhr) {
                    clearInterval(poll);
                    const message = xhr.responseJSON && xhr.responseJSON.message ?
                        xhr.responseJSON.message : '查询结果失败，请重试';
                    showToast(message, 'error');
                    resetForm();
                }
            });
        }, 5000);
    }

    // 显示处理结果
    function showResult(resultUrls) {
        currentResultUrls = resultUrls;
        if (resultPreview.length > 0) {
            resultPreview.empty();
            resultUrls.forEach((url, index) => {
                const resultItem = $(`
                    <div class="xb_aifusion_result_item">
                        <img src="${url}" alt="结果图片 ${index + 1}">
                    </div>
                `);
                resultPreview.append(resultItem);
            });
        }
        if (resultSection.length > 0) {
            resultSection.show();
        }
        showActionButtons();
        resetSubmitButton();
        hideLoadingMessage();
        
        // 不保存结果到会话存储，避免刷新后仍显示
        // sessionStorage.setItem('xb_aifusion_last_result', JSON.stringify({
        //     urls: resultUrls,
        //     timestamp: Date.now()
        // }));
    }

    // 显示加载信息
    function showLoadingMessage() {
        if (resultArea.length > 0) {
            resultArea.html(
                '<div class="xb_aifusion_loading">' +
                '<div class="xb_aifusion_spinner"></div>' +
                '<div class="xb_aifusion_ts_subtitle">🔄 正在创作中</div>' +
                '<p>请稍候，AI正在为您创作图片...</p>' +
                '</div>'
            );
        }
    }

    // 隐藏加载信息
    function hideLoadingMessage() {
        $('.xb_aifusion_loading').remove();
    }

    // 显示操作按钮
    function showActionButtons() {
        if (regenerateBtn.length > 0) {
            regenerateBtn.show();
        }
        if (downloadBtn.length > 0) {
            downloadBtn.show();
        }
    }

    // 隐藏操作按钮
    function hideActionButtons() {
        if (regenerateBtn.length > 0) {
            regenerateBtn.hide();
        }
        if (downloadBtn.length > 0) {
            downloadBtn.hide();
        }
    }

    // 重置提交按钮
    function resetSubmitButton() {
        if (submitButton.length > 0) {
            submitButton.prop('disabled', false).html('<span class="xb_aifusion_button_icon">🚀</span>开始创作');
        }
    }

    // 更新使用次数信息
    function updateUsageInfo(remaining, limit) {
        if (remaining !== undefined && limit !== undefined && usageInfo.length > 0) {
            usageInfo.html(
                '<span class="xb_aifusion_usage_icon">📊</span>今日剩余创作次数：' + remaining + '/' + limit
            );
            if (remaining <= 0) {
                hideUploadAreaButKeepResult();
                sessionStorage.removeItem('xb_aifusion_last_result');
            }
        }
    }

    // 隐藏上传区域但保持结果显示
    function hideUploadAreaButKeepResult() {
        $('.xb_aifusion_prompt_section, .xb_aifusion_upload_section, .xb_aifusion_preview_section').fadeOut(300);
        if (submitButton.length > 0) {
            submitButton.fadeOut(300);
        }
        if (clearAllBtn.length > 0) {
            clearAllBtn.fadeOut(300);
        }
        if (regenerateBtn.length > 0) {
            regenerateBtn.fadeOut(300);
        }
        
        setTimeout(function() {
            const limitMessage =
                '<div class="xb_aifusion_message xb_aifusion_message_info" style="margin-top: 20px;">' +
                '<div class="xb_aifusion_message_icon">📅</div>' +
                '<div class="xb_aifusion_message_content">' +
                '<div class="xb_aifusion_ts_subtitle">今日使用次数已用完</div>' +
                '<p>今日使用次数已经用完，请明天再来。</p>' +
                '</div>' +
                '</div>';
            $('.xb_aifusion_config_section').append(limitMessage);
        }, 300);
    }

    // 按钮事件绑定
    if (regenerateBtn.length > 0) {
        regenerateBtn.on('click', function (e) {
            e.preventDefault();
            if ($('#xb_aifusion_form').length > 0) {
                $('#xb_aifusion_form').trigger('submit');
            }
        });
    }

    if (downloadBtn.length > 0) {
        downloadBtn.on('click', function (e) {
            e.preventDefault();
            if (currentResultUrls.length > 0) {
                downloadImages(currentResultUrls);
            } else {
                showToast('无图片可下载！', 'error');
            }
        });
    }

    // 下载图片
    function downloadImages(urls) {
        if (urls.length === 1) {
            // 单张图片直接下载
            downloadImageDirect(urls[0]);
        } else {
            // 多张图片打包下载
            const downloadUrl = xb_aifusion_ajax.download_url + '?urls=' + encodeURIComponent(urls.join(','));
            window.open(downloadUrl, '_blank');
            showToast('开始下载图片包...', 'success');
        }
    }

    // 直接下载单张图片
    function downloadImageDirect(imageUrl) {
        showToast('开始下载图片...', 'info');
        
        try {
            const link = document.createElement('a');
            link.href = imageUrl;
            link.download = 'ai_fusion_' + Date.now() + '.jpg';
            link.target = '_blank';
            link.style.display = 'none';
            
            document.body.appendChild(link);
            link.click();
            
            setTimeout(() => {
                document.body.removeChild(link);
            }, 100);
            
            showToast('图片下载开始！', 'success');
        } catch (error) {
            console.error('下载失败:', error);
            window.open(imageUrl, '_blank');
            showToast('已在新窗口打开图片，请右键保存', 'info');
        }
    }

    if (clearAllBtn.length > 0) {
        clearAllBtn.on('click', function (e) {
            e.preventDefault();
            resetForm();
            if (resultArea.length > 0) {
                resultArea.empty();
            }
            hideActionButtons();
            // 清除会话存储
            sessionStorage.removeItem('xb_aifusion_last_result');
        });
    }

    // 重置表单
    function resetForm() {
        if (fileInput.length > 0) {
            fileInput.val('');
        }
        $('#xb_aifusion_file_urls').val('');
        if (promptInput.length > 0) {
            promptInput.val('');
        }
        if (previewSection.length > 0) {
            previewSection.hide();
        }
        if (resultSection.length > 0) {
            resultSection.hide();
        }
        if (dropArea.length > 0) {
            dropArea.show().removeClass('xb_aifusion_uploading');
        }
        clearStyleSelection();
        uploadedFiles = [];
        taskId = '';
        currentResultUrls = [];
        
        // 更新所有状态
        updateStylesAvailability();
        updateContinueUploadAvailability();
        updateSubmitButton();
        hideLoadingMessage();
        
        // 清除所有Toast消息
        clearToast('style-warning');
        clearToast('style-limit-warning');
        clearToast('style-disabled');
        clearToast('upload-blocked');
    }

    // 显示提示消息
    function showToast(message, type = 'info', id = null) {
        // 如果指定了ID，先清除同ID的消息
        if (id) {
            clearToast(id);
        }
        
        const toastId = id || 'toast_' + Date.now();
        const toast = $('<div class="xb_aifusion_toast ' + type + '" data-toast-id="' + toastId + '">' +
            '<span class="icon">' + getToastIcon(type) + '</span>' +
            '<span>' + message + '</span>' +
            '</div>');
        
        // 直接添加到页面，位置由CSS控制
        $('body').append(toast);

        const displayTime = type === 'info' ? 1500 : (type === 'warning' ? 4000 : 3000);
        
        setTimeout(function () {
            toast.fadeOut(300, function () {
                toast.remove();
            });
        }, displayTime);
    }
    
    // 清除指定ID的Toast消息
    function clearToast(id) {
        if (id) {
            $('.xb_aifusion_toast[data-toast-id="' + id + '"]').fadeOut(200, function() {
                $(this).remove();
            });
        }
    }

    // 获取提示图标
    function getToastIcon(type) {
        switch (type) {
            case 'success': return '✅';
            case 'error': return '❌';
            case 'info': return 'ℹ️';
            default: return 'ℹ️';
        }
    }

    // 快速登录处理
    $(document).on('click', '.xb_aifusion_login_btn', function (e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });

    // 页面刷新时清除会话存储
    $(window).on('beforeunload', function() {
        // 页面刷新时总是清除会话存储，避免刷新后仍显示结果
        sessionStorage.removeItem('xb_aifusion_last_result');
    });

    // 初始化
    updateSubmitButton();
    updateStylesAvailability();
    updateContinueUploadAvailability();
    // 不在页面加载时检查会话结果，避免刷新后仍显示
    // checkSessionResult();
});