<?php
/*
Plugin Name: AI图像融合创作
Description: 基于豆包Seedream模型的AI图像融合创作工具，支持多图融合、组图生成等功能
Version: 1.0.0
Author: Summer
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xb_aifusion_activate');
function xb_aifusion_activate() {
    xb_aifusion_create_database();
    xb_aifusion_create_front_page();
}

// 创建数据库表
function xb_aifusion_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 使用次数表
    $usage_table = $wpdb->prefix . 'xb_aifusion_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL DEFAULT 0,
        usage_date date NOT NULL,
        usage_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_date (user_id, usage_date)
    ) $charset_collate;";

    // 创作记录表
    $records_table = $wpdb->prefix . 'xb_aifusion_records';
    $records_sql = "CREATE TABLE $records_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL DEFAULT 0,
        image_urls text NOT NULL,
        prompt_text text NOT NULL,
        ai_model varchar(100) DEFAULT NULL,
        image_size varchar(50) DEFAULT NULL,
        image_resolution varchar(10) DEFAULT NULL,
        image_count int(11) DEFAULT 1,
        watermark tinyint(1) DEFAULT 0,
        creation_status varchar(20) NOT NULL,
        creation_time datetime NOT NULL,
        task_id varchar(100) DEFAULT NULL,
        result_urls text DEFAULT NULL,
        error_message text DEFAULT NULL,
        ip_address varchar(45) NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // 预设风格表
    $styles_table = $wpdb->prefix . 'xb_aifusion_styles';
    $styles_sql = "CREATE TABLE $styles_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        style_title varchar(100) NOT NULL,
        style_prompt text NOT NULL,
        style_image varchar(500) DEFAULT NULL,
        sort_order int(11) DEFAULT 0,
        created_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // 示例演示表
    $demos_table = $wpdb->prefix . 'xb_aifusion_demos';
    $demos_sql = "CREATE TABLE $demos_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        demo_title varchar(100) NOT NULL,
        original_image varchar(500) NOT NULL,
        result_image varchar(500) NOT NULL,
        sort_order int(11) DEFAULT 0,
        created_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($usage_sql);
    dbDelta($records_sql);
    dbDelta($styles_sql);
    dbDelta($demos_sql);
}

// 创建前台页面
function xb_aifusion_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_aifusion_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => 'AI图像融合创作',
            'post_content' => '[xb_aifusion_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 加载管理页面
if (is_admin()) {
    require_once plugin_dir_path(__FILE__) . 'xb-aifusion-admin.php';
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_aifusion_enqueue_scripts');
function xb_aifusion_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_aifusion_form')) {
        wp_enqueue_style('xb_aifusion_styles', plugins_url('xb-aifusion.css', __FILE__), array(), '1.0.0');
        wp_enqueue_script('xb_aifusion_scripts', plugins_url('xb-aifusion.js', __FILE__), array('jquery'), '1.0.0', true);
        wp_enqueue_script('img-comparison-slider', 'https://cdn.jsdelivr.net/npm/img-comparison-slider@8.0.6/dist/index.min.js', array(), '8.0.6', true);

        wp_localize_script('xb_aifusion_scripts', 'xb_aifusion_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => rest_url('xb_aifusion/v1/process'),
            'nonce' => wp_create_nonce('wp_rest'),
            'login_url' => wp_login_url(get_permalink()),
            'is_logged_in' => is_user_logged_in() ? 1 : 0,
            'upload_url' => admin_url('admin-ajax.php'),
            'upload_nonce' => wp_create_nonce('xb_aifusion_upload_nonce'),
            'check_result_url' => rest_url('xb_aifusion/v1/check_result'),
            'download_url' => rest_url('xb_aifusion/v1/download'),
        ));
    }
}

// 短代码
add_shortcode('xb_aifusion_form', 'xb_aifusion_form_shortcode');
function xb_aifusion_form_shortcode() {
    $ad_content = get_option('xb_aifusion_ad_content', '');
    $default_limit = absint(get_option('xb_aifusion_default_limit', 10));
    $show_stats = get_option('xb_aifusion_show_stats', 1);
    $show_model_select = get_option('xb_aifusion_show_model_select', 0);
    $allowed_formats = array_map('strtolower', array_map('trim', explode(',', get_option('xb_aifusion_allowed_formats', 'JPG,JPEG,PNG,BMP,TIFF,WEBP'))));
    $max_file_size = absint(get_option('xb_aifusion_max_file_size', 10));
    $max_upload_count = absint(get_option('xb_aifusion_max_upload_count', 6));
    $ai_models = array_map('trim', explode(',', get_option('xb_aifusion_ai_models', 'doubao-seedream-4-0-250828')));
    $image_sizes = array_map('trim', explode(',', get_option('xb_aifusion_image_sizes', '2048x2048,2304x1728,1728x2304')));
    $image_resolutions = array_map('trim', explode(',', get_option('xb_aifusion_image_resolutions', '1K,2K,4K')));
    $image_counts = array_map('trim', explode(',', get_option('xb_aifusion_image_counts', '1,3,6,9')));
    $allow_text_only = get_option('xb_aifusion_allow_text_only', 0);

    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $today = current_time('Y-m-d');

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aifusion_usage';

    // 获取使用次数统计
    $usage_count = 0;
    $user_limit = $default_limit;

    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT usage_count, custom_limit 
                 FROM $usage_table 
                 WHERE user_id = %d AND usage_date = %s",
                $user_id, $today
            )
        );
        $usage_count = $row && $row->usage_count !== null ? absint($row->usage_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;
    } else {
        $usage_count = $user_limit;
    }

    $remaining = max(0, $user_limit - $usage_count);
    $stats_text = "今日剩余创作次数：{$remaining}/{$user_limit}";
    
    $show_upload_area = true;
    $disable_reason = '';

    if (!is_user_logged_in()) {
        $show_upload_area = false;
        $disable_reason = 'guest_disabled';
    } elseif (is_user_logged_in() && $usage_count >= $user_limit) {
        $show_upload_area = false;
        $disable_reason = 'user_limit_exceeded';
    }

    ob_start();
    ?>
    <div class="xb_aifusion_container">
        <div class="xb_aifusion_header">
            <div class="xb_aifusion_title">AI图像融合创作工具</div>
            <p class="xb_aifusion_subtitle">智能图像融合，让创意无限可能</p>
        </div>

        <div class="xb_aifusion_content">
            <div class="xb_aifusion_left_section">
                <div class="xb_aifusion_config_section">
                    <div class="xb_aifusion_section_title">创作配置区域</div>
                    
                    <?php if (!$show_upload_area): ?>
                        <div class="xb_aifusion_message xb_aifusion_message_info">
                            <?php if ($disable_reason === 'guest_disabled'): ?>
                                <div class="xb_aifusion_message_icon">🔐</div>
                                <div class="xb_aifusion_message_content">
                                    <div class="xb_aifusion_ts_subtitle">请先登录</div>
                                    <p>登录后即可使用AI图像融合创作功能</p>
                                    <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xb_aifusion_login_btn">立即登录</a>
                                </div>
                            <?php elseif ($disable_reason === 'user_limit_exceeded'): ?>
                                <div class="xb_aifusion_message_icon">📅</div>
                                <div class="xb_aifusion_message_content">
                                    <div class="xb_aifusion_ts_subtitle">今日使用次数已用完</div>
                                    <p>今日使用次数已经用完，请明天再来。</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <form id="xb_aifusion_form" method="post" enctype="multipart/form-data">
                            <div class="xb_aifusion_prompt_section">
                                <div class="xb_aifusion_input_group">
                                    <label for="xb_aifusion_prompt">创作提示词</label>
                                    <textarea name="xb_aifusion_prompt" id="xb_aifusion_prompt" placeholder="描述您希望的图像融合效果..." rows="3"></textarea>
                                </div>
                                
                                <?php if ($show_model_select && count($ai_models) > 1): ?>
                                <div class="xb_aifusion_input_group">
                                    <label for="xb_aifusion_model">AI模型选择</label>
                                    <select name="xb_aifusion_model" id="xb_aifusion_model">
                                        <?php foreach ($ai_models as $model): ?>
                                            <option value="<?php echo esc_attr($model); ?>"><?php echo esc_html($model); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <?php endif; ?>

                                <div class="xb_aifusion_options_row">
                                    <div class="xb_aifusion_input_group">
                                        <label for="xb_aifusion_size">图片尺寸</label>
                                        <select name="xb_aifusion_size" id="xb_aifusion_size">
                                            <?php foreach ($image_sizes as $size): ?>
                                                <option value="<?php echo esc_attr($size); ?>"><?php echo esc_html($size); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="xb_aifusion_input_group">
                                        <label for="xb_aifusion_resolution">分辨率</label>
                                        <select name="xb_aifusion_resolution" id="xb_aifusion_resolution">
                                            <?php foreach ($image_resolutions as $resolution): ?>
                                                <option value="<?php echo esc_attr($resolution); ?>"><?php echo esc_html($resolution); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="xb_aifusion_input_group">
                                        <label for="xb_aifusion_count">生成数量</label>
                                        <select name="xb_aifusion_count" id="xb_aifusion_count">
                                            <?php foreach ($image_counts as $count): ?>
                                                <option value="<?php echo esc_attr($count); ?>"><?php echo esc_html($count); ?>张</option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="xb_aifusion_input_group">
                                    <label>
                                        <input type="checkbox" name="xb_aifusion_watermark" id="xb_aifusion_watermark" value="1">
                                        添加AI生成水印(不建议)
                                    </label>
                                </div>
                            </div>

                            <?php if (!$allow_text_only): ?>
                            <div class="xb_aifusion_upload_section">
                                <div class="xb_aifusion_drop_area" id="xb_aifusion_drop_area">
                                    <div class="xb_aifusion_drop_icon">🖼️</div>
                                    <div>拖拽图片到此处或点击上传</div>
                                    <p class="xb_aifusion_drop_text">支持 <?php echo implode(', ', $allowed_formats); ?> 格式，最大<?php echo $max_file_size; ?>MB，最多<?php echo $max_upload_count; ?>张</p>
                                    <input type="file" name="xb_aifusion_files[]" id="xb_aifusion_files" accept="<?php echo esc_attr('.' . implode(',.', $allowed_formats)); ?>" multiple style="display:none;">
                                </div>
                            </div>
                            <?php endif; ?>

                            <div class="xb_aifusion_preview_section" id="xb_aifusion_preview_section" style="display:none;">
                                <div class="xb_aifusion_preview_title">已上传图片预览</div>
                                <div class="xb_aifusion_images_preview" id="xb_aifusion_images_preview"></div>
                            </div>

                            <div class="xb_aifusion_actions">
                                <button type="submit" class="xb_aifusion_submit_button" id="xb_aifusion_submit_button" <?php echo !$allow_text_only ? 'disabled' : ''; ?>>
                                    <span class="xb_aifusion_button_icon">🚀</span>
                                    开始创作
                                </button>
                                <button type="button" class="xb_aifusion_clear_button" id="xb_aifusion_clear_all">
                                    <span class="xb_aifusion_button_icon">🗑️</span>
                                    清空全部
                                </button>
                                <button type="button" class="xb_aifusion_regenerate_button" id="xb_aifusion_regenerate" style="display:none;">
                                    <span class="xb_aifusion_button_icon">🔄</span>
                                    重新生成
                                </button>
                                <button type="button" class="xb_aifusion_download_button" id="xb_aifusion_download" style="display:none;">
                                    <span class="xb_aifusion_button_icon">📥</span>
                                    下载结果
                                </button>
                            </div>

                            <div class="xb_aifusion_result_section" id="xb_aifusion_result_section" style="display:none;">
                                <div class="xb_aifusion_result_title">创作结果预览</div>
                                <div class="xb_aifusion_result_preview" id="xb_aifusion_result_preview"></div>
                            </div>

                            <input type="hidden" name="xb_aifusion_nonce" id="xb_aifusion_nonce" value="<?php echo wp_create_nonce('xb_aifusion_nonce'); ?>">
                            <input type="hidden" name="xb_aifusion_file_urls" id="xb_aifusion_file_urls" value="">
                            <input type="hidden" name="xb_aifusion_allow_text_only" value="<?php echo $allow_text_only; ?>">
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <div class="xb_aifusion_right_section">
                <div class="xb_aifusion_styles_section">
                    <div class="xb_aifusion_section_title">预设风格快速选择</div>
                    <div class="xb_aifusion_styles_grid" id="xb_aifusion_styles_grid">
                        <?php
                        $styles_table = $wpdb->prefix . 'xb_aifusion_styles';
                        $styles = $wpdb->get_results("SELECT * FROM $styles_table ORDER BY sort_order DESC, id ASC");
                        
                        if ($styles):
                            foreach ($styles as $style):
                        ?>
                            <div class="xb_aifusion_style_item" data-prompt="<?php echo esc_attr($style->style_prompt); ?>">
                                <?php if ($style->style_image): ?>
                                    <img src="<?php echo esc_url($style->style_image); ?>" alt="<?php echo esc_attr($style->style_title); ?>">
                                <?php else: ?>
                                    <div class="xb_aifusion_style_placeholder">🎨</div>
                                <?php endif; ?>
                                <div class="xb_aifusion_style_title"><?php echo esc_html($style->style_title); ?></div>
                            </div>
                        <?php 
                            endforeach;
                        else:
                        ?>
                            <div class="xb_aifusion_no_styles">
                                <p>暂无预设风格，请联系管理员添加</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="xb_aifusion_result_area">
            <div id="xb_aifusion_result"></div>
            <?php if ($show_stats && ($show_upload_area || $disable_reason === 'user_limit_exceeded')): ?>
                <div class="xb_aifusion_usage_info">
                    <span class="xb_aifusion_usage_icon">📊</span>
                    <?php echo esc_html($stats_text); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="xb_aifusion_demo_section">
            <div class="xb_aifusion_demo_title">AI创作示例</div>
            <div class="xb_aifusion_demo_grid">
                <?php
                $demos_table = $wpdb->prefix . 'xb_aifusion_demos';
                $demos = $wpdb->get_results("SELECT * FROM $demos_table ORDER BY sort_order DESC, id ASC LIMIT 6");
                
                if ($demos):
                    foreach ($demos as $demo):
                ?>
                    <div class="xb_aifusion_demo_item">
                        <div class="xb_aifusion_demo_header"><?php echo esc_html($demo->demo_title); ?></div>
                        <div class="xb_aifusion_demo_comparison">
                            <img-comparison-slider class="xb-aifusion-comparison">
                                <img slot="first" src="<?php echo esc_url($demo->original_image); ?>" alt="原图" class="xb-aifusion-img" />
                                <img slot="second" src="<?php echo esc_url($demo->result_image); ?>" alt="效果图" class="xb-aifusion-img" />
                            </img-comparison-slider>
                            <div class="xb-aifusion-label-first">原图</div>
                            <div class="xb-aifusion-label-second">效果图</div>
                        </div>
                    </div>
                <?php 
                    endforeach;
                else:
                ?>
                    <div class="xb_aifusion_no_demos">
                        <p>暂无示例演示，敬请期待</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if (!empty($ad_content)): ?>
            <div class="xb_aifusion_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

// 注册 REST API 端点
add_action('rest_api_init', 'xb_aifusion_register_rest_routes');
function xb_aifusion_register_rest_routes() {
    register_rest_route('xb_aifusion/v1', '/process', array(
        'methods' => 'POST',
        'callback' => 'xb_aifusion_handle_process',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
        'args' => array(
            'image_urls' => array('required' => false, 'sanitize_callback' => 'sanitize_textarea_field'),
            'prompt' => array('required' => true, 'sanitize_callback' => 'sanitize_textarea_field'),
            'ai_model' => array('required' => false, 'sanitize_callback' => 'sanitize_text_field'),
            'image_size' => array('required' => false, 'sanitize_callback' => 'sanitize_text_field'),
            'image_resolution' => array('required' => false, 'sanitize_callback' => 'sanitize_text_field'),
            'image_count' => array('required' => false, 'sanitize_callback' => 'absint'),
            'watermark' => array('required' => false, 'sanitize_callback' => 'absint'),
        )
    ));

    register_rest_route('xb_aifusion/v1', '/check_result', array(
        'methods' => 'POST',
        'callback' => 'xb_aifusion_check_result',
        'permission_callback' => '__return_true',
        'args' => array(
            'task_id' => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
        )
    ));

    register_rest_route('xb_aifusion/v1', '/download', array(
        'methods' => 'GET',
        'callback' => 'xb_aifusion_handle_download',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
        'args' => array(
            'urls' => array('required' => true, 'sanitize_callback' => 'sanitize_textarea_field'),
        )
    ));
}

// 处理图像融合请求
function xb_aifusion_handle_process(WP_REST_Request $request) {
    $image_urls = $request->get_param('image_urls') ?: '';
    $prompt = $request->get_param('prompt');
    $ai_model = $request->get_param('ai_model') ?: '';
    $image_size = $request->get_param('image_size') ?: '2K';
    $image_resolution = $request->get_param('image_resolution') ?: '2K';
    $image_count = absint($request->get_param('image_count')) ?: 1;
    $watermark = absint($request->get_param('watermark')) ? true : false;
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $ip_address = $_SERVER['REMOTE_ADDR'];

    // 检查违规词
    $banned_words = get_option('xb_aifusion_banned_words', '');
    if (!empty($banned_words)) {
        $banned_list = array_map('trim', explode(',', $banned_words));
        foreach ($banned_list as $word) {
            if (!empty($word) && stripos($prompt, $word) !== false) {
                return new WP_REST_Response(array('message' => '输入内容包含违规词，请重新输入'), 400);
            }
        }
    }

    // 检查使用次数
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aifusion_usage';
    $default_limit = absint(get_option('xb_aifusion_default_limit', 10));
    
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT usage_count, custom_limit 
             FROM $usage_table 
             WHERE user_id = %d AND usage_date = %s",
            $user_id, $today
        )
    );
    
    $usage_count = $row && $row->usage_count !== null ? absint($row->usage_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;

    if ($usage_count >= $user_limit) {
        return new WP_REST_Response(array('message' => '今日使用次数已经用完，请明天再来。'), 403);
    }

    $result = xb_aifusion_call_api($image_urls, $prompt, $ai_model, $image_size, $image_resolution, $image_count, $watermark, $user_id, $ip_address, $today);
    
    $result['remaining'] = max(0, $user_limit - ($usage_count + 1));
    $result['limit'] = $user_limit;
    
    return new WP_REST_Response($result, 200);
}

// 调用AI接口
function xb_aifusion_call_api($image_urls, $prompt, $ai_model, $image_size, $image_resolution, $image_count, $watermark, $user_id, $ip_address, $today) {
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aifusion_records';

    $api_url = get_option('xb_aifusion_api_url', 'https://ark.cn-beijing.volces.com/api/v3/images/generations');
    $api_key = get_option('xb_aifusion_api_key');
    $models = array_map('trim', explode(',', get_option('xb_aifusion_ai_models', 'doubao-seedream-4-0-250828')));
    $selected_model = !empty($ai_model) ? $ai_model : $models[0];

    // 生成唯一任务ID
    $task_id = md5($image_urls . $prompt . microtime(true) . wp_rand());

    // 构建请求体
    $body = array(
        'model' => $selected_model,
        'prompt' => $prompt,
        'size' => $image_size,
        'watermark' => $watermark,
        'stream' => false,
        'response_format' => 'url'
    );

    // 处理图片输入
    $image_array = array();
    if (!empty($image_urls)) {
        $urls = array_filter(array_map('trim', explode(',', $image_urls)));
        if (count($urls) > 1) {
            $body['image'] = $urls;
            $body['sequential_image_generation'] = $image_count > 1 ? 'auto' : 'disabled';
            if ($image_count > 1) {
                $body['sequential_image_generation_options'] = array('max_images' => $image_count);
            }
        } elseif (count($urls) === 1) {
            $body['image'] = $urls[0];
            if ($image_count > 1) {
                $body['sequential_image_generation'] = 'auto';
                $body['sequential_image_generation_options'] = array('max_images' => $image_count);
            }
        }
    } else {
        // 纯文生图
        if ($image_count > 1) {
            $body['sequential_image_generation'] = 'auto';
            $body['sequential_image_generation_options'] = array('max_images' => $image_count);
        }
    }

    $args = array(
        'method' => 'POST',
        'timeout' => 200,
        'sslverify' => false,
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key,
        ),
        'body' => json_encode($body),
    );

    $insert_data = array(
        'user_id' => $user_id,
        'image_urls' => $image_urls,
        'prompt_text' => $prompt,
        'ai_model' => $selected_model,
        'image_size' => $image_size,
        'image_resolution' => $image_resolution,
        'image_count' => $image_count,
        'watermark' => $watermark ? 1 : 0,
        'creation_status' => 'pending',
        'creation_time' => current_time('mysql'),
        'task_id' => $task_id,
        'ip_address' => $ip_address,
    );

    $response = wp_remote_request($api_url, $args);

    if (is_wp_error($response)) {
        $insert_data['creation_status'] = 'failed';
        $insert_data['error_message'] = 'API 请求失败: ' . $response->get_error_message();
        $wpdb->insert($records_table, $insert_data);
        return array(
            'message' => '暂时无法创作请联系客服',
            'task_id' => $task_id,
        );
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if ($status_code >= 400 || !isset($data['data'])) {
        $error_message = isset($data['error']['message']) ? $data['error']['message'] : 'API 请求错误：HTTP ' . $status_code;
        $insert_data['creation_status'] = 'failed';
        $insert_data['error_message'] = $error_message;
        $wpdb->insert($records_table, $insert_data);
        return array(
            'message' => '暂时无法创作请联系客服',
            'task_id' => $task_id,
        );
    }

    // 处理成功响应
    if (isset($data['data']) && is_array($data['data'])) {
        $result_urls = array();
        foreach ($data['data'] as $item) {
            if (isset($item['url'])) {
                $result_urls[] = $item['url'];
            }
        }
        
        if (!empty($result_urls)) {
            $insert_data['creation_status'] = 'success';
            $insert_data['result_urls'] = implode(',', $result_urls);
            
            xb_aifusion_update_usage($user_id, $today);
            
            $wpdb->insert($records_table, $insert_data);
            
            return array(
                'status' => 'success',
                'result_urls' => $result_urls,
                'task_id' => $task_id,
            );
        }
    }

    $insert_data['creation_status'] = 'failed';
    $insert_data['error_message'] = '接口返回格式错误';
    $wpdb->insert($records_table, $insert_data);
    return array(
        'message' => '暂时无法创作请联系客服',
        'task_id' => $task_id,
    );
}

// 更新使用次数
function xb_aifusion_update_usage($user_id, $today) {
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aifusion_usage';

    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT usage_count, custom_limit 
             FROM $usage_table 
             WHERE user_id = %d AND usage_date = %s",
            $user_id, $today
        )
    );

    if ($row) {
        $wpdb->update(
            $usage_table,
            array('usage_count' => $row->usage_count + 1),
            array('user_id' => $user_id, 'usage_date' => $today)
        );
    } else {
        $wpdb->insert(
            $usage_table,
            array(
                'user_id' => $user_id,
                'usage_date' => $today,
                'usage_count' => 1,
                'custom_limit' => null,
            )
        );
    }
}

// 检查结果
function xb_aifusion_check_result(WP_REST_Request $request) {
    $task_id = $request->get_param('task_id');
    
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aifusion_records';
    $record = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $records_table WHERE task_id = %s", $task_id)
    );

    if (!$record) {
        return new WP_REST_Response(array('message' => '任务不存在'), 404);
    }

    if ($record->creation_status === 'success' && $record->result_urls) {
        $user_id = $record->user_id;
        $today = current_time('Y-m-d');
        $usage_table = $wpdb->prefix . 'xb_aifusion_usage';
        $default_limit = absint(get_option('xb_aifusion_default_limit', 10));
        
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT usage_count, custom_limit 
                 FROM $usage_table 
                 WHERE user_id = %d AND usage_date = %s",
                $user_id, $today
            )
        );
        
        $usage_count = $row && $row->usage_count !== null ? absint($row->usage_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;
        $remaining = max(0, $user_limit - $usage_count);

        return new WP_REST_Response(array(
            'status' => 'success',
            'result_urls' => explode(',', $record->result_urls),
            'remaining' => $remaining,
            'limit' => $user_limit
        ), 200);
    } elseif ($record->creation_status === 'failed') {
        return new WP_REST_Response(array('message' => '暂时无法创作请联系客服'), 400);
    } else {
        return new WP_REST_Response(array('status' => 'pending'), 202);
    }
}

// 下载处理
function xb_aifusion_handle_download(WP_REST_Request $request) {
    $urls = $request->get_param('urls');
    $url_array = array_filter(array_map('trim', explode(',', $urls)));
    
    if (count($url_array) === 1) {
        // 单张图片直接下载
        $url = $url_array[0];
        $response = wp_remote_get($url, array('timeout' => 30, 'sslverify' => false));
        
        if (is_wp_error($response)) {
            return new WP_REST_Response(array('message' => '图片下载失败'), 400);
        }
        
        $body = wp_remote_retrieve_body($response);
        $content_type = wp_remote_retrieve_header($response, 'content-type');
        $filename = 'ai_fusion_' . time() . '.jpg';
        
        header('Content-Type: ' . $content_type);
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo $body;
        exit;
    } else {
        // 多张图片打包下载
        $zip = new ZipArchive();
        $zip_filename = tempnam(sys_get_temp_dir(), 'ai_fusion_') . '.zip';
        
        if ($zip->open($zip_filename, ZipArchive::CREATE) !== TRUE) {
            return new WP_REST_Response(array('message' => '无法创建压缩包'), 400);
        }
        
        foreach ($url_array as $index => $url) {
            $response = wp_remote_get($url, array('timeout' => 30, 'sslverify' => false));
            if (!is_wp_error($response)) {
                $body = wp_remote_retrieve_body($response);
                $zip->addFromString('ai_fusion_' . ($index + 1) . '.jpg', $body);
            }
        }
        
        $zip->close();
        
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="ai_fusion_images_' . time() . '.zip"');
        readfile($zip_filename);
        unlink($zip_filename);
        exit;
    }
}

// AJAX 上传功能
add_action('wp_ajax_xb_aifusion_upload', 'xb_aifusion_handle_ajax_upload');
add_action('wp_ajax_nopriv_xb_aifusion_upload', 'xb_aifusion_handle_ajax_upload');
function xb_aifusion_handle_ajax_upload() {
    check_ajax_referer('xb_aifusion_upload_nonce', '_wpnonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => '请先登录后使用'));
    }

    if (!isset($_FILES['files']) || empty($_FILES['files']['name'][0])) {
        wp_send_json_error(array('message' => '未选择文件，请选择文件后重试！'));
    }

    $max_file_size = absint(get_option('xb_aifusion_max_file_size', 10)) * 1024 * 1024;
    $max_upload_count = absint(get_option('xb_aifusion_max_upload_count', 6));
    $allowed_formats = array_map('strtolower', array_map('trim', explode(',', get_option('xb_aifusion_allowed_formats', 'JPG,JPEG,PNG,BMP,TIFF,WEBP'))));
    
    $files = $_FILES['files'];
    $file_count = count($files['name']);
    
    if ($file_count > $max_upload_count) {
        wp_send_json_error(array('message' => '最多只能上传' . $max_upload_count . '张图片！'));
    }
    
    $uploaded_urls = array();
    
    for ($i = 0; $i < $file_count; $i++) {
        if ($files['error'][$i] !== UPLOAD_ERR_OK) {
            continue;
        }
        
        $file_ext = strtolower(pathinfo($files['name'][$i], PATHINFO_EXTENSION));
        if (!in_array($file_ext, $allowed_formats)) {
            wp_send_json_error(array('message' => '不支持的文件格式！支持格式：' . implode(', ', $allowed_formats)));
        }
        
        if ($files['size'][$i] > $max_file_size) {
            wp_send_json_error(array('message' => '文件大小超出限制！'));
        }
        
        $file_type = wp_check_filetype_and_ext($files['tmp_name'][$i], $files['name'][$i]);
        if (!$file_type['ext'] || !in_array(strtolower($file_type['ext']), $allowed_formats)) {
            wp_send_json_error(array('message' => '文件类型验证失败，请上传真实的图片文件！'));
        }
        
        // 创建临时文件数组用于media_handle_upload
        $_FILES['upload_file'] = array(
            'name' => $files['name'][$i],
            'type' => $files['type'][$i],
            'tmp_name' => $files['tmp_name'][$i],
            'error' => $files['error'][$i],
            'size' => $files['size'][$i]
        );
        
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        $attachment_id = media_handle_upload('upload_file', 0);
        if (is_wp_error($attachment_id)) {
            wp_send_json_error(array('message' => '文件上传失败：' . $attachment_id->get_error_message()));
        }
        
        $uploaded_urls[] = wp_get_attachment_url($attachment_id);
    }
    
    wp_send_json_success(array('urls' => $uploaded_urls));
}
?>