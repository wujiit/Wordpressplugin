<?php
// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 添加管理菜单
add_action('admin_menu', 'xb_aifusion_admin_menu');
function xb_aifusion_admin_menu() {
    add_menu_page(
        'AI图像融合创作设置',
        'AI图像融合创作',
        'manage_options',
        'xb_aifusion_settings',
        'xb_aifusion_settings_page',
        'dashicons-format-image',
        80
    );
    add_submenu_page(
        'xb_aifusion_settings',
        '创作记录',
        '创作记录',
        'manage_options',
        'xb_aifusion_records',
        'xb_aifusion_records_page'
    );
    add_submenu_page(
        'xb_aifusion_settings',
        '预设风格管理',
        '预设风格管理',
        'manage_options',
        'xb_aifusion_styles',
        'xb_aifusion_styles_page'
    );
    add_submenu_page(
        'xb_aifusion_settings',
        '示例演示管理',
        '示例演示管理',
        'manage_options',
        'xb_aifusion_demos',
        'xb_aifusion_demos_page'
    );
}

// 插件设置页面
function xb_aifusion_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['xb_aifusion_save_settings'])) {
        check_admin_referer('xb_aifusion_settings_nonce');
        update_option('xb_aifusion_api_url', sanitize_text_field($_POST['xb_aifusion_api_url']));
        update_option('xb_aifusion_api_key', sanitize_text_field($_POST['xb_aifusion_api_key']));
        update_option('xb_aifusion_ai_models', sanitize_text_field($_POST['xb_aifusion_ai_models']));
        $new_limit = absint($_POST['xb_aifusion_default_limit']);
        if ($new_limit > 0) {
            update_option('xb_aifusion_default_limit', $new_limit);
        }
        $new_max_file_size = absint($_POST['xb_aifusion_max_file_size']);
        if ($new_max_file_size > 0) {
            update_option('xb_aifusion_max_file_size', $new_max_file_size);
        }
        $new_max_upload_count = absint($_POST['xb_aifusion_max_upload_count']);
        if ($new_max_upload_count > 0) {
            update_option('xb_aifusion_max_upload_count', $new_max_upload_count);
        }
        update_option('xb_aifusion_show_stats', isset($_POST['xb_aifusion_show_stats']) ? 1 : 0);
        update_option('xb_aifusion_show_model_select', isset($_POST['xb_aifusion_show_model_select']) ? 1 : 0);
        update_option('xb_aifusion_allow_text_only', isset($_POST['xb_aifusion_allow_text_only']) ? 1 : 0);
        update_option('xb_aifusion_allowed_formats', sanitize_text_field($_POST['xb_aifusion_allowed_formats']));
        update_option('xb_aifusion_image_sizes', sanitize_text_field($_POST['xb_aifusion_image_sizes']));
        update_option('xb_aifusion_image_resolutions', sanitize_text_field($_POST['xb_aifusion_image_resolutions']));
        update_option('xb_aifusion_image_counts', sanitize_text_field($_POST['xb_aifusion_image_counts']));
        update_option('xb_aifusion_banned_words', sanitize_textarea_field($_POST['xb_aifusion_banned_words']));
        $allowed_html = array(
            'a' => array('href' => array(), 'title' => array(), 'target' => array()),
            'img' => array('src' => array(), 'alt' => array(), 'width' => array(), 'height' => array()),
            'p' => array(),
            'div' => array('class' => array(), 'style' => array()),
            'span' => array('class' => array(), 'style' => array()),
            'strong' => array(),
            'em' => array(),
            'br' => array()
        );
        update_option('xb_aifusion_ad_content', wp_kses($_POST['xb_aifusion_ad_content'], $allowed_html));
        echo '<div class="updated xb_aifusion_auto_hide_message"><p>设置已保存！</p></div>';
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aifusion_records';
    $stats = array(
        'total_creations' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table"),
        'success_creations' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE creation_status = 'success'"),
        'failed_creations' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE creation_status = 'failed'"),
        'today_creations' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE DATE(creation_time) = %s", current_time('Y-m-d')))
    );

    ?>
    <div class="wrap">
        <h1>AI图像融合创作设置</h1>
        <form method="post">
            <?php wp_nonce_field('xb_aifusion_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_aifusion_api_url">API 接口地址</label></th>
                    <td><input type="text" name="xb_aifusion_api_url" id="xb_aifusion_api_url" value="<?php echo esc_attr(get_option('xb_aifusion_api_url', 'https://ark.cn-beijing.volces.com/api/v3/images/generations')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_api_key">API 密钥</label></th>
                    <td><input type="text" name="xb_aifusion_api_key" id="xb_aifusion_api_key" value="<?php echo esc_attr(get_option('xb_aifusion_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_ai_models">AI模型</label></th>
                    <td>
                        <input type="text" name="xb_aifusion_ai_models" id="xb_aifusion_ai_models" value="<?php echo esc_attr(get_option('xb_aifusion_ai_models', 'doubao-seedream-4-0-250828,doubao-seedream-3-0-250728')); ?>" class="regular-text">
                        <p class="description">多个模型用英文逗号分隔，例如：doubao-seedream-4-0-250828,doubao-seedream-3-0-250728</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_default_limit">每日创作次数</label></th>
                    <td><input type="number" name="xb_aifusion_default_limit" id="xb_aifusion_default_limit" value="<?php echo esc_attr(get_option('xb_aifusion_default_limit', 10)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_max_file_size">最大文件大小(MB)</label></th>
                    <td><input type="number" name="xb_aifusion_max_file_size" id="xb_aifusion_max_file_size" value="<?php echo esc_attr(get_option('xb_aifusion_max_file_size', 10)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_max_upload_count">最多上传图片数量</label></th>
                    <td><input type="number" name="xb_aifusion_max_upload_count" id="xb_aifusion_max_upload_count" value="<?php echo esc_attr(get_option('xb_aifusion_max_upload_count', 6)); ?>" min="1" max="10"></td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_allowed_formats">支持的图片格式</label></th>
                    <td>
                        <input type="text" name="xb_aifusion_allowed_formats" id="xb_aifusion_allowed_formats" value="<?php echo esc_attr(get_option('xb_aifusion_allowed_formats', 'JPG,JPEG,PNG,BMP,TIFF,WEBP')); ?>" class="regular-text">
                        <p class="description">多个格式用英文逗号分隔，例如：JPG,JPEG,PNG,BMP,TIFF,WEBP</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_image_sizes">生成图片尺寸</label></th>
                    <td>
                        <input type="text" name="xb_aifusion_image_sizes" id="xb_aifusion_image_sizes" value="<?php echo esc_attr(get_option('xb_aifusion_image_sizes', '2048x2048,2304x1728,1728x2304')); ?>" class="regular-text">
                        <p class="description">多个尺寸用英文逗号分隔，例如：2048x2048,2304x1728,1728x2304</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_image_resolutions">生成图片分辨率</label></th>
                    <td>
                        <input type="text" name="xb_aifusion_image_resolutions" id="xb_aifusion_image_resolutions" value="<?php echo esc_attr(get_option('xb_aifusion_image_resolutions', '1K,2K,4K')); ?>" class="regular-text">
                        <p class="description">多个分辨率用英文逗号分隔，例如：1K,2K,4K</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_image_counts">生成图片数量</label></th>
                    <td>
                        <input type="text" name="xb_aifusion_image_counts" id="xb_aifusion_image_counts" value="<?php echo esc_attr(get_option('xb_aifusion_image_counts', '1,3,6,9')); ?>" class="regular-text">
                        <p class="description">多个数量用英文逗号分隔，例如：1,3,6,9</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_show_stats">显示统计</label></th>
                    <td><input type="checkbox" name="xb_aifusion_show_stats" id="xb_aifusion_show_stats" <?php checked(get_option('xb_aifusion_show_stats', 1), 1); ?> value="1"> 显示剩余创作次数</td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_show_model_select">前台模型选择</label></th>
                    <td><input type="checkbox" name="xb_aifusion_show_model_select" id="xb_aifusion_show_model_select" <?php checked(get_option('xb_aifusion_show_model_select', 0), 1); ?> value="1"> 启用前台模型选择功能</td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_allow_text_only">允许纯文字生成</label></th>
                    <td><input type="checkbox" name="xb_aifusion_allow_text_only" id="xb_aifusion_allow_text_only" <?php checked(get_option('xb_aifusion_allow_text_only', 0), 1); ?> value="1"> 允许用户不上传图片直接生成</td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_banned_words">违规词设置</label></th>
                    <td>
                        <textarea name="xb_aifusion_banned_words" id="xb_aifusion_banned_words" rows="3" class="large-text"><?php echo esc_textarea(get_option('xb_aifusion_banned_words')); ?></textarea>
                        <p class="description">多个违规词用英文逗号分隔</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aifusion_ad_content">公告内容</label></th>
                    <td>
                        <textarea name="xb_aifusion_ad_content" id="xb_aifusion_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_aifusion_ad_content')); ?></textarea>
                        <p class="description">支持 HTML 格式。</p>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="xb_aifusion_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        <div class="xb_aifusion_stats">
            <p>总创作次数：<?php echo esc_html($stats['total_creations'] ?: 0); ?></p>
            <p>成功创作次数：<?php echo esc_html($stats['success_creations'] ?: 0); ?></p>
            <p>失败创作次数：<?php echo esc_html($stats['failed_creations'] ?: 0); ?></p>
            <p>今日创作次数：<?php echo esc_html($stats['today_creations'] ?: 0); ?></p>
        </div>
    </div>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aifusion_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}

// 创作记录页面
function xb_aifusion_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aifusion_records';
    $usage_table = $wpdb->prefix . 'xb_aifusion_usage';
    $user_id = isset($_POST['xb_aifusion_user_id']) ? absint($_POST['xb_aifusion_user_id']) : '';
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    // 处理各种操作
    if (isset($_POST['xb_aifusion_delete_all_global'])) {
        check_admin_referer('xb_aifusion_delete_all_global_nonce');
        $wpdb->query("TRUNCATE TABLE $records_table");
        echo '<div class="updated xb_aifusion_auto_hide_message"><p>所有记录已删除！</p></div>';
    }

    if (isset($_POST['xb_aifusion_reset_all_usage'])) {
        check_admin_referer('xb_aifusion_reset_all_usage_nonce');
        $wpdb->query("TRUNCATE TABLE $usage_table");
        echo '<div class="updated xb_aifusion_auto_hide_message"><p>所有用户使用次数已重置！</p></div>';
    }

    if (isset($_POST['xb_aifusion_delete_record']) && isset($_POST['record_id'])) {
        check_admin_referer('xb_aifusion_delete_record_nonce');
        $wpdb->delete($records_table, array('id' => absint($_POST['record_id'])), array('%d'));
        echo '<div class="updated xb_aifusion_auto_hide_message"><p>记录已删除！</p></div>';
    }

    if (isset($_POST['xb_aifusion_delete_all_records']) && $user_id) {
        check_admin_referer('xb_aifusion_delete_all_records_nonce');
        $wpdb->delete($records_table, array('user_id' => $user_id), array('%d'));
        echo '<div class="updated xb_aifusion_auto_hide_message"><p>用户记录已删除！</p></div>';
    }

    if (isset($_POST['xb_aifusion_reset_user_usage']) && $user_id) {
        check_admin_referer('xb_aifusion_reset_user_usage_nonce');
        $wpdb->delete($usage_table, array('user_id' => $user_id), array('%d'));
        echo '<div class="updated xb_aifusion_auto_hide_message"><p>用户使用次数已重置！</p></div>';
    }

    if (isset($_POST['xb_aifusion_save_user_limit']) && $user_id) {
        check_admin_referer('xb_aifusion_user_limit_nonce');
        $custom_limit = isset($_POST['xb_aifusion_custom_limit']) ? absint($_POST['xb_aifusion_custom_limit']) : null;
        
        $existing = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id FROM $usage_table WHERE user_id = %d AND usage_date = %s LIMIT 1",
                $user_id, current_time('Y-m-d')
            )
        );
        
        if ($existing) {
            $wpdb->update(
                $usage_table,
                array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
                array('user_id' => $user_id, 'usage_date' => current_time('Y-m-d')),
                array('%d'),
                array('%d', '%s')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'usage_date' => current_time('Y-m-d'),
                    'usage_count' => 0,
                    'custom_limit' => $custom_limit === 0 ? null : $custom_limit,
                )
            );
        }
        echo '<div class="updated xb_aifusion_auto_hide_message"><p>用户创作限制已更新！</p></div>';
    }

    // 获取统计数据和记录
    $default_limit = absint(get_option('xb_aifusion_default_limit', 10));
    $user_limit = $default_limit;
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT custom_limit 
                 FROM $usage_table 
                 WHERE user_id = %d AND usage_date = %s",
                $user_id, current_time('Y-m-d')
            )
        );
        if ($row && $row->custom_limit !== null) {
            $user_limit = absint($row->custom_limit);
        }
    }

    if ($user_id) {
        $stats = array(
            'total_creations' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE user_id = %d", $user_id)),
            'success_creations' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE user_id = %d AND creation_status = 'success'", $user_id)),
            'failed_creations' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE user_id = %d AND creation_status = 'failed'", $user_id)),
            'today_creations' => $wpdb->get_var($wpdb->prepare("SELECT usage_count FROM $usage_table WHERE user_id = %d AND usage_date = %s", $user_id, current_time('Y-m-d')))
        );
    } else {
        $stats = array(
            'total_creations' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table"),
            'success_creations' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE creation_status = 'success'"),
            'failed_creations' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE creation_status = 'failed'"),
            'today_creations' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE DATE(creation_time) = %s", current_time('Y-m-d')))
        );
    }

    $offset = ($paged - 1) * $per_page;
    if ($user_id) {
        $records = $wpdb->get_results($wpdb->prepare("SELECT * FROM $records_table WHERE user_id = %d ORDER BY creation_time DESC LIMIT %d, %d", $user_id, $offset, $per_page));
        $total_records = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE user_id = %d", $user_id));
    } else {
        $records = $wpdb->get_results($wpdb->prepare("SELECT * FROM $records_table ORDER BY creation_time DESC LIMIT %d, %d", $offset, $per_page));
        $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $records_table");
    }
    
    $total_pages = ceil($total_records / $per_page);

    $user_info = $user_id ? get_userdata($user_id) : null;
    $user_display = $user_id ? ($user_info ? $user_info->user_login : '未知用户') : '所有用户';
    ?>
    <div class="wrap">
        <h1>创作记录管理</h1>
        <div style="margin-bottom: 20px;">
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('xb_aifusion_delete_all_global_nonce'); ?>
                <input type="submit" name="xb_aifusion_delete_all_global" class="button-secondary" value="一键删除所有记录" onclick="return confirm('确定删除所有记录吗？这不会重置用户使用次数。');">
            </form>
            <form method="post" style="display:inline; margin-left: 10px;">
                <?php wp_nonce_field('xb_aifusion_reset_all_usage_nonce'); ?>
                <input type="submit" name="xb_aifusion_reset_all_usage" class="button-secondary" value="一键重置所有使用次数" onclick="return confirm('确定重置所有用户的使用次数吗？');">
            </form>
        </div>
        <form method="post">
            <p>
                <label for="xb_aifusion_user_id">用户 ID（留空显示所有记录）：</label>
                <input type="number" name="xb_aifusion_user_id" id="xb_aifusion_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <?php if ($user_id): ?>
            <h2>用户：<?php echo esc_html($user_display); ?> (ID: <?php echo $user_id; ?>)</h2>
            <p>每日创作次数：<?php echo esc_html($user_limit); ?> 次</p>
            <form method="post">
                <?php wp_nonce_field('xb_aifusion_user_limit_nonce'); ?>
                <p>
                    <label for="xb_aifusion_custom_limit">自定义每日创作次数（0 表示默认值）：</label>
                    <input type="number" name="xb_aifusion_custom_limit" id="xb_aifusion_custom_limit" min="0">
                    <input type="hidden" name="xb_aifusion_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_aifusion_save_user_limit" class="button-primary" value="保存">
                </p>
            </form>
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('xb_aifusion_delete_all_records_nonce'); ?>
                <input type="hidden" name="xb_aifusion_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" name="xb_aifusion_delete_all_records" class="button-secondary" value="删除当前用户记录" onclick="return confirm('确定删除当前用户所有记录吗？这不会重置使用次数。');">
            </form>
            <form method="post" style="display:inline; margin-left: 10px;">
                <?php wp_nonce_field('xb_aifusion_reset_user_usage_nonce'); ?>
                <input type="hidden" name="xb_aifusion_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" name="xb_aifusion_reset_user_usage" class="button-secondary" value="重置使用次数" onclick="return confirm('确定重置当前用户的使用次数吗？');">
            </form>
        <?php endif; ?>

        <div class="xb_aifusion_stats">
            <p>总创作次数：<?php echo esc_html($stats['total_creations'] ?: 0); ?></p>
            <p>成功创作次数：<?php echo esc_html($stats['success_creations'] ?: 0); ?></p>
            <p>失败创作次数：<?php echo esc_html($stats['failed_creations'] ?: 0); ?></p>
            <p>今日创作次数：<?php echo esc_html($stats['today_creations'] ?: 0); ?></p>
        </div>

        <table class="widefat">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>创作时间</th>
                    <th>原始图片</th>
                    <th>提示词</th>
                    <th>AI模型</th>
                    <th>状态</th>
                    <th>结果图片</th>
                    <th>错误信息</th>
                    <th>IP 地址</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="10">暂无创作记录。</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td><?php echo esc_html($record->user_id); ?></td>
                            <td><?php echo esc_html($record->creation_time); ?></td>
                            <td>
                                <?php if ($record->image_urls): ?>
                                    <?php $urls = explode(',', $record->image_urls); ?>
                                    <img src="<?php echo esc_url($urls[0]); ?>" style="width:50px;height:50px;object-fit:cover;" alt="原图">
                                    <?php if (count($urls) > 1): ?>
                                        <span>+<?php echo count($urls) - 1; ?></span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    纯文字
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html(mb_substr($record->prompt_text, 0, 50) . (mb_strlen($record->prompt_text) > 50 ? '...' : '')); ?></td>
                            <td><?php echo esc_html($record->ai_model ?: '-'); ?></td>
                            <td><?php echo esc_html($record->creation_status); ?></td>
                            <td>
                                <?php if ($record->result_urls): ?>
                                    <?php $result_urls = explode(',', $record->result_urls); ?>
                                    <img src="<?php echo esc_url($result_urls[0]); ?>" style="width:50px;height:50px;object-fit:cover;" alt="结果图">
                                    <?php if (count($result_urls) > 1): ?>
                                        <span>+<?php echo count($result_urls) - 1; ?></span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($record->error_message ?: '-'); ?></td>
                            <td><?php echo esc_html($record->ip_address); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_aifusion_delete_record_nonce'); ?>
                                    <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>">
                                    <input type="submit" name="xb_aifusion_delete_record" class="button-link" value="删除" onclick="return confirm('确定删除此记录？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aifusion_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}

// 预设风格管理页面
function xb_aifusion_styles_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $styles_table = $wpdb->prefix . 'xb_aifusion_styles';

    if (isset($_POST['xb_aifusion_add_style'])) {
        check_admin_referer('xb_aifusion_style_nonce');
        $style_title = sanitize_text_field($_POST['style_title']);
        $style_prompt = sanitize_textarea_field($_POST['style_prompt']);
        $style_image = sanitize_url($_POST['style_image']);
        $sort_order = absint($_POST['sort_order']);

        if (!empty($style_title) && !empty($style_prompt)) {
            $wpdb->insert(
                $styles_table,
                array(
                    'style_title' => $style_title,
                    'style_prompt' => $style_prompt,
                    'style_image' => $style_image,
                    'sort_order' => $sort_order,
                    'created_time' => current_time('mysql'),
                )
            );
            echo '<div class="updated xb_aifusion_auto_hide_message"><p>风格已添加！</p></div>';
        }
    }

    if (isset($_POST['xb_aifusion_update_style'])) {
        check_admin_referer('xb_aifusion_style_nonce');
        $style_id = absint($_POST['style_id']);
        $style_title = sanitize_text_field($_POST['style_title']);
        $style_prompt = sanitize_textarea_field($_POST['style_prompt']);
        $style_image = sanitize_url($_POST['style_image']);
        $sort_order = absint($_POST['sort_order']);

        if (!empty($style_title) && !empty($style_prompt)) {
            $wpdb->update(
                $styles_table,
                array(
                    'style_title' => $style_title,
                    'style_prompt' => $style_prompt,
                    'style_image' => $style_image,
                    'sort_order' => $sort_order,
                ),
                array('id' => $style_id),
                array('%s', '%s', '%s', '%d'),
                array('%d')
            );
            echo '<div class="updated xb_aifusion_auto_hide_message"><p>风格已更新！</p></div>';
        }
    }

    if (isset($_POST['xb_aifusion_delete_style'])) {
        check_admin_referer('xb_aifusion_delete_style_nonce');
        $style_id = absint($_POST['style_id']);
        $wpdb->delete($styles_table, array('id' => $style_id), array('%d'));
        echo '<div class="updated xb_aifusion_auto_hide_message"><p>风格已删除！</p></div>';
    }

    $styles = $wpdb->get_results("SELECT * FROM $styles_table ORDER BY sort_order DESC, id ASC");
    $edit_style = null;
    if (isset($_GET['edit']) && absint($_GET['edit'])) {
        $edit_style = $wpdb->get_row($wpdb->prepare("SELECT * FROM $styles_table WHERE id = %d", absint($_GET['edit'])));
    }
    ?>
    <div class="wrap">
        <h1>预设风格管理</h1>
        
        <h2><?php echo $edit_style ? '编辑风格' : '添加新风格'; ?></h2>
        <form method="post">
            <?php wp_nonce_field('xb_aifusion_style_nonce'); ?>
            <?php if ($edit_style): ?>
                <input type="hidden" name="style_id" value="<?php echo esc_attr($edit_style->id); ?>">
            <?php endif; ?>
            <table class="form-table">
                <tr>
                    <th><label for="style_title">风格标题</label></th>
                    <td><input type="text" name="style_title" id="style_title" value="<?php echo $edit_style ? esc_attr($edit_style->style_title) : ''; ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="style_prompt">风格提示词</label></th>
                    <td><textarea name="style_prompt" id="style_prompt" rows="3" class="large-text" required><?php echo $edit_style ? esc_textarea($edit_style->style_prompt) : ''; ?></textarea></td>
                </tr>
                <tr>
                    <th><label for="style_image">风格示例图</label></th>
                    <td><input type="url" name="style_image" id="style_image" value="<?php echo $edit_style ? esc_url($edit_style->style_image) : ''; ?>" class="regular-text" placeholder="图片链接（可选）"></td>
                </tr>
                <tr>
                    <th><label for="sort_order">排序</label></th>
                    <td><input type="number" name="sort_order" id="sort_order" value="<?php echo $edit_style ? esc_attr($edit_style->sort_order) : '0'; ?>" min="0"></td>
                </tr>
            </table>
            <p>
                <input type="submit" name="<?php echo $edit_style ? 'xb_aifusion_update_style' : 'xb_aifusion_add_style'; ?>" class="button-primary" value="<?php echo $edit_style ? '更新风格' : '添加风格'; ?>">
                <?php if ($edit_style): ?>
                    <a href="<?php echo admin_url('admin.php?page=xb_aifusion_styles'); ?>" class="button">取消编辑</a>
                <?php endif; ?>
            </p>
        </form>

        <h2>已有风格</h2>
        <table class="widefat">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>风格标题</th>
                    <th>风格提示词</th>
                    <th>示例图</th>
                    <th>排序</th>
                    <th>创建时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($styles)): ?>
                    <tr><td colspan="7">暂无风格。</td></tr>
                <?php else: ?>
                    <?php foreach ($styles as $style): ?>
                        <tr>
                            <td><?php echo esc_html($style->id); ?></td>
                            <td><?php echo esc_html($style->style_title); ?></td>
                            <td><?php echo esc_html(mb_substr($style->style_prompt, 0, 50) . (mb_strlen($style->style_prompt) > 50 ? '...' : '')); ?></td>
                            <td>
                                <?php if ($style->style_image): ?>
                                    <img src="<?php echo esc_url($style->style_image); ?>" style="width:50px;height:50px;object-fit:cover;" alt="示例图">
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($style->sort_order); ?></td>
                            <td><?php echo esc_html($style->created_time); ?></td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=xb_aifusion_styles&edit=' . $style->id); ?>" class="button-small">编辑</a>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_aifusion_delete_style_nonce'); ?>
                                    <input type="hidden" name="style_id" value="<?php echo esc_attr($style->id); ?>">
                                    <input type="submit" name="xb_aifusion_delete_style" class="button-small" value="删除" onclick="return confirm('确定删除此风格？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aifusion_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}

// 示例演示管理页面
function xb_aifusion_demos_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $demos_table = $wpdb->prefix . 'xb_aifusion_demos';

    if (isset($_POST['xb_aifusion_add_demo'])) {
        check_admin_referer('xb_aifusion_demo_nonce');
        $demo_title = sanitize_text_field($_POST['demo_title']);
        $original_image = sanitize_url($_POST['original_image']);
        $result_image = sanitize_url($_POST['result_image']);
        $sort_order = absint($_POST['sort_order']);

        if (!empty($demo_title) && !empty($original_image) && !empty($result_image)) {
            $wpdb->insert(
                $demos_table,
                array(
                    'demo_title' => $demo_title,
                    'original_image' => $original_image,
                    'result_image' => $result_image,
                    'sort_order' => $sort_order,
                    'created_time' => current_time('mysql'),
                )
            );
            echo '<div class="updated xb_aifusion_auto_hide_message"><p>演示已添加！</p></div>';
        }
    }

    if (isset($_POST['xb_aifusion_update_demo'])) {
        check_admin_referer('xb_aifusion_demo_nonce');
        $demo_id = absint($_POST['demo_id']);
        $demo_title = sanitize_text_field($_POST['demo_title']);
        $original_image = sanitize_url($_POST['original_image']);
        $result_image = sanitize_url($_POST['result_image']);
        $sort_order = absint($_POST['sort_order']);

        if (!empty($demo_title) && !empty($original_image) && !empty($result_image)) {
            $wpdb->update(
                $demos_table,
                array(
                    'demo_title' => $demo_title,
                    'original_image' => $original_image,
                    'result_image' => $result_image,
                    'sort_order' => $sort_order,
                ),
                array('id' => $demo_id),
                array('%s', '%s', '%s', '%d'),
                array('%d')
            );
            echo '<div class="updated xb_aifusion_auto_hide_message"><p>演示已更新！</p></div>';
        }
    }

    if (isset($_POST['xb_aifusion_delete_demo'])) {
        check_admin_referer('xb_aifusion_delete_demo_nonce');
        $demo_id = absint($_POST['demo_id']);
        $wpdb->delete($demos_table, array('id' => $demo_id), array('%d'));
        echo '<div class="updated xb_aifusion_auto_hide_message"><p>演示已删除！</p></div>';
    }

    $demos = $wpdb->get_results("SELECT * FROM $demos_table ORDER BY sort_order DESC, id ASC");
    $edit_demo = null;
    if (isset($_GET['edit']) && absint($_GET['edit'])) {
        $edit_demo = $wpdb->get_row($wpdb->prepare("SELECT * FROM $demos_table WHERE id = %d", absint($_GET['edit'])));
    }
    ?>
    <div class="wrap">
        <h1>示例演示管理</h1>
        
        <h2><?php echo $edit_demo ? '编辑演示' : '添加新演示'; ?></h2>
        <form method="post">
            <?php wp_nonce_field('xb_aifusion_demo_nonce'); ?>
            <?php if ($edit_demo): ?>
                <input type="hidden" name="demo_id" value="<?php echo esc_attr($edit_demo->id); ?>">
            <?php endif; ?>
            <table class="form-table">
                <tr>
                    <th><label for="demo_title">演示标题</label></th>
                    <td><input type="text" name="demo_title" id="demo_title" value="<?php echo $edit_demo ? esc_attr($edit_demo->demo_title) : ''; ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="original_image">原始图片链接</label></th>
                    <td><input type="url" name="original_image" id="original_image" value="<?php echo $edit_demo ? esc_url($edit_demo->original_image) : ''; ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="result_image">转换后图片链接</label></th>
                    <td><input type="url" name="result_image" id="result_image" value="<?php echo $edit_demo ? esc_url($edit_demo->result_image) : ''; ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="sort_order">排序</label></th>
                    <td><input type="number" name="sort_order" id="sort_order" value="<?php echo $edit_demo ? esc_attr($edit_demo->sort_order) : '0'; ?>" min="0"></td>
                </tr>
            </table>
            <p>
                <input type="submit" name="<?php echo $edit_demo ? 'xb_aifusion_update_demo' : 'xb_aifusion_add_demo'; ?>" class="button-primary" value="<?php echo $edit_demo ? '更新演示' : '添加演示'; ?>">
                <?php if ($edit_demo): ?>
                    <a href="<?php echo admin_url('admin.php?page=xb_aifusion_demos'); ?>" class="button">取消编辑</a>
                <?php endif; ?>
            </p>
        </form>

        <h2>已有演示</h2>
        <table class="widefat">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>演示标题</th>
                    <th>原始图片</th>
                    <th>转换后图片</th>
                    <th>排序</th>
                    <th>创建时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($demos)): ?>
                    <tr><td colspan="7">暂无演示。</td></tr>
                <?php else: ?>
                    <?php foreach ($demos as $demo): ?>
                        <tr>
                            <td><?php echo esc_html($demo->id); ?></td>
                            <td><?php echo esc_html($demo->demo_title); ?></td>
                            <td>
                                <img src="<?php echo esc_url($demo->original_image); ?>" style="width:50px;height:50px;object-fit:cover;" alt="原图">
                            </td>
                            <td>
                                <img src="<?php echo esc_url($demo->result_image); ?>" style="width:50px;height:50px;object-fit:cover;" alt="转换图">
                            </td>
                            <td><?php echo esc_html($demo->sort_order); ?></td>
                            <td><?php echo esc_html($demo->created_time); ?></td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=xb_aifusion_demos&edit=' . $demo->id); ?>" class="button-small">编辑</a>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_aifusion_delete_demo_nonce'); ?>
                                    <input type="hidden" name="demo_id" value="<?php echo esc_attr($demo->id); ?>">
                                    <input type="submit" name="xb_aifusion_delete_demo" class="button-small" value="删除" onclick="return confirm('确定删除此演示？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aifusion_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}

// 包含管理页面
require_once plugin_dir_path(__FILE__) . 'xb-aifusion-admin.php';
?>