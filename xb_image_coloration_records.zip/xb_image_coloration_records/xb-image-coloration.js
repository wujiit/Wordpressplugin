// xb-image-coloration.js
jQuery(document).ready(function($) {
    const $selectBtn = $('#xb_image_coloration_select');
    const $colorizeBtn = $('#xb_image_coloration_colorize');
    const $originalImg = $('#xb_image_coloration_original_img');
    const $coloredImg = $('#xb_image_coloration_colored_img');
    const $message = $('#xb_image_coloration_message');
    const $originalPlaceholder = $('.xb_image_coloration_original .image-placeholder');
    const $coloredPlaceholder = $('.xb_image_coloration_colored .image-placeholder');
    const $coloringMessage = $('#xb_coloring_message');
    const $remainingCount = $('#xb_remaining_count');
    const $loginBtn = $('.xb-login-btn');
    const $downloadBtn = $('#xb_download_btn');
    const $downloadContainer = $('#xb_download_container');

    // 显示消息提示（仅用于错误情况）
    function showMessage(text, type = 'error') {
        $message.text(text)
            .removeClass()
            .addClass('xb_image_coloration_message xb_image_coloration_' + type)
            .fadeIn();
        setTimeout(() => $message.fadeOut(), 3000);
    }

    // 点击选择图片按钮
    $selectBtn.on('click', function() {
        const input = document.createElement('input');
        input.type = 'file';
        // 使用后台设置的支持格式作为文件选择器的accept属性
        input.accept = xb_image_coloration_vars.accept_string;

        input.onchange = function(e) {
            const file = e.target.files[0];
            if (!file) return;

            // 前端验证文件扩展名
            const fileExt = file.name.split('.').pop().toLowerCase();
            const allowedFormats = xb_image_coloration_vars.allowed_formats;

            if (!allowedFormats.includes(fileExt)) {
                showMessage('图片格式不支持，仅支持：' + allowedFormats.join(','), 'error');
                return;
            }

            // 前端验证文件是否为真实图片
            const reader = new FileReader();
            reader.onload = function(event) {
                const img = new Image();
                img.onload = function() {
                    // 文件是真实图片，继续上传
                    const formData = new FormData();
                    formData.append('file', file);

                    $.ajax({
                        url: xb_image_coloration_vars.ajax_url + '/upload',
                        method: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        headers: { 'X-WP-Nonce': xb_image_coloration_vars.nonce },
                        success: function(response) {
                            $originalImg.attr('src', response.url).show();
                            $originalPlaceholder.hide();
                            $coloredImg.hide();
                            $coloredPlaceholder.show();
                            $coloringMessage.hide();
                            $downloadContainer.hide();
                            $colorizeBtn.prop('disabled', false);
                        },
                        error: function(xhr) {
                            showMessage(xhr.responseJSON.message || '上传失败', 'error');
                        }
                    });
                };
                img.onerror = function() {
                    showMessage('文件不是真实的图片，请更换图片', 'error');
                };
                img.src = event.target.result;
            };
            reader.readAsDataURL(file);
        };
        input.click();
    });

    // 点击开始上色按钮
    $colorizeBtn.on('click', function() {
        $coloredPlaceholder.hide();
        $coloringMessage.show();
        $downloadContainer.hide();
        $colorizeBtn.prop('disabled', true);
        const url = $originalImg.attr('src');
        $.ajax({
            url: xb_image_coloration_vars.ajax_url + '/colorize',
            method: 'POST',
            data: JSON.stringify({ url: url }),
            contentType: 'application/json',
            headers: { 'X-WP-Nonce': xb_image_coloration_vars.nonce },
            success: function(response) {
                $coloredImg.attr('src', response.colored_url).show();
                $coloringMessage.hide();
                $downloadContainer.show();
                $remainingCount.text(response.remaining);
                $downloadBtn.data('ext', response.ext);
            },
            error: function(xhr) {
                $coloringMessage.hide();
                $coloredPlaceholder.show();
                $colorizeBtn.prop('disabled', false);
                showMessage(xhr.responseJSON.message || '上色失败', 'error');
            }
        });
    });

    // 下载按钮
    $downloadBtn.on('click', function() {
        const coloredUrl = $coloredImg.attr('src');
        const ext = $(this).data('ext');
        const randomName = 'colored_' + Math.random().toString(36).substr(2, 9) + '.' + ext;
        const link = document.createElement('a');
        link.href = coloredUrl;
        link.download = randomName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });

    // 登录按钮
    $loginBtn.on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = wp_login_url;
        }
    });
});