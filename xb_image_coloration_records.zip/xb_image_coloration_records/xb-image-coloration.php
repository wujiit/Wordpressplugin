<?php
/*
Plugin Name: 小半AI图像上色
Description: 基于百度云的黑白图像上色处理
Version: 1.0.1
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 创建数据表
function xb_image_coloration_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_image_coloration_records';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) NOT NULL,
        original_url VARCHAR(1024) NOT NULL,
        colored_url VARCHAR(1024) NOT NULL,
        color_time DATETIME NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// 创建前台页面
function xb_image_coloration_create_page() {
    $pages = get_posts([
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_image_coloration_shortcode]',
        'numberposts' => 1,
    ]);

    if (empty($pages)) {
        wp_insert_post([
            'post_title'   => '黑白图片上色',
            'post_name'    => 'black-white-image-coloration',
            'post_content' => '[xb_image_coloration_shortcode]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        ]);
    }
}

// 插件激活
register_activation_hook(__FILE__, 'xb_image_coloration_activate');
function xb_image_coloration_activate() {
    xb_image_coloration_create_table();
    xb_image_coloration_create_page();
}

// 加载前端脚本和样式，仅在包含短代码的页面加载
add_action('wp_enqueue_scripts', 'xb_image_coloration_enqueue_scripts');
function xb_image_coloration_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_image_coloration_shortcode')) {
        //wp_enqueue_script('xb_image_coloration_script', plugins_url('xb-image-coloration.js', __FILE__), ['jquery'], '1.5', true);
        //wp_enqueue_style('xb_image_coloration_style', plugins_url('xb-image-coloration.css', __FILE__), [], '1.5');

        wp_enqueue_script('xb_image_coloration_script', 'https://img.qiyucloud.com/cloud/xb_image_coloration_records/xb-image-coloration.js', ['jquery'], '1.0', true);
        wp_enqueue_style('xb_image_coloration_style', 'https://img.qiyucloud.com/cloud/xb_image_coloration_records/xb-image-coloration.css', [], '1.0');

        // 获取后台设置的支持格式
        $allowed_formats = explode(',', get_option('xb_image_coloration_formats', 'jpg,png'));
        $accept_string = implode(',', array_map(function($ext) { return '.' . trim($ext); }, $allowed_formats));

        wp_localize_script('xb_image_coloration_script', 'xb_image_coloration_vars', [
            'ajax_url' => rest_url('xb_image_coloration/v1'),
            'nonce'    => wp_create_nonce('wp_rest'),
            'allowed_formats' => $allowed_formats,  // 传递支持的格式给前端
            'accept_string'   => $accept_string     // 传递文件选择器的accept属性值
        ]);
    }
}

// 添加后台菜单
add_action('admin_menu', 'xb_image_coloration_admin_menu');
function xb_image_coloration_admin_menu() {
    add_menu_page(
        '图片上色',
        '图片上色',
        'manage_options',
        'xb-image-coloration-settings',
        'xb_image_coloration_settings_page',
        'dashicons-images-alt2'
    );
    add_submenu_page(
        'xb-image-coloration-settings',
        '上色记录',
        '上色记录',
        'manage_options',
        'xb-image-coloration-records',
        'xb_image_coloration_records_page'
    );
}

// 设置页面
function xb_image_coloration_settings_page() {
    if (isset($_POST['xb_image_coloration_save_settings'])) {
        check_admin_referer('xb_image_coloration_settings');
        update_option('xb_image_coloration_apikey', sanitize_text_field($_POST['xb_image_coloration_apikey']));
        update_option('xb_image_coloration_formats', sanitize_text_field($_POST['xb_image_coloration_formats']));
        update_option('xb_image_coloration_max_size', intval($_POST['xb_image_coloration_max_size']));
        update_option('xb_image_coloration_daily_limit', intval($_POST['xb_image_coloration_daily_limit']));
        update_option('xb_image_coloration_notice', wp_kses_post($_POST['xb_image_coloration_notice']));
        echo '<div class="updated"><p>设置已保存。</p></div>';
    }
    ?>
    <div class="wrap">
        <div class="xb-title">图片上色设置</div>
        <form method="post" action="">
            <?php wp_nonce_field('xb_image_coloration_settings'); ?>
            <table class="form-table">
                <tr>
                    <th>百度云 API Key</th>
                    <td><input type="text" name="xb_image_coloration_apikey" value="<?php echo esc_attr(get_option('xb_image_coloration_apikey')); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th>支持的图片格式</th>
                    <td><input type="text" name="xb_image_coloration_formats" value="<?php echo esc_attr(get_option('xb_image_coloration_formats', 'jpg,png')); ?>" class="regular-text" placeholder="jpg,png" /><p class="description">用逗号分隔，例如：jpg,png</p></td>
                </tr>
                <tr>
                    <th>最大文件大小 (MB)</th>
                    <td><input type="number" name="xb_image_coloration_max_size" value="<?php echo esc_attr(get_option('xb_image_coloration_max_size', 5)); ?>" min="1" /></td>
                </tr>
                <tr>
                    <th>每日默认使用次数限制</th>
                    <td><input type="number" name="xb_image_coloration_daily_limit" value="<?php echo esc_attr(get_option('xb_image_coloration_daily_limit', 10)); ?>" min="1" /></td>
                </tr>
                <tr>
                    <th>公告内容</th>
                    <td><textarea name="xb_image_coloration_notice" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_image_coloration_notice')); ?></textarea></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="xb_image_coloration_save_settings" class="button-primary" value="保存设置" /></p>
        </form>
        由百度云提供：https://cloud.baidu.com/doc/IMAGEPROCESS/s/Nk3bclmag <br>
        单价：低于300是0.01元，超过是0.006元
    </div>
    <?php
}

// 用户上色记录页面（用户限额设置）
function xb_image_coloration_records_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_image_coloration_records';
    $total_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $user_id_filter = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

    // 处理删除记录
    if (isset($_GET['delete_id'])) {
        $wpdb->delete($table_name, ['id' => intval($_GET['delete_id'])], ['%d']);
        echo '<div class="updated"><p>记录已删除。</p></div>';
    }

    // 处理用户限额设置
    if (isset($_POST['xb_set_user_limit'])) {
        check_admin_referer('xb_user_limit');
        $user_id = intval($_POST['user_id']);
        $custom_limit = intval($_POST['custom_limit']);
        if ($custom_limit > 0) {
            update_user_meta($user_id, 'xb_image_coloration_custom_limit', $custom_limit);
            echo '<div class="updated"><p>用户限额已设置为 ' . $custom_limit . ' 次/天。</p></div>';
        }
    }

    // 处理恢复默认限额
    if (isset($_POST['xb_reset_user_limit'])) {
        check_admin_referer('xb_user_limit');
        $user_id = intval($_POST['user_id']);
        delete_user_meta($user_id, 'xb_image_coloration_custom_limit');
        echo '<div class="updated"><p>已恢复用户默认限额。</p></div>';
    }

    $where = $user_id_filter ? "WHERE user_id = $user_id_filter" : '';
    $records = $wpdb->get_results("SELECT * FROM $table_name $where ORDER BY color_time DESC LIMIT 50");
    $user_count = $user_id_filter ? $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE user_id = $user_id_filter") : 0;
    $today_count = $user_id_filter ? $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE user_id = $user_id_filter AND DATE(color_time) = CURDATE()") : 0;
    $default_limit = get_option('xb_image_coloration_daily_limit', 10);
    $custom_limit = $user_id_filter ? get_user_meta($user_id_filter, 'xb_image_coloration_custom_limit', true) : '';
    $user_limit = $custom_limit ? $custom_limit : $default_limit;

    ?>
    <div class="wrap">
        <div class="xb-title">用户上色记录</div>
        <p>网站总上色次数：<?php echo $total_count; ?></p>
        <form method="get" action="">
            <input type="hidden" name="page" value="xb-image-coloration-records" />
            <label>用户 ID: </label><input type="number" name="user_id" value="<?php echo $user_id_filter; ?>" />
            <input type="submit" class="button" value="查询" />
        </form>
        <?php if ($user_id_filter) { ?>
            <p>用户 <?php echo $user_id_filter; ?> 总上色次数：<?php echo $user_count; ?>，今日上色次数：<?php echo $today_count; ?>，当前限额：<?php echo $user_limit; ?> 次/天</p>
            <form method="post" action="">
                <?php wp_nonce_field('xb_user_limit'); ?>
                <input type="hidden" name="user_id" value="<?php echo $user_id_filter; ?>" />
                <label>设置每日限额: </label><input type="number" name="custom_limit" min="1" value="<?php echo $custom_limit ?: $default_limit; ?>" />
                <input type="submit" name="xb_set_user_limit" class="button" value="设置限额" />
                <input type="submit" name="xb_reset_user_limit" class="button" value="恢复默认" />
            </form>
        <?php } ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>用户名</th>
                    <th>原始图片</th>
                    <th>上色状态</th>
                    <th>上色时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record) { ?>
                    <tr>
                        <td><?php echo $record->user_id; ?></td>
                        <td><?php echo get_userdata($record->user_id)->user_login; ?></td>
                        <td><img src="<?php echo esc_url($record->original_url); ?>" width="100" height="100" /></td>
                        <td><?php echo $record->colored_url === 'colored' ? '已上色' : '未知'; ?></td>
                        <td><?php echo $record->color_time; ?></td>
                        <td><a href="?page=xb-image-coloration-records&delete_id=<?php echo $record->id; ?>" class="button">删除</a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <?php
}

// 前台短代码
add_shortcode('xb_image_coloration_shortcode', 'xb_image_coloration_shortcode');
function xb_image_coloration_shortcode() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_image_coloration_records';
    $user_id = get_current_user_id();
    $default_limit = get_option('xb_image_coloration_daily_limit', 10);
    $custom_limit = $user_id ? get_user_meta($user_id, 'xb_image_coloration_custom_limit', true) : '';
    $daily_limit = $custom_limit ? $custom_limit : $default_limit;
    $today_count = $user_id ? $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(color_time) = CURDATE()",
        $user_id
    )) : 0;

    ob_start();
    ?>
    <div class="xb_image_coloration_container">
        <div class="xb-title">黑白图像AI上色</div>
        <?php if (!is_user_logged_in()) { ?>
            <div class="xb-login-notice">
                <p>请先登录以使用图片上色功能。</p>
                <button class="xb-login-btn wp-creative-login-btn">快速登录</button>
            </div>
        <?php } else { ?>
            <?php if ($today_count >= $daily_limit) { ?>
                <p class="xb_image_coloration_notice">您已达到今日上色次数限制（<?php echo $daily_limit; ?>次）。</p>
            <?php } else { ?>
                <div class="xb_image_coloration_buttons">
                    <button id="xb_image_coloration_select" class="xb_image_coloration_button">选择图片</button>
                    <button id="xb_image_coloration_colorize" class="xb_image_coloration_button" disabled>开始上色</button>
                </div>
                <div class="xb_image_coloration_preview">
                    <div class="xb_image_coloration_original">
                        <div class="xb-subtitle">原始图片</div>
                        <div class="image-placeholder">请上传图片</div>
                        <img id="xb_image_coloration_original_img" width="600" height="500" style="display: none;" />
                    </div>
                    <div class="xb_image_coloration_colored">
                        <div class="xb-subtitle">上色后的图片</div>
                        <div class="image-placeholder">上色结果将显示在此</div>
                        <div id="xb_coloring_message" class="xb-coloring-message" style="display: none;">正在上色中<span class="dots"></span></div>
                        <img id="xb_image_coloration_colored_img" width="600" height="500" style="display: none;" />
                        <div id="xb_download_container" class="xb-download-container" style="display: none;">
                            <button id="xb_download_btn" class="xb-download-btn">快速下载</button>
                        </div>
                    </div>
                </div>
                <div class="xb_image_coloration_status">
                    <p>今日剩余上色次数：<span id="xb_remaining_count"><?php echo $daily_limit - $today_count; ?></span>/<?php echo $daily_limit; ?></p>
                </div>
            <?php } ?>
        <?php } ?>
        <?php if ($notice = get_option('xb_image_coloration_notice')) { ?>
            <div class="xb_image_coloration_notice"><?php echo wp_kses_post($notice); ?></div>
        <?php } ?>
        <!-- 添加使用示例 -->
        <div class="xb_image_coloration_example">
            <div class="xb-subtitle">使用示例</div>
            <div class="xb_example_container">
                <div class="xb_example_original">
                    <div class="xb_example_label">原始黑白图</div>
                    <img src="https://aiimg.qiyucloud.com/htai/2025/04/20250408120113467.jpg" alt="原始黑白图" />
                </div>
                <div class="xb_example_colored">
                    <div class="xb_example_label">上色后效果</div>
                    <img src="https://aiimg.qiyucloud.com/htai/2025/04/20250408120113754.jpg" alt="上色后效果" />
                </div>
            </div>
        </div>
    </div>
    <div id="xb_image_coloration_message" class="xb_image_coloration_message"></div>
    <?php
    return ob_get_clean();
}

// REST API 注册
add_action('rest_api_init', 'xb_image_coloration_register_api');
function xb_image_coloration_register_api() {
    register_rest_route('xb_image_coloration/v1', '/upload', [
        'methods'  => 'POST',
        'callback' => 'xb_image_coloration_upload',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ]);
    register_rest_route('xb_image_coloration/v1', '/colorize', [
        'methods'  => 'POST',
        'callback' => 'xb_image_coloration_colorize',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ]);
}

// 文件上传处理函数 - 优化版
function xb_image_coloration_upload($request) {
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');

    $file = $_FILES['file'];
    $allowed_formats = explode(',', get_option('xb_image_coloration_formats', 'jpg,png'));
    $max_size = get_option('xb_image_coloration_max_size', 5) * 1024 * 1024;

    // 获取文件扩展名
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    // 第一步：检查文件扩展名是否在允许范围内
    if (!in_array($file_ext, $allowed_formats)) {
        return new WP_Error('invalid_format', '图片格式不支持，仅支持：' . implode(',', $allowed_formats), ['status' => 400]);
    }

    // 第二步：检查文件大小
    if ($file['size'] > $max_size) {
        return new WP_Error('file_too_large', '文件大小超出限制（最大 ' . get_option('xb_image_coloration_max_size', 5) . 'MB）', ['status' => 400]);
    }

    // 第三步：检测真实文件类型
    $file_type = exif_imagetype($file['tmp_name']);
    $mime_to_ext = [
        IMAGETYPE_JPEG => 'jpg',
        IMAGETYPE_PNG => 'png',
        IMAGETYPE_GIF => 'gif',
        IMAGETYPE_BMP => 'bmp'
    ];
    
    if ($file_type === false || !isset($mime_to_ext[$file_type])) {
        return new WP_Error('invalid_image', '文件不是真实的图片，请更换图片', ['status' => 400]);
    }

    // 第四步：验证文件扩展名与实际类型是否匹配
    $real_ext = $mime_to_ext[$file_type];
    if ($file_ext !== $real_ext) {
        return new WP_Error('mismatched_format', '文件扩展名与实际类型不匹配，请更换图片', ['status' => 400]);
    }

    // 文件上传
    $upload_overrides = ['test_form' => false];
    $file_return = wp_handle_upload($file, $upload_overrides);
    
    if (isset($file_return['error'])) {
        return new WP_Error('upload_error', $file_return['error'], ['status' => 500]);
    }

    $attachment = [
        'guid'           => $file_return['url'],
        'post_mime_type' => $file_return['type'],
        'post_title'     => sanitize_file_name($file['name']),
        'post_content'   => '',
        'post_status'    => 'inherit'
    ];
    
    $attach_id = wp_insert_attachment($attachment, $file_return['file']);
    $attach_data = wp_generate_attachment_metadata($attach_id, $file_return['file']);
    wp_update_attachment_metadata($attach_id, $attach_data);

    return ['url' => wp_get_attachment_url($attach_id)];
}

// 上色处理
function xb_image_coloration_colorize($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_image_coloration_records';
    $user_id = get_current_user_id();
    $default_limit = get_option('xb_image_coloration_daily_limit', 10);
    $custom_limit = get_user_meta($user_id, 'xb_image_coloration_custom_limit', true);
    $daily_limit = $custom_limit ? $custom_limit : $default_limit;
    $today_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(color_time) = CURDATE()",
        $user_id
    ));

    if ($today_count >= $daily_limit) {
        return new WP_Error('limit_exceeded', '已达到每日上色次数限制', ['status' => 403]);
    }

    $url = $request['url'];
    $apikey = get_option('xb_image_coloration_apikey');
    if (!$apikey) {
        return new WP_Error('no_apikey', '未配置百度云 API Key', ['status' => 500]);
    }

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://aip.baidubce.com/rest/2.0/image-process/v1/colourize",
        CURLOPT_TIMEOUT => 30,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => http_build_query(['url' => $url]),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/x-www-form-urlencoded',
            'Accept: application/json',
            'Authorization: Bearer ' . $apikey,
        ],
    ]);
    $response = curl_exec($curl);
    $error = curl_error($curl);
    curl_close($curl);

    if ($error) {
        return new WP_Error('curl_error', 'API 请求失败: ' . $error, ['status' => 500]);
    }

    $result = json_decode($response, true);
    if (!isset($result['image'])) {
        return new WP_Error('api_error', '上色失败: ' . ($result['error_msg'] ?? '未知错误'), ['status' => 500]);
    }

    $ext = strtolower(pathinfo($url, PATHINFO_EXTENSION));
    $prefix = $ext === 'png' ? 'data:image/png;base64,' : 'data:image/jpeg;base64,';
    $colored_base64 = $prefix . $result['image'];

    $wpdb->insert($table_name, [
        'user_id'      => $user_id,
        'original_url' => $url,
        'colored_url'  => 'colored',
        'color_time'   => current_time('mysql'),
    ], ['%d', '%s', '%s', '%s']);

    return [
        'colored_url' => $colored_base64,
        'remaining'   => $daily_limit - ($today_count + 1),
        'ext'         => $ext
    ];
}