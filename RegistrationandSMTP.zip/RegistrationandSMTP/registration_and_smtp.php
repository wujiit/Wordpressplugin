<?php
/*
Plugin Name: 注册协议与SMTP
Description: 注册免邮箱验证，也可以设置需要同意注册协议才能注册，支持添加SMTP邮件配置功能。
Plugin URI: https://www.jingxialai.com/4547.html
Version: 1.2
Author: Summer
Author URI: https://www.jingxialai.com/
License: GPL License
*/

if (!defined('ABSPATH')) {
    exit;
}

// 添加插件菜单
add_action('admin_menu', 'wp_cr_custom_registration_plugin_menu');
function wp_cr_custom_registration_plugin_menu() {
    add_options_page('注册协议验证与SMTP设置', '注册协议与SMTP', 'manage_options', 'registration-and-smtp-settings', 'wp_cr_custom_registration_plugin_settings_page');
}

// 设置链接回调函数
function wp_cr_smtp_settings_link($links) {
    $settings_link = '<a href="options-general.php?page=registration-and-smtp-settings">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}
// 设置入口
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wp_cr_smtp_settings_link');


// 添加样式和背景图片
add_action('admin_head', 'wp_cr_custom_registration_styles');
function wp_cr_custom_registration_styles() {
    if (isset($_GET['page']) && $_GET['page'] === 'registration-and-smtp-settings') {
        ?>
        <style>
            body {
                color: #333;
                background-color: #f5f5f5;
                margin: 0;
                padding: 0;
            }
            .wp_cr_wrap {
                max-width: 95%;
                margin: 10px auto;
                background-color: #fff;
                padding: 20px;
                border-radius: 5px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }
            .wp_cr_wrap input[type="text"],
            .wp_cr_wrap input[type="password"],
            .wp_cr_wrap textarea {
                width: 60%;
            }

            .custom-updated {
                background-color: #009933;
                color: white;
                padding: 5px 10px;
                margin-top: 10px;
                border-radius: 5px;
                text-align: center;
            }

            .custom-error {
                background-color: #f44336;
                color: white;
                padding: 5px 10px;
                margin-top: 10px;
                border-radius: 5px;
                text-align: center;
            }
        </style>
        <?php
    }
}



// 设置页面
function wp_cr_custom_registration_plugin_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('您无权限访问这个页面');
    }

    ?>
    <div class="wp_cr_wrap">
        <h2>注册协议验证设置</h2>
        <form method="post" action="options.php">
            <?php settings_fields('custom_registration_plugin_settings'); ?>
            <?php do_settings_sections('custom_registration_plugin_settings'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">注册协议标题</th>
                    <td><textarea name="registration_agreement_text" rows="1" cols="50"><?php echo get_option('registration_agreement_text'); ?></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row">注册协议URL</th>
                    <td><input type="text" name="registration_agreement_url" value="<?php echo get_option('registration_agreement_url'); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">注册页面背景图片</th>
                    <td>
                        <input type="text" name="registration_background_image" value="<?php echo esc_attr(get_option('registration_background_image', '')); ?>" /><br />
                        <small>输入图片链接</small>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">注册页面Logo图片</th>
                    <td>
                        <input type="text" name="registration_logo_image" value="<?php echo esc_attr(get_option('registration_logo_image', '')); ?>" /><br />
                        <small>输入图片链接</small>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">注册自定义内容提醒</th>
                    <td><textarea name="custom_registration_notice" rows="2" cols="50" placeholder="这个可以不用设置，支持单独显示，支持html代码"><?php echo get_option('custom_registration_notice'); ?></textarea></td></tr>

                <tr valign="top">
                    <th scope="row">注册成功跳转URL</th>
                    <td>
                        <input type="text" name="registration_success_redirect_url" value="<?php echo esc_url(get_option('registration_success_redirect_url', '')); ?>" />
                        <br />
                        <small>设置注册成功后跳转的URL，如果留空，则跳转到来源页面(可能不兼容第三方插件页面)。</small>
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row">启用注册验证</th>
                    <td><input type="checkbox" name="enable_registration_settings" value="1" <?php checked(get_option('enable_registration_settings'), 1); ?> /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
        注册协议、背景图片和Logo图片至少需要设置一个才能实现直接输入密码注册，图片不设置就显示默认的.<br>
        设置了注册协议标题就要填协议URL链接，否则同意协议的功能不生效.<br>
        一旦启用验证设置，注册的时候就可以直接输入密码且注册成功会自动登录.
    </div>
    
    <!-- 新增SMTP邮件配置功能 -->
    <div class="wp_cr_wrap">
        <h2>SMTP邮件配置</h2>
        <form method="post" action="">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">服务地址</th>
                    <td><input type="text" name="smtp_host" value="<?php echo esc_attr(get_option('smtp_host', '')); ?>" style="width: 200px;" /> 例如：smtp.qq.com</td>
                </tr>
                <tr valign="top">
                    <th scope="row">服务协议</th>
                    <td><input type="text" name="smtp_protocol" value="<?php echo esc_attr(get_option('smtp_protocol', '')); ?>" style="width: 200px;" /> 例如：ssl</td>
                </tr>
                <tr valign="top">
                    <th scope="row">服务端口</th>
                    <td><input type="text" name="smtp_port" value="<?php echo esc_attr(get_option('smtp_port', '')); ?>" style="width: 200px;" /> 例如：465</td>
                </tr>
                <tr valign="top">
                    <th scope="row">邮箱账号</th>
                    <td><input type="text" name="smtp_username" value="<?php echo esc_attr(get_option('smtp_username', '')); ?>"  style="width: 200px;" /></td>
                </tr>

                <tr valign="top">
                    <th scope="row">授权密码</th>
                    <td style="position: relative;">
                        <div style="position: relative; display: inline-block;">
                            <input type="password" name="smtp_password" id="smtp_password" value="<?php echo esc_attr(get_option('smtp_password', '')); ?>" style="width:200px; padding-right: 30px;" />
                            <span id="toggle_password" style="position: absolute; top: 50%; transform: translateY(-50%); cursor: pointer;"><span class="dashicons dashicons-hidden" aria-hidden="true"></span></span>
                        </div>
                        <span style="margin-left: 25px;">这个一般是SMTP邮件单独的授权密码</span>
                    </td>
                </tr>


                <tr valign="top">
                    <th scope="row">发送名称</th>
                    <td><input type="text" name="smtp_from_name" value="<?php echo esc_attr(get_option('smtp_from_name', '')); ?>" style="width: 200px;" /> 建议写网站名称</td>
                </tr>
                <tr valign="top">
                    <th scope="row">启用SMTP邮件</th>
                    <td><input type="checkbox" name="enable_smtp_mail" value="1" <?php checked(get_option('enable_smtp_mail'), 1); ?> /></td>
                </tr>
            </table>
            <input type="submit" name="save_smtp_settings" value="保存SMTP设置" class="button-primary" />
            <input type="submit" name="reset_smtp_settings" value="清空SMTP设置" class="button-secondary" onclick="return confirm('您确定要清空所有SMTP设置吗？');" />
        </form>

        <form method="post" action="">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">测试邮箱地址</th>
                    <td><input type="email" name="test_email" required /></td>
                </tr>
            </table>
            <input type="submit" name="test_smtp_email" value="发送测试邮件" class="button-primary" />
        </form>
        <p>开启SMTP邮件之后，用户就可以通过邮件找回密码等操作.</p>
    </div>

<!-- 显示授权密码 -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var passwordField = document.getElementById('smtp_password');
        var togglePassword = document.getElementById('toggle_password');
        
        togglePassword.addEventListener('click', function() {
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                togglePassword.innerHTML = '<span class="dashicons dashicons-visibility" aria-hidden="true"></span>';
            } else {
                passwordField.type = 'password';
                togglePassword.innerHTML = '<span class="dashicons dashicons-hidden" aria-hidden="true"></span>';
            }
        });
    });
</script>
<!-- 显示授权密码结束 -->

    <?php
}


// 保存SMTP邮件配置
add_action('admin_init', 'wp_cr_save_smtp_settings');
function wp_cr_save_smtp_settings() {
    if (isset($_POST['save_smtp_settings'])) {
        // 检查设置
        $smtp_host = $_POST['smtp_host'];
        $smtp_protocol = $_POST['smtp_protocol'];
        $smtp_port = $_POST['smtp_port'];
        $smtp_username = $_POST['smtp_username'];
        $smtp_password = $_POST['smtp_password'];
        $smtp_from_name = $_POST['smtp_from_name'];

        if (empty($smtp_host) || empty($smtp_protocol) || empty($smtp_port) || empty($smtp_username) || empty($smtp_password) || empty($smtp_from_name)) {
            //如果没有设置好的提醒
            echo '<div class="custom-error"><p>请先设置好所有SMTP邮件配置内容，然后才能保存。</p></div>';
            return;
        }

        // 全部设置内容
        update_option('smtp_host', $smtp_host);
        update_option('smtp_protocol', $smtp_protocol);
        update_option('smtp_port', $smtp_port);
        update_option('smtp_username', $smtp_username);
        update_option('smtp_password', $smtp_password);
        update_option('smtp_from_name', $smtp_from_name);
        update_option('enable_smtp_mail', isset($_POST['enable_smtp_mail']) ? 1 : 0);

        // 成功提醒
        echo '<div class="custom-updated"><p>SMTP设置已成功保存。</p></div>';
    }
}

//清空smtp设置
add_action('admin_init', 'wp_cr_reset_smtp_settings');
function wp_cr_reset_smtp_settings() {
    if (isset($_POST['reset_smtp_settings'])) {
        // 删除所有 SMTP 设置
        delete_option('smtp_host');
        delete_option('smtp_protocol');
        delete_option('smtp_port');
        delete_option('smtp_username');
        delete_option('smtp_password');
        delete_option('smtp_from_name');
        delete_option('enable_smtp_mail');

        // 成功提醒
        echo '<div class="custom-updated"><p>所有SMTP设置已成功清空。</p></div>';
    }
}


// 添加测试SMTP邮件功能
add_action('admin_init', 'wp_cr_test_smtp_email');
function wp_cr_test_smtp_email() {
    if (isset($_POST['test_smtp_email'])) {
        $to_email = sanitize_email($_POST['test_email']);
        $subject = 'SMTP邮件测试';
        $message = '这是一封测试邮件，如果您收到了该邮件，说明SMTP邮件配置正常。';
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        $result = wp_mail($to_email, $subject, $message, $headers);
        
        if ($result) {
            echo '<div class="custom-updated"><p>测试邮件已成功发送到 ' . $to_email . '</p></div>';
        } else {
            echo '<div class="custom-error"><p>无法发送测试邮件，请检查SMTP配置并重试，特别是授权密码。</p></div>';
        }
    }
}

// 注册协议设置
add_action('admin_init', 'wp_cr_custom_registration_plugin_settings');
function wp_cr_custom_registration_plugin_settings() {
    register_setting('custom_registration_plugin_settings', 'registration_agreement_text');
    register_setting('custom_registration_plugin_settings', 'registration_agreement_url');
    register_setting('custom_registration_plugin_settings', 'registration_background_image');
    register_setting('custom_registration_plugin_settings', 'registration_logo_image');
    register_setting('custom_registration_plugin_settings', 'enable_registration_settings', 'wp_cr_validate_registration_settings');
    register_setting('custom_registration_plugin_settings', 'custom_registration_notice');
    register_setting('custom_registration_plugin_settings', 'registration_success_redirect_url');
}

// 验证注册设置是否至少有一个设置了内容
function wp_cr_validate_registration_settings($input) {
    $enable_registration_settings = isset($input['enable_registration_settings']) ? $input['enable_registration_settings'] : 0;

    if ($enable_registration_settings == 1) {
        return $input;
    }

    $agreement_text = get_option('registration_agreement_text');
    $background_image = get_option('registration_background_image');
    $logo_image = get_option('registration_logo_image');
    $custom_notice = get_option('custom_registration_notice');
    //$redirect_url = get_option('registration_success_redirect_url');

    if (empty($agreement_text) && empty($background_image) && empty($logo_image) && empty($custom_notice)) { 
   //if (empty($agreement_text) && empty($background_image) && empty($logo_image)) {
        add_settings_error(
            'enable_registration_settings',
            'enable_registration_settings_error',
            '请先设置好，如果必须项没有设置则验证注册不生效，自定义提醒支持单独显示。',
            'error'
        );
        return false;
    }

    return $input;
}

// 获取默认值函数
function wp_cr_get_default_value($option_name, $default_value) {
    $value = get_option($option_name);
    return !empty($value) ? $value : $default_value;
}

// 注册页面
add_action('register_form', 'wp_cr_custom_registration_form');
function wp_cr_custom_registration_form() {
    $enable_settings = get_option('enable_registration_settings');
    
    if ($enable_settings) {
        ?>
        <p>
            <label for="password">密码 (密码至少需要8位数)</label>
            <input type="password" name="password" id="password" class="input" pattern=".{8,}" title="密码少于8位数." />
        </p>
        <p>
            <label for="confirm_password">确认密码</label>
            <input type="password" name="confirm_password" id="confirm_password" class="input" />
        </p>
        <?php
    }
    
    if ($enable_settings) {
        $agreement_text = get_option('registration_agreement_text');
        $agreement_url = get_option('registration_agreement_url');
        
        ?>
        <?php if (!empty($agreement_text) && !empty($agreement_url)) : ?>
            <p>
                <input type="checkbox" name="registration_agreement_checkbox" id="registration_agreement_checkbox" />
                <label for="registration_agreement_checkbox"><?php echo esc_html($agreement_text); ?> <a href="<?php echo esc_url($agreement_url); ?>" target="_blank"><?php echo !empty($agreement_url) ? '查看详情' : ''; ?></a></label>
            </p>
        <?php endif; ?>
        <?php
    }

    // 显示自定义内容提醒
    $custom_notice = get_option('custom_registration_notice');
    if (!empty($custom_notice)) {
        echo wp_kses_post($custom_notice);
    }
}


// 反馈
add_filter('registration_errors', 'wp_cr_custom_registration_validation', 10, 3);
function wp_cr_custom_registration_validation($errors, $sanitized_user_login, $user_email) {
    $enable_settings = get_option('enable_registration_settings');

    // 检查是否启用注册设置复选框，如果未启用，则不执行进一步的验证
    if (!$enable_settings) {
        return $errors;
    }

    // 检查密码是否为空
    if (empty($_POST['password'])) {
        $errors->add('password_empty', __("密码不能为空"));
    }

    if (empty($_POST['confirm_password'])) {
        $errors->add('confirm_password_empty', __("确认密码不能为空"));
    }

    if ($_POST['password'] !== $_POST['confirm_password']) {
        $errors->add('password_mismatch', __("密码不匹配"));
    }

    if (strlen($_POST['password']) < 8) {
        $errors->add('password_length_error', __("密码长度至少为 8 个字符"));
    }

    // 如果启用了注册设置，但未设置注册协议，则不进行进一步验证
    if (!get_option('registration_agreement_text') || !get_option('registration_agreement_url')) {
        return $errors;
    }

    // 检查注册协议标题和URL是否为空，如果为空，则跳过注册协议复选框的验证
    if (empty($_POST['registration_agreement_checkbox'])) {
        $errors->add('agreement_error', __("您必须同意注册协议才能注册"));
    }
    
    return $errors;
}

// 获取密码并进行注册
add_action('user_register', 'wp_cr_custom_registration_process', 10, 1);
function wp_cr_custom_registration_process($user_id) {
    $enable_settings = get_option('enable_registration_settings');

    // 如果未启用注册设置，不执行自动登录
    if (!$enable_settings) {
        return;
    }

    // 检查密码是否为空
    if (empty($_POST['password']) || empty($_POST['confirm_password'])) {
        return;
    }

    // 检查密码是否匹配
    if ($_POST['password'] !== $_POST['confirm_password']) {
        return;
    }

    // 更新用户密码
    wp_set_password($_POST['password'], $user_id);

    // 获取跳转URL
    $redirect_url = get_option('registration_success_redirect_url');
    if (empty($redirect_url)) {
        $redirect_url = isset($_POST['_wp_http_referer']) ? esc_url($_POST['_wp_http_referer']) : home_url('/');
    }

    // 注册自动登录
    $user = get_user_by('id', $user_id);
    if ($user) {
        wp_clear_auth_cookie();
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);
        do_action('wp_login', $user->user_login, $user);
        wp_safe_redirect($redirect_url);
        exit;
    }
}

/*// 登录时验证密码
add_filter('wp_authenticate_user', 'wp_cr_check_password_strength', 10, 2);
function wp_cr_check_password_strength($user, $password) {
    // 只有在注册设置启用时才进行密码验证
    $enable_settings = get_option('enable_registration_settings');
    if ($enable_settings) {
        // 获取用户对象
        $user = get_user_by('login', $user->user_login);

        // 检查密码是否匹配
        if ($user && !wp_check_password($password, $user->data->user_pass, $user->ID)) {
            // 如果密码不匹配，返回一个错误消息
            return new WP_Error('authentication_failed', __('<strong>错误</strong>: 密码错误。'));
        }
    }
    
    return $user;
}*/


// 注册页面背景图片和 Logo 图片
add_action('login_enqueue_scripts', 'wp_cr_custom_login_styles');
function wp_cr_custom_login_styles() {
    $enable_settings = get_option('enable_registration_settings');
    if ($enable_settings) {
        $background_image = wp_cr_get_default_value('registration_background_image', '');
        ?>
        <style>
            body.login {
                background-image: url('<?php echo $background_image; ?>');
                background-size: cover;
                background-repeat: no-repeat;
                background-position: center center;
                min-height: 100vh;
                background-attachment: fixed;
            }
        </style>
        <?php
    }
}

// 插入默认WordPress Logo图片
add_action('login_head', 'wp_cr_custom_login_logo');
function wp_cr_custom_login_logo() {
    $enable_settings = get_option('enable_registration_settings');
    $logo_image = wp_cr_get_default_value('registration_logo_image', '');

    // 检查是否设置了注册页面Logo图片，如果未设置，则显示当前主题的默认logo
    if (empty($logo_image) && $enable_settings) {
        // 获取当前主题的logo
        $custom_logo_id = get_theme_mod('custom_logo');
        $logo_image = wp_get_attachment_image_src($custom_logo_id, 'full');
        if ($logo_image) {
            $logo_image = $logo_image[0];
        }
    }

    if (!empty($logo_image)) {
        echo '<style>.login h1 a { background-image: url("' . esc_url($logo_image) . '") !important; }</style>';
    }
}


// SMTP邮件功能
add_action('phpmailer_init', 'wp_cr_smtp_email');
function wp_cr_smtp_email($phpmailer) {
    $enable_smtp_mail = get_option('enable_smtp_mail');
    if ($enable_smtp_mail) {
        $phpmailer->isSMTP();
        $phpmailer->Host       = get_option('smtp_host');
        $phpmailer->SMTPAuth   = true;
        $phpmailer->Port       = get_option('smtp_port');
        $phpmailer->Username   = get_option('smtp_username');
        $phpmailer->Password   = get_option('smtp_password');
        $phpmailer->SMTPSecure = get_option('smtp_protocol');
        $phpmailer->From       = get_option('smtp_username');
        $phpmailer->FromName   = get_option('smtp_from_name');
    }
}

// 注册插件卸载钩子
register_uninstall_hook(__FILE__, 'wp_cr_custom_registration_plugin_uninstall');

// 插件卸载时执行的操作
function wp_cr_custom_registration_plugin_uninstall() {
    // 删除数据库中插件保存的选项
    delete_option('registration_agreement_text');
    delete_option('registration_agreement_url');
    delete_option('registration_background_image');
    delete_option('registration_logo_image');
    delete_option('enable_registration_settings');
    delete_option('custom_registration_notice');
    delete_option('smtp_host');
    delete_option('smtp_protocol');
    delete_option('smtp_port');
    delete_option('smtp_username');
    delete_option('smtp_password');
    delete_option('smtp_from_name');
    delete_option('enable_smtp_mail');
    delete_option('registration_success_redirect_url');
}

?>