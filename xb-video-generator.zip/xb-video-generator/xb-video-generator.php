<?php
/*
Plugin Name: 小半文生视频助手
Description: 基于通义千问接口的WordPress文生视频插件
Version: 1.2.1
Author: summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 创建数据库表
function xb_video_gt_create_database() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_video_gt_records';
    $content_table = $wpdb->prefix . 'xb_video_gt_contents';
    $membership_table = $wpdb->prefix . 'xb_video_gt_memberships';
    $charset_collate = $wpdb->get_charset_collate();

    // 创建记录表
    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        usage_date date NOT NULL,
        total_count int DEFAULT 0,
        success_count int DEFAULT 0,
        custom_limit int DEFAULT NULL,
        PRIMARY KEY (id),
        INDEX user_date_index (user_id, usage_date)
    ) $charset_collate;";

    // 创建内容表
    $content_sql = "CREATE TABLE $content_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        record_id bigint(20) NOT NULL,
        user_id bigint(20) NOT NULL,
        prompt text NOT NULL,
        task_id varchar(255) DEFAULT NULL,
        video_url varchar(255) DEFAULT NULL,
        task_status varchar(50) DEFAULT 'PENDING',
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        INDEX record_user_index (record_id, user_id)
    ) $charset_collate;";

    // 创建会员表
    $membership_sql = "CREATE TABLE $membership_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        username varchar(255) NOT NULL,
        created_at datetime NOT NULL,
        expiry_date datetime NOT NULL,
        PRIMARY KEY (id),
        INDEX user_index (user_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    dbDelta($content_sql);
    dbDelta($membership_sql);
}

// 创建前台页面
function xb_video_gt_create_frontend_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_video_gt_shortcode]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        wp_insert_post(array(
            'post_title'    => '文生视频',
            'post_name'     => 'video-generator',
            'post_content'  => '[xb_video_gt_shortcode]',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        ));
    }
}

// 记录日志函数
function xb_video_gt_log($message, $data = null) {
    // 生产环境可通过注释掉以下代码禁用日志
    $log_enabled = true;
    if ($log_enabled) {
        $log_message = date('Y-m-d H:i:s') . ' - ' . $message;
        if ($data !== null) {
            $log_message .= ' ' . print_r($data, true);
        }
        $log_message .= "\n";
        file_put_contents(WP_CONTENT_DIR . '/debug.log', $log_message, FILE_APPEND);
    }
}

// 加载前端资源
function xb_video_gt_load_resources() {
    wp_enqueue_style('xb_video_gt_styles', plugin_dir_url(__FILE__) . 'xb_video_gt_styles.css', array(), '1.2.1');
    wp_enqueue_script('xb_video_gt_script', plugin_dir_url(__FILE__) . 'xb_video_gt_scripts.js', array('jquery'), '1.2.1', true);

    $models = array_map('trim', explode(',', get_option('xb_video_gt_models', 'wanx2.1-t2v-turbo,wanx2.1-t2v-plus')));

    wp_localize_script('xb_video_gt_script', 'XBVideoGTData', array(
        'rest_url' => esc_url_raw(rest_url('xb_video_gt/v1/generate')),
        'nonce' => wp_create_nonce('wp_rest'),
        'ajax_url' => admin_url('admin-ajax.php'),
        'char_limit' => (int) get_option('xb_video_gt_char_limit', 800),
        'login_url' => esc_url(wp_login_url(get_permalink())),
        'models' => $models,
        'example_prompt' => get_option('xb_video_gt_example_prompt', '一只小猫在月光下奔跑'),
        'membership_url' => get_option('xb_video_gt_membership_url', '') // 添加会员页面URL
    ));
}

add_action('wp_enqueue_scripts', function() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_video_gt_shortcode')) {
        xb_video_gt_load_resources();
    }
});

// 注册激活钩子
register_activation_hook(__FILE__, 'xb_video_gt_create_database');
register_activation_hook(__FILE__, 'xb_video_gt_create_frontend_page');

// 验证分辨率
function xb_video_gt_validate_resolution($model, $resolution) {
    $valid_resolutions = [
        'wanx2.1-t2v-turbo' => ['832*480', '480*832', '624*624', '1280*720', '720*1280', '960*960', '832*1088', '1088*832'],
        'wanx2.1-t2v-plus' => ['1280*720', '720*1280', '960*960', '832*1088', '1088*832']
    ];
    
    return in_array($resolution, $valid_resolutions[$model] ?? []);
}

// 检查用户会员状态
function xb_video_gt_check_membership($user_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_video_gt_memberships';
    $current_date = current_time('mysql');
    
    $membership = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE user_id = %d AND expiry_date > %s",
        $user_id,
        $current_date
    ));
    
    return $membership !== null;
}

// 处理视频生成请求
function xb_video_gt_generate_handler(WP_REST_Request $request) {
    global $wpdb;
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = get_option('xb_video_gt_daily_limit', 5);
    $char_limit = get_option('xb_video_gt_char_limit', 800);
    $prompt_extend = get_option('xb_video_gt_prompt_extend', '0') === '1';
    $models = array_map('trim', explode(',', get_option('xb_video_gt_models', 'wanx2.1-t2v-turbo,wanx2.1-t2v-plus')));

    // 检查会员状态
    if (!xb_video_gt_check_membership($user_id)) {
        echo "data: " . json_encode(array('error' => '请先开通会员以使用文生视频功能')) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    // 获取使用数据
    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT total_count, success_count, custom_limit FROM {$wpdb->prefix}xb_video_gt_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));

    $total_count = $usage_data ? $usage_data->total_count : 0;
    $success_count = $usage_data ? $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? $usage_data->custom_limit : $default_limit;

    if ($success_count >= $user_limit) {
        echo "data: " . json_encode(array('error' => '今日生成次数已达上限，请明天再试')) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    // 检查输入字数
    $prompt = $request->get_param('prompt') ?? '';
    if (mb_strlen($prompt, 'UTF-8') > $char_limit) {
        echo "data: " . json_encode(array('error' => '输入提示词超过 ' . $char_limit . ' 字，请删减后重试')) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    // 获取参数
    $resolution = $request->get_param('resolution') ?? '1280*720';
    $model = $request->get_param('model') ?? $models[0];
    $prompt_extend = $request->get_param('prompt_extend') === 'true' && $prompt_extend;

    // 验证模型参数
    if (!in_array($model, $models)) {
        echo "data: " . json_encode(array('error' => '无效的模型参数，请选择其他模型重试')) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    // 验证分辨率
    if (!xb_video_gt_validate_resolution($model, $resolution)) {
        echo "data: " . json_encode(array('error' => '所选模型不支持该分辨率，请选择其他分辨率或模型重试')) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    // 更新总尝试次数
    if ($usage_data) {
        $wpdb->update(
            $wpdb->prefix . 'xb_video_gt_records',
            array('total_count' => $total_count + 1),
            array('user_id' => $user_id, 'usage_date' => $today)
        );
    } else {
        $wpdb->insert(
            $wpdb->prefix . 'xb_video_gt_records',
            array('user_id' => $user_id, 'usage_date' => $today, 'total_count' => 1, 'success_count' => 0)
        );
    }

    // 保存提示词内容
    $record_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}xb_video_gt_records WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));
    if ($prompt) {
        $wpdb->insert(
            $wpdb->prefix . 'xb_video_gt_contents',
            array(
                'record_id' => $record_id,
                'user_id' => $user_id,
                'prompt' => $prompt,
                'created_at' => current_time('mysql'),
                'task_status' => 'PENDING'
            )
        );
        $content_id = $wpdb->insert_id;
    }

    // 发起 API 请求
    $api_url = get_option('xb_video_gt_api_url', 'https://dashscope.aliyuncs.com/api/v1/services/aigc/video-generation/video-synthesis');
    $api_key = get_option('xb_video_gt_api_key', '');

    if (empty($api_url) || empty($api_key)) {
        echo "data: " . json_encode(array('error' => 'API配置错误，请联系管理员')) . "\n\n";
        ob_flush();
        flush();
        exit;
    }

    // 设置流式响应头
    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no');

    // 使用 cURL 发起任务请求
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Bearer ' . $api_key,
        'Content-Type: application/json',
        'X-DashScope-Async: enable'
    ));
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
        'model' => $model,
        'input' => array('prompt' => $prompt),
        'parameters' => array(
            'size' => $resolution,
            'prompt_extend' => $prompt_extend,
            'duration' => 5
        )
    )));

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if (curl_errno($ch) || $http_code !== 200) {
        $error = curl_error($ch) ?: 'HTTP ' . $http_code;
        xb_video_gt_log('API请求失败', array('error' => $error, 'response' => $response));
        echo "data: " . json_encode(array('error' => '生成失败，请更换模型重试')) . "\n\n";
        ob_flush();
        flush();
        curl_close($ch);
        exit;
    }

    $parsed_data = json_decode($response, true);
    xb_video_gt_log('API创建任务响应', $parsed_data);
    
    if (json_last_error() !== JSON_ERROR_NONE || !isset($parsed_data['output']['task_id'])) {
        xb_video_gt_log('任务创建失败', array('json_error' => json_last_error_msg(), 'response' => $response));
        echo "data: " . json_encode(array('error' => '任务创建失败，请更换模型重试')) . "\n\n";
        ob_flush();
        flush();
        curl_close($ch);
        exit;
    }

    $task_id = $parsed_data['output']['task_id'];
    $wpdb->update(
        $wpdb->prefix . 'xb_video_gt_contents',
        array('task_id' => $task_id),
        array('id' => $content_id)
    );

    echo "data: " . json_encode(array('task_id' => $task_id, 'status' => 'PENDING')) . "\n\n";
    ob_flush();
    flush();
    curl_close($ch);

    // 轮询任务状态（最长10分钟，每20秒一次）
    $start_time = time();
    $max_duration = 600; // 10分钟
    $poll_interval = 20; // 20秒

    while ((time() - $start_time) < $max_duration) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://dashscope.aliyuncs.com/api/v1/tasks/$task_id");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $api_key
        ));

        $task_response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch) || $http_code !== 200) {
            $error = curl_error($ch) ?: 'HTTP ' . $http_code;
            xb_video_gt_log('任务查询失败', array('error' => $error, 'response' => $task_response));
            curl_close($ch);
            sleep($poll_interval);
            continue;
        }

        $task_data = json_decode($task_response, true);
        curl_close($ch);

        xb_video_gt_log('任务查询响应', $task_data);

        if (json_last_error() !== JSON_ERROR_NONE || !isset($task_data['output']['task_status'])) {
            xb_video_gt_log('任务状态解析失败', array('json_error' => json_last_error_msg(), 'response' => $task_response));
            sleep($poll_interval);
            continue;
        }

        $task_status = $task_data['output']['task_status'];
        $wpdb->update(
            $wpdb->prefix . 'xb_video_gt_contents',
            array('task_status' => $task_status),
            array('task_id' => $task_id)
        );

        if ($task_status === 'SUCCEEDED') {
            $video_url = $task_data['output']['video_url'];
            $wpdb->update(
                $wpdb->prefix . 'xb_video_gt_contents',
                array('video_url' => $video_url),
                array('task_id' => $task_id)
            );
            $wpdb->update(
                $wpdb->prefix . 'xb_video_gt_records',
                array('success_count' => $success_count + 1),
                array('user_id' => $user_id, 'usage_date' => $today)
            );
            echo "data: " . json_encode(array('status' => 'SUCCEEDED', 'video_url' => $video_url)) . "\n\n";
            ob_flush();
            flush();
            echo "data: [DONE]\n\n";
            ob_flush();
            flush();
            exit;
        } elseif ($task_status === 'FAILED' || $task_status === 'CANCELED') {
            $error_message = isset($task_data['output']['message']) ? $task_data['output']['message'] : '未知错误';
            xb_video_gt_log('任务失败', array('status' => $task_status, 'message' => $error_message));
            echo "data: " . json_encode(array('error' => '任务失败，请更换模型重试')) . "\n\n";
            ob_flush();
            flush();
            exit;
        }

        echo "data: " . json_encode(array('status' => $task_status)) . "\n\n";
        ob_flush();
        flush();
        sleep($poll_interval);
    }

    xb_video_gt_log('任务超时', array('task_id' => $task_id));
    echo "data: " . json_encode(array('error' => '任务超时，请更换模型重试')) . "\n\n";
    ob_flush();
    flush();
    exit;
}

// 注册 REST API 端点
add_action('rest_api_init', function() {
    register_rest_route('xb_video_gt/v1', '/generate', array(
        'methods' => 'POST',
        'callback' => 'xb_video_gt_generate_handler',
        'permission_callback' => function(WP_REST_Request $request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_not_logged_in', '请先登录', array('status' => 401));
            }
            $nonce = $request->get_header('X-WP-Nonce');
            if (!wp_verify_nonce($nonce, 'wp_rest')) {
                return new WP_Error('rest_forbidden', 'Nonce 验证失败', array('status' => 403));
            }
            return true;
        }
    ));

    register_rest_route('xb_video_gt/v1', '/usage', array(
        'methods' => 'GET',
        'callback' => 'xb_video_gt_get_usage',
        'permission_callback' => function() {
            return is_user_logged_in();
        }
    ));
});

// 获取使用情况
function xb_video_gt_get_usage(WP_REST_Request $request) {
    global $wpdb;
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = get_option('xb_video_gt_daily_limit', 5);

    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT total_count, success_count, custom_limit FROM {$wpdb->prefix}xb_video_gt_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));

    $total_count = $usage_data ? $usage_data->total_count : 0;
    $success_count = $usage_data ? $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? $usage_data->custom_limit : $default_limit;

    return array(
        'remaining' => max(0, $user_limit - $success_count),
        'limit' => $user_limit,
        'total_count' => $total_count,
        'success_count' => $success_count
    );
}

// 后台菜单
function xb_video_gt_admin_menu() {
    add_menu_page(
        '文生视频设置',
        '文生视频',
        'manage_options',
        'xb-video-generator',
        'xb_video_gt_settings_page',
        'dashicons-video-alt3'
    );
    add_submenu_page(
        'xb-video-generator',
        '用户记录',
        '用户记录',
        'manage_options',
        'xb-video-user-records',
        'xb_video_gt_user_records_page'
    );
    add_submenu_page(
        'xb-video-generator',
        '会员管理',
        '会员管理',
        'manage_options',
        'xb-video-membership',
        'xb_video_gt_membership_page'
    );
}
add_action('admin_menu', 'xb_video_gt_admin_menu');

// 注册设置
function xb_video_gt_register_settings() {
    register_setting('xb_video_gt_settings', 'xb_video_gt_api_url');
    register_setting('xb_video_gt_settings', 'xb_video_gt_api_key');
    register_setting('xb_video_gt_settings', 'xb_video_gt_daily_limit');
    register_setting('xb_video_gt_settings', 'xb_video_gt_char_limit');
    register_setting('xb_video_gt_settings', 'xb_video_gt_ad_content');
    register_setting('xb_video_gt_settings', 'xb_video_gt_resolutions');
    register_setting('xb_video_gt_settings', 'xb_video_gt_prompt_extend');
    register_setting('xb_video_gt_settings', 'xb_video_gt_models');
    register_setting('xb_video_gt_settings', 'xb_video_gt_example_prompt');
    register_setting('xb_video_gt_settings', 'xb_video_gt_membership_url'); // 会员页面URL设置

    add_settings_section(
        'xb_video_gt_main_section',
        'API设置',
        null,
        'xb_video_gt_settings'
    );

    add_settings_section(
        'xb_video_gt_content_section',
        '内容设置',
        null,
        'xb_video_gt_settings'
    );

    add_settings_section(
        'xb_video_gt_membership_section',
        '会员设置',
        null,
        'xb_video_gt_settings'
    );

    add_settings_field(
        'xb_video_gt_api_url',
        'API地址',
        'xb_video_gt_api_url_field',
        'xb_video_gt_settings',
        'xb_video_gt_main_section'
    );

    add_settings_field(
        'xb_video_gt_api_key',
        'API密钥',
        'xb_video_gt_api_key_field',
        'xb_video_gt_settings',
        'xb_video_gt_main_section'
    );

    add_settings_field(
        'xb_video_gt_daily_limit',
        '每日生成限制',
        'xb_video_gt_daily_limit_field',
        'xb_video_gt_settings',
        'xb_video_gt_main_section'
    );

    add_settings_field(
        'xb_video_gt_char_limit',
        '提示词字数限制',
        'xb_video_gt_char_limit_field',
        'xb_video_gt_settings',
        'xb_video_gt_main_section'
    );

    add_settings_field(
        'xb_video_gt_resolutions',
        '支持的画质',
        'xb_video_gt_resolutions_field',
        'xb_video_gt_settings',
        'xb_video_gt_main_section'
    );

    add_settings_field(
        'xb_video_gt_models',
        '支持的模型',
        'xb_video_gt_models_field',
        'xb_video_gt_settings',
        'xb_video_gt_main_section'
    );

    add_settings_field(
        'xb_video_gt_prompt_extend',
        '启用Prompt智能改写',
        'xb_video_gt_prompt_extend_field',
        'xb_video_gt_settings',
        'xb_video_gt_content_section'
    );

    add_settings_field(
        'xb_video_gt_ad_content',
        '广告内容 (HTML)',
        'xb_video_gt_ad_content_field',
        'xb_video_gt_settings',
        'xb_video_gt_content_section'
    );

    add_settings_field(
        'xb_video_gt_example_prompt',
        '示例提示词',
        'xb_video_gt_example_prompt_field',
        'xb_video_gt_settings',
        'xb_video_gt_content_section'
    );

    add_settings_field(
        'xb_video_gt_membership_url',
        '会员开通页面URL',
        'xb_video_gt_membership_url_field',
        'xb_video_gt_settings',
        'xb_video_gt_membership_section'
    );
}
add_action('admin_init', 'xb_video_gt_register_settings');

// 设置字段回调函数
function xb_video_gt_api_url_field() {
    $value = get_option('xb_video_gt_api_url', 'https://dashscope.aliyuncs.com/api/v1/services/aigc/video-generation/video-synthesis');
    echo '<input type="text" name="xb_video_gt_api_url" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入API地址 (如 https://dashscope.aliyuncs.com/api/v1/services/aigc/video-generation/video-synthesis)</p>';
}

function xb_video_gt_api_key_field() {
    $value = get_option('xb_video_gt_api_key', '');
    echo '<input type="text" name="xb_video_gt_api_key" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入您的API密钥</p>';
}

function xb_video_gt_daily_limit_field() {
    $value = get_option('xb_video_gt_daily_limit', '5');
    echo '<input type="number" name="xb_video_gt_daily_limit" value="' . esc_attr($value) . '" min="1" />';
    echo '<p class="description">设置用户默认每日生成限制</p>';
}

function xb_video_gt_char_limit_field() {
    $value = get_option('xb_video_gt_char_limit', '800');
    echo '<input type="number" name="xb_video_gt_char_limit" value="' . esc_attr($value) . '" min="1" />';
    echo '<p class="description">设置提示词的最大字数限制</p>';
}

function xb_video_gt_resolutions_field() {
    $value = get_option('xb_video_gt_resolutions', '480P,720P');
    echo '<input type="text" name="xb_video_gt_resolutions" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入支持的画质选项，用逗号分隔 (如 480P,720P)</p>';
}

function xb_video_gt_models_field() {
    $value = get_option('xb_video_gt_models', 'wanx2.1-t2v-turbo,wanx2.1-t2v-plus');
    echo '<input type="text" name="xb_video_gt_models" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入支持的模型，用逗号分隔 (如 wanx2.1-t2v-turbo,wanx2.1-t2v-plus)</p>';
}

function xb_video_gt_prompt_extend_field() {
    $value = get_option('xb_video_gt_prompt_extend', '0');
    echo '<input type="checkbox" name="xb_video_gt_prompt_extend" value="1" ' . checked($value, '1', false) . ' />';
    echo '<p class="description">勾选以启用Prompt智能改写功能</p>';
}

function xb_video_gt_ad_content_field() {
    $value = get_option('xb_video_gt_ad_content', '');
    echo '<textarea name="xb_video_gt_ad_content" rows="5" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">输入广告内容 (支持HTML，图片建议尺寸：宽度不超过600px，高度不超过400px)</p>';
}

function xb_video_gt_example_prompt_field() {
    $value = get_option('xb_video_gt_example_prompt', '一只小猫在月光下奔跑');
    echo '<textarea name="xb_video_gt_example_prompt" rows="3" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">输入示例提示词，点击前台“示例”按钮时将填充此内容</p>';
}

function xb_video_gt_membership_url_field() {
    $value = get_option('xb_video_gt_membership_url', '');
    echo '<input type="text" name="xb_video_gt_membership_url" value="' . esc_attr($value) . '" class="regular-text" />';
    echo '<p class="description">输入会员开通页面的完整URL</p>';
}

// 设置页面
function xb_video_gt_settings_page() {
    ?>
    <div class="wrap">
        <h1>文生视频设置</h1>
        <?php
        if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {
            echo '<div id="setting-saved-notice" class="notice notice-success is-dismissible"><p>设置保存成功！</p></div>';
            echo '<script>
                setTimeout(function() {
                    jQuery("#setting-saved-notice").fadeOut();
                }, 3000);
            </script>';
        }
        ?>
        <form method="post" action="options.php">
            <?php
            settings_fields('xb_video_gt_settings');
            do_settings_sections('xb_video_gt_settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// 用户记录页面
function xb_video_gt_user_records_page() {
    global $wpdb;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : (isset($_GET['user_id']) ? intval($_GET['user_id']) : 0);
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $per_page = 20;

    $total_usage = $wpdb->get_var("SELECT SUM(total_count) FROM {$wpdb->prefix}xb_video_gt_records");
    $total_success = $wpdb->get_var("SELECT SUM(success_count) FROM {$wpdb->prefix}xb_video_gt_records");

    $today = current_time('Y-m-d');
    $today_total_usage = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(total_count) FROM {$wpdb->prefix}xb_video_gt_records WHERE usage_date = %s",
        $today
    ));
    $today_total_success = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(success_count) FROM {$wpdb->prefix}xb_video_gt_records WHERE usage_date = %s",
        $today
    ));

    $total_all_records = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}xb_video_gt_contents");
    $all_records = $wpdb->get_results($wpdb->prepare(
        "SELECT c.*, r.usage_date, r.total_count, r.success_count, r.custom_limit 
        FROM {$wpdb->prefix}xb_video_gt_contents c 
        LEFT JOIN {$wpdb->prefix}xb_video_gt_records r ON c.record_id = r.id 
        ORDER BY c.created_at DESC 
        LIMIT %d OFFSET %d",
        $per_page,
        ($paged - 1) * $per_page
    ));

    ?>
    <div class="wrap">
        <h1>用户记录</h1>
        <h2>生成统计</h2>
        <p>网站总共尝试次数：<?php echo esc_html($total_usage ?: 0); ?> 次，成功次数：<?php echo esc_html($total_success ?: 0); ?> 次</p>
        <p>今日总共尝试次数：<?php echo esc_html($today_total_usage ?: 0); ?> 次，成功次数：<?php echo esc_html($today_total_success ?: 0); ?> 次</p>

        <h2>所有用户生成记录</h2>
        <?php
        if ($all_records) {
            echo '<table class="wp-list-table widefat fixed striped" id="all-records-table">';
            echo '<thead><tr><th>用户ID</th><th>日期</th><th>尝试次数</th><th>成功次数</th><th>自定义限制</th><th>提示词</th><th>任务状态</th><th>视频URL</th><th>创建时间</th><th>操作</th></tr></thead>';
            echo '<tbody>';
            foreach ($all_records as $record) {
                echo '<tr>';
                echo '<td>' . esc_html($record->user_id) . '</td>';
                echo '<td>' . esc_html($record->usage_date) . '</td>';
                echo '<td>' . esc_html($record->total_count) . '</td>';
                echo '<td>' . esc_html($record->success_count) . '</td>';
                echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
                echo '<td>' . esc_html($record->prompt ?: '无记录') . '</td>';
                echo '<td>' . esc_html($record->task_status) . '</td>';
                echo '<td>' . ($record->video_url ? '<a href="' . esc_url($record->video_url) . '" target="_blank">查看</a>' : '无') . '</td>';
                echo '<td>' . esc_html($record->created_at) . '</td>';
                echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
            echo '<button id="delete-all-records">删除全部记录</button>';

            $total_pages = ceil($total_all_records / $per_page);
            if ($total_pages > 1) {
                echo '<div id="all-pagination">';
                for ($i = 1; $i <= $total_pages; $i++) {
                    printf('<a href="#" class="page-number%s" data-page="%d">%d</a>', $i === $paged ? ' active' : '', $i, $i);
                }
                echo '</div>';
            }
        } else {
            echo '<p>暂无用户记录。</p>';
        }
        ?>

        <h2>查询指定用户</h2>
        <form method="post">
            <input type="number" name="user_id" placeholder="输入用户ID" value="<?php echo esc_attr($user_id); ?>">
            <input type="submit" value="搜索" class="button">
        </form>
        <?php
        if ($user_id) {
            $user_total_usage = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(total_count) FROM {$wpdb->prefix}xb_video_gt_records WHERE user_id = %d",
                $user_id
            ));
            $user_total_success = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(success_count) FROM {$wpdb->prefix}xb_video_gt_records WHERE user_id = %d",
                $user_id
            ));

            $user_today_usage = $wpdb->get_var($wpdb->prepare(
                "SELECT total_count FROM {$wpdb->prefix}xb_video_gt_records WHERE user_id = %d AND usage_date = %s",
                $user_id,
                $today
            ));
            $user_today_success = $wpdb->get_var($wpdb->prepare(
                "SELECT success_count FROM {$wpdb->prefix}xb_video_gt_records WHERE user_id = %d AND usage_date = %s",
                $user_id,
                $today
            ));

            $total_records = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}xb_video_gt_contents WHERE user_id = %d",
                $user_id
            ));

            $records = $wpdb->get_results($wpdb->prepare(
                "SELECT c.*, r.usage_date, r.total_count, r.success_count, r.custom_limit 
                FROM {$wpdb->prefix}xb_video_gt_contents c 
                LEFT JOIN {$wpdb->prefix}xb_video_gt_records r ON c.record_id = r.id 
                WHERE c.user_id = %d 
                ORDER BY c.created_at DESC 
                LIMIT %d OFFSET %d",
                $user_id,
                $per_page,
                ($paged - 1) * $per_page
            ));

            echo '<h2>用户记录 (ID: ' . esc_html($user_id) . ')</h2>';
            echo '<p>用户总共尝试次数：' . esc_html($user_total_usage ?: 0) . ' 次，成功次数：' . esc_html($user_total_success ?: 0) . ' 次</p>';
            echo '<p>用户今日尝试次数：' . esc_html($user_today_usage ?: 0) . ' 次，成功次数：' . esc_html($user_today_success ?: 0) . ' 次</p>';

            if ($records) {
                echo '<table class="wp-list-table widefat fixed striped" id="user-records-table">';
                echo '<thead><tr><th>日期</th><th>尝试次数</th><th>成功次数</th><th>自定义限制</th><th>提示词</th><th>任务状态</th><th>视频URL</th><th>操作</th></tr></thead>';
                echo '<tbody>';
                foreach ($records as $record) {
                    echo '<tr>';
                    echo '<td>' . esc_html($record->usage_date) . '</td>';
                    echo '<td>' . esc_html($record->total_count) . '</td>';
                    echo '<td>' . esc_html($record->success_count) . '</td>';
                    echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
                    echo '<td>' . esc_html($record->prompt ?: '无记录') . '</td>';
                    echo '<td>' . esc_html($record->task_status) . '</td>';
                    echo '<td>' . ($record->video_url ? '<a href="' . esc_url($record->video_url) . '" target="_blank">查看</a>' : '无') . '</td>';
                    echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
                echo '<button id="delete-all-user-records" data-user-id="' . esc_attr($user_id) . '">删除全部用户记录</button>';

                $total_pages = ceil($total_records / $per_page);
                if ($total_pages > 1) {
                    echo '<div id="pagination">';
                    for ($i = 1; $i <= $total_pages; $i++) {
                        printf('<a href="#" class="page-number%s" data-page="%d">%d</a>', $i === $paged ? ' active' : '', $i, $i);
                    }
                    echo '</div>';
                }
            } else {
                echo '<p>未找到该用户记录。</p>';
            }

            ?>
            <form method="post">
                <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="number" name="custom_limit" placeholder="自定义每日限制">
                <input type="submit" name="set_limit" value="设置自定义限制" class="button">
                <input type="submit" name="reset_limit" value="恢复默认" class="button">
            </form>
            <?php
        }
        ?>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $('#pagination .page-number').on('click', function(e) {
            e.preventDefault();
            if (!$(this).hasClass('active')) {
                var user_id = $('input[name="user_id"]').val();
                var page = $(this).data('page');
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_video_gt_load_user_records',
                        user_id: user_id,
                        paged: page
                    },
                    success: function(response) {
                        $('#user-records-table tbody').html(response.data.records);
                        $('#pagination .page-number').removeClass('active');
                        $('#pagination .page-number[data-page="' + page + '"]').addClass('active');
                    }
                });
            }
        });

        $('#all-pagination .page-number').on('click', function(e) {
            e.preventDefault();
            if (!$(this).hasClass('active')) {
                var page = $(this).data('page');
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_video_gt_load_all_records',
                        paged: page
                    },
                    success: function(response) {
                        $('#all-records-table tbody').html(response.data.records);
                        $('#all-pagination .page-number').removeClass('active');
                        $('#all-pagination .page-number[data-page="' + page + '"]').addClass('active');
                    }
                });
            }
        });

        $('.delete-record').on('click', function(e) {
            e.preventDefault();
            var content_id = $(this).data('id');
            if (confirm('确定删除此记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_video_gt_delete_record',
                        content_id: content_id
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#all-records-table tr').each(function() {
                                if ($(this).find('.delete-record').data('id') === content_id) {
                                    $(this).remove();
                                }
                            });
                            $('#user-records-table tr').each(function() {
                                if ($(this).find('.delete-record').data('id') === content_id) {
                                    $(this).remove();
                                }
                            });
                        }
                    }
                });
            }
        });

        $('#delete-all-records').on('click', function(e) {
            e.preventDefault();
            if (confirm('确定删除所有记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_video_gt_delete_all_records'
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#all-records-table tbody').empty();
                        }
                    }
                });
            }
        });

        $('#delete-all-user-records').on('click', function(e) {
            e.preventDefault();
            var user_id = $(this).data('user-id');
            if (confirm('确定删除该用户的所有记录？')) {
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'xb_video_gt_delete_user_records',
                        user_id: user_id
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#user-records-table tbody').empty();
                        }
                    }
                });
            }
        });
    });
    </script>
    <?php
}

// 会员管理页面
function xb_video_gt_membership_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_video_gt_memberships';
    
    // 处理添加会员
    if (isset($_POST['add_membership'])) {
        $user_id = intval($_POST['user_id']);
        $expiry_date = sanitize_text_field($_POST['expiry_date']);
        $user = get_userdata($user_id);
        
        if ($user && $expiry_date) {
            $wpdb->insert(
                $table_name,
                array(
                    'user_id' => $user_id,
                    'username' => $user->user_login,
                    'created_at' => current_time('mysql'),
                    'expiry_date' => $expiry_date
                )
            );
        }
    }
    
    // 处理删除会员
    if (isset($_POST['delete_membership'])) {
        $membership_id = intval($_POST['membership_id']);
        $wpdb->delete($table_name, array('id' => $membership_id));
    }

    $memberships = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");
    ?>
    <div class="wrap">
        <h1>会员管理</h1>
        <h2>添加会员</h2>
        <form method="post">
            <input type="number" name="user_id" placeholder="用户ID" required>
            <input type="datetime-local" name="expiry_date" required>
            <input type="submit" name="add_membership" value="添加会员" class="button button-primary">
        </form>
        
        <h2>会员列表</h2>
        <?php if ($memberships): ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户名</th>
                    <th>用户ID</th>
                    <th>添加时间</th>
                    <th>到期时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($memberships as $membership): ?>
                <tr>
                    <td><?php echo esc_html($membership->username); ?></td>
                    <td><?php echo esc_html($membership->user_id); ?></td>
                    <td><?php echo esc_html($membership->created_at); ?></td>
                    <td><?php echo esc_html($membership->expiry_date); ?></td>
                    <td>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="membership_id" value="<?php echo esc_attr($membership->id); ?>">
                            <input type="submit" name="delete_membership" value="删除" class="button button-secondary" onclick="return confirm('确定删除该会员权限？');">
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p>暂无会员记录。</p>
        <?php endif; ?>
    </div>
    <?php
}

// AJAX 获取用户记录
add_action('wp_ajax_xb_video_gt_load_user_records', function() {
    global $wpdb;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $paged = isset($_POST['paged']) ? max(1, intval($_POST['paged'])) : 1;
    $per_page = 20;

    if ($user_id) {
        $records = $wpdb->get_results($wpdb->prepare(
            "SELECT c.*, r.usage_date, r.total_count, r.success_count, r.custom_limit 
            FROM {$wpdb->prefix}xb_video_gt_contents c 
            LEFT JOIN {$wpdb->prefix}xb_video_gt_records r ON c.record_id = r.id 
            WHERE c.user_id = %d 
            ORDER BY c.created_at DESC 
            LIMIT %d OFFSET %d",
            $user_id,
            $per_page,
            ($paged - 1) * $per_page
        ));

        ob_start();
        foreach ($records as $record) {
            echo '<tr>';
            echo '<td>' . esc_html($record->usage_date) . '</td>';
            echo '<td>' . esc_html($record->total_count) . '</td>';
            echo '<td>' . esc_html($record->success_count) . '</td>';
            echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
            echo '<td>' . esc_html($record->prompt ?: '无记录') . '</td>';
            echo '<td>' . esc_html($record->task_status) . '</td>';
            echo '<td>' . ($record->video_url ? '<a href="' . esc_url($record->video_url) . '" target="_blank">查看</a>' : '无') . '</td>';
            echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
            echo '</tr>';
        }
        $html = ob_get_clean();

        wp_send_json_success(array('records' => $html));
    }
    wp_die();
});

// AJAX 获取所有用户记录
add_action('wp_ajax_xb_video_gt_load_all_records', function() {
    global $wpdb;
    $paged = isset($_POST['paged']) ? max(1, intval($_POST['paged'])) : 1;
    $per_page = 20;

    $records = $wpdb->get_results($wpdb->prepare(
        "SELECT c.*, r.usage_date, r.total_count, r.success_count, r.custom_limit 
        FROM {$wpdb->prefix}xb_video_gt_contents c 
        LEFT JOIN {$wpdb->prefix}xb_video_gt_records r ON c.record_id = r.id 
        ORDER BY c.created_at DESC 
        LIMIT %d OFFSET %d",
        $per_page,
        ($paged - 1) * $per_page
    ));

    ob_start();
    foreach ($records as $record) {
        echo '<tr>';
        echo '<td>' . esc_html($record->user_id) . '</td>';
        echo '<td>' . esc_html($record->usage_date) . '</td>';
        echo '<td>' . esc_html($record->total_count) . '</td>';
        echo '<td>' . esc_html($record->success_count) . '</td>';
        echo '<td>' . esc_html($record->custom_limit ?: '默认') . '</td>';
        echo '<td>' . esc_html($record->prompt ?: '无记录') . '</td>';
        echo '<td>' . esc_html($record->task_status) . '</td>';
        echo '<td>' . ($record->video_url ? '<a href="' . esc_url($record->video_url) . '" target="_blank">查看</a>' : '无') . '</td>';
        echo '<td>' . esc_html($record->created_at) . '</td>';
        echo '<td><button class="delete-record" data-id="' . esc_attr($record->id) . '">删除</button></td>';
        echo '</tr>';
    }
    $html = ob_get_clean();

    wp_send_json_success(array('records' => $html));
    wp_die();
});

// AJAX 删除单条记录
add_action('wp_ajax_xb_video_gt_delete_record', function() {
    global $wpdb;
    $content_id = isset($_POST['content_id']) ? intval($_POST['content_id']) : 0;
    if ($content_id) {
        $wpdb->delete($wpdb->prefix . 'xb_video_gt_contents', array('id' => $content_id));
        wp_send_json_success();
    }
    wp_send_json_error();
});

// AJAX 删除所有记录
add_action('wp_ajax_xb_video_gt_delete_all_records', function() {
    global $wpdb;
    $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}xb_video_gt_contents");
    $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}xb_video_gt_records");
    wp_send_json_success();
});

// AJAX 删除用户所有记录
add_action('wp_ajax_xb_video_gt_delete_user_records', function() {
    global $wpdb;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    if ($user_id) {
        $record_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}xb_video_gt_records WHERE user_id = %d",
            $user_id
        ));
        if ($record_ids) {
            $wpdb->delete($wpdb->prefix . 'xb_video_gt_contents', array('record_id' => $record_ids));
            $wpdb->delete($wpdb->prefix . 'xb_video_gt_records', array('user_id' => $user_id));
        }
        wp_send_json_success();
    }
    wp_send_json_error();
});

// 前台短代码
function xb_video_gt_shortcode() {
    global $wpdb;
    $ad_content = get_option('xb_video_gt_ad_content', '');
    $prompt_extend = get_option('xb_video_gt_prompt_extend', '0') === '1';
    $models = array_map('trim', explode(',', get_option('xb_video_gt_models', 'wanx2.1-t2v-turbo,wanx2.1-t2v-plus')));

    if (!is_user_logged_in()) {
        ob_start();
        ?>
        <div class="xb_video_gt_container">
            <div class="xb_video_gt_page_title">AI文字生成视频助手</div>
            <div class="xb_video_gt_login_notice">
                请先登录才能使用文字生成视频助手。
                <button class="xb_video_gt_quick_login_button">快速登录</button>
            </div>
            <?php if ($ad_content): ?>
            <div class="xb_video_gt_ad">
                <?php echo wp_kses_post($ad_content); ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $default_limit = get_option('xb_video_gt_daily_limit', 5);

    $usage_data = $wpdb->get_row($wpdb->prepare(
        "SELECT total_count, success_count, custom_limit FROM {$wpdb->prefix}xb_video_gt_records 
        WHERE user_id = %d AND usage_date = %s",
        $user_id,
        $today
    ));

    $success_count = $usage_data ? $usage_data->success_count : 0;
    $user_limit = $usage_data && $usage_data->custom_limit ? $usage_data->custom_limit : $default_limit;
    $remaining_usage = max(0, $user_limit - $success_count);

    $resolutions = array_map('trim', explode(',', get_option('xb_video_gt_resolutions', '480P,720P')));

    ob_start();
    ?>
    <div class="xb_video_gt_container">
        <div class="xb_video_gt_page_title">AI文字生成视频助手</div>
        
        <?php if (!xb_video_gt_check_membership($user_id)): ?>
        <div class="xb_video_gt_membership_notice">
            <div class="xb_video_gt_membership_popup">
                <p>您需要开通会员才能使用文字生成视频功能！</p>
                <a href="<?php echo esc_url(get_option('xb_video_gt_membership_url', '')); ?>" class="xb_video_gt_membership_button">开通会员</a>
            </div>
        </div>
        <?php else: ?>
        <div class="xb_video_gt_config">
            <div class="xb_video_gt_page_mintitle">生成配置</div>
            
            <div class="xb_video_gt_input_wrapper">
                <label for="xb_video_gt_input">提示词
                    <button class="xb_video_gt_example_button" title="填入示例">
                        <span class="dashicons dashicons-admin-page"></span> 示例
                    </button>
                </label>
                <textarea id="xb_video_gt_input" name="xb_video_gt_input" placeholder="请输入视频生成提示词"></textarea>
                <div class="xb_video_gt_char_count">字数: <span>0</span>/<?php echo esc_html(get_option('xb_video_gt_char_limit', 800)); ?></div>
            </div>
            
            <div class="xb_video_gt_model_wrapper">
                <div>
                    <label for="xb_video_gt_model">模型</label>
                    <select id="xb_video_gt_model" name="xb_video_gt_model">
                        <?php foreach ($models as $model): ?>
                            <option value="<?php echo esc_attr($model); ?>"><?php echo esc_html($model); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label for="xb_video_gt_resolution">画质</label>
                    <select id="xb_video_gt_resolution" name="xb_video_gt_resolution">
                        <?php foreach ($resolutions as $res): ?>
                            <option value="<?php echo esc_attr($res === '480P' ? '832*480' : '1280*720'); ?>"><?php echo esc_html($res); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php if ($prompt_extend): ?>
                <div class="xb_video_gt_prompt_extend_wrapper">
                    <span>智能改写</span>
                    <div class="xb_video_gt_prompt_extend_toggle">
                        <input type="checkbox" id="xb_video_gt_prompt_extend" name="xb_video_gt_prompt_extend">
                        <span class="xb_video_gt_prompt_extend_slider"></span>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <?php if ($remaining_usage > 0): ?>
            <button class="xb_video_gt_generate_button">生成视频</button>
            <?php endif; ?>
        </div>
        
        <div class="xb_video_gt_results">
            <div class="xb_video_gt_page_mintitle">生成结果</div>
            <div class="xb_video_gt_result_content">生成结果将显示在这里...</div>
            <div class="xb_video_gt_result_buttons">
                <a class="xb_video_gt_download_button" style="display: none;" download>下载视频</a>
                <button class="xb_video_gt_clear_button">清空</button>
            </div>
            <div class="xb_video_gt_usage">
                <?php echo $remaining_usage > 0 ? esc_html('今日可用次数：' . $remaining_usage . '/' . $user_limit) : '今日已经使用完，请明天再来'; ?>
            </div>
            <div class="xb_video_gt_notice">
                注意：生成的视频链接仅保留24小时，请及时下载保存！
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($ad_content): ?>
        <div class="xb_video_gt_ad">
            <?php echo wp_kses_post($ad_content); ?>
        </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('xb_video_gt_shortcode', 'xb_video_gt_shortcode');

// 处理自定义限制更新
add_action('admin_post', function() {
    if (isset($_POST['user_id']) && (isset($_POST['set_limit']) || isset($_POST['reset_limit']))) {
        global $wpdb;
        $user_id = intval($_POST['user_id']);
        
        if (isset($_POST['set_limit']) && !empty($_POST['custom_limit'])) {
            $custom_limit = intval($_POST['custom_limit']);
            $wpdb->update(
                $wpdb->prefix . 'xb_video_gt_records',
                array('custom_limit' => $custom_limit),
                array('user_id' => $user_id)
            );
        } elseif (isset($_POST['reset_limit'])) {
            $wpdb->update(
                $wpdb->prefix . 'xb_video_gt_records',
                array('custom_limit' => null),
                array('user_id' => $user_id)
            );
        }
        
        wp_redirect(admin_url('admin.php?page=xb-video-user-records&user_id=' . $user_id));
        exit;
    }
});

// 增强 REST API 权限检查
add_filter('rest_authentication_errors', function($result) {
    if (is_wp_error($result)) {
        return $result;
    }
    if (!is_user_logged_in()) {
        return new WP_Error(
            'rest_not_logged_in',
            '您必须登录才能访问此资源。',
            array('status' => 401)
        );
    }
    return $result;
});
?>