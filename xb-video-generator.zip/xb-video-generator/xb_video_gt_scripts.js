jQuery(document).ready(function($) {
    // 确保 XBVideoGTData 存在
    if (typeof XBVideoGTData === 'undefined') {
        console.error('XBVideoGTData 未定义。');
        $('.xb_video_gt_result_content').html('<p class="xb_video_gt_error">初始化失败，请刷新页面或联系管理员。</p>');
        return;
    }

    // 检查用户是否登录
    const $textarea = $('#xb_video_gt_input');
    const isLoggedIn = $textarea.length > 0;

    if (isLoggedIn) {
        // 示例按钮
        $('.xb_video_gt_example_button').click(function(e) {
            e.preventDefault();
            const exampleData = XBVideoGTData.example_prompt || '';
            $textarea.val(exampleData);
            console.log('示例按钮点击。输入:', exampleData);
            updateCharCount();
        });

        // Prompt 智能改写开关
        $('.xb_video_gt_prompt_extend_slider').click(function() {
            const $checkbox = $('#xb_video_gt_prompt_extend');
            $checkbox.prop('checked', !$checkbox.prop('checked'));
            console.log('Prompt智能改写开关点击。选中:', $checkbox.is(':checked'));
        });

        // 字数统计
        function updateCharCount() {
            const charCount = $textarea.val().length;
            const maxChars = XBVideoGTData.char_limit || 800;
            $('.xb_video_gt_char_count span').text(charCount);
            if (charCount > maxChars) {
                $('.xb_video_gt_char_count').addClass('xb_video_gt_char_exceed');
            } else {
                $('.xb_video_gt_char_count').removeClass('xb_video_gt_char_exceed');
            }
            console.log('字数更新。计数:', charCount, '最大:', maxChars);
        }

        $textarea.on('input', updateCharCount);
        updateCharCount();

        // 生成视频按钮
        $('.xb_video_gt_generate_button').click(function(e) {
            e.preventDefault();
            
            const $resultContent = $('.xb_video_gt_result_content');
            const $downloadButton = $('.xb_video_gt_download_button');
            const prompt = $textarea.val();
            const $generateButton = $(this);

            console.log('生成视频按钮点击。提示词:', prompt);

            // 验证输入
            if (!prompt) {
                $resultContent.html('<p class="xb_video_gt_error">请输入提示词</p>');
                console.log('错误: 提示词为空');
                return;
            }

            // 验证字数限制
            if (prompt.length > XBVideoGTData.char_limit) {
                $resultContent.html('<p class="xb_video_gt_error">提示词超过 ' + XBVideoGTData.char_limit + ' 字，请删减后重试</p>');
                console.log('错误: 提示词超出字数限制');
                return;
            }

            // 显示加载状态
            $resultContent.html('<span class="loading">正在生成视频，请耐心等待（可能需要10分钟）...</span>');
            $downloadButton.hide();
            console.log('显示加载状态');
            
            if (!XBVideoGTData.nonce) {
                $resultContent.html('<p class="xb_video_gt_error">请先登录以使用文生视频生成器。</p>');
                console.log('错误: 无 nonce，用户未登录');
                return;
            }

            const data = {
                model: $('#xb_video_gt_model').val() || XBVideoGTData.models[0],
                prompt: prompt,
                resolution: $('#xb_video_gt_resolution').val() || '1280*720',
                prompt_extend: $('#xb_video_gt_prompt_extend').is(':checked').toString()
            };

            $generateButton.prop('disabled', true);
            console.log('发送 API 请求:', data);

            fetch(XBVideoGTData.rest_url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': XBVideoGTData.nonce,
                    'Accept': 'text/event-stream'
                },
                body: JSON.stringify(data)
            }).then(response => {
                if (!response.ok) {
                    return response.json().then(error => {
                        throw new Error(error.message || '请求失败');
                    });
                }

                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let done = false;

                function readStream() {
                    reader.read().then(({ done: streamDone, value }) => {
                        if (streamDone) {
                            done = true;
                            $generateButton.prop('disabled', false);
                            console.log('流结束');
                            return;
                        }

                        const chunk = decoder.decode(value, { stream: true });
                        const lines = chunk.split('\n').filter(line => line.trim());
                        lines.forEach(line => {
                            if (line.startsWith('data: ')) {
                                const jsonData = line.substring(6);
                                if (jsonData === '[DONE]') {
                                    done = true;
                                    updateUsageCount();
                                    console.log('流 [DONE]');
                                    return;
                                }

                                try {
                                    const data = JSON.parse(jsonData);
                                    if (data.error) {
                                        $resultContent.html('<p class="xb_video_gt_error">' + (data.error || '未知错误') + '</p>');
                                        $generateButton.prop('disabled', false);
                                        console.log('API 错误:', data.error);
                                        return;
                                    }
                                    if (data.status === 'PENDING' || data.status === 'RUNNING') {
                                        $resultContent.html('<span class="loading">任务状态: ' + data.status + '，请耐心等待（可能需要10分钟）...</span>');
                                        console.log('任务状态:', data.status);
                                    } else if (data.status === 'SUCCEEDED' && data.video_url) {
                                        $resultContent.html('<video controls src="' + data.video_url + '" style="max-width: 100%;"></video>');
                                        $downloadButton.attr({
                                            'href': data.video_url,
                                            'download': 'generated_video.mp4'
                                        }).show();
                                        updateUsageCount();
                                        console.log('视频生成成功:', data.video_url);
                                    }
                                } catch (e) {
                                    console.error('解析流数据出错:', e, '数据:', jsonData);
                                }
                            }
                        });

                        if (!done) {
                            readStream();
                        }
                    }).catch(error => {
                        console.error('流读取失败:', error);
                        $resultContent.html('<p class="xb_video_gt_error">生成失败，请更换模型重试。</p>');
                        $generateButton.prop('disabled', false);
                    });
                }

                readStream();
            }).catch(error => {
                console.error('API 请求失败:', error);
                $resultContent.html('<p class="xb_video_gt_error">生成失败，请更换模型重试。</p>');
                $generateButton.prop('disabled', false);
            });
        });

        // 下载按钮
        $('.xb_video_gt_download_button').click(function(e) {
            console.log('下载按钮点击，URL:', $(this).attr('href'));
        });

        // 清空按钮
        $('.xb_video_gt_clear_button').click(function(e) {
            e.preventDefault();
            $('.xb_video_gt_result_content').empty();
            $('.xb_video_gt_download_button').hide();
            console.log('清空按钮点击');
        });

        // 更新使用次数
        function updateUsageCount() {
            $.ajax({
                url: XBVideoGTData.rest_url.replace('/generate', '/usage'),
                method: 'GET',
                headers: {
                    'X-WP-Nonce': XBVideoGTData.nonce
                },
                success: function(response) {
                    if (response.remaining > 0) {
                        $('.xb_video_gt_usage').text('今日可用次数：' + response.remaining + '/' + response.limit);
                        $('.xb_video_gt_generate_button').show();
                        $('.xb_video_gt_generate_button').prop('disabled', false);
                    } else {
                        $('.xb_video_gt_usage').text('今日已经使用完，请明天再来');
                        $('.xb_video_gt_generate_button').hide();
                    }
                    console.log('使用次数更新。剩余:', response.remaining, '限制:', response.limit);
                },
                error: function() {
                    $('.xb_video_gt_usage').text('今日可用次数：无法加载');
                    $('.xb_video_gt_generate_button').hide();
                    console.log('使用次数获取失败');
                }
            });
        }

        updateUsageCount();
    }

    // 快速登录按钮
    $('.xb_video_gt_quick_login_button').on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = XBVideoGTData.login_url || '/wp-login.php';
        }
        console.log('登录按钮点击');
    });
});