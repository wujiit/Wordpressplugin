jQuery(document).ready(function($) {
    // 错误码映射
    var errorMessages = {
        400: '请求参数错误，请检查输入',
        404: '接口地址不正确，请联系管理员',
        500: '服务商维护，请稍后再试',
        501: '官方数据源维护，请稍后再试',
        601: '接口未开通，请联系管理员',
        602: '账号已停用，请联系管理员',
        603: '余额不足，请充值',
        604: '接口已停用，请联系管理员',
        605: '次数不足，请购买套餐',
        606: '调用超限，请稍后再试',
        607: 'IP不在白名单，请联系管理员',
        609: '请求过于频繁，请稍后再试',
        610: '请求超时，请稍后再试',
        701: '查询无结果',
        999: '未知错误，请稍后再试',
        1001: '今日查询次数已用完，请明天再来'
    };

    // 更新剩余查询次数
    function updateRemainingQueries() {
        $.ajax({
            url: xbPatent.ajaxurl + '/remaining-queries',
            method: 'GET',
            headers: {
                'X-WP-Nonce': xbPatent.nonce
            },
            success: function(response) {
                var remaining = response.remaining !== undefined ? response.remaining : 0;
                var dailyLimit = xbPatent.daily_limit;
                var $usage = $('.xb-patent-usage');
                
                if (remaining > 0) {
                    $usage.html('今日剩余查询次数：<span id="xb-patent-remaining">' + remaining + '</span>/' + dailyLimit);
                    $('.xb-patent-query-section').removeClass('hidden');
                } else {
                    $usage.html('今日使用次数已经用完了，请明天再来');
                    $('.xb-patent-query-section').addClass('hidden');
                }
            },
            error: function(xhr) {
                $('.xb-patent-usage').html('无法获取剩余查询次数，请刷新页面');
            }
        });
    }

    // 查询按钮点击事件
    $(document).on('click', '.xb-patent-query-btn', function(e) {
        e.preventDefault();
        var queryType = $(this).data('query-type');
        var keyword = queryType === 'list' ? $('#xb-patent-keyword').val().trim() : '';
        var patentId = queryType === 'detail' ? $('#xb-patent-id').val().trim() : '';

        if (queryType === 'list' && !keyword) {
            alert('请输入企业名称、注册号或社会统一信用代码');
            return;
        }
        if (queryType === 'detail' && !patentId) {
            alert('请输入专利ID');
            return;
        }

        $('#xb-patent-loading').show();
        $('#xb-patent-results').find('.xb-patent-card-container, .xb-patent-detail-container, .xb-patent-pagination, .xb-patent-error, .xb-patent-no-results, .xb-patent-count').remove();

        $.ajax({
            url: xbPatent.ajaxurl + '/query',
            method: 'POST',
            headers: {
                'X-WP-Nonce': xbPatent.nonce
            },
            data: {
                query_type: queryType,
                keyword: keyword,
                patent_id: patentId,
                frontend_page_no: 1
            },
            success: function(response) {
                $('#xb-patent-loading').hide();
                renderResults(response, queryType);
                updateRemainingQueries();
            },
            error: function(xhr) {
                $('#xb-patent-loading').hide();
                var errorData = xhr.responseJSON || {};
                var errorCode = errorData.code || 999;
                var errorMsg = errorMessages[errorCode] || errorData.msg || '查询失败，请稍后再试';
                $('#xb-patent-results').append('<div class="xb-patent-error">' + errorMsg + '</div>');
            }
        });
    });

    // 分页点击事件
    $(document).on('click', '.xb-patent-page-link', function(e) {
        e.preventDefault();
        var pageNo = $(this).data('page');
        var keyword = $('#xb-patent-keyword').val().trim();

        if (!keyword) {
            alert('请输入企业名称、注册号或社会统一信用代码');
            return;
        }

        $('#xb-patent-loading').show();
        $('#xb-patent-results').find('.xb-patent-card-container, .xb-patent-detail-container, .xb-patent-pagination, .xb-patent-error, .xb-patent-no-results, .xb-patent-count').remove();

        $.ajax({
            url: xbPatent.ajaxurl + '/query',
            method: 'POST',
            headers: {
                'X-WP-Nonce': xbPatent.nonce
            },
            data: {
                query_type: 'list',
                keyword: keyword,
                frontend_page_no: pageNo
            },
            success: function(response) {
                $('#xb-patent-loading').hide();
                renderResults(response, 'list');
                updateRemainingQueries();
            },
            error: function(xhr) {
                $('#xb-patent-loading').hide();
                var errorData = xhr.responseJSON || {};
                var errorCode = errorData.code || 999;
                var errorMsg = errorMessages[errorCode] || errorData.msg || '查询失败，请稍后再试';
                $('#xb-patent-results').append('<div class="xb-patent-error">' + errorMsg + '</div>');
            }
        });
    });

    // 快速登录按钮点击事件
    $('.xb-patent-login-btn').on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('data-href');
        }
    });

    // 渲染查询结果
    function renderResults(response, queryType) {
        if (response.code !== 200) {
            var errorCode = response.code || 999;
            var errorMsg = errorMessages[errorCode] || response.msg || '查询失败，请稍后再试';
            $('#xb-patent-results').append('<div class="xb-patent-error">' + errorMsg + '</div>');
            return;
        }

        var data = response.data;

        if (queryType === 'list') {
            var results = data.items || [];
            var page = data.page || {};
            var pageSize = page.pageSize || 10;
            var totalRecords = page.recordCount || 0;
            var currentPage = page.pageNo || 1;
            var totalPages = Math.ceil(totalRecords / pageSize);

            $('#xb-patent-results').append('<div class="xb-patent-count">共查询到 ' + totalRecords + ' 条结果</div>');

            if (!Array.isArray(results) || results.length === 0) {
                $('#xb-patent-results').append('<div class="xb-patent-no-results">无查询结果</div>');
                return;
            }

            var cardContainer = $('<div class="xb-patent-card-container"></div>');

            $.each(results, function(i, item) {
                var card = $('<div class="xb-patent-card"></div>');
                card.append('<h3>' + (item.Title || '-') + '</h3>');
                card.append('<p><strong>申请企业：</strong>' + (item.AssigneestringList || '-') + '</p>');
                card.append('<p><strong>专利ID：</strong>' + (item.Id || '-') + '</p>');
                card.append('<p><strong>申请号：</strong>' + (item.ApplicationNumber || '-') + '</p>');
                card.append('<p><strong>申请日期：</strong>' + (item.ApplicationDate || '-') + '</p>');
                card.append('<p><strong>公开号：</strong>' + (item.PublicationNumber || '-') + '</p>');
                card.append('<p><strong>公开日期：</strong>' + (item.PublicationDate || '-') + '</p>');
                card.append('<p><strong>法律状态：</strong>' + (item.LegalStatusDesc || '-') + '</p>');
                card.append('<p><strong>专利类型：</strong>' + (item.KindCodeDesc || '-') + '</p>');
                cardContainer.append(card);
            });

            $('#xb-patent-results').append(cardContainer);

            if (totalPages > 1) {
                var pagination = $('<div class="xb-patent-pagination"></div>');

                if (currentPage > 1) {
                    pagination.append('<a href="#" class="xb-patent-page-link" data-page="' + (currentPage - 1) + '">上一页</a>');
                }

                var startPage = Math.max(1, currentPage - 2);
                var endPage = Math.min(totalPages, currentPage + 2);
                if (startPage > 1) {
                    pagination.append('<a href="#" class="xb-patent-page-link" data-page="1">1</a>');
                    if (startPage > 2) pagination.append('<span>...</span>');
                }
                for (var i = startPage; i <= endPage; i++) {
                    if (i === currentPage) {
                        pagination.append('<span class="xb-patent-page-current">' + i + '</span>');
                    } else {
                        pagination.append('<a href="#" class="xb-patent-page-link" data-page="' + i + '">' + i + '</a>');
                    }
                }
                if (endPage < totalPages) {
                    if (endPage < totalPages - 1) pagination.append('<span>...</span>');
                    pagination.append('<a href="#" class="xb-patent-page-link" data-page="' + totalPages + '">' + totalPages + '</a>');
                }

                if (currentPage < totalPages) {
                    pagination.append('<a href="#" class="xb-patent-page-link" data-page="' + (currentPage + 1) + '">下一页</a>');
                }

                $('#xb-patent-results').append(pagination);
            }
        } else {
            var detailContainer = $('<div class="xb-patent-detail-container"></div>');
            var detail = $('<div class="xb-patent-detail"></div>');

            detail.append('<h3>' + (data.Title || '-') + '</h3>');
            if (data.PatentImage) {
                detail.append('<img src="' + data.PatentImage + '" alt="Patent Image" class="xb-patent-image">');
            }
            detail.append('<p><strong>申请企业：</strong>' + (data.AssigneestringList || '-') + '</p>');
            detail.append('<p><strong>发明人：</strong>' + (data.InventorStringList || '-') + '</p>');
            detail.append('<p><strong>申请号：</strong>' + (data.ApplicationNumber || '-') + '</p>');
            detail.append('<p><strong>申请日期：</strong>' + (data.ApplicationDate || '-') + '</p>');
            detail.append('<p><strong>公开号：</strong>' + (data.PublicationNumber || '-') + '</p>');
            detail.append('<p><strong>公开日期：</strong>' + (data.PublicationDate || '-') + '</p>');
            detail.append('<p><strong>法律状态：</strong>' + (data.LegalStatusDesc || '-') + '</p>');
            detail.append('<p><strong>法律状态日期：</strong>' + (data.LegalStatusDate || '-') + '</p>');
            detail.append('<p><strong>专利类型：</strong>' + (data.KindCodeDesc || '-') + '</p>');
            detail.append('<p><strong>代理机构：</strong>' + (data.Agency || '-') + '</p>');
            detail.append('<p><strong>代理人：</strong>' + (data.Agent || '-') + '</p>');
            detail.append('<p><strong>IPC分类号：</strong>' + (data.IPCList || '-') + '</p>');
            detail.append('<p><strong>IPC分类详情：</strong>' + (data.IPCDesc || '-') + '</p>');
            detail.append('<div class="xb-patent-abstract"><strong>摘要：</strong><p>' + (data.Abstract || '-') + '</p></div>');

            if (Array.isArray(data.PatentLegalHistory) && data.PatentLegalHistory.length > 0) {
                var history = $('<div class="xb-patent-legal-history"><h4>法律状态历史</h4></div>');
                var historyList = $('<ul></ul>');
                $.each(data.PatentLegalHistory, function(i, item) {
                    historyList.append('<li><strong>' + (item.LegalStatusDate || '-') + ':</strong> ' + (item.LegalStatus || '-') + ' (' + (item.Desc || '-') + ')</li>');
                });
                history.append(historyList);
                detail.append(history);
            }

            detailContainer.append(detail);
            $('#xb-patent-results').append(detailContainer);
        }
    }

    // 初始化剩余查询次数
    updateRemainingQueries();
});