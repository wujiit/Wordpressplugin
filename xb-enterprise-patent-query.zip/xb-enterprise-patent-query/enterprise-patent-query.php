<?php
/*
Plugin Name: 小半企业专利查询
Description: 基于聚美智数实现查询企业的专利列表及专利详情信息。
Plugin URI: https://www.jingxialai.com/4983.html
Version: 1.0.1
Author: Summer
License: GPL License
Author URI: https://www.jingxialai.com/
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('XB_PATENT_PATH', plugin_dir_path(__FILE__));
define('XB_PATENT_URL', plugin_dir_url(__FILE__));

// 插件激活时创建数据表
register_activation_hook(__FILE__, 'xb_patent_create_tables');
function xb_patent_create_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 创建查询记录表
    $table_name = $wpdb->prefix . 'xb_patent_queries';
    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        query_type VARCHAR(20) NOT NULL,
        query_result VARCHAR(20) NOT NULL,
        query_time DATETIME NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // 创建用户每日限制表
    $table_limit = $wpdb->prefix . 'xb_patent_user_limits';
    $sql_limit = "CREATE TABLE $table_limit (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        daily_limit INT NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id)
    ) $charset_collate;";
    dbDelta($sql_limit);
}

// 插件激活时检查并创建前台页面
register_activation_hook(__FILE__, 'xb_patent_create_frontend_page');
function xb_patent_create_frontend_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_patent_query]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page = array(
            'post_title'    => '企业专利查询',
            'post_content'  => '[xb_patent_query]',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_author'   => 1,
        );
        wp_insert_post($page);
    }
}

// 加载前台 JS 和 CSS
add_action('wp_enqueue_scripts', 'xb_patent_enqueue_frontend_assets');
function xb_patent_enqueue_frontend_assets() {
    global $post;

    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_patent_query')) {
        wp_enqueue_style('xb-patent-style', XB_PATENT_URL . 'xb-patent-style.css', array(), '1.0.1');
        wp_enqueue_script('xb-patent-script', XB_PATENT_URL . 'xb-patent-script.js', array('jquery'), '1.0.1', true);
        
        wp_localize_script('xb-patent-script', 'xbPatent', array(
            'ajaxurl' => rest_url('xb-patent/v1'),
            'nonce' => wp_create_nonce('wp_rest'),
            'user_id' => get_current_user_id(),
            'daily_limit' => (int) get_option('xb_patent_daily_limit', 10),
            'login_url' => wp_login_url(get_permalink()),
        ));
    }
}

// 注册 REST API 路由
add_action('rest_api_init', 'xb_patent_register_rest_routes');
function xb_patent_register_rest_routes() {
    $permission_callback = function ($request) {
        if (!is_user_logged_in() || !current_user_can('read')) {
            return new WP_Error('rest_forbidden', '您没有权限访问此接口', array('status' => 403));
        }
        return true;
    };

    register_rest_route('xb-patent/v1', '/query', array(
        'methods' => 'POST',
        'callback' => 'xb_patent_handle_query',
        'permission_callback' => $permission_callback,
    ));

    register_rest_route('xb-patent/v1', '/remaining-queries', array(
        'methods' => 'GET',
        'callback' => 'xb_patent_get_remaining_queries',
        'permission_callback' => $permission_callback,
    ));
}

// 处理查询请求
function xb_patent_handle_query($request) {
    $user_id = get_current_user_id();
    $query_type = sanitize_text_field($request['query_type']);
    $keyword = sanitize_text_field($request['keyword'] ?? '');
    $patent_id = sanitize_text_field($request['patent_id'] ?? '');
    $page_no = intval($request['frontend_page_no']) ?: 1;

    if (!in_array($query_type, ['list', 'detail'])) {
        return new WP_REST_Response(array(
            'code' => 400,
            'msg' => '无效的查询类型',
        ), 400);
    }

    $remaining = xb_patent_get_remaining_queries_for_user($user_id);
    if ($remaining <= 0) {
        return new WP_REST_Response(array(
            'code' => 1001,
            'msg' => '今日使用次数已经用完了，请明天再来',
        ), 403);
    }

    $app_code = get_option('xb_patent_app_code');
    if (!$app_code) {
        return new WP_REST_Response(array(
            'code' => 601,
            'msg' => 'API 配置未设置',
        ), 500);
    }

    $host = "https://patente.market.alicloudapi.com";
    $query_result = '失败';
    $response_data = null;

    if ($query_type === 'list') {
        $url = $host . "/enterprise/patent/list";
        $page_size = 10;
        if (empty($keyword)) {
            return new WP_REST_Response(array(
                'code' => 400,
                'msg' => '关键字不能为空',
            ), 400);
        }

        $cache_key = 'xb_patent_list_' . md5($user_id . $keyword . $page_no);
        $cached_data = get_transient($cache_key);

        $lock_key = 'xb_patent_lock_' . md5($user_id . $keyword . $page_no);
        if (get_transient($lock_key)) {
            return new WP_REST_Response(array(
                'code' => 609,
                'msg' => '请求过于频繁，请稍后再试',
            ), 429);
        }
        set_transient($lock_key, true, 5);

        if ($cached_data !== false) {
            $results = $cached_data['results'];
            $total_records = $cached_data['total_records'];
            $query_result = '成功';
        } else {
            $params = array(
                'keyword' => $keyword,
                'pageNo' => $page_no,
                'pageSize' => $page_size,
            );

            error_log("Patent List API Request: pageNo=$page_no, keyword=$keyword, cache_key=$cache_key");

            $response = wp_remote_post($url, array(
                'method' => 'POST',
                'body' => http_build_query($params),
                'headers' => array(
                    'Authorization' => 'APPCODE ' . $app_code,
                    'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8',
                ),
                'sslverify' => false,
                'timeout' => 10,
            ));

            if (is_wp_error($response)) {
                delete_transient($lock_key);
                error_log("Patent List API Error: " . $response->get_error_message());
                return new WP_REST_Response(array(
                    'code' => 500,
                    'msg' => '网络请求失败: ' . $response->get_error_message(),
                ), 500);
            }

            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                delete_transient($lock_key);
                error_log("Patent List JSON Parse Error");
                return new WP_REST_Response(array(
                    'code' => 500,
                    'msg' => '响应解析失败',
                ), 500);
            }

            error_log("Patent List API Response: " . print_r($body, true));

            if ($body['code'] !== 200) {
                delete_transient($lock_key);
                return new WP_REST_Response($body, 200);
            }

            $data = $body['data'];
            $results = $data['items'] ?? [];
            $total_records = $data['page']['recordCount'] ?? 0;
            $query_result = '成功';

            set_transient($cache_key, array(
                'results' => $results,
                'total_records' => $total_records,
            ), 5 * MINUTE_IN_SECONDS);
        }

        delete_transient($lock_key);

        $response_data = array(
            'code' => 200,
            'msg' => '成功',
            'charge' => true,
            'taskNo' => $body['taskNo'] ?? uniqid(),
            'data' => array(
                'page' => array(
                    'pageNo' => $page_no,
                    'pageSize' => $page_size,
                    'recordCount' => $total_records,
                ),
                'items' => $results,
            ),
        );
    } else {
        $url = $host . "/enterprise/patent/detail";
        if (empty($patent_id)) {
            return new WP_REST_Response(array(
                'code' => 400,
                'msg' => '专利ID不能为空',
            ), 400);
        }

        $cache_key = 'xb_patent_detail_' . md5($user_id . $patent_id);
        $cached_data = get_transient($cache_key);

        $lock_key = 'xb_patent_lock_' . md5($user_id . $patent_id);
        if (get_transient($lock_key)) {
            return new WP_REST_Response(array(
                'code' => 609,
                'msg' => '请求过于频繁，请稍后再试',
            ), 429);
        }
        set_transient($lock_key, true, 5);

        if ($cached_data !== false) {
            $result = $cached_data['result'];
            $query_result = '成功';
        } else {
            $params = array(
                'id' => $patent_id,
            );

            error_log("Patent Detail API Request: id=$patent_id, cache_key=$cache_key");

            $response = wp_remote_post($url, array(
                'method' => 'POST',
                'body' => http_build_query($params),
                'headers' => array(
                    'Authorization' => 'APPCODE ' . $app_code,
                    'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8',
                ),
                'sslverify' => false,
                'timeout' => 10,
            ));

            if (is_wp_error($response)) {
                delete_transient($lock_key);
                error_log("Patent Detail API Error: " . $response->get_error_message());
                return new WP_REST_Response(array(
                    'code' => 500,
                    'msg' => '网络请求失败: ' . $response->get_error_message(),
                ), 500);
            }

            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                delete_transient($lock_key);
                error_log("Patent Detail JSON Parse Error");
                return new WP_REST_Response(array(
                    'code' => 500,
                    'msg' => '响应解析失败',
                ), 500);
            }

            error_log("Patent Detail API Response: " . print_r($body, true));

            if ($body['code'] !== 200) {
                delete_transient($lock_key);
                return new WP_REST_Response($body, 200);
            }

            $result = $body['data'];
            $query_result = '成功';

            set_transient($cache_key, array(
                'result' => $result,
            ), 5 * MINUTE_IN_SECONDS);
        }

        delete_transient($lock_key);

        $response_data = array(
            'code' => 200,
            'msg' => '成功',
            'charge' => true,
            'taskNo' => $body['taskNo'] ?? uniqid(),
            'data' => $result,
        );
    }

    global $wpdb;
    $wpdb->insert(
        $wpdb->prefix . 'xb_patent_queries',
        array(
            'user_id' => $user_id,
            'query_type' => $query_type,
            'query_result' => $query_result,
            'query_time' => current_time('mysql'),
        )
    );

    return new WP_REST_Response($response_data, 200);
}

// 获取用户剩余查询次数
function xb_patent_get_remaining_queries($request) {
    $user_id = get_current_user_id();
    $remaining = xb_patent_get_remaining_queries_for_user($user_id);
    return new WP_REST_Response(array('remaining' => $remaining), 200);
}

function xb_patent_get_remaining_queries_for_user($user_id) {
    global $wpdb;
    $default_limit = (int) get_option('xb_patent_daily_limit', 10);

    $table_limit = $wpdb->prefix . 'xb_patent_user_limits';
    $user_limit = $wpdb->get_var($wpdb->prepare(
        "SELECT daily_limit FROM $table_limit WHERE user_id = %d",
        $user_id
    ));
    $daily_limit = $user_limit ?: $default_limit;

    $today_start = date('Y-m-d 00:00:00');
    $table_queries = $wpdb->prefix . 'xb_patent_queries';
    $used_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_queries WHERE user_id = %d AND query_result = '成功' AND query_time >= %s",
        $user_id,
        $today_start
    ));

    return max(0, $daily_limit - $used_count);
}

// 注册短代码
add_shortcode('xb_patent_query', 'xb_patent_render_frontend');
function xb_patent_render_frontend() {
    ob_start();
    ?>
    <div class="xb-patent-container">
        <div class="xb-patent-title">企业专利查询</div>
        
        <?php if (!is_user_logged_in()) : ?>
            <div class="xb-patent-notice">
                请先登录
                <button class="xb-patent-login-btn" data-href="<?php echo esc_url(wp_login_url(get_permalink())); ?>">快速登录</button>
            </div>
            <?php
            $announcement = get_option('xb_patent_announcement');
            if ($announcement) : ?>
                <div class="xb-patent-announcement"><?php echo wp_kses_post($announcement); ?></div>
            <?php endif; ?>
        <?php else : ?>
            <?php
            $user_id = get_current_user_id();
            $remaining = xb_patent_get_remaining_queries_for_user($user_id);
            $daily_limit = (int) get_option('xb_patent_daily_limit', 10);
            $hide_query_section = $remaining <= 0;
            ?>

            <?php if (!$hide_query_section) : ?>
                <div class="xb-patent-query-section">
                    <div class="xb-patent-input-group">
                        <input type="text" id="xb-patent-keyword" placeholder="企业名称、注册号或社会统一信用代码" />
                        <button id="xb-patent-list-btn" class="xb-patent-query-btn" data-query-type="list">查询专利列表</button>
                    </div>
                    <div class="xb-patent-input-group">
                        <input type="text" id="xb-patent-id" placeholder="专利ID" />
                        <button id="xb-patent-detail-btn" class="xb-patent-query-btn" data-query-type="detail">查询专利详情</button>
                    </div>
                </div>
            <?php endif; ?>

            <div class="xb-patent-results" id="xb-patent-results">
                <div class="xb-patent-subtitle">查询结果</div>
                <div class="xb-patent-loading" id="xb-patent-loading" style="display: none;">
                    正在查询中...
                </div>
            </div>

            <div class="xb-patent-usage">
                <?php if ($remaining > 0) : ?>
                    今日剩余查询次数：<span id="xb-patent-remaining"><?php echo $remaining; ?></span>/<?php echo $daily_limit; ?>
                <?php else : ?>
                    今日使用次数已经用完了，请明天再来
                <?php endif; ?>
            </div>

            <?php
            $announcement = get_option('xb_patent_announcement');
            if ($announcement) : ?>
                <div class="xb-patent-announcement"><?php echo wp_kses_post($announcement); ?></div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

// 注册后台菜单
add_action('admin_menu', 'xb_patent_admin_menu');
function xb_patent_admin_menu() {
    add_menu_page(
        '企业专利查询',
        '企业专利',
        'manage_options',
        'xb-patent-settings',
        'xb_patent_settings_page'
    );
    add_submenu_page(
        'xb-patent-settings',
        '用户查询记录',
        '用户查询',
        'manage_options',
        'xb-patent-user-queries',
        'xb_patent_user_queries_page'
    );
}

// 设置页面
function xb_patent_settings_page() {
    if (isset($_POST['xb_patent_save_settings'])) {
        update_option('xb_patent_app_code', sanitize_text_field($_POST['xb_patent_app_code']));
        update_option('xb_patent_daily_limit', intval($_POST['xb_patent_daily_limit']));
        update_option('xb_patent_announcement', wp_kses_post($_POST['xb_patent_announcement']));
        echo '<div class="updated xb-patent-admin-notice"><p>设置已保存</p></div>';
        echo '<script type="text/javascript">
            setTimeout(function() {
                var notice = document.querySelector(".xb-patent-admin-notice");
                if (notice) {
                    notice.style.transition = "opacity 0.5s ease-out";
                    notice.style.opacity = "0";
                }
            }, 3000);
        </script>';
    }
    ?>
    <div class="wrap">
        <h1>小半企业专利 设置</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>AppCode</th>
                    <td><input type="text" name="xb_patent_app_code" value="<?php echo esc_attr(get_option('xb_patent_app_code')); ?>" /></td>
                </tr>
                <tr>
                    <th>每日查询限制</th>
                    <td><input type="number" name="xb_patent_daily_limit" value="<?php echo esc_attr(get_option('xb_patent_daily_limit', 10)); ?>" /></td>
                </tr>
                <tr>
                    <th>公告内容</th>
                    <td><textarea name="xb_patent_announcement" rows="5" cols="50"><?php echo esc_textarea(get_option('xb_patent_announcement')); ?></textarea></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="xb_patent_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        基于阿里市场聚美智数专利查询接口https://market.aliyun.com/apimarket/detail/cmapi00049308?spm=5176.shop.result.24.16319f39CQeN8x&innerSource=search#sku=yuncode4330800007
    </div>
    <?php
}

// 用户查询记录页面
function xb_patent_user_queries_page() {
    global $wpdb;
    $table_queries = $wpdb->prefix . 'xb_patent_queries';
    $table_limits = $wpdb->prefix . 'xb_patent_user_limits';
    $default_limit = (int) get_option('xb_patent_daily_limit', 10);

    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['query_id'])) {
        $wpdb->delete($table_queries, array('id' => intval($_GET['query_id'])));
        echo '<div class="updated xb-patent-admin-notice"><p>记录已删除</p></div>';
        echo '<script type="text/javascript">
            setTimeout(function() {
                var notice = document.querySelector(".xb-patent-admin-notice");
                if (notice) {
                    notice.style.transition = "opacity 0.5s ease-out";
                    notice.style.opacity = "0";
                }
            }, 3000);
        </script>';
    }

    if (isset($_POST['xb_patent_set_user_limit'])) {
        $user_id = intval($_POST['user_id']);
        $new_limit = intval($_POST['new_limit']);
        $wpdb->replace(
            $table_limits,
            array('user_id' => $user_id, 'daily_limit' => $new_limit),
            array('%d', '%d')
        );
        echo '<div class="updated xb-patent-admin-notice"><p>用户限额已设置</p></div>';
        echo '<script type="text/javascript">
            setTimeout(function() {
                var notice = document.querySelector(".xb-patent-admin-notice");
                if (notice) {
                    notice.style.transition = "opacity 0.5s ease-out";
                    notice.style.opacity = "0";
                }
            }, 3000);
        </script>';
    }

    if (isset($_GET['action']) && $_GET['action'] == 'reset_limit' && isset($_GET['user_id'])) {
        $wpdb->delete($table_limits, array('user_id' => intval($_GET['user_id'])));
        echo '<div class="updated xb-patent-admin-notice"><p>已恢复默认限额</p></div>';
        echo '<script type="text/javascript">
            setTimeout(function() {
                var notice = document.querySelector(".xb-patent-admin-notice");
                if (notice) {
                    notice.style.transition = "opacity 0.5s ease-out";
                    notice.style.opacity = "0";
                }
            }, 3000);
        </script>';
    }

    $user_id_filter = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $per_page = 20;
    $offset = ($paged - 1) * $per_page;

    $where = '';
    if ($user_id_filter) {
        $where = $wpdb->prepare('WHERE user_id = %d', $user_id_filter);
    }

    $total_queries = $wpdb->get_var("SELECT COUNT(*) FROM $table_queries $where");
    $queries = $wpdb->get_results("SELECT * FROM $table_queries $where ORDER BY query_time DESC LIMIT $offset, $per_page");

    $total_all_queries = $wpdb->get_var("SELECT COUNT(*) FROM $table_queries");

    $user_stats = array();
    if ($user_id_filter) {
        $today_start = date('Y-m-d 00:00:00');
        $used_today = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_queries WHERE user_id = %d AND query_result = '成功' AND query_time >= %s",
            $user_id_filter,
            $today_start
        ));
        $total_user_queries = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_queries WHERE user_id = %d",
            $user_id_filter
        ));
        $user_limit = $wpdb->get_var($wpdb->prepare(
            "SELECT daily_limit FROM $table_limits WHERE user_id = %d",
            $user_id_filter
        ));
        $daily_limit = $user_limit ?: $default_limit;

        $user_stats = array(
            'used_today' => $used_today,
            'daily_limit' => $daily_limit,
            'total_queries' => $total_user_queries,
        );
    }
    ?>
    <div class="wrap">
        <h1>用户查询记录</h1>
        <p>网站总共查询次数：<?php echo $total_all_queries; ?></p>

        <form method="get" action="">
            <input type="hidden" name="page" value="xb-patent-user-queries">
            <p>
                <label>用户 ID：</label>
                <input type="number" name="user_id" value="<?php echo $user_id_filter; ?>">
                <input type="submit" class="button" value="筛选">
            </p>
        </form>

        <?php if ($user_id_filter && $user_stats) : ?>
            <h3>用户统计</h3>
            <p>今日已使用次数：<?php echo $user_stats['used_today']; ?></p>
            <p>每日限额：<?php echo $user_stats['daily_limit']; ?></p>
            <p>总共查询次数：<?php echo $user_stats['total_queries']; ?></p>

            <form method="post">
                <p>
                    <label>设置用户每日限额：</label>
                    <input type="number" name="new_limit" required>
                    <input type="hidden" name="user_id" value="<?php echo $user_id_filter; ?>">
                    <input type="submit" name="xb_patent_set_user_limit" class="button" value="设置限额">
                    <a href="<?php echo add_query_arg(array('action' => 'reset_limit', 'user_id' => $user_id_filter)); ?>" class="button">恢复默认限额</a>
                </p>
            </form>
        <?php endif; ?>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>用户名</th>
                    <th>查询类型</th>
                    <th>查询结果</th>
                    <th>处理时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($queries as $query) : ?>
                    <tr>
                        <td><?php echo $query->user_id; ?></td>
                        <td><?php echo get_userdata($query->user_id)->user_login; ?></td>
                        <td><?php echo $query->query_type === 'list' ? '专利列表' : '专利详情'; ?></td>
                        <td><?php echo $query->query_result; ?></td>
                        <td><?php echo $query->query_time; ?></td>
                        <td><a href="<?php echo add_query_arg(array('action' => 'delete', 'query_id' => $query->id)); ?>" class="button">删除</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <?php
        $total_pages = ceil($total_queries / $per_page);
        if ($total_pages > 1) {
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'total' => $total_pages,
                'current' => $paged,
            ));
        }
        ?>
    </div>
    <?php
}
?>