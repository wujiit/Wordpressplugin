jQuery(document).ready(function($) {
    // 页面加载时获取使用情况
    $.ajax({
        url: xb_bilijx_ajax.ajax_url,
        type: 'POST',
        data: {
            action: 'xb_bilijx_get_usage'
        },
        success: function(response) {
            if (response.success) {
                if (!response.data.hide_stats) {
                    $('.xb_bilijx_usage_info').html('今日剩余解析次数：' + response.data.remaining + '/' + response.data.limit).show();
                }
                if (response.data.remaining <= 0) {
                    $('#xb_bilijx_query_form').hide();
                }
            }
        }
    });

    // 提交解析请求
    $('#xb_bilijx_query_form').on('submit', function(e) {
        e.preventDefault();
        var url = $('#xb_bilijx_url').val();
        var nonce = $('#xb_bilijx_nonce').val();

        $('.xb_bilijx_submit_button').prop('disabled', true).text('解析中...');
        $('#xb_bilijx_result').html('');

        $.ajax({
            url: xb_bilijx_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_bilijx_query',
                url: url,
                nonce: nonce
            },
            success: function(response) {
                $('.xb_bilijx_submit_button').prop('disabled', false).text('开始解析');
                if (response.success) {
                    $('#xb_bilijx_result').html(response.data.result);
                    if (!response.data.hide_stats) {
                        $('.xb_bilijx_usage_info').html('今日剩余解析次数：' + response.data.remaining + '/' + response.data.limit).show();
                    }
                    if (response.data.remaining <= 0) {
                        $('#xb_bilijx_query_form').hide();
                        if (response.data.is_guest) {
                            $('.xb_bilijx_message').show();
                            $('.wp-ai-login-btn').show();
                        }
                    }
                } else {
                    $('#xb_bilijx_result').html('<div class="xb_bilijx_error">' + response.data.message + '</div>');
                    if (!response.data.hide_stats) {
                        $('.xb_bilijx_usage_info').html('今日剩余解析次数：' + response.data.remaining + '/' + response.data.limit).show();
                    }
                    if (response.data.remaining <= 0) {
                        $('#xb_bilijx_query_form').hide();
                        if (response.data.is_guest) {
                            $('.xb_bilijx_message').show();
                            $('.wp-ai-login-btn').show();
                        }
                    }
                }
            },
            error: function() {
                $('.xb_bilijx_submit_button').prop('disabled', false).text('开始解析');
                $('#xb_bilijx_result').html('<div class="xb_bilijx_error">请求失败，请稍后重试！</div>');
            }
        });
    });

    // 清空输入框
    $('.xb_bilijx_clear_button').on('click', function() {
        $('#xb_bilijx_url').val('');
        $('#xb_bilijx_result').html('');
    });

    // "请先登录"按钮点击事件 - 新增快速登录功能
    $('.wp-ai-login-btn').on('click', function (e) {
        e.preventDefault();

        // 优先调用启灵主题弹窗
        if (typeof window.developerStarterShowLoginModal === 'function') {
            window.developerStarterShowLoginModal('login');
            return;
        }

        const $themeLoginBtn = $('#header-login-toggle');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });
});