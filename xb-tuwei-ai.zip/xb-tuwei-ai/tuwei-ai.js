jQuery(document).ready(function($) {
    // 刷新土味情话按钮点击事件
    $('.tuwei_ai_refresh').on('click', function() {
        var $button = $(this);
        $button.prop('disabled', true);
        $('#tuwei_ai_content, #tuwei_ai_source, #tuwei_ai_image').css('opacity', '0');

        $.ajax({
            url: tuwei_ai_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'tuwei_ai_refresh',
                nonce: tuwei_ai_vars.nonce,
                _t: new Date().getTime()
            },
            cache: false,
            success: function(response) {
                if (response.success) {
                    $('#tuwei_ai_content').text(response.data.content).css('opacity', '1');
                    if (response.data.source) {
                        $('#tuwei_ai_source').text('出处：' + response.data.source).css('opacity', '1');
                    } else {
                        $('#tuwei_ai_source').empty().css('opacity', '1');
                    }
                    if (response.data.image_url) {
                        $('#tuwei_ai_image').html('<img src="' + response.data.image_url + '" alt="土味情话图片">').css('opacity', '1');
                    } else {
                        $('#tuwei_ai_image').empty().css('opacity', '1');
                    }
                    $('.tuwei_ai_copy').data('content', response.data.content);
                } else {
                    $('#tuwei_ai_notice').text('刷新失败：' + (response.data.message || '未知错误')).show();
                    setTimeout(function() {
                        $('#tuwei_ai_notice').fadeOut('slow', function() {
                            $(this).empty();
                        });
                    }, 3000);
                }
                $button.prop('disabled', false);
            },
            error: function() {
                $('#tuwei_ai_content, #tuwei_ai_source, #tuwei_ai_image').css('opacity', '1');
                $button.prop('disabled', false);
                $('#tuwei_ai_notice').text('网络错误，请稍后再试！').show();
                setTimeout(function() {
                    $('#tuwei_ai_notice').fadeOut('slow', function() {
                        $(this).empty();
                    });
                }, 3000);
            }
        });
    });

    // 复制土味情话文字按钮点击事件
    $('.tuwei_ai_copy').on('click', function() {
        var content = $(this).data('content');
        var $button = $(this);
        var $notice = $('#tuwei_ai_notice');

        navigator.clipboard.writeText(content).then(function() {
            $button.addClass('copied').text('已复制');
            $notice.empty();
            setTimeout(function() {
                $button.removeClass('copied').text('复制');
            }, 2000);
        }).catch(function() {
            $notice.text('复制失败，请手动复制！').show();
            setTimeout(function() {
                $notice.fadeOut('slow', function() {
                    $notice.empty();
                });
            }, 3000);
        });
    });
});