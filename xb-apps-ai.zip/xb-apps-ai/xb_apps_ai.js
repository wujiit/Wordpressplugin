jQuery(document).ready(function($) {
    // DOM元素选择
    const agentMessages = $('#xb-apps-ai-agent-messages');
    const userMessages = $('#xb-apps-ai-user-messages');
    const input = $('#xb-apps-ai-input');
    const notice = $('#xb-apps-ai-notice');
    const confirmDialog = $('#xb-apps-ai-confirm');
    const confirmMessage = $('#xb-apps-ai-confirm-message');
    const confirmOk = $('.xb-apps-ai-confirm-ok');
    const confirmCancel = $('.xb-apps-ai-confirm-cancel');
    const title = $('#xb-apps-ai-title');
    const config = window.xbAppsAiConfig || {};

    // 音频管理对象，存储每个消息的Audio对象及其状态
    const audioMap = new Map(); // key: messageId, value: { audio: Audio, isPlaying: boolean }

    // 显示通知
    function showNotice(message, type = 'error') {
        notice.text(message).removeClass('success error').addClass(type).show();
        setTimeout(() => notice.hide(), 3000);
    }

    // 滚动到底部
    function scrollToBottom() {
        agentMessages.scrollTop(agentMessages[0].scrollHeight);
        userMessages.scrollTop(userMessages[0].scrollHeight);
    }

    // 显示确认对话框
    function showConfirm(message, callback) {
        confirmMessage.text(message);
        confirmDialog.show();
        confirmOk.off('click').on('click', function() {
            callback();
            confirmDialog.hide();
        });
        confirmCancel.off('click').on('click', function() {
            confirmDialog.hide();
        });
    }

    // 加载对话历史，包含语音任务ID和音频URL
    function loadHistory(app_id) {
        if (xbAppsAi.is_user_logged_in !== '1') {
            return;
        }

        if (!app_id) {
            showNotice('未配置智能体，请联系管理员');
            return;
        }
        $.ajax({
            url: xbAppsAi.ajax_admin_url,
            method: 'GET',
            data: {
                action: 'xb_apps_ai_load_log',
                app_id: app_id,
                _ajax_nonce: xbAppsAi.nonce
            },
            success: function(response) {
                if (response.success && response.data.messages) {
                    userMessages.empty();
                    agentMessages.empty();
                    response.data.messages.forEach((msg) => {
                        if (msg.message) {
                            userMessages.append(`<div class="xb-apps-ai-message user">${$('<div>').text(msg.message).html()}</div>`);
                        }
                        if (msg.response) {
                            appendAgentMessage(msg.response, msg.id, msg.audio_task_id, msg.audio_url);
                        }
                        config.session_id = msg.session_id || config.session_id;
                    });
                    scrollToBottom();
                }
            },
            error: function() {
                showNotice('加载历史记录失败');
            }
        });
    }

    // 添加智能体消息，包含复制和语音播放按钮（根据语音功能开关控制）
    function appendAgentMessage(text, messageId, audioTaskId = '', audioUrl = '') {
        // 移除现有的消息（流式更新时）
        agentMessages.find(`.xb-apps-ai-message.agent[data-message-id="${messageId}"]`).remove();
        
        const messageDiv = $(`<div class="xb-apps-ai-message agent" data-message-id="${messageId}"></div>`);
        const contentDiv = $(`<div class="xb-apps-ai-message-content">${$('<div>').text(text).html()}</div>`);
        const buttonsDiv = $('<div class="xb-apps-ai-buttons"></div>');
        const copyButton = $('<button class="xb-apps-ai-copy-button">复制</button>');

        // 复制按钮事件
        copyButton.on('click', function() {
            navigator.clipboard.writeText(text).then(() => {
                copyButton.text('已复制');
                setTimeout(() => copyButton.text('复制'), 2000);
            }).catch(() => {
                showNotice('复制失败');
            });
        });

        buttonsDiv.append(copyButton);

        // 如果语音功能启用，添加语音播放按钮
        if (xbAppsAi.tts_enabled === '1') {
            const ttsButton = $(`<button class="xb-apps-ai-tts-button" data-task-id="${audioTaskId}" data-audio-url="${audioUrl}">${audioUrl ? '播放' : '语音播放'}</button>`);

            // 语音播放按钮事件
            ttsButton.on('click', function() {
                if (xbAppsAi.is_user_logged_in !== '1') {
                    showNotice('请先登录以使用语音功能');
                    return;
                }
                const taskId = $(this).data('task-id');
                const existingAudioUrl = $(this).data('audio-url');
                
                if (existingAudioUrl) {
                    toggleAudioPlayback(existingAudioUrl, messageId, $(this));
                } else if (taskId) {
                    checkTtsStatus(taskId, $(this), text, messageId);
                } else {
                    requestTts(text, messageId, $(this));
                }
            });

            buttonsDiv.append(ttsButton);
        }

        messageDiv.append(contentDiv).append(buttonsDiv);
        agentMessages.append(messageDiv);
        scrollToBottom();
    }

    // 切换音频播放状态
    function toggleAudioPlayback(audioUrl, messageId, button) {
        let audioData = audioMap.get(messageId);

        if (!audioData) {
            // 创建新的Audio对象
            const audio = new Audio(audioUrl);
            audioData = { audio, isPlaying: false };
            audioMap.set(messageId, audioData);

            // 监听音频播放结束事件，重置状态
            audio.addEventListener('ended', () => {
                audioData.isPlaying = false;
                button.text('播放');
                audio.currentTime = 0; // 重置播放位置
            });
        }

        if (audioData.isPlaying) {
            // 暂停播放
            audioData.audio.pause();
            audioData.isPlaying = false;
            button.text('播放');
        } else {
            // 停止其他正在播放的音频
            audioMap.forEach((data, id) => {
                if (id !== messageId && data.isPlaying) {
                    data.audio.pause();
                    data.isPlaying = false;
                    agentMessages.find(`.xb-apps-ai-tts-button[data-audio-url="${data.audio.src}"]`).text('播放');
                }
            });

            // 开始或继续播放
            audioData.audio.play().then(() => {
                audioData.isPlaying = true;
                button.text('暂停');
            }).catch(error => {
                showNotice('音频播放失败: ' + error.message);
                button.text('播放');
            });
        }
    }

    // 请求语音合成
    function requestTts(text, messageId, button) {
        button.prop('disabled', true).text('合成中...');
        fetch(xbAppsAi.tts_url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': xbAppsAi.rest_nonce
            },
            body: JSON.stringify({
                message_id: messageId,
                text: text
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showNotice('语音合成失败: ' + data.error);
                button.prop('disabled', false).text('语音播放');
                return;
            }
            if (data.status === 'completed' && data.audio_url) {
                button.data('task-id', data.task_id).data('audio-url', data.audio_url).text('播放');
                button.prop('disabled', false);
                button.off('click').on('click', function() {
                    toggleAudioPlayback(data.audio_url, messageId, $(this));
                });
            } else {
                button.data('task-id', data.task_id);
                pollTtsStatus(data.task_id, button, text, messageId);
            }
        })
        .catch(error => {
            showNotice('语音合成请求失败');
            button.prop('disabled', false).text('语音播放');
        });
    }

    // 轮询语音合成状态
    function pollTtsStatus(taskId, button, text, messageId) {
        let pollCount = 0;
        const maxPolls = 10;
        const interval = setInterval(() => {
            fetch(xbAppsAi.tts_url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': xbAppsAi.rest_nonce
                },
                body: JSON.stringify({
                    message_id: messageId,
                    text: text
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'completed' && data.audio_url) {
                    clearInterval(interval);
                    button.data('audio-url', data.audio_url).text('播放');
                    button.prop('disabled', false);
                    button.off('click').on('click', function() {
                        toggleAudioPlayback(data.audio_url, messageId, $(this));
                    });
                } else if (data.status === 'failed' || pollCount >= maxPolls) {
                    clearInterval(interval);
                    showNotice('语音合成失败或超时');
                    button.prop('disabled', false).text('语音播放');
                }
                pollCount++;
            })
            .catch(() => {
                clearInterval(interval);
                showNotice('检查语音状态失败');
                button.prop('disabled', false).text('语音播放');
            });
        }, 10000);
    }

    // 检查已有任务的状态
    function checkTtsStatus(taskId, button, text, messageId) {
        button.prop('disabled', true).text('检查中...');
        fetch(xbAppsAi.tts_url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': xbAppsAi.rest_nonce
            },
            body: JSON.stringify({
                message_id: messageId,
                text: text
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'completed' && data.audio_url) {
                button.data('audio-url', data.audio_url).text('播放');
                button.prop('disabled', false);
                button.off('click').on('click', function() {
                    toggleAudioPlayback(data.audio_url, messageId, $(this));
                });
            } else if (data.status === 'failed') {
                showNotice('语音合成失败');
                button.prop('disabled', false).text('语音播放');
            } else {
                pollTtsStatus(taskId, button, text, messageId);
            }
        })
        .catch(() => {
            showNotice('检查语音状态失败');
            button.prop('disabled', false).text('语音播放');
        });
    }

    // 发送消息
    function sendMessage() {
        const message = input.val().trim();
        if (!message) {
            showNotice('请输入消息内容');
            return;
        }

        userMessages.append(`<div class="xb-apps-ai-message user">${$('<div>').text(message).html()}</div>`);
        input.val('');
        scrollToBottom();

        fetch(xbAppsAi.ajax_url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': xbAppsAi.rest_nonce
            },
            body: JSON.stringify({
                message: message,
                app_id: config.app_id,
                provider: config.provider,
                session_id: config.session_id || ''
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const reader = response.body.getReader();
            let responseText = '';
            let lastMessageId;
            const decoder = new TextDecoder('utf-8');

            function readStream() {
                reader.read().then(({ done, value }) => {
                    if (done) {
                        if (responseText) {
                            appendAgentMessage(responseText, lastMessageId);
                            scrollToBottom();
                        }
                        return;
                    }

                    const chunk = decoder.decode(value, { stream: true });
                    const lines = chunk.split('\n');
                    lines.forEach(line => {
                        if (line.startsWith('data: ')) {
                            const data = line.slice(6);
                            if (data === '[DONE]') {
                                return;
                            }
                            try {
                                const jsonData = JSON.parse(data);
                                if (jsonData.error) {
                                    showNotice(jsonData.error);
                                    return;
                                }
                                if (jsonData.text) {
                                    responseText += jsonData.text;
                                    agentMessages.find(`.xb-apps-ai-message.agent[data-message-id="${jsonData.message_id}"]`).remove();
                                    appendAgentMessage(responseText, jsonData.message_id || lastMessageId);
                                    scrollToBottom();
                                }
                                if (jsonData.session_id) {
                                    config.session_id = jsonData.session_id;
                                }
                                if (jsonData.message_id) {
                                    lastMessageId = jsonData.message_id;
                                }
                            } catch (e) {
                                console.error('JSON 解析错误:', e);
                            }
                        }
                    });
                    readStream();
                }).catch(error => {
                    console.error('Stream 读取错误:', error);
                    showNotice('连接错误，请重试');
                });
            }
            readStream();
        })
        .catch(error => {
            console.error('Fetch 错误:', error);
            showNotice('发送消息失败，请重试');
        });
    }

    // 切换智能体
    function switchAgent(app_id, provider, agent_name) {
        // 停止所有正在播放的音频
        audioMap.forEach((data) => {
            data.audio.pause();
            data.audio.src = '';
        });
        audioMap.clear();

        // 更新配置
        config.app_id = app_id;
        config.provider = provider;
        config.agent_name = agent_name;
        config.session_id = '';

        // 保存当前选择到本地存储
        localStorage.setItem('xb_apps_ai_selected_agent', JSON.stringify({
            app_id: app_id,
            provider: provider,
            agent_name: agent_name
        }));

        // 更新标题
        title.text(agent_name);

        // 清除当前显示的消息
        userMessages.empty();
        agentMessages.empty();

        // 加载新智能体的历史记录
        loadHistory(app_id);

        // 更新按钮状态
        $('.xb-apps-ai-agent-button').removeClass('active');
        $(`.xb-apps-ai-agent-button[data-app-id="${app_id}"]`).addClass('active');
    }

    // 初始化智能体选择
    function initAgentSelection() {
        const savedAgent = localStorage.getItem('xb_apps_ai_selected_agent');
        let initialAppId = config.app_id;
        let initialProvider = config.provider;
        let initialAgentName = config.agent_name;

        if (savedAgent) {
            try {
                const { app_id, provider, agent_name } = JSON.parse(savedAgent);
                // 验证保存的智能体是否仍然有效
                const isValidAgent = config.active_agents.some(agent => agent.app_id === app_id && agent.provider === provider);
                if (isValidAgent) {
                    initialAppId = app_id;
                    initialProvider = provider;
                    initialAgentName = agent_name;
                }
            } catch (e) {
                console.error('解析本地存储的智能体数据失败:', e);
            }
        }

        // 设置标题和按钮状态
        title.text(initialAgentName);
        $('.xb-apps-ai-agent-button').removeClass('active');
        $(`.xb-apps-ai-agent-button[data-app-id="${initialAppId}"]`).addClass('active');

        // 更新配置并加载历史记录
        config.app_id = initialAppId;
        config.provider = initialProvider;
        config.agent_name = initialAgentName;
        loadHistory(initialAppId);
    }

    // 发送按钮点击事件
    $('#xb-apps-ai-send').click(sendMessage);

    // 监控回车键
    input.on('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    // 清除智能体记忆
    $('#xb-apps-ai-clear-agent').click(function() {
        if (!config.app_id) {
            showNotice('未配置智能体');
            return;
        }
        showConfirm('一旦清除记忆，之前的对话内容将无法恢复，确认要清除吗？', function() {
            $.ajax({
                url: xbAppsAi.ajax_admin_url,
                method: 'POST',
                data: {
                    action: 'xb_apps_ai_clear_conversation',
                    app_id: config.app_id,
                    _ajax_nonce: xbAppsAi.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // 清空音频管理对象
                        audioMap.forEach((data) => {
                            data.audio.pause();
                            data.audio.src = '';
                        });
                        audioMap.clear();
                        agentMessages.empty();
                        userMessages.empty();
                        input.val('');
                        showNotice('对话记录已清除', 'success');
                    } else {
                        showNotice(response.data?.message || '清除失败，请重试');
                    }
                },
                error: function() {
                    showNotice('清除失败，请重试');
                }
            });
        });
    });

    // 智能体切换按钮事件
    $('.xb-apps-ai-agent-button').click(function() {
        const app_id = $(this).data('app-id');
        const provider = $(this).data('provider');
        const agent_name = $(this).data('agent-name');
        switchAgent(app_id, provider, agent_name);
    });

    // 快速登录按钮点击事件
    $('.wp-ai-login-btn').on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).data('href');
        }
    });

    // 初始化加载
    if (config.app_id) {
        initAgentSelection();
    }
});