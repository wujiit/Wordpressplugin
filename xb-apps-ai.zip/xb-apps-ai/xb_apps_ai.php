<?php
/*
Plugin Name: 小半AI智能体
Description: 智能体插件，支持阿里百炼、扣子、腾讯、火山引擎等多平台智能体对接，包含多轮对话、流式输出、长期记忆及语音播放功能。
Version: 1.1.1
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 设置全局编码为UTF-8
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');

// 定义常量
define('XB_APPS_AI_VERSION', '1.1.1');
define('XB_APPS_AI_TABLE', 'xb_apps_ai_chat_logs');

// 插件激活时创建数据库表和检查短代码页面
register_activation_hook(__FILE__, 'xb_apps_ai_activate');
function xb_apps_ai_activate() {
    xb_apps_ai_create_database();
    xb_apps_ai_create_front_page();
}

// 创建数据库表
function xb_apps_ai_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . XB_APPS_AI_TABLE;

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        app_id VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        response TEXT NOT NULL,
        session_id VARCHAR(255) DEFAULT NULL,
        audio_task_id VARCHAR(100) DEFAULT '',
        audio_url VARCHAR(255) DEFAULT '',
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        INDEX user_app_idx (user_id, app_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// 创建前台页面，仅在无短代码页面时创建
function xb_apps_ai_create_front_page() {
    global $wpdb;

    $pages = get_posts([
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_apps_ai_chat]',
        'numberposts' => 1,
    ]);

    if (empty($pages)) {
        $page_id = wp_insert_post([
            'post_title'    => '智能体',
            'post_content'  => '[xb_apps_ai_chat]',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_name'     => 'ai-agent'
        ]);
        if (is_wp_error($page_id)) {
            error_log('创建智能体页面失败: ' . $page_id->get_error_message());
        }
    }
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_apps_ai_enqueue_assets');
function xb_apps_ai_enqueue_assets() {
    global $post;

    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_apps_ai_chat')) {
        wp_enqueue_style('xb-apps-ai', plugins_url('xb_apps_ai.css', __FILE__), [], XB_APPS_AI_VERSION);
        wp_enqueue_script('xb-apps-ai', plugins_url('xb_apps_ai.js', __FILE__), ['jquery'], XB_APPS_AI_VERSION, true);
        wp_localize_script('xb-apps-ai', 'xbAppsAi', [
            'ajax_url' => rest_url('xb_apps_ai/v1/send-message'),
            'tts_url' => rest_url('xb_apps_ai/v1/tts'),
            'ajax_admin_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('xb_apps_ai_nonce'),
            'rest_nonce' => wp_create_nonce('wp_rest'),
            'login_url' => wp_login_url(get_permalink()),
            'is_user_logged_in' => is_user_logged_in() ? '1' : '0',
            'tts_enabled' => get_option('xb_apps_ai_tts_enabled', '1') // 新增语音功能开关状态
        ]);
    }
}

// 注册短代码
add_shortcode('xb_apps_ai_chat', 'xb_apps_ai_chat_shortcode');
function xb_apps_ai_chat_shortcode() {
    $agents = get_option('xb_apps_ai_agents', []);
    $active_agents = array_filter($agents, function($agent) {
        return isset($agent['active']) && $agent['active'] == 1;
    });
    $first_active_agent = reset($active_agents);
    $ad_content = wp_kses_post(get_option('xb_apps_ai_ad_content', ''));

    ob_start();
    ?>
    <div class="xb-apps-ai-container">
        <div class="xb-apps-ai-title" id="xb-apps-ai-title"><?php echo esc_html($first_active_agent['name'] ?? '智能体'); ?></div>

        <div class="xb-apps-ai-content">
            <?php if (!is_user_logged_in()) : ?>
                <div class="xb-apps-ai-guest-notice">
                    请先登录以使用智能体。
                    <button class="xb-apps-ai-button wp-ai-login-btn" data-href="<?php echo esc_url(wp_login_url(get_permalink())); ?>">快速登录</button>
                </div>
            <?php else : ?>
                <?php if (empty($active_agents)) : ?>
                    <div class="xb-apps-ai-notice">未配置或未启用智能体，请联系管理员。</div>
                <?php else : ?>
                    <div class="xb-apps-ai-agent-response">
                        <div class="xb-apps-ai-section-title">AI内容</div>
                        <div class="xb-apps-ai-messages" id="xb-apps-ai-agent-messages"></div>
                        <!-- 智能体切换板块 -->
                        <div class="xb-apps-ai-agent-switcher">
                            <?php foreach ($active_agents as $agent) : ?>
                                <button class="xb-apps-ai-button xb-apps-ai-agent-button" 
                                        data-app-id="<?php echo esc_attr($agent['app_id']); ?>" 
                                        data-provider="<?php echo esc_attr($agent['provider']); ?>"
                                        data-agent-name="<?php echo esc_attr($agent['name']); ?>">
                                    <?php echo esc_html($agent['name']); ?>
                                </button>
                            <?php endforeach; ?>
                        </div>
                        <button class="xb-apps-ai-button" id="xb-apps-ai-clear-agent">清除记忆</button>
                    </div>
                    <div class="xb-apps-ai-user-input">
                        <div class="xb-apps-ai-section-title">用户内容</div>
                        <div class="xb-apps-ai-messages" id="xb-apps-ai-user-messages"></div>
                        <textarea id="xb-apps-ai-input" class="xb-apps-ai-textarea" placeholder="输入您的问题..."></textarea>
                        <div class="xb-apps-ai-buttons">
                            <button class="xb-apps-ai-button" id="xb-apps-ai-send">发送</button>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <?php if ($ad_content) : ?>
            <div class="xb-apps-ai-ad"><?php echo $ad_content; ?></div>
        <?php endif; ?>

        <div class="xb-apps-ai-notice" id="xb-apps-ai-notice" style="display: none;"></div>
        <div class="xb-apps-ai-confirm" id="xb-apps-ai-confirm" style="display: none;">
            <div class="xb-apps-ai-confirm-content">
                <p id="xb-apps-ai-confirm-message"></p>
                <div class="xb-apps-ai-confirm-buttons">
                    <button class="xb-apps-ai-button xb-apps-ai-confirm-ok">确定</button>
                    <button class="xb-apps-ai-button xb-apps-ai-confirm-cancel">取消</button>
                </div>
            </div>
        </div>
    </div>

    <?php if (!empty($active_agents) && is_user_logged_in()) : ?>
        <script>
            window.xbAppsAiConfig = {
                app_id: '<?php echo esc_js($first_active_agent['app_id']); ?>',
                provider: '<?php echo esc_js($first_active_agent['provider']); ?>',
                agent_name: '<?php echo esc_js($first_active_agent['name']); ?>',
                session_id: '<?php echo esc_js($first_active_agent['session_id'] ?? ''); ?>',
                active_agents: <?php echo json_encode(array_values($active_agents), JSON_UNESCAPED_UNICODE); ?>
            };
        </script>
    <?php endif; ?>
    <?php
    return ob_get_clean();
}

// 获取智能体列表
add_action('wp_ajax_xb_apps_ai_get_agents', 'xb_apps_ai_get_agents');
function xb_apps_ai_get_agents() {
    check_ajax_referer('xb_apps_ai_nonce');
    $agents = get_option('xb_apps_ai_agents', []);
    wp_send_json_success(['agents' => $agents]);
}

// 加载对话历史，包含语音任务ID和音频URL
add_action('wp_ajax_xb_apps_ai_load_log', 'xb_apps_ai_load_log');
function xb_apps_ai_load_log() {
    check_ajax_referer('xb_apps_ai_nonce');
    global $wpdb;
    $table_name = $wpdb->prefix . XB_APPS_AI_TABLE;
    $user_id = get_current_user_id();
    $app_id = sanitize_text_field($_GET['app_id'] ?? '');
    if (empty($app_id)) {
        wp_send_json_error(['message' => '缺少智能体应用ID']);
        return;
    }
    $messages = $wpdb->get_results($wpdb->prepare(
        "SELECT id, message, response, session_id, audio_task_id, audio_url FROM $table_name WHERE user_id = %d AND app_id = %s ORDER BY created_at ASC",
        $user_id, $app_id
    ));
    wp_send_json_success(['messages' => $messages]);
}

// 注册REST API路由
add_action('rest_api_init', function () {
    register_rest_route('xb_apps_ai/v1', '/send-message', [
        'methods' => 'POST',
        'callback' => 'xb_apps_ai_send_message',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ]);
    register_rest_route('xb_apps_ai/v1', '/tts', [
        'methods' => 'POST',
        'callback' => 'xb_apps_ai_tts_request',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ]);
});

// 处理消息发送
function xb_apps_ai_send_message(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . XB_APPS_AI_TABLE;
    $user_id = get_current_user_id();
    $message = sanitize_text_field($request->get_param('message'));
    $app_id = sanitize_text_field($request->get_param('app_id'));
    $session_id = sanitize_text_field($request->get_param('session_id') ?? '');
    $provider = sanitize_text_field($request->get_param('provider'));

    if (empty($message) || empty($app_id) || empty($provider)) {
        header('Content-Type: text/event-stream; charset=UTF-8');
        echo "data: " . json_encode(['error' => '缺少必要参数'], JSON_UNESCAPED_UNICODE) . "\n\n";
        flush();
        exit;
    }

    $agents = get_option('xb_apps_ai_agents', []);
    $agent = array_filter($agents, function ($a) use ($app_id) {
        return $a['app_id'] === $app_id;
    });
    $agent = reset($agent);

    if (!$agent || !isset($agent['provider'])) {
        header('Content-Type: text/event-stream; charset=UTF-8');
        echo "data: " . json_encode(['error' => '智能体未找到或配置无效'], JSON_UNESCAPED_UNICODE) . "\n\n";
        flush();
        exit;
    }

    // 保存用户消息
    $wpdb->insert($table_name, [
        'user_id' => $user_id,
        'app_id' => $app_id,
        'message' => $message,
        'response' => '',
        'session_id' => $session_id ?: null,
        'audio_task_id' => '',
        'audio_url' => '',
        'created_at' => current_time('mysql')
    ]);
    if ($wpdb->last_error) {
        error_log("保存用户消息失败: " . $wpdb->last_error);
        header('Content-Type: text/event-stream; charset=UTF-8');
        echo "data: " . json_encode(['error' => '保存消息失败'], JSON_UNESCAPED_UNICODE) . "\n\n";
        flush();
        exit;
    }
    $message_id = $wpdb->insert_id; // 获取用户消息的ID

    // 设置流式输出头
    while (ob_get_level() > 0) ob_end_clean();
    ini_set('output_buffering', 'off');
    ini_set('zlib.output_compression', false);
    header('Content-Type: text/event-stream; charset=UTF-8');
    header('Cache-Control: no-cache');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no');

    $full_response = '';
    $current_session_id = $session_id;
    $response_message_id = null; // 用于存储AI回复的记录ID

    // 配置API请求
    switch ($provider) {
        case 'ali':
            $api_key = get_option('xb_apps_ai_ali_api_key');
            if (empty($api_key)) {
                echo "data: " . json_encode(['error' => '阿里API Key未配置'], JSON_UNESCAPED_UNICODE) . "\n\n";
                flush();
                exit;
            }
            $url = "https://dashscope.aliyuncs.com/api/v1/apps/{$app_id}/completion";
            $headers = [
                "Authorization: Bearer $api_key",
                "Content-Type: application/json; charset=UTF-8",
                "X-DashScope-SSE: enable"
            ];
            $body = [
                'input' => ['prompt' => $message],
                'parameters' => ['incremental_output' => true],
                'debug' => []
            ];
            if ($session_id) {
                $body['input']['session_id'] = $session_id;
            }
            $body = json_encode($body, JSON_UNESCAPED_UNICODE);
            break;

        case 'coze':
            $access_token = get_option('xb_apps_ai_coze_access_token');
            $expiry = get_option('xb_apps_ai_coze_access_token_expiry');
            if (empty($access_token)) {
                echo "data: " . json_encode(['error' => '扣子平台Access Token未配置'], JSON_UNESCAPED_UNICODE) . "\n\n";
                flush();
                exit;
            }
            if ($expiry && strtotime($expiry) < time()) {
                echo "data: " . json_encode(['error' => '扣子平台Access Token已过期，请更新'], JSON_UNESCAPED_UNICODE) . "\n\n";
                flush();
                exit;
            }
            $url = "https://api.coze.cn/v3/chat";
            $headers = [
                "Authorization: Bearer $access_token",
                "Content-Type: application/json; charset=UTF-8"
            ];
            $body = [
                'bot_id' => $app_id,
                'user_id' => strval($user_id),
                'stream' => true,
                'auto_save_history' => true,
                'additional_messages' => [
                    ['role' => 'user', 'content' => $message]
                ]
            ];
            if ($session_id) {
                $body['conversation_id'] = $session_id;
            }
            $body = json_encode($body, JSON_UNESCAPED_UNICODE);
            break;

        case 'tencent':
            $token = $agent['token'] ?? '';
            if (empty($token)) {
                echo "data: " . json_encode(['error' => '腾讯智能体Token未配置'], JSON_UNESCAPED_UNICODE) . "\n\n";
                flush();
                exit;
            }
            $url = "https://open.hunyuan.tencent.com/openapi/v1/agent/chat/completions";
            $headers = [
                "X-Source: openapi",
                "Content-Type: application/json; charset=UTF-8",
                "Authorization: Bearer $token"
            ];
            $body = [
                "assistant_id" => $app_id,
                "user_id" => strval($user_id),
                "stream" => true,
                "messages" => [
                    [
                        "role" => "user",
                        "content" => [
                            ["type" => "text", "text" => $message]
                        ]
                    ]
                ]
            ];
            $body = json_encode($body, JSON_UNESCAPED_UNICODE);
            break;

        case 'volc':
            $api_key = get_option('xb_apps_ai_volc_api_key');
            if (empty($api_key)) {
                echo "data: " . json_encode(['error' => '火山引擎API Key未配置'], JSON_UNESCAPED_UNICODE) . "\n\n";
                flush();
                exit;
            }
            $url = "https://ark.cn-beijing.volces.com/api/v3/bots/chat/completions";
            $headers = [
                "Authorization: Bearer $api_key",
                "Content-Type: application/json; charset=UTF-8"
            ];
            $body = [
                'model' => $app_id,
                'stream' => true,
                'messages' => [
                    ['role' => 'user', 'content' => $message]
                ]
            ];
            $body = json_encode($body, JSON_UNESCAPED_UNICODE);
            break;

        default:
            echo "data: " . json_encode(['error' => '未知的智能体提供商'], JSON_UNESCAPED_UNICODE) . "\n\n";
            flush();
            exit;
    }

    // 定义响应处理函数
    $write_function = function ($ch, $data) use (&$full_response, &$current_session_id, &$response_message_id, $provider, $app_id, $user_id, $table_name) {
        global $wpdb;
        $data = mb_convert_encoding($data, 'UTF-8', 'UTF-8');
        $lines = explode("\n", $data);
        $should_flush = false;
        $event = null;

        foreach ($lines as $line) {
            $line = trim($line);

            if ($provider === 'coze' && strpos($line, 'event:') === 0) {
                $event = trim(substr($line, 6));
                continue;
            }

            if ($line && strpos($line, 'data:') === 0) {
                $json_str = trim(substr($line, 5));
                if ($json_str === '[DONE]') {
                    if (!empty($full_response) && $response_message_id) {
                        // 更新最终的AI回复
                        $wpdb->update(
                            $table_name,
                            ['response' => $full_response, 'session_id' => $current_session_id],
                            ['id' => $response_message_id],
                            ['%s', '%s'],
                            ['%d']
                        );
                        echo "data: " . json_encode(['message_id' => $response_message_id], JSON_UNESCAPED_UNICODE) . "\n\n";
                    }
                    echo "data: [DONE]\n\n";
                    $should_flush = true;
                    continue;
                }

                $json_data = json_decode($json_str, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    error_log("JSON decode error: " . json_last_error_msg());
                    continue;
                }

                $text = '';
                switch ($provider) {
                    case 'ali':
                        if (isset($json_data['output']['text']) && !empty($json_data['output']['text'])) {
                            $text = $json_data['output']['text'];
                            $full_response .= $text;
                            if (isset($json_data['output']['session_id'])) {
                                $current_session_id = $json_data['output']['session_id'];
                            }
                        }
                        break;

                    case 'coze':
                        if (isset($event) && $event === 'conversation.message.delta' && 
                            isset($json_data['content']) && 
                            isset($json_data['role']) && $json_data['role'] === 'assistant' && 
                            isset($json_data['type']) && $json_data['type'] === 'answer') {
                            $text = $json_data['content'];
                            $full_response .= $text;
                            if (isset($json_data['conversation_id'])) {
                                $current_session_id = $json_data['conversation_id'];
                            }
                        }
                        break;

                    case 'tencent':
                        if (isset($json_data['choices'][0]['delta']['role']) && 
                            $json_data['choices'][0]['delta']['role'] === 'assistant' && 
                            isset($json_data['choices'][0]['delta']['content'])) {
                            $text = $json_data['choices'][0]['delta']['content'];
                            $full_response .= $text;
                        }
                        break;

                    case 'volc':
                        if (isset($json_data['choices'][0]['delta']['content'])) {
                            $text = $json_data['choices'][0]['delta']['content'];
                            $full_response .= $text;
                        }
                        break;
                }

                if ($text) {
                    if (!$response_message_id) {
                        // 插入初始AI回复记录
                        $wpdb->insert($table_name, [
                            'user_id' => $user_id,
                            'app_id' => $app_id,
                            'message' => '',
                            'response' => $full_response,
                            'session_id' => $current_session_id,
                            'audio_task_id' => '',
                            'audio_url' => '',
                            'created_at' => current_time('mysql')
                        ]);
                        $response_message_id = $wpdb->insert_id;
                        if ($wpdb->last_error) {
                            error_log("插入AI回复失败: " . $wpdb->last_error);
                            echo "data: " . json_encode(['error' => '保存AI回复失败'], JSON_UNESCAPED_UNICODE) . "\n\n";
                            $should_flush = true;
                        } else {
                            echo "data: " . json_encode(['text' => $text, 'session_id' => $current_session_id, 'message_id' => $response_message_id], JSON_UNESCAPED_UNICODE) . "\n\n";
                            $should_flush = true;
                        }
                    } else {
                        // 更新AI回复
                        $wpdb->update(
                            $table_name,
                            ['response' => $full_response, 'session_id' => $current_session_id],
                            ['id' => $response_message_id],
                            ['%s', '%s'],
                            ['%d']
                        );
                        if ($wpdb->last_error) {
                            error_log("更新AI回复失败: " . $wpdb->last_error);
                            echo "data: " . json_encode(['error' => '更新AI回复失败'], JSON_UNESCAPED_UNICODE) . "\n\n";
                            $should_flush = true;
                        } else {
                            echo "data: " . json_encode(['text' => $text, 'session_id' => $current_session_id, 'message_id' => $response_message_id], JSON_UNESCAPED_UNICODE) . "\n\n";
                            $should_flush = true;
                        }
                    }
                }
            }
        }

        if ($should_flush) flush();
        return strlen($data);
    };

    // 执行cURL请求
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
    curl_setopt($ch, CURLOPT_WRITEFUNCTION, $write_function);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);

    $result = curl_exec($ch);
    if ($result === false) {
        $curl_error = curl_error($ch);
        $curl_errno = curl_errno($ch);
        error_log("cURL Error ($curl_errno): $curl_error");
        echo "data: " . json_encode(['error' => "数据获取失败（错误代码: $curl_errno - $curl_error），请重试"], JSON_UNESCAPED_UNICODE) . "\n\n";
        echo "data: [DONE]\n\n";
        flush();
    } else {
        echo "data: [DONE]\n\n";
        flush();
    }
    curl_close($ch);
    exit;
}

// 处理语音合成请求
function xb_apps_ai_tts_request(WP_REST_Request $request) {
    // 检查语音功能是否启用
    if (get_option('xb_apps_ai_tts_enabled', '1') !== '1') {
        return new WP_REST_Response(['error' => '语音功能已禁用'], 403);
    }

    global $wpdb;
    $table_name = $wpdb->prefix . XB_APPS_AI_TABLE;
    $message_id = intval($request->get_param('message_id'));
    $text = sanitize_text_field($request->get_param('text'));
    $user_id = get_current_user_id();

    error_log("TTS Request: message_id=$message_id, user_id=$user_id, text=$text");

    if (empty($message_id) || empty($text)) {
        error_log("TTS Error: Missing parameters");
        return new WP_REST_Response(['error' => '缺少必要参数'], 400);
    }

    // 检查消息是否存在且属于当前用户
    $message = $wpdb->get_row($wpdb->prepare(
        "SELECT id, audio_task_id, audio_url FROM $table_name WHERE id = %d AND user_id = %d",
        $message_id, $user_id
    ));

    if (!$message) {
        error_log("TTS Error: Message not found or no permission, message_id=$message_id, user_id=$user_id");
        return new WP_REST_Response(['error' => '消息不存在或无权限'], 403);
    }

    // 如果已有音频URL，直接返回
    if (!empty($message->audio_url)) {
        return new WP_REST_Response([
            'task_id' => $message->audio_task_id,
            'audio_url' => $message->audio_url,
            'status' => 'completed'
        ], 200);
    }

    // 如果有任务ID，检查状态
    if (!empty($message->audio_task_id)) {
        $tts_status = aliyun_tts_get_status($message->audio_task_id);
        if ($tts_status && isset($tts_status['status']) && $tts_status['status'] === 'completed' && !empty($tts_status['audio_url'])) {
            // 更新数据库中的audio_url
            $wpdb->update(
                $table_name,
                ['audio_url' => $tts_status['audio_url']],
                ['id' => $message_id],
                ['%s'],
                ['%d']
            );
            return new WP_REST_Response([
                'task_id' => $tts_status['task_id'],
                'audio_url' => $tts_status['audio_url'],
                'status' => $tts_status['status']
            ], 200);
        }
    }

    // 发起新的语音合成请求
    $tts_result = aliyun_tts_convert_text($text);
    if (isset($tts_result['error'])) {
        error_log('阿里云TTS请求失败: ' . $tts_result['error']);
        return new WP_REST_Response(['error' => $tts_result['error']], 500);
    }

    // 更新数据库中的audio_task_id
    $updated = $wpdb->update(
        $table_name,
        ['audio_task_id' => $tts_result['task_id']],
        ['id' => $message_id],
        ['%s'],
        ['%d']
    );

    if ($updated === false) {
        error_log('更新语音任务ID失败: 消息ID ' . $message_id);
        return new WP_REST_Response(['error' => '数据库更新失败'], 500);
    }

    return new WP_REST_Response([
        'task_id' => $tts_result['task_id'],
        'status' => $tts_result['status']
    ], 200);
}

// 后台设置页面
add_action('admin_menu', 'xb_apps_ai_admin_menu');
function xb_apps_ai_admin_menu() {
    add_menu_page(
        '智能体设置',
        '智能体设置',
        'manage_options',
        'xb-apps-ai',
        'xb_apps_ai_settings_page',
        'dashicons-admin-generic'
    );
    add_submenu_page(
        'xb-apps-ai',
        '对话记录',
        '对话记录',
        'manage_options',
        'xb-apps-ai-logs',
        'xb_apps_ai_logs_page'
    );
}

function xb_apps_ai_settings_page() {
    $saved = isset($_GET['settings-updated']) && $_GET['settings-updated'] === 'true';
    ?>
    <div class="xb-apps-ai-wrap">
        <h1>智能体应用管理</h1>
        <form method="post" action="options.php">
            <?php settings_fields('xb_apps_ai_group'); ?>
            <div class="xb-apps-ai-section">
                <h2>API 配置</h2>
                <?php do_settings_sections('xb-apps-ai'); ?>
                <p>
                    <strong>广告内容</strong><br>
                    <textarea name="xb_apps_ai_ad_content" rows="5" style="width: 500px;"><?php echo esc_textarea(get_option('xb_apps_ai_ad_content')); ?></textarea>
                    <p class="description">支持HTML格式的广告内容，将显示在前台页面底部。</p>
                </p>
                <p>
                    <strong>语音功能</strong><br>
                    <input type="checkbox" name="xb_apps_ai_tts_enabled" value="1" <?php checked(get_option('xb_apps_ai_tts_enabled', '1'), '1'); ?> />
                    <label for="xb_apps_ai_tts_enabled">启用语音播放功能</label>
                    <p class="description">勾选后，前台将显示语音播放按钮；取消勾选将禁用语音功能。</p>
                </p>
            </div>
            <div class="xb-apps-ai-section">
                <h2>智能体应用列表</h2>
                <?php xb_apps_ai_agents_list_callback(); ?>
            </div>
            <?php submit_button('保存设置'); ?>
        </form>
        <div class="xb-apps-ai-success" <?php echo $saved ? 'style="display: block;"' : ''; ?>>设置已保存</div>
    </div>
    <?php if ($saved) : ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
        const successMessage = document.querySelector('.xb-apps-ai-success');
        if (successMessage && successMessage.style.display === 'block') {
            setTimeout(() => {
                successMessage.style.transition = 'opacity 0.5s ease';
                successMessage.style.opacity = '0';
                setTimeout(() => {
                    successMessage.style.display = 'none';
                    successMessage.style.opacity = '1'; // 重置透明度以备下次使用
                }, 500);
            }, 3000);
        }
    });
    </script>
    <?php endif; ?>
    <?php
}

function xb_apps_ai_logs_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . XB_APPS_AI_TABLE;
    $search_user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : '';

    $per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;

    $where_clause = $search_user_id ? $wpdb->prepare("WHERE user_id = %d", $search_user_id) : '';
    $total_logs = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where_clause");
    $logs = $wpdb->get_results($wpdb->prepare(
        "SELECT l.id, l.user_id, l.app_id, l.message, l.response, l.created_at, l.audio_task_id, l.audio_url, u.user_login 
         FROM $table_name l
         LEFT JOIN {$wpdb->users} u ON l.user_id = u.ID 
         $where_clause 
         ORDER BY l.created_at DESC 
         LIMIT %d OFFSET %d",
        $per_page, $offset
    ));

    $agents = get_option('xb_apps_ai_agents', []);
    $agent_map = [];
    foreach ($agents as $agent) {
        $agent_map[$agent['app_id']] = $agent['name'];
    }

    ?>
    <div class="wrap">
        <h1>智能体对话记录</h1>
        <form method="get" class="search-form" style="margin-bottom: 20px;">
            <input type="hidden" name="page" value="xb-apps-ai-logs">
            <label for="user_id">按用户ID搜索: </label>
            <input type="number" name="user_id" id="user_id" value="<?php echo esc_attr($search_user_id); ?>" min="1" style="width: 100px;">
            <input type="submit" class="button" value="搜索">
            <?php if ($search_user_id): ?>
                <a href="?page=xb-apps-ai-logs" class="button">显示所有记录</a>
            <?php endif; ?>
        </form>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width: 80px;">用户ID</th>
                    <th style="width: 150px;">用户名</th>
                    <th style="width: 200px;">智能体</th>
                    <th style="width: 300px;">用户消息</th>
                    <th style="width: 300px;">智能体回复</th>
                    <th style="width: 100px;">语音任务ID</th>
                    <th style="width: 150px;">音频URL</th>
                    <th style="width: 160px;">时间</th>
                    <th style="width: 100px;">操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($logs) : ?>
                    <?php foreach ($logs as $log) : ?>
                        <tr data-id="<?php echo esc_attr($log->id); ?>">
                            <td><?php echo esc_html($log->user_id); ?></td>
                            <td><?php echo esc_html($log->user_login ?: '未知用户'); ?></td>
                            <td><?php echo esc_html($agent_map[$log->app_id] ?? $log->app_id); ?></td>
                            <td><?php echo esc_html(mb_strimwidth($log->message, 0, 50, '...', 'UTF-8')); ?></td>
                            <td><?php echo esc_html(mb_strimwidth($log->response, 0, 50, '...', 'UTF-8')); ?></td>
                            <td><?php echo esc_html($log->audio_task_id ?: '-'); ?></td>
                            <td><?php echo esc_html($log->audio_url ?: '-'); ?></td>
                            <td><?php echo esc_html($log->created_at); ?></td>
                            <td><button class="button xb-apps-ai-delete-log">删除</button></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr><td colspan="9">暂无记录。</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php if ($total_logs > $per_page): ?>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <?php
                    $total_pages = ceil($total_logs / $per_page);
                    $args = [
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => __('« 上一页'),
                        'next_text' => __('下一页 »'),
                        'total' => $total_pages,
                        'current' => $current_page,
                    ];
                    if ($search_user_id) {
                        $args['add_args'] = ['user_id' => $search_user_id];
                    }
                    echo paginate_links($args);
                    ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.xb-apps-ai-delete-log').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                if (!confirm('确定要删除此对话记录吗？')) return;

                const row = this.closest('tr');
                const id = row.getAttribute('data-id');

                const data = new URLSearchParams({
                    action: 'xb_apps_ai_delete_log',
                    id: id,
                    _ajax_nonce: '<?php echo wp_create_nonce('xb_apps_ai_delete_log_nonce'); ?>'
                });

                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: data
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        row.remove();
                        alert('记录已删除');
                    } else {
                        alert('删除失败: ' + (data.data?.message || '未知错误'));
                    }
                })
                .catch(error => {
                    alert('删除请求失败，请稍后重试');
                });
            });
        });
    });
    </script>
    <?php
}

// 注册设置
add_action('admin_init', 'xb_apps_ai_register_settings');
function xb_apps_ai_register_settings() {
    register_setting('xb_apps_ai_group', 'xb_apps_ai_ali_api_key', 'sanitize_text_field');
    register_setting('xb_apps_ai_group', 'xb_apps_ai_coze_access_token', 'sanitize_text_field');
    register_setting('xb_apps_ai_group', 'xb_apps_ai_coze_access_token_expiry', 'xb_apps_ai_sanitize_expiry');
    register_setting('xb_apps_ai_group', 'xb_apps_ai_volc_api_key', 'sanitize_text_field');
    register_setting('xb_apps_ai_group', 'xb_apps_ai_ad_content', 'wp_kses_post');
    register_setting('xb_apps_ai_group', 'xb_apps_ai_agents', 'xb_apps_ai_sanitize_agents');
    register_setting('xb_apps_ai_group', 'xb_apps_ai_tts_enabled', 'sanitize_text_field'); // 新增语音功能开关设置

    add_settings_section('xb_apps_ai_section', '', null, 'xb-apps-ai');
    add_settings_field('xb_apps_ai_ali_api_key', '阿里百炼API Key', 'xb_apps_ai_ali_api_key_callback', 'xb-apps-ai', 'xb_apps_ai_section');
    add_settings_field('xb_apps_ai_coze_access_token', '扣子访问令牌', 'xb_apps_ai_coze_access_token_callback', 'xb-apps-ai', 'xb_apps_ai_section');
    add_settings_field('xb_apps_ai_volc_api_key', '火山引擎API Key', 'xb_apps_ai_volc_api_key_callback', 'xb-apps-ai', 'xb_apps_ai_section');
}

function xb_apps_ai_ali_api_key_callback() {
    $api_key = get_option('xb_apps_ai_ali_api_key');
    echo '<input type="text" name="xb_apps_ai_ali_api_key" value="' . esc_attr($api_key) . '" style="width: 500px;" />';
    echo '<p class="description">输入阿里百炼应用的API Key。</p>';
}

function xb_apps_ai_coze_access_token_callback() {
    $token = get_option('xb_apps_ai_coze_access_token');
    $expiry = get_option('xb_apps_ai_coze_access_token_expiry');
    ?>
    <input type="text" name="xb_apps_ai_coze_access_token" value="<?php echo esc_attr($token); ?>" style="width: 500px;" />
    <p class="description">输入扣子平台的个人访问令牌。</p>
    <p>
        <label for="xb_apps_ai_coze_access_token_expiry">Token 到期时间：</label><br>
        <input type="datetime-local" id="xb_apps_ai_coze_access_token_expiry" name="xb_apps_ai_coze_access_token_expiry" value="<?php echo esc_attr($expiry); ?>" />
        <p class="description">设置Token的到期时间，例如：2025-03-01</p>
    </p>
    <?php if ($expiry) : ?>
        <p style="color: #d63638;">当前Token到期时间：<?php echo esc_html(date('Y-m-d H:i', strtotime($expiry))); ?></p>
    <?php endif; ?>
    <?php
}

function xb_apps_ai_volc_api_key_callback() {
    $api_key = get_option('xb_apps_ai_volc_api_key');
    echo '<input type="text" name="xb_apps_ai_volc_api_key" value="' . esc_attr($api_key) . '" style="width: 500px;" />';
    echo '<p class="description">输入火山引擎应用的API Key。</p>';
}

function xb_apps_ai_agents_list_callback() {
    $agents = get_option('xb_apps_ai_agents', []);
    ?>
    <table class="widefat" id="xb-apps-ai-agents-table">
        <thead>
            <tr>
                <th>提供商</th>
                <th>名称</th>
                <th>应用ID</th>
                <th>腾讯Token</th>
                <th>启用</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($agents as $index => $agent) : ?>
                <tr>
                    <td>
                        <select name="xb_apps_ai_agents[<?php echo $index; ?>][provider]" onchange="xbAppsAiToggleTokenField(this)">
                            <option value="ali" <?php selected($agent['provider'], 'ali'); ?>>阿里百炼</option>
                            <option value="coze" <?php selected($agent['provider'], 'coze'); ?>>扣子</option>
                            <option value="tencent" <?php selected($agent['provider'], 'tencent'); ?>>腾讯</option>
                            <option value="volc" <?php selected($agent['provider'], 'volc'); ?>>火山引擎</option>
                        </select>
                    </td>
                    <td><input type="text" name="xb_apps_ai_agents[<?php echo $index; ?>][name]" value="<?php echo esc_attr($agent['name']); ?>" /></td>
                    <td><input type="text" name="xb_apps_ai_agents[<?php echo $index; ?>][app_id]" value="<?php echo esc_attr($agent['app_id']); ?>" /></td>
                    <td>
                        <?php if ($agent['provider'] === 'tencent') : ?>
                            <input type="text" name="xb_apps_ai_agents[<?php echo $index; ?>][token]" value="<?php echo esc_attr($agent['token'] ?? ''); ?>" style="width: 200px;" />
                        <?php else : ?>
                            <span>-</span>
                        <?php endif; ?>
                    </td>
                    <td><input type="checkbox" name="xb_apps_ai_agents[<?php echo $index; ?>][active]" value="1" <?php checked($agent['active'] ?? 0, 1); ?> /></td>
                    <td><button type="button" class="button xb-apps-ai-delete-agent">删除</button></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <button type="button" class="button" id="xb-apps-ai-add-agent">添加新智能体</button>
    <script>
    document.getElementById('xb-apps-ai-add-agent').addEventListener('click', function() {
        const table = document.getElementById('xb-apps-ai-agents-table').getElementsByTagName('tbody')[0];
        const rowCount = table.rows.length;
        const row = table.insertRow();
        row.innerHTML = `
            <td>
                <select name="xb_apps_ai_agents[${rowCount}][provider]" onchange="xbAppsAiToggleTokenField(this)">
                    <option value="ali">阿里百炼</option>
                    <option value="coze">扣子</option>
                    <option value="tencent">腾讯</option>
                    <option value="volc">火山引擎</option>
                </select>
            </td>
            <td><input type="text" name="xb_apps_ai_agents[${rowCount}][name]" value="" /></td>
            <td><input type="text" name="xb_apps_ai_agents[${rowCount}][app_id]" value="" /></td>
            <td><span>-</span></td>
            <td><input type="checkbox" name="xb_apps_ai_agents[${rowCount}][active]" value="1" /></td>
            <td><button type="button" class="button xb-apps-ai-delete-agent">删除</button></td>
        `;
    });

    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('xb-apps-ai-delete-agent')) {
            e.target.closest('tr').remove();
        }
    });

    function xbAppsAiToggleTokenField(select) {
        const row = select.closest('tr');
        const tokenCell = row.cells[3];
        if (select.value === 'tencent') {
            tokenCell.innerHTML = `<input type="text" name="${select.name.replace('provider', 'token')}" value="" style="width: 200px;" />`;
        } else {
            tokenCell.innerHTML = '<span>-</span>';
        }
    }
    </script>
    <?php
}

function xb_apps_ai_sanitize_agents($input) {
    $agents = [];
    if (is_array($input)) {
        foreach ($input as $agent) {
            if (!empty($agent['name']) && !empty($agent['app_id'])) {
                $sanitized_agent = [
                    'provider' => sanitize_text_field($agent['provider'] ?? 'ali'),
                    'name' => sanitize_text_field($agent['name']),
                    'app_id' => sanitize_text_field($agent['app_id']),
                    'active' => isset($agent['active']) && $agent['active'] == '1' ? 1 : 0
                ];
                if ($agent['provider'] === 'tencent' && !empty($agent['token'])) {
                    $sanitized_agent['token'] = sanitize_text_field($agent['token']);
                }
                $agents[] = $sanitized_agent;
            }
        }
    }
    return $agents;
}

function xb_apps_ai_sanitize_expiry($input) {
    if (empty($input)) {
        return '';
    }
    $timestamp = strtotime($input);
    if ($timestamp === false) {
        add_settings_error('xb_apps_ai_group', 'invalid_expiry', 'Token 到期时间格式无效', 'error');
        return get_option('xb_apps_ai_coze_access_token_expiry');
    }
    return date('Y-m-d\TH:i', $timestamp);
}

// 删除对话记录
add_action('wp_ajax_xb_apps_ai_delete_log', 'xb_apps_ai_delete_log');
function xb_apps_ai_delete_log() {
    check_ajax_referer('xb_apps_ai_delete_log_nonce');
    global $wpdb;
    $table_name = $wpdb->prefix . XB_APPS_AI_TABLE;
    if (!isset($_POST['id'])) {
        wp_send_json_error(['message' => '缺少记录ID']);
        return;
    }

    $id = intval($_POST['id']);
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => '无权删除记录']);
        return;
    }

    $deleted = $wpdb->delete($table_name, ['id' => $id], ['%d']);
    if ($wpdb->last_error) {
        error_log("删除对话记录失败: " . $wpdb->last_error);
        wp_send_json_error(['message' => '删除失败: ' . $wpdb->last_error]);
    } elseif ($deleted === 0) {
        wp_send_json_error(['message' => '没有找到匹配的记录']);
    } else {
        wp_send_json_success(['message' => '记录已删除']);
    }
}

// 清除对话记录
add_action('wp_ajax_xb_apps_ai_clear_conversation', 'xb_apps_ai_clear_conversation');
function xb_apps_ai_clear_conversation() {
    check_ajax_referer('xb_apps_ai_nonce');
    global $wpdb;
    $table_name = $wpdb->prefix . XB_APPS_AI_TABLE;
    $app_id = sanitize_text_field($_POST['app_id'] ?? '');
    $user_id = get_current_user_id();

    if (!$user_id) {
        wp_send_json(['success' => false, 'message' => '请先登录']);
        return;
    }

    if (empty($app_id)) {
        wp_send_json(['success' => false, 'message' => '缺少智能体应用 ID']);
        return;
    }

    $deleted = $wpdb->delete($table_name, ['user_id' => $user_id, 'app_id' => $app_id], ['%d', '%s']);
    if ($wpdb->last_error) {
        error_log("清除对话记录失败: " . $wpdb->last_error);
        wp_send_json(['success' => false, 'message' => '清除失败: 数据库错误']);
    } else {
        wp_send_json(['success' => true, 'message' => '对话记录已清除']);
    }
}

// 插件卸载清理
register_uninstall_hook(__FILE__, 'xb_apps_ai_cleanup');
function xb_apps_ai_cleanup() {
    global $wpdb;
    $table_name = $wpdb->prefix . XB_APPS_AI_TABLE;
    $wpdb->query("DROP TABLE IF EXISTS $table_name");
    delete_option('xb_apps_ai_ali_api_key');
    delete_option('xb_apps_ai_coze_access_token');
    delete_option('xb_apps_ai_coze_access_token_expiry');
    delete_option('xb_apps_ai_volc_api_key');
    delete_option('xb_apps_ai_ad_content');
    delete_option('xb_apps_ai_agents');
    delete_option('xb_apps_ai_tts_enabled'); // 删除语音功能设置
    $page = get_page_by_path('ai-agent');
    if ($page) {
        wp_delete_post($page->ID, true);
    }
}
?>