<?php
/*
Plugin Name: 小半图像文字OCR
Description: 基于百度云的图像文字识别插件，支持前台上传图片并识别文字。
Version: 1.0.1
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 插件激活时执行
 */
register_activation_hook(__FILE__, 'xb_imgocr_activate');
function xb_imgocr_activate() {
    xb_imgocr_create_table();
    xb_imgocr_create_front_page();
}

/**
 * 创建数据库表
 */
function xb_imgocr_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_imgocr_records';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        result_status VARCHAR(20) NOT NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

/**
 * 创建前台页面
 */
function xb_imgocr_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_imgocr_frontend]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page = array(
            'post_title'   => '图像文字识别',
            'post_content' => '[xb_imgocr_frontend]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        );
        wp_insert_post($page);
    }
}

/**
 * 加载前端 JS 和 CSS
 */
function xb_imgocr_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_imgocr_frontend')) {
        wp_enqueue_script(
            'xb-img-ocr-js',
            plugin_dir_url(__FILE__) . 'xb-img-ocr.js',
            array('jquery'),
            '1.0.1',
            true
        );
        wp_localize_script(
            'xb-img-ocr-js',
            'xb_imgocr_params',
            array(
                'ajax_url' => rest_url('xb-img-ocr/v1'),
                'nonce'    => wp_create_nonce('wp_rest'),
            )
        );
        wp_enqueue_style(
            'xb-img-ocr-css',
            plugin_dir_url(__FILE__) . 'xb-img-ocr.css',
            array(),
            '1.0.1'
        );
    }
}
add_action('wp_enqueue_scripts', 'xb_imgocr_enqueue_scripts');

/**
 * 注册短代码
 */
function xb_imgocr_frontend_shortcode() {
    ob_start();
    ?>
    <div class="xb-img-ocr-container">
        <div class="xb-img-ocr-title">图像文字识别</div>
        <?php if (!is_user_logged_in()): ?>
            <div class="xb-img-ocr-login-prompt">
                请先登录才能使用图像OCR文字识别功能
                <a href="<?php echo wp_login_url(get_permalink()); ?>" class="xb-img-ocr-login-btn">快速登录</a>
            </div>
            <?php
            $announcement = get_option('xb_imgocr_announcement', '');
            if ($announcement):
            ?>
                <div class="xb-img-ocr-announcement"><?php echo wp_kses_post($announcement); ?></div>
            <?php endif; ?>
        <?php else: ?>
            <?php
            global $wpdb;
            $table_name = $wpdb->prefix . 'xb_imgocr_records';
            $user_id = get_current_user_id();
            $daily_limit = get_option('xb_imgocr_daily_limit', 10);
            $custom_limit = get_user_meta($user_id, 'xb_imgocr_custom_limit', true);
            $limit = $custom_limit !== '' ? (int)$custom_limit : $daily_limit;
            $today = gmdate('Y-m-d', current_time('timestamp'));
            $used_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND result_status = 'success' AND DATE(created_at) = %s",
                $user_id,
                $today
            ));
            $remaining = max(0, $limit - $used_count);
            $is_exhausted = $remaining <= 0;
            ?>
            <?php if (!$is_exhausted): ?>
                <div class="xb-img-ocr-content">
                    <div class="xb-img-ocr-left">
                        <div class="xb-img-ocr-panel-title">图片配置</div>
                        <div class="xb-img-ocr-upload">
                            <input type="file" id="xb-img-ocr-file" accept="<?php echo esc_attr(get_option('xb_imgocr_image_formats', 'jpg,jpeg,png,bmp')); ?>">
                            <button id="xb-img-ocr-upload-btn">上传图片</button>
                        </div>
                        <div class="xb-img-ocr-preview">
                            <img id="xb-img-ocr-preview-img" src="" alt="图片预览" style="display:none;">
                        </div>
                        <div class="xb-img-ocr-options">
                            <label>图像文字语言：
                                <select id="xb-img-ocr-language">
                                    <?php
                                    $languages = explode(',', get_option('xb_imgocr_languages', 'CHN_ENG'));
                                    $language_names = array(
                                        'CHN_ENG' => '中英文混合',
                                        'ENG' => '英文',
                                        'JAP' => '日语',
                                        'KOR' => '韩语',
                                        'FRE' => '法语',
                                        'SPA' => '西班牙语',
                                        'POR' => '葡萄牙语',
                                        'GER' => '德语',
                                        'ITA' => '意大利语',
                                        'RUS' => '俄语',
                                    );
                                    foreach ($languages as $lang) {
                                        $name = isset($language_names[$lang]) ? $language_names[$lang] : $lang;
                                        echo '<option value="' . esc_attr($lang) . '">' . esc_html($name) . '</option>';
                                    }
                                    ?>
                                </select>
                            </label>
                            <?php if (get_option('xb_imgocr_paragraph_enabled', 'true') === 'true'): ?>
                                <label>输出段落信息：
                                    <div class="xb-img-ocr-toggle" id="xb-img-ocr-paragraph-toggle" data-state="false">
                                        <span class="xb-img-ocr-toggle-label">关闭</span>
                                        <div class="xb-img-ocr-toggle-switch"></div>
                                    </div>
                                </label>
                            <?php endif; ?>
                            <?php if (get_option('xb_imgocr_probability_enabled', 'true') === 'true'): ?>
                                <label>返回每一行置信度：
                                    <div class="xb-img-ocr-toggle" id="xb-img-ocr-probability-toggle" data-state="false">
                                        <span class="xb-img-ocr-toggle-label">关闭</span>
                                        <div class="xb-img-ocr-toggle-switch"></div>
                                    </div>
                                </label>
                            <?php endif; ?>
                            <button id="xb-img-ocr-process-btn">开始识别</button>
                        </div>
                    </div>
                    <div class="xb-img-ocr-right">
                        <div class="xb-img-ocr-panel-title">识别结果</div>
                        <div id="xb-img-ocr-processing" style="display:none;">正在识别中...</div>
                        <div id="xb-img-ocr-result"></div>
                        <button id="xb-img-ocr-copy-btn" style="display:none;">一键复制</button>
                    </div>
                </div>
            <?php endif; ?>
            <div class="xb-img-ocr-usage">
                <?php if ($is_exhausted): ?>
                    今日使用次数已经用完，请明天再来
                <?php else: ?>
                    今日剩余识别次数：<span class="xb-img-ocr-remaining"><?php echo esc_html($remaining); ?></span>/<?php echo esc_html($limit); ?>
                <?php endif; ?>
            </div>
            <?php
            $announcement = get_option('xb_imgocr_announcement', '');
            if ($announcement):
            ?>
                <div class="xb-img-ocr-announcement"><?php echo wp_kses_post($announcement); ?></div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <div id="xb-img-ocr-notification" class="xb-img-ocr-notification" style="display:none;">
        <span id="xb-img-ocr-notification-text"></span>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('xb_imgocr_frontend', 'xb_imgocr_frontend_shortcode');

/**
 * 注册 REST API 路由
 */
function xb_imgocr_register_rest_routes() {
    register_rest_route('xb-img-ocr/v1', '/process', array(
        'methods'  => 'POST',
        'callback' => 'xb_imgocr_process_image',
        'permission_callback' => function () {
            if (!is_user_logged_in()) {
                error_log('REST API Error: User not logged in');
                return new WP_Error('not_logged_in', '请先登录', array('status' => 401));
            }
            if (!isset($_SERVER['HTTP_X_WP_NONCE']) || !wp_verify_nonce($_SERVER['HTTP_X_WP_NONCE'], 'wp_rest')) {
                error_log('REST API Error: Invalid or missing nonce');
                return new WP_Error('invalid_nonce', '认证失败，请刷新页面重试', array('status' => 403));
            }
            return true;
        },
    ));
    register_rest_route('xb-img-ocr/v1', '/usage', array(
        'methods'  => 'GET',
        'callback' => 'xb_imgocr_get_usage',
        'permission_callback' => function () {
            if (!is_user_logged_in()) {
                return new WP_Error('not_logged_in', '请先登录', array('status' => 401));
            }
            return true;
        },
    ));
}
add_action('rest_api_init', 'xb_imgocr_register_rest_routes');

/**
 * 获取用户使用次数
 */
function xb_imgocr_get_usage($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_imgocr_records';
    $user_id = get_current_user_id();
    $daily_limit = get_option('xb_imgocr_daily_limit', 10);
    $custom_limit = get_user_meta($user_id, 'xb_imgocr_custom_limit', true);
    $limit = $custom_limit !== '' ? (int)$custom_limit : $daily_limit;
    $today = gmdate('Y-m-d', current_time('timestamp'));
    $used_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND result_status = 'success' AND DATE(created_at) = %s",
        $user_id,
        $today
    ));
    $remaining = max(0, $limit - $used_count);
    return rest_ensure_response(array(
        'remaining' => $remaining,
        'limit' => $limit,
    ));
}

/**
 * 处理图像 OCR 请求
 */
function xb_imgocr_process_image($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_imgocr_records';
    $user_id = get_current_user_id();

    $params = $request->get_params();
    $raw_body = file_get_contents('php://input');
    error_log('REST API Request Params: ' . json_encode($params, JSON_UNESCAPED_SLASHES));
    error_log('REST API Raw Body (first 100 chars): ' . substr($raw_body, 0, 100));

    $daily_limit = get_option('xb_imgocr_daily_limit', 10);
    $custom_limit = get_user_meta($user_id, 'xb_imgocr_custom_limit', true);
    $limit = $custom_limit !== '' ? (int)$custom_limit : $daily_limit;
    $today = gmdate('Y-m-d', current_time('timestamp'));
    $used_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND result_status = 'success' AND DATE(created_at) = %s",
        $user_id,
        $today
    ));

    if ($used_count >= $limit) {
        error_log('REST API Error: Daily limit exceeded for user ' . $user_id);
        return new WP_Error('limit_exceeded', '今日识别次数已用完', array('status' => 403));
    }

    $image_data = isset($params['image']) ? $params['image'] : '';
    $language = isset($params['language']) ? sanitize_text_field($params['language']) : 'CHN_ENG';
    $paragraph = isset($params['paragraph']) ? rest_sanitize_boolean($params['paragraph']) : false;
    $probability = isset($params['probability']) ? rest_sanitize_boolean($params['probability']) : false;

    if (empty($image_data)) {
        error_log('REST API Error: Missing image data');
        return new WP_Error('missing_image', '图片数据缺失，请上传图片', array('status' => 400));
    }

    // 1. 大小检查
    $image_size_mb = strlen($image_data) / 1024 / 1024;
    $max_size_mb = (int)get_option('xb_imgocr_max_size', 5);
    if ($image_size_mb > $max_size_mb) {
        error_log("REST API Error: Encoded image data too large: {$image_size_mb} MB");
        return new WP_Error('image_too_large', "图片数据过大（{$image_size_mb}MB），请上传 {$max_size_mb}MB 以内的图片", array('status' => 400));
    }

    $base64_data = urldecode($image_data);
    error_log('Received Base64 Data (first 100 chars): ' . substr($base64_data, 0, 100));
    error_log('Base64 Data Size (MB): ' . (strlen($base64_data) / 1024 / 1024));

    if (!base64_decode($base64_data, true)) {
        error_log('REST API Error: Invalid base64 image data');
        return new WP_Error('invalid_image', '图片数据无效，请上传有效图片', array('status' => 400));
    }

    // 2. 格式检查
    $supported_formats = explode(',', get_option('xb_imgocr_image_formats', 'jpg,jpeg,png,bmp'));
    $image_info = getimagesizefromstring(base64_decode($base64_data));
    if (!$image_info) {
        error_log('REST API Error: Failed to get image info from base64 data');
        return new WP_Error('invalid_image', '图片文件不正确，请更换真实图片', array('status' => 400));
    }
    $ext = str_replace('image/', '', $image_info['mime']);
    if (!in_array($ext, $supported_formats)) {
        error_log("REST API Error: Unsupported image format: $ext");
        return new WP_Error('unsupported_format', "不支持的图片格式 $ext，请更换支持的图片格式", array('status' => 400));
    }

    // 3. 真实性检查
    $decoded_image = base64_decode($base64_data);
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_buffer($finfo, $decoded_image);
    finfo_close($finfo);
    if (!in_array($mime_type, array('image/jpeg', 'image/png', 'image/bmp'))) {
        error_log("REST API Error: Invalid image authenticity, MIME type: $mime_type");
        return new WP_Error('invalid_image_authenticity', '图片文件不正常，请更换真实图片', array('status' => 400));
    }

    // 魔术数字检查
    $magic_numbers = array(
        'jpeg' => array(0xFF, 0xD8),
        'png' => array(0x89, 0x50, 0x4E, 0x47),
        'bmp' => array(0x42, 0x4D),
    );
    $is_valid = false;
    $image_bytes = array_values(unpack('C*', substr($decoded_image, 0, 8)));
    foreach ($magic_numbers as $format => $magic) {
        $match = true;
        for ($i = 0; $i < count($magic); $i++) {
            if (!isset($image_bytes[$i]) || $image_bytes[$i] !== $magic[$i]) {
                $match = false;
                break;
            }
        }
        if ($match) {
            $is_valid = true;
            break;
        }
    }
    if (!$is_valid) {
        error_log('REST API Error: Invalid image authenticity, failed magic number check');
        return new WP_Error('invalid_image_authenticity', '图片文件不正常，请更换真实图片', array('status' => 400));
    }

    $width = $image_info[0];
    $height = $image_info[1];
    if (min($width, $height) < 15 || max($width, $height) > 4096) {
        error_log("REST API Error: Invalid image dimensions: {$width}x{$height}");
        return new WP_Error('invalid_dimensions', '图片尺寸不符合要求，最短边至少15px，最长边最大4096px', array('status' => 400));
    }

    $access_token = get_option('xb_imgocr_access_token', '');
    if (empty($access_token)) {
        error_log('REST API Error: No access token configured');
        return new WP_Error('no_access_token', '未配置有效的 access_token', array('status' => 500));
    }

    $url = "https://aip.baidubce.com/rest/2.0/ocr/v1/general_basic?access_token=" . urlencode($access_token);
    $params = array(
        'image' => $base64_data,
        'language_type' => $language,
        'detect_direction' => 'false',
        'detect_language' => 'false',
        'paragraph' => $paragraph ? 'true' : 'false',
        'probability' => $probability ? 'true' : 'false',
    );

    error_log('Baidu API Image Param (first 100 chars): ' . substr($base64_data, 0, 100));
    error_log('Baidu API Image Param Size (MB): ' . (strlen($base64_data) / 1024 / 1024));

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => http_build_query($params),
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/x-www-form-urlencoded',
            'Accept: application/json',
        ),
    ));

    $response = curl_exec($curl);
    $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($curl);
    curl_close($curl);

    if ($curl_error) {
        error_log('Baidu API cURL Error: ' . $curl_error);
        return new WP_Error('curl_error', '请求百度API失败：' . $curl_error, array('status' => 500));
    }
    error_log('Baidu OCR API Response (HTTP ' . $http_code . '): ' . $response);

    $result_status = 'failure';
    $result_data = json_decode($response, true);

    if ($http_code == 200 && isset($result_data['words_result'])) {
        $result_status = 'success';
        $output = '';
        foreach ($result_data['words_result'] as $item) {
            $output .= esc_html($item['words']) . "\n";
        }
        if ($paragraph && isset($result_data['paragraphs_result'])) {
            $output .= "\n段落信息：\n";
            foreach ($result_data['paragraphs_result'] as $para) {
                $output .= "段落包含行序号：" . implode(',', $para['words_result_idx']) . "\n";
            }
        }
        if ($probability && isset($result_data['words_result'][0]['probability'])) {
            $output .= "\n置信度信息：\n";
            foreach ($result_data['words_result'] as $idx => $item) {
                if (isset($item['probability'])) {
                    $prob = $item['probability'];
                    $output .= "行 " . ($idx + 1) . " - 平均置信度: {$prob['average']}, 方差: {$prob['variance']}, 最小值: {$prob['min']}\n";
                }
            }
        }
    } else {
        $error_msg = isset($result_data['error_msg']) ? esc_html($result_data['error_msg']) : '识别失败，请稍后再试';
        $error_code = isset($result_data['error_code']) ? $result_data['error_code'] : 'unknown';
        error_log("OCR Error: Code=$error_code, Message=$error_msg");
        return new WP_Error('ocr_failed', "OCR失败：$error_msg", array('status' => 400));
    }

    $wpdb->insert($table_name, array(
        'user_id' => $user_id,
        'result_status' => $result_status,
        'created_at' => current_time('mysql', true),
    ));

    $remaining = max(0, $limit - ($used_count + ($result_status === 'success' ? 1 : 0)));

    return rest_ensure_response(array(
        'result' => $output,
        'status' => $result_status,
        'remaining' => $remaining,
        'limit' => $limit,
    ));
}

/**
 * 注册管理员菜单
 */
function xb_imgocr_admin_menu() {
    add_menu_page(
        '图像文字识别设置',
        '图像文字识别',
        'manage_options',
        'xb-img-ocr-settings',
        'xb_imgocr_settings_page',
        'dashicons-text'
    );
    add_submenu_page(
        'xb-img-ocr-settings',
        '用户识别记录',
        '用户识别记录',
        'manage_options',
        'xb-img-ocr-records',
        'xb_imgocr_records_page'
    );
}
add_action('admin_menu', 'xb_imgocr_admin_menu');

/**
 * 设置页面
 */
function xb_imgocr_settings_page() {
    if (isset($_POST['xb_imgocr_save_settings']) && check_admin_referer('xb_imgocr_settings', '_wpnonce_settings')) {
        update_option('xb_imgocr_api_key', sanitize_text_field($_POST['xb_imgocr_api_key']));
        update_option('xb_imgocr_secret_key', sanitize_text_field($_POST['xb_imgocr_secret_key']));
        update_option('xb_imgocr_daily_limit', absint($_POST['xb_imgocr_daily_limit']));
        update_option('xb_imgocr_image_formats', sanitize_text_field($_POST['xb_imgocr_image_formats']));
        update_option('xb_imgocr_max_size', absint($_POST['xb_imgocr_max_size']));
        update_option('xb_imgocr_languages', sanitize_text_field($_POST['xb_imgocr_languages']));
        update_option('xb_imgocr_paragraph_enabled', isset($_POST['xb_imgocr_paragraph_enabled']) ? 'true' : 'false');
        update_option('xb_imgocr_probability_enabled', isset($_POST['xb_imgocr_probability_enabled']) ? 'true' : 'false');
        update_option('xb_imgocr_announcement', wp_kses_post($_POST['xb_imgocr_announcement']));
        ?>
        <div class="updated xb-img-ocr-admin-notice"><p>设置已保存</p></div>
        <script>
            jQuery(document).ready(function($) {
                setTimeout(function() {
                    $('.xb-img-ocr-admin-notice').fadeOut();
                }, 3000);
            });
        </script>
        <?php
    }

    if (isset($_POST['xb_imgocr_get_token']) && check_admin_referer('xb_imgocr_token', '_wpnonce_token')) {
        $api_key = get_option('xb_imgocr_api_key', '');
        $secret_key = get_option('xb_imgocr_secret_key', '');
        if ($api_key && $secret_key) {
            $url = "https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=" . urlencode($api_key) . "&client_secret=" . urlencode($secret_key);
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $url,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_HTTPHEADER => array(
                    'Content-Type: application/json',
                    'Accept: application/json',
                ),
            ));
            $response = curl_exec($curl);
            curl_close($curl);
            $data = json_decode($response, true);
            if (isset($data['access_token'])) {
                update_option('xb_imgocr_access_token', $data['access_token']);
                update_option('xb_imgocr_token_expires', time() + $data['expires_in']);
                ?>
                <div class="updated xb-img-ocr-admin-notice"><p>Access Token 已获取</p></div>
                <script>
                    jQuery(document).ready(function($) {
                        setTimeout(function() {
                            $('.xb-img-ocr-admin-notice').fadeOut();
                        }, 3000);
                    });
                </script>
                <?php
            } else {
                ?>
                <div class="error xb-img-ocr-admin-notice"><p>获取 Access Token 失败：<?php echo esc_html($data['error_description'] ?? '未知错误'); ?></p></div>
                <script>
                    jQuery(document).ready(function($) {
                        setTimeout(function() {
                            $('.xb-img-ocr-admin-notice').fadeOut();
                        }, 3000);
                    });
                </script>
                <?php
            }
        } else {
            ?>
            <div class="error xb-img-ocr-admin-notice"><p>请先填写 API Key 和 Secret Key</p></div>
            <script>
                jQuery(document).ready(function($) {
                    setTimeout(function() {
                        $('.xb-img-ocr-admin-notice').fadeOut();
                    }, 3000);
                });
            </script>
            <?php
        }
    }

    $access_token = get_option('xb_imgocr_access_token', '');
    $expires = get_option('xb_imgocr_token_expires', 0);
    $days_left = $expires ? ceil(($expires - time()) / 86400) : 0;
    ?>
    <div class="wrap">
        <h1>图像文字识别设置</h1>
        <form method="post" action="">
            <?php wp_nonce_field('xb_imgocr_settings', '_wpnonce_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label>API Key</label></th>
                    <td><input type="text" name="xb_imgocr_api_key" value="<?php echo esc_attr(get_option('xb_imgocr_api_key', '')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label>Secret Key</label></th>
                    <td><input type="text" name="xb_imgocr_secret_key" value="<?php echo esc_attr(get_option('xb_imgocr_secret_key', '')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label>Access Token</label></th>
                    <td>
                        <input type="text" value="<?php echo esc_attr($access_token); ?>" class="regular-text" readonly>
                        <p>剩余有效天数：<?php echo esc_html($days_left); ?> 天</p>
                    </td>
                </tr>
                <tr>
                    <th><label>每日使用次数限制</label></th>
                    <td><input type="number" name="xb_imgocr_daily_limit" value="<?php echo esc_attr(get_option('xb_imgocr_daily_limit', 10)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label>支持的图片格式</label></th>
                    <td><input type="text" name="xb_imgocr_image_formats" value="<?php echo esc_attr(get_option('xb_imgocr_image_formats', 'jpg,jpeg,png,bmp')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label>最大图片大小 (MB)</label></th>
                    <td><input type="number" name="xb_imgocr_max_size" value="<?php echo esc_attr(get_option('xb_imgocr_max_size', 5)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label>支持的语言</label></th>
                    <td><input type="text" name="xb_imgocr_languages" value="<?php echo esc_attr(get_option('xb_imgocr_languages', 'CHN_ENG,ENG,JAP')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label>启用段落信息</label></th>
                    <td><input type="checkbox" name="xb_imgocr_paragraph_enabled" <?php checked(get_option('xb_imgocr_paragraph_enabled', 'true'), 'true'); ?>></td>
                </tr>
                <tr>
                    <th><label>启用置信度</label></th>
                    <td><input type="checkbox" name="xb_imgocr_probability_enabled" <?php checked(get_option('xb_imgocr_probability_enabled', 'true'), 'true'); ?>></td>
                </tr>
                <tr>
                    <th><label>公告内容</label></th>
                    <td><textarea name="xb_imgocr_announcement" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_imgocr_announcement', '')); ?></textarea></td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="xb_imgocr_save_settings" class="button-primary" value="保存设置">
            </p>
        </form>
        <form method="post" action="">
            <?php wp_nonce_field('xb_imgocr_token', '_wpnonce_token'); ?>
            <p class="submit">
                <input type="submit" name="xb_imgocr_get_token" class="button-secondary" value="获取 Access Token">
            </p>
        </form>
        基于百度云通用文字识别（标准版）https://cloud.baidu.com/doc/OCR/s/9k3h7xuv6 <br>
        单价：0.0050 一次
    </div>
    <?php
}

/**
 * 用户识别记录页面
 */
function xb_imgocr_records_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_imgocr_records';
    $per_page = 20;
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $offset = ($paged - 1) * $per_page;
    $user_id_filter = isset($_GET['user_id']) ? absint($_GET['user_id']) : 0;

    if (isset($_GET['delete_id']) && check_admin_referer('xb_imgocr_delete_record')) {
        $delete_id = absint($_GET['delete_id']);
        $wpdb->delete($table_name, array('id' => $delete_id));
        ?>
        <div class="updated xb-img-ocr-admin-notice"><p>记录已删除</p></div>
        <script>
            jQuery(document).ready(function($) {
                setTimeout(function() {
                    $('.xb-img-ocr-admin-notice').fadeOut();
                }, 3000);
            });
        </script>
        <?php
    }

    if (isset($_POST['xb_imgocr_set_limit']) && check_admin_referer('xb_imgocr_user_limit')) {
        $target_user_id = absint($_POST['xb_imgocr_target_user_id']);
        $custom_limit = absint($_POST['xb_imgocr_custom_limit']);
        if ($custom_limit > 0) {
            update_user_meta($target_user_id, 'xb_imgocr_custom_limit', $custom_limit);
            ?>
            <div class="updated xb-img-ocr-admin-notice"><p>用户限制已设置</p></div>
            <script>
                jQuery(document).ready(function($) {
                    setTimeout(function() {
                        $('.xb-img-ocr-admin-notice').fadeOut();
                    }, 3000);
                });
            </script>
            <?php
        }
    }

    if (isset($_POST['xb_imgocr_reset_limit']) && check_admin_referer('xb_imgocr_user_limit')) {
        $target_user_id = absint($_POST['xb_imgocr_target_user_id']);
        delete_user_meta($target_user_id, 'xb_imgocr_custom_limit');
        ?>
        <div class="updated xb-img-ocr-admin-notice"><p>已恢复默认限制</p></div>
        <script>
            jQuery(document).ready(function($) {
                setTimeout(function() {
                    $('.xb-img-ocr-admin-notice').fadeOut();
                }, 3000);
            });
        </script>
        <?php
    }

    $where = $user_id_filter ? $wpdb->prepare('WHERE user_id = %d', $user_id_filter) : '';
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
    $total_success = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE result_status = 'success'");
    $total_attempts = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");

    $records = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name $where ORDER BY created_at DESC LIMIT %d OFFSET %d",
        $per_page,
        $offset
    ));

    $user_stats = array();
    if ($user_id_filter) {
        $daily_limit = get_option('xb_imgocr_daily_limit', 10);
        $custom_limit = get_user_meta($user_id_filter, 'xb_imgocr_custom_limit', true);
        $limit = $custom_limit !== '' ? (int)$custom_limit : $daily_limit;
        $today = gmdate('Y-m-d', current_time('timestamp'));
        $used_today = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND result_status = 'success' AND DATE(created_at) = %s",
            $user_id_filter,
            $today
        ));
        $total_user = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND result_status = 'success'",
            $user_id_filter
        ));
        $total_user_attempts = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE user_id = %d",
            $user_id_filter
        ));
        $user_stats = array(
            'used_today' => $used_today,
            'limit' => $limit,
            'total' => $total_user,
            'total_attempts' => $total_user_attempts,
        );
    }
    ?>
    <div class="wrap">
        <h1>用户识别记录</h1>
        <p>网站总识别次数：<?php echo esc_html($total_attempts); ?>（成功：<?php echo esc_html($total_success); ?>）</p>
        <form method="get" action="">
            <input type="hidden" name="page" value="xb-img-ocr-records">
            <label>筛选用户 ID：<input type="number" name="user_id" value="<?php echo esc_attr($user_id_filter); ?>"></label>
            <input type="submit" class="button" value="筛选">
        </form>
        <?php if ($user_id_filter): ?>
            <h2>用户 <?php echo esc_html($user_id_filter); ?> 统计</h2>
            <p>今日已使用：<?php echo esc_html($user_stats['used_today']); ?> / <?php echo esc_html($user_stats['limit']); ?> 次</p>
            <p>总识别次数：<?php echo esc_html($user_stats['total_attempts']); ?>（成功：<?php echo esc_html($user_stats['total']); ?>）</p>
            <form method="post" action="">
                <?php wp_nonce_field('xb_imgocr_user_limit'); ?>
                <input type="hidden" name="xb_imgocr_target_user_id" value="<?php echo esc_attr($user_id_filter); ?>">
                <label>设置自定义每日限制：<input type="number" name="xb_imgocr_custom_limit" min="1"></label>
                <input type="submit" name="xb_imgocr_set_limit" class="button" value="设置限制">
                <input type="submit" name="xb_imgocr_reset_limit" class="button" value="恢复默认">
            </form>
        <?php endif; ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>用户名</th>
                    <th>识别结果</th>
                    <th>处理时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record): ?>
                    <tr>
                        <td><?php echo esc_html($record->user_id); ?></td>
                        <td><?php echo esc_html(get_userdata($record->user_id)->user_login); ?></td>
                        <td><?php echo esc_html($record->result_status === 'success' ? '成功' : '失败'); ?></td>
                        <td><?php echo esc_html($record->created_at); ?></td>
                        <td>
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=xb-img-ocr-records&delete_id=' . $record->id), 'xb_imgocr_delete_record'); ?>" class="button">删除</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        echo paginate_links(array(
            'base' => add_query_arg('paged', '%#%'),
            'format' => '&paged=%#%',
            'total' => ceil($total / $per_page),
            'current' => $paged,
        ));
        ?>
    </div>
    <?php
}
?>