jQuery(document).ready(function($) {
    // 自定义通知显示
    function showNotification(message) {
        $('#xb-img-ocr-notification-text').text(message);
        $('#xb-img-ocr-notification').fadeIn().delay(3000).fadeOut();
    }

    // 存储编码后的图片数据
    let encodedImageData = null;
    const supportedFormats = ['image/jpeg', 'image/jpg', 'image/png', 'image/bmp'];
    const maxSizeMB = 5;
    const maxPayloadSizeMB = 8;

    // 图片真实性检查 - 基于魔术数字
    function checkImageAuthenticity(file, callback) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const arrayBuffer = e.target.result;
            const bytes = new Uint8Array(arrayBuffer);

            // 魔术数字检查
            const isJPEG = bytes.length >= 2 && bytes[0] === 0xFF && bytes[1] === 0xD8;
            const isPNG = bytes.length >= 8 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4E && bytes[3] === 0x47;
            const isBMP = bytes.length >= 2 && bytes[0] === 0x42 && bytes[1] === 0x4D;

            if (isJPEG || isPNG || isBMP) {
                console.log('Image Authenticity Check: Valid image format detected');
                callback(true);
            } else {
                console.log('Image Authenticity Check: Invalid image content', bytes.slice(0, 10));
                callback(false);
            }
        };
        reader.onerror = function() {
            console.error('Image Authenticity Check: Failed to read file');
            callback(false);
        };
        reader.readAsArrayBuffer(file.slice(0, 8)); // 读取前8字节足以检查魔术数字
    }

    // 恢复用户设置
    const savedSettings = JSON.parse(localStorage.getItem('xb_img_ocr_settings') || '{}');
    if (savedSettings.language) {
        $('#xb-img-ocr-language').val(savedSettings.language);
    }
    if (savedSettings.paragraph !== undefined) {
        const paragraphState = savedSettings.paragraph ? 'true' : 'false';
        $('#xb-img-ocr-paragraph-toggle').attr('data-state', paragraphState);
        $('#xb-img-ocr-paragraph-toggle .xb-img-ocr-toggle-label').text(savedSettings.paragraph ? '开启' : '关闭');
        $('#xb-img-ocr-paragraph-toggle .xb-img-ocr-toggle-switch').toggleClass('xb-img-ocr-toggle-on', savedSettings.paragraph);
    }
    if (savedSettings.probability !== undefined) {
        const probabilityState = savedSettings.probability ? 'true' : 'false';
        $('#xb-img-ocr-probability-toggle').attr('data-state', probabilityState);
        $('#xb-img-ocr-probability-toggle .xb-img-ocr-toggle-label').text(savedSettings.probability ? '开启' : '关闭');
        $('#xb-img-ocr-probability-toggle .xb-img-ocr-toggle-switch').toggleClass('xb-img-ocr-toggle-on', savedSettings.probability);
    }

    // 图片上传处理
    $('#xb-img-ocr-upload-btn').on('click', function() {
        $('#xb-img-ocr-file').click();
    });

    $('#xb-img-ocr-file').on('change', function(e) {
        const file = e.target.files[0];
        if (!file) {
            encodedImageData = null;
            $('#xb-img-ocr-preview-img').hide();
            return;
        }

        // 1. 格式检查
        if (!supportedFormats.includes(file.type)) {
            showNotification('不支持的图片格式，仅支持 JPG、PNG、BMP');
            encodedImageData = null;
            $('#xb-img-ocr-preview-img').hide();
            $('#xb-img-ocr-file').val('');
            return;
        }

        // 2. 大小检查
        const fileSizeMB = file.size / 1024 / 1024;
        if (fileSizeMB > maxSizeMB) {
            showNotification(`图片太大，请上传 ${maxSizeMB}MB 以内的图片`);
            encodedImageData = null;
            $('#xb-img-ocr-preview-img').hide();
            $('#xb-img-ocr-file').val('');
            return;
        }

        // 3. 真实性检查
        checkImageAuthenticity(file, function(isValid) {
            if (!isValid) {
                showNotification('图片文件不正常，请更换真实图片');
                encodedImageData = null;
                $('#xb-img-ocr-preview-img').hide();
                $('#xb-img-ocr-file').val('');
                return;
            }

            // 所有检查通过，处理图片
            const reader = new FileReader();
            reader.onload = function(e) {
                const base64 = e.target.result.split(',')[1];
                if (!base64 || !/^[A-Za-z0-9+/=]+$/.test(base64)) {
                    showNotification('图片数据无效，请重新上传');
                    console.error('Invalid base64 string:', base64 ? base64.substring(0, 100) : 'empty');
                    encodedImageData = null;
                    $('#xb-img-ocr-preview-img').hide();
                    $('#xb-img-ocr-file').val('');
                    return;
                }

                console.log('Raw Base64 Data (first 100 chars):', base64.substring(0, 100) + '...');
                console.log('Raw Base64 Size (MB):', (base64.length / 1024 / 1024).toFixed(2));

                encodedImageData = encodeURIComponent(base64);
                console.log('Encoded Image Data (first 100 chars):', encodedImageData.substring(0, 100) + '...');
                console.log('Encoded Image Size (MB):', (encodedImageData.length / 1024 / 1024).toFixed(2));

                const payloadSizeMB = encodedImageData.length / 1024 / 1024;
                if (payloadSizeMB > maxPayloadSizeMB) {
                    showNotification(`图片数据过大（${payloadSizeMB.toFixed(2)}MB），请上传更小的图片`);
                    console.error('Payload too large:', payloadSizeMB.toFixed(2), 'MB');
                    encodedImageData = null;
                    $('#xb-img-ocr-preview-img').hide();
                    $('#xb-img-ocr-file').val('');
                    return;
                }

                const img = $('#xb-img-ocr-preview-img');
                img.attr('src', e.target.result).show();
            };
            reader.onerror = function() {
                showNotification('读取图片失败，请重新上传');
                encodedImageData = null;
                $('#xb-img-ocr-preview-img').hide();
                $('#xb-img-ocr-file').val('');
            };
            reader.readAsDataURL(file);
        });
    });

    // 处理开关按钮
    $('.xb-img-ocr-toggle').on('click', function() {
        const $toggle = $(this);
        const isOn = $toggle.attr('data-state') === 'true';
        $toggle.attr('data-state', !isOn);
        $toggle.find('.xb-img-ocr-toggle-label').text(isOn ? '关闭' : '开启');
        $toggle.find('.xb-img-ocr-toggle-switch').toggleClass('xb-img-ocr-toggle-on');
        const settings = JSON.parse(localStorage.getItem('xb_img_ocr_settings') || '{}');
        if ($toggle.attr('id') === 'xb-img-ocr-paragraph-toggle') {
            settings.paragraph = !isOn;
        } else if ($toggle.attr('id') === 'xb-img-ocr-probability-toggle') {
            settings.probability = !isOn;
        }
        localStorage.setItem('xb_img_ocr_settings', JSON.stringify(settings));
    });

    // 保存语言设置
    $('#xb-img-ocr-language').on('change', function() {
        const settings = JSON.parse(localStorage.getItem('xb_img_ocr_settings') || '{}');
        settings.language = $(this).val();
        localStorage.setItem('xb_img_ocr_settings', JSON.stringify(settings));
    });

    // 开始识别
    $('#xb-img-ocr-process-btn').on('click', function() {
        if (!encodedImageData) {
            showNotification('请先上传图片');
            return;
        }

        $('#xb-img-ocr-processing').show();
        $('#xb-img-ocr-result').empty();
        $('#xb-img-ocr-copy-btn').hide();

        const ajaxData = {
            image: encodedImageData,
            language: $('#xb-img-ocr-language').val(),
            paragraph: $('#xb-img-ocr-paragraph-toggle').attr('data-state') === 'true',
            probability: $('#xb-img-ocr-probability-toggle').attr('data-state') === 'true'
        };
        console.log('AJAX Request Data:', {
            image: ajaxData.image.substring(0, 100) + '...',
            imageSizeMB: (ajaxData.image.length / 1024 / 1024).toFixed(2),
            language: ajaxData.language,
            paragraph: ajaxData.paragraph,
            probability: ajaxData.probability,
            nonce: xb_imgocr_params.nonce
        });

        $.ajax({
            url: xb_imgocr_params.ajax_url + '/process',
            method: 'POST',
            headers: {
                'X-WP-Nonce': xb_imgocr_params.nonce
            },
            data: ajaxData,
            dataType: 'json',
            success: function(response) {
                $('#xb-img-ocr-processing').hide();
                console.log('AJAX Success Response:', response);
                console.log('Response.result:', response.result ? response.result.substring(0, 100) + '...' : 'undefined');
                console.log('Response.status:', response.status);

                if (response.result) {
                    $('#xb-img-ocr-result').text(response.result);
                    $('#xb-img-ocr-copy-btn').show();
                    if (response.remaining !== undefined && response.limit !== undefined) {
                        if (response.remaining <= 0) {
                            $('.xb-img-ocr-usage').text('今日使用次数已经用完，请明天再来');
                        } else {
                            $('.xb-img-ocr-usage').html(`今日剩余识别次数：<span class="xb-img-ocr-remaining">${response.remaining}</span>/${response.limit}`);
                        }
                    }
                } else {
                    console.error('AJAX Error: No result in response:', response);
                    const message = response.message ? response.message : '请求失败，请稍后再试';
                    showNotification(message);
                }
            },
            error: function(xhr, status, error) {
                $('#xb-img-ocr-processing').hide();
                console.error('AJAX Network Error:', { xhr, status, error });
                console.log('Raw Server Response:', xhr.responseText);
                const response = xhr.responseJSON || {};
                const message = response.message || '网络错误，请检查连接后重试';
                showNotification(message);
            }
        });
    });

    // 一键复制
    $('#xb-img-ocr-copy-btn').on('click', function() {
        const text = $('#xb-img-ocr-result').text();
        navigator.clipboard.writeText(text).then(function() {
            showNotification('已复制到剪贴板');
        });
    });

    // 快速登录按钮
    $('.xb-img-ocr-login-btn').on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });

    // 动态处理提示
    let dots = 0;
    setInterval(function() {
        if ($('#xb-img-ocr-processing').is(':visible')) {
            dots = (dots + 1) % 4;
            $('#xb-img-ocr-processing').text('正在识别中' + '.'.repeat(dots));
        }
    }, 500);
});