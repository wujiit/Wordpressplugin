<?php
/*
Plugin Name: 小半用户注销申请
Description: 允许用户自行申请注销账户
Version: 1.0
Author: summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时创建页面
register_activation_hook(__FILE__, 'xb_usd_create_page');
function xb_usd_create_page() {
    if (!get_page_by_path('user-delete-account')) {
        $page = array(
            'post_title'    => '用户注销',
            'post_content'  => '[user_self_delete]',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_author'   => 1,
        );
        wp_insert_post($page);
    }
}

// 插件列表页面添加设置入口
function xb_usd_create_add_settings_link($links) {
    $settings_link = '<a href="admin.php?page=user-self-delete">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'xb_usd_create_add_settings_link');

// 添加管理菜单
add_action('admin_menu', 'xb_usd_admin_menu');
function xb_usd_admin_menu() {
    add_menu_page('用户注销', '用户注销', 'manage_options', 'user-self-delete', '', 'dashicons-admin-users');
    add_submenu_page('user-self-delete', '设置', '设置', 'manage_options', 'user-self-delete', 'xb_usd_settings_page');
    add_submenu_page('user-self-delete', '注销记录', '注销记录', 'manage_options', 'usd-records', 'xb_usd_records_page');
}

// 设置页面
function xb_usd_settings_page() {
    if (isset($_POST['usd_save_settings'])) {
        check_admin_referer('usd_settings');
        update_option('usd_enabled', isset($_POST['usd_enabled']) ? 1 : 0);
        update_option('usd_description', wp_kses_post($_POST['usd_description']));
        echo '<div class="updated"><p>设置已保存</p></div>';
    }
    
    $enabled = get_option('usd_enabled', 0);
    $description = get_option('usd_description', '');
    ?>
    <div class="wrap">
        <h1>用户注销设置</h1>
        <form method="post">
            <?php wp_nonce_field('usd_settings'); ?>
            <table class="form-table">
                <tr>
                    <th>启用用户注销</th>
                    <td><input type="checkbox" name="usd_enabled" value="1" <?php checked($enabled, 1); ?>></td>
                </tr>
                <tr>
                    <th>注销说明</th>
                    <td>
                        <?php
                        // 使用 WordPress 经典编辑器
                        wp_editor(
                            $description,
                            'usd_description', // 编辑器 ID
                            array(
                                'textarea_name' => 'usd_description', // 表单字段名称
                                'media_buttons' => true, // 显示媒体上传按钮
                                'textarea_rows' => 10, // 行数
                                'editor_class'  => 'usd-editor', // 编辑器 CSS 类
                            )
                        );
                        ?>
                        <p class="description">在此编辑注销说明内容</p>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="usd_save_settings" class="button-primary" value="保存设置">
            </p>
        </form>
    </div>
    <?php
}

// 注销记录页面
function xb_usd_records_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'usd_requests';
    
    if (isset($_GET['action']) && $_GET['action'] == 'approve' && isset($_GET['id'])) {
        check_admin_referer('usd_approve');
        $wpdb->update($table_name, array('status' => 1), array('id' => intval($_GET['id'])));
    }
    
    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
        check_admin_referer('usd_delete');
        $wpdb->delete($table_name, array('id' => intval($_GET['id'])));
    }
    
    $requests = $wpdb->get_results("SELECT * FROM $table_name ORDER BY request_time DESC");
    ?>
    <div class="wrap">
        <h1>用户注销申请记录</h1>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户ID</th>
                    <th>用户名</th>
                    <th>申请时间</th>
                    <th>操作 - 同意</th>
                    <th>操作 - 删除</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($requests as $request): ?>
                <tr>
                    <td><?php echo esc_html($request->user_id); ?></td>
                    <td><?php echo esc_html(get_userdata($request->user_id)->user_login); ?></td>
                    <td><?php echo esc_html($request->request_time); ?></td>
                    <td>
                        <?php if ($request->status == 0): ?>
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=usd-records&action=approve&id=' . $request->id), 'usd_approve'); ?>" class="button">同意</a>
                        <?php else: ?>
                            已同意
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=usd-records&action=delete&id=' . $request->id), 'usd_delete'); ?>" class="button button-danger" onclick="return confirm('确定要删除这条记录吗？');">删除</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// 创建数据库表
register_activation_hook(__FILE__, 'xb_usd_create_table');
function xb_usd_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'usd_requests';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        request_time datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        status tinyint(1) DEFAULT 0 NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// 前台短代码
add_shortcode('user_self_delete', 'xb_usd_frontend_form');
function xb_usd_frontend_form() {
    if (!is_user_logged_in() || !get_option('usd_enabled')) {
        return '<p>此功能当前不可用。</p>';
    }
    
    $current_user = wp_get_current_user();
    $is_admin = current_user_can('manage_options');
    
    if (isset($_POST['usd_submit']) && check_admin_referer('usd_request') && !$is_admin) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'usd_requests';
        
        $wpdb->insert(
            $table_name,
            array(
                'user_id' => get_current_user_id(),
            )
        );
        
        wp_logout();
        return '<p>您的注销申请已提交，请等待管理员处理。</p>';
    }
    
    $description = get_option('usd_description', '');
    
    ob_start();
    ?>
    <style>
        .usd-form {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
        }
        .usd-description {
            margin-bottom: 20px;
        }
        .usd-checkbox {
            margin: 15px 0;
        }
        .usd-checkbox input[type="checkbox"] {
            margin-right: 10px;
            vertical-align: middle;
        }
        .usd-submit {
            background-color: #0073aa;
            color: white;
            padding: 8px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .usd-submit:hover {
            background-color: #005d82;
        }
    </style>
    <div class="usd-form">
        <div class="usd-description"><?php echo wpautop(wp_kses_post($description)); ?></div>
        <?php if ($is_admin): ?>
            <p>管理员账户无法使用此功能。</p>
        <?php else: ?>
            <form method="post">
                <?php wp_nonce_field('usd_request'); ?>
                <p class="usd-checkbox">
                    <input type="checkbox" name="usd_agree" id="usd_agree" required>
                    <label for="usd_agree">我同意注销我的账户</label>
                </p>
                <p>
                    <input type="submit" name="usd_submit" value="确定注销" class="usd-submit">
                </p>
            </form>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}