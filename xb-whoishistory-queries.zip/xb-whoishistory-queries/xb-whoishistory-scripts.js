jQuery(document).ready(function ($) {
    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('XB WHOIS History: jQuery 未加载！');
        $('#xb_whoishistory_result').html('<div class="xb_whoishistory_message">脚本加载失败，请刷新页面！</div>');
        return;
    }

    // 确保 xb_whoishistory_ajax 配置
    if (typeof xb_whoishistory_ajax === 'undefined') {
        console.error('XB WHOIS History: xb_whoishistory_ajax 未定义！');
        $('#xb_whoishistory_result').html('<div class="xb_whoishistory_message">脚本配置失败，请检查插件设置！</div>');
        return;
    }

    // “快速登录”按钮点击事件
    $(document).on('click', '.wp-ai-login-btn', function (e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });

    // 查询表单提交
    $('#xb_whoishistory_query_form').on('submit', function (e) {
        e.preventDefault();

        var $form = $(this);
        var domain = $('#xb_whoishistory_domain').val().trim();
        var nonce = $('#xb_whoishistory_nonce').val();

        if (!domain) {
            $('#xb_whoishistory_result').html('<div class="xb_whoishistory_message">请输入域名！</div>');
            return;
        }

        // 前端验证域名格式
        var domainPattern = /^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+$/;
        if (!domainPattern.test(domain)) {
            $('#xb_whoishistory_result').html('<div class="xb_whoishistory_message">请输入有效的域名格式（如：example.com）！</div>');
            return;
        }

        if (!nonce) {
            $('#xb_whoishistory_result').html('<div class="xb_whoishistory_message">安全验证参数丢失，请刷新页面！</div>');
            return;
        }

        $.ajax({
            url: xb_whoishistory_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_whoishistory_query',
                domain: domain,
                nonce: nonce
            },
            beforeSend: function () {
                $('.xb_whoishistory_submit_button').prop('disabled', true).text('查询中...');
            },
            success: function (response) {
                if (response.success) {
                    $('#xb_whoishistory_result').html(response.data.result);
                    $('.xb_whoishistory_usage_info').text('今日剩余查询次数：' + response.data.remaining + '/' + response.data.limit);

                    if (response.data.remaining <= 0) {
                        $form.hide();
                        var message = '今日查询次数已用尽！';
                        if (!xb_whoishistory_ajax.is_logged_in) {
                            message += ' 登录可使用更多查询次数！ <a href="' + xb_whoishistory_ajax.login_url + '" class="wp-ai-login-btn">快速登录</a>';
                        } else {
                            message += ' 请明天再试！';
                        }
                        $('#xb_whoishistory_result').append('<div class="xb_whoishistory_message">' + message + '</div>');
                    }
                } else {
                    $('#xb_whoishistory_result').html('<div class="xb_whoishistory_message">' + response.data.message + '</div>');
                }
            },
            error: function (xhr, status, error) {
                console.error('XB WHOIS History: AJAX 错误：' + error);
                var message = '请求失败：' + (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ? xhr.responseJSON.data.message : '未知错误，请检查网络或刷新页面。');
                $('#xb_whoishistory_result').html('<div class="xb_whoishistory_message">' + message + '</div>');
            },
            complete: function () {
                $('.xb_whoishistory_submit_button').prop('disabled', false).text('查询');
            }
        });
    });

    // 分页按钮点击事件
    $(document).on('click', '.xb_whoishistory_prev_page, .xb_whoishistory_next_page', function () {
        var $pagination = $(this).closest('.xb_whoishistory_pagination');
        var domain = $pagination.data('domain');
        var totalPage = parseInt($pagination.data('total-page'));
        var currentPage = parseInt($pagination.data('current-page'));
        var newPage = $(this).hasClass('xb_whoishistory_prev_page') ? currentPage - 1 : currentPage + 1;

        if (newPage < 1 || newPage > totalPage) {
            return;
        }

        $.ajax({
            url: xb_whoishistory_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_whoishistory_pagination',
                domain: domain,
                page: newPage,
                nonce: xb_whoishistory_ajax.nonce
            },
            beforeSend: function () {
                $('#xb_whoishistory_result').html('<div class="xb_whoishistory_message">加载中...</div>');
            },
            success: function (response) {
                if (response.success) {
                    $('#xb_whoishistory_result').html(response.data.result);
                } else {
                    $('#xb_whoishistory_result').html('<div class="xb_whoishistory_message">' + response.data.message + '</div>');
                }
            },
            error: function (xhr, status, error) {
                console.error('XB WHOIS History: Pagination AJAX 错误：' + error);
                $('#xb_whoishistory_result').html('<div class="xb_whoishistory_message">分页加载失败，请重试！</div>');
            }
        });
    });
});