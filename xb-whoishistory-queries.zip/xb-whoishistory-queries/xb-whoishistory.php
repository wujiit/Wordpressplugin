<?php
/*
Plugin Name: WHOIS历史信息
Description: 一个用于查询域名 WHOIS 历史信息的 WordPress 插件，记录查询历史，支持游客查询，包含 IP 和设备信息，前台支持 AJAX 分页展示。
Version: 1.0.0
Author: Summer
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xb_whoishistory_activate');
function xb_whoishistory_activate() {
    xb_whoishistory_create_database();
    xb_whoishistory_create_front_page();
}

// 创建数据库表
function xb_whoishistory_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 查询次数表
    $usage_table = $wpdb->prefix . 'xb_whoishistory_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        ip_address varchar(45) NOT NULL,
        device_info varchar(255) NOT NULL,
        query_date date NOT NULL,
        query_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_ip_date (user_id, ip_address, device_info, query_date)
    ) $charset_collate;";

    // 查询记录表
    $queries_table = $wpdb->prefix . 'xb_whoishistory_queries';
    $queries_sql = "CREATE TABLE $queries_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        ip_address varchar(45) NOT NULL,
        device_info varchar(255) NOT NULL,
        domain varchar(255) NOT NULL,
        query_status varchar(255) NOT NULL,
        query_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($usage_sql);
    dbDelta($queries_sql);

    error_log('XB WHOIS History: Database tables created or updated.');
}

// 检查并创建前台页面
function xb_whoishistory_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_whoishistory_query_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => 'WHOIS 历史信息查询',
            'post_content' => '[xb_whoishistory_query_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_whoishistory_enqueue_scripts');
function xb_whoishistory_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_whoishistory_query_form')) {
        wp_enqueue_style('xb_whoishistory_styles', plugins_url('xb-whoishistory-styles.css', __FILE__), array(), '1.0.0');
        wp_enqueue_script('xb_whoishistory_scripts', plugins_url('xb-whoishistory-scripts.js', __FILE__), array('jquery'), '1.0.0', true);

        wp_localize_script('xb_whoishistory_scripts', 'xb_whoishistory_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('xb_whoishistory_query_nonce'),
            'login_url' => wp_login_url(get_permalink()),
            'is_logged_in' => is_user_logged_in() ? 1 : 0
        ));
    }
}

// 创建短代码，支持游客查询
add_shortcode('xb_whoishistory_query_form', 'xb_whoishistory_query_form_shortcode');
function xb_whoishistory_query_form_shortcode() {
    $ad_content = get_option('xb_whoishistory_ad_content', '');
    $default_limit = absint(get_option('xb_whoishistory_default_limit', 5));
    $guest_limit = absint(get_option('xb_whoishistory_guest_limit', 3));

    ob_start();
    ?>
    <div class="xb_whoishistory_container">
        <div class="xb_whoishistory_title">WHOIS 历史信息查询</div>

        <?php
        $user_id = is_user_logged_in() ? get_current_user_id() : 0;
        $today = current_time('Y-m-d');
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $device_info = !empty($_SERVER['HTTP_USER_AGENT']) ? substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT']), 0, 255) : 'Unknown';

        global $wpdb;
        $table_name = $wpdb->prefix . 'xb_whoishistory_usage';
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT query_count, custom_limit FROM $table_name WHERE user_id = %d AND ip_address = %s AND device_info = %s AND query_date = %s",
                $user_id,
                $ip_address,
                $device_info,
                $today
            )
        );

        $query_count = $row ? absint($row->query_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : ($user_id ? $default_limit : $guest_limit);
        $remaining = max(0, $user_limit - $query_count);
        ?>
        <div class="xb_whoishistory_query_section">
            <?php if ($query_count >= $user_limit): ?>
                <div class="xb_whoishistory_message">
                    今日查询次数已用完！
                    <?php if (!is_user_logged_in()): ?>
                        登录可使用更多查询次数！
                        <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="wp-ai-login-btn">快速登录</a>
                    <?php else: ?>
                        请明天再试！
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <form id="xb_whoishistory_query_form" method="post">
                    <input type="text" name="xb_whoishistory_domain" id="xb_whoishistory_domain" placeholder="请输入域名（如：qq.com）" required>
                    <button type="submit" class="xb_whoishistory_submit_button">查询</button>
                    <input type="hidden" name="xb_whoishistory_nonce" id="xb_whoishistory_nonce" value="<?php echo wp_create_nonce('xb_whoishistory_query_nonce'); ?>">
                </form>
            <?php endif; ?>
            <div class="xb_whoishistory_result_section">
                <div id="xb_whoishistory_result"></div>
                <div class="xb_whoishistory_usage_info">今日剩余查询次数：<?php echo esc_html($remaining); ?>/<?php echo esc_html($user_limit); ?></div>
            </div>
        </div>
        <div class="xb_whoishistory_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
    </div>
    <?php
    return ob_get_clean();
}

// 处理 AJAX 查询请求
add_action('wp_ajax_xb_whoishistory_query', 'xb_whoishistory_handle_query');
add_action('wp_ajax_nopriv_xb_whoishistory_query', 'xb_whoishistory_handle_query');
function xb_whoishistory_handle_query() {
    // 验证 nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'xb_whoishistory_query_nonce')) {
        wp_send_json_error(array('message' => '安全验证失败，请刷新页面重试！'), 403);
        return;
    }

    // 验证 action 参数
    if (!isset($_POST['action']) || $_POST['action'] !== 'xb_whoishistory_query') {
        wp_send_json_error(array('message' => '无效的请求动作！'), 400);
        return;
    }

    // 验证域名参数
    if (!isset($_POST['domain']) || empty(trim($_POST['domain']))) {
        wp_send_json_error(array('message' => '请输入域名！'), 400);
        return;
    }

    $domain = sanitize_text_field($_POST['domain']);
    // 验证域名格式
    if (!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+$/', $domain)) {
        wp_send_json_error(array('message' => '请输入有效的域名格式（如：example.com）！'), 400);
        return;
    }

    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $today = current_time('Y-m-d');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $device_info = !empty($_SERVER['HTTP_USER_AGENT']) ? substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT']), 0, 255) : 'Unknown';

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_whoishistory_usage';
    $queries_table = $wpdb->prefix . 'xb_whoishistory_queries';

    // 检查查询限制
    $default_limit = absint(get_option('xb_whoishistory_default_limit', 5));
    $guest_limit = absint(get_option('xb_whoishistory_guest_limit', 3));
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT query_count, custom_limit FROM $usage_table WHERE user_id = %d AND ip_address = %s AND device_info = %s AND query_date = %s",
            $user_id,
            $ip_address,
            $device_info,
            $today
        )
    );

    $query_count = $row ? absint($row->query_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : ($user_id ? $default_limit : $guest_limit);

    if ($query_count >= $user_limit) {
        if (!is_user_logged_in()) {
            $message = '今日查询次数已用完！登录可使用更多查询次数！ <a href="' . esc_url(wp_login_url()) . '" class="wp-ai-login-btn">快速登录</a>';
        } else {
            $message = '今日查询次数已用完！请明天再试！';
        }
        wp_send_json_error(array('message' => $message), 403);
        return;
    }

    // 调用 API
    $api_url = get_option('xb_whoishistory_api_url', 'https://openapi.chinaz.net/v1/1001/whoishistory');
    $api_key = get_option('xb_whoishistory_api_key');
    $version = '1.0';
    $page = 1; // 默认第一页
    $request_url = sprintf("%s?APIKey=%s&ChinazVer=%s&domain=%s&page=%d", $api_url, urlencode($api_key), urlencode($version), urlencode($domain), $page);

    $args = array(
        'method' => 'GET',
        'timeout' => 60,
        'sslverify' => false,
        'headers' => array(
            'Accept' => 'application/json'
        )
    );

    $response = wp_remote_get($request_url, $args);
    $query_status = 'failed';

    // 准备插入记录
    $insert_data = array(
        'user_id' => $user_id,
        'ip_address' => $ip_address,
        'device_info' => $device_info,
        'domain' => $domain,
        'query_status' => $query_status,
        'query_time' => current_time('mysql')
    );

    if (is_wp_error($response)) {
        $query_status = $response->get_error_message();
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s', '%s'));
        wp_send_json_error(array('message' => 'API 请求失败：' . esc_html($query_status)), 500);
        return;
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    // 记录查询次数
    if ($row) {
        $new_count = $query_count + 1;
        $wpdb->update(
            $usage_table,
            array('query_count' => $new_count),
            array('user_id' => $user_id, 'ip_address' => $ip_address, 'device_info' => $device_info, 'query_date' => $today),
            array('%d'),
            array('%d', '%s', '%s', '%s')
        );
    } else {
        $wpdb->insert(
            $usage_table,
            array(
                'user_id' => $user_id,
                'ip_address' => $ip_address,
                'device_info' => $device_info,
                'query_date' => $today,
                'query_count' => 1,
                'custom_limit' => null
            ),
            array('%d', '%s', '%s', '%s', '%d', '%d')
        );
    }

    // 处理 API 返回结果
    if ($status_code >= 400 && $status_code < 600) {
        $error_codes = array(
            431 => 'APIKey 缺失，请检查配置！',
            432 => 'APIKey 长度错误！',
            433 => '无效的 APIKey！',
            434 => 'APIKey 类型错误！',
            436 => 'API 额度不足或 APIKey 不存在！',
            437 => 'IP 未在白名单内！',
            531 => '请求过于频繁！',
            532 => '未知错误，请联系管理员！'
        );
        $query_status = isset($error_codes[$status_code]) ? $error_codes[$status_code] : (isset($data['Reason']) ? $data['Reason'] : 'API 请求错误：HTTP ' . $status_code);
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s', '%s'));
        wp_send_json_error(array('message' => '查询失败：' . esc_html($query_status)), $status_code);
        return;
    }

    if (isset($data['StateCode']) && $data['StateCode'] == 1) {
        $query_status = 'success';
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s', '%s'));

        // 格式化结果
        $result = $data['Result'];
        $total_count = isset($result['TotalCount']) ? $result['TotalCount'] : 0;
        $total_page = isset($result['TotalPage']) ? $result['TotalPage'] : 1;
        $page_no = isset($result['PageNo']) ? $result['PageNo'] : 1;
        $page_size = isset($result['PageSize']) ? $result['PageSize'] : 0;
        $list = isset($result['List']) ? $result['List'] : array();

        $output = '<table class="xb_whoishistory_result_table">';
        $output .= '<thead><tr>';
        $output .= '<th>注册商</th><th>注册者</th><th>注册日期</th><th>更新日期</th><th>到期日期</th><th>域名状态</th><th>变更项</th>';
        $output .= '</tr></thead><tbody>';

        foreach ($list as $item) {
            $output .= '<tr>';
            $output .= '<td>' . esc_html($item['Registrar'] ?: '-') . '</td>';
            $output .= '<td>' . esc_html($item['ContactPerson'] ?: '-') . '</td>';
            $output .= '<td>' . esc_html($item['CreationDate'] ?: '-') . '</td>';
            $output .= '<td>' . esc_html($item['UpdateDate'] ?: '-') . '</td>';
            $output .= '<td>' . esc_html($item['ExpirationDate'] ?: '-') . '</td>';
            $output .= '<td>' . esc_html($item['DomainStatus'] ?: '-') . '</td>';
            $output .= '<td>' . esc_html($item['Variety'] ?: '-') . '</td>';
            $output .= '</tr>';
        }

        $output .= '</tbody></table>';

        // 分页导航
        if ($total_count > 100) {
            $output .= '<div class="xb_whoishistory_pagination" data-domain="' . esc_attr($domain) . '" data-total-page="' . esc_attr($total_page) . '" data-current-page="' . esc_attr($page_no) . '">';
            $output .= '<button class="xb_whoishistory_prev_page" ' . ($page_no <= 1 ? 'disabled' : '') . '>上一页</button>';
            $output .= '<span class="xb_whoishistory_page_info">第 ' . esc_html($page_no) . ' 页 / 共 ' . esc_html($total_page) . ' 页</span>';
            $output .= '<button class="xb_whoishistory_next_page" ' . ($page_no >= $total_page ? 'disabled' : '') . '>下一页</button>';
            $output .= '</div>';
        }

        wp_send_json_success(array(
            'result' => $output,
            'remaining' => $user_limit - ($query_count + 1),
            'limit' => $user_limit
        ));
    } else {
        $query_status = isset($data['Reason']) ? $data['Reason'] : '未知错误';
        $insert_data['query_status'] = $query_status;
        $wpdb->insert($queries_table, $insert_data, array('%d', '%s', '%s', '%s', '%s', '%s'));
        wp_send_json_error(array('message' => '查询失败：' . esc_html($query_status)), 400);
    }
}

// AJAX 分页请求
add_action('wp_ajax_xb_whoishistory_pagination', 'xb_whoishistory_handle_pagination');
add_action('wp_ajax_nopriv_xb_whoishistory_pagination', 'xb_whoishistory_handle_pagination');
function xb_whoishistory_handle_pagination() {
    // 验证 nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'xb_whoishistory_query_nonce')) {
        wp_send_json_error(array('message' => '安全验证失败，请刷新页面重试！'), 403);
        return;
    }

    // 验证参数
    if (!isset($_POST['domain']) || !isset($_POST['page'])) {
        wp_send_json_error(array('message' => '缺少必要参数！'), 400);
        return;
    }

    $domain = sanitize_text_field($_POST['domain']);
    $page = absint($_POST['page']);

    // 验证域名格式
    if (!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+$/', $domain)) {
        wp_send_json_error(array('message' => '无效的域名格式！'), 400);
        return;
    }

    // 调用 API
    $api_url = get_option('xb_whoishistory_api_url', 'https://openapi.chinaz.net/v1/1001/whoishistory');
    $api_key = get_option('xb_whoishistory_api_key');
    $version = '1.0';
    $request_url = sprintf("%s?APIKey=%s&ChinazVer=%s&domain=%s&page=%d", $api_url, urlencode($api_key), urlencode($version), urlencode($domain), $page);

    $args = array(
        'method' => 'GET',
        'timeout' => 60,
        'sslverify' => false,
        'headers' => array(
            'Accept' => 'application/json'
        )
    );

    $response = wp_remote_get($request_url, $args);

    if (is_wp_error($response)) {
        wp_send_json_error(array('message' => 'API 请求失败：' . esc_html($response->get_error_message())), 500);
        return;
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if ($status_code >= 400 && $status_code < 600) {
        $error_codes = array(
            431 => 'APIKey 缺失，请检查配置！',
            432 => 'APIKey 长度错误！',
            433 => '无效的 APIKey！',
            434 => 'APIKey 类型错误！',
            436 => 'API 额度不足或 APIKey 不存在！',
            437 => 'IP 未在白名单内！',
            531 => '请求过于频繁！',
            532 => '未知错误，请联系管理员！'
        );
        $message = isset($error_codes[$status_code]) ? $error_codes[$status_code] : (isset($data['Reason']) ? $data['Reason'] : 'API 请求错误：HTTP ' . $status_code);
        wp_send_json_error(array('message' => '查询失败：' . esc_html($message)), $status_code);
        return;
    }

    if (isset($data['StateCode']) && $data['StateCode'] == 1) {
        $result = $data['Result'];
        $total_page = isset($result['TotalPage']) ? $result['TotalPage'] : 1;
        $page_no = isset($result['PageNo']) ? $result['PageNo'] : 1;
        $list = isset($result['List']) ? $result['List'] : array();

        $output = '<table class="xb_whoishistory_result_table">';
        $output .= '<thead><tr>';
        $output .= '<th>注册商</th><th>注册者</th><th>注册日期</th><th>更新日期</th><th>到期日期</th><th>域名状态</th><th>变更项</th>';
        $output .= '</tr></thead><tbody>';

        foreach ($list as $item) {
            $output .= '<tr>';
            $output .= '<td>' . esc_html($item['Registrar'] ?: '-') . '</td>';
            $output .= '<td>' . esc_html($item['ContactPerson'] ?: '-') . '</td>';
            $output .= '<td>' . esc_html($item['CreationDate'] ?: '-') . '</td>';
            $output .= '<td>' . esc_html($item['UpdateDate'] ?: '-') . '</td>';
            $output .= '<td>' . esc_html($item['ExpirationDate'] ?: '-') . '</td>';
            $output .= '<td>' . esc_html($item['DomainStatus'] ?: '-') . '</td>';
            $output .= '<td>' . esc_html($item['Variety'] ?: '-') . '</td>';
            $output .= '</tr>';
        }

        $output .= '</tbody></table>';

        // 分页导航
        $output .= '<div class="xb_whoishistory_pagination" data-domain="' . esc_attr($domain) . '" data-total-page="' . esc_attr($total_page) . '" data-current-page="' . esc_attr($page_no) . '">';
        $output .= '<button class="xb_whoishistory_prev_page" ' . ($page_no <= 1 ? 'disabled' : '') . '>上一页</button>';
        $output .= '<span class="xb_whoishistory_page_info">第 ' . esc_html($page_no) . ' 页 / 共 ' . esc_html($total_page) . ' 页</span>';
        $output .= '<button class="xb_whoishistory_next_page" ' . ($page_no >= $total_page ? 'disabled' : '') . '>下一页</button>';
        $output .= '</div>';

        wp_send_json_success(array('result' => $output));
    } else {
        wp_send_json_error(array('message' => '查询失败：' . esc_html(isset($data['Reason']) ? $data['Reason'] : '未知错误')), 400);
    }
}

// 添加管理菜单
add_action('admin_menu', 'xb_whoishistory_admin_menu');
function xb_whoishistory_admin_menu() {
    add_menu_page(
        'WHOIS 历史信息查询设置',
        'WHOIS 历史查询',
        'manage_options',
        'xb_whoishistory_settings',
        'xb_whoishistory_settings_page',
        'dashicons-search',
        80
    );
    add_submenu_page(
        'xb_whoishistory_settings',
        '查询记录',
        '查询记录',
        'manage_options',
        'xb_whoishistory_all_records',
        'xb_whoishistory_all_records_page'
    );
}

// 插件设置页面
function xb_whoishistory_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['xb_whoishistory_save_settings'])) {
        check_admin_referer('xb_whoishistory_settings_nonce');

        update_option('xb_whoishistory_api_url', sanitize_text_field($_POST['xb_whoishistory_api_url']));
        update_option('xb_whoishistory_api_key', sanitize_text_field($_POST['xb_whoishistory_api_key']));
        $new_limit = absint($_POST['xb_whoishistory_default_limit']);
        $new_guest_limit = absint($_POST['xb_whoishistory_guest_limit']);
        if ($new_limit > 0) {
            update_option('xb_whoishistory_default_limit', $new_limit);
        }
        if ($new_guest_limit > 0) {
            update_option('xb_whoishistory_guest_limit', $new_guest_limit);
        }
        $allowed_html = array(
            'a' => array('href' => array(), 'title' => array(), 'target' => array()),
            'img' => array('src' => array(), 'alt' => array(), 'width' => array(), 'height' => array()),
            'p' => array(),
            'div' => array('class' => array(), 'style' => array()),
            'span' => array('class' => array(), 'style' => array()),
            'strong' => array(),
            'em' => array(),
            'br' => array()
        );
        update_option('xb_whoishistory_ad_content', wp_kses($_POST['xb_whoishistory_ad_content'], $allowed_html));

        echo '<div id="xb_whoishistory_settings_notice" class="updated"><p>设置已保存！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_whoishistory_settings_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    global $wpdb;
    $queries_table = $wpdb->prefix . 'xb_whoishistory_queries';
    $stats = array();
    $stats['total_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table");
    $stats['success_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table WHERE query_status = 'success'");
    $stats['failed_queries'] = $stats['total_queries'] - $stats['success_queries'];
    $stats['today_queries'] = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $queries_table WHERE DATE(query_time) = %s", current_time('Y-m-d'))
    );

    ?>
    <div class="wrap">
        <div class="xb_whoishistory_admin_title">WHOIS 历史信息查询设置</div>
        <form method="post">
            <?php wp_nonce_field('xb_whoishistory_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_whoishistory_api_url">API 接口地址</label></th>
                    <td><input type="text" name="xb_whoishistory_api_url" id="xb_whoishistory_api_url" value="<?php echo esc_attr(get_option('xb_whoishistory_api_url', 'https://openapi.chinaz.net/v1/1001/whoishistory')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_whoishistory_api_key">API 密钥</label></th>
                    <td><input type="text" name="xb_whoishistory_api_key" id="xb_whoishistory_api_key" value="<?php echo esc_attr(get_option('xb_whoishistory_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_whoishistory_default_limit">登录用户每日查询次数</label></th>
                    <td><input type="number" name="xb_whoishistory_default_limit" id="xb_whoishistory_default_limit" value="<?php echo esc_attr(get_option('xb_whoishistory_default_limit', 5)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_whoishistory_guest_limit">游客每日查询次数</label></th>
                    <td><input type="number" name="xb_whoishistory_guest_limit" id="xb_whoishistory_guest_limit" value="<?php echo esc_attr(get_option('xb_whoishistory_guest_limit', 3)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_whoishistory_ad_content">广告内容</label></th>
                    <td>
                        <textarea name="xb_whoishistory_ad_content" id="xb_whoishistory_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_whoishistory_ad_content')); ?></textarea>
                        <p class="description">支持 HTML 格式。</p>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="xb_whoishistory_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        <div class="xb_whoishistory_stats">
            <p>总查询次数：<?php echo esc_html($stats['total_queries'] ?: 0); ?></p>
            <p>成功查询次数：<?php echo esc_html($stats['success_queries'] ?: 0); ?></p>
            <p>失败查询次数：<?php echo esc_html($stats['failed_queries'] ?: 0); ?></p>
            <p>今日查询次数：<?php echo esc_html($stats['today_queries'] ?: 0); ?></p>
        </div>
    </div>
    <?php
}

// 查询记录页面
function xb_whoishistory_all_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_whoishistory_usage';
    $queries_table = $wpdb->prefix . 'xb_whoishistory_queries';
    $user_id = isset($_POST['xb_whoishistory_user_id']) ? absint($_POST['xb_whoishistory_user_id']) : 0;
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    // 删除单条记录
    if (isset($_POST['xb_whoishistory_delete_record']) && isset($_POST['record_id'])) {
        check_admin_referer('xb_whoishistory_delete_record_nonce');
        $wpdb->delete($queries_table, array('id' => absint($_POST['record_id'])), array('%d'));
        echo '<div id="xb_whoishistory_delete_notice" class="updated"><p>记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_whoishistory_delete_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 删除用户全部记录
    if (isset($_POST['xb_whoishistory_delete_all_records']) && $user_id) {
        check_admin_referer('xb_whoishistory_delete_all_records_nonce');
        $wpdb->delete($queries_table, array('user_id' => $user_id), array('%d'));
        $wpdb->delete($usage_table, array('user_id' => $user_id), array('%d'));
        echo '<div id="xb_whoishistory_delete_all_notice" class="updated"><p>所有记录已删除！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_whoishistory_delete_all_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 保存用户自定义限制
    if (isset($_POST['xb_whoishistory_save_user_limit']) && $user_id) {
        check_admin_referer('xb_whoishistory_user_limit_nonce');
        $custom_limit = isset($_POST['xb_whoishistory_custom_limit']) ? absint($_POST['xb_whoishistory_custom_limit']) : null;

        $wpdb->update(
            $usage_table,
            array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
            array('user_id' => $user_id, 'query_date' => current_time('Y-m-d')),
            array('%d'),
            array('%d', '%s')
        );

        echo '<div id="xb_whoishistory_limit_notice" class="updated"><p>用户查询限制已更新！</p></div>';
        echo '<script>
        setTimeout(function() {
            var notice = document.getElementById("xb_whoishistory_limit_notice");
            if (notice) {
                notice.style.transition = "opacity 0.5s";
                notice.style.opacity = "0";
                setTimeout(function() { notice.remove(); }, 500);
            }
        }, 3000);
        </script>';
    }

    // 获取用户每日查询次数限制
    $default_limit = absint(get_option('xb_whoishistory_default_limit', 5));
    $guest_limit = absint(get_option('xb_whoishistory_guest_limit', 3));
    $user_limit = $user_id ? $default_limit : $guest_limit;
    if ($user_id || $user_id === 0) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT custom_limit FROM $usage_table WHERE user_id = %d AND query_date = %s LIMIT 1",
                $user_id,
                current_time('Y-m-d')
            )
        );
        if ($row && $row->custom_limit !== null) {
            $user_limit = absint($row->custom_limit);
        }
    }

    // 统计数据
    $stats = array();
    $where_clause = $user_id ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : '';
    $stats['total_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table $where_clause");
    $stats['success_queries'] = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table WHERE query_status = 'success' " . ($user_id ? $wpdb->prepare('AND user_id = %d', $user_id) : ''));
    $stats['failed_queries'] = $stats['total_queries'] - $stats['success_queries'];
    $stats['today_queries'] = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $queries_table WHERE DATE(query_time) = %s " . ($user_id ? 'AND user_id = %d' : ''), current_time('Y-m-d'), $user_id)
    );

    // 获取记录
    $offset = ($paged - 1) * $per_page;
    $query = $user_id
        ? $wpdb->prepare("SELECT id, user_id, ip_address, device_info, domain, query_status, query_time FROM $queries_table WHERE user_id = %d ORDER BY query_time DESC LIMIT %d, %d", $user_id, $offset, $per_page)
        : $wpdb->prepare("SELECT id, user_id, ip_address, device_info, domain, query_status, query_time FROM $queries_table ORDER BY query_time DESC LIMIT %d, %d", $offset, $per_page);
    $records = $wpdb->get_results($query);
    $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $queries_table" . ($user_id ? $wpdb->prepare(' WHERE user_id = %d', $user_id) : ''));
    $total_pages = ceil($total_records / $per_page);

    $user_info = $user_id && $user_id != 0 ? get_userdata($user_id) : null;
    $user_display = $user_id == 0 ? '游客' : ($user_info ? $user_info->user_login : '未知用户');
    ?>
    <div class="wrap">
        <div class="xb_whoishistory_admin_title">所有查询记录</div>
        <form method="post">
            <p>
                <label for="xb_whoishistory_user_id">输入用户 ID（0 表示游客，留空显示所有记录）：</label>
                <input type="number" name="xb_whoishistory_user_id" id="xb_whoishistory_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <?php if ($user_id || $user_id === 0): ?>
            <h2>用户：<?php echo esc_html($user_display); ?> (ID: <?php echo $user_id; ?>)</h2>
            <p>当前用户每日查询次数：<?php echo esc_html($user_limit); ?> 次</p>
            <form method="post">
                <?php wp_nonce_field('xb_whoishistory_user_limit_nonce'); ?>
                <p>
                    <label for="xb_whoishistory_custom_limit">设置自定义每日查询次数（0 表示使用默认值）：</label>
                    <input type="number" name="xb_whoishistory_custom_limit" id="xb_whoishistory_custom_limit" min="0">
                    <input type="hidden" name="xb_whoishistory_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_whoishistory_save_user_limit" class="button-primary" value="保存">
                </p>
            </form>
            <form method="post">
                <?php wp_nonce_field('xb_whoishistory_delete_all_records_nonce'); ?>
                <input type="hidden" name="xb_whoishistory_user_id" value="<?php echo esc_attr($user_id); ?>">
                <p><input type="submit" name="xb_whoishistory_delete_all_records" class="button-secondary" value="删除所有记录" onclick="return confirm('确定删除所有记录吗？');"></p>
            </form>
        <?php endif; ?>

        <div class="xb_whoishistory_stats">
            <p>总查询次数：<?php echo esc_html($stats['total_queries'] ?: 0); ?></p>
            <p>成功查询次数：<?php echo esc_html($stats['success_queries'] ?: 0); ?></p>
            <p>失败查询次数：<?php echo esc_html($stats['failed_queries'] ?: 0); ?></p>
            <p>今日查询次数：<?php echo esc_html($stats['today_queries'] ?: 0); ?></p>
        </div>

        <table class="widefat">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>IP 地址</th>
                    <th>设备信息</th>
                    <th>查询时间</th>
                    <th>域名</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="7">暂无查询记录。</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td><?php echo esc_html($record->user_id == 0 ? '游客' : $record->user_id); ?></td>
                            <td><?php echo esc_html($record->ip_address); ?></td>
                            <td><?php echo esc_html($record->device_info); ?></td>
                            <td><?php echo esc_html($record->query_time); ?></td>
                            <td><?php echo esc_html($record->domain); ?></td>
                            <td><?php echo esc_html($record->query_status); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_whoishistory_delete_record_nonce'); ?>
                                    <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>">
                                    <input type="submit" name="xb_whoishistory_delete_record" class="button-link" value="删除" onclick="return confirm('确定删除此记录？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}
?>