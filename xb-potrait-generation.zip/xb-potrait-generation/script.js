/**
 * 人像写真生成插件前端脚本
 */
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('xb-potrait-form');
    if (!form) return;

    let originalUrl = null;
    let customStyleUrl = null;
    let remainingCount = parseInt(document.getElementById('remaining-count')?.textContent || '0');
    const submitBtn = document.getElementById('xb-potrait-submit');

    // 上传按钮事件
    document.querySelectorAll('.xb-upload-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById(btn.dataset.target).click();
        });
    });

    // 图片上传处理
    ['original_image', 'custom_style_image'].forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            input.addEventListener('change', async function() {
                if (await validateImage(this)) {
                    uploadImage(this, id === 'original_image' ? 'original' : 'custom-style');
                } else {
                    this.value = '';
                }
            });
        }
    });

    // 验证图片
    async function validateImage(input) {
        const file = input.files[0];
        if (!file) {
            showCustomAlert('请选择图片');
            return false;
        }

        const ext = file.name.split('.').pop().toLowerCase();
        if (!xbPotrait.allowedFormats.includes(ext)) {
            showCustomAlert(`不支持的格式：${ext}，请使用 ${xbPotrait.allowedFormats.join(', ')}`);
            return false;
        }

        if (file.size > xbPotrait.maxSize) {
            showCustomAlert(`图片太大，请上传 ${xbPotrait.maxSize / 1024 / 1024}MB 以内的图片`);
            return false;
        }

        if (!['image/jpeg', 'image/png', 'image/bmp'].includes(file.type.toLowerCase())) {
            showCustomAlert('文件不是有效的图片格式');
            return false;
        }

        return new Promise(resolve => {
            const img = new Image();
            img.onload = () => {
                const width = img.width;
                const height = img.height;
                if (input.id === 'original_image') {
                    if (width < 256 || height < 256 || width > 2048 || height > 2048) {
                        showCustomAlert('人物图片分辨率需在256x256到2048x2048之间');
                        resolve(false);
                    } else {
                        resolve(true);
                    }
                } else {
                    if (width < 512 || height < 512 || width > 1680 || height > 1260) {
                        showCustomAlert('自定义模板图片分辨率需在512x512到1680x1260之间');
                        resolve(false);
                    } else {
                        resolve(true);
                    }
                }
            };
            img.onerror = () => {
                showCustomAlert('图片文件不正确，请更换真实图片');
                resolve(false);
            };
            img.src = URL.createObjectURL(file);
        });
    }

    // 上传图片
    function uploadImage(input, type) {
        const formData = new FormData();
        formData.append(type === 'original' ? 'original_image' : 'custom_style_image', input.files[0]);

        fetch(`${xbPotrait.restUrl}/upload`, {
            method: 'POST',
            body: formData,
            headers: { 'X-WP-Nonce': xbPotrait.nonce }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                if (type === 'original') {
                    originalUrl = data.image_url;
                    document.getElementById('original-preview').innerHTML = `<img src="${originalUrl}" alt="原图">`;
                    if (submitBtn) submitBtn.disabled = false; // 启用开始生成按钮
                } else {
                    customStyleUrl = data.image_url;
                    document.getElementById('custom-style-preview').innerHTML = `<img src="${customStyleUrl}" alt="自定义风格">`;
                }
            } else {
                showCustomAlert('上传失败: ' + data.message);
                input.value = '';
                if (type === 'original' && submitBtn) submitBtn.disabled = true; // 上传失败时禁用按钮
            }
        })
        .catch(() => {
            showCustomAlert('上传失败，请稍后再试');
            input.value = '';
            if (type === 'original' && submitBtn) submitBtn.disabled = true; // 上传失败时禁用按钮
        });
    }

    // 提交生成任务
    if (submitBtn) {
        submitBtn.addEventListener('click', () => {
            if (!originalUrl) {
                showCustomAlert('请上传人物图片');
                return;
            }

            const style = document.getElementById('style_select').value;
            document.getElementById('xb-result-message').innerHTML = '<div class="xb-loading">正在生成中...<span class="xb-loading-dots"><span>.</span><span>.</span><span>.</span></span></div>';

            fetch(`${xbPotrait.restUrl}/submit`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': xbPotrait.nonce
                },
                body: JSON.stringify({
                    original_url: originalUrl,
                    style: style,
                    custom_style_url: customStyleUrl
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    pollResult(data.task_id);
                    submitBtn.disabled = true; // 提交后禁用按钮
                } else {
                    document.getElementById('xb-result-message').innerHTML = `<div class="xb-error">${data.message}</div>`;
                    submitBtn.disabled = false; // 失败后重新启用按钮
                }
            })
            .catch(() => {
                document.getElementById('xb-result-message').innerHTML = '<div class="xb-error">提交失败，请稍后再试</div>';
                submitBtn.disabled = false; // 失败后重新启用按钮
            });
        });
    }

    // 轮询结果
    function pollResult(task_id) {
        const interval = setInterval(() => {
            fetch(`${xbPotrait.restUrl}/result/${task_id}`, {
                headers: { 'X-WP-Nonce': xbPotrait.nonce }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('xb-result-message').innerHTML = '';
                    document.getElementById('result-preview').innerHTML = `
                        <div class="xb-result-item">
                            <img src="${data.result_url}" alt="生成结果">
                        </div>
                        <button class="xb-download-btn" data-url="${data.result_url}">一键下载</button>`;
                    remainingCount--;
                    document.getElementById('remaining-count').textContent = remainingCount;
                    if (remainingCount <= 0) {
                        document.getElementById('xb-remaining-count').innerHTML = '今日使用次数已经用完了，请明天再来';
                        if (submitBtn) submitBtn.disabled = true;
                    }
                    attachDownloadEvents();
                    clearInterval(interval);
                } else if (data.message !== '任务尚未完成') {
                    let errorMessage = data.message;
                    if (data.message.includes('InvalidImageResolution')) {
                        errorMessage = '生成失败：输入图片分辨率过大或过小，请确保人物图片分辨率在256x256到2048x2048之间，自定义模板在512x512到1680x1260之间';
                    } else if (data.message.includes('InternalError:Algo')) {
                        errorMessage = '生成失败：请检查图片是否损坏或确保包含清晰的正脸（人脸角度不超过15度）';
                    }
                    document.getElementById('xb-result-message').innerHTML = `<div class="xb-error">${errorMessage}</div>`;
                    if (submitBtn) submitBtn.disabled = false; // 失败后重新启用按钮
                    clearInterval(interval);
                }
            })
            .catch(() => {
                document.getElementById('xb-result-message').innerHTML = '<div class="xb-error">获取结果失败，请稍后再试</div>';
                if (submitBtn) submitBtn.disabled = false; // 失败后重新启用按钮
                clearInterval(interval);
            });
        }, 5000);
    }

    // 下载按钮事件
    function attachDownloadEvents() {
        document.querySelectorAll('.xb-download-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
                const url = btn.dataset.url;
                try {
                    const response = await fetch(url);
                    const blob = await response.blob();
                    const link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = `potrait_${Date.now()}.jpg`;
                    link.click();
                    URL.revokeObjectURL(link.href);
                } catch (e) {
                    showCustomAlert('下载失败，请稍后再试');
                }
            });
        });
    }

    // 自定义提示框
    function showCustomAlert(message, duration = 3000) {
        const alertBox = document.getElementById('xb-custom-alert');
        const alertMessage = document.getElementById('xb-custom-alert-message');
        alertMessage.textContent = message;
        alertBox.classList.add('show');
        setTimeout(() => alertBox.classList.remove('show'), duration);
        document.getElementById('xb-custom-alert-close').addEventListener('click', () => {
            alertBox.classList.remove('show');
        }, { once: true });
    }

    // “请先登录”按钮点击事件
    document.querySelectorAll('.wp-potrait-login-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const themeLoginBtn = document.querySelector('.nav-login .signin-loader');
            if (themeLoginBtn) {
                themeLoginBtn.click();
            } else {
                window.location.href = xbPotrait.loginUrl;
            }
        });
    });
});