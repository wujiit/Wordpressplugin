<?php
/*
Plugin Name: 小半人像写真生成
Description: 基于通义千问模型的人物写真生成插件，支持上传图片、选择预置风格或自定义风格生成写真。
Version: 1.3
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 插件激活时执行
 */
register_activation_hook(__FILE__, 'xb_potrait_activate');
function xb_potrait_activate() {
    // 创建数据表
    xb_potrait_create_tables();
    // 创建前台页面
    xb_potrait_create_front_page();
}

/**
 * 创建数据库表
 */
function xb_potrait_create_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 任务表
    $table_name = $wpdb->prefix . 'xb_potrait_tasks';
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        task_id varchar(255) NOT NULL,
        original_image_url varchar(255) NOT NULL,
        style varchar(255) NOT NULL,
        custom_style_url varchar(255) DEFAULT NULL,
        result_image_url varchar(255) DEFAULT NULL,
        status varchar(50) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        completed_at datetime DEFAULT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // 用户每日限制表
    $limit_table = $wpdb->prefix . 'xb_potrait_user_limits';
    $limit_sql = "CREATE TABLE $limit_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        daily_limit int NOT NULL,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    dbDelta($limit_sql);
}

/**
 * 创建前台页面
 */
function xb_potrait_create_front_page() {
    // 检查是否已有包含短代码的页面
    $pages = get_posts([
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_potrait_form]',
        'numberposts' => 1,
    ]);

    // 如果没有，创建新页面
    if (empty($pages)) {
        wp_insert_post([
            'post_title'   => '人像智能写真生成',
            'post_content' => '[xb_potrait_form]',
            'post_status'  => 'publish',
            'post_author'  => 1,
            'post_type'    => 'page',
            'post_name'    => 'potrait-generation'
        ]);
    }
}

/**
 * 在插件列表添加设置链接
 */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'xb_potrait_add_settings_link');
function xb_potrait_add_settings_link($links) {
    $settings_link = '<a href="admin.php?page=xb-potrait-settings">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}

/**
 * 添加后台菜单
 */
add_action('admin_menu', 'xb_potrait_admin_menu');
function xb_potrait_admin_menu() {
    add_menu_page('人像写真设置', '人像写真', 'manage_options', 'xb-potrait-settings', 'xb_potrait_settings_page', 'dashicons-camera');
    add_submenu_page('xb-potrait-settings', '生成记录', '生成记录', 'manage_options', 'xb-potrait-records', 'xb_potrait_records_page');
}

/**
 * 设置页面
 */
function xb_potrait_settings_page() {
    if (isset($_POST['xb_potrait_save'])) {
        update_option('xb_potrait_api_url', sanitize_text_field($_POST['api_url']));
        update_option('xb_potrait_api_key', sanitize_text_field($_POST['api_key']));
        update_option('xb_potrait_model_params', sanitize_text_field($_POST['model_params']));
        update_option('xb_potrait_styles', sanitize_text_field($_POST['styles']));
        update_option('xb_potrait_enable_custom_style', isset($_POST['enable_custom_style']) ? 1 : 0);
        update_option('xb_potrait_daily_limit', max(1, intval($_POST['daily_limit'])));
        update_option('xb_potrait_notice', wp_kses_post($_POST['notice_content']));
        update_option('xb_potrait_allowed_formats', sanitize_text_field($_POST['allowed_formats']));
        update_option('xb_potrait_max_size', max(1, intval($_POST['max_size'])));
        echo '<div class="updated" id="xb-settings-saved-message"><p>设置已保存</p></div>';
    }

    $api_url = get_option('xb_potrait_api_url', 'https://dashscope.aliyuncs.com/api/v1/services/aigc/album/gen_potrait');
    $api_key = get_option('xb_potrait_api_key', '');
    $model_params = get_option('xb_potrait_model_params', 'facechain-generation');
    $styles = get_option('xb_potrait_styles', 'f_idcard_female(证件照女),f_business_female(商务写真女),m_springflower_female(春日花园)');
    $enable_custom_style = get_option('xb_potrait_enable_custom_style', 0);
    $daily_limit = get_option('xb_potrait_daily_limit', 10);
    $notice_content = get_option('xb_potrait_notice', '');
    $allowed_formats = get_option('xb_potrait_allowed_formats', 'jpg,jpeg,png,bmp');
    $max_size = get_option('xb_potrait_max_size', 3);

    ?>
    <div class="wrap">
        <h1>人像写真设置</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>API 请求地址</th>
                    <td><input type="text" name="api_url" value="<?php echo esc_attr($api_url); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>API Key</th>
                    <td><input type="text" name="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>模型参数</th>
                    <td><input type="text" name="model_params" value="<?php echo esc_attr($model_params); ?>" class="regular-text"><p>多个参数用英文逗号分隔，默认使用第一个</p></td>
                </tr>
                <tr>
                    <th>预置风格</th>
                    <td><input type="text" name="styles" value="<?php echo esc_attr($styles); ?>" class="regular-text"><p>格式：值(名称)，如 f_idcard_female(证件照女),f_business_female(商务写真女)</p></td>
                </tr>
                <tr>
                    <th>支持自定义风格图片</th>
                    <td><input type="checkbox" name="enable_custom_style" value="1" <?php checked($enable_custom_style, 1); ?>> 启用</td>
                </tr>
                <tr>
                    <th>默认每天生成次数限制</th>
                    <td><input type="number" name="daily_limit" value="<?php echo esc_attr($daily_limit); ?>" min="1" class="regular-text"><p>每位用户每天默认生成次数</p></td>
                </tr>
                <tr>
                    <th>公告内容</th>
                    <td><textarea name="notice_content" rows="5" class="large-text"><?php echo esc_textarea($notice_content); ?></textarea><p>支持HTML格式</p></td>
                </tr>
                <tr>
                    <th>支持的图片格式</th>
                    <td><input type="text" name="allowed_formats" value="<?php echo esc_attr($allowed_formats); ?>" class="regular-text"><p>多个格式用英文逗号分隔，如 jpg,jpeg,png,bmp</p></td>
                </tr>
                <tr>
                    <th>最大图片大小(MB)</th>
                    <td><input type="number" name="max_size" value="<?php echo esc_attr($max_size); ?>" min="1" class="regular-text"><p>上传图片的最大大小，单位MB</p></td>
                </tr>
            </table>
            <p><input type="submit" name="xb_potrait_save" class="button-primary" value="保存设置"></p>
        </form>
        <p>参考文档：<a href="https://help.aliyun.com/zh/model-studio/facechain-generation" target="_blank">通义千问人物写真生成API</a></p>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const message = document.getElementById('xb-settings-saved-message');
            if (message) {
                setTimeout(() => message.style.display = 'none', 3000);
            }
        });
    </script>
    <?php
}

/**
 * 生成记录页面
 */
function xb_potrait_records_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_potrait_tasks';
    $limit_table = $wpdb->prefix . 'xb_potrait_user_limits';
    $per_page = 20;
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $search_user_id = isset($_GET['search_user_id']) ? intval($_GET['search_user_id']) : '';

    // 处理用户限制设置
    if (isset($_POST['set_user_limit']) && isset($_POST['user_id']) && isset($_POST['new_limit'])) {
        $user_id = intval($_POST['user_id']);
        $new_limit = max(0, intval($_POST['new_limit']));
        $existing = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $limit_table WHERE user_id = %d", $user_id));
        if ($existing) {
            $wpdb->update($limit_table, ['daily_limit' => $new_limit, 'updated_at' => current_time('mysql')], ['user_id' => $user_id]);
        } else {
            $wpdb->insert($limit_table, ['user_id' => $user_id, 'daily_limit' => $new_limit]);
        }
        echo '<div class="updated" id="xb-limit-updated-message"><p>用户每日限制已更新</p></div>';
    }

    // 删除记录
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['record_id'])) {
        $record_id = intval($_GET['record_id']);
        $wpdb->delete($table_name, ['id' => $record_id]);
        echo '<div class="updated" id="xb-record-deleted-message"><p>记录已删除</p></div>';
    }

    // 清除用户自定义限制
    if (isset($_GET['action']) && $_GET['action'] === 'clear_limit' && isset($_GET['user_id'])) {
        $user_id = intval($_GET['user_id']);
        $wpdb->delete($limit_table, ['user_id' => $user_id]);
        wp_redirect(admin_url('admin.php?page=xb-potrait-records&search_user_id=' . $user_id));
        exit;
    }

    $where = '';
    if ($search_user_id) {
        $where = $wpdb->prepare("WHERE user_id = %d", $search_user_id);
    }

    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
    $offset = ($paged - 1) * $per_page;
    $records = $wpdb->get_results("SELECT * FROM $table_name $where ORDER BY created_at DESC LIMIT $offset, $per_page");

    $all_records_total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $user_total = $search_user_id ? $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d", $search_user_id)) : 0;
    $today_count = 0;
    $user_limit = $search_user_id ? $wpdb->get_var($wpdb->prepare("SELECT daily_limit FROM $limit_table WHERE user_id = %d", $search_user_id)) : null;
    $default_limit = get_option('xb_potrait_daily_limit', 10);

    if ($search_user_id) {
        $today_start = current_time('Y-m-d 00:00:00');
        $today_end = current_time('Y-m-d 23:59:59');
        $today_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND created_at BETWEEN %s AND %s AND status = 'SUCCEEDED'",
            $search_user_id, $today_start, $today_end
        ));
    }

    ?>
    <div class="wrap">
        <h1>生成记录</h1>
        <p>总生成次数: <?php echo $all_records_total; ?>
        <?php if ($search_user_id) { ?>
            (用户 <?php echo esc_html($search_user_id); ?> 总生成次数: <?php echo $user_total; ?> | 
            今日生成次数: <?php echo $today_count; ?> | 
            每日限制: <?php echo $user_limit !== null ? $user_limit : $default_limit . ' (默认)'; ?>)
        <?php } ?></p>

        <form method="get" action="" style="margin-bottom: 10px;">
            <input type="hidden" name="page" value="xb-potrait-records">
            <label>搜索用户ID: <input type="number" name="search_user_id" value="<?php echo esc_attr($search_user_id); ?>"></label>
            <input type="submit" class="button" value="搜索">
            <?php if ($search_user_id) { ?>
                <a href="?page=xb-potrait-records" class="button">查看全部记录</a>
            <?php } ?>
        </form>

        <?php if ($search_user_id) { ?>
            <form method="post" style="margin-bottom: 10px;">
                <label>设置用户 <?php echo esc_html($search_user_id); ?> 的每日生成次数限制:
                    <input type="number" name="new_limit" value="<?php echo esc_attr($user_limit !== null ? $user_limit : $default_limit); ?>" min="0">
                </label>
                <input type="hidden" name="user_id" value="<?php echo esc_attr($search_user_id); ?>">
                <input type="submit" name="set_user_limit" class="button" value="更新限制">
                <?php if ($user_limit !== null) { ?>
                    <a href="?page=xb-potrait-records&action=clear_limit&user_id=<?php echo $search_user_id; ?>" 
                       class="button" 
                       onclick="return confirm('确定要清除此用户的自定义限制吗？将恢复使用默认限制');">清除自定义限制</a>
                <?php } ?>
            </form>
        <?php } ?>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户ID</th>
                    <th>用户名</th>
                    <th>原图</th>
                    <th>风格</th>
                    <th>自定义风格图</th>
                    <th>结果</th>
                    <th>生成时间</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record) {
                    $user = get_user_by('id', $record->user_id);
                    ?>
                    <tr>
                        <td><?php echo esc_html($record->user_id); ?></td>
                        <td><?php echo esc_html($user ? $user->user_login : '未知用户'); ?></td>
                        <td><img src="<?php echo esc_url($record->original_image_url); ?>" style="max-width: 100px;"></td>
                        <td><?php echo esc_html($record->style); ?></td>
                        <td><?php echo $record->custom_style_url ? '<img src="' . esc_url($record->custom_style_url) . '" style="max-width: 100px;">' : '无'; ?></td>
                        <td><?php echo $record->result_image_url ? '有' : '无'; ?></td>
                        <td><?php echo esc_html($record->completed_at ?: $record->created_at); ?></td>
                        <td><?php echo $record->status === 'SUCCEEDED' ? '成功' : ($record->status === 'FAILED' ? '失败' : '处理中'); ?></td>
                        <td><a href="?page=xb-potrait-records&action=delete&record_id=<?php echo $record->id; ?><?php echo $search_user_id ? '&search_user_id=' . $search_user_id : ''; ?>" class="button" onclick="return confirm('确定删除此记录吗？');">删除</a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <?php
        $total_pages = ceil($total / $per_page);
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            $pagination_args = [
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ];
            if ($search_user_id) {
                $pagination_args['add_args'] = ['search_user_id' => $search_user_id];
            }
            echo paginate_links($pagination_args);
            echo '</div></div>';
        }
        ?>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            ['xb-limit-updated-message', 'xb-record-deleted-message'].forEach(id => {
                const message = document.getElementById(id);
                if (message) {
                    setTimeout(() => message.style.display = 'none', 3000);
                }
            });
        });
    </script>
    <?php
}

/**
 * 加载前端资源
 */
add_action('wp_enqueue_scripts', 'xb_potrait_enqueue_assets');
function xb_potrait_enqueue_assets() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_potrait_form')) {
        wp_enqueue_style('xb-potrait-style', plugins_url('style.css', __FILE__), [], '1.3');
        wp_enqueue_script('xb-potrait-script', plugins_url('script.js', __FILE__), ['jquery'], '1.3', true);
        wp_localize_script('xb-potrait-script', 'xbPotrait', [
            'restUrl' => rest_url('xb-potrait/v1'),
            'nonce' => wp_create_nonce('wp_rest'),
            'allowedFormats' => explode(',', get_option('xb_potrait_allowed_formats', 'jpg,jpeg,png,bmp')),
            'maxSize' => get_option('xb_potrait_max_size', 3) * 1024 * 1024,
            'loginUrl' => wp_login_url(get_permalink())
        ]);
    }
}

/**
 * 检查用户每日生成次数
 */
function xb_potrait_check_daily_limit($user_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_potrait_tasks';
    $limit_table = $wpdb->prefix . 'xb_potrait_user_limits';

    $user_limit = $wpdb->get_var($wpdb->prepare("SELECT daily_limit FROM $limit_table WHERE user_id = %d", $user_id));
    $daily_limit = $user_limit !== null ? $user_limit : get_option('xb_potrait_daily_limit', 10);

    if ($daily_limit == 0) {
        return ['exceeded' => false, 'count' => 0, 'limit' => $daily_limit, 'remaining' => PHP_INT_MAX];
    }

    $today_start = current_time('Y-m-d 00:00:00');
    $today_end = current_time('Y-m-d 23:59:59');
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND created_at BETWEEN %s AND %s AND status = 'SUCCEEDED'",
        $user_id, $today_start, $today_end
    ));

    return [
        'exceeded' => $count >= $daily_limit,
        'count' => $count,
        'limit' => $daily_limit,
        'remaining' => $daily_limit - $count
    ];
}

/**
 * 前台短代码
 */
add_shortcode('xb_potrait_form', 'xb_potrait_form_shortcode');
function xb_potrait_form_shortcode() {
    $styles = get_option('xb_potrait_styles', 'f_idcard_female(证件照女),f_business_female(商务写真女),m_springflower_female(春日花园)');
    $style_arr = array_map(function($style) {
        preg_match('/([^\(]+)\((.+)\)/', $style, $matches);
        return ['value' => $matches[1], 'name' => $matches[2]];
    }, explode(',', $styles));
    $enable_custom_style = get_option('xb_potrait_enable_custom_style', 0);
    $notice_content = get_option('xb_potrait_notice', '');

    $user_id = get_current_user_id();
    $limit_check = $user_id ? xb_potrait_check_daily_limit($user_id) : ['exceeded' => false, 'count' => 0, 'limit' => 0, 'remaining' => 0];
    $exceeded_limit = $limit_check['exceeded'];
    $daily_count = $limit_check['count'];
    $daily_limit = $limit_check['limit'];
    $remaining_count = $limit_check['remaining'];

    ob_start();
    ?>
    <div id="xb-potrait-form">
        <div class="xb-page-title">人像Ai智能写真 证件照生成</div>
        <?php if (!$user_id) { ?>
            <div class="xb-login-prompt">
                <p>请先登录以使用人像写真生成功能！</p>
                <a href="<?php echo wp_login_url(get_permalink()); ?>" class="xb-login-link xb-modern-btn wp-potrait-login-btn">点击这里登录</a>
            </div>
        <?php } else if ($exceeded_limit) { ?>
            <div class="xb-limit-prompt">
                <p>今日使用次数已经用完了，请明天再来</p>
            </div>
        <?php } else { ?>
            <div class="xb-main-area">
                <div class="xb-left-panel">
                    <div class="xb-section-title">上传与配置</div>
                    <div class="xb-upload-field">
                        <label>上传人物图片:</label>
                        <input type="file" id="original_image" accept="image/jpeg,image/png,image/jpg,image/bmp" hidden>
                        <button type="button" class="xb-modern-btn xb-upload-btn" data-target="original_image">选择图片</button>
                    </div>
                    <div id="original-preview" class="xb-preview-box"></div>
                    <div class="xb-upload-field">
                        <label>选择预置风格:</label>
                        <select id="style_select">
                            <?php foreach ($style_arr as $style) { ?>
                                <option value="<?php echo esc_attr($style['value']); ?>"><?php echo esc_html($style['name']); ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <?php if ($enable_custom_style) { ?>
                    <div class="xb-right-panel">
                        <div class="xb-section-title">自定义风格</div>
                        <div class="xb-upload-field">
                            <label>上传自定义风格图片:</label>
                            <input type="file" id="custom_style_image" accept="image/jpeg,image/png,image/jpg,image/bmp" hidden>
                            <button type="button" class="xb-modern-btn xb-upload-btn" data-target="custom_style_image">选择图片</button>
                        </div>
                        <div id="custom-style-preview" class="xb-preview-box"></div>
                    </div>
                <?php } ?>
            </div>
            <div class="xb-submit-area">
                <button id="xb-potrait-submit" class="xb-modern-btn" disabled>开始生成</button>
            </div>
            <div id="xb-remaining-count">
                今日剩余生成次数：<span id="remaining-count"><?php echo esc_html($remaining_count); ?></span>/<?php echo esc_html($daily_limit); ?>
            </div>
            <div class="xb-result-area">
                <div class="xb-section-title">生成结果</div>
                <div id="xb-result-message"></div>
                <div id="result-preview" class="xb-result-box"></div>
            </div>
        <?php } ?>
        <?php if (!empty($notice_content)) { ?>
            <div id="xb-notice">
                <div class="xb-notice-content"><?php echo wp_kses_post($notice_content); ?></div>
            </div>
        <?php } ?>
        <div id="xb-demo-section">
            <div class="xb-section-title">效果图演示</div>
            <div class="xb-demo-image">
                <img src="https://aiimg.qiyucloud.com/htai/2025/05/20250512102536672.png" alt="效果图演示">
            </div>
        </div>
        <div id="xb-custom-alert" class="xb-custom-alert">
            <div class="xb-custom-alert-content">
                <span id="xb-custom-alert-message"></span>
                <button id="xb-custom-alert-close" class="xb-custom-alert-close">×</button>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * 注册 REST API
 */
add_action('rest_api_init', 'xb_potrait_register_api');
function xb_potrait_register_api() {
    register_rest_route('xb-potrait/v1', '/upload', [
        'methods' => 'POST',
        'callback' => 'xb_potrait_upload_image',
        'permission_callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_forbidden', '请先登录', ['status' => 401]);
            }
            return wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest');
        }
    ]);

    register_rest_route('xb-potrait/v1', '/submit', [
        'methods' => 'POST',
        'callback' => 'xb_potrait_submit_task',
        'permission_callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_forbidden', '请先登录', ['status' => 401]);
            }
            $user_id = get_current_user_id();
            $limit_check = xb_potrait_check_daily_limit($user_id);
            if ($limit_check['exceeded']) {
                return new WP_Error('rest_forbidden', '今日生成次数已用完，请明天再来', ['status' => 403]);
            }
            return wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest');
        }
    ]);

    register_rest_route('xb-potrait/v1', '/result/(?P<task_id>[a-zA-Z0-9-]+)', [
        'methods' => 'GET',
        'callback' => 'xb_potrait_get_result',
        'permission_callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_Error('rest_forbidden', '请先登录', ['status' => 401]);
            }
            return wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest');
        }
    ]);
}

/**
 * 上传图片
 */
function xb_potrait_upload_image($request) {
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    $files = $request->get_file_params();
    $type = !empty($files['original_image']) ? 'original_image' : 'custom_style_image';
    if (empty($files[$type])) {
        return new WP_REST_Response(['success' => false, 'message' => '请上传图片'], 400);
    }

    $file = $files[$type];
    $allowed_formats = array_map('trim', explode(',', get_option('xb_potrait_allowed_formats', 'jpg,jpeg,png,bmp')));
    $allowed_mime_types = array_map(function($ext) {
        return 'image/' . ($ext === 'jpg' ? 'jpeg' : $ext);
    }, $allowed_formats);
    $max_size = get_option('xb_potrait_max_size', 3) * 1024 * 1024;

    // 检查文件大小
    if ($file['size'] > $max_size) {
        return new WP_REST_Response(['success' => false, 'message' => "图片太大，请上传 {$max_size}MB 以内的图片"], 400);
    }

    // 检查文件扩展名
    $file_name = strtolower($file['name']);
    $file_extension = pathinfo($file_name, PATHINFO_EXTENSION);
    if (!in_array($file_extension, $allowed_formats)) {
        return new WP_REST_Response(['success' => false, 'message' => "不支持的图片格式：{$file_extension}，请更换支持的格式"], 400);
    }

    // 检查 MIME 类型
    if (!in_array(strtolower($file['type']), $allowed_mime_types)) {
        return new WP_REST_Response(['success' => false, 'message' => '文件不是有效的图片格式'], 400);
    }

    // 检查文件真实性
    $image_info = @getimagesize($file['tmp_name']);
    if ($image_info === false) {
        return new WP_REST_Response(['success' => false, 'message' => '图片文件不正确，请更换真实图片'], 400);
    }

    // 检查分辨率 (256x256 to 2048x2048 for original, 512x512 to 1680x1260 for custom)
    $width = $image_info[0];
    $height = $image_info[1];
    if ($type === 'original_image') {
        if ($width < 256 || $height < 256 || $width > 2048 || $height > 2048) {
            return new WP_REST_Response(['success' => false, 'message' => '图片分辨率需在256x256到2048x2048之间'], 400);
        }
    } else {
        if ($width < 512 || $height < 512 || $width > 1680 || $height > 1260) {
            return new WP_REST_Response(['success' => false, 'message' => '自定义模板图片分辨率需在512x512到1680x1260之间'], 400);
        }
    }

    // 检查文件头
    $file_handle = @fopen($file['tmp_name'], 'rb');
    if ($file_handle === false) {
        return new WP_REST_Response(['success' => false, 'message' => '无法读取文件'], 400);
    }
    $file_header = fread($file_handle, 8);
    fclose($file_handle);
    $valid_headers = [
        "\xFF\xD8" => 'image/jpeg',
        "\x89PNG\r\n" => 'image/png',
        "BM" => 'image/bmp'
    ];
    $is_valid_header = false;
    foreach ($valid_headers as $header => $mime) {
        if (strpos($file_header, $header) === 0) {
            $is_valid_header = true;
            break;
        }
    }
    if (!$is_valid_header) {
        return new WP_REST_Response(['success' => false, 'message' => '图片文件不正确，请更换真实图片'], 400);
    }

    // 上传到媒体库
    $upload_id = media_handle_upload($type, 0);
    if (is_wp_error($upload_id)) {
        return new WP_REST_Response(['success' => false, 'message' => '上传失败: ' . $upload_id->get_error_message()], 500);
    }

    $image_url = wp_get_attachment_url($upload_id);
    return new WP_REST_Response(['success' => true, 'image_url' => $image_url], 200);
}

/**
 * 提交生成任务
 */
function xb_potrait_submit_task($request) {
    $params = $request->get_json_params();
    if (!$params) {
        return new WP_REST_Response(['success' => false, 'message' => '无效请求数据'], 400);
    }

    $original_url = $params['original_url'] ?? '';
    $style = $params['style'] ?? '';
    $custom_style_url = $params['custom_style_url'] ?? null;

    if (empty($original_url) || empty($style)) {
        return new WP_REST_Response(['success' => false, 'message' => '缺少必要参数'], 400);
    }

    // 验证 URL 不包含中文字符
    if (preg_match('/[\x{4e00}-\x{9fff}]/u', $original_url) || ($custom_style_url && preg_match('/[\x{4e00}-\x{9fff}]/u', $custom_style_url))) {
        return new WP_REST_Response(['success' => false, 'message' => '图片URL不能包含中文字符'], 400);
    }

    $api_url = get_option('xb_potrait_api_url');
    $api_key = get_option('xb_potrait_api_key');
    $model = explode(',', get_option('xb_potrait_model_params', 'facechain-generation'))[0];
    $enable_custom_style = get_option('xb_potrait_enable_custom_style', 0);

    if (empty($api_key)) {
        return new WP_REST_Response(['success' => false, 'message' => 'API Key 未配置'], 500);
    }

    $body = [
        'model' => $model,
        'parameters' => [
            'style' => $custom_style_url && $enable_custom_style ? 'train_free_portrait_url_template' : $style,
            'n' => 1,
            'size' => '768*1024'
        ]
    ];

    if ($custom_style_url && $enable_custom_style) {
        $body['input'] = [
            'template_url' => $custom_style_url,
            'user_urls' => [$original_url]
        ];
    } else {
        $body['resources'] = [
            [
                'resource_id' => 'women_model',
                'resource_type' => 'facelora'
            ]
        ];
    }

    $response = wp_remote_post($api_url, [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'X-DashScope-Async' => 'enable',
            'Content-Type' => 'application/json'
        ],
        'body' => json_encode($body),
        'timeout' => 30
    ]);

    if (is_wp_error($response)) {
        return new WP_REST_Response(['success' => false, 'message' => 'API 请求失败: ' . $response->get_error_message()], 500);
    }

    $response_body = wp_remote_retrieve_body($response);
    $response_code = wp_remote_retrieve_response_code($response);
    $data = json_decode($response_body, true);

    if ($response_code !== 200 || !isset($data['output']['task_id'])) {
        $error_message = $data['message'] ?? '未知错误';
        $error_code = $data['code'] ?? 'Unknown';
        return new WP_REST_Response(['success' => false, 'message' => "API 错误: $error_message ($error_code)"], 500);
    }

    global $wpdb;
    $wpdb->insert($wpdb->prefix . 'xb_potrait_tasks', [
        'user_id' => get_current_user_id(),
        'task_id' => $data['output']['task_id'],
        'original_image_url' => $original_url,
        'style' => $style,
        'custom_style_url' => $custom_style_url,
        'status' => $data['output']['task_status']
    ]);

    return new WP_REST_Response([
        'success' => true,
        'task_id' => $data['output']['task_id']
    ], 200);
}

/**
 * 获取生成结果
 */
function xb_potrait_get_result($request) {
    $task_id = $request['task_id'];
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_potrait_tasks';
    $task = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE task_id = %s", $task_id));

    if (!$task) {
        return new WP_REST_Response(['success' => false, 'message' => '任务不存在'], 404);
    }

    if ($task->result_image_url) {
        return new WP_REST_Response(['success' => true, 'result_url' => $task->result_image_url], 200);
    }

    $api_key = get_option('xb_potrait_api_key');
    $response = wp_remote_get("https://dashscope.aliyuncs.com/api/v1/tasks/$task_id", [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json'
        ],
        'timeout' => 15
    ]);

    if (is_wp_error($response)) {
        return new WP_REST_Response(['success' => false, 'message' => 'API 请求失败: ' . $response->get_error_message()], 500);
    }

    $response_body = wp_remote_retrieve_body($response);
    $response_code = wp_remote_retrieve_response_code($response);
    $data = json_decode($response_body, true);

    if ($response_code !== 200 || !isset($data['output'])) {
        $error_message = $data['message'] ?? '无法获取任务状态';
        $error_code = $data['code'] ?? 'Unknown';
        return new WP_REST_Response(['success' => false, 'message' => "API 错误: $error_message ($error_code)"], 500);
    }

    $task_status = $data['output']['task_status'];
    $wpdb->update($table_name, ['status' => $task_status], ['task_id' => $task_id]);

    if ($task_status === 'SUCCEEDED' && !empty($data['output']['results'][0]['url'])) {
        $result_url = $data['output']['results'][0]['url'];
        $wpdb->update($table_name, [
            'result_image_url' => $result_url,
            'status' => 'SUCCEEDED',
            'completed_at' => current_time('mysql')
        ], ['task_id' => $task_id]);

        return new WP_REST_Response(['success' => true, 'result_url' => $result_url], 200);
    } elseif ($task_status === 'FAILED') {
        $error_message = $data['output']['message'] ?? '生成失败';
        $error_code = $data['output']['code'] ?? 'Unknown';
        $wpdb->update($table_name, ['status' => 'FAILED'], ['task_id' => $task_id]);
        return new WP_REST_Response(['success' => false, 'message' => "生成失败: $error_message ($error_code)"], 500);
    } elseif ($task_status === 'UNKNOWN') {
        $wpdb->update($table_name, ['status' => 'UNKNOWN'], ['task_id' => $task_id]);
        return new WP_REST_Response(['success' => false, 'message' => '任务状态未知或不存在'], 404);
    }

    return new WP_REST_Response(['success' => false, 'message' => '任务尚未完成'], 202);
}
?>