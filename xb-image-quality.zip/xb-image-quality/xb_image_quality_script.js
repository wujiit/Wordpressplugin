jQuery(document).ready(function($) {
    let selectedFile = null;
    let enhancedImageData = null;

    // 自定义提示框函数
    function showAlert(message) {
        $('#xb_image_quality_alert_msg').text(message);
        $('#xb_image_quality_alert').fadeIn();
        setTimeout(function() {
            $('#xb_image_quality_alert').fadeOut();
        }, 3000);
    }

    // 更新剩余次数显示
    function updateRemainingCount(count) {
        $('#remaining_count').text(count);
    }

    // 检查文件是否为真实图片
    function isValidImage(file) {
        return new Promise((resolve) => {
            const img = new Image();
            const objectUrl = URL.createObjectURL(file);
            img.onload = () => {
                URL.revokeObjectURL(objectUrl);
                resolve(true);
            };
            img.onerror = () => {
                URL.revokeObjectURL(objectUrl);
                resolve(false);
            };
            img.src = objectUrl;
        });
    }

    // 检查文件格式是否在允许范围内
    function isAllowedFormat(file) {
        const extension = file.name.split('.').pop().toLowerCase();
        return xb_image_quality_vars.allowed_formats.includes(extension);
    }

    $('#xb_image_quality_alert_close').on('click', function() {
        $('#xb_image_quality_alert').fadeOut();
    });

    $('#xb_image_quality_select').on('click', function() {
        $('#xb_image_quality_upload').click();
    });

    $('#xb_image_quality_upload').on('change', async function(e) {
        selectedFile = e.target.files[0];
        if (!selectedFile) {
            showAlert('请选择文件！');
            return;
        }

        // 检查文件大小
        if (selectedFile.size > xb_image_quality_vars.max_size) {
            showAlert('文件大小超过限制！');
            selectedFile = null;
            $('#xb_image_quality_enhance').prop('disabled', true);
            return;
        }

        // 检查是否为真实图片
        const isImageValid = await isValidImage(selectedFile);
        if (!isImageValid) {
            showAlert('文件不是真实的图片，请更换图片！');
            selectedFile = null;
            $('#xb_image_quality_enhance').prop('disabled', true);
            $('#xb_image_quality_original_img').hide();
            $('.xb_image_quality_original .xb_image_quality_placeholder').show();
            return;
        }

        // 检查格式是否支持
        if (!isAllowedFormat(selectedFile)) {
            showAlert('图片格式不支持，仅支持：' + xb_image_quality_vars.allowed_formats.join(', '));
            selectedFile = null;
            $('#xb_image_quality_enhance').prop('disabled', true);
            $('#xb_image_quality_original_img').hide();
            $('.xb_image_quality_original .xb_image_quality_placeholder').show();
            return;
        }

        // 文件通过所有检查，显示预览
        const reader = new FileReader();
        reader.onload = function(e) {
            $('#xb_image_quality_original_img').attr('src', e.target.result).show();
            $('.xb_image_quality_original .xb_image_quality_placeholder').hide();
            $('#xb_image_quality_enhance').prop('disabled', false);
        };
        reader.readAsDataURL(selectedFile);
    });

    $('#xb_image_quality_enhance').on('click', function() {
        if (!selectedFile) {
            showAlert('请先选择图片！');
            return;
        }
        $('.xb_image_quality_enhanced .xb_image_quality_placeholder').hide();
        $('.xb_image_quality_processing').show();
        const formData = new FormData();
        formData.append('file', selectedFile);

        $.ajax({
            url: '/wp-json/wp/v2/media',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            headers: { 'X-WP-Nonce': xb_image_quality_vars.nonce },
            success: function(media) {
                $.ajax({
                    url: xb_image_quality_vars.ajax_url,
                    method: 'POST',
                    data: JSON.stringify({ image_url: media.source_url }),
                    contentType: 'application/json',
                    headers: { 'X-WP-Nonce': xb_image_quality_vars.nonce },
                    success: function(response) {
                        enhancedImageData = response.enhanced_image;
                        $('.xb_image_quality_processing').hide();
                        $('#xb_image_quality_enhanced_img').attr('src', enhancedImageData).show();
                        $('#xb_image_quality_download').show();
                        updateRemainingCount(response.remaining_count);
                    },
                    error: function(xhr) {
                        $('.xb_image_quality_processing').hide();
                        $('.xb_image_quality_enhanced .xb_image_quality_placeholder').show();
                        showAlert(xhr.responseJSON.message);
                    }
                });
            },
            error: function(xhr) {
                $('.xb_image_quality_processing').hide();
                $('.xb_image_quality_enhanced .xb_image_quality_placeholder').show();
                showAlert('图片上传失败！');
            }
        });
    });

    $('#xb_image_quality_download').on('click', function() {
        if (!enhancedImageData) return;
        const ext = enhancedImageData.includes('png') ? 'png' : 'jpg';
        const randomName = 'enhanced_' + Math.random().toString(36).substr(2, 9) + '.' + ext;
        const link = document.createElement('a');
        link.href = enhancedImageData;
        link.download = randomName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });

    $('.xb_image_quality_login_btn').on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = wp_login_url;
        }
    });
});