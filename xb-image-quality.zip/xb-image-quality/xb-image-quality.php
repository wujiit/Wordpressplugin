<?php
/*
Plugin Name: 小半AI图像放大
Description: 基于百度云实现无损放大图片。
Version: 1.0.2
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 创建数据表
function xb_image_quality_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_image_quality_logs';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        original_image VARCHAR(255) NOT NULL,
        enhanced_image VARCHAR(255) NOT NULL,
        enhance_time DATETIME NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'xb_image_quality_create_table');

// 创建前台页面
function xb_image_quality_create_front_page() {
    $pages = get_posts([
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_image_quality_shortcode]',
        'numberposts' => 1,
    ]);

    if (empty($pages)) {
        wp_insert_post([
            'post_title'    => '图像无损放大',
            'post_name'     => 'image-quality-enhance',
            'post_content'  => '[xb_image_quality_shortcode]',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
        ]);
    }
}
register_activation_hook(__FILE__, 'xb_image_quality_create_front_page');

// 插件列表页面添加设置入口
function xb_image_quality_add_settings_link($links) {
    $settings_link = '<a href="admin.php?page=xb-image-quality-settings">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'xb_image_quality_add_settings_link');

// 添加菜单
add_action('admin_menu', 'xb_image_quality_menu');
function xb_image_quality_menu() {
    add_menu_page('图像无损放大设置', '图像放大', 'manage_options', 'xb-image-quality-settings', 'xb_image_quality_settings_page', 'dashicons-images-alt2');
    add_submenu_page('xb-image-quality-settings', 'User Enhance Logs', '用户放大记录', 'manage_options', 'xb-image-quality-logs', 'xb_image_quality_logs_page');
}

// 设置页面
function xb_image_quality_settings_page() {
    if (isset($_POST['xb_image_quality_save'])) {
        update_option('xb_image_quality_apikey', sanitize_text_field($_POST['xb_image_quality_apikey']));
        update_option('xb_image_quality_formats', sanitize_text_field($_POST['xb_image_quality_formats']));
        update_option('xb_image_quality_max_size', intval($_POST['xb_image_quality_max_size']));
        update_option('xb_image_quality_daily_limit', intval($_POST['xb_image_quality_daily_limit']));
        update_option('xb_image_quality_notice', wp_kses_post($_POST['xb_image_quality_notice']));
        echo '<div class="updated" id="xp-image-settings-saved-message"><p>设置已保存。</p></div>';
    }
    $apikey = get_option('xb_image_quality_apikey', '');
    $formats = get_option('xb_image_quality_formats', 'jpg,png');
    $max_size = get_option('xb_image_quality_max_size', 3);
    $daily_limit = get_option('xb_image_quality_daily_limit', 10);
    $notice = get_option('xb_image_quality_notice', '');
    ?>
    <div class="wrap">
        <h1>图像无损放大设置</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>百度云 API Key</th>
                    <td><input type="text" name="xb_image_quality_apikey" value="<?php echo esc_attr($apikey); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>支持的图片格式</th>
                    <td><input type="text" name="xb_image_quality_formats" value="<?php echo esc_attr($formats); ?>" class="regular-text">（用逗号分隔，如 jpg,png）</td>
                </tr>
                <tr>
                    <th>最大文件大小 (MB)</th>
                    <td><input type="number" name="xb_image_quality_max_size" value="<?php echo esc_attr($max_size); ?>" min="1"></td>
                </tr>
                <tr>
                    <th>每日使用次数限制（默认）</th>
                    <td><input type="number" name="xb_image_quality_daily_limit" value="<?php echo esc_attr($daily_limit); ?>" min="1"></td>
                </tr>
                <tr>
                    <th>公告内容</th>
                    <td><textarea name="xb_image_quality_notice" rows="5" class="large-text"><?php echo esc_textarea($notice); ?></textarea><p>支持 HTML 格式</p></td>
                </tr>
            </table>
            <p><input type="submit" name="xb_image_quality_save" class="button-primary" value="保存设置"></p>
        </form>
        由百度云提供：https://cloud.baidu.com/doc/IMAGEPROCESS/s/ok3bclnkg<br>
        单价：0.006元/次
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const settingsSavedMessage = document.getElementById('xp-image-settings-saved-message');
            if (settingsSavedMessage) {
                setTimeout(() => {
                    settingsSavedMessage.style.display = 'none';
                }, 3000);
            }
        });
    </script>
    <?php
}

// 用户放大记录页面
function xb_image_quality_logs_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_image_quality_logs';
    $total_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $user_id_filter = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

    if (isset($_POST['xb_set_user_limit'])) {
        $user_limit = intval($_POST['xb_user_daily_limit']);
        if ($user_limit > 0) {
            update_user_meta($user_id_filter, 'xb_image_quality_daily_limit', $user_limit);
            echo '<div class="updated"><p>用户每日限制已设置为 ' . $user_limit . '。</p></div>';
        }
    }
    if (isset($_POST['xb_reset_user_limit'])) {
        delete_user_meta($user_id_filter, 'xb_image_quality_daily_limit');
        echo '<div class="updated"><p>用户每日限制已恢复为默认值。</p></div>';
    }

    if ($user_id_filter) {
        $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d ORDER BY enhance_time DESC", $user_id_filter));
        $user_total = count($logs);
        $today_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(enhance_time) = CURDATE()", $user_id_filter));
        $user_limit = get_user_meta($user_id_filter, 'xb_image_quality_daily_limit', true);
        $daily_limit = $user_limit ? $user_limit : get_option('xb_image_quality_daily_limit', 10);
    } else {
        $logs = $wpdb->get_results("SELECT * FROM $table_name ORDER BY enhance_time DESC");
    }

    if (isset($_GET['delete_id'])) {
        $wpdb->delete($table_name, ['id' => intval($_GET['delete_id'])], ['%d']);
        echo '<div class="updated" id="xp-image-settings-saved-message"><p>记录已删除。</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>用户放大记录</h1>
        <p>总放大次数: <?php echo $total_count; ?></p>
        <?php if ($user_id_filter) { ?>
            <p>用户 <?php echo $user_id_filter; ?> 总放大次数: <?php echo $user_total; ?>，今日放大次数: <?php echo $today_count; ?>，每日限制: <?php echo $daily_limit; ?></p>
            <form method="post" style="margin-bottom: 20px;">
                <label>设置用户每日放大次数限制: </label>
                <input type="number" name="xb_user_daily_limit" value="<?php echo $user_limit ?: ''; ?>" min="1" placeholder="<?php echo $daily_limit; ?>">
                <input type="submit" name="xb_set_user_limit" class="button" value="设置">
                <input type="submit" name="xb_reset_user_limit" class="button" value="恢复默认">
            </form>
        <?php } ?>
        <form method="get">
            <input type="hidden" name="page" value="xb-image-quality-logs">
            <input type="number" name="user_id" placeholder="输入用户ID" value="<?php echo $user_id_filter; ?>">
            <input type="submit" value="查询" class="button">
        </form>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户ID</th>
                    <th>用户名</th>
                    <th>原始图片</th>
                    <th>放大时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log) {
                    $user = get_userdata($log->user_id);
                    ?>
                    <tr>
                        <td><?php echo $log->user_id; ?></td>
                        <td><?php echo $user ? $user->user_login : '未知'; ?></td>
                        <td><img src="<?php echo esc_url($log->original_image); ?>" width="100" height="100"></td>
                        <td><?php echo $log->enhance_time; ?></td>
                        <td><a href="?page=xb-image-quality-logs&delete_id=<?php echo $log->id; ?>" onclick="return confirm('确定删除?');">删除</a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const settingsSavedMessage = document.getElementById('xp-image-settings-saved-message');
            if (settingsSavedMessage) {
                setTimeout(() => {
                    settingsSavedMessage.style.display = 'none';
                }, 3000);
            }
        });
    </script>
    <?php
}

// 前台短代码
add_shortcode('xb_image_quality_shortcode', 'xb_image_quality_front_page');
function xb_image_quality_front_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_image_quality_logs';
    $user_id = get_current_user_id();
    $default_limit = get_option('xb_image_quality_daily_limit', 50);
    $user_limit = get_user_meta($user_id, 'xb_image_quality_daily_limit', true);
    $daily_limit = $user_limit ? $user_limit : $default_limit;
    $today_count = $user_id ? $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(enhance_time) = CURDATE()", $user_id)) : 0;
    $formats = get_option('xb_image_quality_formats', 'jpg,png');
    $accept = '.' . str_replace(',', ',.', $formats);
    $notice = get_option('xb_image_quality_notice', '');
    $remaining_count = $daily_limit - $today_count;
    
    ob_start();
    ?>
    <div class="xb_image_quality_container">
        <div class="xb_image_quality_title">图像AI无损放大处理</div>
        <?php if (is_user_logged_in() && $today_count < $daily_limit) { ?>
            <div class="xb_image_quality_buttons">
                <input type="file" id="xb_image_quality_upload" accept="<?php echo esc_attr($accept); ?>">
                <button id="xb_image_quality_select">选择图片</button>
                <button id="xb_image_quality_enhance" disabled>开始放大</button>
            </div>
        <?php } elseif (is_user_logged_in()) { ?>
            <div class="xb_image_quality_buttons">
                <p class="xb_image_quality_limit">已达到每日放大次数限制</p>
            </div>
        <?php } else { ?>
            <div class="xb_image_quality_buttons">
                <p class="xb_image_quality_notice">请先登录 <button class="xb_image_quality_login_btn">快速登录</button></p>
            </div>
        <?php } ?>
        <div class="xb_image_quality_preview">
            <div class="xb_image_quality_original">
                <span class="xb_image_quality_subtitle">原始图片</span>
                <div class="xb_image_quality_placeholder">请上传图片</div>
                <img id="xb_image_quality_original_img" src="" style="display: none;">
            </div>
            <div class="xb_image_quality_enhanced">
                <span class="xb_image_quality_subtitle">放大后图片</span>
                <div class="xb_image_quality_placeholder">等待放大</div>
                <div class="xb_image_quality_processing" style="display: none;">正在处理中<span class="dots"></span></div>
                <img id="xb_image_quality_enhanced_img" src="" style="display: none;">
                <button id="xb_image_quality_download" style="display: none;">快速下载</button>
            </div>
        </div>
        <div class="xb_image_quality_usage" id="usage_counter">
            <p>今日剩余放大次数：<span id="remaining_count"><?php echo $remaining_count; ?></span>/<?php echo $daily_limit; ?></p>
        </div>
        <?php if ($notice) { ?>
            <div class="xb_image_quality_notice_content"><?php echo wp_kses_post($notice); ?></div>
        <?php } ?>
        <div class="xb_image_quality_example">
            <h3 class="xb_image_quality_example_title">使用示例</h3>
            <div class="xb_image_quality_example_images">
                <div class="xb_image_quality_example_original">
                    <span class="xb_image_quality_subtitle">原始图片</span>
                    <img src="https://aiimg.qiyucloud.com/htai/2025/04/20250408104316984.jpg" alt="原始图片" width="200" height="150">
                </div>
                <div class="xb_image_quality_example_arrow">➔</div>
                <div class="xb_image_quality_example_enhanced">
                    <span class="xb_image_quality_subtitle">放大后图片</span>
                    <img src="https://aiimg.qiyucloud.com/htai/2025/04/20250408104316748.jpg" alt="放大后图片">
                </div>
            </div>
        </div>
    </div>
    <div id="xb_image_quality_alert" class="xb_image_quality_alert">
        <span id="xb_image_quality_alert_msg"></span>
        <button id="xb_image_quality_alert_close">关闭</button>
    </div>
    <?php
    return ob_get_clean();
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_image_quality_enqueue_scripts');
function xb_image_quality_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_image_quality_shortcode')) {
        //wp_enqueue_style('xb_image_quality_style', plugins_url('xb_image_quality_style.css', __FILE__), [], '1.0');
        //wp_enqueue_script('xb_image_quality_script', plugins_url('xb_image_quality_script.js', __FILE__), ['jquery'], '1.0', true);

        wp_enqueue_style('xb_image_quality_style', 'https://img.qiyucloud.com/cloud/xb-image-quality/xb_image_quality_style.css');
        wp_enqueue_script('xb_image_quality_script', 'https://img.qiyucloud.com/cloud/xb-image-quality/xb_image_quality_script.js', ['jquery'], '1.0.2', true);

        // 将支持的格式传递给前端
        $formats = explode(',', get_option('xb_image_quality_formats', 'jpg,png'));
        wp_localize_script('xb_image_quality_script', 'xb_image_quality_vars', [
            'ajax_url' => rest_url('xb_image_quality/v1/enhance'),
            'nonce' => wp_create_nonce('wp_rest'),
            'max_size' => get_option('xb_image_quality_max_size', 3) * 1024 * 1024,
            'allowed_formats' => array_map('trim', $formats), // 支持的格式数组
        ]);
    }
}

// REST API 注册
add_action('rest_api_init', 'xb_image_quality_register_api');
function xb_image_quality_register_api() {
    register_rest_route('xb_image_quality/v1', '/enhance', [
        'methods' => 'POST',
        'callback' => 'xb_image_quality_enhance_image',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ]);
}

function xb_image_quality_enhance_image($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_image_quality_logs';
    $user_id = get_current_user_id();
    $default_limit = get_option('xb_image_quality_daily_limit', 50);
    $user_limit = get_user_meta($user_id, 'xb_image_quality_daily_limit', true);
    $daily_limit = $user_limit ? $user_limit : $default_limit;
    $today_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(enhance_time) = CURDATE()",
        $user_id
    ));

    if ($today_count >= $daily_limit) {
        return new WP_Error('limit_exceeded', '已达到每日放大次数限制', ['status' => 403]);
    }

    $image_url = $request->get_param('image_url');
    $apikey = get_option('xb_image_quality_apikey');
    if (!$apikey || !$image_url) {
        return new WP_Error('invalid_data', '缺少必要参数', ['status' => 400]);
    }

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://aip.baidubce.com/rest/2.0/image-process/v1/image_quality_enhance",
        CURLOPT_TIMEOUT => 30,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => http_build_query(['url' => $image_url]),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/x-www-form-urlencoded',
            'Accept: application/json',
            'Authorization: Bearer ' . $apikey,
        ],
    ]);
    $response = curl_exec($curl);
    $curl_error = curl_error($curl);
    curl_close($curl);

    $data = json_decode($response, true);
    if (isset($data['image'])) {
        $ext = strtolower(pathinfo($image_url, PATHINFO_EXTENSION));
        $base64_header = $ext === 'png' ? 'data:image/png;base64,' : 'data:image/jpeg;base64,';
        $enhanced_image = $base64_header . $data['image'];

        $insert_result = $wpdb->insert(
            $table_name,
            [
                'user_id' => $user_id,
                'original_image' => $image_url,
                'enhanced_image' => 'enhanced_' . time() . '.' . $ext,
                'enhance_time' => current_time('mysql'),
            ],
            ['%d', '%s', '%s', '%s']
        );

        if (false === $insert_result) {
            error_log('XB Image Quality Enhancer: Database insert failed. Error: ' . $wpdb->last_error);
            return new WP_Error('db_insert_failed', '记录保存失败: ' . $wpdb->last_error, ['status' => 500]);
        }

        $remaining_count = $daily_limit - ($today_count + 1);
        return [
            'enhanced_image' => $enhanced_image,
            'ext' => $ext,
            'remaining_count' => $remaining_count
        ];
    } else {
        error_log('XB Image Quality Enhancer: Baidu API failed. Response: ' . $response . ' | Curl Error: ' . $curl_error);
        return new WP_Error('enhance_failed', '图片放大失败', ['status' => 500]);
    }
}