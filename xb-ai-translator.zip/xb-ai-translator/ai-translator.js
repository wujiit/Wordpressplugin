jQuery(document).ready(function($) {
    // Ensure AITranslateData exists
    if (typeof AITranslateData === 'undefined') {
        console.error('AITranslateData is not defined.');
        $('.ai_translate_result_content').html('<p class="ai_translate_error">初始化失败，请刷新页面或联系管理员。</p>');
        return;
    }

    // Check if user is logged in (i.e., textarea exists)
    const $textarea = $('#ai_translate_input');
    const isLoggedIn = $textarea.length > 0;

    // Language button handling (only for logged-in users)
    if (isLoggedIn) {
        $('.ai_translate_language_button').click(function() {
            $(this).toggleClass('active');
            console.log('Language button clicked. Active languages:', $('.ai_translate_language_button.active').map(function() { return $(this).data('value'); }).get());
        });

        // Example button
        $('.ai_translate_example_button').click(function(e) {
            e.preventDefault();
            const exampleData = window.ai_translate_example_data || '';
            $textarea.val(exampleData);
            console.log('Example button clicked. Input:', exampleData);
            updateCharCount();
        });

        // Polish toggle
        $('.ai_translate_polish_slider').click(function() {
            const $checkbox = $('#ai_translate_polish');
            $checkbox.prop('checked', !$checkbox.prop('checked'));
            console.log('Polish toggle clicked. Checked:', $checkbox.is(':checked'));
        });

        // Character count
        function updateCharCount() {
            const charCount = $textarea.val().length;
            const maxChars = AITranslateData.char_limit || 200;
            $('.ai_translate_char_count span').text(charCount);
            if (charCount > maxChars) {
                $('.ai_translate_char_count').addClass('ai_translate_char_exceed');
            } else {
                $('.ai_translate_char_count').removeClass('ai_translate_char_exceed');
            }
            console.log('Char count updated. Count:', charCount, 'Max:', maxChars);
        }

        // Bind input event and initialize char count
        $textarea.on('input', updateCharCount);
        updateCharCount();

        // Generate button
        $('.ai_translate_generate_button').click(function(e) {
            e.preventDefault();
            
            const $resultContent = $('.ai_translate_result_content');
            const inputData = $textarea.val();
            const $generateButton = $(this);

            console.log('Generate button clicked. Input:', inputData, 'Languages:', $('.ai_translate_language_button.active').map(function() { return $(this).data('value'); }).get());

            // Validate input
            if (!inputData) {
                $resultContent.html('<p class="ai_translate_error">请输入需要翻译的文本</p>');
                console.log('Error: Input is empty');
                return;
            }

            // Validate character limit
            if (inputData.length > AITranslateData.char_limit) {
                $resultContent.html('<p class="ai_translate_error">输入内容超过 ' + AITranslateData.char_limit + ' 字，请删减后重试</p>');
                console.log('Error: Input exceeds char limit');
                return;
            }

            // Validate forbidden words
            const forbiddenWords = AITranslateData.forbidden_words || [];
            let foundForbiddenWord = null;
            if (forbiddenWords.length > 0) {
                forbiddenWords.forEach(function(word) {
                    if (inputData.toLowerCase().indexOf(word.toLowerCase()) !== -1) {
                        foundForbiddenWord = word;
                    }
                });
            }

            if (foundForbiddenWord) {
                $resultContent.html('<p class="ai_translate_error">输入内容包含违规词“' + foundForbiddenWord + '”，请重新编辑内容</p>');
                console.log('Error: Forbidden word:', foundForbiddenWord);
                return;
            }

            // Validate selected languages
            const selectedLanguages = [];
            $('.ai_translate_language_button.active').each(function() {
                selectedLanguages.push($(this).data('value'));
            });

            if (selectedLanguages.length === 0) {
                $resultContent.html('<p class="ai_translate_error">请至少选择一种目标语言</p>');
                console.log('Error: No languages selected');
                return;
            }

            // Show loading state
            $resultContent.html('<span class="loading">正在翻译中...</span>');
            console.log('Showing loading state');
            
            if (!AITranslateData.nonce) {
                $resultContent.html('<p class="ai_translate_error">请先登录以使用翻译助手。</p>');
                console.log('Error: No nonce, user not logged in');
                return;
            }

            const data = {
                model: $('#ai_translate_model').val() || 'deepseek-chat',
                data: inputData,
                languages: selectedLanguages,
                polish: $('#ai_translate_polish').is(':checked').toString()
            };

            $generateButton.prop('disabled', true);
            console.log('Sending API request:', data);

            fetch(AITranslateData.rest_url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': AITranslateData.nonce,
                    'Accept': 'text/event-stream'
                },
                body: JSON.stringify(data)
            }).then(response => {
                if (!response.ok) {
                    return response.json().then(error => {
                        throw new Error(error.message || '请求失败');
                    });
                }

                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let done = false;
                let hasContent = false;

                function readStream() {
                    reader.read().then(({ done: streamDone, value }) => {
                        if (streamDone) {
                            done = true;
                            if (hasContent) {
                                updateUsageCount();
                            } else {
                                $resultContent.html('<p class="ai_translate_error">翻译失败，未收到有效内容。</p>');
                            }
                            $generateButton.prop('disabled', false);
                            console.log('Stream done. Has content:', hasContent);
                            return;
                        }

                        const chunk = decoder.decode(value, { stream: true });
                        const lines = chunk.split('\n').filter(line => line.trim());
                        lines.forEach(line => {
                            if (line.startsWith('data: ')) {
                                const jsonData = line.substring(6);
                                if (jsonData === '[DONE]') {
                                    done = true;
                                    if (hasContent) {
                                        updateUsageCount();
                                    } else {
                                        $resultContent.html('<p class="ai_translate_error">翻译失败，未收到有效内容。</p>');
                                    }
                                    $generateButton.prop('disabled', false);
                                    console.log('Stream [DONE]');
                                    return;
                                }

                                try {
                                    const data = JSON.parse(jsonData);
                                    if (data.error) {
                                        $resultContent.html('<p class="ai_translate_error">' + (data.error || '未知错误') + '</p>');
                                        $generateButton.prop('disabled', false);
                                        console.log('Error from API:', data.error);
                                        return;
                                    }
                                    if ($resultContent.find('.loading').length) {
                                        $resultContent.empty();
                                    }
                                    if (data.content) {
                                        hasContent = true;
                                        $resultContent.append(document.createTextNode(data.content));
                                        console.log('Received content:', data.content);
                                    }
                                } catch (e) {
                                    console.error('解析流数据出错:', e, '数据:', jsonData);
                                }
                            }
                        });

                        if (!done) {
                            readStream();
                        }
                    }).catch(error => {
                        console.error('流读取失败:', error);
                        $resultContent.html('<p class="ai_translate_error">翻译失败，请稍后重试。</p>');
                        $generateButton.prop('disabled', false);
                    });
                }

                readStream();
            }).catch(error => {
                console.error('API 请求失败:', error);
                $resultContent.html('<p class="ai_translate_error">' + error.message + '</p>');
                $generateButton.prop('disabled', false);
            });
        });

        // Copy button
        $('.ai_translate_copy_button').click(function(e) {
            e.preventDefault();
            const $temp = $('<textarea>');
            $('body').append($temp);
            $temp.val($('.ai_translate_result_content').text()).select();
            document.execCommand('copy');
            $temp.remove();

            $('.ai_translate_copy_success').html('<p class="copy-success">复制成功！</p>');
            setTimeout(function() {
                $('.ai_translate_copy_success').empty();
            }, 2000);
            console.log('Copy button clicked');
        });

        // Clear button
        $('.ai_translate_clear_button').click(function(e) {
            e.preventDefault();
            $('.ai_translate_result_content').empty();
            console.log('Clear button clicked');
        });

        // Update usage count
        function updateUsageCount() {
            $.ajax({
                url: AITranslateData.rest_url.replace('/generate', '/usage'),
                method: 'GET',
                headers: {
                    'X-WP-Nonce': AITranslateData.nonce
                },
                success: function(response) {
                    if (response.remaining > 0) {
                        $('.ai_translate_usage').text('今日可用次数：' + response.remaining + '/' + response.limit);
                        $('.ai_translate_generate_button').show();
                        $('.ai_translate_generate_button').prop('disabled', false);
                    } else {
                        $('.ai_translate_usage').text('今日已经使用完，请明天再来');
                        $('.ai_translate_generate_button').hide();
                    }
                    console.log('Usage updated. Remaining:', response.remaining, 'Limit:', response.limit);
                },
                error: function() {
                    $('.ai_translate_usage').text('今日可用次数：无法加载');
                    $('.ai_translate_generate_button').hide();
                    console.log('Usage fetch failed');
                }
            });
        }

        updateUsageCount();
    }

    // Quick login button (available for guests)
    $('.ai_translate_quick_login_button').on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = AITranslateData.login_url || '/wp-login.php';
        }
        console.log('Login button clicked');
    });
});