<?php
/**
 * Plugin Name: 小半心愿单
 * Plugin URI: https://www.jingxialai.com/4914.html
 * Description: 自定义心愿单，仅限已登录用户提交。
 * Version: 1.2
 * Author: Summer
 * License: GPL License
 * Author URI: https://www.jingxialai.com/
 */

if (!defined('ABSPATH')) {
    exit; // 禁止直接访问
}

// 插件列表页面添加设置链接
function wishlist_settings_link($links) {
    $settings_link = '<a href="admin.php?page=wishlist-settings">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wishlist_settings_link');


class WP_Wishlist_Plugin {

    public function __construct() {
        register_activation_hook(__FILE__, [$this, 'activate']);
        add_action('init', [$this, 'register_pages']);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_post_submit_wishlist', [$this, 'handle_submission']);
        add_action('admin_post_delete_wishlist', [$this, 'delete_submission']);
        add_shortcode('wishlist_form', [$this, 'wishlist_form_shortcode']);
        add_shortcode('wishlist_display', [$this, 'wishlist_display_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_styles']);
        add_action('admin_post_process_wishlist', [$this, 'process_wishlist_submission']);
    }
    
    public function activate() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wishlist';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED DEFAULT NULL,
            data TEXT NOT NULL,
            status VARCHAR(20) DEFAULT 'Pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        $this->create_pages();
    }

    public function create_pages() {
        $wishlist_form_page = [
            'post_title' => '心愿单提交',
            'post_content' => '[wishlist_form]',
            'post_status' => 'publish',
            'post_type' => 'page'
        ];

        $wishlist_display_page = [
            'post_title' => '心愿单统计展示',
            'post_content' => '[wishlist_display]',
            'post_status' => 'publish',
            'post_type' => 'page'
        ];

        wp_insert_post($wishlist_form_page);
        wp_insert_post($wishlist_display_page);
    }

    public function register_pages() {
        add_rewrite_rule('^wishlist-form/?$', 'index.php?pagename=wishlist-form', 'top');
        add_rewrite_rule('^wishlistdisplay/?$', 'index.php?pagename=wishlistdisplay', 'top');
    }

    public function admin_menu() {
        add_menu_page(
            '心愿单',
            '心愿单列表',
            'manage_options',
            'wishlist-plugin',
            [$this, 'wishlist_admin_page'],
            'dashicons-heart'
        );

        add_submenu_page(
            'wishlist-plugin',
            '心愿单选项设置',
            '心愿单设置',
            'manage_options',
            'wishlist-settings',
            [$this, 'wishlist_settings_page']
        );
    }

    public function wishlist_admin_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wishlist';
        $per_page = 15;
        $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $offset = ($paged - 1) * $per_page;

        $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name ORDER BY created_at DESC LIMIT %d OFFSET %d", $per_page, $offset));

        echo '<div class="wrap"><h1>心愿单列表</h1><table class="widefat"><thead><tr><th>ID</th><th>用户ID</th><th>心愿</th><th>提交日期</th><th>状态</th><th>处理</th></tr></thead><tbody>';
        foreach ($results as $row) {
            $data = json_decode($row->data, true);
            $formatted_data = '';
            foreach ($data as $key => $value) {
                $formatted_data .= '<strong>' . esc_html($key) . ':</strong> ' . esc_html($value) . '<br>';
            }

            $status = isset($row->status) ? esc_html($row->status) : 'Pending';

            echo "<tr><td>{$row->id}</td><td>{$row->user_id}</td><td>{$formatted_data}</td><td>{$row->created_at}</td><td>{$status}</td><td>";
            echo "<a href='" . admin_url("admin-post.php?action=process_wishlist&id={$row->id}&status=accept") . "' class='button'>同意</a> ";
            echo "<a href='" . admin_url("admin-post.php?action=process_wishlist&id={$row->id}&status=reject") . "' class='button button-danger'>拒绝</a> ";
            echo "<a href='" . admin_url("admin-post.php?action=delete_wishlist&id={$row->id}") . "' class='button button-secondary'>删除</a>";
            echo '</td></tr>';
        }
        echo '</tbody></table>';

        $total_items = $wpdb->get_var("SELECT COUNT(id) FROM $table_name");
        $total_pages = ceil($total_items / $per_page);

        if ($total_pages > 1) {
            echo '<div class="tablenav bottom"><div class="tablenav-pages"><span class="displaying-num">' . sprintf(__('显示 %d-%d 条记录，共 %d 条', 'wp_wishlist_plugin'), ($offset + 1), min($offset + $per_page, $total_items), $total_items) . '</span>';
            echo paginate_links([
                'base'    => admin_url("admin.php?page=wishlist-plugin&paged=%#%"),
                'format'  => '',
                'current' => $paged,
                'total'   => $total_pages,
                'prev_text' => __('« 上一页', 'wp_wishlist_plugin'),
                'next_text' => __('下一页 »', 'wp_wishlist_plugin')
            ]);
            echo '</div></div>';
        }

        echo '</div>';
    }

    public function process_wishlist_submission() {
        if (!isset($_GET['id'], $_GET['status']) || !current_user_can('manage_options')) {
            wp_die('Unauthorized request');
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'wishlist';
        $id = intval($_GET['id']);
        $status = sanitize_text_field($_GET['status']);

        if (!in_array($status, ['accept', 'reject'], true)) {
            wp_die('Invalid status');
        }

        $wpdb->update($table_name, ['status' => $status], ['id' => $id]);

        wp_redirect(admin_url('admin.php?page=wishlist-plugin'));
        exit;
    }


public function wishlist_settings_page() {
    $message = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['wishlist_settings_nonce']) && wp_verify_nonce($_POST['wishlist_settings_nonce'], 'wishlist_settings')) {
        $fields = isset($_POST['wishlist_fields']) && is_array($_POST['wishlist_fields']) ? $_POST['wishlist_fields'] : [];
        $description = isset($_POST['wishlist_description']) ? wp_kses_post($_POST['wishlist_description']) : '';
        $display_description = isset($_POST['wishlist_display_description']) ? wp_kses_post($_POST['wishlist_display_description']) : '';

        update_option('wishlist_fields', $fields);
        update_option('wishlist_description', $description);
        update_option('wishlist_display_description', $display_description);

        $message = '已保存'; // 成功后的提示消息
    }

    $fields = get_option('wishlist_fields', []);
    $description = get_option('wishlist_description', '');
    $display_description = get_option('wishlist_display_description', '');

    if (!is_array($fields)) {
        $fields = [];
    }

    ?>
        <style>
            .wishlist-settings-page {
                background: #f9f9f9;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                max-width: 800px;
            }
            .wishlist-settings-page h1 {
                font-size: 1.5em;
                margin-bottom: 20px;
            }
            .wishlist-settings-page form p {
                margin-bottom: 15px;
            }
        </style>
    <div class="wrap wishlist-settings-page">
        <h1>心愿单选项设置页面</h1>
        <?php if (!empty($message)) : ?>
            <div class="notice notice-success is-dismissible">
                <p><?php echo esc_html($message); ?></p>
            </div>
        <?php endif; ?>

        <form method="post">
            <?php wp_nonce_field('wishlist_settings', 'wishlist_settings_nonce'); ?>
            <div id="wishlist-fields">
                <?php foreach ($fields as $key => $data): ?>
                    <p class="field-row">
                        <input type="text" name="wishlist_fields[<?php echo esc_attr($key); ?>][label]" value="<?php echo esc_attr($data['label'] ?? ''); ?>" placeholder="字段标签">
                        <input type="checkbox" name="wishlist_fields[<?php echo esc_attr($key); ?>][visible]" value="1" <?php checked(!empty($data['visible']), true); ?>> 显示
                        <button type="button" class="button remove-field">删除</button>
                    </p>
                <?php endforeach; ?>
            </div>
            <button type="button" id="add-field-button" class="button">添加字段</button>
            <p>
                <label for="wishlist_description">心愿单提交页面说明：</label>
                <textarea name="wishlist_description" rows="4" style="width: 300px;"><?php echo wp_kses_post($description); ?></textarea>
            </p>
            <p>
                <label for="wishlist_display_description">心愿单展示页面说明：</label>
                <textarea name="wishlist_display_description" rows="4" style="width: 300px;"><?php echo wp_kses_post($display_description); ?></textarea>
            </p>                
            <button type="submit" class="button button-primary">保存</button>
        </form>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const fieldsContainer = document.getElementById('wishlist-fields');
            const addFieldButton = document.getElementById('add-field-button');

            addFieldButton.addEventListener('click', function () {
                const fieldCount = fieldsContainer.querySelectorAll('.field-row').length;
                const newFieldHTML = `
                    <p class="field-row">
                        <input type="text" name="wishlist_fields[${fieldCount}][label]" placeholder="字段标签">
                        <input type="checkbox" name="wishlist_fields[${fieldCount}][visible]" value="1"> 显示
                        <button type="button" class="button remove-field">删除</button>
                    </p>`;
                fieldsContainer.insertAdjacentHTML('beforeend', newFieldHTML);
            });

            fieldsContainer.addEventListener('click', function (event) {
                if (event.target.classList.contains('remove-field')) {
                    event.target.closest('.field-row').remove();
                }
            });
        });
    </script>
    <?php
}

    public function wishlist_form_shortcode() {
        if (!is_user_logged_in()) {
            return '<p>请先登录以填写心愿单。</p>'; // 没有登录显示文字
        }

        $fields = get_option('wishlist_fields', []);
        if (!is_array($fields)) {
            $fields = [];
        }

        $description = get_option('wishlist_description', '');

        ob_start();
        ?>
        <div class="wishlist-form-container">
            <h2>提交您的心愿单</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="submit_wishlist">
                <?php wp_nonce_field('wishlist_nonce', 'wishlist_nonce_field'); ?>
                <?php foreach ($fields as $key => $data): ?>
                    <?php if (!empty($data['visible'])): ?>
                        <div class="wishlist-input-group">
                            <label for="<?php echo esc_attr($key); ?>"><?php echo esc_html($data['label']); ?>:</label>
                            <input type="text" name="<?php echo esc_attr($key); ?>" required>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
                <button type="submit">提交</button>
            </form>
            <?php if (!empty($description)): ?>
                <p class="wishlist-description" style="margin-top: 15px;"><?php echo wp_kses_post($description); ?></p>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }


    public function wishlist_display_shortcode() {
        $display_description = get_option('wishlist_display_description', '');

    global $wpdb;
    $table_name = $wpdb->prefix . 'wishlist';
    $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");

    $fields = get_option('wishlist_fields', []);
    if (!is_array($fields)) {
        $fields = [];
    }

    ob_start();
    echo '<div class="wishlist-display-container">';
    if (!empty($display_description)) {
        echo '<p class="wishlist-description">' . wp_kses_post($display_description) . '</p>';
    }
    echo '<table>';
    echo '<thead><tr>';
    foreach ($fields as $field) {
        if (!empty($field['visible'])) {
            echo '<th>' . esc_html($field['label']) . '</th>';
        }
    }
    echo '<th>状态</th></tr></thead><tbody>';
    foreach ($results as $row) {
        $data = json_decode($row->data, true);
        echo '<tr>';
        foreach ($fields as $key => $field) {
            if (!empty($field['visible'])) {
                echo '<td>' . esc_html($data[$key] ?? '') . '</td>';
            }
        }
        $status = isset($row->status) ? esc_html($row->status) : 'Pending';
        $status_translated = $status === 'accept' ? '同意' : ($status === 'reject' ? '拒绝' : '待处理');
        $status_class = strtolower($status); // 转为中文
        echo "<td class='wishlist-status {$status_class}'>" . $status_translated . "</td>";
        echo '</tr>';
    }
    echo '</tbody></table></div>';
    return ob_get_clean();
}



public function handle_submission() {
    if (!isset($_POST['wishlist_nonce_field']) || !wp_verify_nonce($_POST['wishlist_nonce_field'], 'wishlist_nonce')) {
        wp_die('Invalid nonce');
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'wishlist';

    $fields = get_option('wishlist_fields', []);
    if (!is_array($fields)) {
        $fields = [];
    }

    $data = [];
    foreach ($fields as $key => $field) {
        $raw_value = isset($_POST[$key]) ? $_POST[$key] : '';
        
        // 验证输入
        if ($this->contains_code($raw_value)) {
            wp_die('提交内容包含不允许的代码，已被拒绝。');
        }

        $sanitized_value = sanitize_text_field($raw_value);
        $data[$key] = $sanitized_value;
    }

    if (empty($data)) {
        wp_die('提交内容为空或无效。');
    }

    $wpdb->insert($table_name, [
        'user_id' => get_current_user_id(),
        'data' => json_encode($data)
    ]);

    // 获取包含短代码 `[wishlist_display]` 的页面 URL
    $wishlist_display_page = get_posts([
        'post_type' => 'page',
        'post_status' => 'publish',
        'numberposts' => 1,
        's' => '[wishlist_display]'
    ]);

    $redirect_url = !empty($wishlist_display_page) ? get_permalink($wishlist_display_page[0]->ID) : home_url('/');

    wp_redirect($redirect_url);
    exit;
}


    // 检查输入中是否包含潜在的恶意代码
    private function contains_code($input) {
    // 解码输入内容防止编码方式绕过检测
    $decoded_input = html_entity_decode($input, ENT_QUOTES, 'UTF-8');
    $decoded_input = stripslashes($decoded_input);
    $decoded_input = rawurldecode($decoded_input);

    // 确保输入内容的编码兼容中文等多字节字符
    $decoded_input = mb_convert_encoding($decoded_input, 'UTF-8', 'UTF-8');

    // 使用wp_kses移除常见危险标签
    $safe_input = wp_kses($decoded_input, array()); // 删除所有标签

    // 如果移除标签后内容变化，则可能包含不安全内容
    if ($safe_input !== $decoded_input) {
        return true;
    }

    // 正则匹配检测更隐蔽的恶意代码特征
    $patterns = [
        '/<\?php/i',
        '/<\s*script.*?>.*?<\/\s*script>/is',
        '/<.*?on[a-z]+\s*=\s*["\'][^"\']*["\']/is',
        '/<\s*iframe.*?>/is',
        '/<\s*object.*?>/is',
        '/<\s*embed.*?>/is',
        '/<\s*form.*?>/is',
        '/javascript:/i',
        '/vbscript:/i',
        '/eval\(/i',
        '/document\.write\(/i',
        '/<\s*style[^>]*>.*?<\/\s*style>/is',
        '/<\s*meta[^>]*>/is',
    ];

    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $decoded_input)) {
            return true; // 发现恶意代码
        }
    }

    // 使用DOMDocument进行深度解析
    $dom = new \DOMDocument();
    libxml_use_internal_errors(true); // 禁用错误输出

    $load_success = @$dom->loadHTML(mb_convert_encoding($decoded_input, 'HTML-ENTITIES', 'UTF-8'));
    if ($load_success) {

        $script_tags = $dom->getElementsByTagName('script');
        if ($script_tags->length > 0) {
            return true;
        }


        $iframe_tags = $dom->getElementsByTagName('iframe');
        if ($iframe_tags->length > 0) {
            return true;
        }


        $object_tags = $dom->getElementsByTagName('object');
        $embed_tags = $dom->getElementsByTagName('embed');
        if ($object_tags->length > 0 || $embed_tags->length > 0) {
            return true;
        }
    }

    return false; // 没有发现恶意代码
}




    public function delete_submission() {
        if (!isset($_GET['id']) || !current_user_can('manage_options')) {
            wp_die('Unauthorized request');
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'wishlist';
        $id = intval($_GET['id']);
        $wpdb->delete($table_name, ['id' => $id]);

        wp_redirect(admin_url('admin.php?page=wishlist-plugin'));
        exit;
    }

    // 加载css
    public function enqueue_styles() {
    // 判断页面是否包含[wishlist_form]或[wishlist_display]短代码
        if (is_page() && (has_shortcode(get_post()->post_content, 'wishlist_form') || has_shortcode(get_post()->post_content, 'wishlist_display'))) {
        wp_enqueue_style('wishlist-style', plugin_dir_url(__FILE__) . 'style.css');
    }
}


}

new WP_Wishlist_Plugin();