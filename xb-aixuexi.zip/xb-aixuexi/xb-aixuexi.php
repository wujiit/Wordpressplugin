<?php
/*
Plugin Name: AI学习计划
Description: 基于AI的智能学习计划推荐工具，根据用户的学习阶段、学科、目标等需求，生成定制化学习计划。
Version: 1.0.0
Author: Summer
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xb_aixuexi_activate');
function xb_aixuexi_activate() {
    xb_aixuexi_create_database();
    xb_aixuexi_create_front_page();
    xb_aixuexi_upgrade_database();
}

// 数据库升级函数
function xb_aixuexi_upgrade_database() {
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aixuexi_records';
    
    // 检查是否需要添加新字段
    $columns = $wpdb->get_results("SHOW COLUMNS FROM $records_table");
    $column_names = array_column($columns, 'Field');
    
    if (!in_array('learning_stage', $column_names)) {
        $wpdb->query("ALTER TABLE $records_table ADD COLUMN learning_stage varchar(50) DEFAULT NULL AFTER custom_content");
    }
    if (!in_array('subject', $column_names)) {
        $wpdb->query("ALTER TABLE $records_table ADD COLUMN subject varchar(50) DEFAULT NULL AFTER learning_stage");
    }
    if (!in_array('exam_type', $column_names)) {
        $wpdb->query("ALTER TABLE $records_table ADD COLUMN exam_type varchar(50) DEFAULT NULL AFTER subject");
    }
    if (!in_array('skill_type', $column_names)) {
        $wpdb->query("ALTER TABLE $records_table ADD COLUMN skill_type varchar(50) DEFAULT NULL AFTER exam_type");
    }
    if (!in_array('language_type', $column_names)) {
        $wpdb->query("ALTER TABLE $records_table ADD COLUMN language_type varchar(50) DEFAULT NULL AFTER skill_type");
    }
    if (!in_array('study_time', $column_names)) {
        $wpdb->query("ALTER TABLE $records_table ADD COLUMN study_time varchar(50) DEFAULT NULL AFTER language_type");
    }
    if (!in_array('study_goal', $column_names)) {
        $wpdb->query("ALTER TABLE $records_table ADD COLUMN study_goal varchar(50) DEFAULT NULL AFTER study_time");
    }
}

// 创建数据库表
function xb_aixuexi_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 用户使用次数表
    $usage_table = $wpdb->prefix . 'xb_aixuexi_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        usage_date date NOT NULL,
        usage_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_date (user_id, usage_date)
    ) $charset_collate;";

    // 用户记录表
    $records_table = $wpdb->prefix . 'xb_aixuexi_records';
    $records_sql = "CREATE TABLE $records_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        learning_stage varchar(50) DEFAULT NULL,
        subject varchar(50) DEFAULT NULL,
        exam_type varchar(50) DEFAULT NULL,
        skill_type varchar(50) DEFAULT NULL,
        language_type varchar(50) DEFAULT NULL,
        study_time varchar(50) DEFAULT NULL,
        study_goal varchar(50) DEFAULT NULL,
        custom_content text DEFAULT NULL,
        model_name varchar(100) DEFAULT NULL,
        enable_search tinyint(1) DEFAULT 0,
        ai_response longtext DEFAULT NULL,
        status varchar(20) NOT NULL,
        error_message text DEFAULT NULL,
        user_ip varchar(45) DEFAULT NULL,
        user_agent text DEFAULT NULL,
        create_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($usage_sql);
    dbDelta($records_sql);
}

// 创建前台页面
function xb_aixuexi_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_aixuexi_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => 'AI学习计划',
            'post_content' => '[xb_aixuexi_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_aixuexi_enqueue_scripts');
function xb_aixuexi_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_aixuexi_form')) {
        wp_enqueue_style('xb_aixuexi_styles', plugins_url('xb-aixuexi.css', __FILE__), array(), '1.0.0');
        wp_enqueue_script('xb_aixuexi_scripts', plugins_url('xb-aixuexi.js', __FILE__), array('jquery'), '1.0.0', true);
        wp_enqueue_script('html2canvas', 'https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js', array(), '1.4.1', true);
        
        // 添加Markdown渲染库
        wp_enqueue_script('marked', 'https://cdn.jsdelivr.net/npm/marked@9.1.6/marked.min.js', array(), '9.1.6', true);

        wp_localize_script('xb_aixuexi_scripts', 'xb_aixuexi_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => rest_url('xb_aixuexi/v1/recommend'),
            'rest_delete_url' => rest_url('xb_aixuexi/v1/delete-record'),
            'nonce'    => wp_create_nonce('wp_rest'),
            'login_url' => wp_login_url(get_permalink()),
            'is_logged_in' => is_user_logged_in() ? 1 : 0,
        ));
    }
}

// 短代码
add_shortcode('xb_aixuexi_form', 'xb_aixuexi_form_shortcode');
function xb_aixuexi_form_shortcode() {
    $ad_content = get_option('xb_aixuexi_ad_content', '');
    $default_limit = absint(get_option('xb_aixuexi_default_limit', 10));
    $show_stats = get_option('xb_aixuexi_show_stats', 1);
    $enable_model_selection = get_option('xb_aixuexi_enable_model_selection', 0);
    $enable_search = get_option('xb_aixuexi_enable_search', 0);
    
    // 获取各种选项
    $learning_stage_options = get_option('xb_aixuexi_learning_stage_options', '小学,中学,高中,大学,业余时间');
    $subject_options = get_option('xb_aixuexi_subject_options', '数学,物理,化学,历史,语言');
    $exam_options = get_option('xb_aixuexi_exam_options', '高考,托福,雅思,GRE,职称考试');
    $skill_options = get_option('xb_aixuexi_skill_options', '编程语言,设计,数据分析');
    $language_options = get_option('xb_aixuexi_language_options', '英语,日语,西班牙语');
    $study_time_options = get_option('xb_aixuexi_study_time_options', '每天1小时,每天2小时,每天3小时');
    $study_goal_options = get_option('xb_aixuexi_study_goal_options', '考试,技能,兴趣');
    
    $models = array_filter(array_map('trim', explode(',', get_option('xb_aixuexi_models', 'qwen-plus'))));

    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $today = current_time('Y-m-d');

    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aixuexi_usage';

    // 已登录用户按 user_id 和日期查询
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
                $user_id, $today
            )
        );
    } else {
        $row = null;
    }

    $usage_count = $row ? absint($row->usage_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;
    $remaining = max(0, $user_limit - $usage_count);
    $stats_text = "今日剩余推荐次数：{$remaining}/{$user_limit}";

    // 判断是否显示推荐区域
    $show_form = true;
    $disable_reason = '';

    if (!is_user_logged_in()) {
        $show_form = false;
        $disable_reason = 'guest_disabled';
    } elseif (is_user_logged_in() && $usage_count >= $user_limit) {
        $show_form = false;
        $disable_reason = 'user_limit_exceeded';
    }

    ob_start();
    ?>
    <div class="xb_aixuexi_container">
        <div class="xb_aixuexi_header">
            <div class="xb_aixuexi_title">📚 AI学习计划</div>
            <p class="xb_aixuexi_subtitle">智能规划，高效学习</p>
        </div>

        <div class="xb_aixuexi_main_content">
            <!-- 配置区域 -->
            <div class="xb_aixuexi_config_section">
                <div class="xb_aixuexi_section_title">🎯 学习配置</div>
                
                <?php if (!$show_form) { ?>
                    <div class="xb_aixuexi_message xb_aixuexi_message_info">
                        <?php if ($disable_reason === 'guest_disabled') { ?>
                            <div class="xb_aixuexi_message_icon">🔐</div>
                            <div class="xb_aixuexi_message_content">
                                <div class="xb_aixuexi_ts_subtitle">请登录后使用学习计划推荐功能</div>
                                <p>为了更好地为您提供个性化学习计划，请先登录。</p>
                                <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xb_aixuexi_login_btn">立即登录</a>
                            </div>
                        <?php } elseif ($disable_reason === 'user_limit_exceeded') { ?>
                            <div class="xb_aixuexi_message_icon">📅</div>
                            <div class="xb_aixuexi_message_content">
                                <div class="xb_aixuexi_ts_subtitle">今日使用次数已经用完，请明天再来。</div>
                            </div>
                        <?php } ?>
                    </div>
                <?php } else { ?>
                    <form id="xb_aixuexi_form" method="post">
                        <!-- 学习阶段 -->
                        <div class="xb_aixuexi_learning_stage_section">
                            <label>学习阶段：</label>
                            <div class="xb_aixuexi_learning_stage_select">
                                <?php 
                                $learning_stages = array_filter(array_map('trim', explode(',', $learning_stage_options)));
                                foreach ($learning_stages as $index => $stage) { ?>
                                    <div class="xb_aixuexi_learning_stage_option">
                                        <input type="radio" name="learning_stage" value="<?php echo esc_attr($stage); ?>" <?php echo $index === 0 ? 'checked' : ''; ?> id="learning_stage_<?php echo $index; ?>">
                                        <label for="learning_stage_<?php echo $index; ?>"><?php echo esc_html($stage); ?></label>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>

                        <!-- 学科选择 -->
                        <div class="xb_aixuexi_subject_section">
                            <label>学科选择：</label>
                            <div class="xb_aixuexi_subject_select">
                                <?php 
                                $subjects = array_filter(array_map('trim', explode(',', $subject_options)));
                                foreach ($subjects as $index => $subject) { ?>
                                    <div class="xb_aixuexi_subject_option">
                                        <input type="radio" name="subject" value="<?php echo esc_attr($subject); ?>" <?php echo $index === 0 ? 'checked' : ''; ?> id="subject_<?php echo $index; ?>">
                                        <label for="subject_<?php echo $index; ?>"><?php echo esc_html($subject); ?></label>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>

                        <!-- 考试类型 -->
                        <div class="xb_aixuexi_exam_section">
                            <label>考试类型（可选）：</label>
                            <div class="xb_aixuexi_exam_select">
                                <div class="xb_aixuexi_exam_option">
                                    <input type="radio" name="exam_type" value="" checked id="exam_none">
                                    <label for="exam_none">无</label>
                                </div>
                                <?php 
                                $exams = array_filter(array_map('trim', explode(',', $exam_options)));
                                foreach ($exams as $index => $exam) { ?>
                                    <div class="xb_aixuexi_exam_option">
                                        <input type="radio" name="exam_type" value="<?php echo esc_attr($exam); ?>" id="exam_<?php echo $index; ?>">
                                        <label for="exam_<?php echo $index; ?>"><?php echo esc_html($exam); ?></label>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>

                        <!-- 技能类型 -->
                        <div class="xb_aixuexi_skill_section">
                            <label>技能类型（可选）：</label>
                            <div class="xb_aixuexi_skill_select">
                                <div class="xb_aixuexi_skill_option">
                                    <input type="radio" name="skill_type" value="" checked id="skill_none">
                                    <label for="skill_none">无</label>
                                </div>
                                <?php 
                                $skills = array_filter(array_map('trim', explode(',', $skill_options)));
                                foreach ($skills as $index => $skill) { ?>
                                    <div class="xb_aixuexi_skill_option">
                                        <input type="radio" name="skill_type" value="<?php echo esc_attr($skill); ?>" id="skill_<?php echo $index; ?>">
                                        <label for="skill_<?php echo $index; ?>"><?php echo esc_html($skill); ?></label>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>

                        <!-- 语言类型 -->
                        <div class="xb_aixuexi_language_section">
                            <label>语言类型（可选）：</label>
                            <div class="xb_aixuexi_language_select">
                                <div class="xb_aixuexi_language_option">
                                    <input type="radio" name="language_type" value="" checked id="language_none">
                                    <label for="language_none">无</label>
                                </div>
                                <?php 
                                $languages = array_filter(array_map('trim', explode(',', $language_options)));
                                foreach ($languages as $index => $language) { ?>
                                    <div class="xb_aixuexi_language_option">
                                        <input type="radio" name="language_type" value="<?php echo esc_attr($language); ?>" id="language_<?php echo $index; ?>">
                                        <label for="language_<?php echo $index; ?>"><?php echo esc_html($language); ?></label>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>

                        <!-- 可支配学习时间 -->
                        <div class="xb_aixuexi_study_time_section">
                            <label>可支配学习时间：</label>
                            <div class="xb_aixuexi_study_time_select">
                                <?php 
                                $study_times = array_filter(array_map('trim', explode(',', $study_time_options)));
                                foreach ($study_times as $index => $time) { ?>
                                    <div class="xb_aixuexi_study_time_option">
                                        <input type="radio" name="study_time" value="<?php echo esc_attr($time); ?>" <?php echo $index === 0 ? 'checked' : ''; ?> id="study_time_<?php echo $index; ?>">
                                        <label for="study_time_<?php echo $index; ?>"><?php echo esc_html($time); ?></label>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>

                        <!-- 学习目标 -->
                        <div class="xb_aixuexi_study_goal_section">
                            <label>学习目标：</label>
                            <div class="xb_aixuexi_study_goal_select">
                                <?php 
                                $study_goals = array_filter(array_map('trim', explode(',', $study_goal_options)));
                                foreach ($study_goals as $index => $goal) { ?>
                                    <div class="xb_aixuexi_study_goal_option">
                                        <input type="radio" name="study_goal" value="<?php echo esc_attr($goal); ?>" <?php echo $index === 0 ? 'checked' : ''; ?> id="study_goal_<?php echo $index; ?>">
                                        <label for="study_goal_<?php echo $index; ?>"><?php echo esc_html($goal); ?></label>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>

                        <!-- 补充说明 -->
                        <div class="xb_aixuexi_custom_section">
                            <label for="xb_aixuexi_custom_content">补充说明（可选）：</label>
                            <textarea id="xb_aixuexi_custom_content" name="custom_content" maxlength="500" rows="3" placeholder="请描述特殊需求，如：基础薄弱、时间紧张、特定目标..." class="xb_aixuexi_custom_content"></textarea>
                            <div class="xb_aixuexi_char_count">0/500</div>
                        </div>

                        <!-- AI模型和联网搜索 -->
                        <?php if ($enable_model_selection && count($models) > 1 || $enable_search) { ?>
                        <div class="xb_aixuexi_advanced_options">
                            <div class="xb_aixuexi_advanced_title">高级选项</div>
                            <div class="xb_aixuexi_advanced_row">
                                <?php if ($enable_model_selection && count($models) > 1) { ?>
                                <div class="xb_aixuexi_model_wrapper">
                                    <label for="xb_aixuexi_model">AI模型：</label>
                                    <select id="xb_aixuexi_model" name="model" class="xb_aixuexi_model_select">
                                        <?php foreach ($models as $model) { ?>
                                            <option value="<?php echo esc_attr($model); ?>"><?php echo esc_html($model); ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <?php } ?>

                                <?php if ($enable_search) { ?>
                                <div class="xb_aixuexi_search_option">
                                    <input type="checkbox" id="xb_aixuexi_enable_search" name="enable_search" value="1" class="xb_aixuexi_search_checkbox">
                                    <label for="xb_aixuexi_enable_search">启用联网搜索</label>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <?php } ?>

                        <button type="submit" class="xb_aixuexi_submit_button" id="xb_aixuexi_submit_button">
                            <span class="xb_aixuexi_button_icon">📚</span>
                            推荐计划
                        </button>

                        <?php if (is_user_logged_in()) { ?>
                            <input type="hidden" name="xb_aixuexi_nonce" value="<?php echo wp_create_nonce('xb_aixuexi_nonce'); ?>">
                        <?php } ?>
                    </form>
                <?php } ?>
            </div>
            
            <!-- 结果区域 -->
            <div class="xb_aixuexi_result_section" style="display:none;">
                <div class="xb_aixuexi_section_title">📋 推荐结果</div>
                
                <div class="xb_aixuexi_result_actions" style="display:none;">
                    <button id="xb_aixuexi_copy_button" class="xb_aixuexi_action_button">
                        <span class="xb_aixuexi_button_icon">📋</span>
                        复制结果
                    </button>
                    <button id="xb_aixuexi_export_image_button" class="xb_aixuexi_action_button">
                        <span class="xb_aixuexi_button_icon">🖼️</span>
                        导出图片
                    </button>
                    <button id="xb_aixuexi_regenerate_button" class="xb_aixuexi_action_button">
                        <span class="xb_aixuexi_button_icon">🔄</span>
                        重新推荐
                    </button>
                    <button id="xb_aixuexi_clear_button" class="xb_aixuexi_action_button">
                        <span class="xb_aixuexi_button_icon">🗑️</span>
                        清空内容
                    </button>
                </div>

                <div id="xb_aixuexi_result"></div>
                
                <?php if ($show_stats && $show_form) { ?>
                    <div class="xb_aixuexi_usage_info">
                        <span class="xb_aixuexi_usage_icon">📊</span>
                        <span id="xb_aixuexi_usage_text"><?php echo esc_html($stats_text); ?></span>
                    </div>
                <?php } ?>
            </div>
        </div>

        <!-- 历史记录 -->
        <?php if (is_user_logged_in()) { ?>
            <div class="xb_aixuexi_history_section">
                <div class="xb_aixuexi_section_title">📚 我的推荐记录</div>
                <div id="xb_aixuexi_history_list" class="xb_aixuexi_history_list"></div>
            </div>
        <?php } ?>
        
        <!-- 公告内容 -->
        <?php if (!empty($ad_content)) { ?>
            <div class="xb_aixuexi_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
        <?php } ?>
    </div>
    
    <!-- 自定义确认对话框 -->
    <div id="xb_aixuexi_confirm_modal" class="xb_aixuexi_modal" style="display: none;">
        <div class="xb_aixuexi_modal_overlay"></div>
        <div class="xb_aixuexi_modal_content">
            <div class="xb_aixuexi_modal_header">
                <h3 id="xb_aixuexi_confirm_title">确认操作</h3>
            </div>
            <div class="xb_aixuexi_modal_body">
                <p id="xb_aixuexi_confirm_message">您确定要执行此操作吗？</p>
            </div>
            <div class="xb_aixuexi_modal_footer">
                <button id="xb_aixuexi_confirm_cancel" class="xb_aixuexi_modal_btn xb_aixuexi_modal_btn_cancel">取消</button>
                <button id="xb_aixuexi_confirm_ok" class="xb_aixuexi_modal_btn xb_aixuexi_modal_btn_confirm">确定</button>
            </div>
        </div>
    </div>
    
    <!-- 自定义提示对话框 -->
    <div id="xb_aixuexi_alert_modal" class="xb_aixuexi_modal" style="display: none;">
        <div class="xb_aixuexi_modal_overlay"></div>
        <div class="xb_aixuexi_modal_content">
            <div class="xb_aixuexi_modal_header">
                <h3 id="xb_aixuexi_alert_title">提示</h3>
            </div>
            <div class="xb_aixuexi_modal_body">
                <p id="xb_aixuexi_alert_message">操作完成</p>
            </div>
            <div class="xb_aixuexi_modal_footer">
                <button id="xb_aixuexi_alert_ok" class="xb_aixuexi_modal_btn xb_aixuexi_modal_btn_confirm">确定</button>
            </div>
        </div>
    </div>

    <script type="text/javascript">
    // 加载历史记录
    jQuery(document).ready(function($) {
        <?php if (is_user_logged_in()) { ?>
        xb_aixuexi_load_history();
        <?php } ?>
        
        // 历史记录点击事件
        $(document).on('click', '.xb_aixuexi_history_item', function(e) {
            // 如果点击的是删除按钮，不执行查看记录
            if ($(e.target).hasClass('xb_aixuexi_delete_record_btn') || $(e.target).closest('.xb_aixuexi_delete_record_btn').length) {
                return;
            }
            
            var recordId = $(this).data('id');
            
            // 通过AJAX获取完整的历史记录内容
            jQuery.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'xb_aixuexi_get_history_detail',
                    record_id: recordId
                },
                success: function(response) {
                    if (response.success && response.data.ai_response) {
                        // 使用Markdown渲染器渲染内容
                        var renderedContent = '';
                        if (typeof marked !== 'undefined') {
                            renderedContent = marked.parse(response.data.ai_response);
                        } else {
                            renderedContent = response.data.ai_response.replace(/ /g, '<br>');
                        }
                        
                        // 显示历史记录内容到结果区域
                        $('#xb_aixuexi_result').html('<div class="xb_aixuexi_result_content">' + renderedContent + '</div>');
                        $('.xb_aixuexi_result_section').show();
                        $('.xb_aixuexi_result_actions').show();
                        
                        // 滚动到结果区域
                        $('.xb_aixuexi_result_section')[0].scrollIntoView({ behavior: 'smooth' });
                        
                        // 高亮选中的记录
                        $('.xb_aixuexi_history_item').removeClass('xb_aixuexi_selected');
                        $('[data-id="' + recordId + '"]').addClass('xb_aixuexi_selected');
                    } else {
                        xb_aixuexi_show_alert('加载记录失败');
                    }
                },
                error: function() {
                    xb_aixuexi_show_alert('加载记录失败');
                }
            });
        });
        
        // 删除记录按钮点击事件
        $(document).on('click', '.xb_aixuexi_delete_record_btn', function(e) {
            e.stopPropagation();
            var recordId = $(this).data('id');
            
            xb_aixuexi_show_confirm('确认删除', '您确定要删除这条推荐记录吗？删除后无法恢复。', function() {
                // 发送删除请求
                jQuery.ajax({
                    url: '<?php echo rest_url('xb_aixuexi/v1/delete-record'); ?>',
                    type: 'DELETE',
                    headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                    data: JSON.stringify({ record_id: recordId }),
                    contentType: 'application/json',
                    success: function(response) {
                        if (response.success) {
                            // 前台用户删除自己记录时不弹提示框，直接重新加载历史记录
                            xb_aixuexi_load_history();
                            // 如果当前显示的是被删除的记录，清空结果区域
                            if ($('.xb_aixuexi_history_item.xb_aixuexi_selected').data('id') == recordId) {
                                $('#xb_aixuexi_result').empty();
                                $('.xb_aixuexi_result_actions').hide();
                                $('.xb_aixuexi_result_section').hide();
                            }
                        } else {
                            xb_aixuexi_show_alert(response.message || '删除失败');
                        }
                    },
                    error: function(xhr) {
                        var message = xhr.responseJSON && xhr.responseJSON.message ? 
                            xhr.responseJSON.message : '删除失败';
                        xb_aixuexi_show_alert(message);
                    }
                });
            });
        });
    });
    
    // 加载历史记录函数
    function xb_aixuexi_load_history() {
        jQuery.ajax({
            url: '<?php echo rest_url('xb_aixuexi/v1/history'); ?>',
            type: 'GET',
            headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
            success: function(response) {
                if (response && response.length > 0) {
                    var html = '';
                    response.forEach(function(record) {
                        html += '<div class="xb_aixuexi_history_item" data-id="' + record.id + '">';
                        html += '<button class="xb_aixuexi_delete_record_btn" data-id="' + record.id + '" title="删除记录">×</button>';
                        html += '<div class="xb_aixuexi_history_date">' + record.create_time + '</div>';
                        html += '<div class="xb_aixuexi_history_preview">' + (record.learning_stage || '学习计划记录').substring(0, 50) + '...</div>';
                        html += '<div class="xb_aixuexi_history_subject">' + (record.subject || '未知学科') + '</div>';
                        html += '</div>';
                    });
                    jQuery('#xb_aixuexi_history_list').html(html);
                } else {
                    jQuery('#xb_aixuexi_history_list').html('<div class="xb_aixuexi_no_history">暂无推荐记录</div>');
                }
            },
            error: function() {
                jQuery('#xb_aixuexi_history_list').html('<div class="xb_aixuexi_no_history">加载记录失败</div>');
            }
        });
    }
    
    // 自定义确认对话框
    function xb_aixuexi_show_confirm(title, message, onConfirm) {
        $('#xb_aixuexi_confirm_title').text(title);
        $('#xb_aixuexi_confirm_message').text(message);
        $('#xb_aixuexi_confirm_modal').show();
        
        // 绑定确认按钮事件
        $('#xb_aixuexi_confirm_ok').off('click').on('click', function() {
            $('#xb_aixuexi_confirm_modal').hide();
            if (typeof onConfirm === 'function') {
                onConfirm();
            }
        });
        
        // 绑定取消按钮事件
        $('#xb_aixuexi_confirm_cancel').off('click').on('click', function() {
            $('#xb_aixuexi_confirm_modal').hide();
        });
        
        // 点击遮罩层关闭
        $('.xb_aixuexi_modal_overlay').off('click').on('click', function() {
            $('#xb_aixuexi_confirm_modal').hide();
        });
    }
    
    // 自定义提示对话框
    function xb_aixuexi_show_alert(message, title) {
        $('#xb_aixuexi_alert_title').text(title || '提示');
        $('#xb_aixuexi_alert_message').text(message);
        $('#xb_aixuexi_alert_modal').show();
        
        // 绑定确定按钮事件
        $('#xb_aixuexi_alert_ok').off('click').on('click', function() {
            $('#xb_aixuexi_alert_modal').hide();
        });
        
        // 点击遮罩层关闭
        $('.xb_aixuexi_modal_overlay').off('click').on('click', function() {
            $('#xb_aixuexi_alert_modal').hide();
        });
    }
    </script>
    <?php
    return ob_get_clean();
}

// 注册 REST API 端点
add_action('rest_api_init', 'xb_aixuexi_register_rest_routes');
function xb_aixuexi_register_rest_routes() {
    register_rest_route('xb_aixuexi/v1', '/recommend', array(
        'methods' => 'POST',
        'callback' => 'xb_aixuexi_handle_logged_recommend',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ));
    
    register_rest_route('xb_aixuexi/v1', '/history', array(
        'methods' => 'GET',
        'callback' => 'xb_aixuexi_get_user_history',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ));
    
    register_rest_route('xb_aixuexi/v1', '/delete-record', array(
        'methods' => 'DELETE',
        'callback' => 'xb_aixuexi_delete_user_record',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ));
}

// 处理登录用户推荐
function xb_aixuexi_handle_logged_recommend(WP_REST_Request $request) {
    $data = json_decode($request->get_body(), true);
    
    // 验证必填字段
    if (empty($data['learning_stage'])) {
        return new WP_REST_Response(array('message' => '请选择学习阶段'), 400);
    }

    if (empty($data['subject'])) {
        return new WP_REST_Response(array('message' => '请选择学科'), 400);
    }

    if (empty($data['study_time'])) {
        return new WP_REST_Response(array('message' => '请选择可支配学习时间'), 400);
    }

    if (empty($data['study_goal'])) {
        return new WP_REST_Response(array('message' => '请选择学习目标'), 400);
    }

    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');

    // 检查使用次数
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aixuexi_usage';
    $default_limit = absint(get_option('xb_aixuexi_default_limit', 10));
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
            $user_id, $today
        )
    );
    $usage_count = $row ? absint($row->usage_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;

    if ($usage_count >= $user_limit) {
        return new WP_REST_Response(array('message' => '今日使用次数已经用完，请明天再来。'), 403);
    }

    // 检查违规词
    $forbidden_words = get_option('xb_aixuexi_forbidden_words', '');
    if (!empty($forbidden_words)) {
        $words = array_filter(array_map('trim', explode(',', $forbidden_words)));
        $check_content = $data['learning_stage'] . ' ' . $data['subject'] . ' ' . ($data['custom_content'] ?? '');
        foreach ($words as $word) {
            if (stripos($check_content, $word) !== false) {
                return new WP_REST_Response(array('message' => '输入内容包含违规词，请重新输入'), 400);
            }
        }
    }

    $result = xb_aixuexi_call_api($data, $user_id, $today);
    return new WP_REST_Response($result, $result['success'] ? 200 : 400);
}

// 获取用户历史记录
function xb_aixuexi_get_user_history(WP_REST_Request $request) {
    $user_id = get_current_user_id();
    
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aixuexi_records';
    
    $records = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT id, learning_stage, subject, exam_type, skill_type, language_type, study_time, study_goal, custom_content, create_time, status 
             FROM $records_table 
             WHERE user_id = %d AND status = 'success' 
             ORDER BY create_time DESC 
             LIMIT 20",
            $user_id
        )
    );
    
    return $records;
}

// 删除用户记录
function xb_aixuexi_delete_user_record(WP_REST_Request $request) {
    $data = json_decode($request->get_body(), true);
    $record_id = isset($data['record_id']) ? absint($data['record_id']) : 0;
    
    if (!$record_id) {
        return new WP_REST_Response(array('success' => false, 'message' => '记录ID无效'), 400);
    }
    
    $user_id = get_current_user_id();
    
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aixuexi_records';
    
    // 验证记录是否属于当前用户
    $record = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id FROM $records_table WHERE id = %d AND user_id = %d",
            $record_id, $user_id
        )
    );
    
    if (!$record) {
        return new WP_REST_Response(array('success' => false, 'message' => '记录不存在或无权限删除'), 403);
    }
    
    // 删除记录
    $deleted = $wpdb->delete(
        $records_table,
        array('id' => $record_id, 'user_id' => $user_id),
        array('%d', '%d')
    );
    
    if ($deleted) {
        return new WP_REST_Response(array('success' => true, 'message' => '删除成功'));
    } else {
        return new WP_REST_Response(array('success' => false, 'message' => '删除失败'), 500);
    }
}

// 获取历史记录详情
add_action('wp_ajax_xb_aixuexi_get_history_detail', 'xb_aixuexi_get_history_detail');
function xb_aixuexi_get_history_detail() {
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => '请先登录'));
    }

    $record_id = isset($_POST['record_id']) ? absint($_POST['record_id']) : 0;
    if (!$record_id) {
        wp_send_json_error(array('message' => '记录ID无效'));
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aixuexi_records';
    
    $record = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM $records_table WHERE id = %d AND user_id = %d",
            $record_id, get_current_user_id()
        )
    );

    if (!$record) {
        wp_send_json_error(array('message' => '记录不存在'));
    }

    wp_send_json_success(array(
        'ai_response' => $record->ai_response,
        'learning_stage' => $record->learning_stage,
        'subject' => $record->subject,
        'exam_type' => $record->exam_type,
        'skill_type' => $record->skill_type,
        'language_type' => $record->language_type,
        'study_time' => $record->study_time,
        'study_goal' => $record->study_goal,
        'custom_content' => $record->custom_content,
        'create_time' => $record->create_time
    ));
}

// API 调用
function xb_aixuexi_call_api($data, $user_id, $today) {
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aixuexi_records';

    $api_url = get_option('xb_aixuexi_api_url', 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions');
    $api_key = get_option('xb_aixuexi_api_key', '');
    $models = array_filter(array_map('trim', explode(',', get_option('xb_aixuexi_models', 'qwen-plus'))));
    $model = !empty($data['model']) ? $data['model'] : $models[0];

    // 调试日志
    error_log('XB_AIXUEXI_DEBUG: API调用开始');
    error_log('XB_AIXUEXI_DEBUG: API URL: ' . $api_url);
    error_log('XB_AIXUEXI_DEBUG: Model: ' . $model);
    error_log('XB_AIXUEXI_DEBUG: API Key存在: ' . (!empty($api_key) ? '是' : '否'));

    if (empty($api_key)) {
        error_log('XB_AIXUEXI_DEBUG: API Key为空');
        return array('success' => false, 'message' => '暂时无法推荐请联系客服');
    }

    // 构建提示词 - 专业学习规划师
    $prompt = "你是一位经验丰富的专业学习规划师 👨‍🏫，擅长为不同阶段的学习者制定个性化学习计划。现在需要根据用户的学习需求推荐学习计划，请严格按照以下要求：

用户信息：
- 学习阶段：{$data['learning_stage']}
- 学科选择：{$data['subject']}
- 可支配学习时间：{$data['study_time']}
- 学习目标：{$data['study_goal']}
";

    if (!empty($data['exam_type'])) {
        $prompt .= "- 考试类型：{$data['exam_type']}
";
    }

    if (!empty($data['skill_type'])) {
        $prompt .= "- 技能类型：{$data['skill_type']}
";
    }

    if (!empty($data['language_type'])) {
        $prompt .= "- 语言类型：{$data['language_type']}
";
    }

    if (!empty($data['custom_content'])) {
        $prompt .= "- 特殊需求：{$data['custom_content']}
";
    }

    $prompt .= "
请根据以上信息制定一个详细的学习计划，包括：

## 📋 学习计划概览

### 🎯 学习目标分析
**总体目标：** [根据用户目标制定具体可达成的目标]
**预计完成时间：** [根据学习时间和内容难度估算]
**学习重点：** [列出3-5个核心学习重点]

### 📚 学习路径规划

#### 第一阶段：基础建立（预计X周）
**学习内容：**
- [具体学习内容1]
- [具体学习内容2]
- [具体学习内容3]

**每日学习安排：**
- 时间分配：[根据用户可支配时间合理分配]
- 学习方法：[推荐适合的学习方法]
- 练习建议：[具体的练习内容和频率]

#### 第二阶段：能力提升（预计X周）
**学习内容：**
- [进阶学习内容1]
- [进阶学习内容2]
- [进阶学习内容3]

**每日学习安排：**
- 时间分配：[合理的时间安排]
- 学习方法：[适合的学习策略]
- 实践项目：[具体的实践建议]

#### 第三阶段：综合应用（预计X周）
**学习内容：**
- [高级应用内容1]
- [高级应用内容2]
- [综合项目实践]

**每日学习安排：**
- 时间分配：[最终阶段的时间规划]
- 学习方法：[综合运用各种方法]
- 成果检验：[如何验证学习效果]

### 📅 详细学习时间表

**每日学习计划：**
- 学习时长：{$data['study_time']}
- 时间分配建议：
  - 理论学习：X%
  - 实践练习：X%
  - 复习巩固：X%

**每周学习重点：**
- 第1-2周：[具体重点]
- 第3-4周：[具体重点]
- 第5-6周：[具体重点]
...

### 📖 推荐学习资源

**教材推荐：**
- [推荐的核心教材1]
- [推荐的核心教材2]
- [推荐的辅助资料]

**在线资源：**
- [推荐的在线课程或平台]
- [推荐的练习网站]
- [推荐的学习工具]

### 🎯 学习方法建议

**高效学习技巧：**
- [针对该学科的学习技巧1]
- [针对该学科的学习技巧2]
- [记忆和理解的方法]

**进度跟踪：**
- [如何制定学习里程碑]
- [如何评估学习效果]
- [如何调整学习计划]

### ⚠️ 注意事项

**学习建议：**
- [重要的学习注意事项]
- [常见的学习误区提醒]
- [保持学习动力的方法]

**时间管理：**
- [如何合理安排学习时间]
- [如何平衡学习与其他活动]

## 🌟 个性化建议

[根据用户的具体情况，提供个性化的学习建议和鼓励]

请用专业、温暖且易懂的语言回复 😊，适当使用表情符号让内容更加生动有趣 ✨，确保推荐的学习计划符合用户的学习阶段和时间安排，计划详细可执行，让用户能够按照计划高效学习 📚！";

    // 构建请求数据
    $request_data = array(
        'model' => $model,
        'messages' => array(
            array(
                'role' => 'system',
                'content' => '你是一位专业的学习规划师，擅长根据用户的学习需求制定个性化学习计划。你的回复要详细、实用、可执行，适当使用表情符号让交流更加生动友好。'
            ),
            array(
                'role' => 'user',
                'content' => $prompt
            )
        ),
        'stream' => false,
        'temperature' => 0.7
    );

    // 如果启用联网搜索
    if (!empty($data['enable_search'])) {
        $request_data['enable_search'] = true;
    }

    // 记录到数据库
    $insert_data = array(
        'user_id' => $user_id,
        'learning_stage' => $data['learning_stage'],
        'subject' => $data['subject'],
        'exam_type' => $data['exam_type'] ?? '',
        'skill_type' => $data['skill_type'] ?? '',
        'language_type' => $data['language_type'] ?? '',
        'study_time' => $data['study_time'],
        'study_goal' => $data['study_goal'],
        'custom_content' => $data['custom_content'] ?? '',
        'model_name' => $model,
        'enable_search' => !empty($data['enable_search']) ? 1 : 0,
        'status' => 'pending',
        'user_ip' => !empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '',
        'user_agent' => !empty($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '',
        'create_time' => current_time('mysql'),
    );

    $args = array(
        'method' => 'POST',
        'timeout' => 60,
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json',
        ),
        'body' => json_encode($request_data),
    );

    // 调试日志
    error_log('XB_AIXUEXI_DEBUG: 请求数据: ' . json_encode($request_data, JSON_UNESCAPED_UNICODE));

    $response = wp_remote_request($api_url, $args);
    
    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        error_log('XB_AIXUEXI_DEBUG: WP错误: ' . $error_message);
        $insert_data['status'] = 'failed';
        $insert_data['error_message'] = $error_message;
        $wpdb->insert($records_table, $insert_data);
        return array('success' => false, 'message' => '暂时无法推荐请联系客服');
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);

    error_log('XB_AIXUEXI_DEBUG: HTTP状态码: ' . $status_code);
    error_log('XB_AIXUEXI_DEBUG: 响应内容: ' . substr($body, 0, 500) . '...');

    if ($status_code >= 400) {
        error_log('XB_AIXUEXI_DEBUG: HTTP错误 ' . $status_code . ': ' . $body);
        $insert_data['status'] = 'failed';
        $insert_data['error_message'] = 'HTTP ' . $status_code . ': ' . $body;
        $wpdb->insert($records_table, $insert_data);
        return array('success' => false, 'message' => '暂时无法推荐请联系客服');
    }

    // 解析响应
    $response_data = json_decode($body, true);
    $content = '';
    
    if (isset($response_data['choices'][0]['message']['content'])) {
        $content = $response_data['choices'][0]['message']['content'];
    }

    if (empty($content)) {
        $insert_data['status'] = 'failed';
        $insert_data['error_message'] = '接口返回空内容';
        $wpdb->insert($records_table, $insert_data);
        return array('success' => false, 'message' => '暂时无法推荐请联系客服');
    }

    // 成功，更新使用次数
    $usage_table = $wpdb->prefix . 'xb_aixuexi_usage';
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(usage_count) as usage_count, custom_limit FROM $usage_table WHERE user_id = %d AND usage_date = %s GROUP BY user_id, usage_date",
                $user_id, $today
            )
        );
        $usage_count = $row ? absint($row->usage_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : absint(get_option('xb_aixuexi_default_limit', 10));

        $existing_row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id FROM $usage_table WHERE user_id = %d AND usage_date = %s LIMIT 1",
                $user_id, $today
            )
        );
        if ($existing_row) {
            $wpdb->update(
                $usage_table,
                array('usage_count' => $usage_count + 1),
                array('id' => $existing_row->id),
                array('%d'),
                array('%d')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'usage_date' => $today,
                    'usage_count' => 1,
                    'custom_limit' => null,
                )
            );
        }
    }

    $insert_data['status'] = 'success';
    $insert_data['ai_response'] = $content;
    $wpdb->insert($records_table, $insert_data);

    $remaining = $user_limit - ($usage_count + 1);
    
    return array(
        'success' => true,
        'content' => $content,
        'remaining' => $remaining,
        'limit' => $user_limit
    );
}

// 包含管理功能
if (is_admin()) {
    require_once(plugin_dir_path(__FILE__) . 'xb-aixuexi-admin.php');
}
?>