<?php
/*
Plugin Name: 小半HTML代码预览
Plugin URI: https://www.jingxialai.com/4956.html
Description: 插件用于显示HTML代码高亮和实际效果预览，只用于HTML代码的预览。
Version: 1.1
Author: Summer
Author URI: https://www.jingxialai.com
License: GPL2
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // 防止直接访问
}

// 注册经典编辑器插件
function html_preview_register_tinymce_plugin($plugin_array) {
    $plugin_array['html_preview_button'] = plugin_dir_url(__FILE__) . '/assets/html-preview-tinymce.js';
    return $plugin_array;
}

// 添加按钮到经典编辑器工具栏
function html_preview_add_tinymce_button($buttons) {
    array_push($buttons, 'html_preview_button');
    return $buttons;
}

// 初始化经典编辑器插件
function html_preview_add_tinymce_plugin() {
    if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {
        return;
    }

    if (get_user_option('rich_editing') !== 'true') {
        return;
    }

    add_filter('mce_external_plugins', 'html_preview_register_tinymce_plugin');
    add_filter('mce_buttons', 'html_preview_add_tinymce_button');
}

add_action('init', 'html_preview_add_tinymce_plugin');


// 调整do_shortcode优先级，使其在wpautop之前处理以避免自动添加标签
function html_code_preview_adjust_shortcode_priority() {
    // 只在包含 [html_preview] 短代码的页面调整优先级
    if ( is_singular() && has_shortcode( get_post()->post_content, 'html_preview' ) ) {
        if ( ! is_admin() ) {
            remove_filter( 'the_content', 'do_shortcode', 11 );
            add_filter( 'the_content', 'do_shortcode', 9 );
        }
    }
}
// 使用wp钩子，在内容加载完之后判断是否需要调整优先级
add_action( 'wp', 'html_code_preview_adjust_shortcode_priority' );

// 禁止内容转义
function html_preview_disable_wptexturize_filter() {
    remove_filter('the_content', 'wptexturize');
}

// 注册短代码[html_preview]
function html_code_preview_shortcode( $atts, $content = null ) {
    // 禁止转义
    html_preview_disable_wptexturize_filter();
    
    // 清理内容前后的空白
    $content = trim( $content );
    
    // 生成唯一ID
    $unique_id = uniqid( 'html_preview_' );

    // 只检查代码的第一行是否为 <!DOCTYPE html>
    $first_line = strtok($content, "\n"); // 获取内容的第一行
    $show_preview = (trim($first_line) === '<pre>&lt;!DOCTYPE html&gt;');

    // 判断是否是language-Markup的展示方式
    $is_markup = ! $show_preview;

    // 输出代码和预览结构
    ob_start();
    ?>
    <div class="html-code-preview-container" id="container_<?php echo $unique_id; ?>">
        <div class="html-code-preview-buttons">
            <button class="code-btn active" onclick="toggleView('<?php echo $unique_id; ?>')">代码</button>
            <?php if ($show_preview): ?>
                <button class="preview-btn" onclick="toggleView('<?php echo $unique_id; ?>')">预览</button>
            <?php endif; ?>
        </div>
        <div class="html-code-preview-content">
            <div class="code-view">
                <?php if ($is_markup): ?>
                <pre><code class="language-markup line-numbers"><?php echo preg_replace('/<\?php/', '&lt;?php', preg_replace('/\?>/', '?&gt;', $content)); ?></code></pre>
                <?php else: ?>
                <pre><code class="language-html line-numbers"><?php echo $content; ?></code></pre>
                <?php endif; ?>
            </div>
            <?php if ($show_preview): ?>
                <div class="preview-view">
                    <iframe class="preview-iframe"></iframe>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode( 'html_preview', 'html_code_preview_shortcode' );

// 加载Prism库和插件样式，仅在包含[html_preview]短代码的页面加载
function html_code_preview_enqueue_scripts() {
    if ( is_singular() && has_shortcode( get_post()->post_content, 'html_preview' ) ) {
        wp_enqueue_script( 'prism-js', plugin_dir_url( __FILE__ ) . 'assets/prism.js', array(), null, true );
        wp_enqueue_style( 'prism-css', plugin_dir_url( __FILE__ ) . 'assets/prism.css' );
        //wp_enqueue_script( 'prism-js', 'https://cdn.jsdelivr.net/npm/prismjs@1.29.0/prism.min.js', array(), null, true );
        //wp_enqueue_style( 'prism-css', 'https://cdn.jsdelivr.net/npm/prismjs@1.29.0/themes/prism.min.css' );

        // 框架样式
        wp_add_inline_script( 'prism-js', '
            function toggleView(id) {
                var container = document.getElementById("container_" + id);
                var codeView = container.querySelector(".code-view");
                var previewView = container.querySelector(".preview-view");
                var codeBtn = container.querySelector(".code-btn");
                var previewBtn = container.querySelector(".preview-btn");

                if (codeView.style.display === "none") {
                    codeView.style.display = "block";
                    previewView.style.display = "none";
                    codeBtn.classList.add("active");
                    previewBtn.classList.remove("active");
                } else {
                    codeView.style.display = "none";
                    previewView.style.display = "block";
                    previewBtn.classList.add("active");
                    codeBtn.classList.remove("active");
                    var iframe = previewView.querySelector("iframe");
                    iframe.srcdoc = container.querySelector(".code-view code").innerText;
                }
            }

            document.addEventListener("DOMContentLoaded", function() {
                var allContainers = document.querySelectorAll(".html-code-preview-container");
                allContainers.forEach(function(container) {
                    var codeView = container.querySelector(".code-view");
                    var iframe = container.querySelector(".preview-view iframe");

                    // 代码框的高度自适应，但最大为300px，超出部分滚动
                    codeView.style.maxHeight = "300px"; // 最大高度
                    codeView.style.overflowY = "auto"; // 超出部分滚动显示

                    iframe.style.height = "600px"; // 设置预览iframe高度
                });
            });
        ', 'after');

        wp_add_inline_style( 'prism-css', '
            .html-code-preview-container { 
                border: 1px solid #ccc; 
                padding: 10px; 
                margin-bottom: 20px; 
                width: auto;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            }
            .html-code-preview-buttons { 
                display: flex; 
                justify-content: flex-start; 
                margin-bottom: 5px; 
            }
            .html-code-preview-buttons button { 
                margin-right: 10px; 
                padding: 8px 16px; 
                font-size: 14px; 
                cursor: pointer; 
                border: none;
                border-radius: 4px;
                background: linear-gradient(145deg, #4e73df, #224abe);
                color: white; 
                transition: all 0.3s ease;
            }
            .html-code-preview-buttons button.active { 
                background: linear-gradient(145deg, #38a1db, #0073aa);
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            }
            .html-code-preview-buttons button:hover {
                transform: translateY(-2px);
                background: linear-gradient(145deg, #38a1db, #0073aa);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            }
            .html-code-preview-buttons button:focus {
                outline: none;
            }
            .html-code-preview-content { 
                display: flex; 
                flex-direction: column; 
            }
            .code-view, .preview-view { 
                display: none; 
            }
            .code-view pre { 
                margin: 0; 
            }
            code[class*=language-], pre[class*=language-] {
                background: #272822 !important;
            }
            .preview-view iframe { 
                border: none; 
                width: 100%; 
                height: 600px; 
            }
            .code-view { 
                display: block; 
                max-height: 300px;  /* 设置最大高度 */
                overflow-y: auto; /* 超出部分滚动 */
            }
            .token.comment {
                background: transparent !important;
            position: initial !important; /* 确保没有位置问题 */
        }
        ');
    }
}
add_action( 'wp_enqueue_scripts', 'html_code_preview_enqueue_scripts' );