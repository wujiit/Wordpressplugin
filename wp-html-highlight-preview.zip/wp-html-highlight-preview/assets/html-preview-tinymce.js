(function() {
    tinymce.PluginManager.add('html_preview_button', function(editor, url) {
        editor.addButton('html_preview_button', {
            text: '插入HTML代码',
            icon: false,
            onclick: function() {
                editor.windowManager.open({
                    title: '插入HTML代码',
                    body: [
                        {
                            type: 'textbox',
                            name: 'html_code',
                            label: 'HTML 代码',
                            multiline: true,
                            minWidth: 400,
                            minHeight: 150
                        },
                     {
                            type: 'label',
                            text: 'html代码要实现预览，第一行代码必须包含“<!DOCTYPE html>”'
                        }
                    ],
                    onsubmit: function(e) {
                        // 获取输入的HTML代码
                        var htmlCode = e.data.html_code;

                        // 对HTML代码进行转义，防止它在编辑器中被执行
                        var escapedHtml = htmlCode
                            .replace(/</g, '&lt;')
                            .replace(/>/g, '&gt;')
                            .replace(/"/g, '&quot;')
                            .replace(/'/g, '&#039;');

                        // 保留用户输入的换行符，替换为<br>标签
                        escapedHtml = escapedHtml.replace(/\n/g, '<br />');

                        // 使用<pre>标签来包裹HTML代码，以防WordPress去除缩进
                        var formattedHtml = '<pre>' + escapedHtml + '</pre>';

                        // 创建短代码[html_preview]并插入到编辑器
                        var shortcode = '[html_preview]' + formattedHtml + '[/html_preview]';
                        editor.insertContent(shortcode);
                    }
                });
            }
        });
    });
})();
