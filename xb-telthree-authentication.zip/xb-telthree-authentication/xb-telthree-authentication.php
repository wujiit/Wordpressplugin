<?php
/**
 * Plugin Name: 小半手机实名认证
 * Description: 基于阿里云市场API的手机三要素实名验证插件，支持实名验证、记录管理、公告设置等功能。
 * Plugin URI: https://www.jingxialai.com/4975.html
 * Version: 1.0.1
 * Author: Summer
 * License: GPL
 * Author URI: https://www.jingxialai.com/
 */

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 插件激活时执行
 */
register_activation_hook(__FILE__, 'xb_telthree_activate');
function xb_telthree_activate() {
    xb_telthree_create_table(); // 创建或更新数据表
    xb_telthree_create_verification_page(); // 创建前台页面
}

/**
 * 创建或更新数据表
 */
function xb_telthree_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_telthree_verifications';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        name VARCHAR(50) NOT NULL,
        mobile VARCHAR(20) NOT NULL,
        idcard VARCHAR(20) NOT NULL,
        channel VARCHAR(20) DEFAULT '',
        sex VARCHAR(10) DEFAULT '',
        birthday VARCHAR(10) DEFAULT '',
        address VARCHAR(255) DEFAULT '',
        ip_address VARCHAR(45) DEFAULT '',
        result VARCHAR(20) NOT NULL,
        verification_time DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

/**
 * 创建前台验证页面
 */
function xb_telthree_create_verification_page() {
    // 查询是否已有包含短代码 [xb_telthree_verification_form] 的页面
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_telthree_verification_form]',
        'numberposts' => 1,
    ));

    // 如果没有找到包含短代码的页面
    if (empty($pages)) {
        $page = array(
            'post_title'   => '手机身份证实名验证',
            'post_content' => '[xb_telthree_verification_form]',
            'post_status'  => 'publish',
            'post_author'  => 1,
            'post_type'    => 'page',
        );
        wp_insert_post($page);
    }
}

/**
 * 设置入口
 */
function xb_telthree_add_settings_link($links) {
    $settings_link = '<a href="admin.php?page=xb-telthree-settings">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'xb_telthree_add_settings_link');


/**
 * 注册短代码
 */
add_shortcode('xb_telthree_verification_form', 'xb_telthree_verification_form_shortcode');
function xb_telthree_verification_form_shortcode() {
    if (!is_user_logged_in()) {
        wp_redirect(home_url());
        exit;
    }

    ob_start();
    ?>
    <div id="xb-telthree-verification" class="xb-telthree-container">
        <div class="xb-telthree-title">手机身份证实名验证</div>
        <div class="xb-telthree-subtitle">按相关规定本站需要实名验证</div>
        <div id="xb-telthree-form-container"></div>
        <div id="xb-telthree-result" class="xb-telthree-result"></div>
        <div id="xb-telthree-notice" class="xb-telthree-notice">
            <?php echo wp_kses_post(get_option('xb_telthree_notice', '')); ?>
        </div>
        <div id="xb-telthree-message" class="xb-telthree-message"></div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * 加载前台JS和CSS
 */
add_action('wp_enqueue_scripts', 'xb_telthree_enqueue_scripts');
function xb_telthree_enqueue_scripts() {
    global $post;
    // 仅在包含短代码 [xb_telthree_verification_form] 的页面加载
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_telthree_verification_form')) {
        wp_enqueue_style('xb-telthree-style', plugin_dir_url(__FILE__) . 'xb-telthree.css', array(), '1.0.1');
        wp_enqueue_script('xb-telthree-script', plugin_dir_url(__FILE__) . 'xb-telthree.js', array('jquery'), '1.0.1', true);
        wp_localize_script('xb-telthree-script', 'xbTelthree', array(
            'ajax_url' => rest_url('xb-telthree/v1'),
            'nonce'    => wp_create_nonce('wp_rest'),
            'user_id'  => get_current_user_id(),
        ));
    }
}

/**
 * 注册REST API路由
 */
add_action('rest_api_init', 'xb_telthree_register_rest_routes');
function xb_telthree_register_rest_routes() {
    // 验证接口
    register_rest_route('xb-telthree/v1', '/verify', array(
        'methods'  => 'POST',
        'callback' => 'xb_telthree_handle_verification',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ));

    // 获取用户验证状态
    register_rest_route('xb-telthree/v1', '/status', array(
        'methods'  => 'GET',
        'callback' => 'xb_telthree_get_user_status',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ));

    // 删除验证记录
    register_rest_route('xb-telthree/v1', '/delete/(?P<id>\d+)', array(
        'methods'  => 'DELETE',
        'callback' => 'xb_telthree_delete_record',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
    ));
}

/**
 * 处理验证请求
 */
function xb_telthree_handle_verification($request) {
    $user_id = get_current_user_id();
    $name = sanitize_text_field($request['name']);
    $mobile = sanitize_text_field($request['mobile']);
    $idcard = sanitize_text_field($request['idcard']);
    $ip_address = !empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '';

    // 验证输入
    if (empty($name) || empty($mobile) || empty($idcard)) {
        return new WP_Error('invalid_input', '所有字段均为必填', array('status' => 400));
    }

    // 检查每日尝试次数
    $max_attempts = (int) get_option('xb_telthree_max_attempts', 3);
    $today = date('Y-m-d');
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_telthree_verifications';
    $attempts = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(verification_time) = %s",
        $user_id,
        $today
    ));

    if ($attempts >= $max_attempts) {
        return new WP_Error('max_attempts', '今日验证次数已达上限，请明天再试', array('status' => 429));
    }

    // 调用阿里云API
    $result = xb_telthree_call_api($name, $mobile, $idcard);
    $verification_result = $result['success'] && $result['data']['result'] === '0' ? '成功' : '失败';

    // 插入验证记录
    $wpdb->insert($table_name, array(
        'user_id'          => $user_id,
        'name'             => $name,
        'mobile'           => $mobile,
        'idcard'           => $idcard,
        'channel'          => $result['data']['channel'] ?? '',
        'sex'              => $result['data']['sex'] ?? '',
        'birthday'         => $result['data']['birthday'] ?? '',
        'address'          => $result['data']['address'] ?? '',
        'ip_address'       => $ip_address,
        'result'           => $verification_result,
        'verification_time' => current_time('mysql'),
    ));

    // 更新用户meta
    if ($verification_result === '成功') {
        update_user_meta($user_id, 'xb_telthree_verified', true);
        update_user_meta($user_id, 'xb_telthree_name', $name);
        update_user_meta($user_id, 'xb_telthree_mobile', $mobile);
        update_user_meta($user_id, 'xb_telthree_idcard', $idcard);
    }

    return array(
        'success' => $result['success'],
        'message' => $result['msg'],
        'data'    => $result['data'],
        'time'    => current_time('mysql'),
    );
}

/**
 * 调用阿里云API
 * @param string $name 姓名
 * @param string $mobile 手机号
 * @param string $idcard 身份证号
 * @return array API响应
 * 
 * 注意：此函数为浙江数链云信息技术有限公司三要素验证接口实现。
 * 若需添加新接口，复制此函数，修改为新接口的逻辑，并更新后台设置以选择接口。
 */
function xb_telthree_call_api($name, $mobile, $idcard) {
    $api_url = get_option('xb_telthree_api_url', 'https://slytransf.market.alicloudapi.com/mobile_transfer');
    $appcode = get_option('xb_telthree_appcode', '');
    $headers = array("Authorization:APPCODE $appcode");
    $querys = "idcard=$idcard&mobile=$mobile&name=" . urlencode($name);
    $url = $api_url . "?$querys";

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, false);

    if (strpos($api_url, 'https://') === 0) {
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    }

    $response = curl_exec($curl);
    curl_close($curl);

    return json_decode($response, true) ?: array(
        'success' => false,
        'msg'     => 'API请求失败',
        'code'    => 500,
        'data'    => array(),
    );
}

/**
 * 获取用户验证状态
 */
function xb_telthree_get_user_status($request) {
    $user_id = get_current_user_id();
    $verified = get_user_meta($user_id, 'xb_telthree_verified', true);
    $user = get_userdata($user_id);

    if ($verified) {
        $name = get_user_meta($user_id, 'xb_telthree_name', true);
        $mobile = get_user_meta($user_id, 'xb_telthree_mobile', true);
        $idcard = get_user_meta($user_id, 'xb_telthree_idcard', true);
        $ip_address = !empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '';

        return array(
            'verified'    => true,
            'name'        => mb_substr($name, 0, 1) . str_repeat('*', mb_strlen($name) - 1),
            'mobile'      => substr_replace($mobile, '******', 3, 6),
            'idcard'      => substr_replace($idcard, '**********', 4, 10),
            'username'    => $user ? esc_html($user->user_login) : '',
            'email'       => $user && !empty($user->user_email) ? esc_html($user->user_email) : '',
            'ip_address'  => $ip_address,
        );
    }

    return array('verified' => false);
}

/**
 * 删除验证记录
 */
function xb_telthree_delete_record($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_telthree_verifications';
    $id = (int) $request['id'];

    $deleted = $wpdb->delete($table_name, array('id' => $id));

    return array('success' => $deleted !== false);
}

/**
 * 强制实名验证跳转
 */
add_action('template_redirect', 'xb_telthree_force_verification', 1);
function xb_telthree_force_verification() {
    if (!is_user_logged_in() || is_admin() || is_front_page()) {
        return;
    }

    $force_verification = get_option('xb_telthree_force_verification', '0');
    if ($force_verification !== '1') {
        return;
    }

    $user_id = get_current_user_id();
    $verified = get_user_meta($user_id, 'xb_telthree_verified', true);

    if (!$verified) {
        $verification_page = get_posts(array(
            'post_type'   => 'page',
            'post_status' => 'publish',
            's'           => '[xb_telthree_verification_form]',
            'numberposts' => 1,
        ));

        if (!empty($verification_page) && !is_page($verification_page[0]->ID)) {
            wp_redirect(get_permalink($verification_page[0]->ID));
            exit;
        }
    }
}

/**
 * 添加后台菜单
 */
add_action('admin_menu', 'xb_telthree_admin_menu');
function xb_telthree_admin_menu() {
    add_menu_page(
        '手机实名验证',
        '手机实名验证',
        'manage_options',
        'xb-telthree-settings',
        'xb_telthree_settings_page',
        'dashicons-shield'
    );

    add_submenu_page(
        'xb-telthree-settings',
        '用户验证记录',
        '用户验证记录',
        'manage_options',
        'xb-telthree-records',
        'xb_telthree_records_page'
    );
}

/**
 * 后台设置页面
 */
function xb_telthree_settings_page() {
    if (isset($_POST['xb_telthree_save_settings']) && check_admin_referer('xb_telthree_settings')) {
        update_option('xb_telthree_api_url', sanitize_text_field($_POST['xb_telthree_api_url']));
        update_option('xb_telthree_appcode', sanitize_text_field($_POST['xb_telthree_appcode']));
        update_option('xb_telthree_notice', wp_kses_post($_POST['xb_telthree_notice']));
        update_option('xb_telthree_max_attempts', (int) $_POST['xb_telthree_max_attempts']);
        update_option('xb_telthree_force_verification', isset($_POST['xb_telthree_force_verification']) ? '1' : '0');
        echo '<div class="updated"><p>设置已保存</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>手机三要素实名验证设置</h1>
        <form method="post" action="">
            <?php wp_nonce_field('xb_telthree_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_telthree_api_url">数链云API请求地址</label></th>
                    <td><input type="text" name="xb_telthree_api_url" id="xb_telthree_api_url" value="<?php echo esc_attr(get_option('xb_telthree_api_url', 'https://slytransf.market.alicloudapi.com/mobile_transfer')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_telthree_appcode">AppCode</label></th>
                    <td><input type="text" name="xb_telthree_appcode" id="xb_telthree_appcode" value="<?php echo esc_attr(get_option('xb_telthree_appcode', '')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_telthree_notice">公告内容</label></th>
                    <td><textarea name="xb_telthree_notice" id="xb_telthree_notice" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_telthree_notice', '')); ?></textarea></td>
                </tr>
                <tr>
                    <th><label for="xb_telthree_max_attempts">每日最大尝试次数</label></th>
                    <td><input type="number" name="xb_telthree_max_attempts" id="xb_telthree_max_attempts" value="<?php echo esc_attr(get_option('xb_telthree_max_attempts', 3)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_telthree_force_verification">强制实名验证</label></th>
                    <td><input type="checkbox" name="xb_telthree_force_verification" id="xb_telthree_force_verification" value="1" <?php checked(get_option('xb_telthree_force_verification', '0'), '1'); ?>></td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="xb_telthree_save_settings" class="button-primary" value="保存设置">
            </p>
        </form>
        注：用户输入姓名、手机号、身份证进行实名验证.<br>
        如果启用强制实名验证，那么用户登录之后就能通过验证了，才能访问其他页面，首页还是可以正常访问.<br>
        基于浙江数链云信息技术有限公司https://market.aliyun.com/apimarket/detail/cmapi00050268?spm=5176.shop.result.2.6e66b2a3JtKpZC&innerSource=search#sku=yuncode4426800004 <br>
        信息齐全的情况下价格合适，如果你想对接其他接口可以联系我添加。
    </div>
    <?php
}

/**
 * 用户验证记录页面
 */
function xb_telthree_records_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_telthree_verifications';
    $per_page = 20;
    $paged = isset($_GET['paged']) ? max(1, (int) $_GET['paged']) : 1;
    $offset = ($paged - 1) * $per_page;

    $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $records = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name ORDER BY verification_time DESC LIMIT %d OFFSET %d",
        $per_page,
        $offset
    ));

    // 运营商中文名称映射
    $operator_names = array(
        'cmcc' => 'cmcc(移动)',
        'cucc' => 'cucc(联通)',
        'ctcc' => 'ctcc(电信)',
    );
    ?>
    <div class="wrap">
        <h1>用户验证记录</h1>
        <p>总验证次数：<?php echo esc_html($total_records); ?></p>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户ID</th>
                    <th>用户名</th>
                    <th>姓名</th>
                    <th>手机号</th>
                    <th>身份证号</th>
                    <th>运营商</th>
                    <th>性别</th>
                    <th>生日</th>
                    <th>地址</th>
                    <th>IP地址</th>
                    <th>验证结果</th>
                    <th>验证时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record) : 
                    $user = get_userdata($record->user_id);
                    $username = $user ? $user->user_login : '未知';
                    $channel = isset($operator_names[$record->channel]) ? $operator_names[$record->channel] : $record->channel;
                ?>
                <tr>
                    <td><?php echo esc_html($record->user_id); ?></td>
                    <td><?php echo esc_html($username); ?></td>
                    <td><?php echo esc_html($record->name); ?></td>
                    <td><?php echo esc_html($record->mobile); ?></td>
                    <td><?php echo esc_html($record->idcard); ?></td>
                    <td><?php echo esc_html($channel); ?></td>
                    <td><?php echo esc_html($record->sex); ?></td>
                    <td><?php echo esc_html($record->birthday); ?></td>
                    <td><?php echo esc_html($record->address); ?></td>
                    <td><?php echo esc_html($record->ip_address); ?></td>
                    <td><?php echo esc_html($record->result); ?></td>
                    <td><?php echo esc_html($record->verification_time); ?></td>
                    <td>
                        <button class="button xb-telthree-delete" data-id="<?php echo esc_attr($record->id); ?>">删除</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        $total_pages = ceil($total_records / $per_page);
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base'    => add_query_arg('paged', '%#%'),
                'format'  => '',
                'current' => $paged,
                'total'   => $total_pages,
            ));
            echo '</div></div>';
        }
        ?>
        <script>
        jQuery(document).ready(function($) {
            $('.xb-telthree-delete').click(function() {
                if (!confirm('确定删除此记录？')) return;
                var id = $(this).data('id');
                $.ajax({
                    url: '<?php echo rest_url('xb-telthree/v1/delete/'); ?>' + id,
                    method: 'DELETE',
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader('X-WP-Nonce', '<?php echo wp_create_nonce('wp_rest'); ?>');
                    },
                    success: function() {
                        location.reload();
                    },
                    error: function() {
                        alert('删除失败');
                    }
                });
            });
        });
        </script>
    </div>
    <?php
}
?>