/**
 * 前台JavaScript脚本
 */
jQuery(document).ready(function($) {
    // 检查用户验证状态
    $.ajax({
        url: xbTelthree.ajax_url + '/status',
        method: 'GET',
        beforeSend: function(xhr) {
            xhr.setRequestHeader('X-WP-Nonce', xbTelthree.nonce);
        },
        success: function(response) {
            if (response.verified) {
                renderVerifiedUI(response);
            } else {
                renderVerificationForm();
            }
        },
        error: function() {
            showMessage('获取验证状态失败', 'error');
        }
    });

    // 渲染验证表单
    function renderVerificationForm() {
        var html = `
            <div class="xb-telthree-form">
                <div class="xb-telthree-field">
                    <label>姓名<span class="xb-telthree-required">*</span></label>
                    <input type="text" id="xb-telthree-name" required>
                </div>
                <div class="xb-telthree-field">
                    <label>手机号<span class="xb-telthree-required">*</span></label>
                    <input type="text" id="xb-telthree-mobile" required>
                </div>
                <div class="xb-telthree-field">
                    <label>身份证号<span class="xb-telthree-required">*</span></label>
                    <input type="text" id="xb-telthree-idcard" required>
                </div>
                <button id="xb-telthree-verify-btn" disabled>验证</button>
            </div>
        `;
        $('#xb-telthree-form-container').html(html);

        // 验证按钮状态
        $('#xb-telthree-name, #xb-telthree-mobile, #xb-telthree-idcard').on('input', function() {
            var allFilled = $('#xb-telthree-name').val() && $('#xb-telthree-mobile').val() && $('#xb-telthree-idcard').val();
            $('#xb-telthree-verify-btn').prop('disabled', !allFilled);
        });

        // 验证按钮点击
        $('#xb-telthree-verify-btn').click(function() {
            var name = $('#xb-telthree-name').val();
            var mobile = $('#xb-telthree-mobile').val();
            var idcard = $('#xb-telthree-idcard').val();

            $('#xb-telthree-result').html('<div class="xb-telthree-loading">正在验证中...</div>');

            $.ajax({
                url: xbTelthree.ajax_url + '/verify',
                method: 'POST',
                data: { name, mobile, idcard },
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', xbTelthree.nonce);
                },
                success: function(response) {
                    $('#xb-telthree-result').empty();
                    var resultText = response.success ? '验证成功' : '验证失败';
                    var html = `
                        <div>验证结果：<span class="xb-telthree-result-text">${resultText}</span></div>
                        <div>验证时间：${response.time}</div>
                    `;
                    $('#xb-telthree-result').html(html);

                    if (response.success) {
                        location.reload();
                    }
                },
                error: function(xhr) {
                    $('#xb-telthree-result').empty();
                    var message = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : '验证失败';
                    showMessage(message, 'error');
                }
            });
        });
    }

    // 渲染已验证界面
    function renderVerifiedUI(data) {
        var html = `
            <div class="xb-telthree-verified">
                <div class="xb-telthree-verified-title">用户信息(当前页面仅自己可见)：</div>
                <div class="xb-telthree-verified-item"><span>用户名：</span>${data.username}</div>
                <div class="xb-telthree-verified-item"><span>邮箱：</span>${data.email}</div>
                <div class="xb-telthree-verified-item"><span>当前IP：</span>${data.ip_address}</div>
                <div class="xb-telthree-verified-item"><span>姓名：</span>${data.name}</div>
                <div class="xb-telthree-verified-item"><span>手机号：</span>${data.mobile}</div>
                <div class="xb-telthree-verified-item"><span>身份证号码：</span>${data.idcard}</div>
                <button id="xb-telthree-reverify-btn">修改验证</button>
            </div>
        `;
        $('#xb-telthree-form-container').html(html);
        $('#xb-telthree-result').html('<div>验证结果：<span class="xb-telthree-result-text">已验证成功</span></div>');
        
        $('#xb-telthree-reverify-btn').click(function() {
            renderVerificationForm();
        });
    }

    // 显示自定义提示
    function showMessage(message, type) {
        var html = `<div class="xb-telthree-message-inner ${type}">${message}</div>`;
        $('#xb-telthree-message').html(html).show();
        setTimeout(function() {
            $('#xb-telthree-message').hide().empty();
        }, 3000);
    }
});