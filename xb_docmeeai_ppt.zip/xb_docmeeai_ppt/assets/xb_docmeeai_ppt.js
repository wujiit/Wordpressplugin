// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', async function() {
    // 获取配置
    const config = window.xb_docmeeai_ppt_config || {};
    const messageBox = document.getElementById('xb_docmeeai_ppt_message');
    const loginBtn = document.getElementById('xb_docmeeai_ppt_login_btn');
    const membershipBtn = document.getElementById('xb_docmeeai_ppt_membership_btn');

    // 未登录用户处理登录按钮点击事件
    if (loginBtn) {
        loginBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const themeLoginBtn = document.querySelector('.nav-login .signin-loader');
            if (themeLoginBtn) {
                themeLoginBtn.click();
            } else {
                window.location.href = this.getAttribute('href') || config.login_url;
            }
        });
    }

    // 无权限用户处理会员开通按钮点击事件
    if (membershipBtn && config.membership_url) {
        membershipBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = config.membership_url;
        });
    }

    // 未登录或无权限则退出初始化
    if (!config.is_logged_in || !config.has_permission) {
        return;
    }

    const container = document.getElementById('xb_docmeeai_ppt_container');
    if (!container) {
        console.error('Container element not found');
        xb_docmeeai_ppt_show_message('页面加载失败：容器元素未找到');
        return;
    }

    // 检查 token 是否存在
    if (!config.token || config.token.trim() === '') {
        xb_docmeeai_ppt_show_message('请联系管理员配置文多多服务');
        return;
    }

    // 设置 iframe 样式
    container.style.cssText = config.iframe_styles;

    let token = config.token;
    let tokenCreatedAt = config.token_created_at ? new Date(config.token_created_at) : new Date();
    const tokenRefreshInterval = 3600 * 1000; // Token 刷新间隔：1小时
    let docmeeUI = null;
    let lastTaskId = null; // 上一次生成任务的 ID
    let hasLoggedForTask = false; // 当前任务是否已记录

    // 检查 token 是否过期
    function isTokenExpired() {
        const now = new Date();
        const timeDiff = now - tokenCreatedAt;
        return timeDiff >= tokenRefreshInterval;
    }

    // 刷新 token
    async function refreshToken(force = false) {
        try {
            const response = await fetch(config.ajax_url + 'token', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': config.nonce,
                },
                body: JSON.stringify({ uid: config.uid, force_refresh: force }),
            });
            if (!response.ok) throw new Error('Token 请求失败: ' + response.status);
            const data = await response.json();
            if (data.success && data.token) {
                token = data.token;
                tokenCreatedAt = new Date();
                if (config.debug) console.log('Token refreshed:', token);
                if (docmeeUI) {
                    docmeeUI.updateToken(token);
                    if (force) xb_docmeeai_ppt_show_message('Token 已自动刷新');
                }
                return token;
            } else {
                throw new Error(data.message || '无法获取 Token');
            }
        } catch (error) {
            if (config.debug) console.error('Refresh Token Error:', error);
            xb_docmeeai_ppt_show_message('Token 刷新失败: ' + error.message);
            throw error;
        }
    }

    // 记录 PPT 生成使用
    async function logUsage() {
        try {
            const response = await fetch(config.ajax_url + 'log_usage', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': config.nonce,
                },
                body: JSON.stringify({ user_id: config.uid }),
            });
            if (!response.ok) throw new Error('Log usage failed: ' + response.status);
            const data = await response.json();
            if (config.debug) console.log('Log Usage Response:', data);
            if (!data.success) {
                if (config.debug) console.error('记录使用失败: ' + data.message);
            }
        } catch (error) {
            if (config.debug) console.error('Log Usage Fetch Error:', error);
        }
    }

    // 每分钟检查一次 token 是否需要刷新
    setInterval(async () => {
        if (isTokenExpired()) {
            await refreshToken(true);
        }
    }, 60000);

    // 初始化 DocmeeUI
    function initDocmeeUI(token) {
        if (config.debug) console.log('Initializing DocmeeUI with token:', token);
        try {
            docmeeUI = new DocmeeUI({
                container: 'xb_docmeeai_ppt_container',
                page: 'creator',
                creatorVersion: 'v2',
                token: token,
                isMobile: window.innerWidth < 768,
                padding: '20px',
                background: 'linear-gradient(135deg, #a78bfa, #6ee7b7)',
                mode: 'light',
                lang: 'zh',
                hidePdfWatermark: true,
                css: config.iframe_css + `
                .text-sm.mb-4 {
                    visibility: hidden;
                    position: relative;
                }
                .text-sm.mb-4::after {
                    content: "上传20000字以内的PDF、WORD、TXT、MD文件，AI会阅读文件内容，然后理解、润色，生成PPT。字数过多或包含图片、表格等情况，可能会影响生成效果";
                    visibility: visible;
                    position: absolute;
                    top: 0;
                    left: 0;
                }
            `,
                onMessage: async (message) => {
                    if (config.debug) console.log('DocmeeUI Message Received:', message.type, message);

                    switch (message.type) {
                        case 'invalid-token':
                            xb_docmeeai_ppt_show_message('Token 无效，刷新中...');
                            try {
                                const newToken = await refreshToken(true);
                                token = newToken;
                                docmeeUI.updateToken(token);
                            } catch (error) {
                                xb_docmeeai_ppt_show_message('Token 刷新失败: ' + error.message);
                            }
                            break;
                        case 'beforeCreatePpt':
                            lastTaskId = message.data.taskId;
                            hasLoggedForTask = false; // 重置任务记录标记
                            if (config.debug) console.log('New PPT creation started, taskId:', lastTaskId);
                            break;
                        case 'changeSlideIndex':
                            if (message.data.when === 'modify' && !hasLoggedForTask) {
                                if (config.debug) console.log('PPT generation successful, logging usage for taskId:', lastTaskId);
                                await logUsage();
                                hasLoggedForTask = true; // 标记已记录
                            }
                            break;
                        case 'error':
                            if (message.data.code === 88) {
                                xb_docmeeai_ppt_show_message('当前Token生成次数已用完，请等待刷新');
                            } else {
                                xb_docmeeai_ppt_show_message(`生成失败: ${message.data.message || '未知错误'}`);
                            }
                            if (config.debug) console.error('DocmeeUI Error:', message.data);
                            break;
                        case 'pageChange':
                            updateNavigation(message.data.page);
                            break;
                        default:
                            if (config.debug) console.log('Unhandled message type:', message.type);
                            break;
                    }
                },
            });

            // 绑定导航按钮事件
            document.getElementById('xb_docmeeai_ppt_page_creator').addEventListener('click', () => {
                docmeeUI.navigate({ page: 'creator' });
            });
            document.getElementById('xb_docmeeai_ppt_page_dashboard').addEventListener('click', () => {
                docmeeUI.navigate({ page: 'dashboard' });
            });
            document.getElementById('xb_docmeeai_ppt_page_customTemplate').addEventListener('click', () => {
                docmeeUI.navigate({ page: 'customTemplate' });
            });

            docmeeUI.getInfo();
        } catch (error) {
            if (config.debug) console.error('DocmeeUI Initialization Error:', error);
            xb_docmeeai_ppt_show_message(`SDK 初始化失败: ${error.message}`);
        }
    }

    // 初始化流程
    try {
        if (!token || isTokenExpired()) {
            token = await refreshToken(true);
        }
        initDocmeeUI(token);
    } catch (error) {
        if (config.debug) console.error('Initialization Error:', error);
        xb_docmeeai_ppt_show_message(`初始化失败: ${error.message}`);
    }
});

// 更新导航选中状态
function updateNavigation(page) {
    const navItems = document.querySelectorAll('.xb_docmeeai_ppt_nav_item');
    navItems.forEach(item => item.classList.remove('xb_docmeeai_ppt_selected'));
    const targetPage = page === 'creatorV2' ? 'creator' : page;
    const navItem = document.getElementById(`xb_docmeeai_ppt_page_${targetPage}`);
    if (navItem) navItem.classList.add('xb_docmeeai_ppt_selected');
}

// 显示提示消息
function xb_docmeeai_ppt_show_message(message) {
    const messageBox = document.getElementById('xb_docmeeai_ppt_message');
    messageBox.textContent = message;
    messageBox.className = 'xb_docmeeai_ppt_message';
    messageBox.style.display = 'block';
    setTimeout(() => {
        messageBox.style.display = 'none';
        messageBox.textContent = '';
    }, 5000);
}