<?php
/*
Plugin Name: 小半AI PPT
Description: 基于文多多开放平台开发的WordPress AI生成PPT插件
Version: 1.2
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('XB_DOCMEEAI_PPT_PATH', plugin_dir_path(__FILE__));
define('XB_DOCMEEAI_PPT_URL', plugin_dir_url(__FILE__));

// 创建数据库表
function xb_docmeeai_ppt_create_tables() {
    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();

    // 用户限制表
    $limit_table = $wpdb->prefix . 'xb_docmeeai_ppt_user_limits';
    $sql = "CREATE TABLE $limit_table (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        max_limit INT NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id)
    ) $charset_collate;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);

    // 用户 Token 表
    $token_table = $wpdb->prefix . 'xb_docmeeai_ppt_user_tokens';
    $sql = "CREATE TABLE $token_table (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        token VARCHAR(255) NOT NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id)
    ) $charset_collate;";
    dbDelta($sql);

    // 使用记录表
    $usage_table = $wpdb->prefix . 'xb_docmeeai_ppt_usage';
    $sql = "CREATE TABLE $usage_table (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        usage_date DATETIME NOT NULL,
        PRIMARY KEY (id),
        INDEX user_id (user_id)
    ) $charset_collate;";
    dbDelta($sql);

    // 会员权限表
    $permission_table = $wpdb->prefix . 'xb_docmeeai_ppt_permissions';
    $sql = "CREATE TABLE $permission_table (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        added_at DATETIME NOT NULL,
        expires_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id)
    ) $charset_collate;";
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'xb_docmeeai_ppt_create_tables');

// 创建前台页面
function xb_docmeeai_ppt_create_front_page() {
    $pages = get_posts([
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_docmeeai_ppt_shortcode]',
        'numberposts' => 1,
    ]);

    if (empty($pages)) {
        $page = [
            'post_title'   => 'AI生成PPT',
            'post_name'    => 'ai-generate-ppt',
            'post_content' => '[xb_docmeeai_ppt_shortcode]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        ];
        wp_insert_post($page);
    }
}
register_activation_hook(__FILE__, 'xb_docmeeai_ppt_create_front_page');

// 检查当前页面是否包含短代码
function xb_docmeeai_ppt_has_shortcode() {
    global $post;
    return is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_docmeeai_ppt_shortcode');
}

// 检查用户是否有权限
function xb_docmeeai_ppt_has_permission($user_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'xb_docmeeai_ppt_permissions';
    $current_time = current_time('mysql');
    $permission = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table WHERE user_id = %d AND expires_at > %s",
        $user_id,
        $current_time
    ));
    return !empty($permission);
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_docmeeai_ppt_enqueue_scripts');
function xb_docmeeai_ppt_enqueue_scripts() {
    if (xb_docmeeai_ppt_has_shortcode()) {
        // 使用CDN加载CSS
        wp_enqueue_style(
            'xb_docmeeai_ppt_frontend_css',
            'https://img.qiyucloud.com/cloud/xb_docmeeai_ppt/assets/xb_docmeeai_ppt.css',
            [],
            '1.2'
        );

        // 使用CDN加载JS
        wp_enqueue_script(
            'xb_docmeeai_ppt_frontend_js',
            'https://img.qiyucloud.com/cloud/xb_docmeeai_ppt/assets/xb_docmeeai_ppt.js',
            [],
            '1.2',
            true
        );

        //wp_enqueue_style('xb_docmeeai_ppt_frontend_css', plugins_url('assets/xb_docmeeai_ppt.css', __FILE__), [], '1.2');
        //wp_enqueue_script('xb_docmeeai_ppt_frontend_js', plugins_url('assets/xb_docmeeai_ppt.js', __FILE__), [], '1.2', true);

        $user_id = get_current_user_id();
        $has_permission = xb_docmeeai_ppt_has_permission($user_id);
        $membership_url = get_option('xb_docmeeai_ppt_membership_url', '');

        // 如果用户有权限，加载Token和其他配置
        if ($has_permission && is_user_logged_in()) {
            $token_data = xb_docmeeai_ppt_get_user_token($user_id);
            $default_limit = get_option('xb_docmeeai_ppt_default_limit', 2);
            $user_limit = xb_docmeeai_ppt_get_user_limit($user_id);
            $limit = $user_limit ?: $default_limit;

            if (!$token_data || (strtotime($token_data['created_at']) + 3600 < time())) {
                $request = new WP_REST_Request('POST', '');
                $request->set_param('uid', $user_id);
                $request->set_param('limit', $limit);
                $request->set_param('force_refresh', true);
                $token_response = xb_docmeeai_ppt_create_token($request);
                if (!is_wp_error($token_response) && isset($token_response['token'])) {
                    $token_data = ['token' => $token_response['token'], 'created_at' => current_time('mysql')];
                } else {
                    error_log('XB Docmee AI PPT: Failed to generate initial token for user ' . $user_id);
                }
            }

            wp_enqueue_script(
                'xb_docmeeai_ppt_sdk',
                'https://img.qiyucloud.com/cloud/xb_docmeeai_ppt/assets/docmee-ui-sdk-iframe.min.js',
                [],
                '1.0',
                true
            );
            wp_script_add_data('xb_docmeeai_ppt_frontend_js', 'dependency', ['xb_docmeeai_ppt_sdk']);
        }

        // 传递配置到前端
        wp_localize_script('xb_docmeeai_ppt_frontend_js', 'xb_docmeeai_ppt_config', [
            'uid'           => is_user_logged_in() ? strval($user_id) : '',
            'token'         => ($has_permission && is_user_logged_in()) ? ($token_data['token'] ?? '') : '',
            'token_created_at' => ($has_permission && is_user_logged_in()) ? ($token_data['created_at'] ?? '') : '',
            'ajax_url'      => is_user_logged_in() ? rest_url('xb_docmeeai_ppt/v1/') : '',
            'nonce'         => is_user_logged_in() ? wp_create_nonce('wp_rest') : '',
            'iframe_styles' => ($has_permission && is_user_logged_in()) ? get_option('xb_docmeeai_ppt_iframe_styles', 'width: 100%; height: 700px; border: none;') : '',
            'iframe_css'    => ($has_permission && is_user_logged_in()) ? "
                #docmee_SdkContainer {
                    border-radius: 12px !important;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1) !important;
                }
                .docmee-button {
                    background: linear-gradient(90deg, #7c3aed, #22d3ee) !important;
                    border: none !important;
                    border-radius: 8px !important;
                    padding: 12px 24px !important;
                    color: #fff !important;
                    font-weight: 600 !important;
                    transition: all 0.3s ease !important;
                    box-shadow: 0 2px 10px rgba(124, 58, 237, 0.3) !important;
                }
                .docmee-button:hover {
                    background: linear-gradient(90deg, #6d28d9, #06b6d4) !important;
                    transform: translateY(-2px) !important;
                    box-shadow: 0 4px 15px rgba(124, 58, 237, 0.5) !important;
                }
                .docmee-input {
                    border: 2px solid #ddd6fe !important;
                    border-radius: 8px !important;
                    padding: 12px !important;
                    font-size: 16px !important;
                    background: #fff !important;
                    color: #374151 !important;
                }
                .docmee-card {
                    background: #fff !important;
                    border-radius: 12px !important;
                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05) !important;
                    color: #374151 !important;
                }
            " : '',
            'debug'         => defined('WP_DEBUG') && WP_DEBUG,
            'is_logged_in'  => is_user_logged_in(),
            'has_permission' => $has_permission,
            'login_url'     => wp_login_url(),
            'membership_url' => $membership_url,
            'announcement'  => ($has_permission && is_user_logged_in()) ? get_option('xb_docmeeai_ppt_announcement', '') : '',
        ]);
    }
}

// 短代码回调
add_shortcode('xb_docmeeai_ppt_shortcode', 'xb_docmeeai_ppt_shortcode_callback');
function xb_docmeeai_ppt_shortcode_callback() {
    ob_start();
    ?>
    <div class="xb_docmeeai_ppt_wrapper">
        <div class="xb_docmeeai_ppt_custom_title">AI生成PPT</div>
        <?php if (!is_user_logged_in()) : ?>
            <div class="xb_docmeeai_ppt_guest_notice">
                <p>请先登录</p>
                <button id="xb_docmeeai_ppt_login_btn" class="xb_docmeeai_ppt_login_btn" href="<?php echo esc_url(wp_login_url()); ?>">快速登录</button>
            </div>
        <?php elseif (!xb_docmeeai_ppt_has_permission(get_current_user_id())) : ?>
            <div id="xb_docmeeai_ppt_permission_notice" class="xb_docmeeai_ppt_permission_notice">
                <div class="xb_docmeeai_ppt_permission_content">
                    <p>此功能仅限小伙伴权限使用</p>
                    <button id="xb_docmeeai_ppt_membership_btn" class="xb_docmeeai_ppt_membership_btn">查看权限说明</button>
                </div>
            </div>
        <?php else : ?>
            <div class="xb_docmeeai_ppt_navigate">
                <div id="xb_docmeeai_ppt_page_creator" class="xb_docmeeai_ppt_nav_item xb_docmeeai_ppt_selected">生成PPT</div>
                <div id="xb_docmeeai_ppt_page_dashboard" class="xb_docmeeai_ppt_nav_item">PPT列表</div>
                <div id="xb_docmeeai_ppt_page_customTemplate" class="xb_docmeeai_ppt_nav_item">自定义模板</div>
            </div>
            <div id="xb_docmeeai_ppt_container"></div>
            <div id="xb_docmeeai_ppt_announcement" class="xb_docmeeai_ppt_announcement"><?php echo wp_kses_post(get_option('xb_docmeeai_ppt_announcement', '')); ?></div>
        <?php endif; ?>
        <div id="xb_docmeeai_ppt_message" class="xb_docmeeai_ppt_message"></div>
    </div>
    <?php
    return ob_get_clean();
}

// 添加管理菜单
add_action('admin_menu', 'xb_docmeeai_ppt_admin_menu');
function xb_docmeeai_ppt_admin_menu() {
    add_menu_page('AI PPT 设置', 'AI PPT 设置', 'manage_options', 'xb_docmeeai_ppt_settings', 'xb_docmeeai_ppt_settings_page', 'dashicons-slides');
    add_submenu_page('xb_docmeeai_ppt_settings', '用户权限管理', '用户权限管理', 'manage_options', 'xb_docmeeai_ppt_user_permissions', 'xb_docmeeai_ppt_user_permissions_page');
}

// 管理设置页面
function xb_docmeeai_ppt_settings_page() {
    global $wpdb;

    if (isset($_POST['xb_docmeeai_ppt_save_settings']) && check_admin_referer('xb_docmeeai_ppt_save_settings')) {
        $api_key = sanitize_text_field($_POST['xb_docmeeai_ppt_api_key']);
        $default_limit = max(1, intval($_POST['xb_docmeeai_ppt_default_limit']));
        $iframe_styles = sanitize_textarea_field($_POST['xb_docmeeai_ppt_iframe_styles']);
        $announcement = wp_kses_post($_POST['xb_docmeeai_ppt_announcement']);
        $membership_url = esc_url_raw($_POST['xb_docmeeai_ppt_membership_url']);
        
        update_option('xb_docmeeai_ppt_api_key', $api_key);
        update_option('xb_docmeeai_ppt_default_limit', $default_limit);
        update_option('xb_docmeeai_ppt_iframe_styles', $iframe_styles);
        update_option('xb_docmeeai_ppt_announcement', $announcement);
        update_option('xb_docmeeai_ppt_membership_url', $membership_url);
        echo '<div class="updated"><p>设置已保存</p></div>';
    }

    $api_key = get_option('xb_docmeeai_ppt_api_key', '');
    $default_limit = get_option('xb_docmeeai_ppt_default_limit', 2);
    $iframe_styles = get_option('xb_docmeeai_ppt_iframe_styles', 'width: 100%; height: 700px; border: none;');
    $announcement = get_option('xb_docmeeai_ppt_announcement', '');
    $membership_url = get_option('xb_docmeeai_ppt_membership_url', '');
    ?>
    <div class="wrap">
        <h1 class="xb_docmeeai_ppt_title">AI PPT 设置</h1>
        <form method="post">
            <?php wp_nonce_field('xb_docmeeai_ppt_save_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_docmeeai_ppt_api_key">文多多 API Key</label></th>
                    <td><input type="text" name="xb_docmeeai_ppt_api_key" id="xb_docmeeai_ppt_api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_docmeeai_ppt_default_limit">默认每个Token最大生成次数</label></th>
                    <td><input type="number" name="xb_docmeeai_ppt_default_limit" id="xb_docmeeai_ppt_default_limit" value="<?php echo esc_attr($default_limit); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_docmeeai_ppt_iframe_styles">Iframe 自定义样式</label></th>
                    <td><textarea name="xb_docmeeai_ppt_iframe_styles" id="xb_docmeeai_ppt_iframe_styles" rows="5" cols="50"><?php echo esc_textarea($iframe_styles); ?></textarea></td>
                </tr>
                <tr>
                    <th><label for="xb_docmeeai_ppt_announcement">公告内容 (支持 HTML)</label></th>
                    <td><textarea name="xb_docmeeai_ppt_announcement" id="xb_docmeeai_ppt_announcement" rows="5" cols="50"><?php echo esc_textarea($announcement); ?></textarea></td>
                </tr>
                <tr>
                    <th><label for="xb_docmeeai_ppt_membership_url">会员开通页面URL</label></th>
                    <td><input type="url" name="xb_docmeeai_ppt_membership_url" id="xb_docmeeai_ppt_membership_url" value="<?php echo esc_attr($membership_url); ?>" class="regular-text"></td>
                </tr>
            </table>
            <?php submit_button('保存设置', 'primary', 'xb_docmeeai_ppt_save_settings'); ?>
        </form>

        <h2 class="xb_docmeeai_ppt_subtitle">用户信息查询</h2>
        <form method="post" action="<?php echo rest_url('xb_docmeeai_ppt/v1/user_info'); ?>" id="xb_docmeeai_ppt_user_info_form">
            <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('wp_rest'); ?>">
            <table class="form-table">
                <tr>
                    <th><label for="xb_docmeeai_ppt_query_user_id">用户 ID</label></th>
                    <td><input type="number" name="user_id" id="xb_docmeeai_ppt_query_user_id" class="regular-text" required></td>
                </tr>
            </table>
            <button type="submit" class="button button-primary">查询用户信息</button>
            <div id="xb_docmeeai_ppt_user_info"></div>
        </form>

        <h2 class="xb_docmeeai_ppt_subtitle">用户生成次数设置</h2>
        <form method="post" action="<?php echo rest_url('xb_docmeeai_ppt/v1/user_limit'); ?>" id="xb_docmeeai_ppt_user_limit_form">
            <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('wp_rest'); ?>">
            <table class="form-table">
                <tr>
                    <th><label for="xb_docmeeai_ppt_set_user_id">用户 ID</label></th>
                    <td><input type="number" name="user_id" id="xb_docmeeai_ppt_set_user_id" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="xb_docmeeai_ppt_user_limit">用户每个Token最大生成次数</label></th>
                    <td><input type="number" name="max_limit" id="xb_docmeeai_ppt_user_limit" min="0"> (0 表示恢复默认)</td>
                </tr>
            </table>
            <button type="submit" class="button button-primary">设置用户限制</button>
        </form>
    </div>
    <script>
        document.getElementById('xb_docmeeai_ppt_user_info_form').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            fetch(this.action, {
                method: 'POST',
                body: formData,
                headers: { 'X-WP-Nonce': formData.get('nonce') }
            })
            .then(response => response.json())
            .then(data => {
                if (data.user_info) {
                    document.getElementById('xb_docmeeai_ppt_user_info').innerHTML = data.user_info;
                } else {
                    alert('查询失败: 用户不存在或无数据');
                }
            })
            .catch(error => alert('查询失败: ' + error.message));
        });

        document.getElementById('xb_docmeeai_ppt_user_limit_form').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            fetch(this.action, {
                method: 'POST',
                body: formData,
                headers: { 'X-WP-Nonce': formData.get('nonce') }
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
            })
            .catch(error => alert('设置失败: ' + error.message));
        });
    </script>
    <?php
}

// 用户权限管理页面
function xb_docmeeai_ppt_user_permissions_page() {
    global $wpdb;
    $permission_table = $wpdb->prefix . 'xb_docmeeai_ppt_permissions';

    // 处理添加权限
    if (isset($_POST['xb_docmeeai_ppt_add_permission']) && check_admin_referer('xb_docmeeai_ppt_add_permission')) {
        $user_id = intval($_POST['user_id']);
        $expires_at = sanitize_text_field($_POST['expires_at']);
        
        if (!get_user_by('ID', $user_id)) {
            echo '<div class="error"><p>用户 ID 不存在</p></div>';
        } elseif (empty($expires_at)) {
            echo '<div class="error"><p>请设置到期时间</p></div>';
        } else {
            $wpdb->replace($permission_table, [
                'user_id' => $user_id,
                'added_at' => current_time('mysql'),
                'expires_at' => $expires_at
            ], ['%d', '%s', '%s']);
            echo '<div class="updated"><p>权限已添加/更新</p></div>';
        }
    }

    // 处理删除权限
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['user_id']) && check_admin_referer('xb_docmeeai_ppt_delete_permission')) {
        $user_id = intval($_GET['user_id']);
        $wpdb->delete($permission_table, ['user_id' => $user_id], ['%d']);
        echo '<div class="updated"><p>权限已删除</p></div>';
    }

    // 获取所有有权限的用户
    $permissions = $wpdb->get_results("SELECT p.*, u.user_login FROM $permission_table p LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID ORDER BY p.added_at DESC");
    ?>
    <div class="wrap">
        <h1 class="xb_docmeeai_ppt_title">用户权限管理</h1>
        
        <h2>添加用户权限</h2>
        <form method="post">
            <?php wp_nonce_field('xb_docmeeai_ppt_add_permission'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="user_id">用户 ID</label></th>
                    <td><input type="number" name="user_id" id="user_id" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="expires_at">权限到期时间</label></th>
                    <td><input type="datetime-local" name="expires_at" id="expires_at" required></td>
                </tr>
            </table>
            <?php submit_button('添加权限', 'primary', 'xb_docmeeai_ppt_add_permission'); ?>
        </form>

        <h2>已授权用户列表</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户名</th>
                    <th>用户 ID</th>
                    <th>添加时间</th>
                    <th>到期时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($permissions)) : ?>
                    <tr><td colspan="5">暂无授权用户</td></tr>
                <?php else : ?>
                    <?php foreach ($permissions as $perm) : ?>
                        <tr>
                            <td><?php echo esc_html($perm->user_login ?: '未知用户'); ?></td>
                            <td><?php echo esc_html($perm->user_id); ?></td>
                            <td><?php echo esc_html($perm->added_at); ?></td>
                            <td><?php echo esc_html($perm->expires_at); ?></td>
                            <td>
                                <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=xb_docmeeai_ppt_user_permissions&action=delete&user_id=' . $perm->user_id), 'xb_docmeeai_ppt_delete_permission'); ?>" class="button button-small button-danger" onclick="return confirm('确定删除该用户权限？');">删除</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// 注册 REST API 路由
add_action('rest_api_init', 'xb_docmeeai_ppt_register_rest_routes');
function xb_docmeeai_ppt_register_rest_routes() {
    register_rest_route('xb_docmeeai_ppt/v1', '/token', [
        'methods' => 'POST',
        'callback' => 'xb_docmeeai_ppt_create_token',
        'permission_callback' => function() { return current_user_can('read') && xb_docmeeai_ppt_has_permission(get_current_user_id()); },
    ]);

    register_rest_route('xb_docmeeai_ppt/v1', '/user_limit', [
        'methods' => 'POST',
        'callback' => 'xb_docmeeai_ppt_set_user_limit',
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ]);

    register_rest_route('xb_docmeeai_ppt/v1', '/user_info', [
        'methods' => 'POST',
        'callback' => 'xb_docmeeai_ppt_get_user_info',
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ]);

    register_rest_route('xb_docmeeai_ppt/v1', '/log_usage', [
        'methods' => 'POST',
        'callback' => 'xb_docmeeai_ppt_log_usage',
        'permission_callback' => function() { return is_user_logged_in() && xb_docmeeai_ppt_has_permission(get_current_user_id()); },
    ]);
}

// 创建或获取用户 Token（每小时更新）
function xb_docmeeai_ppt_create_token($request) {
    global $wpdb;
    $api_key = get_option('xb_docmeeai_ppt_api_key');
    if (empty($api_key)) {
        error_log('XB Docmee AI PPT: API Key 未设置');
        return new WP_Error('config_error', 'API Key 未设置，请在后台配置', ['status' => 400]);
    }

    $uid = sanitize_text_field($request['uid']);
    $limit = max(1, intval($request['limit']));
    $table = $wpdb->prefix . 'xb_docmeeai_ppt_user_tokens';

    $cache_key = 'xb_docmeeai_ppt_token_' . md5($uid . '_' . $limit);
    $cache_group = 'xb_docmeeai_ppt';

    // 检查Redis缓存
    $cached_token = wp_cache_get($cache_key, $cache_group);

    if (false !== $cached_token) {
        error_log('XB Docmee AI PPT: Cache hit for user ' . $uid . ': ' . $cached_token);
        return ['success' => true, 'token' => $cached_token];
    }

    // 缓存未命中，查数据库
    $token_data = $wpdb->get_row($wpdb->prepare(
        "SELECT token, created_at FROM $table WHERE user_id = %d",
        $uid
    ), ARRAY_A);

    $force_refresh = isset($request['force_refresh']) && $request['force_refresh'];
    $token_expired = !$token_data || (strtotime($token_data['created_at']) + 3600 < time());

    if ($force_refresh || $token_expired) {
        $wpdb->delete($table, ['user_id' => $uid], ['%d']);

        $response = wp_remote_post('https://docmee.cn/api/user/createApiToken', [
            'headers' => [
                'Api-Key' => $api_key,
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode(['uid' => $uid, 'limit' => $limit]),
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            error_log('XB Docmee AI PPT: API 请求失败 - ' . $response->get_error_message());
            return new WP_Error('api_error', '无法连接文多多 API: ' . $response->get_error_message(), ['status' => 500]);
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($body['data']['token'])) {
            $token = $body['data']['token'];
            $wpdb->insert($table, [
                'user_id' => $uid,
                'token' => $token,
                'created_at' => current_time('mysql')
            ], ['%d', '%s', '%s']);

            wp_cache_set($cache_key, $token, $cache_group, 3600);
            error_log('XB Docmee AI PPT: Token created and cached for user ' . $uid . ': ' . $token);
            return ['success' => true, 'token' => $token];
        }

        error_log('XB Docmee AI PPT: Token 创建失败 - ' . ($body['message'] ?? '未知错误'));
        return new WP_Error('token_error', 'Token 创建失败: ' . ($body['message'] ?? '未知错误'), ['status' => 400]);
    }

    wp_cache_set($cache_key, $token_data['token'], $cache_group, 3600);
    error_log('XB Docmee AI PPT: Using DB token and cached for user ' . $uid . ': ' . $token_data['token']);
    return ['success' => true, 'token' => $token_data['token']];
}

// 设置用户限制并刷新Token
function xb_docmeeai_ppt_set_user_limit($request) {
    global $wpdb;
    $user_id = intval($request['user_id']);
    $max_limit = intval($request['max_limit']);
    $limit_table = $wpdb->prefix . 'xb_docmeeai_ppt_user_limits';
    $token_table = $wpdb->prefix . 'xb_docmeeai_ppt_user_tokens';

    if (!get_user_by('ID', $user_id)) {
        return new WP_Error('user_error', '用户 ID 不存在', ['status' => 400]);
    }

    if ($max_limit === 0) {
        $wpdb->delete($limit_table, ['user_id' => $user_id], ['%d']);
        $limit = get_option('xb_docmeeai_ppt_default_limit', 2);
    } else {
        $wpdb->replace($limit_table, [
            'user_id' => $user_id,
            'max_limit' => $max_limit,
        ], ['%d', '%d']);
        $limit = $max_limit;
    }

    $wpdb->delete($token_table, ['user_id' => $user_id], ['%d']);
    $token_request = new WP_REST_Request('POST', '');
    $token_request->set_param('uid', $user_id);
    $token_request->set_param('limit', $limit);
    $token_request->set_param('force_refresh', true);
    $token_response = xb_docmeeai_ppt_create_token($token_request);

    if (is_wp_error($token_response)) {
        error_log('XB Docmee AI PPT: Failed to generate new token after setting limit for user ' . $user_id);
        return new WP_Error('token_error', '设置成功，但新Token生成失败: ' . $token_response->get_error_message(), ['status' => 500]);
    }

    error_log('XB Docmee AI PPT: User limit set for user ' . $user_id . ' to ' . $limit);
    return ['message' => '设置成功，新Token已生成，请刷新页面以应用新限制', 'token' => $token_response['token']];
}

// 获取用户限制
function xb_docmeeai_ppt_get_user_limit($user_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'xb_docmeeai_ppt_user_limits';
    return $wpdb->get_var($wpdb->prepare("SELECT max_limit FROM $table WHERE user_id = %d", $user_id));
}

// 获取用户当前 Token
function xb_docmeeai_ppt_get_user_token($user_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'xb_docmeeai_ppt_user_tokens';
    return $wpdb->get_row($wpdb->prepare(
        "SELECT token, created_at FROM $table WHERE user_id = %d",
        $user_id
    ), ARRAY_A);
}

// 获取用户信息
function xb_docmeeai_ppt_get_user_info($request) {
    global $wpdb;
    $user_id = intval($request['user_id']);
    $token_table = $wpdb->prefix . 'xb_docmeeai_ppt_user_tokens';
    $limit_table = $wpdb->prefix . 'xb_docmeeai_ppt_user_limits';
    $usage_table = $wpdb->prefix . 'xb_docmeeai_ppt_usage';
    $permission_table = $wpdb->prefix . 'xb_docmeeai_ppt_permissions';

    if (!get_user_by('ID', $user_id)) {
        return ['user_info' => '<p>错误：用户 ID ' . esc_html($user_id) . ' 不存在</p>'];
    }

    $token_data = $wpdb->get_row($wpdb->prepare(
        "SELECT token FROM $token_table WHERE user_id = %d",
        $user_id
    ));

    $limit = xb_docmeeai_ppt_get_user_limit($user_id) ?: get_option('xb_docmeeai_ppt_default_limit', 2);

    $total_ppt_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $usage_table WHERE user_id = %d",
        $user_id
    ));

    $permission = $wpdb->get_row($wpdb->prepare(
        "SELECT added_at, expires_at FROM $permission_table WHERE user_id = %d",
        $user_id
    ));

    $user_info = '<h3>用户信息</h3>';
    $user_info .= '<p>用户 ID: ' . esc_html($user_id) . '</p>';
    $user_info .= '<p>当前 Token: ' . ($token_data ? esc_html($token_data->token) : '尚未生成') . '</p>';
    $user_info .= '<p>每个Token最大生成次数: ' . esc_html($limit) . '</p>';
    $user_info .= '<p>总共生成 PPT 次数: ' . esc_html($total_ppt_count) . '</p>';
    $user_info .= '<p>权限状态: ' . ($permission ? '已授权 (添加于: ' . esc_html($permission->added_at) . ', 到期: ' . esc_html($permission->expires_at) . ')' : '未授权') . '</p>';

    return ['user_info' => $user_info];
}

// 记录PPT生成使用
function xb_docmeeai_ppt_log_usage($request) {
    global $wpdb;
    error_log('XB Docmee AI PPT: Log Usage Called - Request: ' . json_encode($request->get_params()));

    $user_id = intval($request['user_id']);
    $table = $wpdb->prefix . 'xb_docmeeai_ppt_usage';

    if (!get_user_by('ID', $user_id)) {
        error_log("XB Docmee AI PPT: Log Usage Failed - User ID $user_id does not exist");
        return new WP_Error('user_error', '用户 ID 不存在', ['status' => 400]);
    }

    $insert_result = $wpdb->insert($table, [
        'user_id' => $user_id,
        'usage_date' => current_time('mysql'),
    ], ['%d', '%s']);

    if ($insert_result === false) {
        error_log("XB Docmee AI PPT: Log Usage Failed - Database insert error for user $user_id: " . $wpdb->last_error);
        return new WP_Error('db_error', '记录使用失败: 数据库错误', ['status' => 500]);
    }

    error_log("XB Docmee AI PPT: Usage Logged Successfully - User ID: $user_id");
    return ['success' => true, 'message' => '使用记录已保存'];
}