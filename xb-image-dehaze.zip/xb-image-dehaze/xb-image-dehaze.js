jQuery(document).ready(function($) {
    const $uploadBtn = $('#xb-dehaze-upload-btn');
    const $preview = $('#xb-dehaze-preview');
    const $processBtn = $('#xb-dehaze-process-btn');
    const $result = $('#xb-dehaze-result');
    const $downloadBtn = $('#xb-dehaze-download-btn');
    const $usage = $('.xb-dehaze-usage');
    let attachmentId = null;
    let originalFormat = null;

    // 从后台获取支持的文件类型
    const allowedTypes = xb_dehaze_vars.allowed_types;
    const acceptValue = allowedTypes.map(type => `.${type}`).join(',');

    // 创建隐藏的 input 文件元素，并设置 accept 属性
    const $fileInput = $(`<input type="file" accept="${acceptValue}" style="display:none;">`);
    $('body').append($fileInput);

    // 点击上传按钮触发文件选择
    $uploadBtn.on('click', function() {
        $fileInput.click();
    });

    // 文件选择后上传
    $fileInput.on('change', function() {
        const file = this.files[0];
        if (!file) return;

        // 获取文件扩展名
        originalFormat = file.name.split('.').pop().toLowerCase();

        // 前端检查文件扩展名是否在允许的类型中
        if (!allowedTypes.includes(originalFormat)) {
            xb_dehaze_show_notice(`图片格式不支持，仅支持：${allowedTypes.join(',')}`);
            $fileInput.val(''); // 清空输入
            return;
        }

        // 使用 FileReader 检查文件真实性
        const reader = new FileReader();
        reader.onload = function(e) {
            const arr = (new Uint8Array(e.target.result)).subarray(0, 4);
            let header = '';
            for (let i = 0; i < arr.length; i++) {
                header += arr[i].toString(16);
            }

            // 检查文件头是否匹配常见图片格式
            const isValidImage = checkImageHeader(header, originalFormat);
            if (!isValidImage) {
                xb_dehaze_show_notice('文件好像不正确，请更换图片');
                $fileInput.val(''); // 清空输入
                return;
            }

            // 如果通过验证，执行上传
            const formData = new FormData();
            formData.append('file', file);

            $.ajax({
                url: xb_dehaze_vars.ajax_url + 'upload',
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: { 'X-WP-Nonce': xb_dehaze_vars.nonce },
                success: function(response) {
                    $preview.html(`<img src="${response.url}" alt="Preview">`);
                    attachmentId = response.attachment_id;
                    $processBtn.prop('disabled', false);
                },
                error: function(xhr) {
                    xb_dehaze_show_notice(xhr.responseJSON.message);
                    $fileInput.val(''); // 清空输入
                }
            });
        };
        reader.readAsArrayBuffer(file);
    });

    // 点击处理按钮去雾
    $processBtn.on('click', function() {
        if (!attachmentId) return;

        $result.html('<div class="xb-dehaze-processing">正在处理中...</div>');

        $.ajax({
            url: xb_dehaze_vars.ajax_url + 'process',
            method: 'POST',
            data: JSON.stringify({ url: $preview.find('img').attr('src'), attachment_id: attachmentId }),
            contentType: 'application/json',
            headers: { 'X-WP-Nonce': xb_dehaze_vars.nonce },
            success: function(response) {
                const imgSrc = 'data:image/' + originalFormat + ';base64,' + response.image;
                $result.html(`<img src="${imgSrc}" alt="Processed">`);
                $downloadBtn.show();
                updateUsageCount(response.remaining, response.limit);
            },
            error: function(xhr) {
                $result.empty();
                xb_dehaze_show_notice(xhr.responseJSON.message);
            }
        });
    });

    // 下载处理后的图片
    $downloadBtn.on('click', function() {
        const imgSrc = $result.find('img').attr('src');
        const link = document.createElement('a');
        link.href = imgSrc;
        link.download = `dehazed_image.${originalFormat}`;
        link.click();
    });

    // “快速登录”按钮点击事件
    $('.xb-dehaze-login-btn').on('click', function(e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = xb_dehaze_vars.login_url;
        }
    });

    // 更新使用次数显示
    function updateUsageCount(remaining, limit) {
        if (remaining > 0) {
            $usage.text(`今日剩余去雾次数：${remaining}/${limit}`);
        } else {
            $usage.text('今日使用次数已经用完了，请明天再来');
        }
    }

    // 显示提示消息
    function xb_dehaze_show_notice(message) {
        const $notice = $('<div class="xb-dehaze-custom-notice"></div>').text(message);
        $('body').append($notice);
        setTimeout(() => $notice.remove(), 3000);
    }

    // 检查图片文件头
    function checkImageHeader(header, format) {
        const signatures = {
            'jpg': ['ffd8ff'],
            'png': ['89504e47'],
            'gif': ['47494638']
        };
        const validSignatures = signatures[format];
        return validSignatures && validSignatures.some(sig => header.toLowerCase().startsWith(sig));
    }
});