<?php
/*
Plugin Name: 小半图片去雾
Description: 基于百度云api的图片去雾处理
Version: 1.0.1
Author: Summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 创建数据表
function xb_dehaze_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_dehaze_records';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        original_image_id BIGINT(20) UNSIGNED NOT NULL,
        processed_time DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// 创建前台页面
function xb_dehaze_create_page() {
    $pages = get_posts([
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_dehaze_frontend]',
        'numberposts' => 1,
    ]);

    if (empty($pages)) {
        wp_insert_post([
            'post_title'    => '图像去雾',
            'post_content'  => '[xb_dehaze_frontend]',
            'post_status'   => 'publish',
            'post_type'     => 'page',
        ]);
    }
}

// 加载前台 JS 和 CSS
function xb_dehaze_enqueue_frontend_assets() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_dehaze_frontend')) {
        //wp_enqueue_style('xb-dehaze-style', plugins_url('xb-image-dehaze.css', __FILE__), [], '1.0');
        //wp_enqueue_script('xb-dehaze-script', plugins_url('xb-image-dehaze.js', __FILE__), ['jquery'], '1.0', true);

        wp_enqueue_style('xb-dehaze-style', 'https://img.qiyucloud.com/cloud/xb-image-dehaze/xb-image-dehaze.css', [], '1.0.1');
        wp_enqueue_script('xb-dehaze-script', 'https://img.qiyucloud.com/cloud/xb-image-dehaze/xb-image-dehaze.js', ['jquery'], '1.0.1', true);
        // 添加支持的文件类型到JS变量中
        $allowed_types = explode(',', get_option('xb_dehaze_file_types', 'jpg,png'));
        wp_localize_script('xb-dehaze-script', 'xb_dehaze_vars', [
            'ajax_url' => rest_url('xb_dehaze/v1/'),
            'nonce'    => wp_create_nonce('wp_rest'),
            'login_url' => wp_login_url(),
            'allowed_types' => $allowed_types // 新增支持的文件类型
        ]);
    }
}

// 插件激活
function xb_dehaze_activate() {
    xb_dehaze_create_table();
    xb_dehaze_create_page();
}
register_activation_hook(__FILE__, 'xb_dehaze_activate');

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_dehaze_enqueue_frontend_assets');

// 注册短代码（效果示例和公告板块共用）
function xb_dehaze_frontend_shortcode() {
    ob_start();
    ?>
    <div class="xb-dehaze-container">
        <div class="xb-dehaze-custom-title">图像去雾处理</div>
        <?php if (!is_user_logged_in()): ?>
            <div class="xb-dehaze-guest-notice">
                <p>请先登录</p>
                <button class="xb-dehaze-login-btn">快速登录</button>
            </div>
        <?php else: ?>
            <?php
            $daily_limit = (int) get_option('xb_dehaze_daily_limit', 10);
            $user_id = get_current_user_id();
            $user_limit = get_user_meta($user_id, 'xb_dehaze_custom_limit', true);
            $limit = $user_limit ? (int) $user_limit : $daily_limit;

            global $wpdb;
            $today = date('Y-m-d');
            $count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}xb_dehaze_records WHERE user_id = %d AND DATE(processed_time) = %s",
                $user_id, $today
            ));
            $remaining = max(0, $limit - $count);

            $usage_text = $remaining > 0 ? "今日剩余去雾次数：{$remaining}/{$limit}" : "今日使用次数已经用完了，请明天再来";
            ?>
            <?php if ($remaining > 0): ?>
                <div class="xb-dehaze-layout">
                    <div class="xb-dehaze-left">
                        <div class="xb-dehaze-title">上传图片</div>
                        <div class="xb-dehaze-upload-btn" id="xb-dehaze-upload-btn">选择图片</div>
                        <div id="xb-dehaze-preview"></div>
                    </div>
                    <div class="xb-dehaze-right">
                        <div class="xb-dehaze-title">图像处理结果</div>
                        <button id="xb-dehaze-process-btn" disabled>开始去雾</button>
                        <div id="xb-dehaze-result"></div>
                        <button id="xb-dehaze-download-btn" style="display:none;">快速下载</button>
                    </div>
                </div>
            <?php endif; ?>
            <div class="xb-dehaze-usage"><?php echo $usage_text; ?></div>
        <?php endif; ?>
        <?php if ($notice = get_option('xb_dehaze_notice')): ?>
            <div class="xb-dehaze-notice-content"><?php echo wp_kses_post($notice); ?></div>
        <?php endif; ?>
        <div class="xb-dehaze-examples">
            <div class="xb-dehaze-example-title">效果示例</div>
            <div class="xb-dehaze-example-images">
                <div class="xb-dehaze-example">
                    <img src="https://aiimg.qiyucloud.com/htai/2025/04/20250409020431507.jpg" alt="原始图片">
                    <span>原始图片</span>
                </div>
                <div class="xb-dehaze-example">
                    <img src="https://aiimg.qiyucloud.com/htai/2025/04/20250409041227683.jpg" alt="处理后图片">
                    <span>处理后图片</span>
                </div>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('xb_dehaze_frontend', 'xb_dehaze_frontend_shortcode');

// REST API 注册
function xb_dehaze_register_rest_routes() {
    register_rest_route('xb_dehaze/v1', '/upload', [
        'methods'  => 'POST',
        'callback' => 'xb_dehaze_handle_upload',
        'permission_callback' => function () {
            return is_user_logged_in() && wp_verify_nonce($_SERVER['HTTP_X_WP_NONCE'], 'wp_rest');
        },
    ]);

    register_rest_route('xb_dehaze/v1', '/process', [
        'methods'  => 'POST',
        'callback' => 'xb_dehaze_handle_process',
        'permission_callback' => function () {
            return is_user_logged_in() && wp_verify_nonce($_SERVER['HTTP_X_WP_NONCE'], 'wp_rest');
        },
    ]);
}
add_action('rest_api_init', 'xb_dehaze_register_rest_routes');

// 处理图片上传
function xb_dehaze_handle_upload($request) {
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    $file = $_FILES['file'];
    $allowed_types = explode(',', get_option('xb_dehaze_file_types', 'jpg,png'));
    $max_size = (int) get_option('xb_dehaze_max_size', 5) * 1024 * 1024;

    // 获取文件扩展名
    $file_type = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    // 检查文件扩展名是否在允许的类型中
    if (!in_array($file_type, $allowed_types)) {
        return new WP_Error('invalid_type', '图片格式不支持，仅支持：' . implode(',', $allowed_types), ['status' => 400]);
    }

    // 检查文件大小
    if ($file['size'] > $max_size) {
        return new WP_Error('file_too_large', '文件太大，请上传低于' . ($max_size / (1024 * 1024)) . 'MB的图片', ['status' => 400]);
    }

    // 检查真实文件类型
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    // 定义允许的MIME类型映射
    $allowed_mime_types = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif'
    ];

    // 检查MIME类型是否与扩展名匹配且在允许范围内
    $expected_mime = isset($allowed_mime_types[$file_type]) ? $allowed_mime_types[$file_type] : null;
    if (!$expected_mime || $mime_type !== $expected_mime || !in_array($file_type, $allowed_types)) {
        return new WP_Error('invalid_image', '文件不是真实的图片，请更换图片', ['status' => 400]);
    }

    $upload = wp_handle_upload($file, ['test_form' => false]);
    if (isset($upload['error'])) {
        return new WP_Error('upload_error', $upload['error'], ['status' => 500]);
    }

    $attachment_id = wp_insert_attachment([
        'guid'           => $upload['url'],
        'post_mime_type' => $upload['type'],
        'post_title'     => basename($upload['file']),
        'post_content'   => '',
        'post_status'    => 'inherit',
    ], $upload['file']);

    require_once(ABSPATH . 'wp-admin/includes/image.php');
    wp_generate_attachment_metadata($attachment_id, $upload['file']);
    return ['url' => $upload['url'], 'attachment_id' => $attachment_id];
}

// 处理去雾请求
function xb_dehaze_handle_process($request) {
    $url = $request['url'];
    $attachment_id = $request['attachment_id'];
    $api_key = get_option('xb_dehaze_api_key');
    if (!$api_key) {
        return new WP_Error('no_api_key', '未设置百度云 API Key', ['status' => 500]);
    }

    $daily_limit = (int) get_option('xb_dehaze_daily_limit', 10);
    $user_id = get_current_user_id();
    $user_limit = get_user_meta($user_id, 'xb_dehaze_custom_limit', true);
    $limit = $user_limit ? (int) $user_limit : $daily_limit;

    global $wpdb;
    $today = date('Y-m-d');
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}xb_dehaze_records WHERE user_id = %d AND DATE(processed_time) = %s",
        $user_id, $today
    ));
    if ($count >= $limit) {
        return new WP_Error('limit_exceeded', '今日去雾次数已用尽', ['status' => 400]);
    }

    $response = wp_remote_post('https://aip.baidubce.com/rest/2.0/image-process/v1/dehaze', [
        'headers' => [
            'Content-Type'  => 'application/x-www-form-urlencoded',
            'Accept'        => 'application/json',
            'Authorization' => 'Bearer ' . $api_key,
        ],
        'body' => ['url' => $url],
    ]);

    if (is_wp_error($response)) {
        return $response;
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    if (!isset($body['image'])) {
        return new WP_Error('api_error', '去雾处理失败', ['status' => 500]);
    }

    $wpdb->insert(
        $wpdb->prefix . 'xb_dehaze_records',
        [
            'user_id'         => $user_id,
            'original_image_id' => $attachment_id,
            'processed_time'  => current_time('mysql'),
        ],
        ['%d', '%d', '%s']
    );

    return [
        'image' => $body['image'],
        'remaining' => max(0, $limit - ($count + 1)),
        'limit' => $limit
    ];
}

// 后台菜单
function xb_dehaze_admin_menu() {
    add_menu_page('图像去雾设置', '图像去雾', 'manage_options', 'xb-dehaze-settings', 'xb_dehaze_settings_page');
    add_submenu_page('xb-dehaze-settings', '用户图像去雾记录', '用户图像去雾', 'manage_options', 'xb-dehaze-records', 'xb_dehaze_records_page');
}
add_action('admin_menu', 'xb_dehaze_admin_menu');

// 设置页面
function xb_dehaze_settings_page() {
    if (isset($_POST['xb_dehaze_save'])) {
        update_option('xb_dehaze_api_key', sanitize_text_field($_POST['api_key']));
        update_option('xb_dehaze_file_types', sanitize_text_field($_POST['file_types']));
        update_option('xb_dehaze_max_size', (int) $_POST['max_size']);
        update_option('xb_dehaze_daily_limit', (int) $_POST['daily_limit']);
        update_option('xb_dehaze_notice', wp_kses_post($_POST['notice']));
        echo '<div class="updated xb-dehaze-admin-notice"><p>设置已保存</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>图像去雾设置</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>百度云 API Key</th>
                    <td><input type="text" name="api_key" value="<?php echo esc_attr(get_option('xb_dehaze_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>支持的图片格式</th>
                    <td><input type="text" name="file_types" value="<?php echo esc_attr(get_option('xb_dehaze_file_types', 'jpg,png')); ?>" class="regular-text"> (用逗号分隔，如 jpg,png)</td>
                </tr>
                <tr>
                    <th>最大图片大小 (MB)</th>
                    <td><input type="number" name="max_size" value="<?php echo esc_attr(get_option('xb_dehaze_max_size', 5)); ?>" min="1" class="small-text"> MB</td>
                </tr>
                <tr>
                    <th>默认每日使用次数</th>
                    <td><input type="number" name="daily_limit" value="<?php echo esc_attr(get_option('xb_dehaze_daily_limit', 10)); ?>" min="1" class="small-text"> 次</td>
                </tr>
                <tr>
                    <th>公告内容</th>
                    <td><textarea name="notice" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_dehaze_notice')); ?></textarea></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="xb_dehaze_save" class="button-primary" value="保存设置"></p>
        </form>
        由百度云提供服务：https://ai.baidu.com/tech/imageprocess/dehaze <br>
        单价：0.007 元
    </div>
    <script>
        jQuery(document).ready(function($) {
            setTimeout(function() {
                $('.xb-dehaze-admin-notice').fadeOut(500);
            }, 3000);
        });
    </script>
    <?php
}

// 用户记录页面
function xb_dehaze_records_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_dehaze_records';
    $per_page = 20;
    $paged = isset($_GET['paged']) ? (int) $_GET['paged'] : 1;
    $offset = ($paged - 1) * $per_page;
    $user_id_filter = isset($_GET['user_id']) ? (int) $_GET['user_id'] : 0;

    if (isset($_GET['delete_id'])) {
        $wpdb->delete($table_name, ['id' => (int) $_GET['delete_id']], ['%d']);
        echo '<div class="updated xb-dehaze-admin-notice"><p>记录已删除</p></div>';
    }

    if (isset($_POST['xb_dehaze_user_limit'])) {
        $custom_limit = (int) $_POST['custom_limit'];
        if ($custom_limit > 0) {
            update_user_meta($user_id_filter, 'xb_dehaze_custom_limit', $custom_limit);
        } else {
            delete_user_meta($user_id_filter, 'xb_dehaze_custom_limit');
        }
        echo '<div class="updated xb-dehaze-admin-notice"><p>用户限制已更新</p></div>';
    }

    $where = $user_id_filter ? $wpdb->prepare('WHERE user_id = %d', $user_id_filter) : '';
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
    $records = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name $where ORDER BY processed_time DESC LIMIT %d OFFSET %d",
        $per_page, $offset
    ));

    $today = date('Y-m-d');
    $daily_count = $user_id_filter ? $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND DATE(processed_time) = %s",
        $user_id_filter, $today
    )) : 0;
    $total_user_count = $user_id_filter ? $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE user_id = %d",
        $user_id_filter
    )) : 0;
    $daily_limit = (int) get_option('xb_dehaze_daily_limit', 10);
    $user_limit = $user_id_filter ? get_user_meta($user_id_filter, 'xb_dehaze_custom_limit', true) : '';
    $limit = $user_limit ? (int) $user_limit : $daily_limit;

    ?>
    <div class="wrap">
        <h1>用户图像去雾记录</h1>
        <p>网站总处理数量：<?php echo $total; ?></p>
        <form method="get">
            <input type="hidden" name="page" value="xb-dehaze-records">
            <label>查询用户 ID: </label>
            <input type="number" name="user_id" value="<?php echo $user_id_filter; ?>">
            <input type="submit" value="查询" class="button">
        </form>
        <?php if ($user_id_filter): ?>
            <p>今日使用次数：<?php echo $daily_count; ?>/<?php echo $limit; ?>，总处理次数：<?php echo $total_user_count; ?></p>
            <form method="post">
                <label>设置用户每日限制: </label>
                <input type="number" name="custom_limit" value="<?php echo $user_limit ?: $daily_limit; ?>" min="0">
                <input type="submit" name="xb_dehaze_user_limit" value="保存" class="button">
                <p class="description">设置为 0 或留空将恢复为默认值 (<?php echo $daily_limit; ?> 次)</p>
            </form>
            <a href="?page=xb-dehaze-records" class="button" style="margin-top: 10px;">返回全部记录</a>
        <?php endif; ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>用户名</th>
                    <th>原始图片</th>
                    <th>处理时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record): ?>
                    <tr>
                        <td><?php echo $record->user_id; ?></td>
                        <td><?php echo get_userdata($record->user_id)->user_login; ?></td>
                        <td><img src="<?php echo wp_get_attachment_url($record->original_image_id); ?>" style="width:100px;height:100px;"></td>
                        <td><?php echo $record->processed_time; ?></td>
                        <td><a href="?page=xb-dehaze-records&delete_id=<?php echo $record->id; ?>" class="button">删除</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        $pagination = paginate_links([
            'base'    => add_query_arg('paged', '%#%'),
            'format'  => '',
            'total'   => ceil($total / $per_page),
            'current' => $paged,
        ]);
        if ($pagination) {
            echo '<div class="tablenav"><div class="tablenav-pages">' . $pagination . '</div></div>';
        }
        ?>
    </div>
    <script>
        jQuery(document).ready(function($) {
            setTimeout(function() {
                $('.xb-dehaze-admin-notice').fadeOut(500);
            }, 3000);
        });
    </script>
    <?php
}