jQuery(document).ready(function($) {
    // 页面加载时获取使用情况
    $.ajax({
        url: xb_aixhs_ajax.ajax_url,
        type: 'POST',
        data: {
            action: 'xb_aixhs_get_usage'
        },
        success: function(response) {
            if (response.success) {
                if (!response.data.hide_stats) {
                    $('.xb_aixhs_usage_info').html('今日剩余解析次数：' + response.data.remaining + '/' + response.data.limit).show();
                }
                if (response.data.remaining <= 0) {
                    $('#xb_aixhs_query_form').hide();
                }
            }
        }
    });

    // 防止重复提交的标志
    var isSubmitting = false;

    // 提交解析请求
    $('#xb_aixhs_query_form').on('submit', function(e) {
        e.preventDefault();
        
        // 防止重复提交
        if (isSubmitting) {
            return false;
        }
        
        var url = $('#xb_aixhs_url').val().trim();
        var cookies = $('#xb_aixhs_cookies').val().trim();
        var nonce = $('#xb_aixhs_nonce').val();

        if (!url) {
            xb_aixhs_show_message('请输入小红书笔记链接！', 'error');
            return false;
        }

        isSubmitting = true;
        $('.xb_aixhs_submit_button').prop('disabled', true).text('解析中...');
        $('#xb_aixhs_result').html('');

        $.ajax({
            url: xb_aixhs_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_aixhs_query',
                url: url,
                cookies: cookies,
                nonce: nonce
            },
            success: function(response) {
                isSubmitting = false;
                $('.xb_aixhs_submit_button').prop('disabled', false).text('开始解析');
                
                if (response.success) {
                    $('#xb_aixhs_result').html(response.data.result);
                    if (!response.data.hide_stats) {
                        $('.xb_aixhs_usage_info').html('今日剩余解析次数：' + response.data.remaining + '/' + response.data.limit).show();
                    }
                    if (response.data.remaining <= 0) {
                        $('#xb_aixhs_query_form').hide();
                        if (response.data.is_guest) {
                            $('.xb_aixhs_message').show();
                            $('.xb_aixhs_login_button').show();
                        }
                    }
                    //xb_aixhs_show_message('解析成功！', 'success');
                } else {
                    $('#xb_aixhs_result').html('<div class="xb_aixhs_error">' + response.data.message + '</div>');
                    if (!response.data.hide_stats) {
                        $('.xb_aixhs_usage_info').html('今日剩余解析次数：' + response.data.remaining + '/' + response.data.limit).show();
                    }
                    if (response.data.remaining <= 0) {
                        $('#xb_aixhs_query_form').hide();
                        if (response.data.is_guest) {
                            $('.xb_aixhs_message').show();
                            $('.xb_aixhs_login_button').show();
                        }
                    }
                    xb_aixhs_show_message(response.data.message, 'error');
                }
            },
            error: function() {
                isSubmitting = false;
                $('.xb_aixhs_submit_button').prop('disabled', false).text('开始解析');
                $('#xb_aixhs_result').html('<div class="xb_aixhs_error">请求失败，请稍后重试！</div>');
                xb_aixhs_show_message('请求失败，请稍后重试！', 'error');
            }
        });
    });

    // 清空输入框
    $('.xb_aixhs_clear_button').on('click', function() {
        $('#xb_aixhs_url').val('');
        $('#xb_aixhs_cookies').val('');
        $('#xb_aixhs_result').html('');
        $('.xb_aixhs_usage_info').hide();
    });

    // 快速登录按钮功能
    $('.xb_aixhs_login_button').on('click', function(e) {
        e.preventDefault();
        
        // 优先调用启灵主题弹窗
        if (typeof window.developerStarterShowLoginModal === 'function') {
            window.developerStarterShowLoginModal('login');
            return;
        }
        
        const $themeLoginBtn = $('#header-login-toggle');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });

    // 图片加载错误处理和画廊功能
    $(document).on('error', '.xb_aixhs_cover, .xb_aixhs_gallery_image', function() {
        var $img = $(this);
        var originalSrc = $img.attr('src');
        
        // 如果图片加载失败，尝试通过其他方式加载
        if (!$img.hasClass('xb_aixhs_retry_loaded')) {
            $img.addClass('xb_aixhs_retry_loaded');
            
            // 创建一个新的图片元素，设置不同的属性
            var newImg = new Image();
            newImg.crossOrigin = 'anonymous';
            newImg.referrerPolicy = 'no-referrer';
            
            newImg.onload = function() {
                $img.attr('src', originalSrc);
            };
            
            newImg.onerror = function() {
                // 如果还是失败，显示占位图或错误信息
                $img.attr('src', 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPuWbvueJh+aXoOazleWKoOi9vTwvdGV4dD48L3N2Zz4=');
                $img.attr('alt', '图片无法加载');
            };
            
            newImg.src = originalSrc;
        }
    });

    // 图片画廊功能
    $(document).on('click', '.xb_aixhs_gallery_image', function() {
        var src = $(this).attr('src');
        xb_aixhs_show_image_modal(src);
    });

    // Cookies本地保存功能
    $('.xb_aixhs_save_cookies_button').on('click', function() {
        var cookies = $('#xb_aixhs_cookies').val().trim();
        if (cookies) {
            localStorage.setItem('xb_aixhs_saved_cookies', cookies);
            xb_aixhs_show_message('Cookies已保存到本地！', 'success');
        } else {
            xb_aixhs_show_message('请先输入Cookies值！', 'error');
        }
    });

    // 载入本地Cookies
    $('.xb_aixhs_load_cookies_button').on('click', function() {
        var savedCookies = localStorage.getItem('xb_aixhs_saved_cookies');
        if (savedCookies) {
            $('#xb_aixhs_cookies').val(savedCookies);
            xb_aixhs_show_message('Cookies已载入！', 'success');
        } else {
            xb_aixhs_show_message('没有找到保存的Cookies！', 'error');
        }
    });

    // 删除本地Cookies
    $('.xb_aixhs_delete_cookies_button').on('click', function() {
        if (localStorage.getItem('xb_aixhs_saved_cookies')) {
            localStorage.removeItem('xb_aixhs_saved_cookies');
            xb_aixhs_show_message('本地Cookies已删除！', 'success');
        } else {
            xb_aixhs_show_message('没有找到保存的Cookies！', 'error');
        }
    });

    // 自定义消息提示函数
    function xb_aixhs_show_message(message, type) {
        // 移除已存在的消息
        $('.xb_aixhs_toast').remove();
        
        var toastClass = type === 'success' ? 'xb_aixhs_toast_success' : 'xb_aixhs_toast_error';
        var toast = $('<div class="xb_aixhs_toast ' + toastClass + '">' + message + '</div>');
        
        $('body').append(toast);
        
        // 显示动画
        setTimeout(function() {
            toast.addClass('xb_aixhs_toast_show');
        }, 100);
        
        // 3秒后自动隐藏
        setTimeout(function() {
            toast.removeClass('xb_aixhs_toast_show');
            setTimeout(function() {
                toast.remove();
            }, 300);
        }, 3000);
    }

    // 图片模态框功能
    function xb_aixhs_show_image_modal(src) {
        var modal = $('<div class="xb_aixhs_image_modal">' +
            '<div class="xb_aixhs_modal_content">' +
            '<span class="xb_aixhs_modal_close">&times;</span>' +
            '<img src="' + src + '" alt="预览图片" class="xb_aixhs_modal_image">' +
            '</div>' +
            '</div>');
        
        $('body').append(modal);
        
        // 显示模态框
        setTimeout(function() {
            modal.addClass('xb_aixhs_modal_show');
        }, 10);
        
        // 关闭模态框
        modal.on('click', function(e) {
            if (e.target === this || $(e.target).hasClass('xb_aixhs_modal_close')) {
                modal.removeClass('xb_aixhs_modal_show');
                setTimeout(function() {
                    modal.remove();
                }, 300);
            }
        });
    }

});