<?php
/*
Plugin Name: AI万能图像编辑
Description: 基于AI接口的万能图像编辑工具，支持多种图像处理风格和自定义提示词
Version: 1.0.2
Author: Summer
License: GPL2
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 插件激活时执行的操作
register_activation_hook(__FILE__, 'xb_aiimage_edit_activate');
function xb_aiimage_edit_activate() {
    xb_aiimage_edit_create_database();
    xb_aiimage_edit_create_front_page();
}

// 创建数据库表
function xb_aiimage_edit_create_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 使用次数表
    $usage_table = $wpdb->prefix . 'xb_aiimage_edit_usage';
    $usage_sql = "CREATE TABLE $usage_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL DEFAULT 0,
        device_id varchar(255) NOT NULL DEFAULT '',
        edit_date date NOT NULL,
        edit_count int(11) DEFAULT 0,
        custom_limit int(11) DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_device_date (user_id, device_id, edit_date)
    ) $charset_collate;";

    // 编辑记录表
    $records_table = $wpdb->prefix . 'xb_aiimage_edit_records';
    $records_sql = "CREATE TABLE $records_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL DEFAULT 0,
        device_id varchar(255) NOT NULL DEFAULT '',
        original_image varchar(500) NOT NULL,
        prompt_text text NOT NULL,
        negative_prompt text DEFAULT NULL,
        ai_model varchar(100) DEFAULT NULL,
        edit_status varchar(20) NOT NULL,
        edit_time datetime NOT NULL,
        task_id varchar(100) DEFAULT NULL,
        result_url varchar(500) DEFAULT NULL,
        error_message text DEFAULT NULL,
        ip_address varchar(45) NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // 预设风格表
    $styles_table = $wpdb->prefix . 'xb_aiimage_edit_styles';
    $styles_sql = "CREATE TABLE $styles_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        style_title varchar(100) NOT NULL,
        style_prompt text NOT NULL,
        style_image varchar(500) DEFAULT NULL,
        sort_order int(11) DEFAULT 0,
        created_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // 示例演示表
    $demos_table = $wpdb->prefix . 'xb_aiimage_edit_demos';
    $demos_sql = "CREATE TABLE $demos_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        demo_title varchar(100) NOT NULL,
        original_image varchar(500) NOT NULL,
        result_image varchar(500) NOT NULL,
        sort_order int(11) DEFAULT 0,
        created_time datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($usage_sql);
    dbDelta($records_sql);
    dbDelta($styles_sql);
    dbDelta($demos_sql);
}

// 获取设备指纹
function xb_aiimage_edit_get_device_id() {
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $accept_language = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
    
    $device_fingerprint = array(
        'user_agent' => $user_agent,
        'ip_address' => $ip_address,
        'accept_language' => $accept_language,
    );
    
    $device_id = md5(json_encode($device_fingerprint));
    return $device_id;
}

// 设置设备Cookie
function xb_aiimage_edit_set_device_cookie($device_id) {
    if (!headers_sent()) {
        setcookie('xb_aiimage_edit_device_id', $device_id, time() + (365 * 24 * 60 * 60), '/');
    }
}

// 获取最终设备ID
function xb_aiimage_edit_get_final_device_id() {
    $cookie_device_id = isset($_COOKIE['xb_aiimage_edit_device_id']) ? sanitize_text_field($_COOKIE['xb_aiimage_edit_device_id']) : '';
    $fingerprint_device_id = xb_aiimage_edit_get_device_id();
    
    if (!empty($cookie_device_id)) {
        xb_aiimage_edit_set_device_cookie($cookie_device_id);
        return $cookie_device_id;
    }
    
    xb_aiimage_edit_set_device_cookie($fingerprint_device_id);
    return $fingerprint_device_id;
}

// 创建前台页面
function xb_aiimage_edit_create_front_page() {
    $pages = get_posts(array(
        'post_type'   => 'page',
        'post_status' => 'publish',
        's'           => '[xb_aiimage_edit_form]',
        'numberposts' => 1,
    ));

    if (empty($pages)) {
        $page_data = array(
            'post_title'   => 'AI万能图像编辑',
            'post_content' => '[xb_aiimage_edit_form]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        );
        wp_insert_post($page_data);
    }
}

// 加载前端资源
add_action('wp_enqueue_scripts', 'xb_aiimage_edit_enqueue_scripts');
function xb_aiimage_edit_enqueue_scripts() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'xb_aiimage_edit_form')) {
        wp_enqueue_style('xb_aiimage_edit_styles', plugins_url('xb-aiimage-edit.css', __FILE__), array(), '1.0.2');
        wp_enqueue_script('xb_aiimage_edit_scripts', plugins_url('xb-aiimage-edit.js', __FILE__), array('jquery'), '1.0.2', true);
        wp_enqueue_script('img-comparison-slider', 'https://cdn.jsdelivr.net/npm/img-comparison-slider@8.0.6/dist/index.min.js', array(), '8.0.6', true);

        wp_localize_script('xb_aiimage_edit_scripts', 'xb_aiimage_edit_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => rest_url('xb_aiimage_edit/v1/process'),
            'nonce' => wp_create_nonce('wp_rest'),
            'login_url' => wp_login_url(get_permalink()),
            'is_logged_in' => is_user_logged_in() ? 1 : 0,
            'upload_url' => admin_url('admin-ajax.php'),
            'upload_nonce' => wp_create_nonce('xb_aiimage_edit_upload_nonce'),
            'check_result_url' => rest_url('xb_aiimage_edit/v1/check_result'),
        ));
    }
}

// 短代码
add_shortcode('xb_aiimage_edit_form', 'xb_aiimage_edit_form_shortcode');
function xb_aiimage_edit_form_shortcode() {
    $ad_content = get_option('xb_aiimage_edit_ad_content', '');
    $default_limit = absint(get_option('xb_aiimage_edit_default_limit', 10));
    $show_stats = get_option('xb_aiimage_edit_show_stats', 1);
    $show_model_select = get_option('xb_aiimage_edit_show_model_select', 0);
    $allowed_formats = array_map('strtolower', array_map('trim', explode(',', get_option('xb_aiimage_edit_allowed_formats', 'JPG,JPEG,PNG,BMP,TIFF,WEBP'))));
    $max_file_size = absint(get_option('xb_aiimage_edit_max_file_size', 10));
    $ai_models = array_map('trim', explode(',', get_option('xb_aiimage_edit_ai_models', 'qwen-image-edit')));

    $display_result = '';
    $display_message = '';
    $show_clear = false;

    // 处理游客消息和结果显示
    if (!is_user_logged_in()) {
        $guest_message = get_transient('xb_aiimage_edit_guest_message');
        if ($guest_message) {
            $display_message = $guest_message;
            $show_clear = true;
            delete_transient('xb_aiimage_edit_guest_message');
        }

        if (isset($_GET['task_id'])) {
            $task_id = sanitize_text_field($_GET['task_id']);
            $transient_result = get_transient('xb_aiimage_edit_result_' . $task_id);
            if ($transient_result) {
                if (isset($transient_result['message'])) {
                    $display_message = $transient_result['message'];
                } else {
                    $display_result = $transient_result['result'];
                }
                $show_clear = true;
                delete_transient('xb_aiimage_edit_result_' . $task_id);
            }
        }
    }

    ob_start();
    ?>
    <div class="xb_aiimage_edit_container">
        <div class="xb_aiimage_edit_header">
            <div class="xb_aiimage_edit_title">AI多功能图像编辑工具</div>
            <p class="xb_aiimage_edit_subtitle">智能图像处理，让创意无限可能</p>
        </div>

        <?php
        $user_id = is_user_logged_in() ? get_current_user_id() : 0;
        $today = current_time('Y-m-d');
        $device_id = xb_aiimage_edit_get_final_device_id();

        global $wpdb;
        $usage_table = $wpdb->prefix . 'xb_aiimage_edit_usage';

        // 获取使用次数统计
        $edit_count = 0;
        $user_limit = $default_limit;

        if ($user_id) {
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT SUM(edit_count) as total_count, MAX(custom_limit) as custom_limit 
                     FROM $usage_table 
                     WHERE user_id = %d AND edit_date = %s",
                    $user_id, $today
                )
            );
            $edit_count = $row && $row->total_count !== null ? absint($row->total_count) : 0;
            $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;
        } else {
            $edit_count = $user_limit;
        }

        $remaining = max(0, $user_limit - $edit_count);
        $stats_text = "今日剩余生成次数：{$remaining}/{$user_limit}";
        
        $show_upload_area = true;
        $disable_reason = '';

        if (!is_user_logged_in()) {
            $show_upload_area = false;
            $disable_reason = 'guest_disabled';
        } elseif (is_user_logged_in() && $edit_count >= $user_limit) {
            $show_upload_area = false;
            $disable_reason = 'user_limit_exceeded';
        }

        // 移除获取最后一次结果的逻辑，避免刷新后仍显示
        $last_result = null;
        ?>

        <div class="xb_aiimage_edit_content">
            <div class="xb_aiimage_edit_left_section">
                <div class="xb_aiimage_edit_config_section">
                    <div class="xb_aiimage_edit_section_title">原始图片配置区域</div>
                    
                    <?php if (!$show_upload_area): ?>
                        <div class="xb_aiimage_edit_message xb_aiimage_edit_message_info">
                            <?php if ($disable_reason === 'guest_disabled'): ?>
                                <div class="xb_aiimage_edit_message_icon">🔐</div>
                                <div class="xb_aiimage_edit_message_content">
                                    <div class="xb_aiimage_edit_ts_subtitle">请先登录</div>
                                    <p>登录后即可使用AI图像编辑功能</p>
                                    <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="xb_aiimage_edit_login_btn">立即登录</a>
                                </div>
                            <?php elseif ($disable_reason === 'user_limit_exceeded'): ?>
                                <div class="xb_aiimage_edit_message_icon">📅</div>
                                <div class="xb_aiimage_edit_message_content">
                                    <div class="xb_aiimage_edit_ts_subtitle">今日使用次数已用完</div>
                                    <p>您今日的编辑次数已达上限，请明天再来。</p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php 
                        // 移除最后一次处理结果的显示，避免刷新后仍然显示
                        ?>

                    <?php else: ?>
                        <form id="xb_aiimage_edit_form" method="post" enctype="multipart/form-data">
                            <div class="xb_aiimage_edit_prompt_section">
                                <div class="xb_aiimage_edit_input_group">
                                    <label for="xb_aiimage_edit_prompt">正向提示词</label>
                                    <textarea name="xb_aiimage_edit_prompt" id="xb_aiimage_edit_prompt" placeholder="描述您希望的图像效果..." rows="3"></textarea>
                                </div>
                                <div class="xb_aiimage_edit_input_group">
                                    <label for="xb_aiimage_edit_negative_prompt">反向提示词（可选）</label>
                                    <textarea name="xb_aiimage_edit_negative_prompt" id="xb_aiimage_edit_negative_prompt" placeholder="描述不希望出现的内容..." rows="2"></textarea>
                                </div>
                                <?php if ($show_model_select && count($ai_models) > 1): ?>
                                <div class="xb_aiimage_edit_input_group">
                                    <label for="xb_aiimage_edit_model">AI模型选择</label>
                                    <select name="xb_aiimage_edit_model" id="xb_aiimage_edit_model">
                                        <?php foreach ($ai_models as $model): ?>
                                            <option value="<?php echo esc_attr($model); ?>"><?php echo esc_html($model); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <?php endif; ?>
                            </div>

                            <div class="xb_aiimage_edit_upload_section">
                                <div class="xb_aiimage_edit_drop_area" id="xb_aiimage_edit_drop_area">
                                    <div class="xb_aiimage_edit_drop_icon">🖼️</div>
                                    <div>拖拽图片到此处或点击上传</div>
                                    <p class="xb_aiimage_edit_drop_text">支持 <?php echo implode(', ', $allowed_formats); ?> 格式，最大<?php echo $max_file_size; ?>MB</p>
                                    <input type="file" name="xb_aiimage_edit_file" id="xb_aiimage_edit_file" accept="<?php echo esc_attr('.' . implode(',.', $allowed_formats)); ?>" style="display:none;">
                                </div>
                            </div>

                            <div class="xb_aiimage_edit_preview_section" id="xb_aiimage_edit_preview_section" style="display:none;">
                                <div class="xb_aiimage_edit_preview_title">原始图片预览</div>
                                <div class="xb_aiimage_edit_image_preview">
                                    <img id="xb_aiimage_edit_preview_img" src="" alt="预览图片">
                                    <button type="button" class="xb_aiimage_edit_remove_image">✕</button>
                                </div>
                            </div>

                            <div class="xb_aiimage_edit_actions">
                                <button type="submit" class="xb_aiimage_edit_submit_button" id="xb_aiimage_edit_submit_button" disabled>
                                    <span class="xb_aiimage_edit_button_icon">🚀</span>
                                    开始处理
                                </button>
                                <button type="button" class="xb_aiimage_edit_clear_button" id="xb_aiimage_edit_clear_all">
                                    <span class="xb_aiimage_edit_button_icon">🗑️</span>
                                    清空全部
                                </button>
                                <button type="button" class="xb_aiimage_edit_regenerate_button" id="xb_aiimage_edit_regenerate" style="display:none;">
                                    <span class="xb_aiimage_edit_button_icon">🔄</span>
                                    重新生成
                                </button>
                                <button type="button" class="xb_aiimage_edit_download_button" id="xb_aiimage_edit_download" style="display:none;">
                                    <span class="xb_aiimage_edit_button_icon">📥</span>
                                    下载结果图片
                                </button>
                            </div>

                            <div class="xb_aiimage_edit_result_section" id="xb_aiimage_edit_result_section" style="display:none;">
                                <div class="xb_aiimage_edit_result_title">转换结果预览</div>
                                <div class="xb_aiimage_edit_result_preview">
                                    <img id="xb_aiimage_edit_result_img" src="" alt="结果图片">
                                </div>
                            </div>

                            <input type="hidden" name="xb_aiimage_edit_nonce" id="xb_aiimage_edit_nonce" value="<?php echo wp_create_nonce('xb_aiimage_edit_nonce'); ?>">
                            <input type="hidden" name="xb_aiimage_edit_file_url" id="xb_aiimage_edit_file_url" value="">
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <div class="xb_aiimage_edit_right_section">
                <div class="xb_aiimage_edit_styles_section">
                    <div class="xb_aiimage_edit_section_title">预设风格快速选择</div>
                    <div class="xb_aiimage_edit_styles_grid" id="xb_aiimage_edit_styles_grid">
                        <?php
                        $styles_table = $wpdb->prefix . 'xb_aiimage_edit_styles';
                        $styles = $wpdb->get_results("SELECT * FROM $styles_table ORDER BY sort_order ASC, id ASC");
                        
                        if ($styles):
                            foreach ($styles as $style):
                        ?>
                            <div class="xb_aiimage_edit_style_item" data-prompt="<?php echo esc_attr($style->style_prompt); ?>">
                                <?php if ($style->style_image): ?>
                                    <img src="<?php echo esc_url($style->style_image); ?>" alt="<?php echo esc_attr($style->style_title); ?>">
                                <?php else: ?>
                                    <div class="xb_aiimage_edit_style_placeholder">🎨</div>
                                <?php endif; ?>
                                <div class="xb_aiimage_edit_style_title"><?php echo esc_html($style->style_title); ?></div>
                            </div>
                        <?php 
                            endforeach;
                        else:
                        ?>
                            <div class="xb_aiimage_edit_no_styles">
                                <p>暂无预设风格，请联系管理员添加</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="xb_aiimage_edit_result_area">
            <div id="xb_aiimage_edit_result">
                <?php 
                if ($display_result) {
                    echo $display_result;
                }
                if ($display_message) {
                    echo '<div class="xb_aiimage_edit_message">' . esc_html($display_message) . '</div>';
                }
                ?>
            </div>
            <?php if ($show_stats && ($show_upload_area || $disable_reason === 'user_limit_exceeded')): ?>
                <div class="xb_aiimage_edit_usage_info">
                    <span class="xb_aiimage_edit_usage_icon">📊</span>
                    <?php echo esc_html($stats_text); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="xb_aiimage_edit_demo_section">
            <div class="xb_aiimage_edit_demo_title">AI示例效果</div>
            <div class="xb_aiimage_edit_demo_grid">
                <?php
                $demos_table = $wpdb->prefix . 'xb_aiimage_edit_demos';
                $demos = $wpdb->get_results("SELECT * FROM $demos_table ORDER BY sort_order ASC, id ASC LIMIT 6");
                
                if ($demos):
                    foreach ($demos as $demo):
                ?>
                    <div class="xb_aiimage_edit_demo_item">
                        <div class="xb_aiimage_edit_demo_header"><?php echo esc_html($demo->demo_title); ?></div>
                        <div class="xb_aiimage_edit_demo_comparison">
                            <img-comparison-slider class="xb-aiimage-comparison">
                                <img slot="first" src="<?php echo esc_url($demo->original_image); ?>" alt="原图" class="xb-aiimage-img" />
                                <img slot="second" src="<?php echo esc_url($demo->result_image); ?>" alt="效果图" class="xb-aiimage-img" />
                            </img-comparison-slider>
                            <div class="xb-aiimage-label-first">原图</div>
                            <div class="xb-aiimage-label-second">效果图</div>
                        </div>
                    </div>
                <?php 
                    endforeach;
                else:
                ?>
                    <div class="xb_aiimage_edit_no_demos">
                        <p>暂无示例演示，敬请期待</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if (!empty($ad_content)): ?>
            <div class="xb_aiimage_edit_ad_content"><?php echo wp_kses_post($ad_content); ?></div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

// 注册 REST API 端点
add_action('rest_api_init', 'xb_aiimage_edit_register_rest_routes');
function xb_aiimage_edit_register_rest_routes() {
    register_rest_route('xb_aiimage_edit/v1', '/process', array(
        'methods' => 'POST',
        'callback' => 'xb_aiimage_edit_handle_process',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
        'args' => array(
            'image_url' => array('required' => true, 'validate_callback' => function ($param) {
                return filter_var($param, FILTER_VALIDATE_URL);
            }),
            'prompt' => array('required' => true, 'sanitize_callback' => 'sanitize_textarea_field'),
            'negative_prompt' => array('required' => false, 'sanitize_callback' => 'sanitize_textarea_field'),
            'ai_model' => array('required' => false, 'sanitize_callback' => 'sanitize_text_field'),
        )
    ));

    register_rest_route('xb_aiimage_edit/v1', '/check_result', array(
        'methods' => 'POST',
        'callback' => 'xb_aiimage_edit_check_result',
        'permission_callback' => '__return_true',
        'args' => array(
            'task_id' => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
        )
    ));
}

// 添加 CORS 头以支持图片下载
add_action('rest_api_init', 'xb_aiimage_edit_add_cors_headers');
function xb_aiimage_edit_add_cors_headers() {
    add_filter('rest_pre_serve_request', function ($value, $result, $request, $server) {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-WP-Nonce');
        return $value;
    }, 10, 4);
}

// 处理图像编辑请求
function xb_aiimage_edit_handle_process(WP_REST_Request $request) {
    $image_url = $request->get_param('image_url');
    $prompt = $request->get_param('prompt');
    $negative_prompt = $request->get_param('negative_prompt') ?: '';
    $ai_model = $request->get_param('ai_model') ?: '';
    $user_id = get_current_user_id();
    $today = current_time('Y-m-d');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $device_id = xb_aiimage_edit_get_final_device_id();

    // 检查违规词
    $banned_words = get_option('xb_aiimage_edit_banned_words', '');
    if (!empty($banned_words)) {
        $banned_list = array_map('trim', explode(',', $banned_words));
        foreach ($banned_list as $word) {
            if (!empty($word) && (stripos($prompt, $word) !== false || stripos($negative_prompt, $word) !== false)) {
                return new WP_REST_Response(array('message' => '输入内容包含违规词，请重新输入'), 400);
            }
        }
    }

    // 检查使用次数
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aiimage_edit_usage';
    $default_limit = absint(get_option('xb_aiimage_edit_default_limit', 10));
    
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT SUM(edit_count) as total_count, MAX(custom_limit) as custom_limit 
             FROM $usage_table 
             WHERE user_id = %d AND edit_date = %s",
            $user_id, $today
        )
    );
    
    $edit_count = $row && $row->total_count !== null ? absint($row->total_count) : 0;
    $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;

    if ($edit_count >= $user_limit) {
        return new WP_REST_Response(array('message' => '今日使用次数已经用完，请明天再来。'), 403);
    }

    $result = xb_aiimage_edit_call_api($image_url, $prompt, $negative_prompt, $ai_model, $user_id, $ip_address, $device_id, $today);
    
    $result['remaining'] = max(0, $user_limit - ($edit_count + 1));
    $result['limit'] = $user_limit;
    
    return new WP_REST_Response($result, 200);
}

// 新增代理下载端点
add_action('rest_api_init', function () {
    register_rest_route('xb_aiimage_edit/v1', '/download', array(
        'methods' => 'GET',
        'callback' => 'xb_aiimage_edit_handle_download',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
        'args' => array(
            'url' => array('required' => true, 'validate_callback' => function ($param) {
                return filter_var($param, FILTER_VALIDATE_URL);
            }),
        )
    ));
});

function xb_aiimage_edit_handle_download(WP_REST_Request $request) {
    $url = $request->get_param('url');
    
    $response = wp_remote_get($url, array(
        'timeout' => 30,
        'sslverify' => false,
    ));

    if (is_wp_error($response)) {
        return new WP_REST_Response(array('message' => '图片下载失败：' . $response->get_error_message()), 400);
    }

    $body = wp_remote_retrieve_body($response);
    $content_type = wp_remote_retrieve_header($response, 'content-type');
    $filename = 'ai_edited_image_' . time() . '.jpg';

    header('Content-Type: ' . $content_type);
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo $body;
    exit;
}

// 调用AI接口
function xb_aiimage_edit_call_api($image_url, $prompt, $negative_prompt, $ai_model, $user_id, $ip_address, $device_id, $today) {
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aiimage_edit_records';

    $api_url = get_option('xb_aiimage_edit_api_url', 'https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation');
    $api_key = get_option('xb_aiimage_edit_api_key');
    $models = array_map('trim', explode(',', get_option('xb_aiimage_edit_ai_models', 'qwen-image-edit')));
    $selected_model = !empty($ai_model) ? $ai_model : $models[0];

    // 生成唯一任务ID
    $task_id = md5($image_url . $prompt . microtime(true) . wp_rand());

    $body = array(
        'model' => $selected_model,
        'input' => array(
            'messages' => array(
                array(
                    'role' => 'user',
                    'content' => array(
                        array('image' => $image_url),
                        array('text' => $prompt)
                    )
                )
            )
        ),
        'parameters' => array(
            'negative_prompt' => $negative_prompt,
            'watermark' => false
        )
    );

    $args = array(
        'method' => 'POST',
        'timeout' => 200, // 增加超时时间至200秒
        'sslverify' => false,
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key,
        ),
        'body' => json_encode($body),
    );

    $insert_data = array(
        'user_id' => $user_id,
        'device_id' => $device_id,
        'original_image' => $image_url,
        'prompt_text' => $prompt,
        'negative_prompt' => $negative_prompt,
        'ai_model' => $selected_model,
        'edit_status' => 'pending',
        'edit_time' => current_time('mysql'),
        'task_id' => $task_id,
        'ip_address' => $ip_address,
    );

    // 启用 WordPress 调试日志
    if (!defined('WP_DEBUG') || !WP_DEBUG) {
        define('WP_DEBUG', true);
        define('WP_DEBUG_LOG', true);
        define('WP_DEBUG_DISPLAY', false);
    }

    // 记录请求数据到 debug.log
    $log_data = array(
        'timestamp' => current_time('mysql'),
        'task_id' => $task_id,
        'api_url' => $api_url,
        'request_body' => $body,
        'headers' => $args['headers'],
    );
    error_log("AI Image Edit API Request: " . json_encode($log_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n", 3, WP_CONTENT_DIR . '/debug.log');

    // 检查网络连接
    $ping_response = wp_remote_get($api_url, array('timeout' => 5, 'method' => 'HEAD', 'sslverify' => false));
    if (is_wp_error($ping_response)) {
        $insert_data['edit_status'] = 'failed';
        $insert_data['error_message'] = '网络连接失败: ' . $ping_response->get_error_message();
        $wpdb->insert($records_table, $insert_data);
        error_log("AI Image Edit API Ping Error: " . $ping_response->get_error_message() . "\n", 3, WP_CONTENT_DIR . '/debug.log');
        return array(
            'message' => '网络连接失败，请联系客服',
            'task_id' => $task_id,
        );
    }

    // 重试机制
    $max_retries = 2;
    $retry_count = 0;
    $response = null;

    while ($retry_count <= $max_retries) {
        $response = wp_remote_request($api_url, $args);
        
        // 记录响应数据
        $response_log = array(
            'timestamp' => current_time('mysql'),
            'task_id' => $task_id,
            'retry_count' => $retry_count,
            'response_code' => is_wp_error($response) ? 'WP_Error' : wp_remote_retrieve_response_code($response),
            'response_body' => is_wp_error($response) ? $response->get_error_message() : wp_remote_retrieve_body($response),
        );
        error_log("AI Image Edit API Response: " . json_encode($response_log, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n", 3, WP_CONTENT_DIR . '/debug.log');

        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) < 400) {
            break; // 成功响应，退出重试
        }

        $retry_count++;
        if ($retry_count <= $max_retries) {
            error_log("AI Image Edit API Retry: Attempt " . ($retry_count + 1) . " for task_id $task_id\n", 3, WP_CONTENT_DIR . '/debug.log');
            sleep(2); // 等待2秒后重试
        }
    }

    if (is_wp_error($response)) {
        $insert_data['edit_status'] = 'failed';
        $insert_data['error_message'] = 'API 请求失败: ' . $response->get_error_message() . ' (重试 $max_retries 次)';
        $wpdb->insert($records_table, $insert_data);
        return array(
            'message' => '暂时无法处理，请联系客服',
            'task_id' => $task_id,
        );
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if ($status_code >= 400 || !isset($data['output'])) {
        $error_message = isset($data['message']) ? $data['message'] : 'API 请求错误：HTTP ' . $status_code . ' (重试 $max_retries 次)';
        $insert_data['edit_status'] = 'failed';
        $insert_data['error_message'] = $error_message;
        $wpdb->insert($records_table, $insert_data);
        return array(
            'message' => '暂时无法处理，请联系客服',
            'task_id' => $task_id,
        );
    }

    // 处理成功响应
    if (isset($data['output']['choices'][0]['message']['content'][0]['image'])) {
        $result_url = $data['output']['choices'][0]['message']['content'][0]['image'];
        $insert_data['edit_status'] = 'success';
        $insert_data['result_url'] = $result_url;
        
        xb_aiimage_edit_update_usage($user_id, $device_id, $today);
        
        $wpdb->insert($records_table, $insert_data);
        
        return array(
            'status' => 'success',
            'result_url' => $result_url,
            'task_id' => $task_id,
        );
    } else {
        $insert_data['edit_status'] = 'failed';
        $insert_data['error_message'] = '接口返回格式错误';
        $wpdb->insert($records_table, $insert_data);
        return array(
            'message' => '暂时无法处理，请联系客服',
            'task_id' => $task_id,
        );
    }
}

// 更新使用次数
function xb_aiimage_edit_update_usage($user_id, $device_id, $today) {
    global $wpdb;
    $usage_table = $wpdb->prefix . 'xb_aiimage_edit_usage';
    $default_limit = absint(get_option('xb_aiimage_edit_default_limit', 10));

    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT edit_count, custom_limit 
             FROM $usage_table 
             WHERE user_id = %d AND device_id = %s AND edit_date = %s",
            $user_id, $device_id, $today
        )
    );

    if ($row) {
        $wpdb->update(
            $usage_table,
            array('edit_count' => $row->edit_count + 1),
            array('user_id' => $user_id, 'device_id' => $device_id, 'edit_date' => $today)
        );
    } else {
        $wpdb->insert(
            $usage_table,
            array(
                'user_id' => $user_id,
                'device_id' => $device_id,
                'edit_date' => $today,
                'edit_count' => 1,
                'custom_limit' => null,
            )
        );
    }
}

// 检查结果
function xb_aiimage_edit_check_result(WP_REST_Request $request) {
    $task_id = $request->get_param('task_id');
    
    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aiimage_edit_records';
    $record = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $records_table WHERE task_id = %s", $task_id)
    );

    if (!$record) {
        return new WP_REST_Response(array('message' => '任务不存在'), 404);
    }

    if ($record->edit_status === 'success' && $record->result_url) {
        $user_id = $record->user_id;
        $today = current_time('Y-m-d');
        $usage_table = $wpdb->prefix . 'xb_aiimage_edit_usage';
        $default_limit = absint(get_option('xb_aiimage_edit_default_limit', 10));
        
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT SUM(edit_count) as total_count, MAX(custom_limit) as custom_limit 
                 FROM $usage_table 
                 WHERE user_id = %d AND edit_date = %s",
                $user_id, $today
            )
        );
        
        $edit_count = $row && $row->total_count !== null ? absint($row->total_count) : 0;
        $user_limit = ($row && $row->custom_limit !== null) ? absint($row->custom_limit) : $default_limit;
        $remaining = max(0, $user_limit - $edit_count);

        return new WP_REST_Response(array(
            'status' => 'success',
            'result_url' => $record->result_url,
            'remaining' => $remaining,
            'limit' => $user_limit
        ), 200);
    } elseif ($record->edit_status === 'failed') {
        return new WP_REST_Response(array('message' => '暂时无法处理，请联系客服'), 400);
    } else {
        return new WP_REST_Response(array('status' => 'pending'), 202);
    }
}

// AJAX 上传功能
add_action('wp_ajax_xb_aiimage_edit_upload', 'xb_aiimage_edit_handle_ajax_upload');
add_action('wp_ajax_nopriv_xb_aiimage_edit_upload', 'xb_aiimage_edit_handle_ajax_upload');
function xb_aiimage_edit_handle_ajax_upload() {
    check_ajax_referer('xb_aiimage_edit_upload_nonce', '_wpnonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => '请先登录后使用'));
    }

    if (!isset($_FILES['file']) || empty($_FILES['file']['name'])) {
        wp_send_json_error(array('message' => '未选择文件，请选择文件后重试！'));
    }

    $file = $_FILES['file'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error(array('message' => '文件上传失败，请重试！'));
    }

    $max_file_size = absint(get_option('xb_aiimage_edit_max_file_size', 10)) * 1024 * 1024;
    $allowed_formats = array_map('strtolower', array_map('trim', explode(',', get_option('xb_aiimage_edit_allowed_formats', 'JPG,JPEG,PNG,BMP,TIFF,WEBP'))));
    $file_ext = strtolower(pathinfo($file['name'] ?? '', PATHINFO_EXTENSION));
    
    if (!in_array($file_ext, $allowed_formats)) {
        wp_send_json_error(array('message' => '不支持的文件格式！支持格式：' . implode(', ', $allowed_formats)));
    }

    if ($file['size'] > $max_file_size) {
        wp_send_json_error(array('message' => '文件大小超出限制！'));
    }

    $file_type = wp_check_filetype_and_ext($file['tmp_name'] ?? '', $file['name']);
    if (!$file_type['ext'] || !in_array(strtolower($file_type['ext']), $allowed_formats)) {
        wp_send_json_error(array('message' => '文件类型验证失败，请上传真实的图片文件！'));
    }

    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attachment_id = media_handle_upload('file', 0);
    if (is_wp_error($attachment_id)) {
        wp_send_json_error(array('message' => '文件上传失败：' . $attachment_id->get_error_message()));
    }

    $file_url = wp_get_attachment_url($attachment_id);
    wp_send_json_success(array('url' => $file_url));
}

// 添加管理菜单
add_action('admin_menu', 'xb_aiimage_edit_admin_menu');
function xb_aiimage_edit_admin_menu() {
    add_menu_page(
        'AI图像编辑设置',
        'AI图像编辑',
        'manage_options',
        'xb_aiimage_edit_settings',
        'xb_aiimage_edit_settings_page',
        'dashicons-format-image',
        80
    );
    add_submenu_page(
        'xb_aiimage_edit_settings',
        '编辑记录',
        '编辑记录',
        'manage_options',
        'xb_aiimage_edit_records',
        'xb_aiimage_edit_records_page'
    );
    add_submenu_page(
        'xb_aiimage_edit_settings',
        '预设风格管理',
        '预设风格管理',
        'manage_options',
        'xb_aiimage_edit_styles',
        'xb_aiimage_edit_styles_page'
    );
    add_submenu_page(
        'xb_aiimage_edit_settings',
        '示例演示管理',
        '示例演示管理',
        'manage_options',
        'xb_aiimage_edit_demos',
        'xb_aiimage_edit_demos_page'
    );
}

// 插件设置页面
function xb_aiimage_edit_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    if (isset($_POST['xb_aiimage_edit_save_settings'])) {
        check_admin_referer('xb_aiimage_edit_settings_nonce');
        update_option('xb_aiimage_edit_api_url', sanitize_text_field($_POST['xb_aiimage_edit_api_url']));
        update_option('xb_aiimage_edit_api_key', sanitize_text_field($_POST['xb_aiimage_edit_api_key']));
        update_option('xb_aiimage_edit_ai_models', sanitize_text_field($_POST['xb_aiimage_edit_ai_models']));
        $new_limit = absint($_POST['xb_aiimage_edit_default_limit']);
        if ($new_limit > 0) {
            update_option('xb_aiimage_edit_default_limit', $new_limit);
        }
        $new_max_file_size = absint($_POST['xb_aiimage_edit_max_file_size']);
        if ($new_max_file_size > 0) {
            update_option('xb_aiimage_edit_max_file_size', $new_max_file_size);
        }
        update_option('xb_aiimage_edit_show_stats', isset($_POST['xb_aiimage_edit_show_stats']) ? 1 : 0);
        update_option('xb_aiimage_edit_show_model_select', isset($_POST['xb_aiimage_edit_show_model_select']) ? 1 : 0);
        update_option('xb_aiimage_edit_allowed_formats', sanitize_text_field($_POST['xb_aiimage_edit_allowed_formats']));
        update_option('xb_aiimage_edit_banned_words', sanitize_textarea_field($_POST['xb_aiimage_edit_banned_words']));
        $allowed_html = array(
            'a' => array('href' => array(), 'title' => array(), 'target' => array()),
            'img' => array('src' => array(), 'alt' => array(), 'width' => array(), 'height' => array()),
            'p' => array(),
            'div' => array('class' => array(), 'style' => array()),
            'span' => array('class' => array(), 'style' => array()),
            'strong' => array(),
            'em' => array(),
            'br' => array()
        );
        update_option('xb_aiimage_edit_ad_content', wp_kses($_POST['xb_aiimage_edit_ad_content'], $allowed_html));
        echo '<div class="updated xb_aiimage_edit_auto_hide_message"><p>设置已保存！</p></div>';
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aiimage_edit_records';
    $stats = array(
        'total_edits' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table"),
        'success_edits' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE edit_status = 'success'"),
        'failed_edits' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE edit_status = 'failed'"),
        'today_edits' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE DATE(edit_time) = %s", current_time('Y-m-d')))
    );

    ?>
    <div class="wrap">
        <h1>AI图像编辑设置</h1>
        <form method="post">
            <?php wp_nonce_field('xb_aiimage_edit_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="xb_aiimage_edit_api_url">API 接口地址</label></th>
                    <td><input type="text" name="xb_aiimage_edit_api_url" id="xb_aiimage_edit_api_url" value="<?php echo esc_attr(get_option('xb_aiimage_edit_api_url', 'https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_aiimage_edit_api_key">API 密钥</label></th>
                    <td><input type="text" name="xb_aiimage_edit_api_key" id="xb_aiimage_edit_api_key" value="<?php echo esc_attr(get_option('xb_aiimage_edit_api_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="xb_aiimage_edit_ai_models">AI模型</label></th>
                    <td>
                        <input type="text" name="xb_aiimage_edit_ai_models" id="xb_aiimage_edit_ai_models" value="<?php echo esc_attr(get_option('xb_aiimage_edit_ai_models', 'qwen-image-edit')); ?>" class="regular-text">
                        <p class="description">多个模型用英文逗号分隔，例如：qwen-image-edit,qwen2-image-edit</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aiimage_edit_default_limit">每日编辑次数</label></th>
                    <td><input type="number" name="xb_aiimage_edit_default_limit" id="xb_aiimage_edit_default_limit" value="<?php echo esc_attr(get_option('xb_aiimage_edit_default_limit', 10)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_aiimage_edit_max_file_size">最大文件大小(MB)</label></th>
                    <td><input type="number" name="xb_aiimage_edit_max_file_size" id="xb_aiimage_edit_max_file_size" value="<?php echo esc_attr(get_option('xb_aiimage_edit_max_file_size', 10)); ?>" min="1"></td>
                </tr>
                <tr>
                    <th><label for="xb_aiimage_edit_allowed_formats">支持的图片格式</label></th>
                    <td>
                        <input type="text" name="xb_aiimage_edit_allowed_formats" id="xb_aiimage_edit_allowed_formats" value="<?php echo esc_attr(get_option('xb_aiimage_edit_allowed_formats', 'JPG,JPEG,PNG,BMP,TIFF,WEBP')); ?>" class="regular-text">
                        <p class="description">多个格式用英文逗号分隔，例如：JPG,JPEG,PNG,BMP,TIFF,WEBP</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aiimage_edit_show_stats">显示统计</label></th>
                    <td><input type="checkbox" name="xb_aiimage_edit_show_stats" id="xb_aiimage_edit_show_stats" <?php checked(get_option('xb_aiimage_edit_show_stats', 1), 1); ?> value="1"> 显示剩余编辑次数</td>
                </tr>
                <tr>
                    <th><label for="xb_aiimage_edit_show_model_select">前台模型选择</label></th>
                    <td><input type="checkbox" name="xb_aiimage_edit_show_model_select" id="xb_aiimage_edit_show_model_select" <?php checked(get_option('xb_aiimage_edit_show_model_select', 0), 1); ?> value="1"> 启用前台模型选择功能</td>
                </tr>
                <tr>
                    <th><label for="xb_aiimage_edit_banned_words">违规词设置</label></th>
                    <td>
                        <textarea name="xb_aiimage_edit_banned_words" id="xb_aiimage_edit_banned_words" rows="3" class="large-text"><?php echo esc_textarea(get_option('xb_aiimage_edit_banned_words')); ?></textarea>
                        <p class="description">多个违规词用英文逗号分隔</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="xb_aiimage_edit_ad_content">公告内容</label></th>
                    <td>
                        <textarea name="xb_aiimage_edit_ad_content" id="xb_aiimage_edit_ad_content" rows="5" class="large-text"><?php echo esc_textarea(get_option('xb_aiimage_edit_ad_content')); ?></textarea>
                        <p class="description">支持 HTML 格式。</p>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="xb_aiimage_edit_save_settings" class="button-primary" value="保存设置"></p>
        </form>
        <div class="xb_aiimage_edit_stats">
            <p>总编辑次数：<?php echo esc_html($stats['total_edits'] ?: 0); ?></p>
            <p>成功编辑次数：<?php echo esc_html($stats['success_edits'] ?: 0); ?></p>
            <p>失败编辑次数：<?php echo esc_html($stats['failed_edits'] ?: 0); ?></p>
            <p>今日编辑次数：<?php echo esc_html($stats['today_edits'] ?: 0); ?></p>
        </div>
    </div>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aiimage_edit_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}

// 编辑记录页面
// 修复后的编辑记录页面函数
function xb_aiimage_edit_records_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $records_table = $wpdb->prefix . 'xb_aiimage_edit_records';
    $usage_table = $wpdb->prefix . 'xb_aiimage_edit_usage';
    $user_id = isset($_POST['xb_aiimage_edit_user_id']) ? absint($_POST['xb_aiimage_edit_user_id']) : '';
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 20;

    if (isset($_POST['xb_aiimage_edit_delete_all_global'])) {
        check_admin_referer('xb_aiimage_edit_delete_all_global_nonce');
        $wpdb->query("TRUNCATE TABLE $records_table");
        echo '<div class="updated xb_aiimage_edit_auto_hide_message"><p>所有记录已删除！</p></div>';
    }

    if (isset($_POST['xb_aiimage_edit_reset_all_usage'])) {
        check_admin_referer('xb_aiimage_edit_reset_all_usage_nonce');
        $wpdb->query("TRUNCATE TABLE $usage_table");
        echo '<div class="updated xb_aiimage_edit_auto_hide_message"><p>所有用户使用次数已重置！</p></div>';
    }

    if (isset($_POST['xb_aiimage_edit_delete_record']) && isset($_POST['record_id'])) {
        check_admin_referer('xb_aiimage_edit_delete_record_nonce');
        $wpdb->delete($records_table, array('id' => absint($_POST['record_id'])), array('%d'));
        echo '<div class="updated xb_aiimage_edit_auto_hide_message"><p>记录已删除！</p></div>';
    }

    if (isset($_POST['xb_aiimage_edit_delete_all_records']) && $user_id) {
        check_admin_referer('xb_aiimage_edit_delete_all_records_nonce');
        $wpdb->delete($records_table, array('user_id' => $user_id), array('%d'));
        echo '<div class="updated xb_aiimage_edit_auto_hide_message"><p>用户记录已删除！</p></div>';
    }

    if (isset($_POST['xb_aiimage_edit_reset_user_usage']) && $user_id) {
        check_admin_referer('xb_aiimage_edit_reset_user_usage_nonce');
        $wpdb->delete($usage_table, array('user_id' => $user_id), array('%d'));
        echo '<div class="updated xb_aiimage_edit_auto_hide_message"><p>用户使用次数已重置！</p></div>';
    }

    if (isset($_POST['xb_aiimage_edit_save_user_limit']) && $user_id) {
        check_admin_referer('xb_aiimage_edit_user_limit_nonce');
        $custom_limit = isset($_POST['xb_aiimage_edit_custom_limit']) ? absint($_POST['xb_aiimage_edit_custom_limit']) : null;
        
        $existing = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id FROM $usage_table WHERE user_id = %d AND edit_date = %s LIMIT 1",
                $user_id, current_time('Y-m-d')
            )
        );
        
        if ($existing) {
            $wpdb->update(
                $usage_table,
                array('custom_limit' => $custom_limit === 0 ? null : $custom_limit),
                array('user_id' => $user_id, 'edit_date' => current_time('Y-m-d')),
                array('%d'),
                array('%d', '%s')
            );
        } else {
            $wpdb->insert(
                $usage_table,
                array(
                    'user_id' => $user_id,
                    'device_id' => '',
                    'edit_date' => current_time('Y-m-d'),
                    'edit_count' => 0,
                    'custom_limit' => $custom_limit === 0 ? null : $custom_limit,
                )
            );
        }
        echo '<div class="updated xb_aiimage_edit_auto_hide_message"><p>用户编辑限制已更新！</p></div>';
    }

    $default_limit = absint(get_option('xb_aiimage_edit_default_limit', 10));
    $user_limit = $default_limit;
    if ($user_id) {
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT MAX(custom_limit) as custom_limit 
                 FROM $usage_table 
                 WHERE user_id = %d AND edit_date = %s",
                $user_id, current_time('Y-m-d')
            )
        );
        if ($row && $row->custom_limit !== null) {
            $user_limit = absint($row->custom_limit);
        }
    }

    // 修复统计查询
    if ($user_id) {
        $stats = array(
            'total_edits' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE user_id = %d", $user_id)),
            'success_edits' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE user_id = %d AND edit_status = 'success'", $user_id)),
            'failed_edits' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE user_id = %d AND edit_status = 'failed'", $user_id)),
            'today_edits' => $wpdb->get_var($wpdb->prepare("SELECT SUM(edit_count) FROM $usage_table WHERE user_id = %d AND edit_date = %s", $user_id, current_time('Y-m-d')))
        );
    } else {
        $stats = array(
            'total_edits' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table"),
            'success_edits' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE edit_status = 'success'"),
            'failed_edits' => $wpdb->get_var("SELECT COUNT(*) FROM $records_table WHERE edit_status = 'failed'"),
            'today_edits' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE DATE(edit_time) = %s", current_time('Y-m-d')))
        );
    }

    $offset = ($paged - 1) * $per_page;
    if ($user_id) {
        $records = $wpdb->get_results($wpdb->prepare("SELECT * FROM $records_table WHERE user_id = %d ORDER BY edit_time DESC LIMIT %d, %d", $user_id, $offset, $per_page));
        $total_records = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $records_table WHERE user_id = %d", $user_id));
    } else {
        $records = $wpdb->get_results($wpdb->prepare("SELECT * FROM $records_table ORDER BY edit_time DESC LIMIT %d, %d", $offset, $per_page));
        $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $records_table");
    }
    
    $total_pages = ceil($total_records / $per_page);

    $user_info = $user_id ? get_userdata($user_id) : null;
    $user_display = $user_id ? ($user_info ? $user_info->user_login : '未知用户') : '所有用户';
    ?>
    <div class="wrap">
        <h1>编辑记录管理</h1>
        <div style="margin-bottom: 20px;">
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('xb_aiimage_edit_delete_all_global_nonce'); ?>
                <input type="submit" name="xb_aiimage_edit_delete_all_global" class="button-secondary" value="一键删除所有记录" onclick="return confirm('确定删除所有记录吗？这不会重置用户使用次数。');">
            </form>
            <form method="post" style="display:inline; margin-left: 10px;">
                <?php wp_nonce_field('xb_aiimage_edit_reset_all_usage_nonce'); ?>
                <input type="submit" name="xb_aiimage_edit_reset_all_usage" class="button-secondary" value="一键重置所有使用次数" onclick="return confirm('确定重置所有用户的使用次数吗？');">
            </form>
        </div>
        <form method="post">
            <p>
                <label for="xb_aiimage_edit_user_id">用户 ID（留空显示所有记录）：</label>
                <input type="number" name="xb_aiimage_edit_user_id" id="xb_aiimage_edit_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" class="button" value="查询">
            </p>
        </form>

        <?php if ($user_id): ?>
            <h2>用户：<?php echo esc_html($user_display); ?> (ID: <?php echo $user_id; ?>)</h2>
            <p>每日编辑次数：<?php echo esc_html($user_limit); ?> 次</p>
            <form method="post">
                <?php wp_nonce_field('xb_aiimage_edit_user_limit_nonce'); ?>
                <p>
                    <label for="xb_aiimage_edit_custom_limit">自定义每日编辑次数（0 表示默认值）：</label>
                    <input type="number" name="xb_aiimage_edit_custom_limit" id="xb_aiimage_edit_custom_limit" min="0">
                    <input type="hidden" name="xb_aiimage_edit_user_id" value="<?php echo esc_attr($user_id); ?>">
                    <input type="submit" name="xb_aiimage_edit_save_user_limit" class="button-primary" value="保存">
                </p>
            </form>
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('xb_aiimage_edit_delete_all_records_nonce'); ?>
                <input type="hidden" name="xb_aiimage_edit_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" name="xb_aiimage_edit_delete_all_records" class="button-secondary" value="删除当前用户记录" onclick="return confirm('确定删除当前用户所有记录吗？这不会重置使用次数。');">
            </form>
            <form method="post" style="display:inline; margin-left: 10px;">
                <?php wp_nonce_field('xb_aiimage_edit_reset_user_usage_nonce'); ?>
                <input type="hidden" name="xb_aiimage_edit_user_id" value="<?php echo esc_attr($user_id); ?>">
                <input type="submit" name="xb_aiimage_edit_reset_user_usage" class="button-secondary" value="重置使用次数" onclick="return confirm('确定重置当前用户的使用次数吗？');">
            </form>
        <?php endif; ?>

        <div class="xb_aiimage_edit_stats">
            <p>总编辑次数：<?php echo esc_html($stats['total_edits'] ?: 0); ?></p>
            <p>成功编辑次数：<?php echo esc_html($stats['success_edits'] ?: 0); ?></p>
            <p>失败编辑次数：<?php echo esc_html($stats['failed_edits'] ?: 0); ?></p>
            <p>今日编辑次数：<?php echo esc_html($stats['today_edits'] ?: 0); ?></p>
        </div>

        <table class="widefat">
            <thead>
                <tr>
                    <th>用户 ID</th>
                    <th>编辑时间</th>
                    <th>原始图片</th>
                    <th>提示词</th>
                    <th>AI模型</th>
                    <th>状态</th>
                    <th>结果图片</th>
                    <th>错误信息</th>
                    <th>IP 地址</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="10">暂无编辑记录。</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td><?php echo esc_html($record->user_id); ?></td>
                            <td><?php echo esc_html($record->edit_time); ?></td>
                            <td>
                                <?php if ($record->original_image): ?>
                                    <img src="<?php echo esc_url($record->original_image); ?>" style="width:50px;height:50px;object-fit:cover;" alt="原图">
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html(mb_substr($record->prompt_text, 0, 50) . (mb_strlen($record->prompt_text) > 50 ? '...' : '')); ?></td>
                            <td><?php echo esc_html($record->ai_model ?: '-'); ?></td>
                            <td><?php echo esc_html($record->edit_status); ?></td>
                            <td>
                                <?php if ($record->result_url): ?>
                                    <img src="<?php echo esc_url($record->result_url); ?>" style="width:50px;height:50px;object-fit:cover;" alt="结果图">
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($record->error_message ?: '-'); ?></td>
                            <td><?php echo esc_html($record->ip_address); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_aiimage_edit_delete_record_nonce'); ?>
                                    <input type="hidden" name="record_id" value="<?php echo esc_attr($record->id); ?>">
                                    <input type="submit" name="xb_aiimage_edit_delete_record" class="button-link" value="删除" onclick="return confirm('确定删除此记录？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => __('«'),
                'next_text' => __('»'),
                'total' => $total_pages,
                'current' => $paged
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aiimage_edit_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}

// 预设风格管理页面
function xb_aiimage_edit_styles_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $styles_table = $wpdb->prefix . 'xb_aiimage_edit_styles';

    if (isset($_POST['xb_aiimage_edit_add_style'])) {
        check_admin_referer('xb_aiimage_edit_style_nonce');
        $style_title = sanitize_text_field($_POST['style_title']);
        $style_prompt = sanitize_textarea_field($_POST['style_prompt']);
        $style_image = sanitize_url($_POST['style_image']);
        $sort_order = absint($_POST['sort_order']);

        if (!empty($style_title) && !empty($style_prompt)) {
            $wpdb->insert(
                $styles_table,
                array(
                    'style_title' => $style_title,
                    'style_prompt' => $style_prompt,
                    'style_image' => $style_image,
                    'sort_order' => $sort_order,
                    'created_time' => current_time('mysql'),
                )
            );
            echo '<div class="updated xb_aiimage_edit_auto_hide_message"><p>风格已添加！</p></div>';
        }
    }

    if (isset($_POST['xb_aiimage_edit_update_style'])) {
        check_admin_referer('xb_aiimage_edit_style_nonce');
        $style_id = absint($_POST['style_id']);
        $style_title = sanitize_text_field($_POST['style_title']);
        $style_prompt = sanitize_textarea_field($_POST['style_prompt']);
        $style_image = sanitize_url($_POST['style_image']);
        $sort_order = absint($_POST['sort_order']);

        if (!empty($style_title) && !empty($style_prompt)) {
            $wpdb->update(
                $styles_table,
                array(
                    'style_title' => $style_title,
                    'style_prompt' => $style_prompt,
                    'style_image' => $style_image,
                    'sort_order' => $sort_order,
                ),
                array('id' => $style_id),
                array('%s', '%s', '%s', '%d'),
                array('%d')
            );
            echo '<div class="updated xb_aiimage_edit_auto_hide_message"><p>风格已更新！</p></div>';
        }
    }

    if (isset($_POST['xb_aiimage_edit_delete_style'])) {
        check_admin_referer('xb_aiimage_edit_delete_style_nonce');
        $style_id = absint($_POST['style_id']);
        $wpdb->delete($styles_table, array('id' => $style_id), array('%d'));
        echo '<div class="updated xb_aiimage_edit_auto_hide_message"><p>风格已删除！</p></div>';
    }

    $styles = $wpdb->get_results("SELECT * FROM $styles_table ORDER BY sort_order ASC, id ASC");
    $edit_style = null;
    if (isset($_GET['edit']) && absint($_GET['edit'])) {
        $edit_style = $wpdb->get_row($wpdb->prepare("SELECT * FROM $styles_table WHERE id = %d", absint($_GET['edit'])));
    }
    ?>
    <div class="wrap">
        <h1>预设风格管理</h1>
        
        <h2><?php echo $edit_style ? '编辑风格' : '添加新风格'; ?></h2>
        <form method="post">
            <?php wp_nonce_field('xb_aiimage_edit_style_nonce'); ?>
            <?php if ($edit_style): ?>
                <input type="hidden" name="style_id" value="<?php echo esc_attr($edit_style->id); ?>">
            <?php endif; ?>
            <table class="form-table">
                <tr>
                    <th><label for="style_title">风格标题</label></th>
                    <td><input type="text" name="style_title" id="style_title" value="<?php echo $edit_style ? esc_attr($edit_style->style_title) : ''; ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="style_prompt">风格提示词</label></th>
                    <td><textarea name="style_prompt" id="style_prompt" rows="3" class="large-text" required><?php echo $edit_style ? esc_textarea($edit_style->style_prompt) : ''; ?></textarea></td>
                </tr>
                <tr>
                    <th><label for="style_image">风格示例图</label></th>
                    <td><input type="url" name="style_image" id="style_image" value="<?php echo $edit_style ? esc_url($edit_style->style_image) : ''; ?>" class="regular-text" placeholder="图片链接（可选）"></td>
                </tr>
                <tr>
                    <th><label for="sort_order">排序</label></th>
                    <td><input type="number" name="sort_order" id="sort_order" value="<?php echo $edit_style ? esc_attr($edit_style->sort_order) : '0'; ?>" min="0"></td>
                </tr>
            </table>
            <p>
                <input type="submit" name="<?php echo $edit_style ? 'xb_aiimage_edit_update_style' : 'xb_aiimage_edit_add_style'; ?>" class="button-primary" value="<?php echo $edit_style ? '更新风格' : '添加风格'; ?>">
                <?php if ($edit_style): ?>
                    <a href="<?php echo admin_url('admin.php?page=xb_aiimage_edit_styles'); ?>" class="button">取消编辑</a>
                <?php endif; ?>
            </p>
        </form>

        <h2>已有风格</h2>
        <table class="widefat">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>风格标题</th>
                    <th>风格提示词</th>
                    <th>示例图</th>
                    <th>排序</th>
                    <th>创建时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($styles)): ?>
                    <tr><td colspan="7">暂无风格。</td></tr>
                <?php else: ?>
                    <?php foreach ($styles as $style): ?>
                        <tr>
                            <td><?php echo esc_html($style->id); ?></td>
                            <td><?php echo esc_html($style->style_title); ?></td>
                            <td><?php echo esc_html(mb_substr($style->style_prompt, 0, 50) . (mb_strlen($style->style_prompt) > 50 ? '...' : '')); ?></td>
                            <td>
                                <?php if ($style->style_image): ?>
                                    <img src="<?php echo esc_url($style->style_image); ?>" style="width:50px;height:50px;object-fit:cover;" alt="示例图">
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($style->sort_order); ?></td>
                            <td><?php echo esc_html($style->created_time); ?></td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=xb_aiimage_edit_styles&edit=' . $style->id); ?>" class="button-small">编辑</a>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_aiimage_edit_delete_style_nonce'); ?>
                                    <input type="hidden" name="style_id" value="<?php echo esc_attr($style->id); ?>">
                                    <input type="submit" name="xb_aiimage_edit_delete_style" class="button-small" value="删除" onclick="return confirm('确定删除此风格？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aiimage_edit_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}

// 示例演示管理页面
function xb_aiimage_edit_demos_page() {
    if (!current_user_can('manage_options')) {
        wp_die('无权限访问此页面');
    }

    global $wpdb;
    $demos_table = $wpdb->prefix . 'xb_aiimage_edit_demos';

    // 添加演示
    if (isset($_POST['xb_aiimage_edit_add_demo'])) {
        check_admin_referer('xb_aiimage_edit_demo_nonce');
        $demo_title = sanitize_text_field($_POST['demo_title']);
        $original_image = sanitize_url($_POST['original_image']);
        $result_image = sanitize_url($_POST['result_image']);
        $sort_order = absint($_POST['sort_order']);

        if (!empty($demo_title) && !empty($original_image) && !empty($result_image)) {
            $wpdb->insert(
                $demos_table,
                array(
                    'demo_title' => $demo_title,
                    'original_image' => $original_image,
                    'result_image' => $result_image,
                    'sort_order' => $sort_order,
                    'created_time' => current_time('mysql'),
                )
            );
            echo '<div class="updated xb_aiimage_edit_auto_hide_message"><p>演示已添加！</p></div>';
        }
    }

    // 编辑演示
    if (isset($_POST['xb_aiimage_edit_update_demo'])) {
        check_admin_referer('xb_aiimage_edit_demo_nonce');
        $demo_id = absint($_POST['demo_id']);
        $demo_title = sanitize_text_field($_POST['demo_title']);
        $original_image = sanitize_url($_POST['original_image']);
        $result_image = sanitize_url($_POST['result_image']);
        $sort_order = absint($_POST['sort_order']);

        if (!empty($demo_title) && !empty($original_image) && !empty($result_image)) {
            $wpdb->update(
                $demos_table,
                array(
                    'demo_title' => $demo_title,
                    'original_image' => $original_image,
                    'result_image' => $result_image,
                    'sort_order' => $sort_order,
                ),
                array('id' => $demo_id),
                array('%s', '%s', '%s', '%d'),
                array('%d')
            );
            echo '<div class="updated xb_aiimage_edit_auto_hide_message"><p>演示已更新！</p></div>';
        }
    }

    // 删除演示
    if (isset($_POST['xb_aiimage_edit_delete_demo'])) {
        check_admin_referer('xb_aiimage_edit_delete_demo_nonce');
        $demo_id = absint($_POST['demo_id']);
        $wpdb->delete($demos_table, array('id' => $demo_id), array('%d'));
        echo '<div class="updated xb_aiimage_edit_auto_hide_message"><p>演示已删除！</p></div>';
    }

    $demos = $wpdb->get_results("SELECT * FROM $demos_table ORDER BY sort_order ASC, id ASC");
    $edit_demo = null;
    if (isset($_GET['edit']) && absint($_GET['edit'])) {
        $edit_demo = $wpdb->get_row($wpdb->prepare("SELECT * FROM $demos_table WHERE id = %d", absint($_GET['edit'])));
    }
    ?>
    <div class="wrap">
        <h1>示例演示管理</h1>
        
        <h2><?php echo $edit_demo ? '编辑演示' : '添加新演示'; ?></h2>
        <form method="post">
            <?php wp_nonce_field('xb_aiimage_edit_demo_nonce'); ?>
            <?php if ($edit_demo): ?>
                <input type="hidden" name="demo_id" value="<?php echo esc_attr($edit_demo->id); ?>">
            <?php endif; ?>
            <table class="form-table">
                <tr>
                    <th><label for="demo_title">演示标题</label></th>
                    <td><input type="text" name="demo_title" id="demo_title" value="<?php echo $edit_demo ? esc_attr($edit_demo->demo_title) : ''; ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="original_image">原始图片链接</label></th>
                    <td><input type="url" name="original_image" id="original_image" value="<?php echo $edit_demo ? esc_url($edit_demo->original_image) : ''; ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="result_image">转换后图片链接</label></th>
                    <td><input type="url" name="result_image" id="result_image" value="<?php echo $edit_demo ? esc_url($edit_demo->result_image) : ''; ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="sort_order">排序</label></th>
                    <td><input type="number" name="sort_order" id="sort_order" value="<?php echo $edit_demo ? esc_attr($edit_demo->sort_order) : '0'; ?>" min="0"></td>
                </tr>
            </table>
            <p>
                <input type="submit" name="<?php echo $edit_demo ? 'xb_aiimage_edit_update_demo' : 'xb_aiimage_edit_add_demo'; ?>" class="button-primary" value="<?php echo $edit_demo ? '更新演示' : '添加演示'; ?>">
                <?php if ($edit_demo): ?>
                    <a href="<?php echo admin_url('admin.php?page=xb_aiimage_edit_demos'); ?>" class="button">取消编辑</a>
                <?php endif; ?>
            </p>
        </form>

        <h2>已有演示</h2>
        <table class="widefat">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>演示标题</th>
                    <th>原始图片</th>
                    <th>转换后图片</th>
                    <th>排序</th>
                    <th>创建时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($demos)): ?>
                    <tr><td colspan="7">暂无演示。</td></tr>
                <?php else: ?>
                    <?php foreach ($demos as $demo): ?>
                        <tr>
                            <td><?php echo esc_html($demo->id); ?></td>
                            <td><?php echo esc_html($demo->demo_title); ?></td>
                            <td>
                                <img src="<?php echo esc_url($demo->original_image); ?>" style="width:50px;height:50px;object-fit:cover;" alt="原图">
                            </td>
                            <td>
                                <img src="<?php echo esc_url($demo->result_image); ?>" style="width:50px;height:50px;object-fit:cover;" alt="转换图">
                            </td>
                            <td><?php echo esc_html($demo->sort_order); ?></td>
                            <td><?php echo esc_html($demo->created_time); ?></td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=xb_aiimage_edit_demos&edit=' . $demo->id); ?>" class="button-small">编辑</a>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('xb_aiimage_edit_delete_demo_nonce'); ?>
                                    <input type="hidden" name="demo_id" value="<?php echo esc_attr($demo->id); ?>">
                                    <input type="submit" name="xb_aiimage_edit_delete_demo" class="button-small" value="删除" onclick="return confirm('确定删除此演示？');">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.xb_aiimage_edit_auto_hide_message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(500, function() {
                    $message.remove();
                });
            }, 3000);
        });
    });
    </script>
    <?php
}
?>