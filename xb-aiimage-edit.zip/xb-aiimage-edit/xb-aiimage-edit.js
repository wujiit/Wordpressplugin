jQuery(document).ready(function ($) {
    // 确保 jQuery 加载
    if (typeof $ === 'undefined') {
        console.error('XB AI Image Edit: jQuery 未加载！');
        return;
    }

    // 确保配置存在
    if (typeof xb_aiimage_edit_ajax === 'undefined') {
        console.error('XB AI Image Edit: 配置未定义！');
        return;
    }

    // 全局变量：存储文件URL、任务ID、选中风格、当前结果URL
    let fileUrl = '';
    let taskId = '';
    let selectedStyle = null;
    let currentResultUrl = '';

    // DOM 元素选择器 - 添加存在性检查
    const dropArea = $('#xb_aiimage_edit_drop_area');
    const fileInput = $('#xb_aiimage_edit_file');
    const previewSection = $('#xb_aiimage_edit_preview_section');
    const previewImg = $('#xb_aiimage_edit_preview_img');
    const submitButton = $('#xb_aiimage_edit_submit_button');
    const promptInput = $('#xb_aiimage_edit_prompt');
    const negativePromptInput = $('#xb_aiimage_edit_negative_prompt');
    const modelSelect = $('#xb_aiimage_edit_model');
    const resultSection = $('#xb_aiimage_edit_result_section');
    const resultImg = $('#xb_aiimage_edit_result_img');
    const regenerateBtn = $('#xb_aiimage_edit_regenerate');
    const downloadBtn = $('#xb_aiimage_edit_download');
    const clearAllBtn = $('#xb_aiimage_edit_clear_all');
    const stylesGrid = $('#xb_aiimage_edit_styles_grid');
    const resultArea = $('#xb_aiimage_edit_result');
    const usageInfo = $('.xb_aiimage_edit_usage_info');

    // 检查关键元素是否存在，如果不存在则说明用户次数已用完或未登录
    const isFormAvailable = promptInput.length > 0 && submitButton.length > 0;

    // 初始化图片对比滑块：确保图片加载后调整布局
    function initComparisonSliders() {
        $('.xb-aiimage-comparison').each(function () {
            const slider = this;
            const images = slider.querySelectorAll('img');
            images.forEach(img => {
                img.addEventListener('load', () => {
                    // 图片加载完成后，强制重新布局
                    slider.dispatchEvent(new Event('resize'));
                });
            });
        });
    }

    // 页面加载完成后初始化滑块
    initComparisonSliders();

    // 窗口调整大小时重新触发滑块布局
    $(window).on('resize', function () {
        $('.xb-aiimage-comparison').each(function () {
            this.dispatchEvent(new Event('resize'));
        });
    });

    // 只有在表单可用时才绑定上传相关事件
    if (isFormAvailable && dropArea.length > 0 && fileInput.length > 0) {
        // 修复文件上传点击问题：点击拖拽区域触发文件输入
        dropArea.on('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            fileInput.click(); // 直接触发文件输入点击
        });

        // 确保文件输入点击事件不被阻止
        fileInput.on('click', function (e) {
            e.stopPropagation(); // 阻止事件冒泡
        });

        // 拖拽上传事件：拖入高亮，离开恢复
        dropArea.on('dragover', function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).addClass('xb_aiimage_edit_drop_active');
        });

        dropArea.on('dragleave', function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('xb_aiimage_edit_drop_active');
        });

        dropArea.on('drop', function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('xb_aiimage_edit_drop_active');
            const files = e.originalEvent.dataTransfer.files;
            if (files.length > 0) {
                handleFile(files[0]);
            }
        });

        // 文件输入变化事件：选择文件后处理
        fileInput.on('change', function () {
            if (this.files && this.files.length > 0) {
                handleFile(this.files[0]);
            }
        });
    }

    // 文件处理函数：验证类型、大小，并上传
    function handleFile(file) {
        // 验证文件类型
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/bmp', 'image/tiff', 'image/webp'];
        if (!allowedTypes.includes(file.type.toLowerCase())) {
            showToast('不支持的文件格式！', 'error');
            return;
        }

        // 验证文件大小
        const maxSize = 10 * 1024 * 1024; // 10MB
        if (file.size > maxSize) {
            showToast('文件大小超出限制！', 'error');
            return;
        }

        // 上传文件到服务器
        const formData = new FormData();
        formData.append('file', file);
        formData.append('action', 'xb_aiimage_edit_upload');
        formData.append('_wpnonce', xb_aiimage_edit_ajax.upload_nonce);

        $.ajax({
            url: xb_aiimage_edit_ajax.upload_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function () {
                if (submitButton.length > 0) {
                    submitButton.prop('disabled', true).html('<span class="xb_aiimage_edit_button_icon">⏳</span>上传中...');
                }
                if (dropArea.length > 0) {
                    dropArea.addClass('xb_aiimage_edit_uploading');
                }
            },
            success: function (response) {
                if (response.success) {
                    fileUrl = response.data.url;
                    $('#xb_aiimage_edit_file_url').val(fileUrl);
                    if (previewImg.length > 0) {
                        previewImg.attr('src', fileUrl);
                    }
                    if (previewSection.length > 0) {
                        previewSection.show();
                    }
                    if (dropArea.length > 0) {
                        dropArea.hide();
                    }
                    updateSubmitButton();
                    //showToast('图片上传成功！', 'success');
                } else {
                    showToast('文件上传失败：' + (response.data && response.data.message || '未知错误'), 'error');
                    resetUploadButton();
                }
            },
            error: function (xhr) {
                const message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ?
                    xhr.responseJSON.data.message : '文件上传失败，请重试！';
                showToast(message, 'error');
                resetUploadButton();
            }
        });
    }

    // 更新提交按钮状态：根据是否有图片和提示词启用/禁用
    function updateSubmitButton() {
        // 检查按钮是否存在
        if (submitButton.length === 0) {
            return;
        }

        const hasImage = fileUrl !== '';
        // 安全地检查提示词输入框是否存在
        const hasPrompt = (promptInput.length > 0 && promptInput.val().trim() !== '') || selectedStyle !== null;
        
        if (hasImage && hasPrompt) {
            submitButton.prop('disabled', false).html('<span class="xb_aiimage_edit_button_icon">🚀</span>开始处理');
        } else if (!hasImage) {
            submitButton.prop('disabled', true).html('<span class="xb_aiimage_edit_button_icon">📤</span>请先上传图片');
        } else {
            submitButton.prop('disabled', true).html('<span class="xb_aiimage_edit_button_icon">✏️</span>请输入提示词或选择风格');
        }
    }

    // 重置上传按钮状态：恢复默认
    function resetUploadButton() {
        if (submitButton.length > 0) {
            submitButton.prop('disabled', true).html('<span class="xb_aiimage_edit_button_icon">🚀</span>开始处理');
        }
        if (dropArea.length > 0) {
            dropArea.removeClass('xb_aiimage_edit_uploading');
        }
    }

    // 只有在表单可用时才绑定输入事件
    if (isFormAvailable) {
        // 提示词输入监听：输入时清除风格选择，并更新按钮
        promptInput.on('input', function () {
            if ($(this).val().trim() !== '') {
                clearStyleSelection();
            }
            updateSubmitButton();
        });

        if (negativePromptInput.length > 0) {
            negativePromptInput.on('input', function () {
                // 违规词检查由后端处理，无需前端干预
            });
        }
    }

    // 风格选择处理：点击风格项切换选中状态
    if (stylesGrid.length > 0) {
        stylesGrid.on('click', '.xb_aiimage_edit_style_item', function () {
            const prompt = $(this).data('prompt');
            
            if (selectedStyle === prompt) {
                clearStyleSelection();
            } else {
                selectedStyle = prompt;
                $('.xb_aiimage_edit_style_item').removeClass('selected');
                $(this).addClass('selected');
                if (promptInput.length > 0) {
                    promptInput.val('');
                }
                if (negativePromptInput.length > 0) {
                    negativePromptInput.val('');
                }
                showToast('已选择预设风格', 'info');
            }
            
            updateSubmitButton();
        });
    }

    // 清除风格选择：移除所有选中类
    function clearStyleSelection() {
        selectedStyle = null;
        $('.xb_aiimage_edit_style_item').removeClass('selected');
    }

    // 移除图片：点击移除按钮重置表单
    $(document).on('click', '.xb_aiimage_edit_remove_image', function (e) {
        e.preventDefault();
        resetForm();
    });

    // 表单提交处理：发送 AJAX 请求到 REST API
    if (isFormAvailable) {
        $('#xb_aiimage_edit_form').on('submit', function (e) {
            e.preventDefault();
            
            if (!fileUrl) {
                showToast('请先上传图片！', 'error');
                return;
            }

            let prompt = selectedStyle || (promptInput.length > 0 ? promptInput.val().trim() : '');
            let negativePrompt = negativePromptInput.length > 0 ? negativePromptInput.val().trim() : '';
            const aiModel = modelSelect.length > 0 ? modelSelect.val() || '' : '';

            if (!prompt) {
                showToast('请输入提示词或选择预设风格！', 'error');
                return;
            }

            $.ajax({
                url: xb_aiimage_edit_ajax.rest_url,
                type: 'POST',
                data: JSON.stringify({
                    image_url: fileUrl,
                    prompt: prompt,
                    negative_prompt: negativePrompt,
                    ai_model: aiModel
                }),
                contentType: 'application/json',
                headers: { 'X-WP-Nonce': xb_aiimage_edit_ajax.nonce },
                beforeSend: function () {
                    if (submitButton.length > 0) {
                        submitButton.prop('disabled', true).html('<span class="xb_aiimage_edit_button_icon">⏳</span>处理中...');
                    }
                    showLoadingMessage();
                    hideActionButtons();
                },
                success: function (response) {
                    if (response.status === 'success' && response.result_url) {
                        showResult(response.result_url);
                        updateUsageInfo(response.remaining, response.limit);
                    } else if (response.task_id) {
                        taskId = response.task_id;
                        setTimeout(function () {
                            checkResult(taskId);
                        }, 3000);
                    } else {
                        showToast(response.message || '处理失败，请重试', 'error');
                        resetForm();
                    }
                },
                error: function (xhr) {
                    const message = xhr.responseJSON && xhr.responseJSON.message ?
                        xhr.responseJSON.message : '暂时无法处理请联系客服';
                    showToast(message, 'error');
                    resetForm();
                }
            });
        });
    }

    // 检查处理结果：轮询检查任务状态
    function checkResult(task_id) {
        const maxAttempts = 30;
        let attempts = 0;

        const poll = setInterval(function () {
            if (attempts >= maxAttempts) {
                clearInterval(poll);
                showToast('处理超时，请稍后重试', 'error');
                resetForm();
                return;
            }

            $.ajax({
                url: xb_aiimage_edit_ajax.check_result_url,
                type: 'POST',
                data: JSON.stringify({ task_id: task_id }),
                contentType: 'application/json',
                headers: { 'X-WP-Nonce': xb_aiimage_edit_ajax.nonce },
                success: function (response) {
                    if (response.status === 'success' && response.result_url) {
                        clearInterval(poll);
                        showResult(response.result_url);
                        updateUsageInfo(response.remaining, response.limit);
                    } else if (response.status === 'pending') {
                        attempts++;
                    } else {
                        clearInterval(poll);
                        showToast(response.message || '暂时无法处理请联系客服', 'error');
                        resetForm();
                    }
                },
                error: function (xhr) {
                    clearInterval(poll);
                    const message = xhr.responseJSON && xhr.responseJSON.message ?
                        xhr.responseJSON.message : '查询结果失败，请重试';
                    showToast(message, 'error');
                    resetForm();
                }
            });
        }, 5000);
    }

    // 显示处理结果：更新结果图片并显示按钮
    function showResult(resultUrl) {
        currentResultUrl = resultUrl;
        if (resultImg.length > 0) {
            resultImg.attr('src', resultUrl);
        }
        if (resultSection.length > 0) {
            resultSection.show();
        }
        showActionButtons();
        resetSubmitButton();
        hideLoadingMessage();
        //showToast('图片处理完成！', 'success');
        
        // 将结果保存到会话存储，仅在当前会话有效
        sessionStorage.setItem('xb_aiimage_edit_last_result', JSON.stringify({
            url: resultUrl,
            timestamp: Date.now()
        }));
    }

    // 显示加载信息：添加加载动画
    function showLoadingMessage() {
        if (resultArea.length > 0) {
            resultArea.html(
                '<div class="xb_aiimage_edit_loading">' +
                '<div class="xb_aiimage_edit_spinner"></div>' +
                '<div class="xb_aiimage_edit_ts_subtitle">🔄 正在处理中</div>' +
                '<p>请稍候，AI正在为您处理图片...</p>' +
                '</div>'
            );
        }
    }

    // 隐藏加载信息：移除加载元素
    function hideLoadingMessage() {
        $('.xb_aiimage_edit_loading').remove();
    }

    // 显示操作按钮：重新生成和下载
    function showActionButtons() {
        if (regenerateBtn.length > 0) {
            regenerateBtn.show();
        }
        if (downloadBtn.length > 0) {
            downloadBtn.show();
        }
    }

    // 隐藏操作按钮
    function hideActionButtons() {
        if (regenerateBtn.length > 0) {
            regenerateBtn.hide();
        }
        if (downloadBtn.length > 0) {
            downloadBtn.hide();
        }
    }

    // 重置提交按钮：恢复默认状态
    function resetSubmitButton() {
        if (submitButton.length > 0) {
            submitButton.prop('disabled', false).html('<span class="xb_aiimage_edit_button_icon">🚀</span>开始处理');
        }
    }

    // 更新使用次数信息：刷新剩余次数显示
    function updateUsageInfo(remaining, limit) {
        if (remaining !== undefined && limit !== undefined && usageInfo.length > 0) {
            usageInfo.html(
                '<span class="xb_aiimage_edit_usage_icon">📊</span>今日剩余生成次数：' + remaining + '/' + limit
            );
            // 当次数用完时，隐藏上传区域但保留结果显示
            if (remaining <= 0) {
                hideUploadAreaButKeepResult();
                // 清除会话存储，避免刷新后仍显示结果
                sessionStorage.removeItem('xb_aiimage_edit_last_result');
            }
        }
    }

    // 隐藏上传区域但保持结果显示
    function hideUploadAreaButKeepResult() {
        // 只隐藏上传相关的元素，保留结果显示
        $('.xb_aiimage_edit_prompt_section, .xb_aiimage_edit_upload_section, .xb_aiimage_edit_preview_section').fadeOut(300);
        if (submitButton.length > 0) {
            submitButton.fadeOut(300);
        }
        if (clearAllBtn.length > 0) {
            clearAllBtn.fadeOut(300);
        }
        if (regenerateBtn.length > 0) {
            regenerateBtn.fadeOut(300); // 隐藏重新生成按钮
        }
        
        // 显示次数用完的提示，但不影响结果显示
        setTimeout(function() {
            const limitMessage =
                '<div class="xb_aiimage_edit_message xb_aiimage_edit_message_info" style="margin-top: 20px;">' +
                '<div class="xb_aiimage_edit_message_icon">📅</div>' +
                '<div class="xb_aiimage_edit_message_content">' +
                '<div class="xb_aiimage_edit_ts_subtitle">今日使用次数已用完</div>' +
                '<p>您今日的编辑次数已用完，请明天再来。</p>' +
                '</div>' +
                '</div>';
            $('.xb_aiimage_edit_config_section').append(limitMessage);
        }, 300);
    }

    // 只有在按钮存在时才绑定事件
    if (regenerateBtn.length > 0) {
        // 重新生成按钮：触发表单提交
        regenerateBtn.on('click', function (e) {
            e.preventDefault();
            if ($('#xb_aiimage_edit_form').length > 0) {
                $('#xb_aiimage_edit_form').trigger('submit');
            }
        });
    }

    if (downloadBtn.length > 0) {
        // 下载按钮使用简单直接的下载方式
        downloadBtn.on('click', function (e) {
            e.preventDefault();
            if (currentResultUrl) {
                downloadImageDirect(currentResultUrl);
            } else {
                showToast('无图片可下载！', 'error');
            }
        });
    }

    // 使用简单的链接下载方式
    function downloadImageDirect(imageUrl) {
        showToast('开始下载图片...', 'info');
        
        try {
            // 创建隐藏的下载链接
            const link = document.createElement('a');
            link.href = imageUrl;
            link.download = 'ai_edited_image_' + Date.now() + '.jpg';
            link.target = '_blank'; // 在新窗口打开，确保下载
            link.style.display = 'none';
            
            // 添加到页面并触发点击
            document.body.appendChild(link);
            link.click();
            
            // 清理DOM
            setTimeout(() => {
                document.body.removeChild(link);
            }, 100);
            
            showToast('图片下载开始！', 'success');
        } catch (error) {
            console.error('下载失败:', error);
            // 备用方案：直接在新窗口打开图片
            window.open(imageUrl, '_blank');
            showToast('已在新窗口打开图片，请右键保存', 'info');
        }
    }

    // 处理次数用完后显示的最后结果下载按钮
    $(document).on('click', '.xb_aiimage_edit_download_button[data-result-url]', function(e) {
        e.preventDefault();
        const resultUrl = $(this).data('result-url');
        if (resultUrl) {
            downloadImageDirect(resultUrl);
        } else {
            showToast('无图片可下载！', 'error');
        }
    });

    if (clearAllBtn.length > 0) {
        // 清空全部按钮：重置表单和结果
        clearAllBtn.on('click', function (e) {
            e.preventDefault();
            resetForm();
            if (resultArea.length > 0) {
                resultArea.empty();
            }
            hideActionButtons();
        });
    }

    // 重置表单：清除所有输入和预览
    function resetForm() {
        if (fileInput.length > 0) {
            fileInput.val('');
        }
        $('#xb_aiimage_edit_file_url').val('');
        if (promptInput.length > 0) {
            promptInput.val('');
        }
        if (negativePromptInput.length > 0) {
            negativePromptInput.val('');
        }
        if (previewSection.length > 0) {
            previewSection.hide();
        }
        if (resultSection.length > 0) {
            resultSection.hide();
        }
        if (dropArea.length > 0) {
            dropArea.show().removeClass('xb_aiimage_edit_uploading');
        }
        clearStyleSelection();
        fileUrl = '';
        taskId = '';
        currentResultUrl = '';
        updateSubmitButton();
        hideLoadingMessage();
    }

    // 显示提示消息：创建居中 toast 提示
    function showToast(message, type = 'info') {
        const toast = $('<div class="xb_aiimage_edit_toast ' + type + '">' +
            '<span class="icon">' + getToastIcon(type) + '</span>' +
            '<span>' + message + '</span>' +
            '</div>');
        
        $('body').append(toast);
        toast.css({
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)'
        });

        // 根据类型设置不同的显示时间
        const displayTime = type === 'info' ? 1500 : 3000;
        
        setTimeout(function () {
            toast.fadeOut(300, function () {
                toast.remove();
            });
        }, 3000);
    }

    // 获取提示图标：根据类型返回 emoji
    function getToastIcon(type) {
        switch (type) {
            case 'success': return '✅';
            case 'error': return '❌';
            case 'info': return 'ℹ️';
            default: return 'ℹ️';
        }
    }

    // 快速登录处理：点击登录按钮触发主题登录或跳转
    $(document).on('click', '.xb_aiimage_edit_login_btn', function (e) {
        e.preventDefault();
        const $themeLoginBtn = $('.nav-login .signin-loader');
        if ($themeLoginBtn.length) {
            $themeLoginBtn.trigger('click');
        } else {
            window.location.href = $(this).attr('href');
        }
    });

    // 页面加载时检查会话存储中的结果
    function checkSessionResult() {
        const savedResult = sessionStorage.getItem('xb_aiimage_edit_last_result');
        if (savedResult) {
            try {
                const resultData = JSON.parse(savedResult);
                // 检查结果是否在1小时内（图片可能有时效性）
                const oneHour = 60 * 60 * 1000;
                if (Date.now() - resultData.timestamp < oneHour) {
                    // 只有在当前会话且时间未过期时才显示结果
                    currentResultUrl = resultData.url;
                    if (resultImg.length > 0) {
                        resultImg.attr('src', resultData.url);
                    }
                    if (resultSection.length > 0) {
                        resultSection.show();
                    }
                    if (downloadBtn.length > 0) {
                        downloadBtn.show(); // 只显示下载按钮
                    }
                } else {
                    // 过期则清除
                    sessionStorage.removeItem('xb_aiimage_edit_last_result');
                }
            } catch (e) {
                sessionStorage.removeItem('xb_aiimage_edit_last_result');
            }
        }
    }

    // 页面刷新时清除会话存储（防止刷新后仍显示）
    $(window).on('beforeunload', function() {
        // 如果用户次数已用完，清除结果存储
        if (usageInfo.length > 0) {
            const usageText = usageInfo.text();
            if (usageText.includes('0/') || usageText.includes('已用完')) {
                sessionStorage.removeItem('xb_aiimage_edit_last_result');
            }
        }
    });

    // 初始化：更新按钮状态和检查会话结果
    updateSubmitButton();
    checkSessionResult();
});