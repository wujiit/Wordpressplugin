jQuery(document).ready(function($) {
    // 防抖函数
    function debounce(func, wait) {
        let timeout;
        return function() {
            clearTimeout(timeout);
            timeout = setTimeout(func, wait);
        };
    }

    // 显示消息
    function showMessage(message, type = 'error') {
        const $messageDiv = $('#xb_rdpic_message');
        $messageDiv.text(message)
            .css({
                'display': 'block',
                'background': type === 'error' ? '#f8d7da' : '#d4edda',
                'color': type === 'error' ? '#721c24' : '#155724',
                'padding': '10px',
                'margin': '10px 0',
                'border-radius': '5px',
                'text-align': 'center'
            });
        setTimeout(() => {
            $messageDiv.fadeOut(500, () => $messageDiv.text(''));
        }, 3000);
    }

    // 获取图片（随机或下一张）
    function getImage(isNext = false) {
        $('#xb_rdpic_next').prop('disabled', true);
        const currentId = isNext ? $('#xb_rdpic_current_id').val() : 0;
        $.ajax({
            url: xb_rdpic_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'xb_rdpic_get_image',
                nonce: xb_rdpic_ajax.nonce,
                current_id: currentId
            },
            success: function(response) {
                if (response.success) {
                    $('#xb_rdpic_image').attr('src', response.data.image_url).css('opacity', 0).animate({opacity: 1}, 300);
                    $('#xb_rdpic_current_id').val(response.data.image_id);
                    $('#xb_rdpic_desc').text(response.data.image_desc || '');
                    $('#xb_rdpic_source').text(response.data.image_source ? '来源: ' + response.data.image_source : '');
                    $('#xb_rdpic_original').toggle(!!response.data.original_url);
                    if (response.data.original_url) {
                        $('#xb_rdpic_original').attr('href', response.data.original_url);
                    }
                } else {
                    showMessage(response.data.message || '无法加载图片，请稍后重试！');
                }
            },
            error: function(xhr, status, error) {
                showMessage('加载图片失败，请检查网络！');
            },
            complete: function() {
                $('#xb_rdpic_next').prop('disabled', false);
            }
        });
    }

    // 初始加载随机图片
    getImage(false);

    // 换一张图片（添加防抖）
    $('#xb_rdpic_next').on('click', debounce(function() {
        getImage(true);
    }, 200));

    // 保存图片（触发下载）
    $('#xb_rdpic_save').on('click', function() {
        const imageUrl = $('#xb_rdpic_image').attr('src');
        fetch(imageUrl)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.blob();
            })
            .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = 'image.jpg';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                window.URL.revokeObjectURL(url);
            })
            .catch(error => {
                console.log('Failed to download image: ' + error);
                showMessage('图片下载失败，请重试！');
            });
    });

    // 原图下载
    $('#xb_rdpic_original').on('click', function(e) {
        e.preventDefault();
        window.open($(this).attr('href'), '_blank');
    });
});