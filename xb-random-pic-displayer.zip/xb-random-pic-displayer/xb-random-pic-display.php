<?php
/*
Plugin Name: 小半随机美图
Description: 随机展示图片的WordPress插件，支持图片管理和现代化前台展示
Version: 1.0.1
Author: summer
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 插件激活时执行
 */
register_activation_hook(__FILE__, 'xb_rdpic_install');
function xb_rdpic_install() {
    xb_rdpic_create_database();
    xb_rdpic_create_front_page();
}

/**
 * 创建数据库表
 */
function xb_rdpic_create_database() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_rdpic_';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        image_url varchar(255) NOT NULL,
        image_desc text,
        image_source varchar(255),
        original_url varchar(255),
        view_count bigint(20) DEFAULT 0,
        today_view_count bigint(20) DEFAULT 0,
        last_view_date date,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

/**
 * 创建前台页面
 */
function xb_rdpic_create_front_page() {
    if (!get_page_by_path('random-picture')) {
        $page = array(
            'post_title' => '随机美图推荐',
            'post_content' => '[xb_rdpic_display]',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_name' => 'random-picture'
        );
        wp_insert_post($page);
    }
}

/**
 * 加载前端资源
 */
function xb_rdpic_enqueue_assets() {
    // 检查当前页面是否有短代码
    $post = get_post();
    if ($post && has_shortcode($post->post_content, 'xb_rdpic_display')) {
        wp_enqueue_style(
            'xb_rdpic_styles',
            plugin_dir_url(__FILE__) . 'xb_rdpic_styles.css',
            array(),
            '1.0'
        );
        wp_enqueue_script(
            'xb_rdpic_scripts',
            plugin_dir_url(__FILE__) . 'xb_rdpic_scripts.js',
            array('jquery'),
            '1.0',
            true
        );
        wp_localize_script('xb_rdpic_scripts', 'xb_rdpic_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('xb_rdpic_nonce')
        ));
    }
}
add_action('wp_enqueue_scripts', 'xb_rdpic_enqueue_assets');

/**
 * 添加后台菜单
 */
function xb_rdpic_admin_menu() {
    add_menu_page(
        '随机美图管理',
        '随机美图',
        'manage_options',
        'xb_rdpic_manager',
        'xb_rdpic_admin_page',
        'dashicons-images-alt2'
    );
}
add_action('admin_menu', 'xb_rdpic_admin_menu');

/**
 * 后台管理页面
 */
function xb_rdpic_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_rdpic_';
    $message = '';

    // 处理添加/编辑表单提交
    if (isset($_POST['xb_rdpic_submit']) && check_admin_referer('xb_rdpic_save')) {
        $image_url = sanitize_text_field($_POST['image_url']);
        $image_desc = sanitize_textarea_field($_POST['image_desc']);
        $image_source = sanitize_text_field($_POST['image_source']);
        $original_url = sanitize_text_field($_POST['original_url']);
        $image_id = isset($_POST['image_id']) ? intval($_POST['image_id']) : 0;

        if (!empty($image_url)) {
            $data = array(
                'image_url' => $image_url,
                'image_desc' => $image_desc,
                'image_source' => $image_source,
                'original_url' => $original_url
            );

            try {
                if ($image_id > 0) {
                    // 更新现有记录
                    $result = $wpdb->update($table_name, $data, array('id' => $image_id));
                    if ($result !== false) {
                        $message = '<div class="notice notice-success is-dismissible"><p>图片更新成功！</p></div>';
                        // 清除编辑状态
                        echo '<script>window.history.replaceState(null, null, "' . esc_url(admin_url('admin.php?page=xb_rdpic_manager')) . '");</script>';
                    } else {
                        $message = '<div class="notice notice-error is-dismissible"><p>图片更新失败，请检查数据！</p></div>';
                    }
                } else {
                    // 插入新记录
                    $result = $wpdb->insert($table_name, $data);
                    if ($result !== false) {
                        $message = '<div class="notice notice-success is-dismissible"><p>图片添加成功！</p></div>';
                    } else {
                        $message = '<div class="notice notice-error is-dismissible"><p>图片添加失败，请检查数据！</p></div>';
                    }
                }
            } catch (Exception $e) {
                $message = '<div class="notice notice-error is-dismissible"><p>发生错误：' . esc_html($e->getMessage()) . '</p></div>';
            }
        } else {
            $message = '<div class="notice notice-error is-dismissible"><p>图片链接不能为空！</p></div>';
        }
    }

    // 处理删除
    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
        $result = $wpdb->delete($table_name, array('id' => intval($_GET['id'])));
        if ($result) {
            $message = '<div class="notice notice-success is-dismissible"><p>图片删除成功！</p></div>';
        } else {
            $message = '<div class="notice notice-error is-dismissible"><p>图片删除失败，请重试！</p></div>';
        }
        echo '<script>window.history.replaceState(null, null, "' . esc_url(admin_url('admin.php?page=xb_rdpic_manager')) . '");</script>';
    }

    // 获取编辑数据（仅在未提交表单时加载）
    $edit_image = null;
    if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id']) && empty($_POST)) {
        $edit_image = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", intval($_GET['id'])));
        if (!$edit_image) {
            $message = '<div class="notice notice-error is-dismissible"><p>图片不存在！</p></div>';
            echo '<script>window.history.replaceState(null, null, "' . esc_url(admin_url('admin.php?page=xb_rdpic_manager')) . '");</script>';
        }
    }

    // 分页逻辑
    $per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;
    $total_images = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $total_pages = ceil($total_images / $per_page);

    // 获取图片列表（带分页）
    $images = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name ORDER BY id DESC LIMIT %d OFFSET %d",
        $per_page,
        $offset
    ));

    ?>
    <div class="wrap">
        <h1>随机美图管理</h1>
        <?php echo $message; ?>
        
        <!-- 添加/编辑图片表单 -->
        <form method="post">
            <?php wp_nonce_field('xb_rdpic_save'); ?>
            <?php if ($edit_image): ?>
                <input type="hidden" name="image_id" value="<?php echo esc_attr($edit_image->id); ?>">
                <h2>编辑图片</h2>
            <?php else: ?>
                <h2>添加新图片</h2>
            <?php endif; ?>
            <table class="form-table">
                <tr>
                    <th><label for="image_url">图片链接 *</label></th>
                    <td><input type="url" name="image_url" id="image_url" value="<?php echo esc_attr($edit_image->image_url ?? ''); ?>" required class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="image_desc">图片说明</label></th>
                    <td><textarea name="image_desc" id="image_desc" class="large-text" rows="4"><?php echo esc_textarea($edit_image->image_desc ?? ''); ?></textarea></td>
                </tr>
                <tr>
                    <th><label for="image_source">图片来源</label></th>
                    <td><input type="text" name="image_source" id="image_source" value="<?php echo esc_attr($edit_image->image_source ?? ''); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="original_url">原图下载链接</label></th>
                    <td><input type="url" name="original_url" id="original_url" value="<?php echo esc_attr($edit_image->original_url ?? ''); ?>" class="regular-text"></td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="xb_rdpic_submit" class="button-primary" value="<?php echo $edit_image ? '更新图片' : '添加图片'; ?>"></p>
        </form>

        <!-- 图片列表 -->
        <h2>图片列表</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>图片</th>
                    <th>说明</th>
                    <th>来源</th>
                    <th>原图链接</th>
                    <th>总浏览</th>
                    <th>今日浏览</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($images)): ?>
                    <tr><td colspan="7">暂无图片数据</td></tr>
                <?php else: ?>
                    <?php foreach ($images as $image): ?>
                    <tr>
                        <td><img src="<?php echo esc_url($image->image_url); ?>" style="max-width:100px;"></td>
                        <td><?php echo esc_html($image->image_desc); ?></td>
                        <td><?php echo esc_html($image->image_source); ?></td>
                        <td><?php echo esc_url($image->original_url); ?></td>
                        <td><?php echo esc_html($image->view_count); ?></td>
                        <td><?php echo esc_html($image->today_view_count); ?></td>
                        <td>
                            <a href="<?php echo esc_url(add_query_arg(['action' => 'edit', 'id' => $image->id])); ?>">编辑</a> |
                            <a href="<?php echo esc_url(add_query_arg(['action' => 'delete', 'id' => $image->id])); ?>" 
                               onclick="return confirm('确定删除?')">删除</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- 分页导航 -->
        <?php if ($total_pages > 1): ?>
            <div class="tablenav">
                <div class="tablenav-pages">
                    <?php
                    $pagination_args = array(
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'total' => $total_pages,
                        'current' => $current_page,
                        'prev_text' => __('« 上一页'),
                        'next_text' => __('下一页 »'),
                    );
                    echo paginate_links($pagination_args);
                    ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * 前台短代码
 */
function xb_rdpic_display_shortcode() {
    ob_start();
    ?>
    <div class="xb_rdpic_container">
        <div class="xb_rdpic_title">随机Cosplay图片推荐</div>
        <div id="xb_rdpic_message" style="display:none;"></div>
        <div class="xb_rdpic_image_wrapper">
            <img id="xb_rdpic_image" src="" alt="随机Cosplay图片">
            <input type="hidden" id="xb_rdpic_current_id" value="0">
            <div class="xb_rdpic_info">
                <p id="xb_rdpic_desc"></p>
                <p id="xb_rdpic_source"></p>
            </div>
        </div>
        <div class="xb_rdpic_buttons">
            <button id="xb_rdpic_save" class="xb_rdpic_button">保存图片</button>
            <button id="xb_rdpic_next" class="xb_rdpic_button">换一张</button>
            <a id="xb_rdpic_original" class="xb_rdpic_button" style="display:none;">原图下载</a>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('xb_rdpic_display', 'xb_rdpic_display_shortcode');

/**
 * AJAX 获取随机或下一张图片
 */
function xb_rdpic_get_image() {
    check_ajax_referer('xb_rdpic_nonce', 'nonce');
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'xb_rdpic_';
    
    // 清除插件相关缓存
    wp_cache_delete('xb_rdpic_images', 'xb_rdpic');
    
    // 判断是随机加载还是下一张
    $current_id = isset($_POST['current_id']) ? intval($_POST['current_id']) : 0;
    if ($current_id > 0) {
        // 获取下一张图片
        $image = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE id > %d ORDER BY id ASC LIMIT 1",
            $current_id
        ));
        // 如果没有下一张，循环到第一张
        if (!$image) {
            $image = $wpdb->get_row("SELECT * FROM $table_name ORDER BY id ASC LIMIT 1");
        }
    } else {
        // 随机选择一张图片
        $min_max = $wpdb->get_row("SELECT MIN(id) as min_id, MAX(id) as max_id FROM $table_name");
        if ($min_max && $min_max->min_id) {
            $random_id = mt_rand($min_max->min_id, $min_max->max_id);
            $image = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id >= %d LIMIT 1", $random_id));
        }
        // 如果随机失败，选择第一张
        if (!$image) {
            $image = $wpdb->get_row("SELECT * FROM $table_name ORDER BY id ASC LIMIT 1");
        }
    }
    
    if ($image) {
        // 更新图片浏览量
        $today = current_time('Y-m-d');
        $wpdb->update(
            $table_name,
            array(
                'view_count' => $image->view_count + 1,
                'today_view_count' => ($image->last_view_date == $today ? 
                    $image->today_view_count + 1 : 1),
                'last_view_date' => $today
            ),
            array('id' => $image->id)
        );
        
        wp_send_json_success(array(
            'image_id' => $image->id,
            'image_url' => $image->image_url,
            'image_desc' => $image->image_desc,
            'image_source' => $image->image_source,
            'original_url' => $image->original_url
        ));
    }
    
    wp_send_json_error(array('message' => '无法获取图片数据'));
}
add_action('wp_ajax_xb_rdpic_get_image', 'xb_rdpic_get_image');
add_action('wp_ajax_nopriv_xb_rdpic_get_image', 'xb_rdpic_get_image');

?>